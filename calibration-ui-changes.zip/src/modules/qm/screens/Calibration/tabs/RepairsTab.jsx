import { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { AppDataTable, mutedDash, statusCell, currencyCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import { CALIBRATION_ENDPOINTS, REPAIR_STATUS_SEVERITY, useCalibrationUser } from '../../../utils/calibrationConstants';
import ActionDialog from '../components/ActionDialog';

const statusBody = statusCell('status', REPAIR_STATUS_SEVERITY);
const costBody = currencyCell('cost');

const OPEN_FIELDS = [
    { name: 'failureDetails', label: 'Failure Details', type: 'textarea', required: true },
    { name: 'repairAction', label: 'Planned Repair / Adjustment', type: 'textarea' },
    { name: 'vendor', label: 'Vendor' },
    { name: 'cost', label: 'Estimated Cost', type: 'decimal' },
];

const COMPLETE_FIELDS = [
    { name: 'repairAction', label: 'Repair / Adjustment Performed', type: 'textarea', required: true },
    { name: 'vendor', label: 'Vendor' },
    { name: 'cost', label: 'Cost', type: 'decimal' },
    { name: 'completionDate', label: 'Completion Date', type: 'date', required: true },
];

const APPROVE_FIELDS = [{ name: 'approvedBy', label: 'Approved By', required: true, width: 12 }];

/**
 * QM-CAL-009 — repair / adjustment history for one equipment.
 * Flow: open repair → complete repair → submit a retest calibration (record
 * dialog above) → QA manager approves return to service. A passing retest alone
 * does not release the equipment.
 */
const RepairsTab = ({ equipmentId, headers, onChanged }) => {
    const user = useCalibrationUser();
    const [dialog, setDialog] = useState(null); // { type, row? }

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.REPAIRS(equipmentId),
        headers,
    });

    const close = useCallback(() => setDialog(null), []);
    const done = useCallback(() => {
        setDialog(null);
        refetch();
        onChanged?.();
    }, [refetch, onChanged]);

    const actionsBody = (row) => {
        if (row.status === 'OPEN' || row.status === 'IN_PROGRESS') {
            return <Button label="Complete" size="small" text onClick={() => setDialog({ type: 'complete', row })} />;
        }
        if (row.status === 'RETEST_PASSED') {
            return <Button label="Approve Return to Service" size="small" text onClick={() => setDialog({ type: 'approve', row })} />;
        }
        if (row.status === 'COMPLETED') {
            return <span className="text-color-secondary text-sm">Awaiting retest calibration</span>;
        }
        return null;
    };

    return (
        <>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">
                    Failed calibration → repair → retest → QA approval before the equipment returns to service.
                </span>
                <Button label="Open Repair" icon="pi pi-wrench" size="small" onClick={() => setDialog({ type: 'open' })} />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column field="id" header="#" style={{ width: '4rem' }} />
                <Column field="failureDetails" header="Failure" />
                <Column header="Repair Action" body={(r) => r.repairAction || mutedDash()} />
                <Column header="Vendor" body={(r) => r.vendor || mutedDash()} />
                <Column header="Cost" body={costBody} />
                <Column header="Status" body={statusBody} />
                <Column header="Approved By" body={(r) => r.approvedBy || mutedDash()} />
                <Column header="" body={actionsBody} />
            </AppDataTable>

            {dialog?.type === 'open' && (
                <ActionDialog
                    header="Open Repair"
                    fields={OPEN_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.REPAIRS(equipmentId)}
                    headers={headers}
                    submitLabel="Open"
                    successMessage="Repair opened."
                    failureMessage="Could not open repair — the equipment needs a failed calibration."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'complete' && (
                <ActionDialog
                    header="Complete Repair"
                    fields={COMPLETE_FIELDS}
                    defaultValues={{
                        repairAction: dialog.row.repairAction || '',
                        vendor: dialog.row.vendor || '',
                        cost: dialog.row.cost ?? null,
                    }}
                    endpoint={CALIBRATION_ENDPOINTS.REPAIR_COMPLETE(dialog.row.id)}
                    headers={headers}
                    submitLabel="Complete"
                    successMessage="Repair completed — submit a retest calibration next."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'approve' && (
                <ActionDialog
                    header="Approve Return to Service"
                    size="sm"
                    fields={APPROVE_FIELDS}
                    defaultValues={{ approvedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.REPAIR_APPROVE_RETURN(dialog.row.id)}
                    headers={headers}
                    submitLabel="Approve"
                    successMessage="Equipment returned to service."
                    failureMessage="Could not approve — QA Manager role is required, and the approver cannot be the person who submitted the retest."
                    onHide={close}
                    onSuccess={done}
                />
            )}
        </>
    );
};

RepairsTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    onChanged: PropTypes.func,
};

export default RepairsTab;
