import { useCallback, useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { AppDataTable, mutedDash, statusCell, dateCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import {
    CALIBRATION_ENDPOINTS,
    OOT_DISPOSITION_OPTIONS,
    OOT_DISPOSITION_SEVERITY,
    useCalibrationUser,
} from '../../../utils/calibrationConstants';
import ActionDialog from '../components/ActionDialog';
import QualityHoldsDialog from '../components/QualityHoldsDialog';

const dispositionBody = statusCell('disposition', OOT_DISPOSITION_SEVERITY);
const ootDateBody = dateCell('ootDate');
const lastValidBody = dateCell('lastValidDate');

const INITIATE_FIELDS = [
    { name: 'calibrationRecordId', label: 'Failed Calibration Record', type: 'dropdown', required: true, width: 12, urlOnly: true },
    { name: 'affectedReferences', label: 'Affected References (press Enter)', type: 'chips', placeholder: 'e.g. batch / work order ids' },
    { name: 'riskAssessment', label: 'Risk Assessment', type: 'textarea' },
    { name: 'containmentAction', label: 'Containment Action', type: 'textarea' },
];

const DISPOSITION_FIELDS = [
    { name: 'disposition', label: 'Disposition', type: 'dropdown', required: true, options: OOT_DISPOSITION_OPTIONS },
    { name: 'approvedBy', label: 'Approved By', required: true },
];

/**
 * QM-CAL-010 / QM-CAL-011 — out-of-tolerance assessments for one equipment and
 * the quality holds raised against them. Holds cannot be resolved until the
 * assessment has an approved disposition.
 */
const OotTab = ({ equipmentId, headers, records, onChanged }) => {
    const user = useCalibrationUser();
    const [dialog, setDialog] = useState(null); // { type, row? }

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.OOT_BY_EQUIPMENT(equipmentId),
        headers,
    });

    const failedRecordOptions = useMemo(
        () =>
            (records || [])
                .filter((r) => r.resultStatus && r.resultStatus !== 'PASS')
                .map((r) => ({ label: `#${r.id} · ${r.calibrationDate} · ${r.resultStatus}`, value: r.id })),
        [records],
    );

    const close = useCallback(() => setDialog(null), []);
    const done = useCallback(() => {
        setDialog(null);
        refetch();
        onChanged?.();
    }, [refetch, onChanged]);

    const refsBody = (row) => (row.affectedReferences?.length ? row.affectedReferences.join(', ') : mutedDash());

    const actionsBody = (row) => (
        <div className="flex gap-1">
            {row.disposition === 'PENDING' && (
                <Button label="Disposition" size="small" text onClick={() => setDialog({ type: 'disposition', row })} />
            )}
            <Button label="Holds" size="small" text onClick={() => setDialog({ type: 'holds', row })} />
        </div>
    );

    return (
        <>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">
                    A failed critical-equipment calibration opens an assessment automatically; start one manually here if needed.
                </span>
                <Button
                    label="Initiate Assessment"
                    icon="pi pi-exclamation-triangle"
                    size="small"
                    onClick={() => setDialog({ type: 'initiate' })}
                    disabled={failedRecordOptions.length === 0}
                    tooltip={failedRecordOptions.length === 0 ? 'No failed calibration record on this equipment' : undefined}
                />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column field="id" header="#" style={{ width: '4rem' }} />
                <Column field="calibrationRecordId" header="Record" />
                <Column header="OOT Date" body={ootDateBody} />
                <Column header="Last Valid" body={lastValidBody} />
                <Column header="Affected References" body={refsBody} />
                <Column header="Disposition" body={dispositionBody} />
                <Column header="Approved By" body={(r) => r.approvedBy || mutedDash()} />
                <Column header="" body={actionsBody} />
            </AppDataTable>

            {dialog?.type === 'initiate' && (
                <ActionDialog
                    header="Initiate OOT Assessment"
                    fields={INITIATE_FIELDS.map((f) => (f.name === 'calibrationRecordId' ? { ...f, options: failedRecordOptions } : f))}
                    defaultValues={{ calibrationRecordId: failedRecordOptions[0]?.value ?? null }}
                    endpointFor={(v) => CALIBRATION_ENDPOINTS.OOT_INITIATE(v.calibrationRecordId)}
                    headers={headers}
                    submitLabel="Initiate"
                    successMessage="Assessment initiated."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'disposition' && (
                <ActionDialog
                    header="Record Disposition"
                    fields={DISPOSITION_FIELDS}
                    defaultValues={{ approvedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.OOT_DISPOSITION(dialog.row.id)}
                    headers={headers}
                    submitLabel="Save"
                    successMessage="Disposition recorded."
                    failureMessage="Could not record disposition — QA Manager role is required, and the approver cannot be the person who submitted the failed calibration."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'holds' && (
                <QualityHoldsDialog assessment={dialog.row} headers={headers} onHide={close} />
            )}
        </>
    );
};

OotTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    records: PropTypes.array,
    onChanged: PropTypes.func,
};

export default OotTab;
