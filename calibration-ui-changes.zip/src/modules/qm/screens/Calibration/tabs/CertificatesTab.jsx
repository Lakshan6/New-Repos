import { useCallback, useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';

import { Card, ReadOnlyField, mutedDash } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import {
    CALIBRATION_ENDPOINTS,
    CERTIFICATE_STATUS_SEVERITY,
    useCalibrationUser,
} from '../../../utils/calibrationConstants';
import ActionDialog from '../components/ActionDialog';
import { useCalibrationAction } from '../components/useCalibrationAction';

const ATTACH_FIELDS = [
    { name: 'calibrationRecordId', label: 'Calibration Record', type: 'dropdown', required: true, urlOnly: true, width: 12 },
    { name: 'certificateNumber', label: 'Certificate Number', required: true },
    { name: 'provider', label: 'Provider / Lab', required: true },
    { name: 'issueDate', label: 'Issue Date', type: 'date', required: true },
    { name: 'expiryDate', label: 'Expiry Date', type: 'date' },
    { name: 'calibrationDate', label: 'Calibration Date', type: 'date', required: true },
    { name: 'equipmentSerialNumber', label: 'Equipment Serial Number (as on certificate)', required: true },
    { name: 'scope', label: 'Scope', width: 12 },
    { name: 'attachmentReference', label: 'Attachment Reference (file id / link)', width: 12 },
];

const APPROVE_FIELDS = [{ name: 'approvedBy', label: 'Approved By', required: true, width: 12 }];

/**
 * QM-CAL-012 — current calibration certificate for the equipment, attach a
 * certificate to a calibration record, then verify (technical check) and
 * approve (QA Manager / Document Controller). The backend checks that the
 * serial number and calibration date on the certificate match the equipment
 * and the record.
 */
const CertificatesTab = ({ equipmentId, serialNumber, headers, records, onChanged }) => {
    const user = useCalibrationUser();
    const [dialog, setDialog] = useState(null); // 'attach' | 'approve'
    const { run, busyKey } = useCalibrationAction(headers);

    const {
        data: cert,
        isError: noCert,
        refetch,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CERTIFICATE_CURRENT(equipmentId),
        headers,
        options: { retry: false },
    });

    const recordOptions = useMemo(
        () => (records || []).map((r) => ({ label: `#${r.id} · ${r.calibrationDate} · ${r.resultStatus}`, value: r.id })),
        [records],
    );

    const close = useCallback(() => setDialog(null), []);
    const done = useCallback(() => {
        setDialog(null);
        refetch();
        onChanged?.();
    }, [refetch, onChanged]);

    const verify = () =>
        run({
            key: 'verify',
            endpoint: CALIBRATION_ENDPOINTS.CERTIFICATE_VERIFY(cert.id),
            body: { verifiedBy: user },
            success: 'Certificate verified.',
            failure: 'Could not verify certificate.',
            onDone: done,
        });

    const hasCert = cert && !noCert;

    return (
        <>
            <Card
                compact
                title="Current Certificate"
                header={
                    <div className="flex gap-2">
                        {hasCert && cert.approvalStatus === 'PENDING' && (
                            <Button label="Verify" size="small" text loading={busyKey === 'verify'} onClick={verify} />
                        )}
                        {hasCert && cert.approvalStatus === 'VERIFIED' && (
                            <Button label="Approve" size="small" text onClick={() => setDialog('approve')} />
                        )}
                        <Button
                            label="Attach Certificate"
                            icon="pi pi-paperclip"
                            size="small"
                            onClick={() => setDialog('attach')}
                            disabled={recordOptions.length === 0}
                            tooltip={recordOptions.length === 0 ? 'Submit a calibration record first' : undefined}
                        />
                    </div>
                }
            >
                {!hasCert ? (
                    <p className="text-color-secondary m-0">No certificate attached yet.</p>
                ) : (
                    <div className="grid">
                        <div className="col-3"><ReadOnlyField label="Certificate No." value={cert.certificateNumber} /></div>
                        <div className="col-3"><ReadOnlyField label="Provider" value={cert.provider} /></div>
                        <div className="col-3"><ReadOnlyField label="Issued" value={cert.issueDate} /></div>
                        <div className="col-3"><ReadOnlyField label="Expires" value={cert.expiryDate || '—'} /></div>
                        <div className="col-6"><ReadOnlyField label="Scope" value={cert.scope || '—'} /></div>
                        <div className="col-6"><ReadOnlyField label="Attachment" value={cert.attachmentReference || '—'} /></div>
                        <div className="col-3">
                            <span className="block text-sm mb-2">Status</span>
                            <Tag value={cert.approvalStatus} severity={CERTIFICATE_STATUS_SEVERITY[cert.approvalStatus] ?? 'info'} />
                        </div>
                        <div className="col-3"><ReadOnlyField label="Verified By" value={cert.verifiedBy || '—'} /></div>
                        <div className="col-3"><ReadOnlyField label="Approved By" value={cert.approvedBy || '—'} /></div>
                        <div className="col-3">{cert.calibrationRecordId ? <ReadOnlyField label="Record" value={`#${cert.calibrationRecordId}`} /> : mutedDash()}</div>
                    </div>
                )}
            </Card>

            {dialog === 'attach' && (
                <ActionDialog
                    header="Attach Certificate"
                    size="lg"
                    fields={ATTACH_FIELDS.map((f) => (f.name === 'calibrationRecordId' ? { ...f, options: recordOptions } : f))}
                    defaultValues={{
                        calibrationRecordId: recordOptions[0]?.value ?? null,
                        equipmentSerialNumber: serialNumber || '',
                        provider: '',
                    }}
                    endpointFor={(v) => CALIBRATION_ENDPOINTS.CERTIFICATE_ATTACH(v.calibrationRecordId)}
                    headers={headers}
                    submitLabel="Attach"
                    successMessage="Certificate attached — verification and approval are pending."
                    failureMessage="Could not attach certificate — check the serial number and calibration date match."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog === 'approve' && hasCert && (
                <ActionDialog
                    header="Approve Certificate"
                    size="sm"
                    fields={APPROVE_FIELDS}
                    defaultValues={{ approvedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.CERTIFICATE_APPROVE(cert.id)}
                    headers={headers}
                    submitLabel="Approve"
                    successMessage="Certificate approved."
                    failureMessage="Could not approve — QA Manager or Document Controller role is required, and the approver must be someone other than the verifier."
                    onHide={close}
                    onSuccess={done}
                />
            )}
        </>
    );
};

CertificatesTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    serialNumber: PropTypes.string,
    headers: PropTypes.object.isRequired,
    records: PropTypes.array,
    onChanged: PropTypes.func,
};

export default CertificatesTab;
