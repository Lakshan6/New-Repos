import { useCallback } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';

import { AppDataTable, mutedDash, statusCell, dateCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import {
    CALIBRATION_ENDPOINTS,
    EQUIPMENT_STATUS_SEVERITY,
    useCalibrationUser,
} from '../../../utils/calibrationConstants';
import { useCalibrationAction } from '../components/useCalibrationAction';

const statusBody = statusCell('statusSnapshot', EQUIPMENT_STATUS_SEVERITY);
const lastCalBody = dateCell('lastCalibrationDateSnapshot');
const nextDueBody = dateCell('nextDueDateSnapshot');

/**
 * QM-CAL-015 — calibration status labels. A label is a snapshot of status,
 * last calibration date, next due date and certificate reference. The backend
 * re-validates the equipment state when a label is issued, so a label for
 * equipment that has since gone out of calibration is refused.
 */
const LabelsTab = ({ equipmentId, headers }) => {
    const user = useCalibrationUser();
    const { run, busyKey } = useCalibrationAction(headers);

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.LABELS(equipmentId),
        headers,
    });

    const generate = useCallback(
        () =>
            run({
                key: 'generate',
                endpoint: CALIBRATION_ENDPOINTS.LABELS(equipmentId),
                body: { generatedBy: user },
                success: 'Label generated.',
                failure: 'Could not generate label.',
                onDone: refetch,
            }),
        [run, equipmentId, user, refetch],
    );

    const issuedBody = (row) =>
        row.issued ? (
            <Tag value="Issued" severity="success" />
        ) : (
            <Tag value="Not issued" severity="warning" />
        );

    const actionsBody = (row) =>
        row.issued ? null : (
            <Button
                label="Issue"
                size="small"
                text
                loading={busyKey === row.id}
                onClick={() =>
                    run({
                        key: row.id,
                        endpoint: CALIBRATION_ENDPOINTS.LABEL_ISSUE(row.id),
                        body: { issuedBy: user },
                        success: 'Label issued.',
                        failure: 'Could not issue label — the equipment state may have changed.',
                        onDone: refetch,
                    })
                }
            />
        );

    return (
        <>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">Status labels to attach to the physical equipment.</span>
                <Button label="Generate Label" icon="pi pi-tag" size="small" loading={busyKey === 'generate'} onClick={generate} />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column field="id" header="#" style={{ width: '4rem' }} />
                <Column header="Status" body={statusBody} />
                <Column header="Last Calibrated" body={lastCalBody} />
                <Column header="Next Due" body={nextDueBody} />
                <Column header="Certificate" body={(r) => r.certificateReferenceSnapshot || mutedDash()} />
                <Column header="Generated" body={(r) => (r.generatedAt ? `${r.generatedBy} · ${new Date(r.generatedAt).toLocaleString()}` : mutedDash())} />
                <Column header="Issued" body={issuedBody} />
                <Column header="" body={actionsBody} />
            </AppDataTable>
        </>
    );
};

LabelsTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
};

export default LabelsTab;
