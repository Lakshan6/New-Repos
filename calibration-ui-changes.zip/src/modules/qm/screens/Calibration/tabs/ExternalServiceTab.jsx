import { useCallback, useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { AppDataTable, mutedDash, statusCell, dateCell, currencyCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import {
    CALIBRATION_ENDPOINTS,
    EXTERNAL_STATUS_SEVERITY,
    useCalibrationUser,
} from '../../../utils/calibrationConstants';
import ActionDialog from '../components/ActionDialog';
import { useCalibrationAction } from '../components/useCalibrationAction';

const statusBody = statusCell('status', EXTERNAL_STATUS_SEVERITY);
const dispatchBody = dateCell('dispatchDate');
const returnBody = dateCell('actualReturnDate');
const costBody = currencyCell('actualCost');

const DISPATCH_FIELDS = [
    { name: 'dispatchDate', label: 'Dispatch Date', type: 'date', required: true },
    { name: 'expectedReturnDate', label: 'Expected Return Date', type: 'date' },
];

const CERTIFICATE_FIELDS = [
    { name: 'certificateNumber', label: 'Certificate Number', required: true },
    { name: 'certificateIssueDate', label: 'Certificate Issue Date', type: 'date', required: true },
    { name: 'certificateExpiryDate', label: 'Certificate Expiry Date', type: 'date' },
    { name: 'actualReturnDate', label: 'Actual Return Date', type: 'date', required: true },
    { name: 'actualCost', label: 'Actual Cost', type: 'decimal' },
    { name: 'certificateAttachmentReference', label: 'Attachment Reference (file id / link)', required: true, width: 12 },
];

/**
 * QM-CAL-014 — equipment sent to an approved external calibration provider:
 * request → dispatch → receive certificate → verify → reactivate (QA Manager).
 * Only providers registered on the Approved Providers screen can be used.
 */
const ExternalServiceTab = ({ equipmentId, headers, onChanged }) => {
    const user = useCalibrationUser();
    const [dialog, setDialog] = useState(null); // { type, row? }
    const { run, busyKey } = useCalibrationAction(headers);

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EXTERNAL_REQUESTS(equipmentId),
        headers,
    });

    const { data: providers } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.APPROVED_PROVIDERS,
        headers,
    });

    const providerOptions = useMemo(
        () =>
            (Array.isArray(providers) ? providers : [])
                .filter((p) => p.active)
                .map((p) => ({ label: p.name, value: p.name })),
        [providers],
    );

    const createFields = useMemo(
        () => [
            { name: 'provider', label: 'Approved Provider', type: 'dropdown', required: true, options: providerOptions, width: 12 },
            { name: 'quotedCost', label: 'Quoted Cost', type: 'decimal' },
        ],
        [providerOptions],
    );

    const close = useCallback(() => setDialog(null), []);
    const done = useCallback(() => {
        setDialog(null);
        refetch();
        onChanged?.();
    }, [refetch, onChanged]);

    const act = (row, endpoint, body, success, failure, confirm) =>
        run({ key: `${row.id}-${endpoint}`, endpoint, body, success, failure, confirm, onDone: done });

    const actionsBody = (row) => {
        const busy = (ep) => busyKey === `${row.id}-${ep}`;
        const buttons = [];
        if (row.status === 'REQUESTED') {
            buttons.push(<Button key="d" label="Dispatch" size="small" text onClick={() => setDialog({ type: 'dispatch', row })} />);
        }
        if (row.status === 'DISPATCHED') {
            buttons.push(<Button key="c" label="Receive Certificate" size="small" text onClick={() => setDialog({ type: 'certificate', row })} />);
        }
        if (row.status === 'CERTIFICATE_RECEIVED') {
            const ep = CALIBRATION_ENDPOINTS.EXTERNAL_VERIFY(row.id);
            buttons.push(
                <Button
                    key="v"
                    label="Verify"
                    size="small"
                    text
                    loading={busy(ep)}
                    onClick={() => act(row, ep, { verifiedBy: user }, 'Certificate verified.', 'Could not verify certificate.')}
                />,
            );
        }
        if (row.status === 'VERIFIED') {
            const ep = CALIBRATION_ENDPOINTS.EXTERNAL_REACTIVATE(row.id);
            buttons.push(
                <Button
                    key="r"
                    label="Reactivate"
                    size="small"
                    text
                    loading={busy(ep)}
                    onClick={() =>
                        act(row, ep, null, 'Equipment reactivated.', 'Could not reactivate — QA Manager role is required.', 'Reactivate this equipment after external calibration?')
                    }
                />,
            );
        }
        if (row.status === 'REQUESTED' || row.status === 'DISPATCHED') {
            const ep = CALIBRATION_ENDPOINTS.EXTERNAL_CANCEL(row.id);
            buttons.push(
                <Button
                    key="x"
                    label="Cancel"
                    size="small"
                    text
                    severity="danger"
                    loading={busy(ep)}
                    onClick={() => act(row, ep, null, 'Request cancelled.', 'Could not cancel request.', 'Cancel this external service request?')}
                />,
            );
        }
        return <div className="flex gap-1">{buttons}</div>;
    };

    return (
        <>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">Calibration performed by an approved external provider.</span>
                <Button
                    label="New Request"
                    icon="pi pi-send"
                    size="small"
                    onClick={() => setDialog({ type: 'create' })}
                    disabled={providerOptions.length === 0}
                    tooltip={providerOptions.length === 0 ? 'Register an approved provider first' : undefined}
                />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column field="provider" header="Provider" />
                <Column header="Status" body={statusBody} />
                <Column header="Dispatched" body={dispatchBody} />
                <Column header="Returned" body={returnBody} />
                <Column header="Certificate" body={(r) => r.certificateNumber || mutedDash()} />
                <Column header="Cost" body={costBody} />
                <Column header="Verified By" body={(r) => r.verifiedBy || mutedDash()} />
                <Column header="" body={actionsBody} />
            </AppDataTable>

            {dialog?.type === 'create' && (
                <ActionDialog
                    header="New External Service Request"
                    size="sm"
                    fields={createFields}
                    endpoint={CALIBRATION_ENDPOINTS.EXTERNAL_REQUESTS(equipmentId)}
                    headers={headers}
                    submitLabel="Create"
                    successMessage="External service request created."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'dispatch' && (
                <ActionDialog
                    header="Dispatch Equipment"
                    size="sm"
                    fields={DISPATCH_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.EXTERNAL_DISPATCH(dialog.row.id)}
                    headers={headers}
                    submitLabel="Dispatch"
                    successMessage="Equipment dispatched."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'certificate' && (
                <ActionDialog
                    header="Receive Certificate"
                    size="lg"
                    fields={CERTIFICATE_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.EXTERNAL_CERTIFICATE(dialog.row.id)}
                    headers={headers}
                    submitLabel="Save"
                    successMessage="Certificate recorded — verification is pending."
                    onHide={close}
                    onSuccess={done}
                />
            )}
        </>
    );
};

ExternalServiceTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    onChanged: PropTypes.func,
};

export default ExternalServiceTab;
