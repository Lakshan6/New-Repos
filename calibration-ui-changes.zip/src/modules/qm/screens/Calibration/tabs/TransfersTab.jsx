import { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { AppDataTable, mutedDash, dateCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import { CALIBRATION_ENDPOINTS, useCalibrationUser } from '../../../utils/calibrationConstants';
import ActionDialog from '../components/ActionDialog';

const dateBody = dateCell('transferDate');

const TRANSFER_FIELDS = [
    { name: 'toLocation', label: 'To Location', required: true },
    { name: 'toCustodian', label: 'To Custodian', required: true },
    { name: 'reason', label: 'Reason', type: 'textarea' },
    { name: 'override', label: 'Override', type: 'checkbox', checkboxLabel: 'Transfer even though calibration work is open', width: 12 },
    { name: 'authorizedBy', label: 'Authorized By (required for override)', width: 12 },
];

/**
 * QM-CAL-017 — location / custodian transfers. A transfer is refused while
 * calibration work is open unless it is explicitly overridden and authorised.
 */
const TransfersTab = ({ equipmentId, headers, onChanged }) => {
    const user = useCalibrationUser();
    const [showDialog, setShowDialog] = useState(false);

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.TRANSFERS(equipmentId),
        headers,
    });

    const close = useCallback(() => setShowDialog(false), []);
    const done = useCallback(() => {
        setShowDialog(false);
        refetch();
        onChanged?.();
    }, [refetch, onChanged]);

    return (
        <>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">Custody and location history.</span>
                <Button label="Transfer" icon="pi pi-arrow-right-arrow-left" size="small" onClick={() => setShowDialog(true)} />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column header="Date" body={dateBody} />
                <Column header="From" body={(r) => r.fromLocation || mutedDash()} />
                <Column field="toLocation" header="To" />
                <Column header="From Custodian" body={(r) => r.fromCustodian || mutedDash()} />
                <Column field="toCustodian" header="To Custodian" />
                <Column header="Reason" body={(r) => r.reason || mutedDash()} />
                <Column header="Authorized By" body={(r) => r.authorizedBy || mutedDash()} />
            </AppDataTable>

            {showDialog && (
                <ActionDialog
                    header="Transfer Equipment"
                    fields={TRANSFER_FIELDS}
                    defaultValues={{ authorizedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.TRANSFERS(equipmentId)}
                    headers={headers}
                    submitLabel="Transfer"
                    successMessage="Equipment transferred."
                    failureMessage="Could not transfer — calibration work may be open (use override with an authoriser)."
                    onHide={close}
                    onSuccess={done}
                />
            )}
        </>
    );
};

TransfersTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    onChanged: PropTypes.func,
};

export default TransfersTab;
