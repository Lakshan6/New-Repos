import { useMemo, useState } from 'react';
import PropTypes from 'prop-types';
import { Dropdown } from 'primereact/dropdown';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';

import { AppDataTable, mutedDash } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import { CALIBRATION_ENDPOINTS } from '../../../utils/calibrationConstants';

const CHANGE_SEVERITY = { ADD: 'success', MOD: 'info', DEL: 'danger', CREATED: 'success', UPDATED: 'info', DELETED: 'danger' };

/**
 * QM-CAL-020 — field-level change history (Hibernate Envers). Pick what to
 * inspect — the equipment itself, its calibration plan, or one calibration
 * record — and see who changed what and when. "View" shows the full snapshot
 * of that revision (scalar fields only).
 */
const AuditTab = ({ equipmentId, headers, plan, records }) => {
    const [target, setTarget] = useState('equipment');
    const [snapshot, setSnapshot] = useState(null);

    const options = useMemo(() => {
        const list = [{ label: 'Equipment', value: 'equipment' }];
        if (plan?.id) list.push({ label: 'Calibration plan', value: 'plan' });
        (records || []).forEach((r) => list.push({ label: `Calibration record #${r.id}`, value: `record:${r.id}` }));
        return list;
    }, [plan, records]);

    const endpoint = useMemo(() => {
        if (target === 'plan') return CALIBRATION_ENDPOINTS.AUDIT_PLAN(plan.id);
        if (target.startsWith('record:')) return CALIBRATION_ENDPOINTS.AUDIT_RECORD(target.split(':')[1]);
        return CALIBRATION_ENDPOINTS.AUDIT_EQUIPMENT(equipmentId);
    }, [target, plan, equipmentId]);

    const { data, isLoading } = useReadApi({ service: 'calibration', endpoint, headers });

    const changeBody = (row) => <Tag value={row.changeType} severity={CHANGE_SEVERITY[row.changeType] ?? 'info'} />;
    const whenBody = (row) => (row.timestamp ? new Date(row.timestamp).toLocaleString() : mutedDash());
    const viewBody = (row) => <Button label="View" size="small" text onClick={() => setSnapshot(row)} />;

    return (
        <>
            <div className="flex align-items-center gap-2 mb-3">
                <span className="text-sm">Show history of</span>
                <Dropdown value={target} options={options} onChange={(e) => setTarget(e.value)} className="w-16rem" />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="revision" paginator={false}>
                <Column field="revision" header="Revision" style={{ width: '6rem' }} />
                <Column header="When" body={whenBody} />
                <Column header="User" body={(r) => r.username || mutedDash()} />
                <Column header="Change" body={changeBody} />
                <Column header="" body={viewBody} />
            </AppDataTable>

            {snapshot && (
                <Dialog header={`Revision ${snapshot.revision}`} visible onHide={() => setSnapshot(null)} style={{ width: '36rem', maxWidth: '95vw' }}>
                    <pre className="m-0 text-sm overflow-auto" style={{ maxHeight: '60vh' }}>
                        {JSON.stringify(snapshot.snapshot, null, 2)}
                    </pre>
                </Dialog>
            )}
        </>
    );
};

AuditTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    plan: PropTypes.object,
    records: PropTypes.array,
};

export default AuditTab;
