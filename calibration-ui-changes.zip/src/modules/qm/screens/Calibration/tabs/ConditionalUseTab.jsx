import { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { AppDataTable, mutedDash, statusCell, dateCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import {
    CALIBRATION_ENDPOINTS,
    CONDITIONAL_USE_STATUS_SEVERITY,
    useCalibrationUser,
} from '../../../utils/calibrationConstants';
import ActionDialog from '../components/ActionDialog';
import { useCalibrationAction } from '../components/useCalibrationAction';

const statusBody = statusCell('status', CONDITIONAL_USE_STATUS_SEVERITY);
const startBody = dateCell('startDate');
const endBody = dateCell('endDate');

const REQUEST_FIELDS = [
    { name: 'justification', label: 'Justification', type: 'textarea', required: true },
    { name: 'riskAssessment', label: 'Risk Assessment', type: 'textarea', required: true },
    { name: 'extensionDays', label: 'Extension (days)', type: 'number', required: true, min: 1 },
    { name: 'requestedBy', label: 'Requested By', required: true },
];

const APPROVE_FIELDS = [{ name: 'approvedBy', label: 'Approved By', required: true, width: 12 }];

const REJECT_FIELDS = [
    { name: 'rejectedBy', label: 'Rejected By', required: true, width: 12 },
    { name: 'reason', label: 'Reason', type: 'textarea', required: true },
];

/**
 * QM-CAL-016 — time-limited conditional use of overdue equipment. The extension
 * is capped by configuration (30 days by default), critical equipment is
 * excluded unless the backend allows it, and approved authorisations expire
 * automatically on their end date.
 */
const ConditionalUseTab = ({ equipmentId, headers, onChanged }) => {
    const user = useCalibrationUser();
    const [dialog, setDialog] = useState(null); // { type, row? }
    const { run, busyKey } = useCalibrationAction(headers);

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CONDITIONAL_USE(equipmentId),
        headers,
    });

    const close = useCallback(() => setDialog(null), []);
    const done = useCallback(() => {
        setDialog(null);
        refetch();
        onChanged?.();
    }, [refetch, onChanged]);

    const actionsBody = (row) => {
        const buttons = [];
        if (row.status === 'REQUESTED') {
            buttons.push(<Button key="a" label="Approve" size="small" text onClick={() => setDialog({ type: 'approve', row })} />);
            buttons.push(<Button key="r" label="Reject" size="small" text severity="danger" onClick={() => setDialog({ type: 'reject', row })} />);
        }
        if (row.status === 'ACTIVE') {
            buttons.push(
                <Button
                    key="c"
                    label="Close"
                    size="small"
                    text
                    loading={busyKey === row.id}
                    onClick={() =>
                        run({
                            key: row.id,
                            endpoint: CALIBRATION_ENDPOINTS.CONDITIONAL_USE_CLOSE(row.id),
                            success: 'Conditional use closed.',
                            failure: 'Could not close authorization.',
                            confirm: 'Close this conditional-use authorization now?',
                            onDone: done,
                        })
                    }
                />,
            );
        }
        return <div className="flex gap-1">{buttons}</div>;
    };

    return (
        <>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">Controlled, time-limited use of overdue equipment.</span>
                <Button label="Request Conditional Use" icon="pi pi-clock" size="small" onClick={() => setDialog({ type: 'request' })} />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column field="id" header="#" style={{ width: '4rem' }} />
                <Column field="justification" header="Justification" />
                <Column field="extensionDays" header="Days" style={{ width: '5rem' }} />
                <Column header="Status" body={statusBody} />
                <Column header="From" body={startBody} />
                <Column header="Until" body={endBody} />
                <Column field="requestedBy" header="Requested By" />
                <Column header="Approved By" body={(r) => r.approvedBy || mutedDash()} />
                <Column header="" body={actionsBody} />
            </AppDataTable>

            {dialog?.type === 'request' && (
                <ActionDialog
                    header="Request Conditional Use"
                    size="lg"
                    fields={REQUEST_FIELDS}
                    defaultValues={{ requestedBy: user, extensionDays: 7 }}
                    endpoint={CALIBRATION_ENDPOINTS.CONDITIONAL_USE(equipmentId)}
                    headers={headers}
                    submitLabel="Submit"
                    successMessage="Request submitted for QA approval."
                    failureMessage="Could not request conditional use — check the extension limit and equipment criticality."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'approve' && (
                <ActionDialog
                    header="Approve Conditional Use"
                    size="sm"
                    fields={APPROVE_FIELDS}
                    defaultValues={{ approvedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.CONDITIONAL_USE_APPROVE(dialog.row.id)}
                    headers={headers}
                    submitLabel="Approve"
                    successMessage="Conditional use approved."
                    failureMessage="Could not approve — QA Manager role is required, and the approver cannot be the requester."
                    onHide={close}
                    onSuccess={done}
                />
            )}
            {dialog?.type === 'reject' && (
                <ActionDialog
                    header="Reject Conditional Use"
                    size="sm"
                    fields={REJECT_FIELDS}
                    defaultValues={{ rejectedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.CONDITIONAL_USE_REJECT(dialog.row.id)}
                    headers={headers}
                    submitLabel="Reject"
                    successMessage="Conditional use rejected."
                    onHide={close}
                    onSuccess={done}
                />
            )}
        </>
    );
};

ConditionalUseTab.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    onChanged: PropTypes.func,
};

export default ConditionalUseTab;
