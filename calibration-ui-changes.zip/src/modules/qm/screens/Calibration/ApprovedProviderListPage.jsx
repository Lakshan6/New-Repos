import { useState } from 'react';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';

import { ListPage, AppDataTable } from '@shared/components';
import { useT, useSafeContext, useReadApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { CALIBRATION_ENDPOINTS, useCalibrationHeaders } from '../../utils/calibrationConstants';
import ActionDialog from './components/ActionDialog';
import { useCalibrationAction } from './components/useCalibrationAction';

const activeBody = (row) => <Tag value={row.active ? 'Active' : 'Inactive'} severity={row.active ? 'success' : 'secondary'} />;

const ADD_FIELDS = [{ name: 'name', label: 'Provider Name', required: true, width: 12 }];

/**
 * QM-CAL-014 — approved external calibration providers. Only active providers
 * can be chosen when raising an external service request on an equipment.
 */
const ApprovedProviderListPage = () => {
    const { t } = useT();
    const { authToken } = useSafeContext(AuthContext);
    const headers = useCalibrationHeaders(authToken);
    const { run, busyKey } = useCalibrationAction(headers);
    const [showAdd, setShowAdd] = useState(false);

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.APPROVED_PROVIDERS,
        headers,
    });

    const actionsBody = (row) =>
        row.active ? (
            <Button
                label="Deactivate"
                size="small"
                text
                severity="danger"
                loading={busyKey === row.name}
                onClick={() =>
                    run({
                        key: row.name,
                        endpoint: CALIBRATION_ENDPOINTS.APPROVED_PROVIDER_DEACTIVATE(row.name),
                        success: 'Provider deactivated.',
                        failure: 'Could not deactivate provider.',
                        confirm: `Deactivate ${row.name}? It will no longer be selectable for new external service requests.`,
                        onDone: refetch,
                    })
                }
            />
        ) : null;

    return (
        <ListPage
            title={t('APPROVED_PROVIDERS', { fallbackText: 'Approved Providers' })}
            subtitle="External laboratories approved to calibrate equipment."
            actions={<Button label="Add Provider" icon="pi pi-plus" onClick={() => setShowAdd(true)} />}
        >
            <AppDataTable value={Array.isArray(data) ? data : []} loading={isLoading} dataKey="id">
                <Column field="name" header="Provider" sortable />
                <Column header="Status" body={activeBody} />
                <Column header="" body={actionsBody} style={{ width: '9rem' }} />
            </AppDataTable>

            {showAdd && (
                <ActionDialog
                    header="Add Approved Provider"
                    size="sm"
                    fields={ADD_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.APPROVED_PROVIDERS}
                    headers={headers}
                    submitLabel="Add"
                    successMessage="Provider added."
                    failureMessage="Could not add provider — it may already exist."
                    onHide={() => setShowAdd(false)}
                    onSuccess={() => {
                        setShowAdd(false);
                        refetch();
                    }}
                />
            )}
        </ListPage>
    );
};

export default ApprovedProviderListPage;
