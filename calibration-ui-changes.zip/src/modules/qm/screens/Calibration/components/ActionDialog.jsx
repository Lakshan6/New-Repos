import { useMemo } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';

import {
    FormDialog,
    FormGroup,
    ControlledInputText,
    ControlledInputTextarea,
    ControlledInputNumber,
    ControlledCalendar,
    ControlledDropdown,
    ControlledCheckbox,
    ControlledChips,
    useAppToast,
} from '@shared/components';
import { useMutation } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { toLocalDateString } from '@shared/utils/dateUtils';

/**
 * A small config-driven form dialog used by every calibration action that
 * needs input (open repair, record disposition, place hold, dispatch, ...).
 *
 * fields: [{ name, label, type, required, options, width, placeholder }]
 *   type: 'text' (default) | 'textarea' | 'number' | 'decimal' | 'date' |
 *         'dropdown' | 'checkbox' | 'chips'
 *   width: PrimeFlex column width out of 12 (default 6; textarea/chips 12)
 *
 * The dialog POSTs (or `method`) the form values to `endpoint`; date fields are
 * sent as yyyy-MM-dd via toLocalDateString, empty optional values as null.
 * Pass `endpoint` for a fixed URL, or `endpointFor(values)` when the URL depends
 * on a form value (e.g. the chosen calibration record id). A field marked
 * `urlOnly` is used for the URL and left out of the request body.
 */
const ActionDialog = ({
    header,
    size = 'md',
    fields,
    defaultValues = {},
    endpoint,
    endpointFor,
    method = 'POST',
    headers,
    submitLabel = 'Save',
    successMessage = 'Saved.',
    failureMessage = 'Could not complete the action.',
    transform,
    onHide,
    onSuccess,
}) => {
    const toast = useAppToast();

    const initial = useMemo(() => {
        const base = {};
        fields.forEach((f) => {
            if (f.type === 'checkbox') base[f.name] = false;
            else if (f.type === 'chips') base[f.name] = [];
            else if (f.type === 'number' || f.type === 'decimal' || f.type === 'date' || f.type === 'dropdown')
                base[f.name] = null;
            else base[f.name] = '';
        });
        return { ...base, ...defaultValues };
        // defaultValues are only read when the dialog mounts
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    const { control, handleSubmit } = useForm({ defaultValues: initial });

    const mutation = useMutation({
        mutationFn: ({ url, body }) => apiRequest({ service: 'calibration', endpoint: url, method, headers, body }),
        onSuccess: (data) => {
            toast.success('Success', successMessage);
            onSuccess?.(data);
        },
        onError: (err) => toast.apiError(err, failureMessage),
    });

    const submit = (values) => {
        const payload = {};
        fields.forEach((f) => {
            if (f.urlOnly) return;
            const v = values[f.name];
            if (f.type === 'date') payload[f.name] = v ? toLocalDateString(v) : null;
            else if (f.type === 'text' || f.type === 'textarea' || f.type === undefined)
                payload[f.name] = typeof v === 'string' && v.trim() === '' ? null : v;
            else payload[f.name] = v;
        });
        mutation.mutate({
            url: endpointFor ? endpointFor(values) : endpoint,
            body: transform ? transform(payload) : payload,
        });
    };

    const renderField = (f) => {
        const id = `cal-act-${f.name}`;
        const rules = f.required ? { required: `${f.label} is required` } : undefined;
        switch (f.type) {
            case 'textarea':
                return <ControlledInputTextarea name={f.name} control={control} inputId={id} rows={3} autoResize rules={rules} />;
            case 'number':
                return <ControlledInputNumber name={f.name} control={control} inputId={id} min={f.min ?? 0} rules={rules} />;
            case 'decimal':
                return (
                    <ControlledInputNumber
                        name={f.name}
                        control={control}
                        inputId={id}
                        mode="decimal"
                        minFractionDigits={0}
                        maxFractionDigits={4}
                        rules={rules}
                    />
                );
            case 'date':
                return <ControlledCalendar name={f.name} control={control} inputId={id} showIcon rules={rules} />;
            case 'dropdown':
                return (
                    <ControlledDropdown
                        name={f.name}
                        control={control}
                        inputId={id}
                        options={f.options || []}
                        placeholder={f.placeholder || 'Select'}
                        rules={rules}
                    />
                );
            case 'checkbox':
                return <ControlledCheckbox name={f.name} control={control} inputId={id} label={f.checkboxLabel} />;
            case 'chips':
                return <ControlledChips name={f.name} control={control} inputId={id} placeholder={f.placeholder} separator="," />;
            default:
                return <ControlledInputText name={f.name} control={control} inputId={id} rules={rules} />;
        }
    };

    return (
        <FormDialog
            header={header}
            size={size}
            onHide={onHide}
            onSubmit={handleSubmit(submit)}
            submitLabel={submitLabel}
            busy={mutation.isPending}
        >
            <div className="grid formgrid">
                {fields.map((f) => (
                    <div key={f.name} className={`col-${f.width ?? (f.type === 'textarea' || f.type === 'chips' ? 12 : 6)}`}>
                        <FormGroup htmlFor={`cal-act-${f.name}`} label={f.label} required={!!f.required}>
                            {renderField(f)}
                        </FormGroup>
                    </div>
                ))}
            </div>
        </FormDialog>
    );
};

ActionDialog.propTypes = {
    header: PropTypes.string.isRequired,
    size: PropTypes.string,
    fields: PropTypes.arrayOf(PropTypes.object).isRequired,
    defaultValues: PropTypes.object,
    endpoint: PropTypes.string,
    endpointFor: PropTypes.func,
    method: PropTypes.string,
    headers: PropTypes.object.isRequired,
    submitLabel: PropTypes.string,
    successMessage: PropTypes.string,
    failureMessage: PropTypes.string,
    transform: PropTypes.func,
    onHide: PropTypes.func.isRequired,
    onSuccess: PropTypes.func,
};

export default ActionDialog;
