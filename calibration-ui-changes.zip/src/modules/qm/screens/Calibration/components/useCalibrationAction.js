import { useCallback, useState } from 'react';
import { useAppToast, useAppConfirm } from '@shared/components';
import { apiRequest } from '@shared/utils';

/**
 * Runs one-click row actions (verify, cancel, issue, retire, ...) that hit a
 * per-row endpoint with no form. useMutationApi binds its endpoint when the
 * hook is created, so per-row calls go through apiRequest directly.
 *
 *   const { run, busyKey } = useCalibrationAction(headers);
 *   run({ key: row.id, endpoint, body, success: 'Done.', failure: 'Failed.', onDone: refetch });
 *   run({ ..., confirm: 'Cancel this request?' })   // asks first
 */
export function useCalibrationAction(headers) {
    const toast = useAppToast();
    const { confirm } = useAppConfirm();
    const [busyKey, setBusyKey] = useState(null);

    const execute = useCallback(
        async ({ key, endpoint, method = 'POST', body, success, failure, onDone }) => {
            setBusyKey(key);
            try {
                await apiRequest({ service: 'calibration', endpoint, method, headers, body });
                toast.success('Success', success || 'Done.');
                onDone?.();
            } catch (err) {
                toast.apiError(err, failure || 'Could not complete the action.');
            } finally {
                setBusyKey(null);
            }
        },
        [headers, toast],
    );

    const run = useCallback(
        (opts) => {
            if (opts.confirm) {
                confirm({ message: opts.confirm, accept: () => execute(opts) });
            } else {
                execute(opts);
            }
        },
        [confirm, execute],
    );

    return { run, busyKey };
}
