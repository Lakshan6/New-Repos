import { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { AppDataTable, mutedDash, statusCell } from '@shared/components';
import { useReadApi } from '@shared/hooks';
import {
    CALIBRATION_ENDPOINTS,
    QUALITY_HOLD_RESOLVE_OPTIONS,
    QUALITY_HOLD_STATUS_SEVERITY,
} from '../../../utils/calibrationConstants';
import ActionDialog from './ActionDialog';

const statusBody = statusCell('status', QUALITY_HOLD_STATUS_SEVERITY);

const PLACE_FIELDS = [
    { name: 'affectedBatchLot', label: 'Affected Batch / Lot', required: true },
    { name: 'quantity', label: 'Quantity', type: 'decimal' },
    { name: 'customerStatus', label: 'Customer Status (shipped / not shipped)', width: 12 },
    { name: 'holdReason', label: 'Hold Reason', type: 'textarea', required: true },
];

const RESOLVE_FIELDS = [
    { name: 'status', label: 'New Status', type: 'dropdown', required: true, options: QUALITY_HOLD_RESOLVE_OPTIONS, width: 12 },
];

/**
 * QM-CAL-011 — quality holds against one OOT assessment: place a hold on an
 * affected batch/lot, and resolve it (reinspected / released / recalled).
 * The backend refuses to resolve a hold until the assessment's disposition
 * has been approved.
 */
const QualityHoldsDialog = ({ assessment, headers, onHide }) => {
    const [sub, setSub] = useState(null); // { type: 'place' } | { type: 'resolve', row }

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.QUALITY_HOLDS(assessment.id),
        headers,
    });

    const closeSub = useCallback(() => setSub(null), []);
    const done = useCallback(() => {
        setSub(null);
        refetch();
    }, [refetch]);

    const actionsBody = (row) =>
        row.status === 'ON_HOLD' || row.status === 'REINSPECTED' ? (
            <Button label="Resolve" size="small" text onClick={() => setSub({ type: 'resolve', row })} />
        ) : null;

    return (
        <Dialog header={`Quality Holds — assessment #${assessment.id}`} visible onHide={onHide} style={{ width: '48rem', maxWidth: '95vw' }}>
            <div className="flex justify-content-between align-items-center mb-3">
                <span className="text-color-secondary text-sm">
                    Disposition: <strong>{assessment.disposition}</strong>
                </span>
                <Button label="Place Hold" icon="pi pi-lock" size="small" onClick={() => setSub({ type: 'place' })} />
            </div>

            <AppDataTable value={data || []} loading={isLoading} dataKey="id" paginator={false}>
                <Column field="affectedBatchLot" header="Batch / Lot" />
                <Column header="Qty" body={(r) => (r.quantity != null ? r.quantity : mutedDash())} />
                <Column header="Customer Status" body={(r) => r.customerStatus || mutedDash()} />
                <Column field="holdReason" header="Reason" />
                <Column header="Status" body={statusBody} />
                <Column header="" body={actionsBody} />
            </AppDataTable>

            {sub?.type === 'place' && (
                <ActionDialog
                    header="Place Quality Hold"
                    fields={PLACE_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.QUALITY_HOLDS(assessment.id)}
                    headers={headers}
                    submitLabel="Place Hold"
                    successMessage="Quality hold placed."
                    onHide={closeSub}
                    onSuccess={done}
                />
            )}
            {sub?.type === 'resolve' && (
                <ActionDialog
                    header="Resolve Quality Hold"
                    size="sm"
                    fields={RESOLVE_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.QUALITY_HOLD_RESOLVE(sub.row.id)}
                    headers={headers}
                    submitLabel="Resolve"
                    successMessage="Quality hold updated."
                    failureMessage="Could not resolve — the OOT disposition must be approved first, and QA / Warehouse Manager role is required."
                    onHide={closeSub}
                    onSuccess={done}
                />
            )}
        </Dialog>
    );
};

QualityHoldsDialog.propTypes = {
    assessment: PropTypes.object.isRequired,
    headers: PropTypes.object.isRequired,
    onHide: PropTypes.func.isRequired,
};

export default QualityHoldsDialog;
