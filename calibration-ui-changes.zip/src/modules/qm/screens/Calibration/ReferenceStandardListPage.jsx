import { useMemo, useState } from 'react';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';

import { ListPage, AppDataTable, FilterToolbar, emphasisCell, statusCell, dateCell, mutedDash } from '@shared/components';
import { useT, useSafeContext, useReadApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import {
    CALIBRATION_ENDPOINTS,
    REFERENCE_STANDARD_STATUS_SEVERITY,
    useCalibrationHeaders,
} from '../../utils/calibrationConstants';
import ActionDialog from './components/ActionDialog';
import { useCalibrationAction } from './components/useCalibrationAction';

const standardIdBody = emphasisCell('standardId');
const statusBody = statusCell('status', REFERENCE_STANDARD_STATUS_SEVERITY);
const issueBody = dateCell('issueDate');
const expiryBody = dateCell('expiryDate');

const REGISTER_FIELDS = [
    { name: 'standardId', label: 'Standard ID', required: true },
    { name: 'name', label: 'Name', required: true },
    { name: 'certificateNumber', label: 'Certificate Number', required: true },
    { name: 'standardAuthority', label: 'Standard Authority (e.g. NABL / NIST)' },
    { name: 'issueDate', label: 'Issue Date', type: 'date' },
    { name: 'expiryDate', label: 'Expiry Date', type: 'date', required: true },
    { name: 'uncertainty', label: 'Uncertainty', type: 'decimal' },
];

/**
 * QM-CAL-013 — traceable reference standards. A calibration record can only be
 * submitted against a reference standard that is ACTIVE and unexpired on the
 * calibration date.
 */
const ReferenceStandardListPage = () => {
    const { t } = useT();
    const { authToken } = useSafeContext(AuthContext);
    const headers = useCalibrationHeaders(authToken);
    const { run, busyKey } = useCalibrationAction(headers);

    const [keyword, setKeyword] = useState('');
    const [showRegister, setShowRegister] = useState(false);

    const { data, isLoading, refetch } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.REFERENCE_STANDARDS,
        headers,
    });

    const rows = useMemo(() => {
        const list = Array.isArray(data) ? data : [];
        if (!keyword.trim()) return list;
        const kw = keyword.trim().toLowerCase();
        return list.filter(
            (s) =>
                s.standardId?.toLowerCase().includes(kw) ||
                s.name?.toLowerCase().includes(kw) ||
                s.certificateNumber?.toLowerCase().includes(kw),
        );
    }, [data, keyword]);

    const actionsBody = (row) =>
        row.status === 'RETIRED' ? null : (
            <Button
                label="Retire"
                size="small"
                text
                severity="danger"
                loading={busyKey === row.standardId}
                onClick={() =>
                    run({
                        key: row.standardId,
                        endpoint: CALIBRATION_ENDPOINTS.REFERENCE_STANDARD_RETIRE(row.standardId),
                        success: 'Reference standard retired.',
                        failure: 'Could not retire reference standard.',
                        confirm: `Retire reference standard ${row.standardId}? It can no longer be used for new calibrations.`,
                        onDone: refetch,
                    })
                }
            />
        );

    return (
        <ListPage
            title={t('REFERENCE_STANDARDS', { fallbackText: 'Reference Standards' })}
            subtitle="Traceable standards used to calibrate equipment."
            actions={<Button label="Register Standard" icon="pi pi-plus" onClick={() => setShowRegister(true)} />}
            toolbar={<FilterToolbar keyword={keyword} onKeywordChange={setKeyword} onRefresh={refetch} />}
        >
            <AppDataTable value={rows} loading={isLoading} dataKey="standardId">
                <Column field="standardId" header="Standard ID" body={standardIdBody} sortable />
                <Column field="name" header="Name" sortable />
                <Column field="certificateNumber" header="Certificate" />
                <Column header="Authority" body={(r) => r.standardAuthority || mutedDash()} />
                <Column header="Issued" body={issueBody} />
                <Column header="Expires" body={expiryBody} sortable field="expiryDate" />
                <Column header="Uncertainty" body={(r) => (r.uncertainty != null ? r.uncertainty : mutedDash())} />
                <Column header="Status" body={statusBody} />
                <Column header="" body={actionsBody} style={{ width: '7rem' }} />
            </AppDataTable>

            {showRegister && (
                <ActionDialog
                    header="Register Reference Standard"
                    size="lg"
                    fields={REGISTER_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.REFERENCE_STANDARDS}
                    headers={headers}
                    submitLabel="Register"
                    successMessage="Reference standard registered."
                    failureMessage="Could not register reference standard — the Standard ID may already exist."
                    onHide={() => setShowRegister(false)}
                    onSuccess={() => {
                        setShowRegister(false);
                        refetch();
                    }}
                />
            )}
        </ListPage>
    );
};

export default ReferenceStandardListPage;
