import { useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';
import { TabView, TabPanel } from 'primereact/tabview';

import {
    PageLayout,
    Card,
    AppDataTable,
    MetricCard,
    mutedDash,
    statusCell,
    dateCell,
    emphasisCell,
} from '@shared/components';
import { useT, useSafeContext, useReadApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { toLocalDateString } from '@shared/utils/dateUtils';
import {
    CALIBRATION_ENDPOINTS,
    CERTIFICATE_STATUS_OPTIONS,
    CERTIFICATE_STATUS_SEVERITY,
    CRITICALITY_SEVERITY,
    EQUIPMENT_STATUS_SEVERITY,
    OOT_DISPOSITION_SEVERITY,
    useCalibrationHeaders,
    useCalibrationUser,
} from '../../utils/calibrationConstants';
import ActionDialog from './components/ActionDialog';
import { useCalibrationAction } from './components/useCalibrationAction';

const equipmentIdBody = emphasisCell('equipmentId');
const eqStatusBody = statusCell('status', EQUIPMENT_STATUS_SEVERITY);
const criticalityBody = statusCell('criticality', CRITICALITY_SEVERITY);
const dispositionBody = statusCell('disposition', OOT_DISPOSITION_SEVERITY);
const ootDateBody = dateCell('ootDate');
const certStatusBody = statusCell('approvalStatus', CERTIFICATE_STATUS_SEVERITY);
const issueBody = dateCell('issueDate');
const expiryBody = dateCell('expiryDate');

const APPROVE_FIELDS = [{ name: 'approvedBy', label: 'Approved By', required: true, width: 12 }];

/** dd range → query string, skipping empty bounds. */
const rangeQuery = (from, to, extra = '') => {
    const parts = [];
    if (from) parts.push(`from=${toLocalDateString(from)}`);
    if (to) parts.push(`to=${toLocalDateString(to)}`);
    if (extra) parts.push(extra);
    return parts.length ? `?${parts.join('&')}` : '';
};

/**
 * QM-CAL-019 — calibration dashboard and registers: KPI tiles for a period,
 * overdue equipment, out-of-tolerance events and the certificate register
 * (with verify / approve for pending certificates).
 */
const CalibrationReportsPage = () => {
    const { t } = useT();
    const navigate = useNavigate();
    const { authToken } = useSafeContext(AuthContext);
    const headers = useCalibrationHeaders(authToken);
    const user = useCalibrationUser();
    const { run, busyKey } = useCalibrationAction(headers);

    const [from, setFrom] = useState(null);
    const [to, setTo] = useState(null);
    const [certStatus, setCertStatus] = useState(null);
    const [approving, setApproving] = useState(null);

    const rangeSuffix = useMemo(() => rangeQuery(from, to), [from, to]);

    const { data: dash, refetch: refetchDash } = useReadApi({
        service: 'calibration',
        endpoint: `${CALIBRATION_ENDPOINTS.REPORT_DASHBOARD}${rangeSuffix}`,
        headers,
    });
    const { data: overdue, isLoading: overdueLoading } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.REPORT_OVERDUE,
        headers,
    });
    const { data: oot, isLoading: ootLoading } = useReadApi({
        service: 'calibration',
        endpoint: `${CALIBRATION_ENDPOINTS.REPORT_OOT}${rangeSuffix}`,
        headers,
    });
    const {
        data: certs,
        isLoading: certsLoading,
        refetch: refetchCerts,
    } = useReadApi({
        service: 'calibration',
        endpoint: `${CALIBRATION_ENDPOINTS.REPORT_CERTIFICATES}${certStatus ? `?status=${certStatus}` : ''}`,
        headers,
    });

    const refreshCerts = () => {
        setApproving(null);
        refetchCerts();
        refetchDash();
    };

    const certActions = (row) => {
        if (row.approvalStatus === 'PENDING') {
            return (
                <Button
                    label="Verify"
                    size="small"
                    text
                    loading={busyKey === row.id}
                    onClick={() =>
                        run({
                            key: row.id,
                            endpoint: CALIBRATION_ENDPOINTS.CERTIFICATE_VERIFY(row.id),
                            body: { verifiedBy: user },
                            success: 'Certificate verified.',
                            failure: 'Could not verify certificate.',
                            onDone: refreshCerts,
                        })
                    }
                />
            );
        }
        if (row.approvalStatus === 'VERIFIED') {
            return <Button label="Approve" size="small" text onClick={() => setApproving(row)} />;
        }
        return null;
    };

    const openEquipment = (e) => navigate(`/web/landing/qms/calibration/equipment/${e.data.equipmentId}`);

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('CALIBRATION_REPORTS', { fallbackText: 'Calibration Reports' })}
                subtitle="Status, out-of-tolerance events and certificate register."
            />
            <PageLayout.Content>
                <Card
                    title="Dashboard"
                    header={
                        <div className="flex align-items-center gap-2">
                            <Calendar value={from} onChange={(e) => setFrom(e.value)} placeholder="From" showIcon showButtonBar />
                            <Calendar value={to} onChange={(e) => setTo(e.value)} placeholder="To" showIcon showButtonBar />
                        </div>
                    }
                >
                    {dash ? (
                        <div className="grid">
                            <div className="col-12 md:col-3"><MetricCard value={dash.totalEquipment} label="Total equipment" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.dueCount} label="Due" severity="warning" status="Due" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.overdueCount} label="Overdue" severity="danger" status="Overdue" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.blockedCount} label="Blocked" severity="danger" status="Blocked" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.activeCount} label="Active" severity="success" status="Active" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.inCalibrationCount} label="In calibration" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.retiredCount} label="Retired" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.openQualityHolds} label="Open quality holds" severity="danger" status="Holds" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.completedInPeriod} label="Calibrations in period" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.failedInPeriod} label="Failed in period" severity="danger" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.ootEventsInPeriod} label="OOT events in period" severity="danger" /></div>
                            <div className="col-12 md:col-3"><MetricCard value={dash.certificatesExpiringSoon} label="Certificates expiring soon" severity="warning" /></div>
                        </div>
                    ) : (
                        <p className="text-color-secondary m-0">Loading…</p>
                    )}
                </Card>

                <Card>
                    <TabView>
                        <TabPanel header="Overdue Equipment">
                            <AppDataTable
                                value={overdue || []}
                                loading={overdueLoading}
                                dataKey="equipmentId"
                                onRowClick={openEquipment}
                                className="cursor-pointer"
                            >
                                <Column field="equipmentId" header="Equipment ID" body={equipmentIdBody} sortable />
                                <Column field="name" header="Name" sortable />
                                <Column field="type" header="Type" />
                                <Column header="Criticality" body={criticalityBody} />
                                <Column header="Status" body={eqStatusBody} />
                                <Column field="location" header="Location" />
                                <Column field="owner" header="Owner" />
                            </AppDataTable>
                        </TabPanel>

                        <TabPanel header="Out-of-Tolerance Events">
                            <AppDataTable value={oot || []} loading={ootLoading} dataKey="id">
                                <Column field="equipmentId" header="Equipment" body={equipmentIdBody} sortable />
                                <Column header="OOT Date" body={ootDateBody} />
                                <Column header="Disposition" body={dispositionBody} />
                                <Column header="Risk Assessment" body={(r) => r.riskAssessment || mutedDash()} />
                                <Column header="Approved By" body={(r) => r.approvedBy || mutedDash()} />
                            </AppDataTable>
                        </TabPanel>

                        <TabPanel header="Certificate Register">
                            <div className="mb-3">
                                <Dropdown
                                    value={certStatus}
                                    options={CERTIFICATE_STATUS_OPTIONS}
                                    onChange={(e) => setCertStatus(e.value)}
                                    placeholder="All statuses"
                                    showClear
                                    className="w-12rem"
                                />
                            </div>
                            <AppDataTable value={certs || []} loading={certsLoading} dataKey="id">
                                <Column field="equipmentId" header="Equipment" body={equipmentIdBody} sortable />
                                <Column field="certificateNumber" header="Certificate No." />
                                <Column field="provider" header="Provider" />
                                <Column header="Issued" body={issueBody} />
                                <Column header="Expires" body={expiryBody} field="expiryDate" sortable />
                                <Column header="Status" body={certStatusBody} />
                                <Column header="" body={certActions} style={{ width: '7rem' }} />
                            </AppDataTable>
                        </TabPanel>
                    </TabView>
                </Card>
            </PageLayout.Content>

            {approving && (
                <ActionDialog
                    header="Approve Certificate"
                    size="sm"
                    fields={APPROVE_FIELDS}
                    defaultValues={{ approvedBy: user }}
                    endpoint={CALIBRATION_ENDPOINTS.CERTIFICATE_APPROVE(approving.id)}
                    headers={headers}
                    submitLabel="Approve"
                    successMessage="Certificate approved."
                    failureMessage="Could not approve — QA Manager or Document Controller role is required, and the approver must be someone other than the verifier."
                    onHide={() => setApproving(null)}
                    onSuccess={refreshCerts}
                />
            )}
        </PageLayout>
    );
};

export default CalibrationReportsPage;
