/**
 * @file calibrationConstants.js
 * @description Endpoint paths, option lists and status→severity maps for the
 * Calibration Management screens (erp-qm-service, QM-CAL-001..008/CAL-004).
 * Centralised here so screens never hardcode path strings or status colours.
 */
import { getUserDetails, getUserRole } from '@shared/utils';

/* ─────────────────────────────────────────────────────────────────────────
   ENDPOINTS — must match erp-qm-service's controllers exactly.
───────────────────────────────────────────────────────────────────────── */
export const CALIBRATION_ENDPOINTS = {
    EQUIPMENT: '/api/v1/equipment',
    EQUIPMENT_BY_ID: (equipmentId) => `/api/v1/equipment/${equipmentId}`,
    EQUIPMENT_APPROVE: (equipmentId) => `/api/v1/equipment/${equipmentId}/approve`,
    EQUIPMENT_ACTIVATE: (equipmentId) => `/api/v1/equipment/${equipmentId}/activate`,

    CALIBRATION_PLAN: (equipmentId) => `/api/v1/equipment/${equipmentId}/calibration-plan`,
    CALIBRATION_PLAN_APPROVE: (equipmentId) =>
        `/api/v1/equipment/${equipmentId}/calibration-plan/approve`,

    CALIBRATION_RECORDS: (equipmentId) => `/api/v1/equipment/${equipmentId}/calibration-records`,

    SCHEDULE_GENERATE: '/api/v1/calibration-schedule/generate',
    SCHEDULE_LIST: '/api/v1/calibration-schedule',
    SCHEDULE_ASSIGN: (scheduleId) => `/api/v1/calibration-schedule/${scheduleId}/assign`,

    // CAL-017 retire
    EQUIPMENT_RETIRE: (equipmentId) => `/api/v1/equipment/${equipmentId}/retire`,

    // CAL-013 reference standards
    REFERENCE_STANDARDS: '/api/v1/reference-standards',
    REFERENCE_STANDARD_RETIRE: (standardId) => `/api/v1/reference-standards/${standardId}/retire`,

    // CAL-014 approved providers + external service
    APPROVED_PROVIDERS: '/api/v1/approved-providers',
    APPROVED_PROVIDER_DEACTIVATE: (name) => `/api/v1/approved-providers/${encodeURIComponent(name)}/deactivate`,
    EXTERNAL_REQUESTS: (equipmentId) => `/api/v1/equipment/${equipmentId}/external-service-requests`,
    EXTERNAL_DISPATCH: (id) => `/api/v1/external-service-requests/${id}/dispatch`,
    EXTERNAL_CERTIFICATE: (id) => `/api/v1/external-service-requests/${id}/certificate`,
    EXTERNAL_VERIFY: (id) => `/api/v1/external-service-requests/${id}/verify`,
    EXTERNAL_REACTIVATE: (id) => `/api/v1/external-service-requests/${id}/reactivate`,
    EXTERNAL_CANCEL: (id) => `/api/v1/external-service-requests/${id}/cancel`,

    // CAL-009 repairs
    REPAIRS: (equipmentId) => `/api/v1/equipment/${equipmentId}/repairs`,
    REPAIR_COMPLETE: (id) => `/api/v1/repairs/${id}/complete`,
    REPAIR_APPROVE_RETURN: (id) => `/api/v1/repairs/${id}/approve-return-to-service`,

    // CAL-010 / CAL-011 OOT + quality holds
    OOT_BY_EQUIPMENT: (equipmentId) => `/api/v1/equipment/${equipmentId}/oot-assessments`,
    OOT_INITIATE: (recordId) => `/api/v1/calibration-records/${recordId}/oot-assessments`,
    OOT_DISPOSITION: (id) => `/api/v1/oot-assessments/${id}/disposition`,
    QUALITY_HOLDS: (ootId) => `/api/v1/oot-assessments/${ootId}/quality-holds`,
    QUALITY_HOLD_RESOLVE: (id) => `/api/v1/quality-holds/${id}/resolve`,

    // CAL-012 certificates
    CERTIFICATE_CURRENT: (equipmentId) => `/api/v1/equipment/${equipmentId}/certificate/current`,
    CERTIFICATE_ATTACH: (recordId) => `/api/v1/calibration-records/${recordId}/certificate`,
    CERTIFICATE_VERIFY: (id) => `/api/v1/certificates/${id}/verify`,
    CERTIFICATE_APPROVE: (id) => `/api/v1/certificates/${id}/approve`,

    // CAL-015 labels
    LABELS: (equipmentId) => `/api/v1/equipment/${equipmentId}/labels`,
    LABEL_ISSUE: (id) => `/api/v1/labels/${id}/issue`,

    // CAL-016 conditional use
    CONDITIONAL_USE: (equipmentId) => `/api/v1/equipment/${equipmentId}/conditional-use`,
    CONDITIONAL_USE_APPROVE: (id) => `/api/v1/conditional-use/${id}/approve`,
    CONDITIONAL_USE_REJECT: (id) => `/api/v1/conditional-use/${id}/reject`,
    CONDITIONAL_USE_CLOSE: (id) => `/api/v1/conditional-use/${id}/close`,

    // CAL-017 transfers
    TRANSFERS: (equipmentId) => `/api/v1/equipment/${equipmentId}/transfers`,

    // CAL-019 reports
    REPORT_DASHBOARD: '/api/v1/reports/dashboard',
    REPORT_OVERDUE: '/api/v1/reports/overdue',
    REPORT_OOT: '/api/v1/reports/oot',
    REPORT_CERTIFICATES: '/api/v1/reports/certificates',

    // CAL-020 audit
    AUDIT_EQUIPMENT: (equipmentId) => `/api/v1/audit/equipment/${equipmentId}/revisions`,
    AUDIT_PLAN: (id) => `/api/v1/audit/calibration-plans/${id}/revisions`,
    AUDIT_RECORD: (id) => `/api/v1/audit/calibration-records/${id}/revisions`,
    AUDIT_REFERENCE_STANDARD: (standardId) => `/api/v1/audit/reference-standards/${standardId}/revisions`,
};

/* ─────────────────────────────────────────────────────────────────────────
   OPTION LISTS — mirror the backend enums exactly (org.bel.qm.entity.*).
───────────────────────────────────────────────────────────────────────── */
export const EQUIPMENT_STATUS_OPTIONS = [
    { label: 'Due', value: 'DUE' },
    { label: 'Overdue', value: 'OVERDUE' },
    { label: 'Blocked', value: 'BLOCKED' },
    { label: 'In Calibration', value: 'IN_CALIBRATION' },
    { label: 'Active', value: 'ACTIVE' },
    { label: 'Retired', value: 'RETIRED' },
];

export const EQUIPMENT_STATUS_SEVERITY = {
    DUE: 'warning',
    OVERDUE: 'danger',
    BLOCKED: 'danger',
    IN_CALIBRATION: 'info',
    ACTIVE: 'success',
    RETIRED: 'secondary',
};

export const CRITICALITY_OPTIONS = [
    { label: 'Critical', value: 'CRITICAL' },
    { label: 'Non-Critical', value: 'NON_CRITICAL' },
];

export const CRITICALITY_SEVERITY = {
    CRITICAL: 'danger',
    NON_CRITICAL: 'secondary',
};

export const SCHEDULE_STATUS_SEVERITY = {
    SCHEDULED: 'info',
    ASSIGNED: 'info',
    IN_PROGRESS: 'warning',
    COMPLETED: 'success',
    CANCELLED: 'secondary',
};

export const RESULT_STATUS_SEVERITY = {
    PASS: 'success',
    FAIL: 'danger',
    CONDITIONAL: 'warning',
    OUT_OF_TOLERANCE: 'danger',
};

export const REFERENCE_STANDARD_STATUS_SEVERITY = { ACTIVE: 'success', EXPIRED: 'danger', RETIRED: 'secondary' };

export const REPAIR_STATUS_SEVERITY = {
    OPEN: 'warning',
    IN_PROGRESS: 'info',
    COMPLETED: 'info',
    RETEST_PASSED: 'success',
    RETEST_FAILED: 'danger',
    RETURNED_TO_SERVICE: 'success',
};

/** PENDING is the initial state; it is not a valid choice when recording a disposition. */
export const OOT_DISPOSITION_OPTIONS = [
    { label: 'Use as is', value: 'USE_AS_IS' },
    { label: 'Rework', value: 'REWORK' },
    { label: 'Scrap', value: 'SCRAP' },
    { label: 'Recall', value: 'RECALL' },
    { label: 'No impact', value: 'NO_IMPACT' },
];

export const OOT_DISPOSITION_SEVERITY = {
    PENDING: 'warning',
    USE_AS_IS: 'info',
    REWORK: 'info',
    SCRAP: 'danger',
    RECALL: 'danger',
    NO_IMPACT: 'success',
};

export const QUALITY_HOLD_RESOLVE_OPTIONS = [
    { label: 'Reinspected', value: 'REINSPECTED' },
    { label: 'Released', value: 'RELEASED' },
    { label: 'Recalled', value: 'RECALLED' },
];

export const QUALITY_HOLD_STATUS_SEVERITY = {
    ON_HOLD: 'danger',
    REINSPECTED: 'info',
    RELEASED: 'success',
    RECALLED: 'warning',
};

export const CERTIFICATE_STATUS_OPTIONS = [
    { label: 'Pending', value: 'PENDING' },
    { label: 'Verified', value: 'VERIFIED' },
    { label: 'Approved', value: 'APPROVED' },
];

export const CERTIFICATE_STATUS_SEVERITY = { PENDING: 'warning', VERIFIED: 'info', APPROVED: 'success' };

export const EXTERNAL_STATUS_SEVERITY = {
    REQUESTED: 'info',
    DISPATCHED: 'info',
    CERTIFICATE_RECEIVED: 'warning',
    VERIFIED: 'info',
    REACTIVATED: 'success',
    CANCELLED: 'secondary',
};

export const CONDITIONAL_USE_STATUS_SEVERITY = {
    REQUESTED: 'warning',
    APPROVED: 'info',
    REJECTED: 'danger',
    ACTIVE: 'success',
    EXPIRED: 'danger',
    CLOSED: 'secondary',
};

/* ─────────────────────────────────────────────────────────────────────────
   AUTH HEADERS
   ─────────────────────────────────────────────────────────────────────────
   erp-qm-service's RBAC (QM-CAL-018) reads X-User-Id / X-User-Role directly
   (see its README) rather than validating the JWT itself — it expects a
   gateway to have already authenticated the request and forwarded these.
   We send them from what the platform already has client-side as a
   pragmatic bridge, but:

   getUserRole() returns EVERY role the user holds across tenants; there is
   no guarantee any of them match erp-qm-service's UserRole enum values
   (QA_MANAGER, CALIBRATION_TECHNICIAN, LAB_MANAGER, ASSET_MANAGER, ...).
   Only Equipment.activate and CalibrationPlan.approve are role-guarded in
   this first UI pass — if role names don't line up, those two actions will
   403 even for a legitimate user until tenant/role config (or a gateway
   claim-mapping step) assigns them a matching role name.
───────────────────────────────────────────────────────────────────────── */
export function useCalibrationHeaders(authToken) {
    const userDetails = getUserDetails();
    const roles = getUserRole();
    return {
        Authorization: `Bearer ${authToken}`,
        'X-User-Id': userDetails?.username || '',
        'X-User-Role': roles?.[0] || '',
    };
}

/**
 * Name of the logged-in user, used to pre-fill the "approved by / requested by /
 * verified by" fields the backend takes from the request body.
 */
export function useCalibrationUser() {
    return getUserDetails()?.username || '';
}
