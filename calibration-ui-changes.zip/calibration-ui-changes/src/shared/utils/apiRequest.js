/**
 * Returns the full service URL for the given service key.
 *
 * @param service - The target service
 * @param endPoint - Extra path to append at the end
 * @param useGateway - If true, will return the gateway URL + the target service's context URL
 */
const getServiceUrl = (service, endPoint = '', useGateway = true) => {
    const baseUrls = {
        user: import.meta.env.VITE_PF_USER_SERVICE_URL ?? '',
        mdms: import.meta.env.VITE_PF_MDMS_SERVICE_URL ?? '',
        workflow: import.meta.env.VITE_PF_WF_SERVICE_URL ?? '',
        dwf: import.meta.env.VITE_PF_DWF_SERVICE_URL ?? '',
        fileStore: import.meta.env.VITE_PF_FILESTORE_SERVICE_URL ?? '',
        localization: import.meta.env.VITE_PF_LOCALIZATION_SERVICE_URL ?? '',
        dashboard: import.meta.env.VITE_PF_DASHBOARD_SERVICE_URL ?? '',
        reports: import.meta.env.VITE_PF_REPORTS_SERVICE_URL ?? '',
        gateway: import.meta.env.VITE_PF_GATEWAY_SERVICE_URL ?? '',
        irs: import.meta.env.VITE_PF_CNS_IRS_SERVICE_URL ?? '',
        business: import.meta.env.VITE_CENSUS_BUSINESS_SERVICE_URL ?? '',
        erp_hrms: import.meta.env.VITE_ERP_HRMS_SERVICE_URL ?? '',
        material: import.meta.env.VITE_ERP_PLM_SERVICE_URL ?? '',
        mrp: import.meta.env.VITE_ERP_MRP_SERVICE_URL ?? '',
        finance: import.meta.env.VITE_FINANCE_SERVICE_URL ?? '',
        payroll: import.meta.env.VITE_PAYROLL_SERVICE_URL ?? '',
        llm: import.meta.env.VITE_PF_LLM_SERVICE_URL ?? '',
        ps: import.meta.env.VITE_PROJECT_SYSTEM_SERVICE_URL ?? '',
        dl: import.meta.env.VITE_ERP_RAGFLOW_SERVICE_URL ?? '',
        inv_ml: import.meta.env.VITE_ERP_INV_ML_SERVICE_URL ?? '',
        requirement: import.meta.env.VITE_PLM_REQUIREMENT_SERVICE_URL ?? '',
        am: import.meta.env.VITE_ERP_AM_SERVICE_URL ?? '',
        qms: import.meta.env.VITE_QMS_SERVICE_URL ?? '',
        calibration: import.meta.env.VITE_ERP_QM_SERVICE_URL ?? '',
    };

    const contextUrls = {
        user: import.meta.env.VITE_PF_USER_SERVICE_CONTEXT_URL ?? '',
        mdms: import.meta.env.VITE_PF_MDMS_SERVICE_CONTEXT_URL ?? '',
        workflow: import.meta.env.VITE_PF_WF_SERVICE_CONTEXT_URL ?? '',
        dwf: import.meta.env.VITE_PF_DWF_SERVICE_CONTEXT_URL ?? '',
        fileStore: import.meta.env.VITE_PF_FILESTORE_SERVICE_CONTEXT_URL ?? '',
        localization: import.meta.env.VITE_PF_LOCALIZATION_SERVICE_CONTEXT_URL ?? '',
        dashboard: import.meta.env.VITE_PF_DASHBOARD_SERVICE_CONTEXT_URL ?? '',
        reports: import.meta.env.VITE_PF_REPORTS_SERVICE_CONTEXT_URL ?? '',
        gateway: '',
        irs: import.meta.env.VITE_PF_CNS_IRS_SERVICE_CONTEXT_URL ?? '',
        business: import.meta.env.VITE_CENSUS_BUSINESS_SERVICE_CONTEXT_URL ?? '',
        erp_hrms: import.meta.env.VITE_ERP_HRMS_SERVICE_CONTEXT_URL ?? '',
        material: import.meta.env.VITE_ERP_PLM_SERVICE_CONTEXT_URL ?? '',
        mrp: import.meta.env.VITE_ERP_MRP_SERVICE_CONTEXT_URL ?? '',
        finance: import.meta.env.VITE_FINANCE_SERVICE_CONTEXT_URL ?? '',
        payroll: import.meta.env.VITE_PAYROLL_SERVICE_CONTEXT_URL ?? '',
        llm: import.meta.env.VITE_PF_LLM_SERVICE_CONTEXT_URL ?? '',
        ps: import.meta.env.VITE_PROJECT_SYSTEM_SERVICE_CONTEXT_URL ?? '',
        dl: import.meta.env.VITE_ERP_RAGFLOW_SERVICE_CONTEXT_URL ?? '',
        inv_ml: import.meta.env.VITE_ERP_INV_ML_SERVICE_CONTEXT_URL ?? '',
        requirement: import.meta.env.VITE_PLM_REQUIREMENT_SERVICE_CONTEXT_URL ?? '',
        am: import.meta.env.VITE_ERP_AM_SERVICE_CONTEXT_URL ?? '',
        qms: import.meta.env.VITE_ERP_QMS_SERVICE_CONTEXT_URL ?? '',
        calibration: import.meta.env.VITE_ERP_QM_SERVICE_CONTEXT_URL ?? '',
    };

    if (!baseUrls[service] && !contextUrls[service]) {
        return 'No service with the given name found.';
    }

    const base = useGateway ? baseUrls.gateway : baseUrls[service];
    return base + contextUrls[service] + endPoint;
};

export async function apiRequest({
    method = 'GET',
    headers = {},
    body,
    service = '',
    endpoint = '',
    useGateway = true,
}) {
    const url = getServiceUrl(service, endpoint, useGateway);
    const isFormData = body instanceof FormData;

    const options = {
        method,
        headers: {
            ...headers,
        },
    };

    // If the request is for the Document Library / RAGFlow service, include cookies
    if (service === 'dl') {
        options.credentials = 'include';
    }

    if (body && method !== 'GET') {
        if (isFormData) {
            options.body = body;
        } else {
            options.headers['Content-Type'] = 'application/json';
            options.body = JSON.stringify(body);
        }
    }

    try {
        const response = await fetch(url, options);

        const contentType = response.headers.get('Content-Type') ?? '';
        const isJson = contentType.includes('application/json');

        let responseData = null;
        try {
            // responseData = isJson ? await response.json() : await response.text();

            if (isJson) {
                responseData = await response.json();
            }
        } catch {
            responseData = null;
        }

        if (!response.ok) {
            const error = new Error(responseData?.message || response.statusText);
            error.status = response.status;
            error.data = responseData;
            throw error;
        }

        if (isJson) return responseData;

        if (
            contentType.includes('application/vnd.ms-excel') ||
            contentType.includes('application/vnd.openxmlformats-officedocument') ||
            contentType.includes('application/octet-stream') ||
            contentType.includes('application/pdf') ||
            contentType.startsWith('image/') ||
            contentType.startsWith('video/')
        ) {
            return await response.blob();
        }

        if (contentType.startsWith('text/')) {
            return await response.text();
        }

        return await response.blob();
    } catch (error) {
        console.error('API request failed:', {
            url,
            status: error.status,
            message: error.message,
            data: error.data,
        });
        throw error;
    }
}
