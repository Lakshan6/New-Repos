import { useCallback, useMemo, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';
import { useForm } from 'react-hook-form';

import {
    ListPage,
    AppDataTable,
    FilterToolbar,
    FormDialog,
    FormGroup,
    ControlledInputText,
    ControlledDropdown,
    ControlledInputTextarea,
    ControlledCalendar,
    useAppToast,
    mutedDash,
    emphasisCell,
    statusCell,
} from '@shared/components';
import { useT, useSafeContext, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext, apiRequest } from '@shared/utils';
import { toLocalDateString } from '@shared/utils/dateUtils';
import {
    CALIBRATION_ENDPOINTS,
    EQUIPMENT_STATUS_OPTIONS,
    EQUIPMENT_STATUS_SEVERITY,
    CRITICALITY_OPTIONS,
    CRITICALITY_SEVERITY,
    useCalibrationHeaders,
} from '../../utils/calibrationConstants';

const DEFAULT_VALUES = {
    equipmentId: '',
    name: '',
    type: '',
    manufacturer: '',
    model: '',
    serialNumber: '',
    assetTag: '',
    location: '',
    owner: '',
    category: '',
    criticality: null,
    measurementRange: '',
    accuracy: '',
    resolution: '',
    intendedUse: '',
    acquisitionDate: null,
};

const equipmentIdBody = emphasisCell('equipmentId');
const nameBody = (row) => row.name || mutedDash();
const statusBody = statusCell('status', EQUIPMENT_STATUS_SEVERITY);
const criticalityBody = statusCell('criticality', CRITICALITY_SEVERITY);

/**
 * QM-CAL-001 / QM-CAL-002 — register, list, approve and activate calibration
 * equipment. Row click opens the equipment's detail page (plan, schedule,
 * records history).
 */
const EquipmentListPage = () => {
    const { t } = useT();
    const navigate = useNavigate();
    const { authToken } = useSafeContext(AuthContext);
    const toast = useAppToast();
    const headers = useCalibrationHeaders(authToken);

    const [keyword, setKeyword] = useState('');
    const [statusFilter, setStatusFilter] = useState(null);
    const [showRegister, setShowRegister] = useState(false);
    const [rowActionId, setRowActionId] = useState(null);

    const { control, handleSubmit, reset } = useForm({ defaultValues: DEFAULT_VALUES });

    const {
        data: equipmentList,
        isLoading,
        refetch,
    } = useReadApi({
        service: 'calibration',
        endpoint: statusFilter
            ? `${CALIBRATION_ENDPOINTS.EQUIPMENT}?status=${statusFilter}`
            : CALIBRATION_ENDPOINTS.EQUIPMENT,
        headers,
    });

    const rows = useMemo(() => {
        const list = Array.isArray(equipmentList) ? equipmentList : [];
        if (!keyword.trim()) return list;
        const kw = keyword.trim().toLowerCase();
        return list.filter(
            (e) =>
                e.equipmentId?.toLowerCase().includes(kw) ||
                e.name?.toLowerCase().includes(kw) ||
                e.serialNumber?.toLowerCase().includes(kw),
        );
    }, [equipmentList, keyword]);

    const registerMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT,
        method: 'POST',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Equipment registered.');
                setShowRegister(false);
                reset(DEFAULT_VALUES);
                refetch();
            },
            onError: (err) => toast.apiError(err, 'Could not register equipment.'),
        },
    });

    const openRegister = useCallback(() => setShowRegister(true), []);
    const hideRegister = useCallback(() => {
        setShowRegister(false);
        reset(DEFAULT_VALUES);
    }, [reset]);

    const submitRegister = useCallback(
        (values) => {
            registerMutation.mutate({
                ...values,
                acquisitionDate: values.acquisitionDate ? toLocalDateString(values.acquisitionDate) : null,
            });
        },
        [registerMutation],
    );

    const handleRowClick = useCallback((e) => navigate(e.data.equipmentId), [navigate]);

    /**
     * Approve/activate hit a per-row endpoint (`/equipment/{id}/approve`), which
     * useMutationApi can't express (its endpoint is fixed at hook-creation time)
     * — so these call apiRequest directly instead of going through the hook.
     */
    const runRowAction = useCallback(
        async (row, endpoint, successMessage, failureMessage) => {
            setRowActionId(row.equipmentId);
            try {
                await apiRequest({ service: 'calibration', endpoint, method: 'POST', headers });
                toast.success('Success', successMessage);
                refetch();
            } catch (err) {
                toast.apiError(err, failureMessage);
            } finally {
                setRowActionId(null);
            }
        },
        [headers, refetch, toast],
    );

    const handleApprove = useCallback(
        (e, row) => {
            e.stopPropagation();
            runRowAction(
                row,
                CALIBRATION_ENDPOINTS.EQUIPMENT_APPROVE(row.equipmentId),
                'Equipment approved.',
                'Could not approve equipment.',
            );
        },
        [runRowAction],
    );

    const handleActivate = useCallback(
        (e, row) => {
            e.stopPropagation();
            runRowAction(
                row,
                CALIBRATION_ENDPOINTS.EQUIPMENT_ACTIVATE(row.equipmentId),
                'Equipment activated.',
                'Could not activate equipment — it may need approval first.',
            );
        },
        [runRowAction],
    );

    const actionsBody = useCallback(
        (row) => {
            const busy = rowActionId === row.equipmentId;
            if (!row.approved) {
                return <Button label="Approve" size="small" text loading={busy} onClick={(e) => handleApprove(e, row)} />;
            }
            if (!row.active) {
                return <Button label="Activate" size="small" text loading={busy} onClick={(e) => handleActivate(e, row)} />;
            }
            return null;
        },
        [rowActionId, handleApprove, handleActivate],
    );

    return (
        <ListPage
            title={t('CALIBRATION_EQUIPMENT', { fallbackText: 'Calibration Equipment' })}
            subtitle="Register and track quality-critical measuring equipment."
            actions={<Button label="Register Equipment" icon="pi pi-plus" onClick={openRegister} />}
            toolbar={
                <FilterToolbar keyword={keyword} onKeywordChange={setKeyword} onRefresh={refetch}>
                    <Dropdown
                        value={statusFilter}
                        options={EQUIPMENT_STATUS_OPTIONS}
                        onChange={(e) => setStatusFilter(e.value)}
                        placeholder="All statuses"
                        showClear
                        className="w-12rem"
                    />
                </FilterToolbar>
            }
        >
            <AppDataTable value={rows} loading={isLoading} dataKey="equipmentId" onRowClick={handleRowClick} className="cursor-pointer">
                <Column field="equipmentId" header="Equipment ID" sortable />
                <Column field="name" header="Name" body={nameBody} sortable />
                <Column field="type" header="Type" sortable />
                <Column header="Criticality" body={criticalityBody} />
                <Column header="Status" body={statusBody} />
                <Column field="location" header="Location" />
                <Column field="owner" header="Owner" />
                <Column header="" body={actionsBody} style={{ width: '8rem' }} />
            </AppDataTable>

            {showRegister && (
                <FormDialog
                    header="Register Equipment"
                    size="lg"
                    onHide={hideRegister}
                    onSubmit={handleSubmit(submitRegister)}
                    submitLabel="Register"
                    submitIcon="pi pi-check"
                    busy={registerMutation.isPending}
                >
                    <div className="grid formgrid">
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-id" label="Equipment ID" required>
                                <ControlledInputText name="equipmentId" control={control} inputId="cal-eq-id" rules={{ required: 'Equipment ID is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-name" label="Name" required>
                                <ControlledInputText name="name" control={control} inputId="cal-eq-name" rules={{ required: 'Name is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-type" label="Type" required>
                                <ControlledInputText name="type" control={control} inputId="cal-eq-type" rules={{ required: 'Type is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-criticality" label="Criticality" required>
                                <ControlledDropdown
                                    name="criticality"
                                    control={control}
                                    inputId="cal-eq-criticality"
                                    options={CRITICALITY_OPTIONS}
                                    placeholder="Select criticality"
                                    rules={{ required: 'Criticality is required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-manufacturer" label="Manufacturer">
                                <ControlledInputText name="manufacturer" control={control} inputId="cal-eq-manufacturer" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-model" label="Model">
                                <ControlledInputText name="model" control={control} inputId="cal-eq-model" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-serial" label="Serial Number" required>
                                <ControlledInputText name="serialNumber" control={control} inputId="cal-eq-serial" rules={{ required: 'Serial number is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-asset-tag" label="Asset Tag">
                                <ControlledInputText name="assetTag" control={control} inputId="cal-eq-asset-tag" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-location" label="Location">
                                <ControlledInputText name="location" control={control} inputId="cal-eq-location" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-owner" label="Owner" required>
                                <ControlledInputText name="owner" control={control} inputId="cal-eq-owner" rules={{ required: 'Owner is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-category" label="Category">
                                <ControlledInputText name="category" control={control} inputId="cal-eq-category" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cal-eq-acq-date" label="Acquisition Date">
                                <ControlledCalendar name="acquisitionDate" control={control} inputId="cal-eq-acq-date" showIcon />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cal-eq-range" label="Measurement Range">
                                <ControlledInputText name="measurementRange" control={control} inputId="cal-eq-range" />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cal-eq-accuracy" label="Accuracy">
                                <ControlledInputText name="accuracy" control={control} inputId="cal-eq-accuracy" />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cal-eq-resolution" label="Resolution">
                                <ControlledInputText name="resolution" control={control} inputId="cal-eq-resolution" />
                            </FormGroup>
                        </div>
                        <div className="col-12">
                            <FormGroup htmlFor="cal-eq-intended-use" label="Intended Use">
                                <ControlledInputTextarea name="intendedUse" control={control} inputId="cal-eq-intended-use" rows={2} autoResize />
                            </FormGroup>
                        </div>
                    </div>
                </FormDialog>
            )}
        </ListPage>
    );
};

export default EquipmentListPage;
