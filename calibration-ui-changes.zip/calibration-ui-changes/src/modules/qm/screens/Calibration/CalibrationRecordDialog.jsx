import { useCallback } from 'react';
import PropTypes from 'prop-types';
import { useFieldArray, useForm } from 'react-hook-form';
import { Button } from 'primereact/button';

import {
    FormDialog,
    FormGroup,
    ControlledInputText,
    ControlledInputNumber,
    ControlledInputTextarea,
    ControlledCalendar,
    useAppToast,
} from '@shared/components';
import { useMutationApi } from '@shared/hooks';
import { toLocalDateString } from '@shared/utils/dateUtils';
import { getUserDetails } from '@shared/utils';
import { CALIBRATION_ENDPOINTS } from '../../utils/calibrationConstants';

const EMPTY_TEST_RESULT = { parameterName: '', uom: '', targetValue: null, asFoundValue: null, asLeftValue: null };

const DEFAULT_VALUES = {
    calibrationDate: new Date(),
    technician: '',
    method: '',
    referenceStandardId: '',
    submittedBy: getUserDetails()?.username || '',
    remarks: '',
    testResults: [{ ...EMPTY_TEST_RESULT }],
};

/**
 * QM-CAL-007 execution capture / QM-CAL-008 tolerance evaluation.
 *
 * `referenceStandardId` is a plain text field here — there's no Reference
 * Standard register/picker screen in this first UI pass (QM-CAL-013's
 * backend exists; its UI doesn't yet), so the technician must already know
 * the standard's business key. The backend rejects unknown, expired, or
 * retired standard ids at submission time.
 */
const CalibrationRecordDialog = ({ equipmentId, headers, onHide, onSuccess }) => {
    const toast = useAppToast();
    const { control, handleSubmit } = useForm({ defaultValues: DEFAULT_VALUES });
    const { fields, append, remove } = useFieldArray({ control, name: 'testResults' });

    const submitMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_RECORDS(equipmentId),
        method: 'POST',
        headers,
        options: {
            onSuccess: (data) => {
                toast.success(
                    'Success',
                    `Calibration submitted — result: ${data?.resultStatus ?? 'recorded'}.`,
                );
                onSuccess();
            },
            onError: (err) => toast.apiError(err, 'Could not submit calibration record.'),
        },
    });

    const onSubmit = useCallback(
        (values) => {
            submitMutation.mutate({
                ...values,
                calibrationDate: toLocalDateString(values.calibrationDate),
                testResults: values.testResults.map((r) => ({
                    ...r,
                    targetValue: r.targetValue ?? null,
                    asLeftValue: r.asLeftValue ?? null,
                })),
            });
        },
        [submitMutation],
    );

    const addRow = useCallback(() => append({ ...EMPTY_TEST_RESULT }), [append]);

    return (
        <FormDialog
            header="Submit Calibration"
            size="lg"
            onHide={onHide}
            onSubmit={handleSubmit(onSubmit)}
            submitLabel="Submit"
            submitIcon="pi pi-check"
            busy={submitMutation.isPending}
        >
            <div className="grid formgrid">
                <div className="col-4">
                    <FormGroup htmlFor="cr-date" label="Calibration Date" required>
                        <ControlledCalendar
                            name="calibrationDate"
                            control={control}
                            inputId="cr-date"
                            showIcon
                            rules={{ required: 'Calibration date is required' }}
                        />
                    </FormGroup>
                </div>
                <div className="col-4">
                    <FormGroup htmlFor="cr-technician" label="Technician" required>
                        <ControlledInputText name="technician" control={control} inputId="cr-technician" rules={{ required: 'Technician is required' }} />
                    </FormGroup>
                </div>
                <div className="col-4">
                    <FormGroup htmlFor="cr-method" label="Method" required>
                        <ControlledInputText name="method" control={control} inputId="cr-method" rules={{ required: 'Method is required' }} />
                    </FormGroup>
                </div>
                <div className="col-6">
                    <FormGroup htmlFor="cr-standard" label="Reference Standard ID" required>
                        <ControlledInputText
                            name="referenceStandardId"
                            control={control}
                            inputId="cr-standard"
                            placeholder="e.g. STD-0012"
                            rules={{ required: 'Reference standard is required' }}
                        />
                    </FormGroup>
                </div>
                <div className="col-6">
                    <FormGroup htmlFor="cr-submitted-by" label="Submitted By" required>
                        <ControlledInputText name="submittedBy" control={control} inputId="cr-submitted-by" rules={{ required: 'Required' }} />
                    </FormGroup>
                </div>

                <div className="col-12">
                    <div className="flex align-items-center justify-content-between mb-2">
                        <span className="font-medium text-600">Test Points</span>
                        <Button label="Add Point" icon="pi pi-plus" size="small" text onClick={addRow} />
                    </div>

                    <div className="flex flex-column gap-2">
                        <div className="grid formgrid text-sm text-600 mb-1">
                            <div className="col-3">Parameter</div>
                            <div className="col-2">UOM</div>
                            <div className="col-2">Target</div>
                            <div className="col-2">As-Found</div>
                            <div className="col-2">As-Left</div>
                            <div className="col-1" />
                        </div>

                        {fields.map((field, index) => (
                            <div className="grid formgrid align-items-start" key={field.id}>
                                <div className="col-3">
                                    <ControlledInputText
                                        name={`testResults.${index}.parameterName`}
                                        control={control}
                                        inputId={`tp-name-${index}`}
                                        rules={{ required: 'Required' }}
                                    />
                                </div>
                                <div className="col-2">
                                    <ControlledInputText name={`testResults.${index}.uom`} control={control} inputId={`tp-uom-${index}`} />
                                </div>
                                <div className="col-2">
                                    <ControlledInputNumber name={`testResults.${index}.targetValue`} control={control} inputId={`tp-target-${index}`} mode="decimal" maxFractionDigits={4} />
                                </div>
                                <div className="col-2">
                                    <ControlledInputNumber
                                        name={`testResults.${index}.asFoundValue`}
                                        control={control}
                                        inputId={`tp-found-${index}`}
                                        mode="decimal"
                                        maxFractionDigits={4}
                                        rules={{ required: 'Required' }}
                                    />
                                </div>
                                <div className="col-2">
                                    <ControlledInputNumber name={`testResults.${index}.asLeftValue`} control={control} inputId={`tp-left-${index}`} mode="decimal" maxFractionDigits={4} />
                                </div>
                                <div className="col-1">
                                    <Button
                                        icon="pi pi-trash"
                                        rounded
                                        text
                                        severity="danger"
                                        disabled={fields.length === 1}
                                        onClick={() => remove(index)}
                                        aria-label="Remove test point"
                                    />
                                </div>
                            </div>
                        ))}
                    </div>
                </div>

                <div className="col-12">
                    <FormGroup htmlFor="cr-remarks" label="Remarks">
                        <ControlledInputTextarea name="remarks" control={control} inputId="cr-remarks" rows={2} autoResize />
                    </FormGroup>
                </div>
            </div>
        </FormDialog>
    );
};

CalibrationRecordDialog.propTypes = {
    equipmentId: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    onHide: PropTypes.func.isRequired,
    onSuccess: PropTypes.func.isRequired,
};

export default CalibrationRecordDialog;
