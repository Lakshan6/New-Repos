import { useCallback, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { useForm } from 'react-hook-form';

import {
    ListPage,
    AppDataTable,
    FilterToolbar,
    FormDialog,
    FormGroup,
    ControlledInputText,
    useAppToast,
    mutedDash,
    emphasisCell,
    statusCell,
    dateCell,
} from '@shared/components';
import { useT, useSafeContext, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { CALIBRATION_ENDPOINTS, SCHEDULE_STATUS_SEVERITY, useCalibrationHeaders } from '../../utils/calibrationConstants';

const equipmentIdBody = emphasisCell('equipmentId');
const dueDateBody = dateCell('dueDate');
const statusBody = statusCell('status', SCHEDULE_STATUS_SEVERITY);

/**
 * QM-CAL-004 — due/overdue calibration worklist. "Generate Worklist" runs the
 * same job as erp-qm-service's daily cron, on demand; assigning a technician
 * moves an item from SCHEDULED to ASSIGNED.
 */
const CalibrationScheduleListPage = () => {
    const { t } = useT();
    const navigate = useNavigate();
    const { authToken } = useSafeContext(AuthContext);
    const toast = useAppToast();
    const headers = useCalibrationHeaders(authToken);

    const [keyword, setKeyword] = useState('');
    const [assignTarget, setAssignTarget] = useState(null);

    const { control, handleSubmit, reset } = useForm({ defaultValues: { technician: '' } });

    const {
        data: scheduleList,
        isLoading,
        refetch,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.SCHEDULE_LIST,
        headers,
    });

    const generateMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.SCHEDULE_GENERATE,
        method: 'POST',
        headers,
        options: {
            onSuccess: (data) => {
                const count = Array.isArray(data) ? data.length : 0;
                toast.success('Success', `Generated ${count} worklist item${count === 1 ? '' : 's'}.`);
                refetch();
            },
            onError: (err) => toast.apiError(err, 'Could not generate the worklist.'),
        },
    });

    const assignMutation = useMutationApi({
        service: 'calibration',
        endpoint: assignTarget ? CALIBRATION_ENDPOINTS.SCHEDULE_ASSIGN(assignTarget.id) : undefined,
        method: 'POST',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Technician assigned.');
                setAssignTarget(null);
                reset({ technician: '' });
                refetch();
            },
            onError: (err) => toast.apiError(err, 'Could not assign technician.'),
        },
    });

    const rows = (Array.isArray(scheduleList) ? scheduleList : []).filter((s) => {
        if (!keyword.trim()) return true;
        const kw = keyword.trim().toLowerCase();
        return s.equipmentId?.toLowerCase().includes(kw) || s.equipmentName?.toLowerCase().includes(kw);
    });

    const handleRowClick = useCallback((e) => navigate(`../equipment/${e.data.equipmentId}`), [navigate]);

    const openAssign = useCallback((e, row) => {
        e.stopPropagation();
        setAssignTarget(row);
        reset({ technician: row.assignedTechnician || '' });
    }, [reset]);

    const hideAssign = useCallback(() => setAssignTarget(null), []);

    const submitAssign = useCallback(
        (values) => assignMutation.mutate(values),
        [assignMutation],
    );

    const actionsBody = useCallback(
        (row) => <Button label="Assign" size="small" text onClick={(e) => openAssign(e, row)} />,
        [openAssign],
    );

    return (
        <ListPage
            title={t('CALIBRATION_SCHEDULE', { fallbackText: 'Calibration Schedule' })}
            subtitle="Due and overdue calibration worklist."
            actions={
                <Button
                    label="Generate Worklist"
                    icon="pi pi-refresh"
                    onClick={() => generateMutation.mutate()}
                    loading={generateMutation.isPending}
                />
            }
            toolbar={<FilterToolbar keyword={keyword} onKeywordChange={setKeyword} onRefresh={refetch} />}
        >
            <AppDataTable value={rows} loading={isLoading} dataKey="id" onRowClick={handleRowClick} className="cursor-pointer">
                <Column field="equipmentId" header="Equipment ID" body={equipmentIdBody} sortable />
                <Column field="equipmentName" header="Equipment" body={(row) => row.equipmentName || mutedDash()} />
                <Column header="Due Date" body={dueDateBody} sortable />
                <Column header="Status" body={statusBody} />
                <Column field="assignedTechnician" header="Technician" body={(row) => row.assignedTechnician || mutedDash()} />
                <Column field="location" header="Location" body={(row) => row.location || mutedDash()} />
                <Column header="" body={actionsBody} style={{ width: '8rem' }} />
            </AppDataTable>

            {assignTarget && (
                <FormDialog
                    header={`Assign Technician — ${assignTarget.equipmentId}`}
                    size="sm"
                    onHide={hideAssign}
                    onSubmit={handleSubmit(submitAssign)}
                    submitLabel="Assign"
                    busy={assignMutation.isPending}
                >
                    <FormGroup htmlFor="assign-technician" label="Technician" required>
                        <ControlledInputText
                            name="technician"
                            control={control}
                            inputId="assign-technician"
                            rules={{ required: 'Technician is required' }}
                        />
                    </FormGroup>
                </FormDialog>
            )}
        </ListPage>
    );
};

export default CalibrationScheduleListPage;
