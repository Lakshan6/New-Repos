import { useCallback, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { useForm } from 'react-hook-form';

import {
    PageLayout,
    Card,
    AppDataTable,
    FormDialog,
    FormGroup,
    ReadOnlyField,
    ControlledInputText,
    ControlledInputNumber,
    ControlledCalendar,
    useAppToast,
    mutedDash,
    statusCell,
    dateCell,
} from '@shared/components';
import { useT, useSafeContext, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { toLocalDateString } from '@shared/utils/dateUtils';
import {
    CALIBRATION_ENDPOINTS,
    EQUIPMENT_STATUS_SEVERITY,
    CRITICALITY_SEVERITY,
    RESULT_STATUS_SEVERITY,
    useCalibrationHeaders,
} from '../../utils/calibrationConstants';
import CalibrationRecordDialog from './CalibrationRecordDialog';

const PLAN_DEFAULT_VALUES = {
    calibrationIntervalDays: null,
    calibrationMethod: '',
    toleranceLower: null,
    toleranceUpper: null,
    uom: '',
    serviceProvider: '',
    lastCalibrationDate: null,
};

const resultStatusBody = statusCell('resultStatus', RESULT_STATUS_SEVERITY);
const calDateBody = dateCell('calibrationDate');

/**
 * Equipment detail — QM-CAL-001/002 info, QM-CAL-003 calibration plan
 * (create/update + approve), QM-CAL-007/008 calibration history + submission.
 */
const EquipmentDetailPage = () => {
    const { t } = useT();
    const { equipmentId } = useParams();
    const { authToken } = useSafeContext(AuthContext);
    const toast = useAppToast();
    const headers = useCalibrationHeaders(authToken);

    const [showPlanDialog, setShowPlanDialog] = useState(false);
    const [showRecordDialog, setShowRecordDialog] = useState(false);

    const {
        data: equipment,
        isLoading: equipmentLoading,
        refetch: refetchEquipment,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT_BY_ID(equipmentId),
        headers,
    });

    const {
        data: plan,
        isError: planMissing,
        refetch: refetchPlan,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN(equipmentId),
        headers,
        options: { retry: false },
    });

    const {
        data: records,
        isLoading: recordsLoading,
        refetch: refetchRecords,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_RECORDS(equipmentId),
        headers,
    });

    const { control, handleSubmit, reset } = useForm({ defaultValues: PLAN_DEFAULT_VALUES });

    const planMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN(equipmentId),
        method: 'PUT',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Calibration plan saved — approval is required before it takes effect.');
                setShowPlanDialog(false);
                refetchPlan();
            },
            onError: (err) => toast.apiError(err, 'Could not save calibration plan.'),
        },
    });

    const approvePlanMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN_APPROVE(equipmentId),
        method: 'POST',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Calibration plan approved.');
                refetchPlan();
                refetchEquipment();
            },
            onError: (err) => toast.apiError(err, 'Could not approve calibration plan — check your role.'),
        },
    });

    const activateMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT_ACTIVATE(equipmentId),
        method: 'POST',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Equipment activated.');
                refetchEquipment();
            },
            onError: (err) => toast.apiError(err, 'Could not activate equipment — check your role or approval status.'),
        },
    });

    const openPlanDialog = useCallback(() => {
        if (plan) {
            reset({
                calibrationIntervalDays: plan.calibrationIntervalDays,
                calibrationMethod: plan.calibrationMethod,
                toleranceLower: plan.toleranceLower,
                toleranceUpper: plan.toleranceUpper,
                uom: plan.uom,
                serviceProvider: plan.serviceProvider,
                lastCalibrationDate: plan.lastCalibrationDate ?? null,
            });
        } else {
            reset(PLAN_DEFAULT_VALUES);
        }
        setShowPlanDialog(true);
    }, [plan, reset]);

    const hidePlanDialog = useCallback(() => setShowPlanDialog(false), []);

    const submitPlan = useCallback(
        (values) => {
            planMutation.mutate({
                ...values,
                lastCalibrationDate: values.lastCalibrationDate ? toLocalDateString(values.lastCalibrationDate) : null,
            });
        },
        [planMutation],
    );

    const handleRecordSuccess = useCallback(() => {
        setShowRecordDialog(false);
        refetchRecords();
        refetchEquipment();
        refetchPlan();
    }, [refetchRecords, refetchEquipment, refetchPlan]);

    if (equipmentLoading || !equipment) {
        return <div className="p-4 text-center">Loading…</div>;
    }

    return (
        <PageLayout>
            <PageLayout.Header
                title={equipment.name}
                subtitle={`${equipment.equipmentId} · ${equipment.type}`}
                backButton
                status={
                    <>
                        {equipment.status && <Tag value={equipment.status} severity={EQUIPMENT_STATUS_SEVERITY[equipment.status] ?? 'info'} />}
                        {equipment.criticality && (
                            <Tag className="ml-2" value={equipment.criticality} severity={CRITICALITY_SEVERITY[equipment.criticality] ?? 'info'} />
                        )}
                    </>
                }
                actions={
                    !equipment.active &&
                    equipment.approved && <Button label="Activate" icon="pi pi-bolt" onClick={() => activateMutation.mutate()} loading={activateMutation.isPending} />
                }
            />

            <PageLayout.Content>
                <Card title={t('EQUIPMENT_DETAILS', { fallbackText: 'Equipment Details' })}>
                    <div className="grid">
                        <div className="col-3"><ReadOnlyField label="Manufacturer" value={equipment.manufacturer} /></div>
                        <div className="col-3"><ReadOnlyField label="Model" value={equipment.model} /></div>
                        <div className="col-3"><ReadOnlyField label="Serial Number" value={equipment.serialNumber} /></div>
                        <div className="col-3"><ReadOnlyField label="Asset Tag" value={equipment.assetTag} /></div>
                        <div className="col-3"><ReadOnlyField label="Location" value={equipment.location} /></div>
                        <div className="col-3"><ReadOnlyField label="Owner" value={equipment.owner} /></div>
                        <div className="col-3"><ReadOnlyField label="Category" value={equipment.category} /></div>
                        <div className="col-3"><ReadOnlyField label="Measurement Range" value={equipment.measurementRange} /></div>
                        <div className="col-3"><ReadOnlyField label="Accuracy" value={equipment.accuracy} /></div>
                        <div className="col-3"><ReadOnlyField label="Resolution" value={equipment.resolution} /></div>
                        <div className="col-6"><ReadOnlyField label="Intended Use" value={equipment.intendedUse} /></div>
                    </div>
                </Card>

                <Card
                    title={t('CALIBRATION_PLAN', { fallbackText: 'Calibration Plan' })}
                    header={
                        <div className="flex gap-2">
                            <Button label={plan ? 'Edit Plan' : 'Create Plan'} icon="pi pi-pencil" text onClick={openPlanDialog} />
                            {plan && !plan.approved && (
                                <Button
                                    label="Approve Plan"
                                    icon="pi pi-check"
                                    text
                                    onClick={() => approvePlanMutation.mutate()}
                                    loading={approvePlanMutation.isPending}
                                />
                            )}
                        </div>
                    }
                >
                    {planMissing || !plan ? (
                        <p className="text-color-secondary m-0">No calibration plan configured yet.</p>
                    ) : (
                        <div className="grid">
                            <div className="col-3"><ReadOnlyField label="Interval (days)" value={String(plan.calibrationIntervalDays)} /></div>
                            <div className="col-3"><ReadOnlyField label="Method" value={plan.calibrationMethod} /></div>
                            <div className="col-3"><ReadOnlyField label="Tolerance" value={`${plan.toleranceLower} – ${plan.toleranceUpper} ${plan.uom || ''}`} /></div>
                            <div className="col-3"><ReadOnlyField label="Service Provider" value={plan.serviceProvider} /></div>
                            <div className="col-3"><ReadOnlyField label="Last Calibration" value={plan.lastCalibrationDate || mutedDash()} /></div>
                            <div className="col-3"><ReadOnlyField label="Next Due" value={plan.nextDueDate || mutedDash()} /></div>
                            <div className="col-3">
                                <FormGroup label="Approved">
                                    <Tag value={plan.approved ? 'Approved' : 'Pending Approval'} severity={plan.approved ? 'success' : 'warning'} />
                                </FormGroup>
                            </div>
                        </div>
                    )}
                </Card>

                <Card
                    title={t('CALIBRATION_RECORDS', { fallbackText: 'Calibration Records' })}
                    header={
                        <Button
                            label="Submit Calibration"
                            icon="pi pi-plus"
                            onClick={() => setShowRecordDialog(true)}
                            disabled={!plan?.approved}
                            tooltip={!plan?.approved ? 'An approved calibration plan is required first' : undefined}
                        />
                    }
                >
                    <AppDataTable value={records || []} loading={recordsLoading} dataKey="id" paginator={false}>
                        <Column header="Date" body={calDateBody} />
                        <Column field="technician" header="Technician" />
                        <Column field="method" header="Method" />
                        <Column header="Result" body={resultStatusBody} />
                        <Column field="submittedBy" header="Submitted By" />
                        <Column field="remarks" header="Remarks" body={(row) => row.remarks || mutedDash()} />
                    </AppDataTable>
                </Card>
            </PageLayout.Content>

            {showPlanDialog && (
                <FormDialog
                    header={plan ? 'Edit Calibration Plan' : 'Create Calibration Plan'}
                    size="md"
                    onHide={hidePlanDialog}
                    onSubmit={handleSubmit(submitPlan)}
                    submitLabel="Save"
                    busy={planMutation.isPending}
                >
                    <div className="grid formgrid">
                        <div className="col-6">
                            <FormGroup htmlFor="cp-interval" label="Interval (days)" required>
                                <ControlledInputNumber
                                    name="calibrationIntervalDays"
                                    control={control}
                                    inputId="cp-interval"
                                    min={1}
                                    rules={{ required: 'Interval is required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cp-method" label="Method" required>
                                <ControlledInputText name="calibrationMethod" control={control} inputId="cp-method" rules={{ required: 'Method is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cp-tol-lower" label="Tolerance Lower" required>
                                <ControlledInputNumber
                                    name="toleranceLower"
                                    control={control}
                                    inputId="cp-tol-lower"
                                    mode="decimal"
                                    maxFractionDigits={4}
                                    rules={{ required: 'Required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cp-tol-upper" label="Tolerance Upper" required>
                                <ControlledInputNumber
                                    name="toleranceUpper"
                                    control={control}
                                    inputId="cp-tol-upper"
                                    mode="decimal"
                                    maxFractionDigits={4}
                                    rules={{ required: 'Required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cp-uom" label="Unit">
                                <ControlledInputText name="uom" control={control} inputId="cp-uom" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cp-provider" label="Service Provider">
                                <ControlledInputText name="serviceProvider" control={control} inputId="cp-provider" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cp-last-cal" label="Last Calibration Date">
                                <ControlledCalendar name="lastCalibrationDate" control={control} inputId="cp-last-cal" showIcon />
                            </FormGroup>
                        </div>
                    </div>
                </FormDialog>
            )}

            {showRecordDialog && (
                <CalibrationRecordDialog
                    equipmentId={equipmentId}
                    headers={headers}
                    onHide={() => setShowRecordDialog(false)}
                    onSuccess={handleRecordSuccess}
                />
            )}
        </PageLayout>
    );
};

export default EquipmentDetailPage;
