import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';

const MaterialScreen = lazy(() => import('@modules/qm/screens/MaterialScreen'));
const InspectionPaln = lazy(() => import('@modules/qm/screens/InspectionPaln'));
const InspectionChracterstic=lazy(() => import('@modules/qm/screens/MasterInspectionCharacteristic'));
const CalibrationEquipmentListPage = lazy(() => import('@modules/qm/screens/Calibration/EquipmentListPage'));
const CalibrationEquipmentDetailPage = lazy(() => import('@modules/qm/screens/Calibration/EquipmentDetailPage'));
const CalibrationScheduleListPage = lazy(() => import('@modules/qm/screens/Calibration/CalibrationScheduleListPage'));
const RouteFallback = () => <div className="p-4 text-center">Loading...</div>;

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.QMS}
            translationsAtom={translationsAtom}
        >
            <Suspense fallback={<RouteFallback />}>
                <Routes>
                    <Route index element={<MaterialScreen />} />
                    <Route path="/inspection-plan" element={<InspectionPaln />} />
                    <Route path="/create-material" element={<MaterialScreen />} />
                    <Route path="/master-insp-char"element={<InspectionChracterstic/>}/>
                    <Route path="/calibration/equipment" element={<CalibrationEquipmentListPage />} />
                    <Route path="/calibration/equipment/:equipmentId" element={<CalibrationEquipmentDetailPage />} />
                    <Route path="/calibration/schedule" element={<CalibrationScheduleListPage />} />
                    <Route path="*" element={<NotFoundPage />} />
                </Routes>
            </Suspense>
        </TranslationProvider>
    );
};

export default Router;
