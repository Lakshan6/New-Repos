/**
 * @file calibrationConstants.js
 * @description Endpoint paths, option lists and status→severity maps for the
 * Calibration Management screens (erp-qm-service, QM-CAL-001..008/CAL-004).
 * Centralised here so screens never hardcode path strings or status colours.
 */
import { getUserDetails, getUserRole } from '@shared/utils';

/* ─────────────────────────────────────────────────────────────────────────
   ENDPOINTS — must match erp-qm-service's controllers exactly.
───────────────────────────────────────────────────────────────────────── */
export const CALIBRATION_ENDPOINTS = {
    EQUIPMENT: '/api/v1/equipment',
    EQUIPMENT_BY_ID: (equipmentId) => `/api/v1/equipment/${equipmentId}`,
    EQUIPMENT_APPROVE: (equipmentId) => `/api/v1/equipment/${equipmentId}/approve`,
    EQUIPMENT_ACTIVATE: (equipmentId) => `/api/v1/equipment/${equipmentId}/activate`,

    CALIBRATION_PLAN: (equipmentId) => `/api/v1/equipment/${equipmentId}/calibration-plan`,
    CALIBRATION_PLAN_APPROVE: (equipmentId) =>
        `/api/v1/equipment/${equipmentId}/calibration-plan/approve`,

    CALIBRATION_RECORDS: (equipmentId) => `/api/v1/equipment/${equipmentId}/calibration-records`,

    SCHEDULE_GENERATE: '/api/v1/calibration-schedule/generate',
    SCHEDULE_LIST: '/api/v1/calibration-schedule',
    SCHEDULE_ASSIGN: (scheduleId) => `/api/v1/calibration-schedule/${scheduleId}/assign`,
};

/* ─────────────────────────────────────────────────────────────────────────
   OPTION LISTS — mirror the backend enums exactly (org.bel.qm.entity.*).
───────────────────────────────────────────────────────────────────────── */
export const EQUIPMENT_STATUS_OPTIONS = [
    { label: 'Due', value: 'DUE' },
    { label: 'Overdue', value: 'OVERDUE' },
    { label: 'Blocked', value: 'BLOCKED' },
    { label: 'In Calibration', value: 'IN_CALIBRATION' },
    { label: 'Active', value: 'ACTIVE' },
    { label: 'Retired', value: 'RETIRED' },
];

export const EQUIPMENT_STATUS_SEVERITY = {
    DUE: 'warning',
    OVERDUE: 'danger',
    BLOCKED: 'danger',
    IN_CALIBRATION: 'info',
    ACTIVE: 'success',
    RETIRED: 'secondary',
};

export const CRITICALITY_OPTIONS = [
    { label: 'Critical', value: 'CRITICAL' },
    { label: 'Non-Critical', value: 'NON_CRITICAL' },
];

export const CRITICALITY_SEVERITY = {
    CRITICAL: 'danger',
    NON_CRITICAL: 'secondary',
};

export const SCHEDULE_STATUS_SEVERITY = {
    SCHEDULED: 'info',
    ASSIGNED: 'info',
    IN_PROGRESS: 'warning',
    COMPLETED: 'success',
    CANCELLED: 'secondary',
};

export const RESULT_STATUS_SEVERITY = {
    PASS: 'success',
    FAIL: 'danger',
    CONDITIONAL: 'warning',
    OUT_OF_TOLERANCE: 'danger',
};

/* ─────────────────────────────────────────────────────────────────────────
   AUTH HEADERS
   ─────────────────────────────────────────────────────────────────────────
   erp-qm-service's RBAC (QM-CAL-018) reads X-User-Id / X-User-Role directly
   (see its README) rather than validating the JWT itself — it expects a
   gateway to have already authenticated the request and forwarded these.
   We send them from what the platform already has client-side as a
   pragmatic bridge, but:

   getUserRole() returns EVERY role the user holds across tenants; there is
   no guarantee any of them match erp-qm-service's UserRole enum values
   (QA_MANAGER, CALIBRATION_TECHNICIAN, LAB_MANAGER, ASSET_MANAGER, ...).
   Only Equipment.activate and CalibrationPlan.approve are role-guarded in
   this first UI pass — if role names don't line up, those two actions will
   403 even for a legitimate user until tenant/role config (or a gateway
   claim-mapping step) assigns them a matching role name.
───────────────────────────────────────────────────────────────────────── */
export function useCalibrationHeaders(authToken) {
    const userDetails = getUserDetails();
    const roles = getUserRole();
    return {
        Authorization: `Bearer ${authToken}`,
        'X-User-Id': userDetails?.username || '',
        'X-User-Role': roles?.[0] || '',
    };
}
