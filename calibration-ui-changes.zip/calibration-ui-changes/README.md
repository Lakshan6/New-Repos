# Calibration Management UI — integration package

Adds the first UI slice for erp-qm-service (QM-CAL-001–004, 007–008) into the
existing `qm` frontend module, alongside its Material/Inspection Plan/Master
Insp Char screens. Same scope as the backend's first phase — Repairs, OOT,
Certificates, Reference Standards, External Service, Labels, Conditional Use,
RBAC admin, Reporting, and Audit trail screens aren't built yet.

## Files — 4 modified, 5 added

**Modified** (apply as diffs/replacements against your working tree):
- `.env.local`, `.env.production` — new `VITE_ERP_QM_SERVICE_URL` /
  `VITE_ERP_QM_SERVICE_CONTEXT_URL` env vars.
- `src/shared/utils/apiRequest.js` — registers a new `calibration` service
  key (erp-qm-service is a separate microservice from the existing `qms`
  key, which is your other, pre-existing Inspection Planning backend).
- `src/modules/qm/routes/Router.jsx` — three new lazy routes.

**Added:**
- `src/modules/qm/utils/calibrationConstants.js` — endpoint paths, status
  option/severity maps, auth-header helper.
- `src/modules/qm/screens/Calibration/EquipmentListPage.jsx` — register,
  list, approve, activate (CAL-001/002). Route: `/calibration/equipment`.
- `src/modules/qm/screens/Calibration/EquipmentDetailPage.jsx` — equipment
  info + calibration plan (create/update/approve, CAL-003) + records history
  (CAL-007/008). Route: `/calibration/equipment/:equipmentId`.
- `src/modules/qm/screens/Calibration/CalibrationRecordDialog.jsx` — submit
  calibration results with dynamic test-point rows (CAL-007/008).
- `src/modules/qm/screens/Calibration/CalibrationScheduleListPage.jsx` — the
  due/overdue worklist, generate + assign (CAL-004). Route:
  `/calibration/schedule`.

## To apply

Drop these into the matching paths in your actual `pf-ui` tree, overwriting
`apiRequest.js`, `Router.jsx`, `.env.local` and `.env.production` (they're
small, targeted diffs — everything else in those files is untouched), and
adding the five new files as-is.

## Three things that need a decision from you before this is production-ready

1. **Local dev port (`.env.local`)** — I set `VITE_ERP_QM_SERVICE_URL=
   http://localhost:8090`. erp-qm-service's own `application.yml` (from the
   backend build) currently says port 8086 — which collides with `am`
   (Asset Management) in this UI's `.env.local`. Pick one and make both
   sides agree; I used 8090 as a placeholder on the UI side rather than
   silently "fixing" your backend config.

2. **RBAC header bridging** — erp-qm-service's `@RequiresRole` guards (only
   `Equipment.activate` and `CalibrationPlan.approve` in this slice) read
   `X-User-Id` / `X-User-Role` headers directly rather than validating the
   JWT itself. `calibrationConstants.js`'s `useCalibrationHeaders()` sends
   `X-User-Id` from `getUserDetails().username` and `X-User-Role` from the
   first entry of `getUserRole()` — but nothing guarantees your platform's
   role names match erp-qm-service's `UserRole` enum values (`QA_MANAGER`,
   `LAB_MANAGER`, `ASSET_MANAGER`, ...). Until tenant/role config (or a
   gateway claim-mapping step) assigns matching role names, Approve Plan and
   Activate will 403 for otherwise-legitimate users. This is flagged with a
   comment in the code; it's a platform-role-naming decision, not something
   I could resolve from the frontend alone.

3. **Reference Standard entry is free text** — `CalibrationRecordDialog`'s
   "Reference Standard ID" field is a plain text input, not a picker,
   because there's no Reference Standards register/browse screen in this
   pass (the backend for QM-CAL-013 exists; its UI doesn't yet). The
   technician has to already know the standard's business key. Worth
   building a proper picker once Reference Standards get a UI.

## Notes on how I fit this into your existing patterns

- Built on your `ListPage` / `AppDataTable` / `FilterToolbar` / `FormDialog`
  / `FormGroup` + `Controlled*` shared component library and `useReadApi`
  / `useMutationApi` hooks — I didn't introduce a new data-fetching or form
  pattern.
- `useMutationApi`'s `endpoint` is fixed at hook-creation time, which
  doesn't work for per-row actions with a row-specific URL (e.g. "Approve"
  on an arbitrary equipment row). Those call `apiRequest()` directly instead
  — see `runRowAction` in `EquipmentListPage.jsx`.
- All dates go through `toLocalDateString`/`formatDisplayDate` from
  `@shared/utils/dateUtils.js`, never `toISOString()` (that file documents
  why — the raw ISO conversion shifts the date near midnight in most
  non-UTC timezones).
- I placed the new screens under `src/modules/qm/screens/Calibration/`
  (a subfolder) rather than flat alongside `MaterialScreen.jsx` etc. — most
  of this codebase keeps screens flat, but the `am` module already
  precedents subfolders per feature area (`screens/Equipment/`,
  `screens/Asset Management/`), and grouping 4 calibration-specific files
  together seemed clearer than mixing them into the existing flat list.
- No sidebar/menu file needed editing — this app's menu items come from
  `LandingContext`/`vmenu`, populated by a backend call, not a static
  frontend config. Whoever owns that menu config will need to add entries
  pointing at `/calibration/equipment` and `/calibration/schedule` for users
  to reach these screens by clicking around; until then they're reachable by
  direct URL.
