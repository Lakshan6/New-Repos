import { useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';

import { ListPage, AppDataTable, mutedDash, statusCell, dateCell } from '@shared/components';
import { useT, useSafeContext, useReadApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import {
    CALIBRATION_ENDPOINTS,
    RESULT_STATUS_SEVERITY,
    useCalibrationHeaders,
} from '../../utils/calibrationConstants';
import CalibrationRecordDialog from './CalibrationRecordDialog';

const calDateBody = dateCell('calibrationDate');
const resultStatusBody = statusCell('resultStatus', RESULT_STATUS_SEVERITY);

/**
 * QM-CAL-007 / QM-CAL-008 — calibration records and submission, as its own
 * menu entry. Pick an equipment to see its calibration history and submit a
 * new calibration (needs an approved calibration plan).
 * Deep link: /calibration/records?equipment=<equipmentId>
 */
const CalibrationRecordsPage = () => {
    const { t } = useT();
    const { authToken } = useSafeContext(AuthContext);
    const headers = useCalibrationHeaders(authToken);
    const [searchParams] = useSearchParams();

    const [equipmentId, setEquipmentId] = useState(searchParams.get('equipment') || null);
    const [showSubmit, setShowSubmit] = useState(false);

    const { data: equipmentData, isLoading: equipmentLoading } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT,
        headers,
    });

    const equipmentOptions = useMemo(() => {
        const list = Array.isArray(equipmentData) ? equipmentData : equipmentData?.content || [];
        return list.map((e) => ({
            label: e.name ? `${e.equipmentId} — ${e.name}` : e.equipmentId,
            value: e.equipmentId,
        }));
    }, [equipmentData]);

    const {
        data: records,
        isLoading: recordsLoading,
        refetch: refetchRecords,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_RECORDS(equipmentId),
        headers,
        options: { enabled: !!equipmentId },
    });

    const { data: plan, isError: planMissing } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN(equipmentId),
        headers,
        options: { enabled: !!equipmentId, retry: false },
    });

    const canSubmit = !!equipmentId && !!plan?.approved;
    let submitHint;
    if (!equipmentId) submitHint = 'Select an equipment first';
    else if (planMissing || !plan) submitHint = 'This equipment has no calibration plan yet';
    else if (!plan.approved) submitHint = 'The calibration plan must be approved first';

    return (
        <ListPage
            title={t('CALIBRATION_RECORDS', { fallbackText: 'Calibration Records' })}
            subtitle="Submit calibration results and review calibration history per equipment."
            actions={
                <span title={submitHint}>
                    <Button
                        label="Submit Calibration"
                        icon="pi pi-plus"
                        disabled={!canSubmit}
                        onClick={() => setShowSubmit(true)}
                    />
                </span>
            }
            toolbar={
                <div className="flex align-items-center gap-2">
                    <span className="text-sm">Equipment</span>
                    <Dropdown
                        value={equipmentId}
                        options={equipmentOptions}
                        onChange={(e) => setEquipmentId(e.value)}
                        placeholder="Select equipment"
                        filter
                        loading={equipmentLoading}
                        className="w-20rem"
                    />
                </div>
            }
        >
            <AppDataTable
                value={equipmentId && Array.isArray(records) ? records : []}
                loading={!!equipmentId && recordsLoading}
                dataKey="id"
                emptyMessage={equipmentId ? 'No calibration records yet.' : 'Select an equipment to see its records.'}
            >
                <Column header="Date" body={calDateBody} />
                <Column field="technician" header="Technician" />
                <Column field="method" header="Method" />
                <Column field="referenceStandardId" header="Reference Standard" body={(r) => r.referenceStandardId || mutedDash()} />
                <Column header="Result" body={resultStatusBody} />
                <Column field="submittedBy" header="Submitted By" />
                <Column header="Remarks" body={(r) => r.remarks || mutedDash()} />
            </AppDataTable>

            {showSubmit && (
                <CalibrationRecordDialog
                    equipmentId={equipmentId}
                    headers={headers}
                    onHide={() => setShowSubmit(false)}
                    onSuccess={() => {
                        setShowSubmit(false);
                        refetchRecords();
                    }}
                />
            )}
        </ListPage>
    );
};

export default CalibrationRecordsPage;
