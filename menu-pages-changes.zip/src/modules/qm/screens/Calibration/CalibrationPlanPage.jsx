import { useCallback, useMemo, useState } from 'react';
import { useSearchParams } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { Tag } from 'primereact/tag';
import { useForm } from 'react-hook-form';

import {
    ListPage,
    Card,
    FormDialog,
    FormGroup,
    ReadOnlyField,
    ControlledInputText,
    ControlledInputNumber,
    ControlledCalendar,
    useAppToast,
    mutedDash,
} from '@shared/components';
import { useT, useSafeContext, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { toLocalDateString } from '@shared/utils/dateUtils';
import { CALIBRATION_ENDPOINTS, useCalibrationHeaders } from '../../utils/calibrationConstants';

const PLAN_DEFAULT_VALUES = {
    calibrationIntervalDays: null,
    calibrationMethod: '',
    toleranceLower: null,
    toleranceUpper: null,
    uom: '',
    serviceProvider: '',
    lastCalibrationDate: null,
};

/**
 * QM-CAL-003 — calibration plan (create / edit / approve) as its own menu
 * entry. Pick an equipment, then create or edit its plan. A plan takes effect
 * only after approval by someone other than the submitter.
 * Deep link: /calibration/plans?equipment=<equipmentId>
 */
const CalibrationPlanPage = () => {
    const { t } = useT();
    const { authToken } = useSafeContext(AuthContext);
    const headers = useCalibrationHeaders(authToken);
    const toast = useAppToast();
    const [searchParams] = useSearchParams();

    const [equipmentId, setEquipmentId] = useState(searchParams.get('equipment') || null);
    const [showPlanDialog, setShowPlanDialog] = useState(false);

    const { data: equipmentData, isLoading: equipmentLoading } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT,
        headers,
    });

    const equipmentOptions = useMemo(() => {
        const list = Array.isArray(equipmentData) ? equipmentData : equipmentData?.content || [];
        return list.map((e) => ({
            label: e.name ? `${e.equipmentId} — ${e.name}` : e.equipmentId,
            value: e.equipmentId,
        }));
    }, [equipmentData]);

    const {
        data: plan,
        isError: planMissing,
        refetch: refetchPlan,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN(equipmentId),
        headers,
        options: { enabled: !!equipmentId, retry: false },
    });

    const { control, handleSubmit, reset } = useForm({ defaultValues: PLAN_DEFAULT_VALUES });

    const planMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN(equipmentId),
        method: 'PUT',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Calibration plan saved — approval is required before it takes effect.');
                setShowPlanDialog(false);
                refetchPlan();
            },
            onError: (err) => toast.apiError(err, 'Could not save calibration plan.'),
        },
    });

    const approvePlanMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN_APPROVE(equipmentId),
        method: 'POST',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Calibration plan approved.');
                refetchPlan();
            },
            onError: (err) => toast.apiError(err, 'Could not approve calibration plan — check your role.'),
        },
    });

    const openPlanDialog = useCallback(() => {
        if (plan) {
            reset({
                calibrationIntervalDays: plan.calibrationIntervalDays,
                calibrationMethod: plan.calibrationMethod,
                toleranceLower: plan.toleranceLower,
                toleranceUpper: plan.toleranceUpper,
                uom: plan.uom,
                serviceProvider: plan.serviceProvider,
                lastCalibrationDate: plan.lastCalibrationDate ?? null,
            });
        } else {
            reset(PLAN_DEFAULT_VALUES);
        }
        setShowPlanDialog(true);
    }, [plan, reset]);

    const hidePlanDialog = useCallback(() => setShowPlanDialog(false), []);

    const submitPlan = useCallback(
        (values) => {
            planMutation.mutate({
                ...values,
                lastCalibrationDate: values.lastCalibrationDate ? toLocalDateString(values.lastCalibrationDate) : null,
            });
        },
        [planMutation],
    );

    const hasPlan = !!equipmentId && !planMissing && !!plan;

    return (
        <ListPage
            title={t('CALIBRATION_PLAN', { fallbackText: 'Calibration Plan' })}
            subtitle="Set the calibration interval, method and tolerance for an equipment, then approve it."
            toolbar={
                <div className="flex align-items-center gap-2">
                    <span className="text-sm">Equipment</span>
                    <Dropdown
                        value={equipmentId}
                        options={equipmentOptions}
                        onChange={(e) => setEquipmentId(e.value)}
                        placeholder="Select equipment"
                        filter
                        loading={equipmentLoading}
                        className="w-20rem"
                    />
                </div>
            }
        >
            {!equipmentId ? (
                <p className="text-color-secondary m-0">Select an equipment to view or set its calibration plan.</p>
            ) : (
                <Card
                    title={t('CALIBRATION_PLAN', { fallbackText: 'Calibration Plan' })}
                    header={
                        <div className="flex gap-2">
                            <Button label={hasPlan ? 'Edit Plan' : 'Create Plan'} icon="pi pi-pencil" text onClick={openPlanDialog} />
                            {hasPlan && !plan.approved && (
                                <Button
                                    label="Approve Plan"
                                    icon="pi pi-check"
                                    text
                                    onClick={() => approvePlanMutation.mutate()}
                                    loading={approvePlanMutation.isPending}
                                />
                            )}
                        </div>
                    }
                >
                    {!hasPlan ? (
                        <p className="text-color-secondary m-0">No calibration plan configured yet.</p>
                    ) : (
                        <div className="grid">
                            <div className="col-3"><ReadOnlyField label="Interval (days)" value={String(plan.calibrationIntervalDays)} /></div>
                            <div className="col-3"><ReadOnlyField label="Method" value={plan.calibrationMethod} /></div>
                            <div className="col-3"><ReadOnlyField label="Tolerance" value={`${plan.toleranceLower} – ${plan.toleranceUpper} ${plan.uom || ''}`} /></div>
                            <div className="col-3"><ReadOnlyField label="Service Provider" value={plan.serviceProvider} /></div>
                            <div className="col-3"><ReadOnlyField label="Last Calibration" value={plan.lastCalibrationDate || mutedDash()} /></div>
                            <div className="col-3"><ReadOnlyField label="Next Due" value={plan.nextDueDate || mutedDash()} /></div>
                            <div className="col-3">
                                <FormGroup label="Approved">
                                    <Tag value={plan.approved ? 'Approved' : 'Pending Approval'} severity={plan.approved ? 'success' : 'warning'} />
                                </FormGroup>
                            </div>
                        </div>
                    )}
                </Card>
            )}

            {showPlanDialog && (
                <FormDialog
                    header={hasPlan ? 'Edit Calibration Plan' : 'Create Calibration Plan'}
                    size="md"
                    onHide={hidePlanDialog}
                    onSubmit={handleSubmit(submitPlan)}
                    submitLabel="Save"
                    busy={planMutation.isPending}
                >
                    <div className="grid formgrid">
                        <div className="col-6">
                            <FormGroup htmlFor="cp-interval" label="Interval (days)" required>
                                <ControlledInputNumber
                                    name="calibrationIntervalDays"
                                    control={control}
                                    inputId="cp-interval"
                                    min={1}
                                    rules={{ required: 'Interval is required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cp-method" label="Method" required>
                                <ControlledInputText name="calibrationMethod" control={control} inputId="cp-method" rules={{ required: 'Method is required' }} />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cp-tol-lower" label="Tolerance Lower" required>
                                <ControlledInputNumber
                                    name="toleranceLower"
                                    control={control}
                                    inputId="cp-tol-lower"
                                    mode="decimal"
                                    maxFractionDigits={4}
                                    rules={{ required: 'Required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cp-tol-upper" label="Tolerance Upper" required>
                                <ControlledInputNumber
                                    name="toleranceUpper"
                                    control={control}
                                    inputId="cp-tol-upper"
                                    mode="decimal"
                                    maxFractionDigits={4}
                                    rules={{ required: 'Required' }}
                                />
                            </FormGroup>
                        </div>
                        <div className="col-4">
                            <FormGroup htmlFor="cp-uom" label="Unit">
                                <ControlledInputText name="uom" control={control} inputId="cp-uom" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cp-provider" label="Service Provider">
                                <ControlledInputText name="serviceProvider" control={control} inputId="cp-provider" />
                            </FormGroup>
                        </div>
                        <div className="col-6">
                            <FormGroup htmlFor="cp-last-cal" label="Last Calibration Date">
                                <ControlledCalendar name="lastCalibrationDate" control={control} inputId="cp-last-cal" showIcon />
                            </FormGroup>
                        </div>
                    </div>
                </FormDialog>
            )}
        </ListPage>
    );
};

export default CalibrationPlanPage;
