import { useCallback, useState } from 'react';
import { useParams } from 'react-router-dom';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { TabView, TabPanel } from 'primereact/tabview';

import {
    PageLayout,
    Card,
    ReadOnlyField,
    useAppToast,
} from '@shared/components';
import { useT, useSafeContext, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import {
    CALIBRATION_ENDPOINTS,
    EQUIPMENT_STATUS_SEVERITY,
    CRITICALITY_SEVERITY,
    useCalibrationHeaders,
} from '../../utils/calibrationConstants';
import ActionDialog from './components/ActionDialog';
import RepairsTab from './tabs/RepairsTab';
import OotTab from './tabs/OotTab';
import CertificatesTab from './tabs/CertificatesTab';
import ExternalServiceTab from './tabs/ExternalServiceTab';
import LabelsTab from './tabs/LabelsTab';
import ConditionalUseTab from './tabs/ConditionalUseTab';
import TransfersTab from './tabs/TransfersTab';
import AuditTab from './tabs/AuditTab';

const RETIRE_FIELDS = [
    { name: 'retirementDate', label: 'Retirement Date', type: 'date', required: true, width: 12 },
    { name: 'disposalDetails', label: 'Disposal Details', type: 'textarea', required: true },
];

/**
 * Equipment detail — QM-CAL-001/002 info plus the per-equipment tabs.
 * Calibration plan and calibration records/submission have their own menu pages.
 */
const EquipmentDetailPage = () => {
    const { t } = useT();
    const { equipmentId } = useParams();
    const { authToken } = useSafeContext(AuthContext);
    const toast = useAppToast();
    const headers = useCalibrationHeaders(authToken);

    const [showRetireDialog, setShowRetireDialog] = useState(false);

    const {
        data: equipment,
        isLoading: equipmentLoading,
        refetch: refetchEquipment,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT_BY_ID(equipmentId),
        headers,
    });

    const {
        data: plan,
        refetch: refetchPlan,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_PLAN(equipmentId),
        headers,
        options: { retry: false },
    });

    const {
        data: records,
        refetch: refetchRecords,
    } = useReadApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.CALIBRATION_RECORDS(equipmentId),
        headers,
    });

    const activateMutation = useMutationApi({
        service: 'calibration',
        endpoint: CALIBRATION_ENDPOINTS.EQUIPMENT_ACTIVATE(equipmentId),
        method: 'POST',
        headers,
        options: {
            onSuccess: () => {
                toast.success('Success', 'Equipment activated.');
                refetchEquipment();
            },
            onError: (err) => toast.apiError(err, 'Could not activate equipment — check your role or approval status.'),
        },
    });

    /** Tabs call this after any change that can alter the equipment's status or history. */
    const refreshAll = useCallback(() => {
        refetchEquipment();
        refetchRecords();
        refetchPlan();
    }, [refetchEquipment, refetchRecords, refetchPlan]);

    if (equipmentLoading || !equipment) {
        return <div className="p-4 text-center">Loading…</div>;
    }

    return (
        <PageLayout>
            <PageLayout.Header
                title={equipment.name}
                subtitle={`${equipment.equipmentId} · ${equipment.type}`}
                backButton
                status={
                    <>
                        {equipment.status && <Tag value={equipment.status} severity={EQUIPMENT_STATUS_SEVERITY[equipment.status] ?? 'info'} />}
                        {equipment.criticality && (
                            <Tag className="ml-2" value={equipment.criticality} severity={CRITICALITY_SEVERITY[equipment.criticality] ?? 'info'} />
                        )}
                    </>
                }
                actions={
                    <div className="flex gap-2">
                        {!equipment.active && equipment.approved && (
                            <Button label="Activate" icon="pi pi-bolt" onClick={() => activateMutation.mutate()} loading={activateMutation.isPending} />
                        )}
                        {equipment.status !== 'RETIRED' && (
                            <Button label="Retire" icon="pi pi-ban" severity="danger" outlined onClick={() => setShowRetireDialog(true)} />
                        )}
                    </div>
                }
            />

            <PageLayout.Content>
                <Card title={t('EQUIPMENT_DETAILS', { fallbackText: 'Equipment Details' })}>
                    <div className="grid">
                        <div className="col-3"><ReadOnlyField label="Manufacturer" value={equipment.manufacturer} /></div>
                        <div className="col-3"><ReadOnlyField label="Model" value={equipment.model} /></div>
                        <div className="col-3"><ReadOnlyField label="Serial Number" value={equipment.serialNumber} /></div>
                        <div className="col-3"><ReadOnlyField label="Asset Tag" value={equipment.assetTag} /></div>
                        <div className="col-3"><ReadOnlyField label="Location" value={equipment.location} /></div>
                        <div className="col-3"><ReadOnlyField label="Owner" value={equipment.owner} /></div>
                        <div className="col-3"><ReadOnlyField label="Category" value={equipment.category} /></div>
                        <div className="col-3"><ReadOnlyField label="Measurement Range" value={equipment.measurementRange} /></div>
                        <div className="col-3"><ReadOnlyField label="Accuracy" value={equipment.accuracy} /></div>
                        <div className="col-3"><ReadOnlyField label="Resolution" value={equipment.resolution} /></div>
                        <div className="col-6"><ReadOnlyField label="Intended Use" value={equipment.intendedUse} /></div>
                    </div>
                </Card>

                <Card>
                    <TabView>
                        <TabPanel header="Certificates">
                            <CertificatesTab
                                equipmentId={equipmentId}
                                serialNumber={equipment.serialNumber}
                                headers={headers}
                                records={records}
                                onChanged={refreshAll}
                            />
                        </TabPanel>
                        <TabPanel header="Repairs">
                            <RepairsTab equipmentId={equipmentId} headers={headers} onChanged={refreshAll} />
                        </TabPanel>
                        <TabPanel header="OOT & Holds">
                            <OotTab equipmentId={equipmentId} headers={headers} records={records} onChanged={refreshAll} />
                        </TabPanel>
                        <TabPanel header="External Service">
                            <ExternalServiceTab equipmentId={equipmentId} headers={headers} onChanged={refreshAll} />
                        </TabPanel>
                        <TabPanel header="Labels">
                            <LabelsTab equipmentId={equipmentId} headers={headers} />
                        </TabPanel>
                        <TabPanel header="Conditional Use">
                            <ConditionalUseTab equipmentId={equipmentId} headers={headers} onChanged={refreshAll} />
                        </TabPanel>
                        <TabPanel header="Transfers">
                            <TransfersTab equipmentId={equipmentId} headers={headers} onChanged={refreshAll} />
                        </TabPanel>
                        <TabPanel header="Audit History">
                            <AuditTab equipmentId={equipmentId} headers={headers} plan={plan} records={records} />
                        </TabPanel>
                    </TabView>
                </Card>
            </PageLayout.Content>

            {showRetireDialog && (
                <ActionDialog
                    header="Retire Equipment"
                    fields={RETIRE_FIELDS}
                    endpoint={CALIBRATION_ENDPOINTS.EQUIPMENT_RETIRE(equipmentId)}
                    headers={headers}
                    submitLabel="Retire"
                    successMessage="Equipment retired."
                    failureMessage="Could not retire equipment — Asset Manager or QA Manager role is required."
                    onHide={() => setShowRetireDialog(false)}
                    onSuccess={() => {
                        setShowRetireDialog(false);
                        refreshAll();
                    }}
                />
            )}
        </PageLayout>
    );
};

export default EquipmentDetailPage;
