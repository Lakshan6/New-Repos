package org.bel.qm;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@EnableScheduling
public class QmServiceApplication {

    public static void main(String[] args) {
        SpringApplication.run(QmServiceApplication.class, args);
    }
}
