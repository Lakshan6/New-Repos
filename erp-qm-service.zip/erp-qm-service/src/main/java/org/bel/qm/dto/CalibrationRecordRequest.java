package org.bel.qm.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;
import java.util.List;

/** QM-CAL-007: submission of a calibration execution event. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationRecordRequest {

    /** Optional - links this execution back to the worklist item it fulfils. */
    private Long scheduleId;

    @NotNull
    private LocalDate calibrationDate;

    @NotBlank
    private String technician;

    @NotBlank
    private String method;

    @NotBlank
    private String referenceStandard;

    @NotBlank
    private String submittedBy;

    private String remarks;

    @NotEmpty
    private List<@Valid TestResultRequest> testResults;
}
