package org.bel.qm.entity;

/** QM-CAL-004: status of a generated calibration worklist item. */
public enum ScheduleStatus {
    SCHEDULED,
    ASSIGNED,
    IN_PROGRESS,
    COMPLETED,
    CANCELLED
}
