package org.bel.qm.repository;

import org.bel.qm.entity.CalibrationRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface CalibrationRecordRepository extends JpaRepository<CalibrationRecord, Long> {

    List<CalibrationRecord> findByEquipment_EquipmentIdOrderByCalibrationDateDesc(String equipmentId);
}
