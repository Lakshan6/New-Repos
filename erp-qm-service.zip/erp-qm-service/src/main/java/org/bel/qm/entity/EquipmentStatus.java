package org.bel.qm.entity;

/** QM-CAL-006: automatically-managed equipment usage status. */
public enum EquipmentStatus {
    DUE,
    OVERDUE,
    BLOCKED,
    IN_CALIBRATION,
    ACTIVE,
    RETIRED
}
