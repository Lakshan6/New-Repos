package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.ScheduleStatus;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationScheduleResponse {
    private Long id;
    private String equipmentId;
    private String equipmentName;
    private LocalDate dueDate;
    private String assignedTechnician;
    private String location;
    private ScheduleStatus status;
}
