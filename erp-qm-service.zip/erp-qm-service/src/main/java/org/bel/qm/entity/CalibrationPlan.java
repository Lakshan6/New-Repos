package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

/**
 * QM-CAL-003: the current calibration plan for one piece of equipment -
 * interval, method, tolerance, provider and the calculated next-due-date.
 * One active plan per equipment; approving a new plan supersedes the old one.
 */
@Entity
@Table(name = "calibration_plan", uniqueConstraints = {
        @UniqueConstraint(name = "uk_plan_equipment", columnNames = "equipment_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationPlan {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    @Column(name = "calibration_interval_days", nullable = false)
    private Integer calibrationIntervalDays;

    @Column(name = "calibration_method", nullable = false, length = 200)
    private String calibrationMethod;

    @Column(name = "tolerance_lower", nullable = false)
    private Double toleranceLower;

    @Column(name = "tolerance_upper", nullable = false)
    private Double toleranceUpper;

    @Column(length = 30)
    private String uom;

    @Column(name = "service_provider", length = 200)
    private String serviceProvider;

    @Column(name = "last_calibration_date")
    private LocalDate lastCalibrationDate;

    @Column(name = "next_due_date", nullable = false)
    private LocalDate nextDueDate;

    @Column(nullable = false)
    private boolean approved;

    @Column(nullable = false)
    private boolean active;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
