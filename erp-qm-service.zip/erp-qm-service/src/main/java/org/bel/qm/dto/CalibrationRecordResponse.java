package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.CalibrationResultStatus;

import java.time.Instant;
import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationRecordResponse {
    private Long id;
    private String equipmentId;
    private LocalDate calibrationDate;
    private String technician;
    private String method;
    private String referenceStandard;
    private CalibrationResultStatus resultStatus;
    private String remarks;
    private String submittedBy;
    private Instant submittedAt;
    private List<TestResultResponse> testResults;
}
