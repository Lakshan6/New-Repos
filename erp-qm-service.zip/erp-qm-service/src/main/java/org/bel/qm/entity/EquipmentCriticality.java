package org.bel.qm.entity;

/** QM-CAL-002: quality-impact classification of a measuring equipment. */
public enum EquipmentCriticality {
    CRITICAL,
    NON_CRITICAL
}
