package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * QM-CAL-007: one calibration execution event - who, when, with what method
 * and reference standard, and its as-found/as-left test results.
 * QM-CAL-008: resultStatus is derived from comparing those results to the
 * plan's approved tolerance.
 */
@Entity
@Table(name = "calibration_record")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    /** Optional link back to the worklist item that triggered this calibration. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "calibration_schedule_id")
    private CalibrationSchedule schedule;

    @Column(name = "calibration_date", nullable = false)
    private LocalDate calibrationDate;

    @Column(nullable = false, length = 150)
    private String technician;

    @Column(nullable = false, length = 200)
    private String method;

    @Column(name = "reference_standard", nullable = false, length = 200)
    private String referenceStandard;

    @Enumerated(EnumType.STRING)
    @Column(name = "result_status", nullable = false, length = 20)
    private CalibrationResultStatus resultStatus;

    @Column(length = 1000)
    private String remarks;

    @Column(name = "submitted_by", nullable = false, length = 150)
    private String submittedBy;

    @Column(name = "submitted_at", nullable = false)
    private Instant submittedAt;

    @Builder.Default
    @OneToMany(mappedBy = "calibrationRecord", cascade = CascadeType.ALL, orphanRemoval = true)
    private List<CalibrationTestResult> testResults = new ArrayList<>();

    public void addTestResult(CalibrationTestResult result) {
        result.setCalibrationRecord(this);
        this.testResults.add(result);
    }

    @PrePersist
    void onCreate() {
        if (this.submittedAt == null) {
            this.submittedAt = Instant.now();
        }
    }
}
