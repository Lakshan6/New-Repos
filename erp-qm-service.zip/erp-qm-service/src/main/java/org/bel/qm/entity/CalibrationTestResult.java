package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * QM-CAL-008: a single measured test point within a calibration record,
 * compared against the plan's tolerance limits to produce a pass/fail.
 */
@Entity
@Table(name = "calibration_test_result")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationTestResult {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "calibration_record_id", nullable = false)
    private CalibrationRecord calibrationRecord;

    @Column(name = "parameter_name", nullable = false, length = 150)
    private String parameterName;

    @Column(length = 30)
    private String uom;

    @Column(name = "target_value")
    private Double targetValue;

    @Column(name = "tolerance_lower", nullable = false)
    private Double toleranceLower;

    @Column(name = "tolerance_upper", nullable = false)
    private Double toleranceUpper;

    @Column(name = "as_found_value", nullable = false)
    private Double asFoundValue;

    /** Null when no adjustment was needed / performed. */
    @Column(name = "as_left_value")
    private Double asLeftValue;

    @Enumerated(EnumType.STRING)
    @Column(name = "point_result_status", nullable = false, length = 10)
    private PointResultStatus pointResultStatus;
}
