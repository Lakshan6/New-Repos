package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationPlanRequest;
import org.bel.qm.dto.CalibrationPlanResponse;
import org.bel.qm.entity.CalibrationPlan;
import org.bel.qm.entity.Equipment;
import org.bel.qm.entity.EquipmentStatus;
import org.bel.qm.repository.CalibrationPlanRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;

/** QM-CAL-003: calibration plan lifecycle - configure, approve, calculate next due date. */
@Service
@RequiredArgsConstructor
public class CalibrationPlanService {

    private final CalibrationPlanRepository planRepository;
    private final EquipmentService equipmentService;

    @Transactional
    public CalibrationPlanResponse createOrUpdate(String equipmentId, CalibrationPlanRequest request) {
        Equipment equipment = equipmentService.getEntity(equipmentId);
        if (!equipment.isActive()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Equipment must be active before a calibration plan can be configured: " + equipmentId);
        }
        if (request.getToleranceLower() > request.getToleranceUpper()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "toleranceLower must not exceed toleranceUpper");
        }

        CalibrationPlan plan = planRepository.findByEquipment_EquipmentId(equipmentId)
                .orElseGet(() -> CalibrationPlan.builder().equipment(equipment).approved(false).active(false).build());

        plan.setCalibrationIntervalDays(request.getCalibrationIntervalDays());
        plan.setCalibrationMethod(request.getCalibrationMethod());
        plan.setToleranceLower(request.getToleranceLower());
        plan.setToleranceUpper(request.getToleranceUpper());
        plan.setUom(request.getUom());
        plan.setServiceProvider(request.getServiceProvider());
        plan.setLastCalibrationDate(request.getLastCalibrationDate());
        plan.setNextDueDate(calculateNextDueDate(request.getLastCalibrationDate(), request.getCalibrationIntervalDays()));
        // configuration changes require re-approval
        plan.setApproved(false);
        plan.setActive(false);

        return toResponse(planRepository.save(plan));
    }

    @Transactional
    public CalibrationPlanResponse approve(String equipmentId) {
        CalibrationPlan plan = getEntity(equipmentId);
        plan.setApproved(true);
        plan.setActive(true);

        Equipment equipment = plan.getEquipment();
        EquipmentStatus derived = plan.getNextDueDate().isBefore(LocalDate.now())
                ? EquipmentStatus.OVERDUE
                : EquipmentStatus.ACTIVE;
        equipmentService.updateStatus(equipment.getId(), derived);

        return toResponse(plan);
    }

    /** Recalculates and persists the next due date after a completed calibration (QM-CAL-007). */
    @Transactional
    public void recalculateAfterCalibration(String equipmentId, LocalDate calibrationDate) {
        CalibrationPlan plan = getEntity(equipmentId);
        plan.setLastCalibrationDate(calibrationDate);
        plan.setNextDueDate(calculateNextDueDate(calibrationDate, plan.getCalibrationIntervalDays()));
    }

    @Transactional(readOnly = true)
    public CalibrationPlanResponse getByEquipmentId(String equipmentId) {
        return toResponse(getEntity(equipmentId));
    }

    CalibrationPlan getEntity(String equipmentId) {
        return planRepository.findByEquipment_EquipmentId(equipmentId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No calibration plan configured for equipment: " + equipmentId));
    }

    static LocalDate calculateNextDueDate(LocalDate lastCalibrationDate, int intervalDays) {
        LocalDate base = lastCalibrationDate != null ? lastCalibrationDate : LocalDate.now();
        return base.plusDays(intervalDays);
    }

    private CalibrationPlanResponse toResponse(CalibrationPlan p) {
        return CalibrationPlanResponse.builder()
                .id(p.getId())
                .equipmentId(p.getEquipment().getEquipmentId())
                .calibrationIntervalDays(p.getCalibrationIntervalDays())
                .calibrationMethod(p.getCalibrationMethod())
                .toleranceLower(p.getToleranceLower())
                .toleranceUpper(p.getToleranceUpper())
                .uom(p.getUom())
                .serviceProvider(p.getServiceProvider())
                .lastCalibrationDate(p.getLastCalibrationDate())
                .nextDueDate(p.getNextDueDate())
                .approved(p.isApproved())
                .active(p.isActive())
                .build();
    }
}
