package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationPlanResponse {
    private Long id;
    private String equipmentId;
    private Integer calibrationIntervalDays;
    private String calibrationMethod;
    private Double toleranceLower;
    private Double toleranceUpper;
    private String uom;
    private String serviceProvider;
    private LocalDate lastCalibrationDate;
    private LocalDate nextDueDate;
    private boolean approved;
    private boolean active;
}
