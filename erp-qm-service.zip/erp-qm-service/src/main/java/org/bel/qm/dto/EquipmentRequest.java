package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.EquipmentCriticality;

/** QM-CAL-001 / QM-CAL-002 register + classification payload. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EquipmentRequest {

    @NotBlank
    private String equipmentId;

    @NotBlank
    private String name;

    @NotBlank
    private String type;

    private String manufacturer;
    private String model;

    @NotBlank
    private String serialNumber;

    private String assetTag;
    private String location;

    @NotBlank
    private String owner;

    private String category;

    @NotNull
    private EquipmentCriticality criticality;

    private String measurementRange;
    private String accuracy;
    private String resolution;
    private String intendedUse;
}
