package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.EquipmentRequest;
import org.bel.qm.dto.EquipmentResponse;
import org.bel.qm.entity.EquipmentStatus;
import org.bel.qm.service.EquipmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/equipment")
@RequiredArgsConstructor
public class EquipmentController {

    private final EquipmentService equipmentService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public EquipmentResponse register(@Valid @RequestBody EquipmentRequest request) {
        return equipmentService.register(request);
    }

    @PostMapping("/{equipmentId}/approve")
    public EquipmentResponse approve(@PathVariable String equipmentId) {
        return equipmentService.approve(equipmentId);
    }

    @PostMapping("/{equipmentId}/activate")
    public EquipmentResponse activate(@PathVariable String equipmentId) {
        return equipmentService.activate(equipmentId);
    }

    @GetMapping("/{equipmentId}")
    public EquipmentResponse get(@PathVariable String equipmentId) {
        return equipmentService.getByEquipmentId(equipmentId);
    }

    @GetMapping
    public List<EquipmentResponse> list(
            @RequestParam(required = false) EquipmentStatus status,
            @RequestParam(required = false) String type) {
        return equipmentService.list(status, type);
    }
}
