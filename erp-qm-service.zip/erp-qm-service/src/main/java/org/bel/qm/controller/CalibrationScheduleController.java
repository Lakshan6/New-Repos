package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.AssignTechnicianRequest;
import org.bel.qm.dto.CalibrationScheduleResponse;
import org.bel.qm.service.CalibrationScheduleService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/calibration-schedule")
@RequiredArgsConstructor
public class CalibrationScheduleController {

    private final CalibrationScheduleService scheduleService;

    /** On-demand trigger; the same logic also runs on a daily cron (QM-CAL-004). */
    @PostMapping("/generate")
    public List<CalibrationScheduleResponse> generate() {
        return scheduleService.generateWorklist();
    }

    @GetMapping
    public List<CalibrationScheduleResponse> listOpen() {
        return scheduleService.listOpen();
    }

    @PostMapping("/{scheduleId}/assign")
    public CalibrationScheduleResponse assign(@PathVariable Long scheduleId,
                                               @Valid @RequestBody AssignTechnicianRequest request) {
        return scheduleService.assignTechnician(scheduleId, request.getTechnician());
    }
}
