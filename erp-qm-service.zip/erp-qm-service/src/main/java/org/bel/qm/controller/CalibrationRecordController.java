package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationRecordRequest;
import org.bel.qm.dto.CalibrationRecordResponse;
import org.bel.qm.service.CalibrationRecordService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/equipment/{equipmentId}/calibration-records")
@RequiredArgsConstructor
public class CalibrationRecordController {

    private final CalibrationRecordService recordService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public CalibrationRecordResponse submit(@PathVariable String equipmentId,
                                             @Valid @RequestBody CalibrationRecordRequest request) {
        return recordService.submit(equipmentId, request);
    }

    @GetMapping
    public List<CalibrationRecordResponse> history(@PathVariable String equipmentId) {
        return recordService.history(equipmentId);
    }
}
