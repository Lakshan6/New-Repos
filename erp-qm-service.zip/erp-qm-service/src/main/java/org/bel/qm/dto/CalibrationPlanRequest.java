package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/** QM-CAL-003 calibration plan payload. Submitted against an existing, approved equipment. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationPlanRequest {

    @NotNull
    @Positive
    private Integer calibrationIntervalDays;

    @NotBlank
    private String calibrationMethod;

    @NotNull
    private Double toleranceLower;

    @NotNull
    private Double toleranceUpper;

    private String uom;
    private String serviceProvider;

    /** Optional - if omitted, next due date is calculated from today. */
    private LocalDate lastCalibrationDate;
}
