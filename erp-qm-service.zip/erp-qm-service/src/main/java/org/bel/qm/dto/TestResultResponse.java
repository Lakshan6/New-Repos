package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.PointResultStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestResultResponse {
    private String parameterName;
    private String uom;
    private Double targetValue;
    private Double toleranceLower;
    private Double toleranceUpper;
    private Double asFoundValue;
    private Double asLeftValue;
    private PointResultStatus pointResultStatus;
}
