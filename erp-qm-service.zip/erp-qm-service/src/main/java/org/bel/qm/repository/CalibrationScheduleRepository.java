package org.bel.qm.repository;

import org.bel.qm.entity.CalibrationSchedule;
import org.bel.qm.entity.ScheduleStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CalibrationScheduleRepository extends JpaRepository<CalibrationSchedule, Long> {

    List<CalibrationSchedule> findByStatusIn(List<ScheduleStatus> statuses);

    /** QM-CAL-004: prevents duplicate open worklist entries for the same equipment. */
    Optional<CalibrationSchedule> findFirstByEquipment_IdAndStatusIn(Long equipmentId, List<ScheduleStatus> openStatuses);

    List<CalibrationSchedule> findByEquipment_EquipmentId(String equipmentId);
}
