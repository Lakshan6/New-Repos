package org.bel.qm.repository;

import org.bel.qm.entity.CalibrationPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;
import java.util.Optional;

public interface CalibrationPlanRepository extends JpaRepository<CalibrationPlan, Long> {

    Optional<CalibrationPlan> findByEquipmentId(Long equipmentId);

    Optional<CalibrationPlan> findByEquipment_EquipmentId(String equipmentId);

    /** QM-CAL-004: active plans due for scheduling within the planning horizon. */
    List<CalibrationPlan> findByActiveTrueAndNextDueDateLessThanEqual(LocalDate horizonDate);
}
