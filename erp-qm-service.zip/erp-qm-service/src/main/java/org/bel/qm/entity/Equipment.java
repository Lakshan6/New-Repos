package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * QM-CAL-001 / QM-CAL-002: equipment register + classification.
 * One record per quality-critical measuring instrument, gauge, test device,
 * lab equipment or reference standard.
 */
@Entity
@Table(name = "equipment", uniqueConstraints = {
        @UniqueConstraint(name = "uk_equipment_equipment_id", columnNames = "equipment_id"),
        @UniqueConstraint(name = "uk_equipment_serial_number", columnNames = "serial_number")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Equipment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Business key, e.g. "GAUGE-0042". */
    @Column(name = "equipment_id", nullable = false, length = 64)
    private String equipmentId;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(nullable = false, length = 100)
    private String type;

    @Column(length = 150)
    private String manufacturer;

    @Column(length = 150)
    private String model;

    @Column(name = "serial_number", nullable = false, length = 100)
    private String serialNumber;

    @Column(name = "asset_tag", length = 100)
    private String assetTag;

    @Column(length = 200)
    private String location;

    @Column(nullable = false, length = 150)
    private String owner;

    // --- QM-CAL-002 classification fields ---
    @Column(length = 100)
    private String category;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 30)
    private EquipmentCriticality criticality;

    @Column(name = "measurement_range", length = 100)
    private String measurementRange;

    @Column(length = 100)
    private String accuracy;

    @Column(length = 100)
    private String resolution;

    @Column(name = "intended_use", length = 300)
    private String intendedUse;

    // --- lifecycle / workflow ---
    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private EquipmentStatus status;

    @Column(nullable = false)
    private boolean approved;

    @Column(nullable = false)
    private boolean active;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.status == null) {
            this.status = EquipmentStatus.DUE;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
