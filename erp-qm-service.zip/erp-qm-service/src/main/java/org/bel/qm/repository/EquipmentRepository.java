package org.bel.qm.repository;

import org.bel.qm.entity.Equipment;
import org.bel.qm.entity.EquipmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface EquipmentRepository extends JpaRepository<Equipment, Long> {

    Optional<Equipment> findByEquipmentId(String equipmentId);

    boolean existsByEquipmentId(String equipmentId);

    boolean existsBySerialNumber(String serialNumber);

    List<Equipment> findByStatus(EquipmentStatus status);

    List<Equipment> findByTypeIgnoreCase(String type);
}
