package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.EquipmentCriticality;
import org.bel.qm.entity.EquipmentStatus;

import java.time.Instant;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EquipmentResponse {
    private Long id;
    private String equipmentId;
    private String name;
    private String type;
    private String manufacturer;
    private String model;
    private String serialNumber;
    private String assetTag;
    private String location;
    private String owner;
    private String category;
    private EquipmentCriticality criticality;
    private String measurementRange;
    private String accuracy;
    private String resolution;
    private String intendedUse;
    private EquipmentStatus status;
    private boolean approved;
    private boolean active;
    private Instant createdAt;
    private Instant updatedAt;
}
