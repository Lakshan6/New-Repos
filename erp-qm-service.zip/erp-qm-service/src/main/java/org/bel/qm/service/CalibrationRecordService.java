package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationRecordRequest;
import org.bel.qm.dto.CalibrationRecordResponse;
import org.bel.qm.dto.TestResultRequest;
import org.bel.qm.dto.TestResultResponse;
import org.bel.qm.entity.*;
import org.bel.qm.repository.CalibrationRecordRepository;
import org.bel.qm.repository.CalibrationScheduleRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * QM-CAL-007: records calibration execution (as-found/as-left results).
 * QM-CAL-008: evaluates results against the approved plan's tolerance and
 * derives Pass/Fail/Out-of-Tolerance, then drives the equipment status update
 * (QM-CAL-006) equipment ends up ACTIVE on pass, BLOCKED on fail pending
 * repair/recalibration per QM-CAL-009.
 */
@Service
@RequiredArgsConstructor
public class CalibrationRecordService {

    private final CalibrationRecordRepository recordRepository;
    private final CalibrationScheduleRepository scheduleRepository;
    private final EquipmentService equipmentService;
    private final CalibrationPlanService planService;

    @Transactional
    public CalibrationRecordResponse submit(String equipmentId, CalibrationRecordRequest request) {
        Equipment equipment = equipmentService.getEntity(equipmentId);
        if (equipment.getStatus() == EquipmentStatus.RETIRED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Cannot calibrate retired equipment: " + equipmentId);
        }

        CalibrationPlan plan = planService.getEntity(equipmentId);
        if (!plan.isApproved()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "No approved calibration plan for equipment: " + equipmentId);
        }

        CalibrationRecord record = CalibrationRecord.builder()
                .equipment(equipment)
                .calibrationDate(request.getCalibrationDate())
                .technician(request.getTechnician())
                .method(request.getMethod())
                .referenceStandard(request.getReferenceStandard())
                .remarks(request.getRemarks())
                .submittedBy(request.getSubmittedBy())
                .build();

        if (request.getScheduleId() != null) {
            record.setSchedule(scheduleRepository.findById(request.getScheduleId()).orElse(null));
        }

        boolean allPass = true;
        for (TestResultRequest tr : request.getTestResults()) {
            double valueToEvaluate = tr.getAsLeftValue() != null ? tr.getAsLeftValue() : tr.getAsFoundValue();
            boolean pointPass = valueToEvaluate >= plan.getToleranceLower() && valueToEvaluate <= plan.getToleranceUpper();
            allPass &= pointPass;

            record.addTestResult(CalibrationTestResult.builder()
                    .parameterName(tr.getParameterName())
                    .uom(tr.getUom())
                    .targetValue(tr.getTargetValue())
                    .toleranceLower(plan.getToleranceLower())
                    .toleranceUpper(plan.getToleranceUpper())
                    .asFoundValue(tr.getAsFoundValue())
                    .asLeftValue(tr.getAsLeftValue())
                    .pointResultStatus(pointPass ? PointResultStatus.PASS : PointResultStatus.FAIL)
                    .build());
        }
        record.setResultStatus(allPass ? CalibrationResultStatus.PASS : CalibrationResultStatus.FAIL);

        CalibrationRecord saved = recordRepository.save(record);

        if (allPass) {
            planService.recalculateAfterCalibration(equipmentId, request.getCalibrationDate());
            equipmentService.updateStatus(equipment.getId(), EquipmentStatus.ACTIVE);
        } else {
            // QM-CAL-009: failed equipment is blocked until repair/adjustment and a passing recalibration.
            equipmentService.updateStatus(equipment.getId(), EquipmentStatus.BLOCKED);
        }

        if (record.getSchedule() != null) {
            record.getSchedule().setStatus(ScheduleStatus.COMPLETED);
        }

        return toResponse(saved);
    }

    @Transactional(readOnly = true)
    public List<CalibrationRecordResponse> history(String equipmentId) {
        return recordRepository.findByEquipment_EquipmentIdOrderByCalibrationDateDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    private CalibrationRecordResponse toResponse(CalibrationRecord r) {
        List<TestResultResponse> points = r.getTestResults().stream()
                .map(t -> TestResultResponse.builder()
                        .parameterName(t.getParameterName())
                        .uom(t.getUom())
                        .targetValue(t.getTargetValue())
                        .toleranceLower(t.getToleranceLower())
                        .toleranceUpper(t.getToleranceUpper())
                        .asFoundValue(t.getAsFoundValue())
                        .asLeftValue(t.getAsLeftValue())
                        .pointResultStatus(t.getPointResultStatus())
                        .build())
                .toList();

        return CalibrationRecordResponse.builder()
                .id(r.getId())
                .equipmentId(r.getEquipment().getEquipmentId())
                .calibrationDate(r.getCalibrationDate())
                .technician(r.getTechnician())
                .method(r.getMethod())
                .referenceStandard(r.getReferenceStandard())
                .resultStatus(r.getResultStatus())
                .remarks(r.getRemarks())
                .submittedBy(r.getSubmittedBy())
                .submittedAt(r.getSubmittedAt())
                .testResults(points)
                .build();
    }
}
