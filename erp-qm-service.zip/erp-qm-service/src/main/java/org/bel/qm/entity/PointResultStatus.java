package org.bel.qm.entity;

/** Pass/fail outcome for a single measured test point within a calibration record. */
public enum PointResultStatus {
    PASS,
    FAIL
}
