package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** One measured parameter within a QM-CAL-007 submission. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class TestResultRequest {

    @NotBlank
    private String parameterName;

    private String uom;
    private Double targetValue;

    @NotNull
    private Double asFoundValue;

    /** Omit if no adjustment was performed. */
    private Double asLeftValue;
}
