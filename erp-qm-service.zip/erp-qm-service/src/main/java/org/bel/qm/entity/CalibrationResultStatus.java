package org.bel.qm.entity;

/** QM-CAL-008: outcome of comparing calibration results against approved tolerance. */
public enum CalibrationResultStatus {
    PASS,
    FAIL,
    CONDITIONAL,
    OUT_OF_TOLERANCE
}
