package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationScheduleResponse;
import org.bel.qm.entity.CalibrationPlan;
import org.bel.qm.entity.CalibrationSchedule;
import org.bel.qm.entity.Equipment;
import org.bel.qm.entity.EquipmentStatus;
import org.bel.qm.entity.ScheduleStatus;
import org.bel.qm.repository.CalibrationPlanRepository;
import org.bel.qm.repository.CalibrationScheduleRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

/**
 * QM-CAL-004: generates the due/overdue calibration worklist ahead of due dates,
 * and QM-CAL-006's automatic DUE/OVERDUE equipment-status transitions.
 * QM-CAL-005 reminders/escalations would hang off this same worklist.
 */
@Service
@RequiredArgsConstructor
public class CalibrationScheduleService {

    private static final List<ScheduleStatus> OPEN_STATUSES =
            List.of(ScheduleStatus.SCHEDULED, ScheduleStatus.ASSIGNED, ScheduleStatus.IN_PROGRESS);

    private final CalibrationPlanRepository planRepository;
    private final CalibrationScheduleRepository scheduleRepository;
    private final EquipmentService equipmentService;

    @Value("${calibration.scheduling.planning-horizon-days:30}")
    private int planningHorizonDays;

    /** Runs daily; also callable on-demand via the controller. */
    @Scheduled(cron = "0 0 1 * * *")
    @Transactional
    public List<CalibrationScheduleResponse> generateWorklist() {
        LocalDate horizon = LocalDate.now().plusDays(planningHorizonDays);
        List<CalibrationPlan> duePlans = planRepository.findByActiveTrueAndNextDueDateLessThanEqual(horizon);

        return duePlans.stream()
                .filter(plan -> scheduleRepository
                        .findFirstByEquipment_IdAndStatusIn(plan.getEquipment().getId(), OPEN_STATUSES)
                        .isEmpty())
                .map(this::createScheduleEntry)
                .map(this::toResponse)
                .toList();
    }

    private CalibrationSchedule createScheduleEntry(CalibrationPlan plan) {
        Equipment equipment = plan.getEquipment();

        // QM-CAL-006: reflect due/overdue on the equipment itself as the worklist is generated.
        EquipmentStatus status = plan.getNextDueDate().isBefore(LocalDate.now())
                ? EquipmentStatus.OVERDUE
                : EquipmentStatus.DUE;
        equipmentService.updateStatus(equipment.getId(), status);

        CalibrationSchedule schedule = CalibrationSchedule.builder()
                .equipment(equipment)
                .calibrationPlan(plan)
                .dueDate(plan.getNextDueDate())
                .location(equipment.getLocation())
                .status(ScheduleStatus.SCHEDULED)
                .build();
        return scheduleRepository.save(schedule);
    }

    @Transactional
    public CalibrationScheduleResponse assignTechnician(Long scheduleId, String technician) {
        CalibrationSchedule schedule = scheduleRepository.findById(scheduleId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Schedule item not found: " + scheduleId));
        schedule.setAssignedTechnician(technician);
        schedule.setStatus(ScheduleStatus.ASSIGNED);
        return toResponse(schedule);
    }

    @Transactional(readOnly = true)
    public List<CalibrationScheduleResponse> listOpen() {
        return scheduleRepository.findByStatusIn(OPEN_STATUSES).stream().map(this::toResponse).toList();
    }

    private CalibrationScheduleResponse toResponse(CalibrationSchedule s) {
        return CalibrationScheduleResponse.builder()
                .id(s.getId())
                .equipmentId(s.getEquipment().getEquipmentId())
                .equipmentName(s.getEquipment().getName())
                .dueDate(s.getDueDate())
                .assignedTechnician(s.getAssignedTechnician())
                .location(s.getLocation())
                .status(s.getStatus())
                .build();
    }
}
