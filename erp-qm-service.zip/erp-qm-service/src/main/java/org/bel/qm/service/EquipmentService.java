package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.EquipmentRequest;
import org.bel.qm.dto.EquipmentResponse;
import org.bel.qm.entity.Equipment;
import org.bel.qm.entity.EquipmentStatus;
import org.bel.qm.repository.EquipmentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/** QM-CAL-001 / QM-CAL-002: equipment register and classification. */
@Service
@RequiredArgsConstructor
public class EquipmentService {

    private final EquipmentRepository equipmentRepository;

    @Transactional
    public EquipmentResponse register(EquipmentRequest request) {
        if (equipmentRepository.existsByEquipmentId(request.getEquipmentId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Equipment ID already exists: " + request.getEquipmentId());
        }
        if (equipmentRepository.existsBySerialNumber(request.getSerialNumber())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Serial number already registered: " + request.getSerialNumber());
        }

        Equipment equipment = Equipment.builder()
                .equipmentId(request.getEquipmentId())
                .name(request.getName())
                .type(request.getType())
                .manufacturer(request.getManufacturer())
                .model(request.getModel())
                .serialNumber(request.getSerialNumber())
                .assetTag(request.getAssetTag())
                .location(request.getLocation())
                .owner(request.getOwner())
                .category(request.getCategory())
                .criticality(request.getCriticality())
                .measurementRange(request.getMeasurementRange())
                .accuracy(request.getAccuracy())
                .resolution(request.getResolution())
                .intendedUse(request.getIntendedUse())
                .approved(false)
                .active(false)
                .build();

        return toResponse(equipmentRepository.save(equipment));
    }

    @Transactional
    public EquipmentResponse approve(String equipmentId) {
        Equipment equipment = getEntity(equipmentId);
        equipment.setApproved(true);
        return toResponse(equipment);
    }

    /** Activates a reviewed/approved equipment record; requires approval first. */
    @Transactional
    public EquipmentResponse activate(String equipmentId) {
        Equipment equipment = getEntity(equipmentId);
        if (!equipment.isApproved()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Equipment must be approved before activation: " + equipmentId);
        }
        equipment.setActive(true);
        equipment.setStatus(EquipmentStatus.ACTIVE);
        return toResponse(equipment);
    }

    /** QM-CAL-006: internal status transition, used by scheduling/execution/OOT flows. */
    @Transactional
    public void updateStatus(Long equipmentId, EquipmentStatus status) {
        Equipment equipment = equipmentRepository.findById(equipmentId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Equipment not found: " + equipmentId));
        equipment.setStatus(status);
    }

    @Transactional(readOnly = true)
    public EquipmentResponse getByEquipmentId(String equipmentId) {
        return toResponse(getEntity(equipmentId));
    }

    @Transactional(readOnly = true)
    public List<EquipmentResponse> list(EquipmentStatus status, String type) {
        List<Equipment> results;
        if (status != null) {
            results = equipmentRepository.findByStatus(status);
        } else if (type != null) {
            results = equipmentRepository.findByTypeIgnoreCase(type);
        } else {
            results = equipmentRepository.findAll();
        }
        return results.stream().map(this::toResponse).toList();
    }

    Equipment getEntity(String equipmentId) {
        return equipmentRepository.findByEquipmentId(equipmentId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Equipment not found: " + equipmentId));
    }

    private EquipmentResponse toResponse(Equipment e) {
        return EquipmentResponse.builder()
                .id(e.getId())
                .equipmentId(e.getEquipmentId())
                .name(e.getName())
                .type(e.getType())
                .manufacturer(e.getManufacturer())
                .model(e.getModel())
                .serialNumber(e.getSerialNumber())
                .assetTag(e.getAssetTag())
                .location(e.getLocation())
                .owner(e.getOwner())
                .category(e.getCategory())
                .criticality(e.getCriticality())
                .measurementRange(e.getMeasurementRange())
                .accuracy(e.getAccuracy())
                .resolution(e.getResolution())
                .intendedUse(e.getIntendedUse())
                .status(e.getStatus())
                .approved(e.isApproved())
                .active(e.isActive())
                .createdAt(e.getCreatedAt())
                .updatedAt(e.getUpdatedAt())
                .build();
    }
}
