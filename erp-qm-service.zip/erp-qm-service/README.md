# erp-qm-service — Calibration Management

Standalone Spring Boot module (package `org.bel.qm`) implementing the first
slice of the Quality Management calibration requirements: **QM-CAL-001
through QM-CAL-008**.

## Covered requirements

| Req ID | What's implemented |
|---|---|
| QM-CAL-001 | `Equipment` register — unique `equipmentId`/`serialNumber`, register→approve→activate workflow |
| QM-CAL-002 | Classification fields on `Equipment` (category, criticality, range, accuracy, resolution, intended use) |
| QM-CAL-003 | `CalibrationPlan` — interval, method, tolerance, provider; `nextDueDate` auto-calculated on save and on approval |
| QM-CAL-004 | `CalibrationScheduleService.generateWorklist()` — daily cron + on-demand endpoint; skips equipment with an already-open worklist item |
| QM-CAL-005 | Not built out — the schedule/due-date data this would key off is in place, no notification dispatch yet (see below) |
| QM-CAL-006 | `EquipmentStatus` (DUE/OVERDUE/BLOCKED/IN_CALIBRATION/ACTIVE/RETIRED), transitioned automatically by the plan-approval, scheduling and record-submission flows |
| QM-CAL-007 | `CalibrationRecord` + `CalibrationTestResult` — as-found/as-left values per parameter, technician/method/reference standard |
| QM-CAL-008 | Each test point evaluated against the plan's tolerance band; overall record gets PASS/FAIL; equipment flips to ACTIVE (pass) or BLOCKED (fail, pending QM-CAL-009 repair flow — not yet built) |

**Not included in this pass** (per your scope choice): OOT assessment/quality
hold (CAL-010/011), certificates (CAL-012), reference-standard traceability
(CAL-013), external vendor service requests (CAL-014), labels (CAL-015),
conditional-use extensions (CAL-016), location/custody history (CAL-017),
RBAC (CAL-018), reporting/dashboards (CAL-019), audit trail (CAL-020).
`CONDITIONAL` and `OUT_OF_TOLERANCE` exist as enum values but the current
logic only ever produces PASS/FAIL — worth revisiting once CAL-010 lands.

## Structure

```
src/main/java/org/bel/qm/
  entity/      Equipment, CalibrationPlan, CalibrationSchedule,
               CalibrationRecord, CalibrationTestResult + enums
  dto/         request/response objects per endpoint
  repository/  Spring Data JPA interfaces
  service/     EquipmentService, CalibrationPlanService,
               CalibrationScheduleService, CalibrationRecordService
  controller/  REST endpoints (see below)
```

## Endpoints

```
POST   /api/v1/equipment                                  register
POST   /api/v1/equipment/{id}/approve
POST   /api/v1/equipment/{id}/activate
GET    /api/v1/equipment/{id}
GET    /api/v1/equipment?status=&type=

PUT    /api/v1/equipment/{id}/calibration-plan             create/update
POST   /api/v1/equipment/{id}/calibration-plan/approve
GET    /api/v1/equipment/{id}/calibration-plan

POST   /api/v1/calibration-schedule/generate                run worklist generation on demand
GET    /api/v1/calibration-schedule                          list open worklist items
POST   /api/v1/calibration-schedule/{id}/assign

POST   /api/v1/equipment/{id}/calibration-records            submit a calibration execution
GET    /api/v1/equipment/{id}/calibration-records             history
```

## Before this builds in your reactor

1. **`pom.xml` parent** — currently points at `spring-boot-starter-parent`
   directly. Swap in your actual `erp-services` reactor parent (whatever
   `erp-plm-service` / `pf-mdms-service` use) so versions and shared deps
   stay consistent, and add this module to the reactor's `<modules>`.
2. **DB driver/schema** — `application.yml` assumes Postgres and
   `ddl-auto: update`; point it at your real datasource and swap to
   Flyway/Liquibase if that's the convention elsewhere in the reactor.
3. **Cross-service conventions** — `erp-plm-service` has `client`,
   `orchestrator`, `document`, `workflow`, `exception` packages that this
   module deliberately skipped for a first pass. If QM needs to call PLM/MDMS
   (e.g. equipment master data lookup) or needs custom exception handling,
   those packages are where that would go.
4. No `@ControllerAdvice`/global exception handler yet — validation and
   business-rule failures currently surface as Spring's default error body
   via `ResponseStatusException`. Add one if the reactor has a standard
   error-response shape to match.
