package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.ReferenceStandardStatus;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReferenceStandardResponse {
    private Long id;
    private String standardId;
    private String name;
    private String certificateNumber;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private Double uncertainty;
    private String standardAuthority;
    private ReferenceStandardStatus status;
}
