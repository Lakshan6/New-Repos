package org.bel.qm.entity;

/** QM-CAL-016: lifecycle of a temporary calibration extension / concession. */
public enum ConditionalUseStatus {
    REQUESTED,
    APPROVED,
    REJECTED,
    ACTIVE,
    EXPIRED,
    CLOSED
}
