package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.envers.Audited;

import java.time.Instant;
import java.time.LocalDate;

/** QM-CAL-017: one location/custodian movement in an equipment's history. */
@Entity
@Table(name = "equipment_transfer")
@Audited
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EquipmentTransfer {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    @Column(name = "from_location", length = 200)
    private String fromLocation;

    @Column(name = "to_location", nullable = false, length = 200)
    private String toLocation;

    @Column(name = "from_custodian", length = 150)
    private String fromCustodian;

    @Column(name = "to_custodian", nullable = false, length = 150)
    private String toCustodian;

    @Column(length = 500)
    private String reason;

    /** Set only when this transfer overrode an open-calibration-activity block. */
    @Column(name = "authorized_by", length = 150)
    private String authorizedBy;

    @Column(name = "transfer_date", nullable = false)
    private LocalDate transferDate;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @PrePersist
    void onCreate() {
        this.createdAt = Instant.now();
        if (this.transferDate == null) {
            this.transferDate = LocalDate.now();
        }
    }
}
