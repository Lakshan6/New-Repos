package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** QM-CAL-009: sign-off required before equipment can return to active use post-repair. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ApproveReturnToServiceRequest {
    @NotBlank
    private String approvedBy;
}
