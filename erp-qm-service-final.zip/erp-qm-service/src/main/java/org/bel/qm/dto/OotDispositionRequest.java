package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.OotDisposition;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class OotDispositionRequest {

    @NotNull
    private OotDisposition disposition;

    @NotBlank
    private String approvedBy;
}
