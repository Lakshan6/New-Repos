package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ReferenceStandardRequest;
import org.bel.qm.dto.ReferenceStandardResponse;
import org.bel.qm.service.ReferenceStandardService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/reference-standards")
@RequiredArgsConstructor
public class ReferenceStandardController {

    private final ReferenceStandardService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ReferenceStandardResponse register(@Valid @RequestBody ReferenceStandardRequest request) {
        return service.register(request);
    }

    @PostMapping("/{standardId}/retire")
    public ReferenceStandardResponse retire(@PathVariable String standardId) {
        return service.retire(standardId);
    }

    @GetMapping("/{standardId}")
    public ReferenceStandardResponse get(@PathVariable String standardId) {
        return service.get(standardId);
    }

    @GetMapping
    public List<ReferenceStandardResponse> list() {
        return service.list();
    }
}
