package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationDashboardResponse;
import org.bel.qm.dto.EquipmentResponse;
import org.bel.qm.dto.OotAssessmentResponse;
import org.bel.qm.entity.CalibrationResultStatus;
import org.bel.qm.entity.CertificateApprovalStatus;
import org.bel.qm.entity.EquipmentStatus;
import org.bel.qm.entity.QualityHoldStatus;
import org.bel.qm.repository.CalibrationCertificateRepository;
import org.bel.qm.repository.CalibrationRecordRepository;
import org.bel.qm.repository.EquipmentRepository;
import org.bel.qm.repository.OotAssessmentRepository;
import org.bel.qm.repository.QualityHoldRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDate;
import java.util.List;

/**
 * QM-CAL-019: read-only aggregate reporting. Counts are pulled straight from
 * the repositories (not the per-entity services) since this is purely
 * derived, view-only data with no business rules of its own.
 */
@Service
@RequiredArgsConstructor
public class ReportingService {

    private final EquipmentRepository equipmentRepository;
    private final CalibrationRecordRepository recordRepository;
    private final OotAssessmentRepository ootAssessmentRepository;
    private final QualityHoldRepository qualityHoldRepository;
    private final CalibrationCertificateRepository certificateRepository;
    private final EquipmentService equipmentService;
    private final OotAssessmentService ootAssessmentService;

    @Transactional(readOnly = true)
    public CalibrationDashboardResponse dashboard(LocalDate from, LocalDate to, int expiringSoonDays) {
        LocalDate periodFrom = from != null ? from : LocalDate.now().minusDays(30);
        LocalDate periodTo = to != null ? to : LocalDate.now();
        LocalDate expiryHorizon = LocalDate.now().plusDays(expiringSoonDays);

        return CalibrationDashboardResponse.builder()
                .periodFrom(periodFrom)
                .periodTo(periodTo)
                .totalEquipment(equipmentRepository.count())
                .dueCount(equipmentRepository.countByStatus(EquipmentStatus.DUE))
                .overdueCount(equipmentRepository.countByStatus(EquipmentStatus.OVERDUE))
                .blockedCount(equipmentRepository.countByStatus(EquipmentStatus.BLOCKED))
                .activeCount(equipmentRepository.countByStatus(EquipmentStatus.ACTIVE))
                .inCalibrationCount(equipmentRepository.countByStatus(EquipmentStatus.IN_CALIBRATION))
                .retiredCount(equipmentRepository.countByStatus(EquipmentStatus.RETIRED))
                .completedInPeriod(recordRepository.countByResultStatusAndCalibrationDateBetween(
                        CalibrationResultStatus.PASS, periodFrom, periodTo))
                .failedInPeriod(recordRepository.countByResultStatusAndCalibrationDateBetween(
                        CalibrationResultStatus.FAIL, periodFrom, periodTo))
                .ootEventsInPeriod(ootAssessmentRepository.countByOotDateBetween(periodFrom, periodTo))
                .openQualityHolds(qualityHoldRepository.countByStatus(QualityHoldStatus.ON_HOLD))
                .certificatesExpiringSoon(certificateRepository.countByApprovalStatusAndExpiryDateBetween(
                        CertificateApprovalStatus.APPROVED, LocalDate.now(), expiryHorizon))
                .build();
    }

    /** QM-CAL-019 overdue list - reuses the same equipment filter the main equipment endpoint exposes. */
    @Transactional(readOnly = true)
    public List<EquipmentResponse> overdueList() {
        return equipmentService.list(EquipmentStatus.OVERDUE, null);
    }

    @Transactional(readOnly = true)
    public List<OotAssessmentResponse> ootReport(LocalDate from, LocalDate to) {
        LocalDate periodFrom = from != null ? from : LocalDate.now().minusDays(90);
        LocalDate periodTo = to != null ? to : LocalDate.now();
        return ootAssessmentService.toResponses(
                ootAssessmentRepository.findByOotDateBetweenOrderByOotDateDesc(periodFrom, periodTo));
    }
}
