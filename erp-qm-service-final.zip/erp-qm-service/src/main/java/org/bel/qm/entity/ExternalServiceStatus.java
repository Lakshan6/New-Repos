package org.bel.qm.entity;

/** QM-CAL-014: lifecycle of an equipment sent out for external calibration. */
public enum ExternalServiceStatus {
    REQUESTED,
    DISPATCHED,
    CERTIFICATE_RECEIVED,
    VERIFIED,
    REACTIVATED,
    CANCELLED
}
