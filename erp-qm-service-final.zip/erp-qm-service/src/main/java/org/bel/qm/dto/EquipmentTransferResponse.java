package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EquipmentTransferResponse {
    private Long id;
    private String equipmentId;
    private String fromLocation;
    private String toLocation;
    private String fromCustodian;
    private String toCustodian;
    private String reason;
    private String authorizedBy;
    private LocalDate transferDate;
}
