package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationPlanRequest;
import org.bel.qm.dto.CalibrationPlanResponse;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.CalibrationPlanService;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/equipment/{equipmentId}/calibration-plan")
@RequiredArgsConstructor
public class CalibrationPlanController {

    private final CalibrationPlanService planService;

    @PutMapping
    public CalibrationPlanResponse createOrUpdate(@PathVariable String equipmentId,
                                                    @Valid @RequestBody CalibrationPlanRequest request) {
        return planService.createOrUpdate(equipmentId, request);
    }

    @RequiresRole({UserRole.QA_MANAGER, UserRole.LAB_MANAGER})
    @PostMapping("/approve")
    public CalibrationPlanResponse approve(@PathVariable String equipmentId) {
        return planService.approve(equipmentId);
    }

    @GetMapping
    public CalibrationPlanResponse get(@PathVariable String equipmentId) {
        return planService.getByEquipmentId(equipmentId);
    }
}
