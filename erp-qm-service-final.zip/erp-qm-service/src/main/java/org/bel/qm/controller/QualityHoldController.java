package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.QualityHoldDispositionRequest;
import org.bel.qm.dto.QualityHoldRequest;
import org.bel.qm.dto.QualityHoldResponse;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.QualityHoldService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class QualityHoldController {

    private final QualityHoldService qualityHoldService;

    @PostMapping("/api/v1/oot-assessments/{ootAssessmentId}/quality-holds")
    @ResponseStatus(HttpStatus.CREATED)
    public QualityHoldResponse placeHold(@PathVariable Long ootAssessmentId,
                                          @Valid @RequestBody QualityHoldRequest request) {
        return qualityHoldService.placeHold(ootAssessmentId, request);
    }

    /** Requires the OOT assessment to already carry an approved disposition. */
    @RequiresRole({UserRole.QA_MANAGER, UserRole.WAREHOUSE_MANAGER})
    @PostMapping("/api/v1/quality-holds/{holdId}/resolve")
    public QualityHoldResponse resolve(@PathVariable Long holdId,
                                        @Valid @RequestBody QualityHoldDispositionRequest request) {
        return qualityHoldService.resolve(holdId, request.getStatus());
    }

    @GetMapping("/api/v1/oot-assessments/{ootAssessmentId}/quality-holds")
    public List<QualityHoldResponse> byOotAssessment(@PathVariable Long ootAssessmentId) {
        return qualityHoldService.byOotAssessment(ootAssessmentId);
    }
}
