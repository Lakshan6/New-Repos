package org.bel.qm.service;

import jakarta.persistence.EntityManager;
import jakarta.persistence.ElementCollection;
import jakarta.persistence.ManyToOne;
import jakarta.persistence.OneToMany;
import jakarta.persistence.OneToOne;
import lombok.RequiredArgsConstructor;
import org.bel.qm.audit.QmRevisionEntity;
import org.bel.qm.dto.AuditRevisionResponse;
import org.hibernate.envers.AuditReader;
import org.hibernate.envers.AuditReaderFactory;
import org.hibernate.envers.RevisionType;
import org.hibernate.envers.query.AuditEntity;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.lang.reflect.Field;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * QM-CAL-020: immutable audit trail, backed by Hibernate Envers revision
 * history (see the entity {@code @Audited} annotations and
 * {@link org.bel.qm.audit.QmRevisionEntity}). Snapshots include only scalar
 * fields - relation fields (@ManyToOne/@OneToMany/etc) are skipped so this
 * works generically across entities without per-entity mapping code or the
 * lazy-loading pitfalls of serializing a detached proxy graph.
 */
@Service
@RequiredArgsConstructor
public class AuditTrailService {

    private final EntityManager entityManager;

    @Transactional(readOnly = true)
    @SuppressWarnings("unchecked")
    public <T> List<AuditRevisionResponse> revisionsFor(Class<T> entityClass, Object id) {
        AuditReader reader = AuditReaderFactory.get(entityManager);

        List<Object[]> rows = reader.createQuery()
                .forRevisionsOfEntity(entityClass, false, true)
                .add(AuditEntity.id().eq(id))
                .addOrder(AuditEntity.revisionNumber().asc())
                .getResultList();

        return rows.stream().map(row -> {
            Object entitySnapshot = row[0];
            QmRevisionEntity revisionEntity = (QmRevisionEntity) row[1];
            RevisionType revisionType = (RevisionType) row[2];

            return AuditRevisionResponse.builder()
                    .revision(revisionEntity.getId())
                    .timestamp(Instant.ofEpochMilli(revisionEntity.getTimestamp()))
                    .username(revisionEntity.getUsername())
                    .changeType(revisionType.name())
                    .snapshot(scalarSnapshot(entitySnapshot))
                    .build();
        }).toList();
    }

    private Map<String, Object> scalarSnapshot(Object entity) {
        Map<String, Object> result = new LinkedHashMap<>();
        for (Field field : entity.getClass().getDeclaredFields()) {
            if (field.isAnnotationPresent(ManyToOne.class) || field.isAnnotationPresent(OneToMany.class)
                    || field.isAnnotationPresent(OneToOne.class) || field.isAnnotationPresent(ElementCollection.class)) {
                continue;
            }
            field.setAccessible(true);
            try {
                result.put(field.getName(), field.get(entity));
            } catch (IllegalAccessException ignored) {
                // skip - shouldn't happen given setAccessible(true)
            }
        }
        return result;
    }
}
