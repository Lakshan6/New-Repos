package org.bel.qm.entity;

/** QM-CAL-011: containment status of stock/records impacted by an OOT finding. */
public enum QualityHoldStatus {
    ON_HOLD,
    REINSPECTED,
    RELEASED,
    RECALLED
}
