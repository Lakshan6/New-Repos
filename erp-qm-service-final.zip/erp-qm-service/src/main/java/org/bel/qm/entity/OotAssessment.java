package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

/**
 * QM-CAL-010: out-of-tolerance impact assessment for inspections/tests/
 * production records completed between the last valid calibration and the
 * failed one. Auto-initiated for CRITICAL equipment on a failed calibration.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "oot_assessment")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OotAssessment {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    /** The failed calibration record that identified the OOT condition. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "calibration_record_id", nullable = false)
    private CalibrationRecord calibrationRecord;

    @Column(name = "oot_date", nullable = false)
    private LocalDate ootDate;

    /** Date of the last calibration on this equipment that passed, if any. */
    @Column(name = "last_valid_date")
    private LocalDate lastValidDate;

    /** IDs of inspections / work orders / batches potentially affected. */
    @Builder.Default
    @ElementCollection
    @CollectionTable(name = "oot_affected_reference", joinColumns = @JoinColumn(name = "oot_assessment_id"))
    @Column(name = "reference_id", length = 100)
    private List<String> affectedReferences = new ArrayList<>();

    @Column(name = "risk_assessment", length = 2000)
    private String riskAssessment;

    @Column(name = "containment_action", length = 2000)
    private String containmentAction;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private OotDisposition disposition;

    @Column(name = "approved_by", length = 150)
    private String approvedBy;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.disposition == null) {
            this.disposition = OotDisposition.PENDING;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
