package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.envers.Audited;

import java.time.Instant;
import java.time.LocalDate;

/**
 * QM-CAL-014: tracks equipment dispatched to an external provider for
 * calibration - status, dates, cost, and the returned certificate. Equipment
 * stays IN_CALIBRATION until {@code reactivate()} completes.
 */
@Entity
@Table(name = "external_service_request")
@Audited
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExternalServiceRequest {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    @Column(nullable = false, length = 200)
    private String provider;

    @Column(name = "dispatch_date")
    private LocalDate dispatchDate;

    @Column(name = "expected_return_date")
    private LocalDate expectedReturnDate;

    @Column(name = "actual_return_date")
    private LocalDate actualReturnDate;

    @Column(name = "quoted_cost")
    private Double quotedCost;

    @Column(name = "actual_cost")
    private Double actualCost;

    @Column(name = "certificate_number", length = 100)
    private String certificateNumber;

    @Column(name = "certificate_issue_date")
    private LocalDate certificateIssueDate;

    @Column(name = "certificate_expiry_date")
    private LocalDate certificateExpiryDate;

    @Column(name = "certificate_attachment_reference", length = 500)
    private String certificateAttachmentReference;

    @Column(name = "verified_by", length = 150)
    private String verifiedBy;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ExternalServiceStatus status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.status == null) {
            this.status = ExternalServiceStatus.REQUESTED;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
