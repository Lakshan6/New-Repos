package org.bel.qm.repository;

import org.bel.qm.entity.AccessDecisionLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AccessDecisionLogRepository extends JpaRepository<AccessDecisionLog, Long> {
}
