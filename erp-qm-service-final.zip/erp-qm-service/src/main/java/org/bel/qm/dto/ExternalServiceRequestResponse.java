package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.ExternalServiceStatus;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExternalServiceRequestResponse {
    private Long id;
    private String equipmentId;
    private String provider;
    private LocalDate dispatchDate;
    private LocalDate expectedReturnDate;
    private LocalDate actualReturnDate;
    private Double quotedCost;
    private Double actualCost;
    private String certificateNumber;
    private LocalDate certificateIssueDate;
    private LocalDate certificateExpiryDate;
    private String certificateAttachmentReference;
    private String verifiedBy;
    private ExternalServiceStatus status;
}
