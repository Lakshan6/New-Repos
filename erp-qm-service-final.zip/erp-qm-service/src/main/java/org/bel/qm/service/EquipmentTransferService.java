package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.EquipmentTransferRequest;
import org.bel.qm.dto.EquipmentTransferResponse;
import org.bel.qm.entity.*;
import org.bel.qm.repository.CalibrationScheduleRepository;
import org.bel.qm.repository.EquipmentTransferRepository;
import org.bel.qm.repository.ExternalServiceRequestRepository;
import org.bel.qm.repository.RepairRecordRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * QM-CAL-017: location/custodian movement history. Blocks a transfer while
 * the equipment has an open calibration schedule item, an unresolved repair,
 * or an unreturned external service request - unless explicitly overridden
 * with an authorizer.
 */
@Service
@RequiredArgsConstructor
public class EquipmentTransferService {

    private static final List<ScheduleStatus> OPEN_SCHEDULE_STATUSES =
            List.of(ScheduleStatus.SCHEDULED, ScheduleStatus.ASSIGNED, ScheduleStatus.IN_PROGRESS);

    private static final List<RepairStatus> OPEN_REPAIR_STATUSES =
            List.of(RepairStatus.OPEN, RepairStatus.IN_PROGRESS, RepairStatus.COMPLETED,
                    RepairStatus.RETEST_PASSED, RepairStatus.RETEST_FAILED);

    private static final List<ExternalServiceStatus> CLOSED_EXTERNAL_STATUSES =
            List.of(ExternalServiceStatus.REACTIVATED, ExternalServiceStatus.CANCELLED);

    private final EquipmentTransferRepository transferRepository;
    private final CalibrationScheduleRepository scheduleRepository;
    private final RepairRecordRepository repairRepository;
    private final ExternalServiceRequestRepository externalServiceRepository;
    private final EquipmentService equipmentService;

    @Transactional
    public EquipmentTransferResponse transfer(String equipmentId, EquipmentTransferRequest request) {
        Equipment equipment = equipmentService.getEntity(equipmentId);

        String openActivity = findOpenCalibrationActivity(equipment.getId());
        if (openActivity != null) {
            if (!request.isOverride()) {
                throw new ResponseStatusException(HttpStatus.CONFLICT,
                        "Equipment has an open " + openActivity + " - set override=true with authorizedBy to transfer anyway");
            }
            if (request.getAuthorizedBy() == null || request.getAuthorizedBy().isBlank()) {
                throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "authorizedBy is required to override an open-activity block");
            }
        }

        EquipmentTransfer transfer = EquipmentTransfer.builder()
                .equipment(equipment)
                .fromLocation(equipment.getLocation())
                .toLocation(request.getToLocation())
                .fromCustodian(equipment.getOwner())
                .toCustodian(request.getToCustodian())
                .reason(request.getReason())
                .authorizedBy(openActivity != null ? request.getAuthorizedBy() : null)
                .build();
        transferRepository.save(transfer);

        equipment.setLocation(request.getToLocation());
        equipment.setOwner(request.getToCustodian());

        return toResponse(transfer);
    }

    private String findOpenCalibrationActivity(Long equipmentId) {
        if (scheduleRepository.findFirstByEquipment_IdAndStatusIn(equipmentId, OPEN_SCHEDULE_STATUSES).isPresent()) {
            return "calibration schedule item";
        }
        if (repairRepository.findFirstByEquipment_IdAndStatusInOrderByCreatedAtDesc(equipmentId, OPEN_REPAIR_STATUSES).isPresent()) {
            return "repair";
        }
        if (externalServiceRepository.findFirstByEquipment_IdAndStatusNotInOrderByCreatedAtDesc(equipmentId, CLOSED_EXTERNAL_STATUSES).isPresent()) {
            return "external calibration service request";
        }
        return null;
    }

    @Transactional(readOnly = true)
    public List<EquipmentTransferResponse> history(String equipmentId) {
        return transferRepository.findByEquipment_EquipmentIdOrderByTransferDateDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    private EquipmentTransferResponse toResponse(EquipmentTransfer t) {
        return EquipmentTransferResponse.builder()
                .id(t.getId())
                .equipmentId(t.getEquipment().getEquipmentId())
                .fromLocation(t.getFromLocation())
                .toLocation(t.getToLocation())
                .fromCustodian(t.getFromCustodian())
                .toCustodian(t.getToCustodian())
                .reason(t.getReason())
                .authorizedBy(t.getAuthorizedBy())
                .transferDate(t.getTransferDate())
                .build();
    }
}
