package org.bel.qm.repository;

import org.bel.qm.entity.ConditionalUseAuthorization;
import org.bel.qm.entity.ConditionalUseStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.time.LocalDate;
import java.util.List;

public interface ConditionalUseAuthorizationRepository extends JpaRepository<ConditionalUseAuthorization, Long> {
    List<ConditionalUseAuthorization> findByEquipment_EquipmentIdOrderByCreatedAtDesc(String equipmentId);

    /** QM-CAL-016: daily job picks up active authorizations whose window has closed. */
    List<ConditionalUseAuthorization> findByStatusAndEndDateLessThan(ConditionalUseStatus status, LocalDate date);
}
