package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.OotAssessmentRequest;
import org.bel.qm.dto.OotDispositionRequest;
import org.bel.qm.dto.OotAssessmentResponse;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.OotAssessmentService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class OotAssessmentController {

    private final OotAssessmentService ootAssessmentService;

    /**
     * CRITICAL equipment failures auto-open an assessment during calibration-record
     * submission; this endpoint covers manual/QA-discretion initiation otherwise
     * (e.g. a NON_CRITICAL equipment failure judged to warrant one).
     */
    @PostMapping("/api/v1/calibration-records/{calibrationRecordId}/oot-assessments")
    @ResponseStatus(HttpStatus.CREATED)
    public OotAssessmentResponse initiate(@PathVariable Long calibrationRecordId,
                                           @RequestBody(required = false) OotAssessmentRequest request) {
        return ootAssessmentService.initiateManual(calibrationRecordId, request);
    }

    @RequiresRole({UserRole.QA_MANAGER})
    @PostMapping("/api/v1/oot-assessments/{assessmentId}/disposition")
    public OotAssessmentResponse disposition(@PathVariable Long assessmentId,
                                              @Valid @RequestBody OotDispositionRequest request) {
        return ootAssessmentService.disposition(assessmentId, request.getDisposition(), request.getApprovedBy());
    }

    @GetMapping("/api/v1/equipment/{equipmentId}/oot-assessments")
    public List<OotAssessmentResponse> history(@PathVariable String equipmentId) {
        return ootAssessmentService.history(equipmentId);
    }
}
