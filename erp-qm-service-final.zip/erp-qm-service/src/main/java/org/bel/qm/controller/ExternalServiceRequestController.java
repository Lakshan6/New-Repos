package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.*;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.ExternalServiceRequestService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ExternalServiceRequestController {

    private final ExternalServiceRequestService service;

    @PostMapping("/api/v1/equipment/{equipmentId}/external-service-requests")
    @ResponseStatus(HttpStatus.CREATED)
    public ExternalServiceRequestResponse create(@PathVariable String equipmentId,
                                                  @Valid @RequestBody ExternalServiceRequestCreate request) {
        return service.create(equipmentId, request);
    }

    @PostMapping("/api/v1/external-service-requests/{requestId}/dispatch")
    public ExternalServiceRequestResponse dispatch(@PathVariable Long requestId,
                                                    @Valid @RequestBody DispatchRequest request) {
        return service.dispatch(requestId, request);
    }

    @PostMapping("/api/v1/external-service-requests/{requestId}/certificate")
    public ExternalServiceRequestResponse receiveCertificate(@PathVariable Long requestId,
                                                              @Valid @RequestBody ReceiveCertificateRequest request) {
        return service.receiveCertificate(requestId, request);
    }

    @PostMapping("/api/v1/external-service-requests/{requestId}/verify")
    public ExternalServiceRequestResponse verify(@PathVariable Long requestId,
                                                  @Valid @RequestBody VerifyCertificateRequest request) {
        return service.verify(requestId, request.getVerifiedBy());
    }

    @RequiresRole({UserRole.QA_MANAGER})
    @PostMapping("/api/v1/external-service-requests/{requestId}/reactivate")
    public ExternalServiceRequestResponse reactivate(@PathVariable Long requestId) {
        return service.reactivate(requestId);
    }

    @PostMapping("/api/v1/external-service-requests/{requestId}/cancel")
    public ExternalServiceRequestResponse cancel(@PathVariable Long requestId) {
        return service.cancel(requestId);
    }

    @GetMapping("/api/v1/equipment/{equipmentId}/external-service-requests")
    public List<ExternalServiceRequestResponse> history(@PathVariable String equipmentId) {
        return service.history(equipmentId);
    }
}
