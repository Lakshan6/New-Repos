package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ApproveReturnToServiceRequest;
import org.bel.qm.dto.CompleteRepairRequest;
import org.bel.qm.dto.RepairRecordRequest;
import org.bel.qm.dto.RepairRecordResponse;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.RepairRecordService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class RepairRecordController {

    private final RepairRecordService repairRecordService;

    @PostMapping("/api/v1/equipment/{equipmentId}/repairs")
    @ResponseStatus(HttpStatus.CREATED)
    public RepairRecordResponse open(@PathVariable String equipmentId, @Valid @RequestBody RepairRecordRequest request) {
        return repairRecordService.open(equipmentId, request);
    }

    @PostMapping("/api/v1/repairs/{repairId}/complete")
    public RepairRecordResponse complete(@PathVariable Long repairId, @Valid @RequestBody CompleteRepairRequest request) {
        return repairRecordService.complete(repairId, request);
    }

    /** QM-CAL-009: requires the repair to already have a passing retest (status RETEST_PASSED). */
    @RequiresRole({UserRole.QA_MANAGER})
    @PostMapping("/api/v1/repairs/{repairId}/approve-return-to-service")
    public RepairRecordResponse approveReturnToService(@PathVariable Long repairId,
                                                         @Valid @RequestBody ApproveReturnToServiceRequest request) {
        return repairRecordService.approveReturnToService(repairId, request);
    }

    @GetMapping("/api/v1/equipment/{equipmentId}/repairs")
    public List<RepairRecordResponse> history(@PathVariable String equipmentId) {
        return repairRecordService.history(equipmentId);
    }
}
