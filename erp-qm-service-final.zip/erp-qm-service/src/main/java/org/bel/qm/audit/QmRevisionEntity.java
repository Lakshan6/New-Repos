package org.bel.qm.audit;

import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.envers.DefaultRevisionEntity;
import org.hibernate.envers.RevisionEntity;

/**
 * QM-CAL-020: extends Envers' default revision (id + timestamp) with the
 * acting user, so every audited change - equipment setup, calibration
 * results, adjustments, certificates, status changes, OOT assessments,
 * releases, retirements - can be attributed to who made it.
 */
@Entity
@RevisionEntity(QmRevisionListener.class)
@Getter
@Setter
public class QmRevisionEntity extends DefaultRevisionEntity {

    @Column(length = 150)
    private String username;
}
