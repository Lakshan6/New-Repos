package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.OotAssessmentRequest;
import org.bel.qm.dto.OotAssessmentResponse;
import org.bel.qm.entity.*;
import org.bel.qm.repository.CalibrationRecordRepository;
import org.bel.qm.repository.OotAssessmentRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.Comparator;
import java.util.List;

/**
 * QM-CAL-010: out-of-tolerance impact assessment. initiateForFailure() is
 * called automatically by CalibrationRecordService for CRITICAL equipment
 * failures, and can also be invoked manually for non-critical ones.
 */
@Service
@RequiredArgsConstructor
public class OotAssessmentService {

    private final OotAssessmentRepository ootRepository;
    private final CalibrationRecordRepository recordRepository;

    /** Manual initiation - e.g. QA discretion for a failed NON_CRITICAL equipment. */
    @Transactional
    public OotAssessmentResponse initiateManual(Long calibrationRecordId, OotAssessmentRequest request) {
        CalibrationRecord failedRecord = recordRepository.findById(calibrationRecordId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Calibration record not found: " + calibrationRecordId));
        if (failedRecord.getResultStatus() == CalibrationResultStatus.PASS) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "OOT assessment only applies to a failed calibration record: " + calibrationRecordId);
        }
        return initiateForFailure(failedRecord, request);
    }

    @Transactional
    public OotAssessmentResponse initiateForFailure(CalibrationRecord failedRecord, OotAssessmentRequest request) {
        Equipment equipment = failedRecord.getEquipment();

        LocalDate lastValidDate = recordRepository
                .findByEquipment_EquipmentIdOrderByCalibrationDateDesc(equipment.getEquipmentId())
                .stream()
                .filter(r -> r.getResultStatus() == CalibrationResultStatus.PASS)
                .filter(r -> !r.getCalibrationDate().isAfter(failedRecord.getCalibrationDate()))
                .max(Comparator.comparing(CalibrationRecord::getCalibrationDate))
                .map(CalibrationRecord::getCalibrationDate)
                .orElse(null);

        OotAssessment assessment = OotAssessment.builder()
                .equipment(equipment)
                .calibrationRecord(failedRecord)
                .ootDate(failedRecord.getCalibrationDate())
                .lastValidDate(lastValidDate)
                .affectedReferences(request != null && request.getAffectedReferences() != null
                        ? request.getAffectedReferences() : List.of())
                .riskAssessment(request != null ? request.getRiskAssessment() : null)
                .containmentAction(request != null ? request.getContainmentAction() : null)
                .disposition(OotDisposition.PENDING)
                .build();

        return toResponse(ootRepository.save(assessment));
    }

    @Transactional
    public OotAssessmentResponse disposition(Long assessmentId, OotDisposition disposition, String approvedBy) {
        OotAssessment assessment = getEntity(assessmentId);
        // QM-CAL-018 segregation of duties: whoever submitted the failing calibration cannot also approve disposition.
        if (approvedBy.equalsIgnoreCase(assessment.getCalibrationRecord().getSubmittedBy())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Self-approval is not permitted");
        }
        assessment.setDisposition(disposition);
        assessment.setApprovedBy(approvedBy);
        return toResponse(assessment);
    }

    @Transactional(readOnly = true)
    public List<OotAssessmentResponse> history(String equipmentId) {
        return ootRepository.findByEquipment_EquipmentIdOrderByCreatedAtDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    /** QM-CAL-019: used by ReportingService to map a date-ranged query without exposing the entity. */
    @Transactional(readOnly = true)
    public List<OotAssessmentResponse> toResponses(List<OotAssessment> assessments) {
        return assessments.stream().map(this::toResponse).toList();
    }

    OotAssessment getEntity(Long id) {
        return ootRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "OOT assessment not found: " + id));
    }

    private OotAssessmentResponse toResponse(OotAssessment a) {
        return OotAssessmentResponse.builder()
                .id(a.getId())
                .equipmentId(a.getEquipment().getEquipmentId())
                .calibrationRecordId(a.getCalibrationRecord().getId())
                .ootDate(a.getOotDate())
                .lastValidDate(a.getLastValidDate())
                .affectedReferences(a.getAffectedReferences())
                .riskAssessment(a.getRiskAssessment())
                .containmentAction(a.getContainmentAction())
                .disposition(a.getDisposition())
                .approvedBy(a.getApprovedBy())
                .build();
    }
}
