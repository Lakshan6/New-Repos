package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.*;
import org.bel.qm.entity.*;
import org.bel.qm.repository.ExternalServiceRequestRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/**
 * QM-CAL-014: equipment dispatched to an external provider for calibration.
 * Equipment is set IN_CALIBRATION on dispatch and stays there until
 * {@link #reactivate} - certificate receipt alone isn't enough, it must also
 * be verified.
 */
@Service
@RequiredArgsConstructor
public class ExternalServiceRequestService {

    private final ExternalServiceRequestRepository requestRepository;
    private final EquipmentService equipmentService;
    private final ApprovedProviderService approvedProviderService;
    private final CalibrationPlanService planService;

    @Transactional
    public ExternalServiceRequestResponse create(String equipmentId, ExternalServiceRequestCreate request) {
        Equipment equipment = equipmentService.getEntity(equipmentId);
        if (equipment.getStatus() == EquipmentStatus.RETIRED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Cannot service retired equipment: " + equipmentId);
        }
        // QM-CAL-014: provider approval is required for CRITICAL equipment.
        if (equipment.getCriticality() == EquipmentCriticality.CRITICAL && !approvedProviderService.isApproved(request.getProvider())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Provider is not on the approved list, required for CRITICAL equipment: " + request.getProvider());
        }

        ExternalServiceRequest serviceRequest = ExternalServiceRequest.builder()
                .equipment(equipment)
                .provider(request.getProvider())
                .quotedCost(request.getQuotedCost())
                .status(ExternalServiceStatus.REQUESTED)
                .build();

        return toResponse(requestRepository.save(serviceRequest));
    }

    @Transactional
    public ExternalServiceRequestResponse dispatch(Long requestId, DispatchRequest request) {
        ExternalServiceRequest serviceRequest = getEntity(requestId);
        if (serviceRequest.getStatus() != ExternalServiceStatus.REQUESTED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Request is not in REQUESTED status: " + requestId);
        }
        serviceRequest.setDispatchDate(request.getDispatchDate());
        serviceRequest.setExpectedReturnDate(request.getExpectedReturnDate());
        serviceRequest.setStatus(ExternalServiceStatus.DISPATCHED);
        // QM-CAL-014: equipment is unavailable while externally calibrated.
        equipmentService.updateStatus(serviceRequest.getEquipment().getId(), EquipmentStatus.IN_CALIBRATION);
        return toResponse(serviceRequest);
    }

    @Transactional
    public ExternalServiceRequestResponse receiveCertificate(Long requestId, ReceiveCertificateRequest request) {
        ExternalServiceRequest serviceRequest = getEntity(requestId);
        if (serviceRequest.getStatus() != ExternalServiceStatus.DISPATCHED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Request is not in DISPATCHED status: " + requestId);
        }
        serviceRequest.setCertificateNumber(request.getCertificateNumber());
        serviceRequest.setCertificateIssueDate(request.getCertificateIssueDate());
        serviceRequest.setCertificateExpiryDate(request.getCertificateExpiryDate());
        serviceRequest.setCertificateAttachmentReference(request.getCertificateAttachmentReference());
        serviceRequest.setActualReturnDate(request.getActualReturnDate());
        serviceRequest.setActualCost(request.getActualCost());
        serviceRequest.setStatus(ExternalServiceStatus.CERTIFICATE_RECEIVED);
        // Equipment remains IN_CALIBRATION - verification and acceptance are still pending.
        return toResponse(serviceRequest);
    }

    @Transactional
    public ExternalServiceRequestResponse verify(Long requestId, String verifiedBy) {
        ExternalServiceRequest serviceRequest = getEntity(requestId);
        if (serviceRequest.getStatus() != ExternalServiceStatus.CERTIFICATE_RECEIVED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Request has no certificate to verify yet: " + requestId);
        }
        if (serviceRequest.getCertificateAttachmentReference() == null || serviceRequest.getCertificateAttachmentReference().isBlank()) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "Certificate attachment is missing");
        }
        serviceRequest.setVerifiedBy(verifiedBy);
        serviceRequest.setStatus(ExternalServiceStatus.VERIFIED);
        return toResponse(serviceRequest);
    }

    /** QM-CAL-014: equipment remains IN_CALIBRATION until verification AND this acceptance step complete. */
    @Transactional
    public ExternalServiceRequestResponse reactivate(Long requestId) {
        ExternalServiceRequest serviceRequest = getEntity(requestId);
        if (serviceRequest.getStatus() != ExternalServiceStatus.VERIFIED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Request must be VERIFIED before reactivation: " + requestId);
        }
        Equipment equipment = serviceRequest.getEquipment();
        try {
            planService.recalculateAfterCalibration(equipment.getEquipmentId(),
                    serviceRequest.getCertificateIssueDate() != null
                            ? serviceRequest.getCertificateIssueDate()
                            : serviceRequest.getActualReturnDate());
        } catch (ResponseStatusException ignored) {
            // no calibration plan configured yet - still allow reactivation, plan can be set up separately.
        }
        equipmentService.updateStatus(equipment.getId(), EquipmentStatus.ACTIVE);
        serviceRequest.setStatus(ExternalServiceStatus.REACTIVATED);
        return toResponse(serviceRequest);
    }

    @Transactional
    public ExternalServiceRequestResponse cancel(Long requestId) {
        ExternalServiceRequest serviceRequest = getEntity(requestId);
        if (serviceRequest.getStatus() == ExternalServiceStatus.REACTIVATED || serviceRequest.getStatus() == ExternalServiceStatus.CANCELLED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Request is already closed: " + requestId);
        }
        serviceRequest.setStatus(ExternalServiceStatus.CANCELLED);
        return toResponse(serviceRequest);
    }

    @Transactional(readOnly = true)
    public List<ExternalServiceRequestResponse> history(String equipmentId) {
        return requestRepository.findByEquipment_EquipmentIdOrderByCreatedAtDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    private ExternalServiceRequest getEntity(Long id) {
        return requestRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "External service request not found: " + id));
    }

    private ExternalServiceRequestResponse toResponse(ExternalServiceRequest r) {
        return ExternalServiceRequestResponse.builder()
                .id(r.getId())
                .equipmentId(r.getEquipment().getEquipmentId())
                .provider(r.getProvider())
                .dispatchDate(r.getDispatchDate())
                .expectedReturnDate(r.getExpectedReturnDate())
                .actualReturnDate(r.getActualReturnDate())
                .quotedCost(r.getQuotedCost())
                .actualCost(r.getActualCost())
                .certificateNumber(r.getCertificateNumber())
                .certificateIssueDate(r.getCertificateIssueDate())
                .certificateExpiryDate(r.getCertificateExpiryDate())
                .certificateAttachmentReference(r.getCertificateAttachmentReference())
                .verifiedBy(r.getVerifiedBy())
                .status(r.getStatus())
                .build();
    }
}
