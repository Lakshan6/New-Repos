package org.bel.qm.entity;

/** QM-CAL-010: outcome recorded once impact assessment is complete. */
public enum OotDisposition {
    PENDING,
    USE_AS_IS,
    REWORK,
    SCRAP,
    RECALL,
    NO_IMPACT
}
