package org.bel.qm.repository;

import org.bel.qm.entity.OotAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface OotAssessmentRepository extends JpaRepository<OotAssessment, Long> {
    List<OotAssessment> findByEquipment_EquipmentIdOrderByCreatedAtDesc(String equipmentId);

    List<OotAssessment> findByOotDateBetweenOrderByOotDateDesc(java.time.LocalDate from, java.time.LocalDate to);

    long countByOotDateBetween(java.time.LocalDate from, java.time.LocalDate to);
}
