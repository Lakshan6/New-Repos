package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

/**
 * QM-CAL-012: internal/external calibration certificate for one calibration
 * event. One certificate per calibration record.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "calibration_certificate", uniqueConstraints = {
        @UniqueConstraint(name = "uk_certificate_calibration_record", columnNames = "calibration_record_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationCertificate {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @OneToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "calibration_record_id", nullable = false)
    private CalibrationRecord calibrationRecord;

    @Column(name = "certificate_number", nullable = false, length = 100)
    private String certificateNumber;

    @Column(nullable = false, length = 200)
    private String provider;

    @Column(name = "issue_date", nullable = false)
    private LocalDate issueDate;

    @Column(name = "expiry_date")
    private LocalDate expiryDate;

    @Column(length = 300)
    private String scope;

    /** Reference/URL into the file store (e.g. pf-filestore-service), not the file bytes. */
    @Column(name = "attachment_reference", length = 500)
    private String attachmentReference;

    @Enumerated(EnumType.STRING)
    @Column(name = "approval_status", nullable = false, length = 20)
    private CertificateApprovalStatus approvalStatus;

    @Column(name = "verified_by", length = 150)
    private String verifiedBy;

    @Column(name = "approved_by", length = 150)
    private String approvedBy;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.approvalStatus == null) {
            this.approvalStatus = CertificateApprovalStatus.PENDING;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
