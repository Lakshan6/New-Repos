package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.OotDisposition;

import java.time.LocalDate;
import java.util.List;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OotAssessmentResponse {
    private Long id;
    private String equipmentId;
    private Long calibrationRecordId;
    private LocalDate ootDate;
    private LocalDate lastValidDate;
    private List<String> affectedReferences;
    private String riskAssessment;
    private String containmentAction;
    private OotDisposition disposition;
    private String approvedBy;
}
