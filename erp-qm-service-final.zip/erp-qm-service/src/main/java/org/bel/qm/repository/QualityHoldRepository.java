package org.bel.qm.repository;

import org.bel.qm.entity.QualityHold;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface QualityHoldRepository extends JpaRepository<QualityHold, Long> {
    List<QualityHold> findByOotAssessment_Id(Long ootAssessmentId);

    long countByStatus(org.bel.qm.entity.QualityHoldStatus status);
}
