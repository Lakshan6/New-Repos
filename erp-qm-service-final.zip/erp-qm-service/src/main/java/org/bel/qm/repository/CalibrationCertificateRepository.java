package org.bel.qm.repository;

import org.bel.qm.entity.CalibrationCertificate;
import org.bel.qm.entity.CertificateApprovalStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface CalibrationCertificateRepository extends JpaRepository<CalibrationCertificate, Long> {
    Optional<CalibrationCertificate> findByCalibrationRecord_Id(Long calibrationRecordId);

    /** QM-CAL-012: "current valid certificate" retrievable directly from the equipment record. */
    Optional<CalibrationCertificate> findFirstByCalibrationRecord_Equipment_EquipmentIdAndApprovalStatusOrderByIssueDateDesc(
            String equipmentId, CertificateApprovalStatus approvalStatus);

    /** QM-CAL-019: certificate register / expiring-soon report. */
    java.util.List<CalibrationCertificate> findByApprovalStatus(CertificateApprovalStatus approvalStatus);

    long countByApprovalStatusAndExpiryDateBetween(
            CertificateApprovalStatus approvalStatus, java.time.LocalDate from, java.time.LocalDate to);
}
