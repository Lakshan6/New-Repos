package org.bel.qm.audit;

import org.hibernate.envers.RevisionListener;

public class QmRevisionListener implements RevisionListener {

    @Override
    public void newRevision(Object revisionEntity) {
        ((QmRevisionEntity) revisionEntity).setUsername(AuditUserContext.getCurrentUser());
    }
}
