package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ReferenceStandardRequest;
import org.bel.qm.dto.ReferenceStandardResponse;
import org.bel.qm.entity.ReferenceStandard;
import org.bel.qm.entity.ReferenceStandardStatus;
import org.bel.qm.repository.ReferenceStandardRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

/** QM-CAL-013: register and maintain traceable reference standards. */
@Service
@RequiredArgsConstructor
public class ReferenceStandardService {

    private final ReferenceStandardRepository repository;

    @Transactional
    public ReferenceStandardResponse register(ReferenceStandardRequest request) {
        if (repository.existsByStandardId(request.getStandardId())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Reference standard already exists: " + request.getStandardId());
        }
        ReferenceStandard standard = ReferenceStandard.builder()
                .standardId(request.getStandardId())
                .name(request.getName())
                .certificateNumber(request.getCertificateNumber())
                .issueDate(request.getIssueDate())
                .expiryDate(request.getExpiryDate())
                .uncertainty(request.getUncertainty())
                .standardAuthority(request.getStandardAuthority())
                .status(ReferenceStandardStatus.ACTIVE)
                .build();
        return toResponse(repository.save(standard));
    }

    @Transactional
    public ReferenceStandardResponse retire(String standardId) {
        ReferenceStandard standard = getEntity(standardId);
        standard.setStatus(ReferenceStandardStatus.RETIRED);
        return toResponse(standard);
    }

    @Transactional(readOnly = true)
    public ReferenceStandardResponse get(String standardId) {
        return toResponse(getEntity(standardId));
    }

    @Transactional(readOnly = true)
    public List<ReferenceStandardResponse> list() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    /**
     * QM-CAL-013: fetches the standard and enforces it's usable (active, not
     * expired) as of the given calibration date. Auto-flips to EXPIRED so the
     * stored status stays accurate.
     */
    @Transactional
    ReferenceStandard getUsableOrThrow(String standardId, LocalDate calibrationDate) {
        ReferenceStandard standard = getEntity(standardId);
        if (standard.getStatus() == ReferenceStandardStatus.ACTIVE
                && standard.getExpiryDate().isBefore(LocalDate.now())) {
            standard.setStatus(ReferenceStandardStatus.EXPIRED);
        }
        if (!standard.isUsableOn(calibrationDate)) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Reference standard is expired or invalid: " + standardId);
        }
        return standard;
    }

    ReferenceStandard getEntity(String standardId) {
        return repository.findByStandardId(standardId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Reference standard not found: " + standardId));
    }

    private ReferenceStandardResponse toResponse(ReferenceStandard s) {
        return ReferenceStandardResponse.builder()
                .id(s.getId())
                .standardId(s.getStandardId())
                .name(s.getName())
                .certificateNumber(s.getCertificateNumber())
                .issueDate(s.getIssueDate())
                .expiryDate(s.getExpiryDate())
                .uncertainty(s.getUncertainty())
                .standardAuthority(s.getStandardAuthority())
                .status(s.getStatus())
                .build();
    }
}
