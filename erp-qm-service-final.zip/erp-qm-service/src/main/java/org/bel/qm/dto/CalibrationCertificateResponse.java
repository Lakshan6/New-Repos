package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.CertificateApprovalStatus;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationCertificateResponse {
    private Long id;
    private Long calibrationRecordId;
    private String equipmentId;
    private String certificateNumber;
    private String provider;
    private LocalDate issueDate;
    private LocalDate expiryDate;
    private String scope;
    private String attachmentReference;
    private CertificateApprovalStatus approvalStatus;
    private String verifiedBy;
    private String approvedBy;
}
