package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.RepairStatus;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepairRecordResponse {
    private Long id;
    private String equipmentId;
    private Long failedCalibrationRecordId;
    private String failureDetails;
    private String repairAction;
    private String vendor;
    private Double cost;
    private LocalDate completionDate;
    private Long retestCalibrationRecordId;
    private RepairStatus status;
    private String approvedBy;
}
