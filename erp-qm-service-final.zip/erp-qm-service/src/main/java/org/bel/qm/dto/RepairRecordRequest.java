package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** QM-CAL-009: open a repair against the equipment's most recent failed calibration. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepairRecordRequest {

    @NotBlank
    private String failureDetails;

    private String repairAction;
    private String vendor;
    private Double cost;
}
