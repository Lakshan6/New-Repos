package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** QM-CAL-014: open a calibration service request against an external provider. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ExternalServiceRequestCreate {

    @NotBlank
    private String provider;

    private Double quotedCost;
}
