package org.bel.qm.security;

import org.bel.qm.entity.UserRole;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * QM-CAL-018: marks a controller method as restricted to the given roles.
 * Enforced by {@link RoleAccessInterceptor} against the X-User-Role header.
 */
@Retention(RetentionPolicy.RUNTIME)
@Target(ElementType.METHOD)
public @interface RequiresRole {
    UserRole[] value();
}
