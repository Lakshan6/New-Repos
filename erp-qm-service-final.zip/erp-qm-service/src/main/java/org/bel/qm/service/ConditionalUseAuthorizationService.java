package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ConditionalUseRequest;
import org.bel.qm.dto.ConditionalUseResponse;
import org.bel.qm.entity.ConditionalUseAuthorization;
import org.bel.qm.entity.ConditionalUseStatus;
import org.bel.qm.entity.Equipment;
import org.bel.qm.entity.EquipmentCriticality;
import org.bel.qm.repository.ConditionalUseAuthorizationRepository;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpStatus;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.LocalDate;
import java.util.List;

/**
 * QM-CAL-016: a bounded, risk-assessed concession to keep using equipment
 * that is due/overdue. This does not itself change EquipmentStatus - it's a
 * separate, time-boxed authorization that expires automatically.
 */
@Service
@RequiredArgsConstructor
public class ConditionalUseAuthorizationService {

    private final ConditionalUseAuthorizationRepository repository;
    private final EquipmentService equipmentService;

    @Value("${calibration.conditional-use.max-extension-days:30}")
    private int maxExtensionDays;

    @Value("${calibration.conditional-use.allow-critical-equipment:false}")
    private boolean allowCriticalEquipment;

    @Transactional
    public ConditionalUseResponse request(String equipmentId, ConditionalUseRequest request) {
        Equipment equipment = equipmentService.getEntity(equipmentId);

        if (equipment.getCriticality() == EquipmentCriticality.CRITICAL && !allowCriticalEquipment) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Conditional use is not permitted for CRITICAL equipment: " + equipmentId);
        }
        if (request.getExtensionDays() > maxExtensionDays) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Requested extension exceeds the configured maximum of " + maxExtensionDays + " days");
        }

        ConditionalUseAuthorization authorization = ConditionalUseAuthorization.builder()
                .equipment(equipment)
                .justification(request.getJustification())
                .riskAssessment(request.getRiskAssessment())
                .extensionDays(request.getExtensionDays())
                .requestedBy(request.getRequestedBy())
                .status(ConditionalUseStatus.REQUESTED)
                .build();

        return toResponse(repository.save(authorization));
    }

    /** QM-CAL-018 segregation of duties: the approver cannot be the requester. */
    @Transactional
    public ConditionalUseResponse approve(Long id, String approvedBy) {
        ConditionalUseAuthorization authorization = getEntity(id);
        if (authorization.getStatus() != ConditionalUseStatus.REQUESTED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Authorization is not pending approval: " + id);
        }
        if (approvedBy.equalsIgnoreCase(authorization.getRequestedBy())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Self-approval is not permitted");
        }
        LocalDate today = LocalDate.now();
        authorization.setApprovedBy(approvedBy);
        authorization.setStartDate(today);
        authorization.setEndDate(today.plusDays(authorization.getExtensionDays()));
        authorization.setStatus(ConditionalUseStatus.ACTIVE);
        return toResponse(authorization);
    }

    @Transactional
    public ConditionalUseResponse reject(Long id, String rejectedBy, String reason) {
        ConditionalUseAuthorization authorization = getEntity(id);
        if (authorization.getStatus() != ConditionalUseStatus.REQUESTED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Authorization is not pending approval: " + id);
        }
        authorization.setApprovedBy(rejectedBy);
        authorization.setRejectionReason(reason);
        authorization.setStatus(ConditionalUseStatus.REJECTED);
        return toResponse(authorization);
    }

    @Transactional
    public ConditionalUseResponse close(Long id) {
        ConditionalUseAuthorization authorization = getEntity(id);
        if (authorization.getStatus() != ConditionalUseStatus.ACTIVE) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Only an ACTIVE authorization can be closed: " + id);
        }
        authorization.setStatus(ConditionalUseStatus.CLOSED);
        return toResponse(authorization);
    }

    /** QM-CAL-016: "automatically expires the authorization" - daily sweep past endDate. */
    @Scheduled(cron = "0 30 0 * * *")
    @Transactional
    public void expireLapsed() {
        repository.findByStatusAndEndDateLessThan(ConditionalUseStatus.ACTIVE, LocalDate.now())
                .forEach(a -> a.setStatus(ConditionalUseStatus.EXPIRED));
    }

    @Transactional(readOnly = true)
    public List<ConditionalUseResponse> history(String equipmentId) {
        return repository.findByEquipment_EquipmentIdOrderByCreatedAtDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    private ConditionalUseAuthorization getEntity(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Conditional use authorization not found: " + id));
    }

    private ConditionalUseResponse toResponse(ConditionalUseAuthorization a) {
        return ConditionalUseResponse.builder()
                .id(a.getId())
                .equipmentId(a.getEquipment().getEquipmentId())
                .justification(a.getJustification())
                .riskAssessment(a.getRiskAssessment())
                .extensionDays(a.getExtensionDays())
                .requestedBy(a.getRequestedBy())
                .approvedBy(a.getApprovedBy())
                .rejectionReason(a.getRejectionReason())
                .startDate(a.getStartDate())
                .endDate(a.getEndDate())
                .status(a.getStatus())
                .build();
    }
}
