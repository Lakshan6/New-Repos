package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;

/**
 * QM-CAL-011: quality hold placed on impacted lots/batches/inspection records
 * or released goods following an OOT finding. Always tied to an OOT reference.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "quality_hold")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QualityHold {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    /** Mandatory OOT reference - holds cannot exist without one. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "oot_assessment_id", nullable = false)
    private OotAssessment ootAssessment;

    @Column(name = "affected_batch_lot", nullable = false, length = 150)
    private String affectedBatchLot;

    private Double quantity;

    @Column(name = "customer_status", length = 200)
    private String customerStatus;

    @Column(name = "hold_reason", nullable = false, length = 1000)
    private String holdReason;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private QualityHoldStatus status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.status == null) {
            this.status = QualityHoldStatus.ON_HOLD;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
