package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/**
 * QM-CAL-012: attach a certificate to a calibration record. equipmentSerialNumber
 * and calibrationDate are supplied for cross-check against the record itself.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationCertificateRequest {

    @NotBlank
    private String certificateNumber;

    @NotBlank
    private String provider;

    @NotNull
    private LocalDate issueDate;

    private LocalDate expiryDate;
    private String scope;
    private String attachmentReference;

    @NotBlank
    private String equipmentSerialNumber;

    @NotNull
    private LocalDate calibrationDate;
}
