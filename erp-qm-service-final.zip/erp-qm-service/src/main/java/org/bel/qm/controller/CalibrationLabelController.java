package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationLabelResponse;
import org.bel.qm.dto.GenerateLabelRequest;
import org.bel.qm.dto.IssueLabelRequest;
import org.bel.qm.service.CalibrationLabelService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class CalibrationLabelController {

    private final CalibrationLabelService labelService;

    @PostMapping("/api/v1/equipment/{equipmentId}/labels")
    @ResponseStatus(HttpStatus.CREATED)
    public CalibrationLabelResponse generate(@PathVariable String equipmentId,
                                              @Valid @RequestBody GenerateLabelRequest request) {
        return labelService.generate(equipmentId, request.getGeneratedBy());
    }

    @PostMapping("/api/v1/labels/{labelId}/issue")
    public CalibrationLabelResponse issue(@PathVariable Long labelId, @Valid @RequestBody IssueLabelRequest request) {
        return labelService.issue(labelId, request.getIssuedBy());
    }

    /** What a barcode/label scan resolves to. */
    @GetMapping("/api/v1/equipment/{equipmentId}/labels/current")
    public CalibrationLabelResponse current(@PathVariable String equipmentId) {
        return labelService.currentForEquipment(equipmentId);
    }

    @GetMapping("/api/v1/equipment/{equipmentId}/labels")
    public List<CalibrationLabelResponse> history(@PathVariable String equipmentId) {
        return labelService.history(equipmentId);
    }
}
