package org.bel.qm.repository;

import org.bel.qm.entity.RepairRecord;
import org.bel.qm.entity.RepairStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface RepairRecordRepository extends JpaRepository<RepairRecord, Long> {

    List<RepairRecord> findByEquipment_EquipmentIdOrderByCreatedAtDesc(String equipmentId);

    /** QM-CAL-009: the open repair (if any) currently blocking this equipment from returning to service. */
    Optional<RepairRecord> findFirstByEquipment_IdAndStatusInOrderByCreatedAtDesc(Long equipmentId, List<RepairStatus> openStatuses);
}
