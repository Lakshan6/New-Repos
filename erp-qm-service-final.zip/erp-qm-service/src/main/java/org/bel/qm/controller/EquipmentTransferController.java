package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.EquipmentTransferRequest;
import org.bel.qm.dto.EquipmentTransferResponse;
import org.bel.qm.service.EquipmentTransferService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class EquipmentTransferController {

    private final EquipmentTransferService transferService;

    @PostMapping("/api/v1/equipment/{equipmentId}/transfers")
    @ResponseStatus(HttpStatus.CREATED)
    public EquipmentTransferResponse transfer(@PathVariable String equipmentId,
                                               @Valid @RequestBody EquipmentTransferRequest request) {
        return transferService.transfer(equipmentId, request);
    }

    @GetMapping("/api/v1/equipment/{equipmentId}/transfers")
    public List<EquipmentTransferResponse> history(@PathVariable String equipmentId) {
        return transferService.history(equipmentId);
    }
}
