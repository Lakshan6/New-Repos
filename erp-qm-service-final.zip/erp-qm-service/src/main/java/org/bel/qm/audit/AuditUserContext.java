package org.bel.qm.audit;

/** QM-CAL-020: carries the acting user (from X-User-Id) onto each Envers revision. */
public final class AuditUserContext {

    private static final ThreadLocal<String> CURRENT_USER = new ThreadLocal<>();

    private AuditUserContext() {
    }

    public static void set(String username) {
        CURRENT_USER.set(username);
    }

    public static String getCurrentUser() {
        return CURRENT_USER.get();
    }

    public static void clear() {
        CURRENT_USER.remove();
    }
}
