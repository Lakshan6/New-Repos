package org.bel.qm.entity;

/**
 * QM-CAL-009 lifecycle. Equipment stays BLOCKED through RETEST_PASSED -
 * only an explicit approval (RETURNED_TO_SERVICE) reactivates it, so a
 * passing recalibration alone can't bypass sign-off.
 */
public enum RepairStatus {
    OPEN,
    IN_PROGRESS,
    COMPLETED,
    RETEST_PASSED,
    RETEST_FAILED,
    RETURNED_TO_SERVICE
}
