package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ApprovedProviderRequest;
import org.bel.qm.dto.ApprovedProviderResponse;
import org.bel.qm.entity.ApprovedProvider;
import org.bel.qm.repository.ApprovedProviderRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/** QM-CAL-014: registry of external calibration providers approved for use. */
@Service
@RequiredArgsConstructor
public class ApprovedProviderService {

    private final ApprovedProviderRepository repository;

    @Transactional
    public ApprovedProviderResponse register(ApprovedProviderRequest request) {
        if (repository.existsByNameIgnoreCase(request.getName())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Provider already registered: " + request.getName());
        }
        ApprovedProvider provider = ApprovedProvider.builder().name(request.getName()).active(true).build();
        return toResponse(repository.save(provider));
    }

    @Transactional
    public ApprovedProviderResponse deactivate(String name) {
        ApprovedProvider provider = repository.findByNameIgnoreCase(name)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Provider not found: " + name));
        provider.setActive(false);
        return toResponse(provider);
    }

    @Transactional(readOnly = true)
    public List<ApprovedProviderResponse> list() {
        return repository.findAll().stream().map(this::toResponse).toList();
    }

    /** QM-CAL-014: "provider must be approved where required" - enforced for CRITICAL equipment. */
    @Transactional(readOnly = true)
    boolean isApproved(String name) {
        return repository.existsByNameIgnoreCaseAndActiveTrue(name);
    }

    private ApprovedProviderResponse toResponse(ApprovedProvider p) {
        return ApprovedProviderResponse.builder().id(p.getId()).name(p.getName()).active(p.isActive()).build();
    }
}
