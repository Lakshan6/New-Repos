package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.ConditionalUseStatus;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConditionalUseResponse {
    private Long id;
    private String equipmentId;
    private String justification;
    private String riskAssessment;
    private Integer extensionDays;
    private String requestedBy;
    private String approvedBy;
    private String rejectionReason;
    private LocalDate startDate;
    private LocalDate endDate;
    private ConditionalUseStatus status;
}
