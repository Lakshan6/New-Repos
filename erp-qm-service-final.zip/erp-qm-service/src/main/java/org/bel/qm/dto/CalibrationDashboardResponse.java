package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/** QM-CAL-019: aggregate calibration compliance and equipment-risk snapshot. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationDashboardResponse {
    private LocalDate periodFrom;
    private LocalDate periodTo;

    private long totalEquipment;
    private long dueCount;
    private long overdueCount;
    private long blockedCount;
    private long activeCount;
    private long inCalibrationCount;
    private long retiredCount;

    private long completedInPeriod;
    private long failedInPeriod;
    private long ootEventsInPeriod;
    private long openQualityHolds;
    private long certificatesExpiringSoon;
}
