package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

/**
 * QM-CAL-013: a recognized, traceable calibration reference standard.
 * CalibrationRecord links to one of these instead of a free-text field so
 * expired/invalid standards can be blocked from use.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "reference_standard", uniqueConstraints = {
        @UniqueConstraint(name = "uk_reference_standard_id", columnNames = "standard_id")
})
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReferenceStandard {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "standard_id", nullable = false, length = 64)
    private String standardId;

    @Column(nullable = false, length = 200)
    private String name;

    @Column(name = "certificate_number", nullable = false, length = 100)
    private String certificateNumber;

    @Column(name = "issue_date")
    private LocalDate issueDate;

    @Column(name = "expiry_date", nullable = false)
    private LocalDate expiryDate;

    private Double uncertainty;

    @Column(name = "standard_authority", length = 200)
    private String standardAuthority;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private ReferenceStandardStatus status;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.status == null) {
            this.status = ReferenceStandardStatus.ACTIVE;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }

    /** QM-CAL-013: expired or retired standards must not be usable in a calibration. */
    public boolean isUsableOn(LocalDate calibrationDate) {
        return status == ReferenceStandardStatus.ACTIVE
                && expiryDate != null
                && !expiryDate.isBefore(calibrationDate);
    }
}
