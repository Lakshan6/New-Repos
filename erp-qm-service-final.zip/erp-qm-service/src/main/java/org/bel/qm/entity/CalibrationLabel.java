package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.hibernate.envers.Audited;

import java.time.Instant;
import java.time.LocalDate;

/**
 * QM-CAL-015: a generated calibration label, snapshotting the equipment's
 * status/dates/certificate at generation time. issue() re-checks that
 * snapshot still matches the live record before it can be affixed.
 */
@Entity
@Table(name = "calibration_label")
@Audited
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationLabel {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    @Enumerated(EnumType.STRING)
    @Column(name = "status_snapshot", nullable = false, length = 20)
    private EquipmentStatus statusSnapshot;

    @Column(name = "last_calibration_date_snapshot")
    private LocalDate lastCalibrationDateSnapshot;

    @Column(name = "next_due_date_snapshot")
    private LocalDate nextDueDateSnapshot;

    @Column(name = "certificate_reference_snapshot", length = 100)
    private String certificateReferenceSnapshot;

    @Column(name = "generated_by", nullable = false, length = 150)
    private String generatedBy;

    @Column(name = "generated_at", nullable = false, updatable = false)
    private Instant generatedAt;

    @Column(nullable = false)
    private boolean issued;

    @Column(name = "issued_by", length = 150)
    private String issuedBy;

    @Column(name = "issued_at")
    private Instant issuedAt;

    @PrePersist
    void onCreate() {
        this.generatedAt = Instant.now();
    }
}
