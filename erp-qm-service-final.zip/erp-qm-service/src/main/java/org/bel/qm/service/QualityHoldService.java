package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.QualityHoldRequest;
import org.bel.qm.dto.QualityHoldResponse;
import org.bel.qm.entity.OotAssessment;
import org.bel.qm.entity.OotDisposition;
import org.bel.qm.entity.QualityHold;
import org.bel.qm.entity.QualityHoldStatus;
import org.bel.qm.repository.QualityHoldRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.List;

/** QM-CAL-011: quality hold on product impacted by an OOT finding. */
@Service
@RequiredArgsConstructor
public class QualityHoldService {

    private final QualityHoldRepository holdRepository;
    private final OotAssessmentService ootAssessmentService;

    @Transactional
    public QualityHoldResponse placeHold(Long ootAssessmentId, QualityHoldRequest request) {
        // Requiring the OOT assessment to exist enforces "holds require an OOT reference" (CAL-011).
        OotAssessment ootAssessment = ootAssessmentService.getEntity(ootAssessmentId);

        QualityHold hold = QualityHold.builder()
                .ootAssessment(ootAssessment)
                .affectedBatchLot(request.getAffectedBatchLot())
                .quantity(request.getQuantity())
                .customerStatus(request.getCustomerStatus())
                .holdReason(request.getHoldReason())
                .status(QualityHoldStatus.ON_HOLD)
                .build();

        return toResponse(holdRepository.save(hold));
    }

    /**
     * QM-CAL-011: "impacted stock is blocked until OOT assessment and disposition
     * are approved" - so resolving a hold (reinspect/release/recall) requires the
     * parent OOT assessment to already have an approved disposition.
     */
    @Transactional
    public QualityHoldResponse resolve(Long holdId, QualityHoldStatus status) {
        if (status == QualityHoldStatus.ON_HOLD) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST, "ON_HOLD is not a valid resolution status");
        }
        QualityHold hold = holdRepository.findById(holdId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Quality hold not found: " + holdId));
        OotAssessment ootAssessment = hold.getOotAssessment();
        if (ootAssessment.getApprovedBy() == null || ootAssessment.getDisposition() == null
                || ootAssessment.getDisposition() == OotDisposition.PENDING) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Hold cannot be resolved until its OOT assessment has an approved disposition: " + ootAssessment.getId());
        }
        hold.setStatus(status);
        return toResponse(hold);
    }

    @Transactional(readOnly = true)
    public List<QualityHoldResponse> byOotAssessment(Long ootAssessmentId) {
        return holdRepository.findByOotAssessment_Id(ootAssessmentId).stream().map(this::toResponse).toList();
    }

    private QualityHoldResponse toResponse(QualityHold h) {
        return QualityHoldResponse.builder()
                .id(h.getId())
                .ootAssessmentId(h.getOotAssessment().getId())
                .affectedBatchLot(h.getAffectedBatchLot())
                .quantity(h.getQuantity())
                .customerStatus(h.getCustomerStatus())
                .holdReason(h.getHoldReason())
                .status(h.getStatus())
                .build();
    }
}
