package org.bel.qm.audit;

import jakarta.servlet.Filter;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.ServletRequest;
import jakarta.servlet.ServletResponse;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.stereotype.Component;

import java.io.IOException;

/**
 * QM-CAL-020: every request's acting user (X-User-Id, set by the upstream
 * gateway/identity layer) is made available to the Envers revision listener
 * for the duration of the request, so each audit revision records who made
 * the change - not just when.
 */
@Component
public class AuditUserContextFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        try {
            if (request instanceof HttpServletRequest httpRequest) {
                AuditUserContext.set(httpRequest.getHeader("X-User-Id"));
            }
            chain.doFilter(request, response);
        } finally {
            AuditUserContext.clear();
        }
    }
}
