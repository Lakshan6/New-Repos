package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

/** QM-CAL-013 register/update a traceable reference standard. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReferenceStandardRequest {

    @NotBlank
    private String standardId;

    @NotBlank
    private String name;

    @NotBlank
    private String certificateNumber;

    private LocalDate issueDate;

    @NotNull
    private LocalDate expiryDate;

    private Double uncertainty;
    private String standardAuthority;
}
