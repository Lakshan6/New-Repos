package org.bel.qm.entity;

/** QM-CAL-009: type of corrective action taken on failed equipment. */
public enum RepairActionType {
    ADJUSTMENT,
    REPAIR,
    MAINTENANCE
}
