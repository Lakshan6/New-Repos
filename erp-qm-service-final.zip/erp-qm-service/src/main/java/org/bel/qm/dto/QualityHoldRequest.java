package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** QM-CAL-011: place impacted product on hold; always tied to an OOT assessment. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QualityHoldRequest {

    @NotBlank
    private String affectedBatchLot;

    private Double quantity;
    private String customerStatus;

    @NotBlank
    private String holdReason;
}
