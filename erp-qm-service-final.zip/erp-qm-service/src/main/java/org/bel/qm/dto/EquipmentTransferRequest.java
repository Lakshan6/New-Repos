package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** QM-CAL-017: relocate equipment and/or hand it to a new custodian. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class EquipmentTransferRequest {

    @NotBlank
    private String toLocation;

    @NotBlank
    private String toCustodian;

    private String reason;

    /** Set true only to override an open-calibration-activity block; requires authorizedBy. */
    private boolean override;

    private String authorizedBy;
}
