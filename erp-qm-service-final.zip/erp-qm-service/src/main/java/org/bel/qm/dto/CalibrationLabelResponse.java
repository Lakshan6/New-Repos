package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.EquipmentStatus;

import java.time.Instant;
import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class CalibrationLabelResponse {
    private Long id;
    private String equipmentId;
    private EquipmentStatus statusSnapshot;
    private LocalDate lastCalibrationDateSnapshot;
    private LocalDate nextDueDateSnapshot;
    private String certificateReferenceSnapshot;
    private String generatedBy;
    private Instant generatedAt;
    private boolean issued;
    private String issuedBy;
    private Instant issuedAt;
}
