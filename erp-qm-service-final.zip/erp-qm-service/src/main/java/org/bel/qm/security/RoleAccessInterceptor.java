package org.bel.qm.security;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import org.bel.qm.entity.AccessDecisionLog;
import org.bel.qm.entity.UserRole;
import org.bel.qm.repository.AccessDecisionLogRepository;
import org.springframework.stereotype.Component;
import org.springframework.web.method.HandlerMethod;
import org.springframework.web.servlet.HandlerInterceptor;

import java.util.Arrays;

/**
 * QM-CAL-018: enforces {@link RequiresRole} on controller methods using the
 * X-User-Id / X-User-Role headers supplied by the upstream gateway/identity
 * layer, and logs every decision (allow or deny) to AccessDecisionLog.
 *
 * This service does not authenticate users itself - it trusts headers set by
 * infrastructure in front of it. Wire your real auth/gateway to populate
 * X-User-Id and X-User-Role before relying on this in production.
 */
@Component
@RequiredArgsConstructor
public class RoleAccessInterceptor implements HandlerInterceptor {

    private final AccessDecisionLogRepository accessDecisionLogRepository;

    @Override
    public boolean preHandle(HttpServletRequest request, HttpServletResponse response, Object handler) throws Exception {
        if (!(handler instanceof HandlerMethod handlerMethod)) {
            return true;
        }
        RequiresRole requiresRole = handlerMethod.getMethodAnnotation(RequiresRole.class);
        if (requiresRole == null) {
            return true;
        }

        String username = request.getHeader("X-User-Id");
        String roleHeader = request.getHeader("X-User-Role");
        String action = handlerMethod.getBeanType().getSimpleName() + "." + handlerMethod.getMethod().getName();

        UserRole role = parseRole(roleHeader);
        boolean allowed = role != null && Arrays.asList(requiresRole.value()).contains(role);
        String reason = allowed ? null
                : (role == null ? "missing/unrecognized X-User-Role header" : "role not authorized for this action");

        accessDecisionLogRepository.save(AccessDecisionLog.builder()
                .username(username)
                .role(roleHeader)
                .action(action)
                .allowed(allowed)
                .reason(reason)
                .build());

        if (!allowed) {
            response.setStatus(HttpServletResponse.SC_FORBIDDEN);
            response.setContentType("application/json");
            response.getWriter().write("{\"error\":\"Forbidden\",\"message\":\"Role '" + roleHeader
                    + "' is not authorized to perform " + action + "\"}");
            return false;
        }
        return true;
    }

    private UserRole parseRole(String roleHeader) {
        if (roleHeader == null || roleHeader.isBlank()) {
            return null;
        }
        try {
            return UserRole.valueOf(roleHeader.trim().toUpperCase());
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
