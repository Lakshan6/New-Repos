package org.bel.qm.repository;

import org.bel.qm.entity.CalibrationLabel;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface CalibrationLabelRepository extends JpaRepository<CalibrationLabel, Long> {
    List<CalibrationLabel> findByEquipment_EquipmentIdOrderByGeneratedAtDesc(String equipmentId);
    Optional<CalibrationLabel> findFirstByEquipment_EquipmentIdAndIssuedTrueOrderByIssuedAtDesc(String equipmentId);
}
