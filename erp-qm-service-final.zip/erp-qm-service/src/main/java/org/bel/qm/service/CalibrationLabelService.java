package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationLabelResponse;
import org.bel.qm.entity.CalibrationCertificate;
import org.bel.qm.entity.CalibrationLabel;
import org.bel.qm.entity.CalibrationPlan;
import org.bel.qm.entity.Equipment;
import org.bel.qm.repository.CalibrationCertificateRepository;
import org.bel.qm.repository.CalibrationLabelRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.time.Instant;
import java.util.List;
import java.util.Objects;

/**
 * QM-CAL-015: generates a label snapshotting the equipment's current
 * status/due-date/certificate, and issues it only once that snapshot is
 * re-confirmed to still match the live record.
 */
@Service
@RequiredArgsConstructor
public class CalibrationLabelService {

    private final CalibrationLabelRepository labelRepository;
    private final CalibrationCertificateRepository certificateRepository;
    private final EquipmentService equipmentService;
    private final CalibrationPlanService planService;

    @Transactional
    public CalibrationLabelResponse generate(String equipmentId, String generatedBy) {
        Equipment equipment = equipmentService.getEntity(equipmentId);
        CalibrationPlan plan = planService.getEntity(equipmentId);
        if (!plan.isApproved()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Equipment has no approved calibration plan to label against: " + equipmentId);
        }

        String certificateRef = currentApprovedCertificateNumber(equipmentId);

        CalibrationLabel label = CalibrationLabel.builder()
                .equipment(equipment)
                .statusSnapshot(equipment.getStatus())
                .lastCalibrationDateSnapshot(plan.getLastCalibrationDate())
                .nextDueDateSnapshot(plan.getNextDueDate())
                .certificateReferenceSnapshot(certificateRef)
                .generatedBy(generatedBy)
                .issued(false)
                .build();

        return toResponse(labelRepository.save(label));
    }

    /** QM-CAL-015: "label data must match the current approved calibration record" - re-verified here. */
    @Transactional
    public CalibrationLabelResponse issue(Long labelId, String issuedBy) {
        CalibrationLabel label = labelRepository.findById(labelId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Label not found: " + labelId));

        Equipment equipment = label.getEquipment();
        CalibrationPlan plan = planService.getEntity(equipment.getEquipmentId());
        String currentCertificateRef = currentApprovedCertificateNumber(equipment.getEquipmentId());

        boolean stillMatches = label.getStatusSnapshot() == equipment.getStatus()
                && Objects.equals(label.getLastCalibrationDateSnapshot(), plan.getLastCalibrationDate())
                && Objects.equals(label.getNextDueDateSnapshot(), plan.getNextDueDate())
                && Objects.equals(label.getCertificateReferenceSnapshot(), currentCertificateRef);

        if (!stillMatches) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Label data is stale relative to the current calibration record - regenerate before issuing: " + labelId);
        }

        label.setIssued(true);
        label.setIssuedBy(issuedBy);
        label.setIssuedAt(Instant.now());
        return toResponse(label);
    }

    /** QM-CAL-015: what a barcode/label scan would resolve to. */
    @Transactional(readOnly = true)
    public CalibrationLabelResponse currentForEquipment(String equipmentId) {
        return toResponse(labelRepository.findFirstByEquipment_EquipmentIdAndIssuedTrueOrderByIssuedAtDesc(equipmentId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No issued label on file for equipment: " + equipmentId)));
    }

    @Transactional(readOnly = true)
    public List<CalibrationLabelResponse> history(String equipmentId) {
        return labelRepository.findByEquipment_EquipmentIdOrderByGeneratedAtDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    private String currentApprovedCertificateNumber(String equipmentId) {
        return certificateRepository
                .findFirstByCalibrationRecord_Equipment_EquipmentIdAndApprovalStatusOrderByIssueDateDesc(
                        equipmentId, org.bel.qm.entity.CertificateApprovalStatus.APPROVED)
                .map(CalibrationCertificate::getCertificateNumber)
                .orElse(null);
    }

    private CalibrationLabelResponse toResponse(CalibrationLabel l) {
        return CalibrationLabelResponse.builder()
                .id(l.getId())
                .equipmentId(l.getEquipment().getEquipmentId())
                .statusSnapshot(l.getStatusSnapshot())
                .lastCalibrationDateSnapshot(l.getLastCalibrationDateSnapshot())
                .nextDueDateSnapshot(l.getNextDueDateSnapshot())
                .certificateReferenceSnapshot(l.getCertificateReferenceSnapshot())
                .generatedBy(l.getGeneratedBy())
                .generatedAt(l.getGeneratedAt())
                .issued(l.isIssued())
                .issuedBy(l.getIssuedBy())
                .issuedAt(l.getIssuedAt())
                .build();
    }
}
