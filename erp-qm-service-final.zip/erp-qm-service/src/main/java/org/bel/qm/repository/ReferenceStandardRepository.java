package org.bel.qm.repository;

import org.bel.qm.entity.ReferenceStandard;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface ReferenceStandardRepository extends JpaRepository<ReferenceStandard, Long> {
    Optional<ReferenceStandard> findByStandardId(String standardId);
    boolean existsByStandardId(String standardId);
}
