package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.QualityHoldStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class QualityHoldResponse {
    private Long id;
    private Long ootAssessmentId;
    private String affectedBatchLot;
    private Double quantity;
    private String customerStatus;
    private String holdReason;
    private QualityHoldStatus status;
}
