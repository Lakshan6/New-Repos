package org.bel.qm.dto;

import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import org.bel.qm.entity.QualityHoldStatus;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class QualityHoldDispositionRequest {

    @NotNull
    private QualityHoldStatus status;
}
