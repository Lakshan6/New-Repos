package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ApproveReturnToServiceRequest;
import org.bel.qm.dto.CompleteRepairRequest;
import org.bel.qm.dto.RepairRecordRequest;
import org.bel.qm.dto.RepairRecordResponse;
import org.bel.qm.entity.*;
import org.bel.qm.repository.CalibrationRecordRepository;
import org.bel.qm.repository.RepairRecordRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

import java.util.Comparator;
import java.util.List;

/**
 * QM-CAL-009: adjustment/repair control for equipment that failed
 * calibration. A passing retest (recorded by CalibrationRecordService) moves
 * the repair to RETEST_PASSED but leaves the equipment BLOCKED - only
 * {@link #approveReturnToService} reactivates it, so recalibrating alone
 * can't return equipment to service without sign-off.
 */
@Service
@RequiredArgsConstructor
public class RepairRecordService {

    /** Anything short of RETURNED_TO_SERVICE still counts as "this repair is open". */
    private static final List<RepairStatus> NOT_YET_RETURNED =
            List.of(RepairStatus.OPEN, RepairStatus.IN_PROGRESS, RepairStatus.COMPLETED,
                    RepairStatus.RETEST_PASSED, RepairStatus.RETEST_FAILED);

    private final RepairRecordRepository repairRepository;
    private final CalibrationRecordRepository calibrationRecordRepository;
    private final EquipmentService equipmentService;

    @Transactional
    public RepairRecordResponse open(String equipmentId, RepairRecordRequest request) {
        Equipment equipment = equipmentService.getEntity(equipmentId);

        CalibrationRecord failedRecord = calibrationRecordRepository
                .findByEquipment_EquipmentIdOrderByCalibrationDateDesc(equipmentId).stream()
                .filter(r -> r.getResultStatus() != CalibrationResultStatus.PASS)
                .max(Comparator.comparing(CalibrationRecord::getCalibrationDate))
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.CONFLICT,
                        "No failed calibration record found for equipment: " + equipmentId));

        RepairRecord repair = RepairRecord.builder()
                .equipment(equipment)
                .failedCalibrationRecord(failedRecord)
                .failureDetails(request.getFailureDetails())
                .repairAction(request.getRepairAction())
                .vendor(request.getVendor())
                .cost(request.getCost())
                .status(RepairStatus.IN_PROGRESS)
                .build();

        return toResponse(repairRepository.save(repair));
    }

    @Transactional
    public RepairRecordResponse complete(Long repairId, CompleteRepairRequest request) {
        RepairRecord repair = getEntity(repairId);
        repair.setRepairAction(request.getRepairAction());
        repair.setVendor(request.getVendor());
        repair.setCost(request.getCost());
        repair.setCompletionDate(request.getCompletionDate());
        repair.setStatus(RepairStatus.COMPLETED);
        // Equipment remains BLOCKED - a recalibration (and then approval) is still required.
        return toResponse(repair);
    }

    /**
     * Called by CalibrationRecordService once a recalibration for this equipment
     * is recorded. Returns true if an open repair was found and linked - the
     * caller uses that to decide whether the equipment may reactivate immediately
     * (no open repair) or must wait on {@link #approveReturnToService} instead.
     */
    @Transactional
    boolean recordRetestOutcome(Long equipmentId, CalibrationRecord retestRecord, boolean passed) {
        return repairRepository.findFirstByEquipment_IdAndStatusInOrderByCreatedAtDesc(equipmentId, NOT_YET_RETURNED)
                .map(repair -> {
                    repair.setRetestCalibrationRecord(retestRecord);
                    repair.setStatus(passed ? RepairStatus.RETEST_PASSED : RepairStatus.RETEST_FAILED);
                    return true;
                })
                .orElse(false);
    }

    /** QM-CAL-009: explicit sign-off required before blocked equipment returns to active use. */
    @Transactional
    public RepairRecordResponse approveReturnToService(Long repairId, ApproveReturnToServiceRequest request) {
        RepairRecord repair = getEntity(repairId);
        if (repair.getStatus() != RepairStatus.RETEST_PASSED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Repair must have a passing retest before it can be approved for return to service: " + repairId);
        }
        // QM-CAL-018 segregation of duties: whoever submitted the passing retest cannot also approve it.
        if (repair.getRetestCalibrationRecord() != null
                && request.getApprovedBy().equalsIgnoreCase(repair.getRetestCalibrationRecord().getSubmittedBy())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Self-approval is not permitted");
        }
        repair.setStatus(RepairStatus.RETURNED_TO_SERVICE);
        repair.setApprovedBy(request.getApprovedBy());
        equipmentService.updateStatus(repair.getEquipment().getId(), EquipmentStatus.ACTIVE);
        return toResponse(repair);
    }

    @Transactional(readOnly = true)
    public List<RepairRecordResponse> history(String equipmentId) {
        return repairRepository.findByEquipment_EquipmentIdOrderByCreatedAtDesc(equipmentId)
                .stream().map(this::toResponse).toList();
    }

    private RepairRecord getEntity(Long id) {
        return repairRepository.findById(id)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Repair record not found: " + id));
    }

    private RepairRecordResponse toResponse(RepairRecord r) {
        return RepairRecordResponse.builder()
                .id(r.getId())
                .equipmentId(r.getEquipment().getEquipmentId())
                .failedCalibrationRecordId(r.getFailedCalibrationRecord().getId())
                .failureDetails(r.getFailureDetails())
                .repairAction(r.getRepairAction())
                .vendor(r.getVendor())
                .cost(r.getCost())
                .completionDate(r.getCompletionDate())
                .retestCalibrationRecordId(r.getRetestCalibrationRecord() != null ? r.getRetestCalibrationRecord().getId() : null)
                .status(r.getStatus())
                .approvedBy(r.getApprovedBy())
                .build();
    }
}
