package org.bel.qm.repository;

import org.bel.qm.entity.ApprovedProvider;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ApprovedProviderRepository extends JpaRepository<ApprovedProvider, Long> {
    Optional<ApprovedProvider> findByNameIgnoreCase(String name);
    boolean existsByNameIgnoreCase(String name);
    boolean existsByNameIgnoreCaseAndActiveTrue(String name);
    List<ApprovedProvider> findByActiveTrue();
}
