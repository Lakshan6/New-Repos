package org.bel.qm.entity;

/** QM-CAL-012: review status of a calibration certificate. */
public enum CertificateApprovalStatus {
    PENDING,
    VERIFIED,
    APPROVED
}
