package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.*;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.ConditionalUseAuthorizationService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequiredArgsConstructor
public class ConditionalUseController {

    private final ConditionalUseAuthorizationService service;

    @PostMapping("/api/v1/equipment/{equipmentId}/conditional-use")
    @ResponseStatus(HttpStatus.CREATED)
    public ConditionalUseResponse request(@PathVariable String equipmentId,
                                           @Valid @RequestBody ConditionalUseRequest request) {
        return service.request(equipmentId, request);
    }

    @RequiresRole({UserRole.QA_MANAGER})
    @PostMapping("/api/v1/conditional-use/{id}/approve")
    public ConditionalUseResponse approve(@PathVariable Long id, @Valid @RequestBody ConditionalUseApproveRequest request) {
        return service.approve(id, request.getApprovedBy());
    }

    @PostMapping("/api/v1/conditional-use/{id}/reject")
    public ConditionalUseResponse reject(@PathVariable Long id, @Valid @RequestBody ConditionalUseRejectRequest request) {
        return service.reject(id, request.getRejectedBy(), request.getReason());
    }

    @PostMapping("/api/v1/conditional-use/{id}/close")
    public ConditionalUseResponse close(@PathVariable Long id) {
        return service.close(id);
    }

    @GetMapping("/api/v1/equipment/{equipmentId}/conditional-use")
    public List<ConditionalUseResponse> history(@PathVariable String equipmentId) {
        return service.history(equipmentId);
    }
}
