package org.bel.qm.controller;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationCertificateResponse;
import org.bel.qm.dto.CalibrationDashboardResponse;
import org.bel.qm.dto.EquipmentResponse;
import org.bel.qm.dto.OotAssessmentResponse;
import org.bel.qm.entity.CertificateApprovalStatus;
import org.bel.qm.service.CalibrationCertificateService;
import org.bel.qm.service.ReportingService;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.web.bind.annotation.*;

import java.time.LocalDate;
import java.util.List;

/** QM-CAL-019: calibration compliance and equipment-risk visibility. */
@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
public class ReportingController {

    private final ReportingService reportingService;
    private final CalibrationCertificateService certificateService;

    @GetMapping("/dashboard")
    public CalibrationDashboardResponse dashboard(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to,
            @RequestParam(defaultValue = "30") int expiringSoonDays) {
        return reportingService.dashboard(from, to, expiringSoonDays);
    }

    @GetMapping("/overdue")
    public List<EquipmentResponse> overdueList() {
        return reportingService.overdueList();
    }

    @GetMapping("/oot")
    public List<OotAssessmentResponse> ootReport(
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate from,
            @RequestParam(required = false) @DateTimeFormat(iso = DateTimeFormat.ISO.DATE) LocalDate to) {
        return reportingService.ootReport(from, to);
    }

    @GetMapping("/certificates")
    public List<CalibrationCertificateResponse> certificateRegister(@RequestParam(required = false) CertificateApprovalStatus status) {
        return certificateService.register(status);
    }
}
