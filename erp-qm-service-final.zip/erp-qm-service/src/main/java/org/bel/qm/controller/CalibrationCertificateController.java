package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ApproveCertificateRequest;
import org.bel.qm.dto.CalibrationCertificateRequest;
import org.bel.qm.dto.CalibrationCertificateResponse;
import org.bel.qm.dto.VerifyCertificateRequest;
import org.bel.qm.entity.UserRole;
import org.bel.qm.security.RequiresRole;
import org.bel.qm.service.CalibrationCertificateService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

@RestController
@RequiredArgsConstructor
public class CalibrationCertificateController {

    private final CalibrationCertificateService certificateService;

    @PostMapping("/api/v1/calibration-records/{calibrationRecordId}/certificate")
    @ResponseStatus(HttpStatus.CREATED)
    public CalibrationCertificateResponse attach(@PathVariable Long calibrationRecordId,
                                                  @Valid @RequestBody CalibrationCertificateRequest request) {
        return certificateService.attach(calibrationRecordId, request);
    }

    @PostMapping("/api/v1/certificates/{certificateId}/verify")
    public CalibrationCertificateResponse verify(@PathVariable Long certificateId,
                                                  @Valid @RequestBody VerifyCertificateRequest request) {
        return certificateService.verify(certificateId, request.getVerifiedBy());
    }

    @RequiresRole({UserRole.QA_MANAGER, UserRole.DOCUMENT_CONTROLLER})
    @PostMapping("/api/v1/certificates/{certificateId}/approve")
    public CalibrationCertificateResponse approve(@PathVariable Long certificateId,
                                                   @Valid @RequestBody ApproveCertificateRequest request) {
        return certificateService.approve(certificateId, request.getApprovedBy());
    }

    @GetMapping("/api/v1/calibration-records/{calibrationRecordId}/certificate")
    public CalibrationCertificateResponse getByRecord(@PathVariable Long calibrationRecordId) {
        return certificateService.getByRecord(calibrationRecordId);
    }

    /** QM-CAL-012: current valid certificate, retrievable directly from the equipment record. */
    @GetMapping("/api/v1/equipment/{equipmentId}/certificate/current")
    public CalibrationCertificateResponse getCurrentForEquipment(@PathVariable String equipmentId) {
        return certificateService.getCurrentForEquipment(equipmentId);
    }
}
