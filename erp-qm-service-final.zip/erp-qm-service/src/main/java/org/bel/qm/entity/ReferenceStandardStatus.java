package org.bel.qm.entity;

/** QM-CAL-013: validity status of a traceable reference standard. */
public enum ReferenceStandardStatus {
    ACTIVE,
    EXPIRED,
    RETIRED
}
