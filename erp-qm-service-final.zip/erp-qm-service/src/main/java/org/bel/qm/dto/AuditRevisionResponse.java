package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.util.Map;

/** QM-CAL-020: one immutable revision in an entity's audit history. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class AuditRevisionResponse {
    private Number revision;
    private Instant timestamp;
    private String username;
    /** ADD, MOD, or DEL. */
    private String changeType;
    /** Scalar field values as of this revision (relations are omitted - see README). */
    private Map<String, Object> snapshot;
}
