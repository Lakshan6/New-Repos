package org.bel.qm.entity;

/**
 * QM-CAL-018: roles referenced across the calibration requirements. Identity
 * and role assignment live upstream (gateway/IdP) - this service trusts the
 * X-User-Id / X-User-Role headers it's handed. See README for wiring notes.
 */
public enum UserRole {
    CALIBRATION_TECHNICIAN,
    CALIBRATION_COORDINATOR,
    QA_ENGINEER,
    QA_MANAGER,
    LAB_MANAGER,
    ASSET_MANAGER,
    PROCUREMENT_USER,
    EXTERNAL_VENDOR,
    PRODUCTION_MANAGER,
    WAREHOUSE_MANAGER,
    DEPARTMENT_MANAGER,
    DOCUMENT_CONTROLLER,
    SYSTEM_ADMINISTRATOR,
    INTERNAL_AUDITOR
}
