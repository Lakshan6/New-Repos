package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Positive;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/** QM-CAL-016: request a bounded, risk-assessed extension of continued use. */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ConditionalUseRequest {

    @NotBlank
    private String justification;

    @NotBlank
    private String riskAssessment;

    @NotNull
    @Positive
    private Integer extensionDays;

    @NotBlank
    private String requestedBy;
}
