package org.bel.qm.controller;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.ApprovedProviderRequest;
import org.bel.qm.dto.ApprovedProviderResponse;
import org.bel.qm.service.ApprovedProviderService;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/approved-providers")
@RequiredArgsConstructor
public class ApprovedProviderController {

    private final ApprovedProviderService service;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    public ApprovedProviderResponse register(@Valid @RequestBody ApprovedProviderRequest request) {
        return service.register(request);
    }

    @PostMapping("/{name}/deactivate")
    public ApprovedProviderResponse deactivate(@PathVariable String name) {
        return service.deactivate(name);
    }

    @GetMapping
    public List<ApprovedProviderResponse> list() {
        return service.list();
    }
}
