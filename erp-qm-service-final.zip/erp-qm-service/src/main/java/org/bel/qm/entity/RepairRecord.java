package org.bel.qm.entity;

import jakarta.persistence.*;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.Instant;
import java.time.LocalDate;

/**
 * QM-CAL-009: adjustment/repair/maintenance action against equipment that
 * failed calibration. Equipment stays BLOCKED through a passing retest
 * (status RETEST_PASSED) - only explicit sign-off here (RETURNED_TO_SERVICE)
 * reactivates it, so a passing recalibration alone can't bypass approval.
 */
@Entity
@org.hibernate.envers.Audited
@Table(name = "repair_record")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class RepairRecord {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "equipment_id", nullable = false)
    private Equipment equipment;

    /** The failed calibration event that triggered this repair. */
    @ManyToOne(fetch = FetchType.LAZY, optional = false)
    @JoinColumn(name = "failed_calibration_record_id", nullable = false)
    private CalibrationRecord failedCalibrationRecord;

    @Column(name = "failure_details", nullable = false, length = 1000)
    private String failureDetails;

    @Column(name = "repair_action", length = 1000)
    private String repairAction;

    @Column(length = 200)
    private String vendor;

    private Double cost;

    @Column(name = "completion_date")
    private LocalDate completionDate;

    /** Set once a post-repair calibration passes and closes this repair. */
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "retest_calibration_record_id")
    private CalibrationRecord retestCalibrationRecord;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false, length = 20)
    private RepairStatus status;

    @Column(name = "approved_by", length = 150)
    private String approvedBy;

    @Column(name = "created_at", nullable = false, updatable = false)
    private Instant createdAt;

    @Column(name = "updated_at", nullable = false)
    private Instant updatedAt;

    @PrePersist
    void onCreate() {
        Instant now = Instant.now();
        this.createdAt = now;
        this.updatedAt = now;
        if (this.status == null) {
            this.status = RepairStatus.OPEN;
        }
    }

    @PreUpdate
    void onUpdate() {
        this.updatedAt = Instant.now();
    }
}
