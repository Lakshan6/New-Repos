package org.bel.qm.repository;

import org.bel.qm.entity.ExternalServiceRequest;
import org.bel.qm.entity.ExternalServiceStatus;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

public interface ExternalServiceRequestRepository extends JpaRepository<ExternalServiceRequest, Long> {
    List<ExternalServiceRequest> findByEquipment_EquipmentIdOrderByCreatedAtDesc(String equipmentId);

    /** QM-CAL-017: a request not yet REACTIVATED/CANCELLED blocks a transfer. */
    Optional<ExternalServiceRequest> findFirstByEquipment_IdAndStatusNotInOrderByCreatedAtDesc(
            Long equipmentId, List<ExternalServiceStatus> closedStatuses);
}
