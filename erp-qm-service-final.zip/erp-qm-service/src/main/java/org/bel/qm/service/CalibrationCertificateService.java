package org.bel.qm.service;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.CalibrationCertificateRequest;
import org.bel.qm.dto.CalibrationCertificateResponse;
import org.bel.qm.entity.CalibrationCertificate;
import org.bel.qm.entity.CalibrationRecord;
import org.bel.qm.entity.CertificateApprovalStatus;
import org.bel.qm.repository.CalibrationCertificateRepository;
import org.bel.qm.repository.CalibrationRecordRepository;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.server.ResponseStatusException;

/** QM-CAL-012: attach, verify and approve a calibration certificate. */
@Service
@RequiredArgsConstructor
public class CalibrationCertificateService {

    private final CalibrationCertificateRepository certificateRepository;
    private final CalibrationRecordRepository recordRepository;

    @Transactional
    public CalibrationCertificateResponse attach(Long calibrationRecordId, CalibrationCertificateRequest request) {
        CalibrationRecord record = recordRepository.findById(calibrationRecordId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "Calibration record not found: " + calibrationRecordId));

        // QM-CAL-012: certificate must match equipment serial number and calibration date.
        if (!record.getEquipment().getSerialNumber().equals(request.getEquipmentSerialNumber())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Certificate equipment serial number does not match the calibration record's equipment");
        }
        if (!record.getCalibrationDate().equals(request.getCalibrationDate())) {
            throw new ResponseStatusException(HttpStatus.BAD_REQUEST,
                    "Certificate calibration date does not match the calibration record");
        }
        if (certificateRepository.findByCalibrationRecord_Id(calibrationRecordId).isPresent()) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "A certificate is already attached to calibration record: " + calibrationRecordId);
        }

        CalibrationCertificate certificate = CalibrationCertificate.builder()
                .calibrationRecord(record)
                .certificateNumber(request.getCertificateNumber())
                .provider(request.getProvider())
                .issueDate(request.getIssueDate())
                .expiryDate(request.getExpiryDate())
                .scope(request.getScope())
                .attachmentReference(request.getAttachmentReference())
                .approvalStatus(CertificateApprovalStatus.PENDING)
                .build();

        return toResponse(certificateRepository.save(certificate));
    }

    @Transactional
    public CalibrationCertificateResponse verify(Long certificateId, String verifiedBy) {
        CalibrationCertificate certificate = getEntity(certificateId);
        certificate.setApprovalStatus(CertificateApprovalStatus.VERIFIED);
        certificate.setVerifiedBy(verifiedBy);
        return toResponse(certificate);
    }

    @Transactional
    public CalibrationCertificateResponse approve(Long certificateId, String approvedBy) {
        CalibrationCertificate certificate = getEntity(certificateId);
        if (certificate.getApprovalStatus() != CertificateApprovalStatus.VERIFIED) {
            throw new ResponseStatusException(HttpStatus.CONFLICT,
                    "Certificate must be verified before it can be approved: " + certificateId);
        }
        // QM-CAL-018 segregation of duties: whoever verified it cannot also approve it.
        if (approvedBy.equalsIgnoreCase(certificate.getVerifiedBy())) {
            throw new ResponseStatusException(HttpStatus.CONFLICT, "Self-approval is not permitted");
        }
        certificate.setApprovalStatus(CertificateApprovalStatus.APPROVED);
        certificate.setApprovedBy(approvedBy);
        return toResponse(certificate);
    }

    @Transactional(readOnly = true)
    public CalibrationCertificateResponse getByRecord(Long calibrationRecordId) {
        return toResponse(certificateRepository.findByCalibrationRecord_Id(calibrationRecordId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No certificate attached to calibration record: " + calibrationRecordId)));
    }

    /** QM-CAL-012 acceptance criteria: the current valid certificate, straight off the equipment record. */
    @Transactional(readOnly = true)
    public CalibrationCertificateResponse getCurrentForEquipment(String equipmentId) {
        return toResponse(certificateRepository
                .findFirstByCalibrationRecord_Equipment_EquipmentIdAndApprovalStatusOrderByIssueDateDesc(
                        equipmentId, CertificateApprovalStatus.APPROVED)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND,
                        "No approved certificate on file for equipment: " + equipmentId)));
    }

    /** QM-CAL-019: certificate register report, optionally filtered by approval status. */
    @Transactional(readOnly = true)
    public java.util.List<CalibrationCertificateResponse> register(CertificateApprovalStatus status) {
        java.util.List<CalibrationCertificate> certificates = status != null
                ? certificateRepository.findByApprovalStatus(status)
                : certificateRepository.findAll();
        return certificates.stream().map(this::toResponse).toList();
    }

    private CalibrationCertificate getEntity(Long certificateId) {
        return certificateRepository.findById(certificateId)
                .orElseThrow(() -> new ResponseStatusException(HttpStatus.NOT_FOUND, "Certificate not found: " + certificateId));
    }

    private CalibrationCertificateResponse toResponse(CalibrationCertificate c) {
        return CalibrationCertificateResponse.builder()
                .id(c.getId())
                .calibrationRecordId(c.getCalibrationRecord().getId())
                .equipmentId(c.getCalibrationRecord().getEquipment().getEquipmentId())
                .certificateNumber(c.getCertificateNumber())
                .provider(c.getProvider())
                .issueDate(c.getIssueDate())
                .expiryDate(c.getExpiryDate())
                .scope(c.getScope())
                .attachmentReference(c.getAttachmentReference())
                .approvalStatus(c.getApprovalStatus())
                .verifiedBy(c.getVerifiedBy())
                .approvedBy(c.getApprovedBy())
                .build();
    }
}
