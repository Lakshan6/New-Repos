package org.bel.qm.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.AllArgsConstructor;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.time.LocalDate;

@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
public class ReceiveCertificateRequest {

    @NotBlank
    private String certificateNumber;

    @NotNull
    private LocalDate certificateIssueDate;

    private LocalDate certificateExpiryDate;

    @NotBlank
    private String certificateAttachmentReference;

    @NotNull
    private LocalDate actualReturnDate;

    private Double actualCost;
}
