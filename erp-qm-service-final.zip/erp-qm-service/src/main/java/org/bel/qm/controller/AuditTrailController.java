package org.bel.qm.controller;

import lombok.RequiredArgsConstructor;
import org.bel.qm.dto.AuditRevisionResponse;
import org.bel.qm.entity.*;
import org.bel.qm.service.AuditTrailService;
import org.bel.qm.service.EquipmentService;
import org.bel.qm.service.ReferenceStandardService;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * QM-CAL-020: searchable, immutable audit trail. Equipment and reference
 * standards are looked up by business key first (their Envers history is
 * keyed on the internal numeric id, same as every other audited entity here).
 */
@RestController
@RequestMapping("/api/v1/audit")
@RequiredArgsConstructor
public class AuditTrailController {

    private final AuditTrailService auditTrailService;
    private final EquipmentService equipmentService;
    private final ReferenceStandardService referenceStandardService;

    @GetMapping("/equipment/{equipmentId}/revisions")
    public List<AuditRevisionResponse> equipmentRevisions(@PathVariable String equipmentId) {
        Long id = equipmentService.getByEquipmentId(equipmentId).getId();
        return auditTrailService.revisionsFor(Equipment.class, id);
    }

    @GetMapping("/calibration-plans/{id}/revisions")
    public List<AuditRevisionResponse> planRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(CalibrationPlan.class, id);
    }

    @GetMapping("/calibration-schedule/{id}/revisions")
    public List<AuditRevisionResponse> scheduleRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(CalibrationSchedule.class, id);
    }

    @GetMapping("/calibration-records/{id}/revisions")
    public List<AuditRevisionResponse> calibrationRecordRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(CalibrationRecord.class, id);
    }

    @GetMapping("/repairs/{id}/revisions")
    public List<AuditRevisionResponse> repairRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(RepairRecord.class, id);
    }

    @GetMapping("/certificates/{id}/revisions")
    public List<AuditRevisionResponse> certificateRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(CalibrationCertificate.class, id);
    }

    @GetMapping("/oot-assessments/{id}/revisions")
    public List<AuditRevisionResponse> ootAssessmentRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(OotAssessment.class, id);
    }

    @GetMapping("/quality-holds/{id}/revisions")
    public List<AuditRevisionResponse> qualityHoldRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(QualityHold.class, id);
    }

    @GetMapping("/reference-standards/{standardId}/revisions")
    public List<AuditRevisionResponse> referenceStandardRevisions(@PathVariable String standardId) {
        Long id = referenceStandardService.get(standardId).getId();
        return auditTrailService.revisionsFor(ReferenceStandard.class, id);
    }

    @GetMapping("/external-service-requests/{id}/revisions")
    public List<AuditRevisionResponse> externalServiceRequestRevisions(@PathVariable Long id) {
        return auditTrailService.revisionsFor(ExternalServiceRequest.class, id);
    }
}
