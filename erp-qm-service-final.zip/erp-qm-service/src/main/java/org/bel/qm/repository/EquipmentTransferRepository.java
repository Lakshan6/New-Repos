package org.bel.qm.repository;

import org.bel.qm.entity.EquipmentTransfer;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;

public interface EquipmentTransferRepository extends JpaRepository<EquipmentTransfer, Long> {
    List<EquipmentTransfer> findByEquipment_EquipmentIdOrderByTransferDateDesc(String equipmentId);
}
