package org.bel.qm.dto;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

/**
 * QM-CAL-010: manual OOT assessment input. Also used internally when the
 * system auto-initiates an assessment for a failed CRITICAL equipment.
 */
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class OotAssessmentRequest {
    private List<String> affectedReferences;
    private String riskAssessment;
    private String containmentAction;
}
