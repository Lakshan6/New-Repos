# erp-qm-service — Calibration Management

Standalone Spring Boot module (package `org.bel.qm`) implementing
**QM-CAL-001 through QM-CAL-020** — the full calibration requirement set.

## Covered requirements

| Req ID | What's implemented |
|---|---|
| QM-CAL-001 | `Equipment` register — unique `equipmentId`/`serialNumber`, register→approve→activate workflow |
| QM-CAL-002 | Classification fields on `Equipment` (category, criticality, range, accuracy, resolution, intended use) |
| QM-CAL-003 | `CalibrationPlan` — interval, method, tolerance, provider; `nextDueDate` auto-calculated on save and on approval |
| QM-CAL-004 | `CalibrationScheduleService.generateWorklist()` — daily cron + on-demand endpoint; skips equipment with an already-open worklist item |
| QM-CAL-005 | Not built out — the schedule/due-date data this would key off is in place, no notification dispatch yet |
| QM-CAL-006 | `EquipmentStatus` (DUE/OVERDUE/BLOCKED/IN_CALIBRATION/ACTIVE/RETIRED), transitioned automatically by the plan-approval, scheduling, record-submission, repair-approval and external-service flows |
| QM-CAL-007 | `CalibrationRecord` + `CalibrationTestResult` — as-found/as-left values per parameter, technician/method/traceable reference standard |
| QM-CAL-008 | Each test point evaluated against the plan's tolerance band; overall record gets PASS/FAIL |
| QM-CAL-009 | `RepairRecord` — adjustment/repair/maintenance against a failed record. A passing retest moves it to `RETEST_PASSED`, but the equipment stays BLOCKED until a separate `approveReturnToService` call — a passing recalibration alone can't reactivate it |
| QM-CAL-010 | `OotAssessmentService.initiateForFailure()` auto-opens an assessment when CRITICAL equipment fails calibration (manual initiation also available for non-critical); tracks last-valid-date, affected references, risk assessment, and disposition |
| QM-CAL-011 | `QualityHold`, always tied to an OOT assessment; `resolve()` refuses to move a hold off `ON_HOLD` until that assessment has an approved disposition |
| QM-CAL-012 | `CalibrationCertificate` — attach→verify→approve, cross-checked against the calibration record's equipment serial number and date; `GET .../certificate/current` returns the latest approved one |
| QM-CAL-013 | `ReferenceStandard` register/retire; `CalibrationRecordService.submit()` rejects a calibration if the chosen standard is expired, retired, or unknown |
| QM-CAL-014 | `ApprovedProvider` registry + `ExternalServiceRequest` lifecycle (request→dispatch→certificate received→verify→reactivate); equipment is IN_CALIBRATION for the duration; provider approval enforced for CRITICAL equipment |
| QM-CAL-015 | `CalibrationLabel` — `generate()` snapshots status/dates/certificate, `issue()` re-validates the snapshot still matches the live record before allowing it |
| QM-CAL-016 | `ConditionalUseAuthorization` — request→approve/reject, auto-expires via a daily scheduled sweep; configurable max extension and a CRITICAL-equipment exclusion |
| QM-CAL-017 | `EquipmentTransfer` history + `Equipment.retire()` (adds `acquisitionDate`/`retirementDate`/`disposalDetails`); transfers blocked while a calibration schedule item, repair, or external service request is open, unless explicitly overridden with an authorizer |
| QM-CAL-018 | Lightweight RBAC: `UserRole` enum + `@RequiresRole` annotation + an interceptor checking `X-User-Role`/`X-User-Id` headers, applied to the sensitive approval endpoints; every decision is logged to `AccessDecisionLog`; explicit self-approval checks (approver ≠ submitter) on certificate approval, repair return-to-service, OOT disposition, and conditional-use approval |
| QM-CAL-019 | `ReportingService` — compliance dashboard (equipment status counts, pass/fail/OOT counts for a date range, open holds, certificates expiring soon), overdue list, OOT report, certificate register |
| QM-CAL-020 | Hibernate Envers on every core entity (`@Audited`), with a custom revision entity that stamps the acting user (from `X-User-Id`) onto each change; `AuditTrailService`/`AuditTrailController` expose per-entity revision history |

`OotDisposition.CONDITIONAL`-equivalent nuance isn't modeled —
`CalibrationResultStatus` only ever resolves to PASS/FAIL, not
CONDITIONAL/OUT_OF_TOLERANCE, even though those enum values exist.


## Structure

```
src/main/java/org/bel/qm/
  entity/      Equipment, CalibrationPlan, CalibrationSchedule,
               CalibrationRecord, CalibrationTestResult, RepairRecord,
               OotAssessment, QualityHold, CalibrationCertificate,
               ReferenceStandard, ExternalServiceRequest, ApprovedProvider,
               CalibrationLabel, ConditionalUseAuthorization,
               EquipmentTransfer, AccessDecisionLog, UserRole + enums
  dto/         request/response objects per endpoint
  repository/  Spring Data JPA interfaces
  service/     one per entity area (see table above)
  controller/  REST endpoints (see below)
  security/    RequiresRole annotation + RoleAccessInterceptor (CAL-018)
  config/      WebConfig - registers the interceptor
  audit/       Envers wiring: custom revision entity/listener + the
               per-request filter that stamps the acting user (CAL-020)
```

This is a bigger footprint than the "simple layered structure" originally
scoped for CAL-001 through CAL-008 - `security`, `config`, and `audit`
didn't fit cleanly into controller/service/repository/entity/dto once RBAC
and audit infrastructure were in scope, so they're separate.

## Endpoints

```
POST   /api/v1/equipment                                    register
POST   /api/v1/equipment/{id}/approve
POST   /api/v1/equipment/{id}/activate
POST   /api/v1/equipment/{id}/retire                        [role: ASSET_MANAGER, QA_MANAGER]
GET    /api/v1/equipment/{id}
GET    /api/v1/equipment?status=&type=

PUT    /api/v1/equipment/{id}/calibration-plan               create/update
POST   /api/v1/equipment/{id}/calibration-plan/approve       [role: QA_MANAGER, LAB_MANAGER]
GET    /api/v1/equipment/{id}/calibration-plan

POST   /api/v1/calibration-schedule/generate                 run worklist generation on demand
GET    /api/v1/calibration-schedule                          list open worklist items
POST   /api/v1/calibration-schedule/{id}/assign

POST   /api/v1/equipment/{id}/calibration-records             submit a calibration execution
GET    /api/v1/equipment/{id}/calibration-records              history

POST   /api/v1/equipment/{id}/repairs                         open a repair against the latest failed record
POST   /api/v1/repairs/{id}/complete                          record repair action/vendor/cost/completion date
POST   /api/v1/repairs/{id}/approve-return-to-service          [role: QA_MANAGER] sign off after a passing retest
GET    /api/v1/equipment/{id}/repairs                          history

POST   /api/v1/calibration-records/{id}/oot-assessments        manual initiation (auto-fires for failed CRITICAL equipment)
POST   /api/v1/oot-assessments/{id}/disposition                 [role: QA_MANAGER] record risk assessment outcome + approver
GET    /api/v1/equipment/{id}/oot-assessments                   history

POST   /api/v1/oot-assessments/{id}/quality-holds               place a hold (requires the OOT reference)
POST   /api/v1/quality-holds/{id}/resolve                       [role: QA_MANAGER, WAREHOUSE_MANAGER] blocked until OOT disposition approved
GET    /api/v1/oot-assessments/{id}/quality-holds                holds for an assessment

POST   /api/v1/calibration-records/{id}/certificate             attach (cross-checked against serial number + date)
POST   /api/v1/certificates/{id}/verify
POST   /api/v1/certificates/{id}/approve                        [role: QA_MANAGER, DOCUMENT_CONTROLLER] requires verify first
GET    /api/v1/calibration-records/{id}/certificate
GET    /api/v1/equipment/{id}/certificate/current                latest approved certificate

POST   /api/v1/reference-standards                              register
POST   /api/v1/reference-standards/{standardId}/retire
GET    /api/v1/reference-standards/{standardId}
GET    /api/v1/reference-standards

POST   /api/v1/approved-providers                              register an approved external provider
POST   /api/v1/approved-providers/{name}/deactivate
GET    /api/v1/approved-providers

POST   /api/v1/equipment/{id}/external-service-requests         open a request
POST   /api/v1/external-service-requests/{id}/dispatch
POST   /api/v1/external-service-requests/{id}/certificate       receive the returned certificate
POST   /api/v1/external-service-requests/{id}/verify
POST   /api/v1/external-service-requests/{id}/reactivate         [role: QA_MANAGER]
POST   /api/v1/external-service-requests/{id}/cancel
GET    /api/v1/equipment/{id}/external-service-requests          history

POST   /api/v1/equipment/{id}/labels                            generate (snapshots current state)
POST   /api/v1/labels/{id}/issue                                 re-validates snapshot before issuing
GET    /api/v1/equipment/{id}/labels/current                     what a scan resolves to
GET    /api/v1/equipment/{id}/labels                             history

POST   /api/v1/equipment/{id}/conditional-use                   request an extension
POST   /api/v1/conditional-use/{id}/approve                      [role: QA_MANAGER]
POST   /api/v1/conditional-use/{id}/reject
POST   /api/v1/conditional-use/{id}/close
GET    /api/v1/equipment/{id}/conditional-use                    history

POST   /api/v1/equipment/{id}/transfers                          relocate / change custodian
GET    /api/v1/equipment/{id}/transfers                          history

GET    /api/v1/reports/dashboard?from=&to=&expiringSoonDays=     compliance snapshot
GET    /api/v1/reports/overdue                                   overdue equipment list
GET    /api/v1/reports/oot?from=&to=                             OOT events in range
GET    /api/v1/reports/certificates?status=                      certificate register

GET    /api/v1/audit/equipment/{equipmentId}/revisions           full revision history (who/when/what changed)
GET    /api/v1/audit/calibration-records/{id}/revisions
GET    /api/v1/audit/repairs/{id}/revisions
GET    /api/v1/audit/certificates/{id}/revisions
GET    /api/v1/audit/oot-assessments/{id}/revisions
GET    /api/v1/audit/quality-holds/{id}/revisions
GET    /api/v1/audit/reference-standards/{standardId}/revisions
GET    /api/v1/audit/external-service-requests/{id}/revisions
GET    /api/v1/audit/calibration-plans/{id}/revisions
GET    /api/v1/audit/calibration-schedule/{id}/revisions
```

Note: `CalibrationRecordRequest` now takes a `referenceStandardId` (the
business key of a registered `ReferenceStandard`) instead of free text —
register standards via the endpoints above before submitting calibrations.

## RBAC (QM-CAL-018) — how it actually works here

This service doesn't authenticate anyone itself. It trusts two headers set
by whatever sits in front of it (API gateway / IdP-issued JWT already
validated upstream, etc.):

- `X-User-Id` — the acting user, recorded on access-decision and audit logs
- `X-User-Role` — one of the `UserRole` enum values; checked against the
  `@RequiresRole(...)` on the endpoints listed above

Every decision (allowed or denied) is written to `AccessDecisionLog`. Before
relying on this in production, wire your real auth layer to populate those
two headers - right now anyone who can reach this service and set an
`X-User-Role` header gets through, which is fine for local dev but not a
substitute for actual authentication.

## Audit trail (QM-CAL-020) — how it actually works here

Every core entity is `@Audited` (Hibernate Envers), and a custom revision
entity (`QmRevisionEntity`) stamps the acting user from `X-User-Id` onto
each revision via a servlet filter + `RevisionListener`. `AuditTrailService`
queries that history generically by reflecting over each entity's scalar
fields (skipping `@ManyToOne`/`@OneToMany`/`@OneToOne`/`@ElementCollection`
relations, to sidestep lazy-loading issues) - so audit responses show field
values as of each revision, but not a resolved view of related entities at
that point in time. For that, cross-reference against the related entity's
own revision history using its timestamp.

## Before this builds in your reactor

1. **`pom.xml` parent** — currently points at `spring-boot-starter-parent`
   directly. Swap in your actual `erp-services` reactor parent (whatever
   `erp-plm-service` / `pf-mdms-service` use) so versions and shared deps
   stay consistent, and add this module to the reactor's `<modules>`.
2. **DB driver/schema** — `application.yml` assumes Postgres and
   `ddl-auto: update`; point it at your real datasource and swap to
   Flyway/Liquibase if that's the convention elsewhere in the reactor.
3. **Cross-service conventions** — `erp-plm-service` has `client`,
   `orchestrator`, `document`, `workflow`, `exception` packages that this
   module deliberately skipped for a first pass. If QM needs to call PLM/MDMS
   (e.g. equipment master data lookup) or needs custom exception handling,
   those packages are where that would go.
4. No `@ControllerAdvice`/global exception handler yet — validation and
   business-rule failures currently surface as Spring's default error body
   via `ResponseStatusException`. Add one if the reactor has a standard
   error-response shape to match.
5. **Hibernate Envers** — `ddl-auto: update` will create the `*_AUD` history
   tables and `REVINFO`-equivalent (`qm_revision_entity`, named by class)
   automatically on first boot against a fresh schema. If you switch to
   Flyway/Liquibase per point 2, generate migrations for those tables too.
6. **RBAC/audit headers aren't populated by anything yet** — see the RBAC
   and audit sections above. Until your gateway/auth layer sets `X-User-Id`
   / `X-User-Role`, every `@RequiresRole`-guarded endpoint will 403 and every
   audit revision's `username` will be null.


---
## Running behind the pf gateway (local setup)
- Port 8172, context path `/erp-qm-service` (see application.yml); gateway route `erp-qm-service` -> http://localhost:8172.
- `sql/erp_qm_schema.sql`: PostgreSQL schema (run once on an empty `erp_qm` database; keep `ddl-auto: update` for the first start).
- `sql/qm_api_endpoints.csv`: all 68 API paths for the gateway `api_resource` table.
- Replace the whole `src/main/java/org/bel/qm` tree when upgrading; mixing versions causes errors such as
  `column reference_standard does not exist`.
