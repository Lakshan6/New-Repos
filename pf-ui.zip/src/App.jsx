import { Chart } from 'chart.js';
import { PrimeReactProvider } from 'primereact/api';
import { QueryClientProvider } from '@tanstack/react-query';
import { queryClient, LOCALISATION_MODULES } from '@shared/utils';
import { ErrorBoundary } from 'react-error-boundary';
import { ErrorPage } from '@shared/screens';
import {
    AuthProvider,
    ConfirmDialogProvider,
    LayoutProvider,
    TranslationProvider,
    SuspenseFallback,
} from '@shared/components';
import { ToastProvider } from '@shared/components/Toast';
import { translationsAtom } from '@shared/store';
import { Suspense } from 'react';
import { ReactQueryDevtools } from '@tanstack/react-query-devtools';
import { RouterProvider } from 'react-router';
import { Router } from '@shared/routes/Router';
import ChartDataLabels from 'chartjs-plugin-datalabels';
import 'primeflex/primeflex.css';
import 'primeicons/primeicons.css';
import '@shared/styles/layout.scss';
import './App.css';

Chart.register(ChartDataLabels);

function App() {
    return (
        <QueryClientProvider client={queryClient}>
            <ErrorBoundary FallbackComponent={ErrorPage}>
                <PrimeReactProvider>
                    <AuthProvider>
                        <LayoutProvider>
                            <TranslationProvider
                                module={LOCALISATION_MODULES.COMMON}
                                translationsAtom={translationsAtom}
                            >
                                <ToastProvider>
                                    <ConfirmDialogProvider>
                                        <Suspense fallback={<SuspenseFallback />}>
                                            <RouterProvider router={Router} />
                                        </Suspense>
                                    </ConfirmDialogProvider>
                                </ToastProvider>
                            </TranslationProvider>
                        </LayoutProvider>
                    </AuthProvider>
                </PrimeReactProvider>
                {import.meta.env.DEV && <ReactQueryDevtools initialIsOpen={false} />}
            </ErrorBoundary>
        </QueryClientProvider>
    );
}

export default App;
