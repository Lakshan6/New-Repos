import { atom } from "jotai";

const translationsAtom = atom({});

export { translationsAtom };
