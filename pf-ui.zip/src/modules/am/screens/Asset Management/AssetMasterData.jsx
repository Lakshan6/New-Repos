import { useMutationApi, useReadApi } from "@shared/hooks";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { InputText } from "primereact/inputtext";
import { useEffect, useMemo, useRef, useState } from "react";
import { TabPanel, TabView } from "primereact/tabview";
import { Checkbox } from "primereact/checkbox";
import { set, get } from "lodash";
import { DataTable } from "primereact/datatable";
import { Column } from 'primereact/column';
import { Controller, useForm } from "react-hook-form";
import { Calendar } from "primereact/calendar";
import { toast } from "@modules/document-library/utils/toast";

const unwrapList = (response) => {
  const data = response?.data ?? response ?? null;
  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.content)) return data.content;
  return [];
};

const AssetMasterData = ({ initialData, isEdit }) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken] );
  const [activeIndex, setActiveIndex] = useState(0);
  const [open, setOpen] = useState(false);
  console.log("initialData", initialData);
   console.log("isedit", isEdit);
  const isEditMode = isEdit;
  const { reset,control } = useForm();
  
  const [formData, setFormData] = useState({
    // asset: "",
    // companyCode: "",
    // assetClass: "",
     asset: initialData?.asset || "",
    assetClass: initialData?.assetClass || "",
    companyCode: initialData?.companyCode || "",
    subNumber: initialData?.subNumber || "",

    generalData: {
      description: "",
      assetMainNoText: "",
      acctDetermination: "",
      serialNo: "",
      inventoryNo: "",
      quantity: "",
      quantity1: "",
      mngHist: false,
      lastInventoryOn: "",
      inventoryList: false,
      inventoryNote: "",
      // capitalizedOn: "",
      // deactivationOn: "",
      // firstAcquisitionOn: "",
      // acquisitionYear: "",
      // acquisitionYear1: "",
      // materialNo: "",
      initialAssetId: initialData?.id
    },

    // timeDependent: {
    //   businessArea: "",
    //   costCenter: "",
    //   activityType: "",
    //   plant: "",
    //   location: "",
    //   room: "",
    //   personnelNo: "",
    //   wbsElementCosts: "",
    //   profitCenter: "",
    //   segment: "",
    //   initialAssetId: initialData?.id
    // },

    // allocations: {
    //   evaluationGrp1: "",
    //   evaluationGrp2: "",
    //   evaluationGrp3: "",
    //   evaluationGrp4: "",
    //   evaluationGrp5: "",
    //   investmentReason: "",
    //   assetSuperNo: "",
    //    initialAssetId: initialData?.id
    // },

    origin: {
      vendor1: "",
      vendor2: "",
      manufacturer: "",
      assetPurchasedNew: "",
      purchasedUsed: "",
      tradingPartner: "",
      countryOfOrigin: "",
      typeName: "",
      originalAsset: "",
      originalAsset1: "",
      acquisitionOn: "",
      originalAcquisYear: "",
      originalValue: "",
      inHouseProdPerc: "",
      // investmentOrder: "",
       initialAssetId: initialData?.id
    },

    // indiaSpecificData: {
    //   blockKey: "",
    //   putToUseDate: "",
    //   additionalBlockKey: "",
    //    initialAssetId: initialData?.id
    // },

    // leasing: {

    // },

    // depreciationAreas: [
    //   { id: null, deact: false, asset: '', description: '', dKey: '', useLife: '', prd: '', oDepStart: '', index: '' },
    // ],

  });
  const [filteredOptions, setFilteredOptions] = useState([]);
  
  const handleInputChange = (_e, field, value = null) => {
    const val = value !== null ? value : e.target.value;
    console.log("Selected Value:", value);
    console.log("Type of Value:", typeof value);
    console.log("Current Form State:", FormData[field]);
    
    setFormData((prev) => {
      const newState = { ...prev };
      set(newState, field, val);
      return newState;
    });
  };
  const [loading, setLoading] = useState(false); // Add this to track API status

  const onSaveError = (error) => {
  const message = error?.response?.data?.message || error?.message || 'Failed to save Asset data.';
    alert(message);
  };

  const searchOptions = (query) => {
    let filtered = classOptions.filter((option) => {  // Filter your classOptions based on what the user typed
      return option.assetClass.toLowerCase().includes(query.toLowerCase());
    });
    setFilteredOptions(filtered);
  };
const asDateText = (value) => {
  if (!value) return '';
  return String(value).slice(0, 10);
};

  const { mutate: createAssetData, isPending: isCreatePending } = useMutationApi({
    service: 'am',
    endpoint: isEditMode? (`/asset/updateAsset/${initialData?.asset}/${initialData?.subNumber}/${initialData?.companyCode}`):('/asset/save'),
    method: isEditMode? 'PATCH':'POST',
    headers: authHeaders,
    options: {
    // This runs when the API succeeds
      onSuccess: (data) => {
        console.log("Save Successful:", data);
        toast.success("submitted successfully");
        setActiveIndex(1); // Move to next tab
      },
    
    // This runs when the API fails
      onError: (error) => {
        console.error("Save Error:", error);
        alert("Failed to save: " + (error?.response?.data?.message || error.message));
      }
    }
  });


  const handleNext = () => {
    // 1. Validation
    const isFormValid = formData.assetClass;
    // if (!isFormValid) {
    //   alert("Please fill in all required fields before proceeding.");
    //   return;
    // }
 const cleanData = JSON.parse(JSON.stringify(formData));

  // 3. Helper function to convert Date objects to YYYY-MM-DD strings
  const formatDateForJava = (dateInput) => {
    if (!dateInput) return null;
    const date = new Date(dateInput);
    // This extracts only the YYYY-MM-DD part
    return date.toISOString().split('T')[0]; 
  };

  // 4. Manually fix the date fields that are causing the error
  // Note: Use the exact paths to your date fields in your formData object
    cleanData.generalData.lastInventoryOn = formatDateForJava(formData.generalData.lastInventoryOn);
     cleanData.generalData.capitalizedOn = formatDateForJava(formData.generalData.capitalizedOn);
    // 2. Call the mutation function from the hook
    // Pass the formData as the argument
    createAssetData(cleanData);
  };

  const { data: classResponse, isFetching, error } = useReadApi({
    service: "am",
    endpoint: "",
    headers: authHeaders,
    options: {
      enabled: Boolean(authToken)
    }
  });
  const classOptions = useMemo(() => unwrapList(classResponse), [classResponse]);
  
  // const RowStyle = { display: 'flex', alignItems: 'center', gap: '2rem', width: '45%', marginBottom: '15px', justifyContent: 'space-between' };
  // const LabelStyle = { fontSize: '1rem', minWidth: '150px' };
  // const InputStyle = { width: '50%' };
  const isInitialized = useRef(false);
   useEffect(() => {
  if (!initialData) return;

  setFormData((prev) => ({
    ...prev,


    asset: initialData.asset ?? "",
    assetClass: initialData.assetClass ?? "",
    companyCode: initialData.companyCode ?? "",
    subNumber: initialData.subNumber ?? "",
    generalData: {
      ...prev.generalData,
      description: initialData.generalData?.description ?? "",
      assetMainNoText: initialData.generalData?.assetMainNoText ?? "",
      acctDetermination: initialData.generalData?.acctDetermination ?? "",
      serialNo: initialData.generalData?.serialNo ?? "",
      inventoryNo: initialData.generalData?.inventoryNo ?? "",
      quantity: initialData.generalData?.quantity ?? "",
      lastInventoryOn: initialData.generalData?.lastInventoryOn
        ? new Date(initialData.generalData.lastInventoryOn)
        : null,
      inventoryNote: initialData.generalData?.inventoryNote ?? "",
      capitalizedOn: initialData.generalData?.capitalizedOn
        ? new Date(initialData.generalData.capitalizedOn)
        : null,
      firstAcquisitionOn: initialData.generalData?.firstAcquisitionOn
        ? new Date(initialData.generalData.firstAcquisitionOn)
        : null,
      acquisitionYear: initialData.generalData?.acquisitionYear ?? "",
      materialNo: initialData.generalData?.materialNo ?? "",
    },

    timeDependent: {
      ...prev.timeDependent,
      ...initialData.timeDependent,
    },

    allocations: {
      ...prev.allocations,
      ...initialData.allocations,
    },

    origin: {
      ...prev.origin,
      vendor1: initialData.origin?.vendor1 ?? "",
       vendor2: initialData.origin?.vendor2 ?? "",
      manufacturer: initialData.origin?.manufacturer ?? "",
      countryOfOrigin: initialData.origin?.country ?? "",
      typeName: initialData.origin?.typeName ?? "",
      originalAsset: initialData.origin?.originalAsset ?? "",
      originalValue: initialData.origin?.originalValue ?? "",
      inHouseProdPerc: initialData.origin?.inHouseProdPerc ?? "",
      investmentOrder: initialData.origin?.investmentOrder ?? "",
      acquisitionOn: initialData.origin?.acquisitionOn ? moment(initialData.origin?.acquisitionOn).format("DD-MM-yyyy"): "",
      tradingPartner: initialData.origin?.tradingPartner ?? "",
      originalAcquisYear: initialData.origin?.originalAcquisYear ?? "",
    },
  }));
}, [initialData]);

useEffect(() => {
    // If the equipment ID changes, allow re-initialization
    isInitialized.current = false;
}, [initialData?.asset]); 
  return (
    <>
      <div className="sap-section-wrapper"
        style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px' }}>
        <label style={{ fontSize: '1rem' }}>Asset</label>
        <InputText 
          style={{ width: '25%', }} 
          value={initialData?.asset}
          onChange={(e) => handleInputChange(e, 'asset', e.target.value)}
        />
      </div>
      <div >
        <div style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '60%', marginBottom: '20px', justifyContent: 'space-between' }}>
          <label style={{ fontSize:'1 rem' }}>Class</label>
          <InputText 
            style={{ width: '35%',marginRight:'350px' }} 
            value={initialData?.assetClass}
            onChange={(e) => handleInputChange(e, 'assetClass', e.target.value)}
          />
          {/* <label style={{ fontSize:'1 rem' }}>{formData.assetClass}</label> */}
          <label style={{ fontSize:'1 rem',marginRight:'80px' }}>Company Code</label>
          <InputText 
            style={{ width: '35%', }} 
            value={initialData?.companyCode}
            onChange={(e) => handleInputChange(e, 'companyCode', e.target.value)}
          />
        </div>
      </div>
      <div>
        <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
          {/* TAB 1: GENERAL DATA SCREEN */}
          <TabPanel header="General">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                General Data
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Description</label>
                <InputText 
                  style={{ width: '60%', }} 
                  value={formData.generalData.description}
                  onChange={(e) => handleInputChange(e, 'generalData.description', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Asset Main No. Text</label>
                <InputText 
                  style={{ width: '60%', }} 
                  value={formData.generalData.assetMainNoText}
                  onChange={(e) => handleInputChange(e, 'generalData.assetMainNoText', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '26.5%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Acct Determination</label>
                <InputText 
                  style={{ width: '25%', }} 
                  value={formData.generalData.acctDetermination}
                  onChange={(e) => handleInputChange(e, 'generalData.acctDetermination', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '33%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Serial No. </label>
                <InputText 
                  style={{ width: '40%', }} 
                  value={formData.generalData.serialNo}
                  onChange={(e) => handleInputChange(e, 'generalData.serialNo', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Inventory No. </label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.generalData.inventoryNo}
                  onChange={(e) => handleInputChange(e, 'generalData.inventoryNo', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '57%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Quantity</label>
                <div style={{ width: '65%', display: 'flex', alignItems: 'center', gap: '2rem' }}> 
                  <InputText 
                    style={{ width: '50%', }} 
                    value={formData.generalData.quantity}
                    onChange={(e) => handleInputChange(e, 'generalData.quantity', e.target.value)}
                  />
                  <InputText 
                    style={{ width: '10%', paddingLeft: '20px' }} 
                    value={formData.generalData.quantity1}
                    onChange={(e) => handleInputChange(e, 'generalData.quantity1', e.target.value)}
                  />
                </div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px' }}>
                <Checkbox
                  onChange={(e) => handleInputChange(e, 'generalData.mngHist', e.checked)}
                  checked={formData.generalData.mngHist} />
                <label style={{ fontSize: '1rem' }}>Manage Historically</label>
              </div>

              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Inventory
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '65%', marginBottom: '20px', justifyContent: 'space-between' }}>
                 <label style={{ fontSize: '1rem' }}>Last Inventory on</label>
                {/* <InputText 
                  style={{ width: '25%', }} 
                  value={formData.generalData.lastInventoryOn}
                  onChange={(e) => handleInputChange(e, 'generalData.lastInventoryOn', e.target.value)}
                /> */}
                 
  <div style={{marginRight:'40px'}} >
    <Calendar
      value={formData.generalData.lastInventoryOn}
      onChange={(e) => handleInputChange(e, 'generalData.lastInventoryOn', e.value)}
      dateFormat="dd-mm-yy"
      showIcon
      placeholder="Select Date"
      style={{ width: '60%' }}
      inputStyle={{ width: '100%' }} 
    />
  </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
                  <Checkbox
                    onChange={(e) => handleInputChange(e, 'generalData.inventoryList', e.checked)}
                    checked={formData.generalData.inventoryList}
                  />
                  <label>Include asset in inventory list</label>
                </div>
              </div>
              
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Inventory Note</label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.generalData.inventoryNote}
                  onChange={(e) => handleInputChange(e, 'generalData.inventoryNote', e.target.value)}
                />
              </div>

              {/* <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Posting Information
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '100%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Capitalized on</label>
               
                  <div style={{marginRight:"80px"}}>
    <Calendar
      value={formData.generalData.capitalizedOn}
      onChange={(e) => handleInputChange(e, 'generalData.capitalizedOn', e.value)}
      dateFormat="dd-mm-yy"
      showIcon
      placeholder="Select Date"
      style={{ width: '60%' }}
      inputStyle={{ width: '100%' }} 
    />
  </div>
                <label style={{ fontSize: '1rem' }}>Deactivated on</label>
                  <div >
    <Calendar
      value={formData.generalData.deactivationOn}
      onChange={(e) => handleInputChange(e, 'generalData.deactivationOn', e.value)}
      dateFormat="dd-mm-yy"
      showIcon
      placeholder="Select Date"
      style={{ width: '40%',marginRight:"170px" }}
      
    />
  </div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>First Acquisition on</label>
              
                  <div style={{marginRight:"80px"}} >
                     <Calendar
                      value={formData.generalData.firstAcquisitionOn}
                      onChange={(e) => handleInputChange(e, 'generalData.firstAcquisitionOn', e.value)}
                      dateFormat="dd-mm-yy"
                      showIcon
                      placeholder="Select Date"
                      style={{ width: '60%' }}
                      inputStyle={{ width: '100%' }} 
                    />
                 </div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Acquisition year</label>
                <div style={{ width: '50%', display: 'flex', alignItems: 'center', gap: '2rem' }}>
                  <InputText 
                    style={{ width: '35%', }} 
                    value={formData.generalData.acquisitionYear}
                    onChange={(e) => handleInputChange(e, 'generalData.acquisitionYear', e.target.value)}
                  />
                  <InputText 
                    style={{ width: '35%', }}  
                    value={formData.generalData.acquisitionYear1}
                    onChange={(e) => handleInputChange(e, 'generalData.acquisitionYear1', e.target.value)}
                  />
                </div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Material Number</label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.generalData.materialNo}
                  onChange={(e) => handleInputChange(e, 'generalData.materialNo', e.target.value)}
                />
              </div> */}
              {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isCreatePending ? "Saving..." : "Next"} 
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
            </div> */}
            </Card>
          </TabPanel>

          {/* TAB 2: TIME DEPENDENT SCREEN */}
          {/* <TabPanel header="Time-Dependent">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Interval from{ }
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '25%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Business Area</label>
                <InputText 
                  style={{ width: '20%',marginLeft:'230px' }} 
                  value={formData.timeDependent.businessArea}
                  onChange={(e) => handleInputChange(e, 'timeDependent.businessArea', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Cost Center</label>
                <InputText 
                  style={{ width: '35%', }} 
                  value={formData.timeDependent.costCenter}
                  onChange={(e) => handleInputChange(e, 'timeDependent.costCenter', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '28%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Activity Type</label>
                <InputText 
                  style={{ width: '28%', }} 
                  value={formData.timeDependent.activityType}
                  onChange={(e) => handleInputChange(e, 'timeDependent.activityType', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '25%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Plant</label>
                <InputText 
                  style={{ width: '30%',marginLeft:'285px' }} 
                  value={formData.timeDependent.plant}
                  onChange={(e) => handleInputChange(e, 'timeDependent.plant', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Location</label>
                <InputText 
                  style={{ width: '35%', }} 
                  value={formData.timeDependent.location}
                  onChange={(e) => handleInputChange(e, 'timeDependent.location', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '29%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Room</label>
                <InputText 
                  style={{ width: '31%', marginLeft:'280px'}} 
                  value={formData.timeDependent.room}
                  onChange={(e) => handleInputChange(e, 'timeDependent.room', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '29%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Personnel Number</label>
                <InputText 
                  style={{ width: '31%', marginLeft:'195px' }} 
                  value={formData.timeDependent.personnelNo}
                  onChange={(e) => handleInputChange(e, 'timeDependent.personnelNo', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>WBS Element (Costs)</label>
                <InputText 
                  style={{ width: '50%',marginLeft:'178px' }} 
                  value={formData.timeDependent.wbsElementCosts}
                  onChange={(e) => handleInputChange(e, 'timeDependent.wbsElementCosts', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Profit Center</label>
                <InputText 
                  style={{ width: '35%', }} 
                  value={formData.timeDependent.profitCenter}
                  onChange={(e) => handleInputChange(e, 'timeDependent.profitCenter', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Segment</label>
                <InputText 
                  style={{ width: '35%', }} 
                  value={formData.timeDependent.segment}
                  onChange={(e) => handleInputChange(e, 'timeDependent.segment', e.target.value)}
                />
              </div>
              {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isCreatePending ? "Saving..." : "Next"} 
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
            </div> */}
            {/* </Card>
          </TabPanel> */}
          {/* TAB 3: ALLOCATIONS SCREEN */}
          {/* <TabPanel header="Allocations">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Allocations
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '28%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Evaluation Group 1</label>
                <InputText 
                  style={{ width: '28%', }} 
                  value={formData.allocations.evaluationGrp1}
                  onChange={(e) => handleInputChange(e, 'allocations.evaluationGrp1', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '28%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Evaluation Group 2</label>
                <InputText 
                  style={{ width: '28%', }} 
                  value={formData.allocations.evaluationGrp2}
                  onChange={(e) => handleInputChange(e, 'allocations.evaluationGrp2', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '28%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Evaluation Group 3</label>
                <InputText 
                  style={{ width: '28%', }} 
                  value={formData.allocations.evaluationGrp3}
                  onChange={(e) => handleInputChange(e, 'allocations.evaluationGrp3', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '28%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Evaluation Group 4</label>
                <InputText 
                  style={{ width: '28%', }} 
                  value={formData.allocations.evaluationGrp4}
                  onChange={(e) => handleInputChange(e, 'allocations.evaluationGrp4', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Evaluation Group 5</label>
                <InputText 
                  style={{ width: '35%', }} 
                  value={formData.allocations.evaluationGrp5}
                  onChange={(e) => handleInputChange(e, 'allocations.evaluationGrp5', e.target.value)}
                />
              </div>
              <div 
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Investment Reason</label>
                <InputText 
                  style={{ width: '30%',marginRight:'135px' }} 
                  value={formData.allocations.investmentReason}
                  onChange={(e) => handleInputChange(e, 'allocations.investmentReason', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Asset Super Number</label>
                <InputText 
                  style={{ width: '50%', marginLeft:'130px'}} 
                  value={formData.allocations.assetSuperNo}
                  onChange={(e) => handleInputChange(e, 'allocations.assetSuperNo', e.target.value)}
                />
              </div>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Investment support measures
              </div>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Intergration of Assets and Equipment
              </div>
              {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isCreatePending ? "Saving..." : "Next"} 
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
            </div> */}
            {/* </Card>
          </TabPanel>  */}

          {/* TAB 4: ORIGIN SCREEN */}
          <TabPanel header="Origin">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Origin
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '51.5%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <div><label style={{ fontSize: '1rem' }}>Vendor</label></div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
                  <InputText 
                  style={{ width: '35%',marginRight:'70px' }} 
                  value={formData.origin.vendor1}
                  onChange={(e) => handleInputChange(e, 'origin.vendor1', e.target.value)}
                />
                <InputText 
                  style={{ width: '35%', }} 
                  value={formData.origin.vendor2}
                  onChange={(e) => handleInputChange(e, 'origin.vendor2', e.target.value)}
                /></div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Manufacturer</label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.origin.manufacturer}
                  onChange={(e) => handleInputChange(e, 'origin.manufacturer', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px', }}>
                <Checkbox
                  onChange={(e) => handleInputChange(e, 'origin.assetPurchasedNew', e.checked)}
                  checked={formData.origin.assetPurchasedNew}
                />
                <label>Asset Purchased new</label>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px' }}>
                <Checkbox
                  onChange={(e) => handleInputChange(e, 'origin.purchasedUsed', e.checked)}
                  checked={formData.origin.purchasedUsed}
                />
                <label>Purchased used</label>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Trading Partner</label>
                <InputText 
                  style={{ width: '35%',marginRight:'3px' }} 
                  value={formData.origin.tradingPartner}
                  onChange={(e) => handleInputChange(e, 'origin.tradingPartner', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '25%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Country of Origin</label>
                <InputText 
                  style={{ width: '20%', }} 
                  value={formData.origin.countryOfOrigin}
                  onChange={(e) => handleInputChange(e, 'origin.countryOfOrigin', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Type Name</label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.origin.typeName}
                  onChange={(e) => handleInputChange(e, 'origin.typeName', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', width: '80%', marginBottom: '20px', gap: '2rem' }}>
                <div style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '64.5%', justifyContent: 'space-between'}}>
                  <label style={{ fontSize: '1rem' }}>Original Asset</label>
                  <div style={{ display: 'flex', alignItems: 'center', gap: '2rem' }}>
                    <InputText 
                      style={{ width: '50%',marginRight:'70px' }} 
                      value={formData.origin.originalAsset}
                      onChange={(e) => handleInputChange(e, 'origin.originalAsset', e.target.value)}
                    />
                    <InputText 
                      style={{ width: '20%', }} 
                      value={formData.origin.originalAsset1}
                      onChange={(e) => handleInputChange(e, 'origin.originalAsset1', e.target.value)}
                    />
                  </div>
                </div>
                <label style={{ fontSize: '1rem' }}>Acquisition on </label>
                {/* <InputText 
                  style={{ width: '20%', }} 
                  value={formData.origin.acquisitionOn}
                  onChange={(e) => handleInputChange(e, 'origin.acquisitionOn', e.target.value)}
                  
                /> */}
                {/* <Controller
                             name="acquisitionOn" 
                             control={control}
                             render={({ field }) => (
                             <Calendar
                             value={field.acquisitionOn ? new Date(field.acquisitionOn) : null}           
                              onChange={(e) => field.onChange(e.value)} 
                                 dateFormat="dd-mm-yy"
                                  placeholder="Select Date"
                              showIcon
                              style={{ width: '15%' }}  
                            />
                           )}
                />    */}
                <div style={{marginRight:'40px'}} >
    <Calendar
      value={formData.origin.acquisitionOn}
      onChange={(e) => handleInputChange(e, 'origin.acquisitionOn', e.value)}
      dateFormat="dd-mm-yy"
      showIcon
      placeholder="Select Date"
      style={{ width: '60%' }}
      inputStyle={{ width: '100%' }} 
    />
  </div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '28%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Original Acquisition Year</label>
                <InputText 
                  style={{ width: '28%',marginRight:'3px' }} 
                  value={formData.origin.originalAcquisYear}
                  onChange={(e) => handleInputChange(e, 'origin.originalAcquisYear', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Original Value</label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.origin.originalValue}
                  onChange={(e) => handleInputChange(e, 'origin.originalValue', e.target.value)}
                />
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '31%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>In-house Prod. percent</label>
                <InputText 
                  style={{ width: '35%',marginRight:'3px' }} 
                  value={formData.origin.inHouseProdPerc}
                  onChange={(e) => handleInputChange(e, 'origin.inHouseProdPerc', e.target.value)}
                />
              </div>
              {/* <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Account Assignment for Investment
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '40%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Investment Order</label>
                <InputText 
                  style={{ width: '50%', }} 
                  value={formData.origin.investmentOrder}
                  onChange={(e) => handleInputChange(e, 'origin.investmentOrder', e.target.value)}
                />
              </div> */}
              {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isCreatePending ? "Saving..." : "Next"} 
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
            </div> */}
            </Card>
          </TabPanel>

          {/* TAB 5: INDIA SPECIFIC DATA SCREEN */}
          {/* <TabPanel header="India Specific Data">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                General Data
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '80%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Block Key</label>
                <InputText 
                  style={{ width: '20%', }} 
                  value={formData.indiaSpecificData.blockKey}
                  onChange={(e) => handleInputChange(e, 'indiaSpecificData.blockKey', e.target.value)}
                />
                <label style={{ fontSize: '1rem' }}>Put to use date</label>
              
                <div style={{marginRight:"40px"}} >
                     <Calendar
                      value={formData.indiaSpecificData.putToUseDate}
                      onChange={(e) => handleInputChange(e, 'indiaSpecificData.putToUseDate', e.value)}
                      dateFormat="dd-mm-yy"
                      showIcon
                      placeholder="Select Date"
                      style={{ width: '60%' }}
                      inputStyle={{ width: '100%' }} 
                    />
                 </div>
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '33%', marginBottom: '20px', justifyContent: 'space-between' }}>
                <label style={{ fontSize: '1rem' }}>Additional Block Key</label>
                <InputText 
                  style={{ width: '50%',marginRight:'10px' }} 
                  value={formData.indiaSpecificData.additionalBlockKey}
                  onChange={(e) => handleInputChange(e, 'indiaSpecificData.additionalBlockKey', e.target.value)}
                />
              </div>
              {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isCreatePending ? "Saving..." : "Next"} 
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
            </div> */}
            {/* </Card>
          </TabPanel> */}

          {/* TAB 6: LEASING SCREEN */}
          {/* <TabPanel header="Leasing">

          </TabPanel> */}

          {/* TAB 7: DEPRECIATION AREAS SCREEN */}
          {/* <TabPanel header="Depreciation Areas">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              <div
                style={{ backgroundColor: '#ffffff', padding: '10px', border: '1px solid #cccccc', marginBottom: '20px', fontsize: '1.1rem', fontWeight: 'bold' }}>
                Valuation
              </div>
              <div className="sap-section-wrapper"
                style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '80%', marginBottom: '20px'}}>
                <DataTable 
                  value={formData.depreciationAreas} 
                  stripedRows 
                  tableStyle={{ minWidth: '100rem' }}
                  className="p-datatable-sm"
                  responsiveLayout="scroll">
                  <Column header="Deact"
                    headerStyle={{ textAlign: 'center'}}
                    body={(rowData) => (
                    <Checkbox 
                      onChange={(e) => {
                          // Logic to update deact status in formData
                          const updated = formData.depreciationAreas.map(item => 
                              item.id === rowData.id ? {...item, deact: e.checked} : item
                          );
                          setFormData({...formData, depreciationAreas: updated});
                      }} 
                      checked={rowData.deact} 
                    />)}
                    style={{ width: '5rem', textAlign: 'center' }}
                  />
                  <Column field="asset" header="Asset" headerStyle={{ textAlign: 'center'}} style={{ width: '10rem' }} />
                  <Column field="description" header="Depreciation area" headerStyle={{ textAlign: 'center'}} style={{ width: '20rem' }} />
                  <Column field="dKey" header="Depre. Key" headerStyle={{ textAlign: 'center'}} style={{ width: '15rem' }} />
                  <Column field="useLife" header="UseLife" headerStyle={{ textAlign: 'center'}} style={{ width: '15rem' }} />
                  <Column field="prd" header="Prd" headerStyle={{ textAlign: 'center'}} style={{ width: '10rem' }} />
                  <Column field="oDepStart" header="ODep Start" headerStyle={{ textAlign: 'center'}} style={{ width: '20rem' }} />
                  <Column field="index" header="Index" headerStyle={{ textAlign: 'center'}} style={{ width: '10rem' }} />
                </DataTable>
              </div>
              {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isCreatePending ? "Saving..." : "Next"} 
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
              </div>
               */}
            {/* </Card>
          </TabPanel>  */}
          
        </TabView>     
        <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button 
                label={isEditMode ? "update" : "submit"} 
                // icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} 
                onClick={handleNext} 
                loading={isCreatePending} 
                disabled={isCreatePending} 
              />
              </div>
              
      </div>
    </>
  );
}
export default AssetMasterData;