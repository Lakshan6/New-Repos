import { useMutationApi, useReadApi } from "@shared/hooks";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { AutoComplete } from "primereact/autocomplete";
import { InputText } from "primereact/inputtext";
import { useEffect, useMemo, useState } from "react";
import AssetMasterData from "./AssetMasterData";
import { TabPanel, TabView } from "primereact/tabview";
import { Checkbox } from "primereact/checkbox";


const unwrapResponse = (response) => response?.data ?? response ?? null;

const unwrapList = (response) => {
  const data = unwrapResponse(response);

  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.content)) return data.content;

  return [];
};

// const AssetInitialScreen = () => {
//     const authToken = localStorage.getItem('authToken') ?? '';
//     const authHeaders = useMemo(
//     () => ({
//       Authorization: `Bearer ${authToken}`
//     }),
//     [authToken]
//   );
//   const [formData, setFormData] = useState({
//     assetClass: "",
//     companyCode: "",
//     similarAssets: "",
//     asset: "",
//     subNumber: ""
//     });
//   const [activeIndex, setActiveIndex] = useState(0);
//   const [filteredOptions, setFilteredOptions] = useState([]);
//   const handleInputChange = (_e, field, value = null) => {
//     console.log("Selected Value:", value);
//     console.log("Type of Value:", typeof value);
//     console.log("Current Form State:", formData[field]);
    
//     setFormData((prev) => ({
//       ...prev,
//       [field]: value
//     }));
//   };
//   const [loading, setLoading] = useState(false); // Add this to track API status
  
//   const onSaveError = (error) => {
//     const message = error?.response?.data?.message || error?.message || 'Failed to save Asset data.';
//     alert(message);
//   };

//   const searchOptions = (query) => {
//     let filtered = classOptions.filter((option) => {  // Filter your classOptions based on what the user typed
//       return option.assetClass.toLowerCase().includes(query.toLowerCase());
//     });
//     setFilteredOptions(filtered);
//   };

// const { mutate: createAssetData, isPending: isCreatePending } = useMutationApi({
//   service: 'am',
//   endpoint: '/asset/create',
//   method: 'POST',
//   headers: authHeaders,
//   options: {
//     // This runs when the API succeeds
//     onSuccess: (data) => {
//       console.log("Save Successful:", data);
//       setActiveIndex(1); // Move to next tab
//     },
//     // This runs when the API fails
//     onError: (error) => {
//       console.error("Save Error:", error);
//       alert("Failed to save: " + (error.message || "Server Error"));
//     }
//   }
// });

// const handleNext = () => {
//   // 1. Validation
//   if (!formData.assetClass) {
//     alert("Please fill in all required fields before proceeding.");
//     return;
//   }

//   // 2. Call the mutation function from the hook
//   // Pass the formData as the argument
//   createAssetData(formData);
// };

// const { data: classResponse, isFetching, error } = useReadApi({
//   service: "am",
//   endpoint: "",
//   headers: authHeaders,
//   options: {
//     enabled: Boolean(authToken)
//   }
// });
// const classOptions = useMemo(() => unwrapList(classResponse), [classResponse]);
// return (
//   <div className="material-container" style={{width:'100%',alignContent:'center'}}>
//     <div style={{backgroundColor: '#ffffff',
//       padding: '10px',
//       border: '1px solid #cccccc',
//       marginBottom: '20px',
//       fontsize: '1.1rem',
//       fontWeight: 'bold'
//     }}>
//       Create Asset
//     </div>
//     <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
//       {/* TAB 1: INITIAL SCREEN */}
//       <TabPanel  header="Initial Details">
//         <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa'}}>
//           <div
//             className="sap-section-wrapper"
//             style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom:'20px'}}>
//             <label style={{ fontSize: '1rem' }}>Asset Class</label>
//             <AutoComplete
//               aria-label="Select or Enter Class"
//               value={formData.assetClass} // Use value from formData
//               suggestions={filteredOptions} // options comes from your classOptions array
//               completeMethod={searchOptions}
//               onChange={(e) => handleInputChange(e, 'assetClass', e.value)}
//               optionLabel="assetClass"
//               placeholder="Select or Enter Class"
//               style={{ width: '30%', paddingLeft: '100px' }}
//               className="small-input"
//               forceSelection={false} // This allows the user to type whatever they want
//             />
//           </div>
//           <div
//             className="sap-section-wrapper"
//             style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '20%', marginBottom:'20px', justifyContent: 'space-between' }}>
//             <label style={{ fontSize:'1 rem' }}>Company Code</label>
//             <InputText
//               style={{ width: '35%' }}
//               value={formData.companyCode}
//               onChange={(e) => handleInputChange(e, 'companyCode', e.target.value)}
//             />
//           </div>
//           <div
//             className="sap-section-wrapper"
//             style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '20%', marginBottom:'20px', justifyContent: 'space-between' }}>
//             <label style={{ fontsize: '1rem' }}>No. of Similar Assets</label>
//             <InputText
//               style={{ width: '35%' }}
//               value={formData.similarAssets}
//               onChange={(e) => handleInputChange(e, 'similarAssets', e.target.value)}
//             />
//           </div>
          
//           <div className="sap-section-wrapper" style={{ padding: '2px', backgroundColor: '#f8f9fa' }}>
//             <div style={{
//               backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px',
//               boxShadow: '0 2px 4px rgba(0,0,0,0.05)', overflow: 'hidden', marginBottom: '20px' // Space between cards
//             }}>
//             <div style={{ padding: '10px 15px', borderBottom: '1px solid #dee2e6', backgroundColor: '#fdfdfd' }}>
//               <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: '600', color: '#333' }}>Reference</h3>
//             </div>
//             <div  style={{ padding: '20px 15px'}}>
//               <label style={{ fontSize: '1rem',marginRight:'170px' }}>Asset</label>
//               <InputText style={{ width: '20%' }} value={formData.asset}
//                 onChange={(e) => handleInputChange(e, 'asset', e.target.value)}
//               />
//             </div>
//             <div style={{ padding: '20px 15px' }}>
//               <label style={{ fontSize: '1rem',marginRight:'120px' }}>Sub-Number</label>
//               <InputText style={{ width: '10%' }} value={formData.subNumber}
//                 onChange={(e) => handleInputChange(e, 'subNumber', e.target.value)}
//               />
//             </div>
//             <div style={{ padding: '20px 15px' }}>
//               <label style={{ fontSize: '1rem',marginRight:'100px' }}>Company Code</label>
//               <InputText style={{ width: '10%' }} value={formData.companyCode}
//                 onChange={(e) => handleInputChange(e, 'companyCode', e.target.value)}
//               />
//             </div>
//               </div>
//             </div>
            
//             <div style={{ marginTop: '20px', textAlign: 'right' }}>
//               <Button
//                 label={isCreatePending ? "Saving..." : "Next"}
//                 icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"}
//                 onClick={handleNext}
//                 loading={isCreatePending}
//                 disabled={isCreatePending}
//               />
//             </div>
//           </Card>
//         </TabPanel>
//         {/* TAB 2: MASTER SCREEN */}
//         <TabPanel header="Master Data" >
//           <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa'}}>
//               <AssetMasterData initialData={formData} />
//           </Card>
//         </TabPanel>
//       </TabView>
//     </div>
//   );
// }
const AssetInitialScreen = () => {
  // --- NEW STATE FOR MODE ---
  const [mode, setMode] = useState('create'); // 'create' or 'change'
  
  const authToken = localStorage.getItem('authToken') ?? '';
  const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);
  
  const [formData, setFormData] = useState({
    assetClass: "",
    companyCode: "",
    similarAssets: "",
    asset: "",
    subNumber: "",
    // companyCodeCheck: true // Added for the checkbox in Change mode
  });
const [changeForm, setChangeForm] = useState({
       asset: "",
    subNumber: "",
      companyCode: "",
    });
  const [activeIndex, setActiveIndex] = useState(0);
  const [filteredOptions, setFilteredOptions] = useState([]);

  const handleInputChange = (_e, field, value = null) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

const [searchTrigger, setSearchTrigger] = useState({asset:"",subNumber:"",companyCode:""}); 
 const searchOptions = (query) => {
    let filtered = classOptions.filter((option) => {  // Filter your classOptions based on what the user typed
      return option.assetClass.toLowerCase().includes(query.toLowerCase());
    });
    setFilteredOptions(filtered);
  };

const { mutate: createAssetData, isPending: isCreatePending } = useMutationApi({
  service: 'am',
  endpoint: '/asset/create',
  method: 'POST',
  headers: authHeaders,
  options: {
    // This runs when the API succeeds
    onSuccess: (data) => {
      console.log("Save Successful:", data);
      setActiveIndex(1); // Move to next tab
    },
    // This runs when the API fails
    onError: (error) => {
      console.error("Save Error:", error);
      alert("Failed to save: " + (error.message || "Server Error"));
    }
  }
});


const handleNext = () => {
  // 1. Validation
  if (!formData.assetClass) {
    alert("Please fill in all required fields before proceeding.");
    return;
  }

  // 2. Call the mutation function from the hook
  // Pass the formData as the argument
  createAssetData(formData);
};
const handleFetchDetails = () => {
        if (!changeForm.asset.trim() || !changeForm.subNumber.trim()) {
            alert("Please enter asset");
            return;
        }
  setSearchTrigger({ asset:changeForm.asset,subNumber:changeForm?.subNumber,companyCode:changeForm?.companyCode });
    };
 const { data: searchResult, isFetching: isFetchingAsset } = useReadApi({
        service: 'am',
        endpoint: `/asset/getAsset/${encodeURIComponent(searchTrigger?.asset)}/${encodeURIComponent(searchTrigger?.subNumber)}/${encodeURIComponent(searchTrigger?.companyCode)}`,
        headers: authHeaders,
        options: { 
            enabled: Boolean(searchTrigger) 
        }
 });
   useEffect(() => {
        if (searchResult) {
            console.log("Data received successfully:", searchResult);
            
            // Step A: Fill the form
          setFormData({
                assetClass:  searchResult.assetClass || "",
                companyCode:  searchResult.companyCode || "",
                similarAssets:  searchResult.similarAssets || "",
                asset:  searchResult.asset || "",
                subNumber:  searchResult.subNumber || "",
                fetchedDetails: searchResult,
                 isUpdate: true
            });

            // Step B: Switch the tab
            setActiveIndex(1);

            // Step C: Switch mode back to CREATE
            setMode('create');

            // Step D: Reset trigger so we can search again if needed
            setSearchTrigger({asset:"",subNumber:"",companyCode:""});
        }
    }, [searchResult]); // This triggers as soon as the API response arrives
const { data: classResponse, isFetching, error } = useReadApi({
  service: "am",
  endpoint: "",
  headers: authHeaders,
  options: {
    enabled: Boolean(authToken)
  }
});
   const handleChangeInputChange = (e, field, value) => {
        setChangeForm(prev => ({ ...prev, [field]: value }));
    };

  return (
    <div className="material-container" style={{ width: '100%', alignContent: 'center' }}>
      
      {/* HEADER SECTION WITH MODE TOGGLE */}
      <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        backgroundColor: '#ffffff', 
        padding: '10px', 
        border: '1px solid #cccccc', 
        marginBottom: '20px' 
      }}>
        <div style={{ fontWeight: 'bold', fontSize: '1.1rem' }}>
          {mode === 'create' ? 'Create Asset' : 'Change Asset: Initial screen'}
        </div>
        
        {/* THE SWITCH BUTTON */}
        <Button 
          label={mode === 'create' ? "Switch to Change Mode" : "Switch to Create Mode"} 
          className="p-button-outlined p-button-sm"
          onClick={() => setMode(mode === 'create' ? 'change' : 'create')} 
        />
      </div>

      <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
        
        {/* TAB 1: INITIAL / CHANGE SCREEN */}
        <TabPanel header={mode === 'create' ? "Initial Details" : "Initial screen"}>
          <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
            
            {/* --- RENDER CONTENT BASED ON MODE --- */}
            {mode === 'create' ? (
              /* ORIGINAL CREATE UI */
              <>
                <div
              className="sap-section-wrapper"
              style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom:'10px',marginRight:"90px"}}>
              <label style={{ fontSize: '1rem' }}>Asset Class</label>
              <AutoComplete
                
                value={formData.assetClass}   
                // suggestions={filteredOptions}  
                // completeMethod={searchOptions}
                onChange={(e) => handleInputChange(e, 'assetClass', e.value)}
                optionLabel="assetClass"
                // placeholder="Select or Enter Class"
                style={{ width: '30%', paddingLeft: '100px' }}
                className="small-input"
                forceSelection={false}  
              />
            </div>
            <div className="sap-section-wrapper" style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom:'10px',marginRight:"90px"}}>
                <label style={{ fontSize: '1rem' }}>Company Code</label>
                <InputText style={{ width: '25%',marginLeft:'75px' }} value={formData.companyCode}
                  onChange={(e) => handleInputChange(e, 'companyCode', e.target.value)}
                />
              </div>
            <div
              className="sap-section-wrapper"
              style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '80%', marginBottom:'10px', justifyContent: 'space-between' }}>
             
                  <label style={{ fontSize: '1rem' }}>Number of similar assets</label>
                <InputText style={{ width: '16%',marginRight:'974px' }} value={formData.similarAssets}
                  onChange={(e) => handleInputChange(e, 'similarAssets', e.target.value)}
                />
            </div>
          
            <div className="sap-section-wrapper" style={{ padding: '2px', backgroundColor: '#f8f9fa' }}>
              <div style={{
                backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px',
                boxShadow: '0 2px 4px rgba(0,0,0,0.05)', overflow: 'hidden', marginBottom: '10px'
              }}>
              <div style={{ padding: '10px 15px', borderBottom: '1px solid #dee2e6', backgroundColor: '#fdfdfd' }}>
                <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: '600', color: '#333' }}>Reference</h3>
              </div>
              <div  style={{ padding: '20px 15px'}}>
                <label style={{ fontSize: '1rem',marginRight:'150px' }}>Asset</label>
                <InputText style={{ width: '10%' }} value={formData.asset}
                  onChange={(e) => handleInputChange(e, 'asset', e.target.value)}
                />
              </div>
              <div style={{ padding: '20px 15px',paddingTop:'0px' }}>
                <label style={{ fontSize: '1rem',marginRight:'102px' }}>Sub-Number</label>
                <InputText style={{ width: '10%' }} value={formData.subNumber}
                  onChange={(e) => handleInputChange(e, 'subNumber', e.target.value)}
                /> 
              </div>
              <div style={{ padding: '20px 15px',paddingTop:'0px' }}>
                <label style={{ fontSize: '1rem',marginRight:'85px' }}>Company Code</label>
                <InputText style={{ width: '10%' }} value={formData.companyCode}
                  onChange={(e) => handleInputChange(e, 'companyCode', e.target.value)}
                />
              </div>
                </div>
                </div>
                 <div style={{ marginTop: '20px', textAlign: 'right' }}>
                        <Button label={isCreatePending ? "Saving..." : "Next"} icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} onClick={handleNext} loading={isCreatePending} disabled={isCreatePending} />
                </div>
              </>
            ) : (
              /* NEW CHANGE UI (As per your image) */
              <div >
                {/* Table-like rows for Change Mode */}
                <div style={{ display: 'flex', padding: '15px',  alignItems: 'center' }}>
                  <label style={{ width: '150px' }}>Asset</label>
                  <InputText style={{ width: '200px' }} value={changeForm.asset} onChange={(e) => handleChangeInputChange(e, 'asset', e.target.value)} />
                </div>

                <div style={{ display: 'flex', padding: '15px', paddingTop:'0px', alignItems: 'center' }}>
                  <label style={{ width: '150px' }}>Sub-number</label>
                  <InputText style={{ width: '200px' }} value={changeForm.subNumber} onChange={(e) => handleChangeInputChange(e, 'subNumber', e.target.value)} />
                </div>

                <div style={{ display: 'flex', padding: '15px',paddingTop:'0px', alignItems: 'center' }}>
                  <label style={{ width: '150px' }}>Company Code</label>
                  {/* <Checkbox
                    onChange={e => handleInputChange(e, 'companyCodeCheck', e.checked)} 
                    checked={formData.companyCodeCheck} 
                  />
                  <span style={{ marginLeft: '10px' }}></span> */}
                     <InputText style={{ width: '200px' }} value={changeForm.companyCode} onChange={(e) => handleChangeInputChange(e, 'companyCode', e.target.value)} />
                  </div>
                   <div style={{ marginTop: '20px', textAlign: 'right' }}>
                       <Button label="Next"  onClick={handleFetchDetails} loading={isFetchingAsset} />
                  </div>
              </div>
            )}

            {/* ACTION BUTTON */}
            {/* <div style={{ marginTop: '20px', textAlign: 'right' }}>
              <Button
                label={mode === 'create' ? (isCreatePending ? "Saving..." : "Next") : (isCreatePending ? "Updating..." : "Continue")}
                icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"}
                onClick={handleNext}
                loading={isCreatePending}
              />
            </div> */}
          </Card>
        </TabPanel>

        {/* TAB 2: MASTER DATA (Only visible/relevant in Create mode usually) */}
        
          <TabPanel header="Master Data">
            <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
              <AssetMasterData initialData={formData.fetchedDetails || formData}  isEdit={!!formData.isUpdate} />
            </Card>
          </TabPanel>
       
      </TabView>
    </div>
  );
};
export default AssetInitialScreen;