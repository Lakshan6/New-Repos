import React, { useState,useRef,useEffect } from 'react';
import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import GeneralEquipment from './GeneralEquipment';
import LocationData from './LocationData';
import OrganizationData from './OrganizationData';
import PRTData from './PRTData';
import { useForm, FormProvider, Controller } from "react-hook-form";
import { z } from "zod";
import { zodResolver } from "@hookform/resolvers/zod";
import { Toast } from "primereact/toast";
import { TabView, TabPanel } from "primereact/tabview";
import { Button } from "primereact/button";
import { useMemo } from 'react';
import { useMutationApi } from '@shared/hooks';
import { Calendar } from 'primereact/calendar';

const STORAGE_KEY = "erp-am-customer-form";

const schema = z.object({
  material: z.string().min(1, "material is required"),
  category: z.string().min(1, "category is required"),
  description: z.string().min(1, "description is required"),
  status: z.string().min(1, "status is required"),
  class: z.string().min(1, "class is required"),
  objectType: z.string().min(1, "objecttype is required"),
  authGrp: z.string().min(1, "authGrp is required"),
  location: z.string().min(1, "location is required"),
  // room: z.string().min(1, "room is required"),

});
const TAB_MAP = {
  class: { tab: "General", index: 0 },
  objectType: { tab: "General", index: 0 },
  authGrp: { tab: "General", index: 0 },
  Weight: { tab: "General", index: 0 },
  unit: { tab: "General", index: 0 },
  size: { tab: "General", index: 0 },
  inventoryNo: { tab: "General", index: 0 },
  startUpDate: { tab: "General", index: 0 },
  acquistnValue: { tab: "General", index: 0 },
  aqcuistionDate: { tab: "General", index: 0 },
  manufacturer: { tab: "General", index: 0 },
  manufCountry: { tab: "General", index: 0 },
  modelNumber: { tab: "General", index: 0 },
  constrYear: { tab: "General", index: 0 },
  constrMonth: { tab: "General", index: 0 },  
  manufPartNo: { tab: "General", index: 0 },
  manufSerialNo: { tab: "General", index: 0 },

  maintPlant: { tab: "Location", index: 1 },
  location: { tab: "Location", index: 1 },
  room: { tab: "Location", index: 1 },
  plantSection: { tab: "Location", index: 1 },
  workCenter: { tab: "Location", index: 1 },
  abcIndic: { tab: "Location", index: 1 },
  sortField: { tab: "Location", index: 1 },
  addressName: { tab: "Location", index: 1 },
  addressStreet: { tab: "Location", index: 1 },
  addressLocation:{ tab: "Location", index: 1 },
  telephone: { tab: "Location", index: 1 },
  fax: { tab: "Location", index: 1 },

  companyCode: { tab: "Organization", index: 2 },
  asset: { tab: "Organization", index: 2 },
  costCenter: { tab: "Organization", index: 2 },
  planningPlant: { tab: "Organization", index: 2 },
  plannerGrp: { tab: "Organization", index: 2 },
  mainWorkCtr: { tab: "Organization", index: 2 },
  catalogProfile: { tab: "Organization", index: 2 },

  taskList: { tab: "PRTData", index: 3 },
  groupingKey1: { tab: "PRTData", index: 3 },
  groupingKey2: { tab: "PRTData", index: 3 },
  controlKey: { tab: "PRTData", index: 3 },
  standTxtKey: { tab: "PRTData", index: 3 },
  usageValFormula: { tab: "PRTData", index: 3 },
  startRef: { tab: "PRTData", index: 3 },
  startOffset: { tab: "PRTData", index: 3 },
  endRef: { tab: "PRTData", index: 3 },
  endOffset: { tab: "PRTData", index: 3 },
  maintPlan: { tab: "PRTData", index: 3 },
  measPoint: { tab: "PRTData", index: 3 },
  

};

const EquipmentScreen = ({ initialdata,isEdit }) => {
  console.log('initialdata', initialdata);
  const toast = useRef(null);
  const [activeTab, setActiveTab] = useState(0);
  const [submitting,setIsSubmitting]=useState(false)
  const savedData = JSON.parse(
    localStorage.getItem(STORAGE_KEY) || "{}"
  );
 const authToken = localStorage.getItem('authToken') ?? '';

  const authHeaders = useMemo(
    () => ({
      Authorization: `Bearer ${authToken}`
    }),
    [authToken]
  );
  console.log("isedit", isEdit);
  const isEditMode = isEdit;
  const methods = useForm({
    // resolver: zodResolver(schema),
    shouldUnregister: false,
    defaultValues: {
      class: "",
      objectType: "",
      authGrp: "",
      weight: "",
      unit: "",
      size: "",
      inventoryNo: "",
      startUpDate: "",
      acquistnValue: "",
      acquistionDate: "",
      manufacturer: "",
      manufCountry: "",
      modelNumber: "",
      constrYear: "",
      constrMonth: "",
      manufPartNo: "",
      manufSerialNo: "",
      maintPlant: "",
      location: "",
      room: "",
      plantSection: "",
      workCenter: "",
      abcIndic: "",
      sortField: "",
      addressName: "",
      addressStreet: "",
      addressLocation:"",
      telephone: "",
      fax: "",
      companyCode: "",
      asset: "",
      costCenter: "",
      planningPlant: "",
      plannerGrp: "",
      mainWorkCtr: "",
      catalogProfile: "",
      taskList: "",
      groupingKey1: "",
      groupingKey2: "",
      controlKey: "",
      standTxtKey: "",
      usageValFormula: "",
      startRef: "",
      startOffset: "",
      endRef: "",
      endOffset: "",
      maintPlan: "",
      measPoint: "",
       ...savedData
    
    },
  });
  const { watch, handleSubmit, reset, register,control } = methods;

  // Persist form values
  useEffect(() => {
    const subscription = watch((value) => {
      localStorage.setItem(
        STORAGE_KEY,
        JSON.stringify(value)
      );
    });

    return () => subscription.unsubscribe();
  }, [watch]);

  const { mutate: createAssetData, isPending: isCreatePending } =
    useMutationApi({
      service: 'am',
      endpoint:isEditMode? `/equipment/updateEquipment/${initialdata?.equipment}`:'/equipment/save',
      method: isEditMode? 'PATCH':'POST',
      headers: authHeaders,
     options: {
    // This runs when the API succeeds
    onSuccess: (data) => {
      console.log("Save Successful:", data);
     
    },
    // This runs when the API fails
    onError: (error) => {
      console.error("Save Error:", error);
      alert("Failed to save: " + (error.message || "Server Error"));
    }
  }
    });

 const onSubmit = async (data) => {
    setIsSubmitting(true); // Start loading
 const formatDate = (dateValue) => {
    if (!dateValue) return null;
    const d = new Date(dateValue);
    return d.toISOString().split('T')[0]; // Returns "2026-03-12"
  };
 
     const payload = {
       equipment: initialdata?.equipment,
       category: initialdata?.equipCat?.equipCat,
       description: data?.description,
       status: data?.status,
       validFrom: formatDate(data?.validFrom),
       validTo: formatDate(data?.validTo),
      generalDto: {
        class: data?.class,
        objectType: data?.objectType,
        authGrp: data?.authGrp,
        weight: data?.weight,
        unit: data?.unit,
        size: data?.size,
        inventoryNo: data?.inventoryNo,
        startUpDate: formatDate(data?.startUpDate),
        acquistnValue: data?.acquistnValue,
        acquistionDate: formatDate(data?.acquistionDate),
        manufacturer: data?.manufacturer,
        manufCountry: data?.manufCountry,
        modelNumber: data?.modelNumber,
        constrYear: data?.constrYear,
        constrMonth: data?.constrMonth,
        manufPartNo: data?.manufPartNo,
        manufSerialNo: data?.manufSerialNo
      },
       locationDto: {
        maintPlant: data?.maintPlant,
        location: data?.location,
        room: data?.room,
        plantSection: data?.plantSection,
        workCenter: data?.workCenter,
        abcIndic: data?.abcIndic,
        sortField: data?.sortField,
        addressName: data?.addressName,
         addressStreet: data?.addressStreet,
        addressLocation: data?.addressLocation,
        telephone: data?.telephone,
        fax: data?.fax,
       },
       organizationDto: {
        companyCode: data?.companyCode,
        asset: data?.asset,
        costCenter: data?.costCenter,
        planningPlant: data?.planningPlant,
        plannerGrp: data?.plannerGrp,
        mainWorkCtr: data?.mainWorkCtr, 
        catalogProfile: data?.catalogProfile
       },
       PRTDataDto: {
         taskList: data?.taskList,
         groupingKey1: data?.groupingKey1,
         groupingKey2: data?.groupingKey2,
         controlKey: data?.controlKey,
         standTxtKey: data?.standTxtKey,
         usageValFormula: data?.usageValFormula,
         startRef: data?.startRef,
         startOffset: data?.startOffset,
         endRef: data?.endRef,
         endOffset: data?.endOffset,
         maintPlan: data?.maintPlan,
         measPoint: data?.measPoint,
       }
      
    };

     createAssetData(payload);
  
 
  };
  const isInitialized = useRef(false);
    useEffect(() => {
    if (initialdata && !isInitialized.current) {
      // Mapping the API response to the structure expected by your form
      // This ensures 'initialdata.validFrom' goes into 'validFrom' field, etc.
      reset({
        category: initialdata?.category || "",
        description: initialdata.description || "",
        status: initialdata.status || "",
        validFrom: initialdata.validFrom ? new Date(initialdata.validFrom) : null,
        validTo: initialdata.validTo ? new Date(initialdata.validTo) : null,
        // General Tab fields
       class: initialdata.generalDto?.class || "",
      objectType: initialdata.generalDto?.objectType || "",
      authGrp: initialdata.generalDto?.authGrp || "",
      weight: initialdata.generalDto?.weight || "",
      unit: initialdata.generalDto?.unit || "",
      inventoryNo: initialdata.generalDto?.inventoryNo || "",
      startUpDate: initialdata.generalDto?.startUpDate ? new Date(initialdata.generalDto.startUpDate) : null,
      acquistionDate: initialdata.generalDto?.acquistionDate ? new Date(initialdata.generalDto.acquistionDate) : null,
      manufacturer: initialdata.generalDto?.manufacturer || "",
      manufCountry: initialdata.generalDto?.manufCountry || "",
      modelNumber: initialdata.generalDto?.modelNumber || "",
      constrYear: initialdata.generalDto?.constrYear || "",
      constrMonth: initialdata.generalDto?.constrMonth || "",
      manufPartNo: initialdata.generalDto?.manufPartNo || "",
      manufSerialNo: initialdata.generalDto?.manufSerialNo || "",
        // Location Tab fields
        maintPlant: initialdata.locationDto?.maintplantId || initialdata.locationDto?.maintPlant || "",
      location: initialdata.locationDto?.location || "",
      room: initialdata.locationDto?.room || "",
      telephone: initialdata.locationDto?.telephone || "",
      fax: initialdata.locationDto?.fax || "",
      plantSection: initialdata.locationDto?.plantSection || "",
        workCenter: initialdata.locationDto?.workCenter || "",
        abcIndic: initialdata.locationDto?.abcIndic || "",
        addressName: initialdata.locationDto?.addressName || "",
        addressStreet: initialdata.locationDto?.addressStreet || "",
        addressLocation: initialdata.locationDto?.addressLocation || "",
          sortField: initialdata.locationDto?.sortField || "",
        // Organization Tab fields
       companyCode: initialdata.organizationDto?.companyCode || "",
      asset: initialdata.organizationDto?.asset || "",
      costCenter: initialdata.organizationDto?.costCenter || "",
      planningPlant: initialdata.organizationDto?.planningPlant || "",
      plannerGrp: initialdata.organizationDto?.plannerGrp || "",
      mainWorkCtr: initialdata.organizationDto?.mainWorkCtr || "",
      catalogProfile: initialdata.organizationDto?.catalogProfile || "",

        // PRT Data Tab fields
       taskList: initialdata.prtDataDto?.taskList || initialdata.PRTDataDto?.taskList || "",
      groupingKey1: initialdata.prtDataDto?.groupingKey1 || initialdata.PRTDataDto?.groupingKey1 || "",
      groupingKey2: initialdata.prtDataDto?.groupingKey2 || initialdata.PRTDataDto?.groupingKey2 || "",
      controlKey: initialdata.prtDataDto?.controlKey || initialdata.PRTDataDto?.controlKey || "",
      standTxtKey: initialdata.prtDataDto?.standTxtKey || initialdata.PRTDataDto?.standTxtKey || "",
      usageValFormula: initialdata.prtDataDto?.usageValFormula || initialdata.PRTDataDto?.usageValFormula || "",
      startRef: initialdata.prtDataDto?.startRef || initialdata.PRTDataDto?.startRef || "",
      startOffset: initialdata.prtDataDto?.startOffset || initialdata.PRTDataDto?.startOffset || "",
      endRef: initialdata.prtDataDto?.endRef || initialdata.PRTDataDto?.endRef || "",
      endOffset: initialdata.prtDataDto?.endOffset || initialdata.PRTDataDto?.endOffset || "",
      maintPlan: initialdata.prtDataDto?.maintPlan || initialdata.PRTDataDto?.maintPlan || "",
      measPoint: initialdata.prtDataDto?.measPoint || initialdata.PRTDataDto?.measPoint || "",
      });
    }
  }, [initialdata, reset]); 
useEffect(() => {
    // If the equipment ID changes, allow re-initialization
    isInitialized.current = false;
}, [initialdata?.equipment]); 
  return (
  <FormProvider {...methods}>
    <Toast ref={toast} />

    <div className="material-container" style={{ width: '100%' }}>

      <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa', padding: '1rem' }}>
        
        <form onSubmit={handleSubmit(onSubmit)}>
          <div className="sap-section-wrapper"
                    style={{ 
                    display: 'flex',          
                    alignItems: 'center',    
                    gap: '2rem',             
                      width: '50%', 
                    marginBottom:'20px'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <label style={{ width: '100px', fontSize: '1rem', whiteSpace: 'nowrap' }}>Equipment</label>
                        <div className="input-group" style={{ flex: 1 }}>
                             <InputText style={{ width: '50%' }} readOnly value={initialdata.equipment} />
                        </div>
                    </div>
                     <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <label style={{ width: '100px', fontSize: '1rem', whiteSpace: 'nowrap' }}>Category</label>
                        <div className="input-group" style={{ flex: 1 }}>
                              <InputText style={{ width: '100%' }} value={initialdata?.equipCat?.equipCat || initialdata.category } />
                         </div>
                    </div>
                </div>
                 <div className="sap-section-wrapper"
                    style={{ 
                    display: 'flex',          
                    alignItems: 'center',   
                    gap: '2rem',             
                      width: '50%',
                    marginBottom:'20px'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <label style={{ width: '100px', fontSize: '1rem', whiteSpace: 'nowrap' }}>Description</label>
                        <div className="input-group" style={{ flex: 1 }}>
                          <InputText
                    {...register("description")}
                    readOnly={isEditMode}
                          style={{ width: '80%' }}
                        />
                        </div>
                    </div>


                </div>
                 <div className="sap-section-wrapper"
                    style={{ 
                    display: 'flex',         
                    alignItems: 'center',   
                    gap: '2rem',           
                      width: '50%',
                    marginBottom:'20px'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <label style={{ width: '100px', fontSize: '1rem', whiteSpace: 'nowrap' }}>Status</label>
                        <div className="input-group" style={{ flex: 1 }}>
                            <InputText
                          {...register("status")}
                          style={{ width: '100%' }}
                        />
                        </div>
                    </div>
                     <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <div className="input-group" style={{ flex: 1 }}>
                          <InputText
                           {...register(" ")}
                           style={{ width: '100%' }}
                         />
                         </div>
                    </div>
                </div>
                 <div className="sap-section-wrapper"
                    style={{ 
                    display: 'flex',          
                    alignItems: 'center',   
                    gap: '2rem',            
                      width: '50%',
                    marginBottom:'20px'
                    }}
                >
                    <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <label style={{ width: '100px', fontSize: '1rem', whiteSpace: 'nowrap' }}>Valid from</label>
                        <div className="input-group" style={{ flex: 1 }}>
                          <Controller
                        name="validFrom" 
                        control={control}
                        render={({ field }) => (
                        <Calendar
                            value={field.value}              
                            onChange={(e) => field.onChange(e.value)} 
                            placeholder="select Date"
                            dateFormat="dd-mm-yy"
                            showIcon 
                            style={{ width: '80%' }}  
                         />
                       )}
                      />    </div>
                    </div>
                     <div style={{ display: 'flex', alignItems: 'center', gap: '8px', flex: 1 }}>
                        <label style={{ width: '100px', fontSize: '1rem', whiteSpace: 'nowrap' }}>Valid to</label>
                        <div className="input-group" style={{ flex: 1 }}>
                          <Controller
                        name="validTo" 
                        control={control}
                        render={({ field }) => (
                        <Calendar
                            value={field.value}              
                            onChange={(e) => field.onChange(e.value)} 
                            placeholder="select Date"
                            dateFormat="dd-mm-yy"
                            showIcon 
                            style={{ width: '80%' }}  
                         />
                       )}
                      />   
                        </div>
                    </div>
            </div>
          
          <div className="sap-section-wrapper" style={{
            backgroundColor: '#ffffff',
            border: '1px solid #dee2e6',
            borderRadius: '4px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
            overflow: 'hidden',
            marginBottom: '20px'
          }}>
      
            {/* Custom Tab Navigation Logic */}
            <div className="sap-tab-bar" style={{ display: 'flex', borderBottom: '1px solid #dee2e6', backgroundColor: '#f1f3f5' }}>
          
              <div 
                className={`sap-tab ${activeTab === 0 ? 'active' : ''}`} 
                onClick={() => setActiveTab(0)}
                style={{ cursor: 'pointer', padding: '10px 20px', borderBottom: activeTab === 0 ? '2px solid #007ad9' : 'none' }}
              >
                General
              </div>
              <div 
                className={`sap-tab ${activeTab === 1 ? 'active' : ''}`} 
                onClick={() => setActiveTab(1)}
                style={{ cursor: 'pointer', padding: '10px 20px', borderBottom: activeTab === 1 ? '2px solid #007ad9' : 'none' }}
              >
                Location
              </div>
              <div 
                className={`sap-tab ${activeTab === 2 ? 'active' : ''}`} 
                onClick={() => setActiveTab(2)}
                style={{ cursor: 'pointer', padding: '10px 20px', borderBottom: activeTab === 2 ? '2px solid #007ad9' : 'none' }}
              >
                Organization
                </div>
                <div 
                className={`sap-tab ${activeTab === 3 ? 'active' : ''}`} 
                onClick={() => setActiveTab(3)}
                style={{ cursor: 'pointer', padding: '10px 20px', borderBottom: activeTab === 3 ? '2px solid #007ad9' : 'none' }}
              >
                PRT Data
              </div>
            </div>

            <div className="sap-card-body">
 
              {activeTab === 0 && <GeneralEquipment />}
              {activeTab === 1 && <LocationData />}
              {activeTab === 2 && <OrganizationData />}
              {activeTab === 3 && <PRTData />}
            </div>
          </div>

          <div className="mt-4" style={{ display: 'flex', justifyContent: 'flex-end' }}>
            <Button
              type="submit"
              label="Submit All Tabs"
              className="p-button-primary"
            />
          </div>
        </form>

      </Card>
    </div>
  </FormProvider>
); 
    
}
export default EquipmentScreen;