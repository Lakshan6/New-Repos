import { InputText } from "primereact/inputtext";
import { useFormContext } from "react-hook-form";

const OrganizationData = () => {
    const {
    register,
    formState: { errors },
  } = useFormContext();
    return (
        <div>
            <div className="sap-section-wrapper" style={{padding:'10px',backgroundColor: '#f8f9fa'}}>
                <div style={{ backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px', marginBottom: '20px' }}>
                    <div style={{ borderBottom: '1px solid #dee2e6',padding:'10px 15px' }}>
                        <h3 style={{margin:0,fontSize:'1rem',fontweight:'600',fontcolor:'#333'}}>Account assignment</h3>
                    </div>
                    <div style={{padding:'20px 15px'}} >
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: '230px 400px 190px 1fr',
                            columnGap: '15px',
                            rowGap: '15px',
                             alignItems: 'center'
                        }}>
                            <label style={{ fontSize: '1rem' }}>Company code</label>
                             <InputText
                                {...register("companyCode")}
                                style={{width:'40%'}} 
                              /> 
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Asset</label>
                            <div style={{ display: 'flex', alignItems: 'center',gap:'5px' }}>
                                <InputText
                                      {...register("asset")}
                                       style={{width:'30%'}} 
                                /> 
                                <span>/</span>
                                <InputText style={{ width: '10%' }} />
                            </div>
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Cost Center</label>
                            <div style={{ display: 'flex', alignItems: 'center',gap:'5px' }}>
                                <InputText
                                      {...register("costCenter")}
                                       style={{width:'30%'}} 
                                /> 
                                <span>/</span>
                                <InputText style={{ width: '20%' }} />
                            </div>
                            <div />
                            <div />

                            
                           
                        </div>

                    </div>
                </div>
            </div>
              <div className="sap-section-wrapper" style={{paddingLeft:'10px',backgroundColor: '#f8f9fa',paddingRight:'10px'}}>
                <div style={{ backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px', marginBottom: '20px' }}>
                    <div style={{ borderBottom: '1px solid #dee2e6',padding:'10px 15px' }}>
                        <h3 style={{margin:0,fontSize:'1rem',fontweight:'600',fontcolor:'#333'}}>Responsibilities</h3>
                    </div>
                    <div style={{padding:'20px 15px'}} >
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: '230px 400px 190px 1fr',
                            columnGap: '15px',
                            rowGap: '15px',
                             alignItems: 'center'
                        }}>
                            <label style={{ fontSize: '1rem' }}>Planning plant</label>
                            <InputText
                                      {...register("planningPlant")}
                                       style={{width:'30%'}} 
                                /> 
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Planner Group</label>               
                           <InputText
                                      {...register("plannerGrp")}
                                       style={{width:'30%'}}  
                                /> 
                            
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Main WorkCtr</label>
                            <div style={{ display: 'flex', alignItems: 'center',gap:'5px' }}>
                                <InputText
                                      {...register("mainWorkCtr")}
                                       style={{width:'30%'}} 
                                /> 
                                <span>/</span>
                                <InputText style={{ width: '20%' }} />
                            </div>
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Catalog profile</label>
                            <InputText
                                      {...register("catalogProfile")}
                                       style={{width:'30%'}} 
                                /> 
                            <div />
                            <div />
                           
                        </div>

                    </div>
                </div>
            </div>
        </div>
    );
    
}
export default OrganizationData;