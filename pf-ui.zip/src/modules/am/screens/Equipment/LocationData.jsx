import { InputText } from "primereact/inputtext";
import { useFormContext } from "react-hook-form";

const LocationData = () => {
    const {
    register,
    formState: { errors },
  } = useFormContext();

    return (
        <div>
           <div className="sap-section-wrapper"style={{padding:'10px'}} >
            <div style={{
                border: '1px solid #dee2e6',
                borderRadius: '4px',
                marginBottom:'20px'

            }}>
                <div style={{borderBottom:'1px solid #dee2e6',padding:'10px 15px' }}>
                    <h3 style={{margin: 0,fontSize:'1rem',fontWeight:'600',color:'#333'}}>Location Data</h3>
                </div>
                    <div style={{
                        display: 'grid',
                        gridTemplateColumns: '230px 400px 190px 1fr',
                        columnGap: '15px', rowGap: '15px',
                        padding: '20px 15px', alignItems: 'center'
                    }}>
                        {/* Row 1 */}
                        <label style={{ fontSize: '1rem' }}>MaintPlant</label>
                         <InputText
                           {...register("maintPlant")}
                            style={{width:'30%'}} 
                         /> 
                        <div />
                        <div />
                         <label style={{ fontSize: '1rem' }}>Location</label>
                        <InputText
                            {...register("location")}
                            style={{width:'30%'}} 
                        />
                        <div />
                        <div />
                         <label style={{ fontSize: '1rem' }}>Room</label>
                       <InputText
                          {...register("room")}
                          style={{width:'30%'}} 
                        />
                        <div />
                        <div />
                         <label style={{ fontSize: '1rem' }}>Plant Section</label>
                         <InputText
                          {...register("plantSection")}
                          style={{width:'40%'}} 
                         /> 
                        <div />
                        <div />
                         <label style={{ fontSize: '1rem' }}>Work Center</label>
                         <InputText
                            {...register("workCenter")}
                            style={{width:'40%'}} 
                         /> 
                        <div />
                        <div />
                         <label style={{ fontSize: '1rem' }}>ABC indic.</label>
                         <InputText
                             {...register("abcIndic")}
                              style={{width:'10%'}} 
                         /> 
                        <div />
                        <div />
                         <label style={{ fontSize: '1rem' }}>Sort field</label>
                         <InputText
                             {...register("sortField")}
                              style={{width:'60%'}} 
                         /> 
                        <div />
                        <div />
                        
                    </div>
            </div>
            </div>
            <div className="sap-section-wrapper" style={{ paddingLeft: '10px' }}>
                <div style={{ border: '1px solid #dee2e6', borderRadius: '4px', marginBottom: '20px' }}>
                    <div style={{ padding: '10px 15px',borderBottom: '1px solid #dee2e6' }}>
                        <h3 style={{ margin: 0,fontSize:'1rem',fontWeight:'600',color:'#333'}}>Address</h3>
                    </div>
                    <div style={{ padding: '20px 15px' }}>
                        <div style={{
                            display: 'grid', gridTemplateColumns: '230px 400px 190px 1fr',
                            columnGap: '15px',
                            rowGap: '15px',
                            alignItems:'center'
                        }}>
                            <label style={{fontSize:'1rem'}}>Name</label>
                             <InputText
                              {...register("addressName")}
                              style={{width:'40%'}} 
                             /> 
                            <div />
                            <div />

                             <label style={{fontSize:'1rem'}}>Street</label>
                             <InputText
                              {...register("addressStreet")}
                              style={{width:'80%'}} 
                             /> 
                            <div />
                            <div />

                           <div />
                             <InputText
                              {...register("street")}
                              style={{width:'80%'}} 
                              /> 
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Location</label>
                            <div style={{ display: 'flex',gap: '5px' }}>
                                <InputText {...register("addressLocation")} style={{ width: '30%' }} />
                                <InputText style={{ width: '100%' }} />
                                <InputText style={{ width: '20%' }} />
                                 <InputText style={{ width: '20%' }} />
                            </div>
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Telephone</label>
                            <div style={{ display: 'flex',gap: '5px',alignItems:'center' }}>
                                <InputText
                                   {...register("telephone")}
                                    style={{width:'80%'}} 
                                /> 
                                <span style={{ paddingLeft: '15px', fontSize: '1rem' }}>FAX</span>
                                 <InputText
                                     {...register("fax")}
                                      style={{width:'80%'}} 
                                 /> 
                            </div>

                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
}
export default LocationData;