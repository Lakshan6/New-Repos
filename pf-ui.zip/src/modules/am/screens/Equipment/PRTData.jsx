import { InputText } from "primereact/inputtext";
import { Checkbox } from 'primereact/checkbox';
import React, { useState } from 'react';
import { useFormContext } from "react-hook-form";
const PRTData = () => {
    const {
    register,
    formState: { errors },
  } = useFormContext();
     const [formData, setFormData] = useState({
         loadRecords: false,
         controlKey: false,
         standardTextKey: false,
         usageValueFormula: false,
         setupStartDate: false,
         stratOffset: false,
         executionStartDate: false,
         endOffset: false
    });
    
    const handleInputChange = (e, field, value = null) => {
        setFormData(prev => ({
            ...prev,
            [field]: value !== null ? value : e.target.value
        }));
    };

    return (
          <div>
            <div className="sap-section-wrapper" style={{padding:'10px',backgroundColor: '#f8f9fa'}}>
                <div style={{ backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px', marginBottom: '20px' }}>
                    <div style={{ borderBottom: '1px solid #dee2e6',padding:'10px 15px' }}>
                        <h3 style={{margin:0,fontSize:'1rem',fontweight:'600',fontcolor:'#333'}}>Basic data</h3>
                    </div>
                    <div style={{padding:'20px 15px'}} >
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: '230px 400px 190px 1fr',
                            columnGap: '15px',
                            rowGap: '15px',
                             alignItems: 'center'
                        }}>
                
                            <div />
                            <div />
                            <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                                <Checkbox
                                    aria-label='loadRecords'
                                    onChange={(e) => handleInputChange(e, 'loadRecords', e.checked)}
                                    checked={formData.loadRecords}
                                />
                               <span style={{ fontSize: '1rem' }}>Load records</span>
                            </div>
                            <div />

                            <label style={{ fontSize: '1rem' }}>Task list usage</label>
                            <InputText
                                      {...register("taskList")}
                                       style={{width:'30%'}} 
                                /> 
                             <label style={{ fontSize: '1rem' }}>All task list types</label>
                            <div />

                            <label style={{ fontSize: '1rem' }}>Grouping key 1</label>
                            <InputText
                                      {...register("groupingKey1")}
                                       style={{width:'30%'}} 
                                />                            
                            <div />
                            <div />

                            <label style={{ fontSize: '1rem' }}>Grouping key 2</label>
                            <InputText
                                      {...register("groupingKey2")}
                                       style={{width:'30%'}} 
                                />                            
                            <div />
                            <div />

                            
                           
                        </div>

                    </div>
                </div>
            </div>
              <div className="sap-section-wrapper" style={{paddingLeft:'10px',backgroundColor: '#f8f9fa',paddingRight:'10px'}}>
                <div style={{ backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px', marginBottom: '20px' }}>
                    <div style={{ borderBottom: '1px solid #dee2e6',padding:'10px 15px' }}>
                        <h3 style={{margin:0,fontSize:'1rem',fontweight:'600',fontcolor:'#333'}}>Default values for task list assignment</h3>
                    </div>
                    <div style={{padding:'20px 15px'}} >
                        <div style={{
                            display: 'grid',
                            gridTemplateColumns: '230px 400px 190px 1fr',
                            columnGap: '15px',
                            rowGap: '15px',
                             alignItems: 'center'
                        }}>
                            <div />
                            <div />
                            <div />
                            <label style={{ fontSize: '1rem' }}>Cannot be changed</label>

                            <label style={{ fontSize: '1rem' }}>Control Key</label>
                            <InputText
                                      {...register("controlKey")}
                                       style={{width:'20%'}} 
                                /> 
                            <div />
                           <Checkbox
                                    aria-label='controlKey'
                                    onChange={(e) => handleInputChange(e, 'controlKey', e.checked)}
                                    checked={formData.controlKey}
                                /> 

                            <label style={{ fontSize: '1rem' }}>Standard text key</label>               
                            <InputText
                                      {...register("standTxtKey")}
                                       style={{width:'30%'}} 
                                />                            
                            <div />
                           <Checkbox
                                aria-label='standardTextKey'
                                onChange={(e) => handleInputChange(e, 'standardTextKey', e.checked)}
                                checked={formData.standardTextKey}
                            /> 


                             <label style={{ fontSize: '1rem' }}>Usage value formula</label>               
                           <InputText
                                      {...register("usageValFormula")}
                                       style={{width:'30%'}} 
                                />                            
                            <div />
                            <Checkbox
                                aria-label='usageValueFormula'
                                onChange={(e) => handleInputChange(e, 'usageValueFormula', e.checked)}
                                checked={formData.usageValueFormula}
                            /> 


                            <label style={{ fontSize: '1rem' }}>Start reference</label>
                            <InputText
                                      {...register("startRef")}
                                       style={{width:'30%'}} 
                                />  
                            <label style={{ fontSize: '1rem' }}>Start date for setup</label>
                           <Checkbox
                                aria-label='setupStartDate'
                                onChange={(e) => handleInputChange(e, 'setupStartDate', e.checked)}
                                checked={formData.setupStartDate}
                            /> 

                            <label style={{ fontSize: '1rem' }}>Start offset</label>
                            <div style={{ display: 'flex', alignItems: 'center',gap:'5px' }}>
                                <InputText
                                      {...register("startOffset")}
                                       style={{width:'30%'}} 
                                /> 
                                <InputText style={{ width: '10%' }} />
                            </div>
                            <div />
                           <Checkbox
                                aria-label='stratOffset'
                                onChange={(e) => handleInputChange(e, 'stratOffset', e.checked)}
                                checked={formData.stratOffset}
                            /> 

                             <label style={{ fontSize: '1rem' }}>End reference</label>
                            <InputText
                                      {...register("endRef")}
                                       style={{width:'30%'}} 
                                />  
                            <label style={{ fontSize: '1rem' }}>Start date for execution</label>
                           <Checkbox
                                aria-label='executionStartDate'
                                onChange={(e) => handleInputChange(e, 'executionStartDate', e.checked)}
                                checked={formData.executionStartDate}
                            />

                            <label style={{ fontSize: '1rem' }}>End offset</label>
                            <div style={{ display: 'flex', alignItems: 'center',gap:'5px' }}>
                                <InputText
                                      {...register("endOffset")}
                                       style={{width:'30%'}} 
                                /> 
                                <InputText style={{ width: '10%' }} />
                            </div>
                            <div />
                           <Checkbox
                                aria-label='endOffset'
                                onChange={(e) => handleInputChange(e, 'endOffset', e.checked)}
                                checked={formData.endOffset}
                            /> 
                            
                        </div>
                     
                    </div>
                </div>
            </div>
             <div className="sap-section-wrapper"  style={{ paddingLeft: '10px', backgroundColor: '#f8f9fa',paddingRight:'10px' }} >
                <div style={{  backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px',marginBottom:'20px'}}>
                    <div style={{ backgroundColor: '#fdfdfd', borderBottom: '1px solid #dee2e6',padding:'10px 15px' }}>
                        <h3 style={{  margin: 0,fontSize: '1rem', fontWeight: '600', color: '#333' }}>
                            Default values for maintenance
                        </h3>
                    </div>
                    <div style={{ padding: '20px 15px' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '230px 400px 190px 1fr', columnGap: '15px',alignItems: 'center'}}>
                            <label style={{ fontSize: '1rem' }}>MaintenancePlan</label>
                            <InputText
                                      {...register("maintPlan")}
                                       style={{width:'40%'}} 
                                /> 
                            <label style={{ fontSize: '1rem' }}>Measpoint</label>
                           <InputText
                                      {...register("measPoint")}
                                       style={{width:'40%'}} 
                                /> 
                            
                        </div>
                    </div>
                </div>
                
         </div>
        </div>
    );
}
export default PRTData;