import React, { useState } from 'react';
import { Checkbox } from 'primereact/checkbox';
import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import { Controller, useFormContext } from 'react-hook-form';
import { Calendar } from 'primereact/calendar';
import { InputNumber } from 'primereact/inputnumber';
const GeneralEquipment = () => {
   
const {
  register,
  control,
    formState: { errors },
  } = useFormContext();

    return (
     <div >
        <div className="sap-section-wrapper" style={{ padding: '10px', backgroundColor: '#f8f9fa',paddingTop:'20px' }}>

          <div style={{
            backgroundColor: '#ffffff',
            border: '1px solid #dee2e6',
            borderRadius: '4px',
            boxShadow: '0 2px 4px rgba(0,0,0,0.05)',
            overflow: 'hidden',
            marginBottom: '20px' // Space between cards
          }}
          >

            <div style={{
              padding: '10px 15px',
              borderBottom: '1px solid #dee2e6',
              backgroundColor: '#fdfdfd'
            }}>
              <h3 style={{ margin: 0, fontSize: '1rem', fontWeight: '600', color: '#333' }}>
                General data
              </h3>
            </div>


            <div style={{ padding: '20px 15px' }}>
              <div
                style={{
                  display: 'grid',
                  gridTemplateColumns: '230px 400px 190px 1fr',
                  columnGap: '15px',
                  rowGap: '15px',
                  alignItems: 'center'
                }}
              >
                {/* ROW 1 */}
                <label style={{ fontSize: '1rem' }}>Class</label>
                <InputText
                    {...register("class")}
                    style={{width:'40%'}} 
                /> 
                <div />
               <div />

                {/* ROW 2 */}
                <label style={{ fontSize: '1rem' }}>Object type</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                  <InputText
                    {...register("objectType")}
                    style={{width:'40%'}}
                  />
                  <span style={{ fontSize: '0.85rem' }}>Test Jigs</span>
                </div>
                <div />
                <div />

                {/* ROW 3 */}
                <label style={{ fontSize: '1rem' }}>AuthorizGroup</label>
                <InputText
                    {...register("authGrp")}
                   style={{width:'40%'}} 
                /> 
                <div />
                <div />

                {/* ROW 4 */}
                <label style={{ fontSize: '1rem' }}>Weight</label>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                        <InputText
                          {...register("weight")}
                          style={{width:'40%'}} 
                        /> 
                    <InputText
                       {...register("unit")}
                       style={{width:'40%'}} 
                    /> 
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '1rem' }}>Size/dimension</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                     <InputText
                       {...register("size")}
                       style={{width:'40%'}} 
                    /> 
                </div>

                {/* ROW 5 */}
                <label style={{ fontSize: '1rem' }}>Inventory no.</label>
                <InputText
                    {...register("inventoryNo")}
                    style={{width:'40%'}} 
                /> 
                <div style={{ display: 'flex', alignItems: 'center', gap: '8px' }}>
                  <span style={{ fontSize: '1rem' }}>Start-up date</span>
                </div>
                <div style={{ display: 'flex', alignItems: 'center', gap: '5px' }}>
                     <Controller
                        name="startUpDate" 
                        control={control}
                        render={({ field }) => (
                        <Calendar
                            value={field.value}              
                            onChange={(e) => field.onChange(e.value)} 
                            dateFormat="dd-mm-yy"
                            showIcon
                            style={{ width: '40%' }}  
                         />
                       )}
                      />   
                </div>


              </div>
            </div>
          </div>
        </div>
        <div className="sap-section-wrapper"  style={{ paddingLeft: '10px', backgroundColor: '#f8f9fa',paddingRight:'10px' }} >
                <div style={{  backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px',marginBottom:'20px'}}>
                    <div style={{ backgroundColor: '#fdfdfd', borderBottom: '1px solid #dee2e6',padding:'10px 15px' }}>
                        <h3 style={{  margin: 0,fontSize: '1rem', fontWeight: '600', color: '#333' }}>
                            Reference Data
                        </h3>
                    </div>
                    <div style={{ padding: '20px 15px' }}>
                        <div style={{ display: 'grid', gridTemplateColumns: '230px 400px 190px 1fr', columnGap: '15px',alignItems: 'center'}}>
                            <label style={{ fontSize: '1rem' }}>AcquistnValue</label>
                            <InputText
                              {...register("acquistnValue")}
                               style={{width:'40%'}} 
                            /> 
                            <label style={{ fontSize: '1rem' }}>Acquistion date</label>
                            <Controller
                             name="acquistionDate" 
                             control={control}
                             render={({ field }) => (
                             <Calendar
                              value={field.value}              
                              onChange={(e) => field.onChange(e.value)} 
                              dateFormat="dd-mm-yy"
                              showIcon
                              style={{ width: '40%' }}  
                            />
                           )}
                          />   
                        </div>
                    </div>
                </div>
                
         </div>
            <div className="sap-section-wrapper" style={{paddingLeft:'10px',backgroundColor: '#f8f9fa',paddingRight:'10px'}}>
                <div style={{ backgroundColor: '#ffffff', border: '1px solid #dee2e6', borderRadius: '4px', marginBottom: '20px' }}>
                    <div style={{ padding: '10px 15px',borderBottom:'1px solid #dee2e6' }}>
                        <h3 style={{margin: 0, fontSize: '1rem', fontWeight: '600', color: '#333' }}>
                            Manufacturer data
                        </h3>
                    </div>
                     <div style={{ padding: '20px 15px' }}>
                        <div style={{
                        display: 'grid',
                        gridTemplateColumns: '230px 400px 190px 1fr',
                        columnGap: '15px', rowGap: '15px',
                        alignItems: 'center'
                        }}>
                            {/* Row 1 */}
                            <label style={{ fontSize: '1rem' }}>Manufacturer</label>
                            <InputText
                                  {...register("manufacturer")}
                                 style={{width:'40%'}} 
                            /> 
                            <label style={{ fontSize: '1rem' }}>ManufCountry</label>
                            <InputText
                                  {...register("manufCountry")}
                                  style={{width:'20%'}} 
                            /> 

                            {/* Row 2 */}
                            <label style={{ fontSize: '1rem' }}>Model number</label>
                            <InputText
                                {...register("modelNumber")}
                                style={{width:'40%'}} 
                            /> 
                            <label style={{ fontSize: '1rem' }}>Constr.yr/mth</label>
                            <div style={{ display: 'flex',alignItems: 'center', gap: '5px' }}>
                                <InputText
                                  {...register("constrYear")}
                                  style={{width:'20%'}} 
                                /> 
                                <span > / </span>
                                <InputText
                                   {...register("constrMonth")}
                                   style={{width:'20%'}} 
                                /> 

                            </div>
                            
                            {/* Row 3 */}
                            <label style={{fontSize:'1rem'}}>ManufPartNo.</label>
                            <InputText
                                {...register("manufPartNo")}
                                style={{width:'40%'}} 
                             /> 
                            <div />
                            <div />

                            {/* Row 4 */}
                            <label style={{ fontSize: '1rem' }}>ManufSerialNo.</label>
                            <InputText
                                 {...register("manufSerialNo")}
                                 style={{width:'40%'}} 
                            /> 

                        </div>
                    </div>
                </div>
        </div> 
      </div> 
    );
}
export default GeneralEquipment;