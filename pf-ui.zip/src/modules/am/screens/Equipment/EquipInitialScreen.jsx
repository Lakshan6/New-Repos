import { useMutationApi, useReadApi } from "@shared/hooks";
import { Button } from "primereact/button";
import { Card } from "primereact/card";
import { Dropdown } from "primereact/dropdown";
import { InputText } from "primereact/inputtext";
import { useEffect, useMemo, useState } from "react";
import EquipmentScreen from "./EquipmentScreen";
import { TabPanel, TabView } from "primereact/tabview";
import { Checkbox } from "primereact/checkbox";


const unwrapResponse = (response) => response?.data ?? response ?? null;

const unwrapList = (response) => {
  const data = unwrapResponse(response);

  if (Array.isArray(data)) return data;
  if (Array.isArray(data?.data)) return data.data;
  if (Array.isArray(data?.content)) return data.content;

  return [];
};

const EquipInitialScreen = () => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);
    
    // --- NEW STATES FOR CHANGE MODE ---
    const [viewMode, setViewMode] = useState('CREATE'); // 'CREATE' or 'CHANGE'
    const [changeForm, setChangeForm] = useState({
        equipment: "",
      
    });
    // ----------------------------------
 const [searchTrigger, setSearchTrigger] = useState(""); 
    const [open, setOpen] = useState(false);
    const [formData, setFormData] = useState({
        equipment: "",
        validOn: "",
        equipCat: null,
        material: ""
    });
    const [activeIndex, setActiveIndex] = useState(0);

    const handleInputChange = (_e, field, value = null) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
    };

    // --- NEW HANDLER FOR CHANGE FORM ---
    const handleChangeInputChange = (e, field, value) => {
        setChangeForm(prev => ({ ...prev, [field]: value }));
    };

    // --- NEW MUTATION FOR FETCHING CHANGE DATA ---
  // This is specifically for the "Change" mode search
// --- UPDATED MUTATION ---
// CHANGE THIS:
// const { mutate: performSearch, isPending: isFetchingAsset } = useReadApi({ ... })

// TO THIS:
  const { data: searchResult, isFetching: isFetchingAsset } = useReadApi({
        service: 'am',
        endpoint: `/equipment/getEquipment/${encodeURIComponent(searchTrigger)}`,
        headers: authHeaders,
        options: { 
            enabled: Boolean(searchTrigger) 
        }
    });

    // 2. THE WATCHER: This runs every time 'searchResult' changes
    useEffect(() => {
        if (searchResult) {
            console.log("Data received successfully:", searchResult);
            
            // Step A: Fill the form
            setFormData({
                equipment: searchResult.equipment || "",
                validOn: searchResult.validOn || "",
                equipCat: searchResult.equipCat || null,
                material: searchResult.material || "",
                fetchedDetails: searchResult,
                 isUpdate: true
            });

            // Step B: Switch the tab
            setActiveIndex(1);

            // Step C: Switch mode back to CREATE
            setViewMode('CREATE');

            // Step D: Reset trigger so we can search again if needed
            setSearchTrigger("");
        }
    }, [searchResult]); // This triggers as soon as the API response arrives

    const handleFetchDetails = () => {
        if (!changeForm.equipment.trim()) {
            alert("Please enter equipment");
            return;
        }
        setSearchTrigger(changeForm.equipment);
    };

    const { mutate: createEquipData, isPending: isCreatePending } = useMutationApi({
        service: 'am',
        endpoint: '/create-equip/save',
        method: 'POST',
        headers: authHeaders,
        options: {
            onSuccess: (data) => {
                setActiveIndex(1);
            }
        }
    });

    const handleNext = () => {
        const isFormValid = formData.equipCat;
        if (!isFormValid) {
            alert("Please fill in all required fields before proceeding.");
            return;
        }
        createEquipData(formData);
    };

    // --- NEW HANDLER FOR CHANGE BUTTON ---
// const handleFetchAsset = () => {
//     if (!changeForm.equipment) {
//         alert("Please enter equipment");
//         return;
//     }
//     // Use the new search function
//     // We pass the endpoint in the payload
//   performSearch(endpoint);

// };
    const { data: categoryResponse } = useReadApi({
        service: "am",
        endpoint: "/equip-cat/getAll",
        headers: authHeaders,
        options: { enabled: Boolean(authToken) }
    });

    const categoryOptions = useMemo(() => unwrapList(categoryResponse), [categoryResponse]);

    return (
        <div className="material-container" style={{ width: '100%', alignContent: 'center' }}>
             <div style={{ 
        display: 'flex', 
        justifyContent: 'space-between', 
        alignItems: 'center',
        backgroundColor: '#ffffff', 
        padding: '10px', 
        border: '1px solid #cccccc', 
        marginBottom: '20px' 
      }}>
                <span>{viewMode === 'CREATE' ? "Create Equipment" : "Change Asset: Initial screen"}</span>
                
                {/* BUTTON TO SWITCH MODES */}
                {viewMode === 'CREATE' ? (
                    <Button label="Change" icon="pi pi-external-link" className="p-button-outlined p-button-sm" onClick={() => setViewMode('CHANGE')} />
                ) : (
                    <Button label="Back" icon="pi pi-arrow-left" className="p-button-text p-button-sm" onClick={() => setViewMode('CREATE')} />
                )}
            </div>

            <TabView activeIndex={activeIndex} onTabChange={(e) => setActiveIndex(e.index)}>
                <TabPanel header="Initial Details">
                    <Card className="sap-content-card" style={{ margin: '0 auto', backgroundColor: '#f8f9fa' }}>
                        
                        {/* CONDITIONAL RENDERING BASED ON VIEW MODE */}
                        {viewMode === 'CREATE' ? (
                            /* --- YOUR ORIGINAL CREATE CODE (UNTTOUCHED) --- */
                            <>
                                <div className="sap-section-wrapper" style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px' }}>
                                    <label style={{ fontSize: '1rem' }}>Equipment</label>
                                    <InputText style={{ width: '30%',marginLeft:'100px' }} value={formData.equipment} onChange={(e) => handleInputChange(e, 'equipment', e.target.value)} />
                                </div>
                                <div className="sap-section-wrapper" style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px' }}>
                                    <label style={{ fontSize: '1rem' }}>Valid on</label>
                                    <InputText style={{ width: '30%',marginLeft:'117px' }} value={formData.validOn} onChange={(e) => handleInputChange(e, 'validOn', e.target.value)} />
                                </div>
                                <div className="sap-section-wrapper" style={{ display: 'flex', alignItems: 'center', gap: '2rem', width: '50%', marginBottom: '20px' }}>
                                    <label style={{ fontSize: '1rem' }}>Equipment Category</label>
                                  <Dropdown aria-label="select category"
                                     value={formData.equipCat}
                                    options={categoryOptions || []}
                                    onChange={(e) => handleInputChange(e, 'equipCat', e.value)}
                                    optionLabel="equipCat"
                                    placeholder="select category"
                                    style={{ width: '40%',marginLeft:"31px" }}
                                    className="small-input" />
                             </div>
                                {/* ... rest of your original Reference card ... */}
                                <div style={{ marginTop: '20px', textAlign: 'right' }}>
                                    <Button label={isCreatePending ? "Saving..." : "Next"} icon={isCreatePending ? "pi pi-spin pi-spinner" : "pi pi-arrow-right"} onClick={handleNext} loading={isCreatePending} disabled={isCreatePending} />
                                </div>
                            </>
                        ) : (
                            /* --- NEW CHANGE MODE UI (The requested screen) --- */
                            <div style={{ width: '50%' }}>
                                <div className="sap-section-wrapper" style={{ display: 'flex', alignItems: 'center', gap: '2rem', marginBottom: '20px' }}>
                                    <label style={{ width: '150px',marginLeft:'0px' }}>Equipment</label>
                                    <InputText style={{ width: '20%' }} value={changeForm.equipment} onChange={(e) => handleChangeInputChange(e, 'equipment', e.target.value)} />
                                     <div style={{  textAlign: 'right',alignItems:'center',backgroundColor:'' }}>
                                    <Button  icon="pi pi-search" onClick={handleFetchDetails} loading={isFetchingAsset} />
                                </div>
                                    </div>
                              
                               
                            </div>
                        )}
                    </Card>
                </TabPanel>

                <TabPanel header="General Data">
                    <Card className="sap-content-card">
                        {/* IMPORTANT: Pass fetchedDetails if they exist, otherwise pass original formData */}
                        <EquipmentScreen initialdata={formData.fetchedDetails || formData}  isEdit={!!formData.isUpdate}  />
                    </Card>
                </TabPanel>
            </TabView>
        </div>
    );
}
export default EquipInitialScreen;