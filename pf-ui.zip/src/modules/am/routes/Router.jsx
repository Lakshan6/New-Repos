import { Routes, Route } from 'react-router-dom';

import EquipInitialScreen from '../screens/Equipment/EquipInitialScreen.jsx';
import AssetInitialScreen from '../screens/Asset Management/AssetInitialScreen.jsx';






const AmRoutes = () => {
  return (
    <Routes>
      {/* This will resolve to /web/landing/qm/material */}
      
      <Route path="create-equip" element={<EquipInitialScreen />} />
      <Route path="create-asset" element={<AssetInitialScreen />} />
       {/* <Route path="create-equip-initial" element={<EquipInitialScreen />} /> */}
      {/* Optional: Default index for the module */}
      <Route index element={<div>AM Home</div>} />
    </Routes>
    
  );
};

export default AmRoutes;