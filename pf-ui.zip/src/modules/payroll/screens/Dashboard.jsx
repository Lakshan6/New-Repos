import React, { useState } from 'react';
import { Card } from 'primereact/card';
import { Chart } from 'primereact/chart';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';

const Dashboard = () => {

    const [payrollRuns] = useState([
        { month: 'Jan 2026', total: 450000, status: 'Completed' },
        { month: 'Feb 2026', total: 470000, status: 'Processing' },
        { month: 'Mar 2026', total: 480000, status: 'Pending' },
    ]);

    const monthlyPayrollData = {
        labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun'],
        datasets: [
            {
                label: 'Total Payroll',
                data: [450000, 470000, 480000, 500000, 520000, 550000],
                borderColor: '#6366F1',
                fill: false,
                tension: 0.4
            }
        ]
    };

    const salaryDistribution = {
        labels: ['Basic', 'HRA', 'Allowances', 'Bonus'],
        datasets: [
            {
                data: [50, 20, 20, 10],
                backgroundColor: ['#6366F1', '#22C55E', '#F59E0B', '#EF4444']
            }
        ]
    };

    const statusBodyTemplate = (rowData) => {
        const severity =
            rowData.status === 'Completed' ? 'success' :
                rowData.status === 'Processing' ? 'warning' :
                    'danger';

        return <Tag value={rowData.status} severity={severity} />;
    };

    return (
        <div className="grid">

            {/* KPI CARDS */}
            <div className="col-12 md:col-6 lg:col-3">
                <Card className="shadow-2 border-round-xl">
                    <div className="flex justify-content-between">
                        <div>
                            <span className="block text-500 mb-2">Total Employees</span>
                            <div className="text-900 text-xl font-bold">1,245</div>
                        </div>
                        <i className="pi pi-users text-blue-500 text-3xl"></i>
                    </div>
                </Card>
            </div>

            <div className="col-12 md:col-6 lg:col-3">
                <Card className="shadow-2 border-round-xl">
                    <div className="flex justify-content-between">
                        <div>
                            <span className="block text-500 mb-2">This Month Payroll</span>
                            <div className="text-900 text-xl font-bold">₹5,50,000</div>
                        </div>
                        <i className="pi pi-wallet text-green-500 text-3xl"></i>
                    </div>
                </Card>
            </div>

            <div className="col-12 md:col-6 lg:col-3">
                <Card className="shadow-2 border-round-xl">
                    <div>
                        <span className="block text-500 mb-2">Pending Approvals</span>
                        <div className="text-900 text-xl font-bold">23</div>
                    </div>
                </Card>
            </div>

            <div className="col-12 md:col-6 lg:col-3">
                <Card className="shadow-2 border-round-xl">
                    <div>
                        <span className="block text-500 mb-2">Net Payout</span>
                        <div className="text-900 text-xl font-bold">₹4,80,000</div>
                    </div>
                </Card>
            </div>

            {/* CHARTS */}
            <div className="col-12 lg:col-8">
                <Card title="Monthly Payroll Trend" className="shadow-2 border-round-xl">
                    <Chart type="line" data={monthlyPayrollData} />
                </Card>
            </div>

            <div className="col-12 lg:col-4">
                <Card title="Salary Distribution" className="shadow-2 border-round-xl">
                    <Chart type="pie" data={salaryDistribution} />
                </Card>
            </div>

            {/* TABLE */}
            <div className="col-12">
                <Card title="Recent Payroll Runs" className="shadow-2 border-round-xl">
                    <DataTable value={payrollRuns} paginator rows={5}>
                        <Column field="month" header="Month" />
                        <Column field="total" header="Total Amount" />
                        <Column field="status" header="Status" body={statusBodyTemplate} />
                    </DataTable>
                </Card>
            </div>

        </div>
    );
};

export default Dashboard;
