// src/pages/master/MasterListView.jsx
import React, { useState } from 'react';
import { useNavigate, useParams } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import { MASTER_CONFIG } from '../../hooks/master/masterConfig';
import { useEntityList } from '../../hooks/master/useEntity';
import SearchCard from '@shared/components/SearchCard';

const MasterListView = () => {
    const { type } = useParams();
    const navigate = useNavigate();

    const config = MASTER_CONFIG[type];
    if (!config) return <div className="p-5 text-red-500">Invalid master type: {type}</div>;

    const {
        data: entities = [],
        isLoading,
        isError,
        error,
        refetch,
    } = useEntityList(config);

    // ── KEY FIX: no useEffect — derive filtered list from search term only ──
    const [searchTerm, setSearchTerm] = useState('');

    const firstColumn = config.columns?.[0];

    const filteredData = searchTerm.trim()
        ? entities.filter((item) => {
            const fieldValue = item[firstColumn?.key];
            if (fieldValue == null) return false;
            return String(fieldValue).toLowerCase().includes(searchTerm.toLowerCase());
          })
        : entities;

    // ─── Breadcrumb ───────────────────────────────────────────────
    const breadcrumbItems = [
        { label: 'PAYROLL', command: () => navigate('/web/landing/payroll') },
        { label: config.title || 'Master List' },
    ];

    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const searchFilters = firstColumn
        ? [
            {
                type: 'InputText',
                label: firstColumn.label,
                name: firstColumn.key,
                placeholder: `e.g. ${firstColumn.label === 'Skill Name' ? 'Java, React, Leadership' : 'search ' + firstColumn.label.toLowerCase() + '...'}`,
            },
          ]
        : [];

    const handleSearch = (values) => {
        setSearchTerm(values[firstColumn?.key || ''] || '');
    };

    const handleClear = () => {
        setSearchTerm('');
        refetch?.();
    };

    const handleAddNew = () => {
        navigate(`/web/landing/payroll/${type}/add`);
    };

    // ─── Date formatter ───────────────────────────────────────────
    const formatDate = (dateString) => {
        if (!dateString) return '—';
        const d = new Date(dateString);
        if (isNaN(d.getTime())) return '—';
        return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
    };

    const dateBodyTemplate = (rowData, column) => formatDate(rowData[column.field]);

    return (
        <div className="surface-ground min-h-screen p-3">
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {searchFilters.length > 0 && (
                <SearchCard
                    filters={searchFilters}
                    onSubmit={handleSearch}
                    onClear={handleClear}
                />
            )}

            <Card className="mt-4">
                <div className="flex justify-content-between align-items-center mb-3 px-2">
                    <h4 className="m-0 text-2xl font-semibold">{config.title}</h4>

                    <Button
                        label="Add New"
                        icon="pi pi-plus"
                        className="p-button-sm p-button-success"
                        onClick={handleAddNew}
                    />
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <DataTable
                    value={filteredData}
                    stripedRows
                    paginator
                    rows={10}
                    rowsPerPageOptions={[10, 25, 50]}
                    rowHover
                    loading={isLoading}
                    emptyMessage={
                        isError
                            ? `Error: ${error?.message || 'Failed to load data'}`
                            : `No ${config.title.toLowerCase()} found`
                    }
                    onRowClick={(e) =>
                        navigate(`/web/landing/payroll/${type}/detail`, {
                            state: { id: e.data.id },
                        })
                    }
                    selectionMode="single"
                    className="cursor-pointer"
                    responsiveLayout="scroll"
                >
                    {config.columns?.map((col) => (
                        <Column
                            key={col.key}
                            field={col.key}
                            header={col.label}
                            sortable={col.sortable !== false}
                            body={col.type === 'date' ? dateBodyTemplate : undefined}
                        />
                    ))}
                </DataTable>
            </Card>
        </div>
    );
};

export default MasterListView;