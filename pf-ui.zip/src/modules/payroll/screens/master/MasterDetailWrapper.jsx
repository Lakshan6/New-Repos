import MasterDetailView from './MasterDetailView';
import { useNavigate, useLocation } from 'react-router';
const MasterDetailWrapper = () => {
    const location = useLocation();
    // /web/landing/hrms/skill/{id}
    const parts = location.pathname.split('/');
    const type = parts[parts.length - 2];
    const id = parts[parts.length - 1];
    return <MasterDetailView type={type} id={id} />;
};



export default MasterDetailWrapper;