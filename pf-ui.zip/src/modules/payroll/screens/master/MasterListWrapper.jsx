import MasterListView from './MasterListView';
import { useNavigate, useLocation } from 'react-router';

const MasterListWrapper = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const type = location.pathname.split('/').pop();
    return (
        <MasterListView
            type={type}
            onRowClick={(id) =>
                navigate(`${location.pathname}/${id}`)
            }
        />
    );
};

export default MasterListWrapper;