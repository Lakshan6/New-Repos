// src/pages/master/MasterDetailView.jsx
import React, { useEffect, useRef, useState, useMemo } from 'react';
import { useNavigate, useParams, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { InputSwitch } from 'primereact/inputswitch';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { MASTER_CONFIG } from '../../hooks/master/masterConfig';
import {
  useEntityDetail,
  useUpdateEntity,
  useCreateEntity,
  useDeleteEntity,
} from '../../hooks/master/useEntity';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';
import { usePayrollEnums } from '../../hooks/master/usePayrollEnums';

const MasterDetailView = () => {
  const { type } = useParams();
  const location = useLocation();
  const navigate = useNavigate();
  const toast = useRef(null);

  // ── Stable config reference ─────────────────────────────────────────────
  const config = useMemo(() => MASTER_CONFIG[type], [type]);

  const id = location.state?.id;
  const isAddMode = !id && location.pathname.endsWith('/add');

  const [formData, setFormData] = useState({});
  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isAddMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  // ── Collect all unique enumKeys from select fields in this config ───────
  const enumKeysNeeded = useMemo(() => {
    if (!config?.formFields) return [];
    return [
      ...new Set(
        config.formFields
          .filter((f) => f.type === 'select' && !!f.enumKey)
          .map((f) => f.enumKey)
      ),
    ];
  }, [config]);

  // ── Single API call — fetches ALL enums needed for this page ────────────
  const {
    getOptions,
    isLoading: isEnumsLoading,
    isError: isEnumsError,
  } = usePayrollEnums(enumKeysNeeded);

  // ── Entity detail query ─────────────────────────────────────────────────
  const {
    data,
    isLoading: isDetailLoading,
    isError: isDetailError,
    refetch,
  } = useEntityDetail({
    entityType: config?.entityType,
    id,
    listEndpoint: config?.listEndpoint,
  });

  const updateMutation = useUpdateEntity({
    entityType: config?.entityType,
    listEndpoint: config?.listEndpoint,
  });

  const createMutation = useCreateEntity({
    entityType: config?.entityType,
    listEndpoint: config?.listEndpoint,
  });

  const deleteMutation = useDeleteEntity({
    entityType: config?.entityType,
    listEndpoint: config?.listEndpoint,
  });

  // ── Tenant list — only needed in add mode ───────────────────────────────
  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({
    enabled: isAddMode,
  });

  const tenantOptions = (tenants || []).map((t) => ({
    label:
      t.name ||
      t.tenantName ||
      t.displayName ||
      t.companyName ||
      t.code ||
      'Unnamed Tenant',
    value: t.tenantId || t.id || t.code || '',
  }));

  // ── Check if this config has a tenantId field ───────────────────────────
  const hasTenantField = config?.formFields?.some((f) => f.key === 'tenantId');

  const isOperationRunning =
    updateMutation.isPending ||
    createMutation.isPending ||
    deleteMutation.isPending;

  // ── Initialize blank form for add mode ─────────────────────────────────
  useEffect(() => {
    if (!isAddMode || !config) return;
    const blank = config.formFields.reduce(
      (acc, field) => {
        if (field.key === 'tenantId') return acc;
        acc[field.key] =
          field.type === 'checkbox'
            ? false
            : field.type === 'date'
            ? null
            : field.type === 'number'
            ? null  // Changed from 0 to null
            : '';
        return acc;
      },
      { tenantId: '' }
    );
    setFormData(blank);
    setOriginalFormData({ ...blank });
  }, [isAddMode, config]);

  // ── Initialize form from API data ───────────────────────────────────────
  useEffect(() => {
    if (isAddMode || !data || !config || hasInitialized) return;

    const values = config.formFields.reduce((acc, field) => {
      let v = data[field.key];
      if (field.type === 'date' && v) {
        try {
          const d = new Date(v);
          acc[field.key] = !isNaN(d.getTime())
            ? d.toISOString().split('T')[0]
            : '';
        } catch {
          acc[field.key] = '';
        }
      } else if (field.type === 'checkbox') {
        acc[field.key] = !!v;
      } else {
        acc[field.key] = v ?? '';
      }
      return acc;
    }, {});

    if (!values.tenantId) values.tenantId = data.tenantId ?? '';

    setFormData(values);
    setOriginalFormData(values);
    setHasInitialized(true);
  }, [data, config, isAddMode, hasInitialized]);

  // ── Invalid config guard ────────────────────────────────────────────────
  if (!config)
    return (
      <div className="p-5 text-red-500">Invalid master type: {type}</div>
    );

  // ── Handlers ────────────────────────────────────────────────────────────
  const handleInputChange = (key, value) =>
    setFormData((prev) => ({ ...prev, [key]: value }));

  const handleCancel = () => {
    if (isAddMode) return navigate(-1);
    setFormData({ ...originalFormData });
    setIsEditing(false);
    toast.current?.show({
      severity: 'info',
      summary: 'Cancelled',
      detail: 'Changes reverted',
      life: 2500,
    });
  };

  const handleDelete = () =>
    confirmDialog({
      message: `Are you sure you want to delete this ${config.title.toLowerCase()}?\nThis action cannot be undone.`,
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: () => {
        deleteMutation.mutate(id, {
          onSuccess: () => {
            toast.current?.show({
              severity: 'success',
              summary: 'Deleted',
              detail: `${config.title} deleted successfully`,
              life: 2500,
            });
            setTimeout(
              () =>
                navigate(`/web/landing/payroll/${type}`, { replace: true }),
              800
            );
          },
          onError: (err) => {
            const msg =
              err?.response?.data?.message || err?.message || 'Delete failed';
            toast.current?.show({
              severity: 'error',
              summary: 'Delete Failed',
              detail: msg,
              life: 5000,
            });
          },
        });
      },
    });

  const handleSave = () => {
    if (isAddMode && hasTenantField && !formData.tenantId) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Required',
        detail: 'Tenant is required',
        life: 4000,
      });
      return;
    }

    let payload = { ...formData };

    config.formFields.forEach((field) => {
      let val = payload[field.key];
      if (typeof val === 'string') val = val.trim();
      if (field.type === 'checkbox') val = !!val;
      if (field.type === 'date' && val) {
        try {
          val = new Date(val).toISOString();
        } catch {
          val = null;
        }
      }
      // Fixed number field handling
      if (field.type === 'number') {
        if (val === '' || val === null || val === undefined) {
          val = null; // Send null for empty number fields
        } else {
          val = Number(val);
        }
      }
      payload[field.key] = val;
    });

    const nameField = config.formFields.find((f) => /name|code/i.test(f.key));
    if (nameField && !payload[nameField.key]) {
      toast.current?.show({
        severity: 'warn',
        summary: 'Required',
        detail: `${nameField.label} is required`,
        life: 4000,
      });
      return;
    }

    const mutationOptions = {
      onSuccess: () => {
        toast.current?.show({
          severity: 'success',
          summary: isAddMode ? 'Created' : 'Updated',
          detail: `${config.title} ${
            isAddMode ? 'created' : 'updated'
          } successfully`,
          life: 3000,
        });
        if (isAddMode) {
          setTimeout(
            () =>
              navigate(`/web/landing/payroll/${type}`, { replace: true }),
            800
          );
        } else {
          setIsEditing(false);
          refetch();
        }
      },
      onError: (err) => {
        const msg =
          err?.response?.data?.message || err?.message || 'Failed';
        toast.current?.show({
          severity: 'error',
          summary: isAddMode ? 'Create Failed' : 'Update Failed',
          detail: msg,
          life: 5000,
        });
      },
    };

    if (isAddMode) {
      createMutation.mutate(payload, mutationOptions);
    } else {
      updateMutation.mutate({ id, payload }, mutationOptions);
    }
  };

  // ── Loading / error states ───────────────────────────────────────────────
  if (!isAddMode && isDetailLoading)
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">
              Loading {config.title?.toLowerCase()} details...
            </p>
          </div>
        </PageContentCard>
      </div>
    );

  if (!isAddMode && (isDetailError || !data))
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load {config.title}</h2>
            <p className="text-600 mb-4">Record not found or invalid access</p>
            <div className="flex gap-3">
              <Button
                label="Go Back"
                icon="pi pi-arrow-left"
                outlined
                onClick={() => navigate(-1)}
              />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );

  // ── Breadcrumbs ─────────────────────────────────────────────────────────
  const breadcrumbItems = [
    { label: 'PAYROLL', command: () => navigate('/web/landing/payroll') },
    {
      label: `${config.title}s`,
      command: () => navigate(`/web/landing/payroll/${type}`),
    },
    { label: isAddMode ? 'Add New' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const pageTitle = isAddMode
    ? `Add New ${config.title}`
    : `${config.title} Details`;
  const subtitle =
    formData[config.formFields?.[0]?.key] ||
    (isAddMode ? `New ${config.title}` : '—');

  // ── Exclude tenantId — rendered separately ──────────────────────────────
  const fieldsToRender = config.formFields.filter((f) => f.key !== 'tenantId');

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />

      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">

        {/* ── Header bar ── */}
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button
              icon="pi pi-arrow-left"
              text
              rounded
              onClick={() => navigate(-1)}
            />
            <h4 className="m-0 text-2xl font-semibold">{pageTitle}</h4>
            {!isAddMode && id && (
              <Button
                size="small"
                label={id}
                severity="secondary"
                rounded
                onClick={() => navigator.clipboard.writeText(id)}
                tooltip="Copy ID"
              />
            )}
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">
            {isAddMode ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isOperationRunning}
                  size="small"
                />
                <Button
                  label="Create"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={createMutation.isPending}
                  size="small"
                />
              </>
            ) : isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  size="small"
                />
                <Button
                  label="Delete"
                  icon="pi pi-trash"
                  severity="danger"
                  outlined
                  onClick={handleDelete}
                  loading={deleteMutation.isPending}
                  size="small"
                />
                <Button
                  label="Save"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={updateMutation.isPending}
                  size="small"
                />
              </>
            ) : (
              <Button
                label="Edit"
                icon="pi pi-pencil"
                outlined
                onClick={() => setIsEditing(true)}
                size="small"
              />
            )}
          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        {/* ── Form ── */}
        <TabbedSectionCard transparentBorder>
          <SectionCardWithHeader
            title={`${config.title} Information`}
            subtitle={subtitle}
          >
            <div className="sc-grid-2 gap-4">

              {/* ── Tenant Dropdown (add mode only) ── */}
              {hasTenantField && isAddMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading}
                  />
                </div>
              )}

              {/* ── All other fields ── */}
              {fieldsToRender.map((field) => {
                const disabled =
                  !(isEditing || isAddMode) || field.editable === false;
                const value = formData[field.key];

                // ── Checkbox / Toggle ────────────────────────────────────
                if (field.type === 'checkbox') {
                  return (
                    <div key={field.key}>
                      <label className="block text-600 mb-1">
                        {field.label}
                      </label>
                      <div className="flex align-items-center gap-3">
                        <InputSwitch
                          checked={!!value}
                          onChange={(e) =>
                            handleInputChange(field.key, e.value)
                          }
                          disabled={disabled}
                        />
                        <span className="text-500 text-sm">
                          {value ? 'Yes' : 'No'}
                        </span>
                      </div>
                    </div>
                  );
                }

                // ── Date Picker ──────────────────────────────────────────
                if (field.type === 'date') {
                  return (
                    <div key={field.key}>
                      <label className="block text-600 mb-1">
                        {field.label}
                      </label>
                      <Calendar
                        value={value ? new Date(value) : null}
                        onChange={(e) => {
                          if (!e.value) {
                            handleInputChange(field.key, '');
                            return;
                          }
                          const d = e.value;
                          const yyyy = d.getFullYear();
                          const mm = String(d.getMonth() + 1).padStart(2, '0');
                          const dd = String(d.getDate()).padStart(2, '0');
                          handleInputChange(field.key, `${yyyy}-${mm}-${dd}`);
                        }}
                        showIcon
                        dateFormat="yy-mm-dd"
                        disabled={disabled}
                        className="w-full"
                        placeholder={
                          isAddMode || isEditing ? 'Select date' : ''
                        }
                      />
                    </div>
                  );
                }

                // ── Select / Dropdown (fully API-driven via usePayrollEnums) ─
                if (field.type === 'select') {
                  const dropdownOptions = field.enumKey
                    ? getOptions(field.enumKey)
                    : [];
                  const enumLoading = !!field.enumKey && isEnumsLoading;

                  return (
                    <div key={field.key}>
                      <label className="block text-600 mb-1">
                        {field.label}
                      </label>

                      {/* Read-only when not editing */}
                      {disabled ? (
                        <InputText
                          value={value ?? ''}
                          disabled
                          className="w-full bg-gray-100"
                        />
                      ) : (
                        <>
                          <Dropdown
                            value={value}
                            options={dropdownOptions}
                            onChange={(e) =>
                              handleInputChange(field.key, e.value)
                            }
                            placeholder={
                              enumLoading
                                ? 'Loading options...'
                                : dropdownOptions.length === 0
                                ? 'No options available'
                                : `Select ${field.label.toLowerCase()}`
                            }
                            className="w-full"
                            showClear
                            disabled={enumLoading}
                            emptyMessage={
                              isEnumsError
                                ? 'Failed to load options'
                                : 'No options available'
                            }
                          />
                          {isEnumsError && field.enumKey && (
                            <small className="p-error mt-1 block">
                              Could not load options — please refresh and try again.
                            </small>
                          )}
                        </>
                      )}
                    </div>
                  );
                }

                // ── Textarea (description fields) ────────────────────────
                if (
                  field.type === 'textarea' ||
                  field.key.toLowerCase().includes('description')
                ) {
                  return (
                    <div key={field.key}>
                      <label className="block text-600 mb-1">
                        {field.label}
                      </label>
                      <InputTextarea
                        value={value || ''}
                        onChange={(e) =>
                          handleInputChange(field.key, e.target.value)
                        }
                        disabled={disabled}
                        rows={4}
                        className="w-full"
                        placeholder={
                          isAddMode || isEditing
                            ? `Enter ${field.label.toLowerCase()}`
                            : ''
                        }
                      />
                    </div>
                  );
                }

                // ── Text / Number (default) ──────────────────────────────
                return (
                  <div key={field.key}>
                    <label className="block text-600 mb-1">
                      {field.label}
                    </label>
                    <InputText
                      type={field.type === 'number' ? 'number' : 'text'}
                      value={value ?? ''}
                      onChange={(e) =>
                        handleInputChange(field.key, e.target.value)
                      }
                      disabled={disabled}
                      className="w-full"
                      placeholder={
                        isAddMode || isEditing
                          ? `Enter ${field.label.toLowerCase()}`
                          : ''
                      }
                      step={field.type === 'number' ? 'any' : undefined}
                    />
                  </div>
                );
              })}

              {/* ── Tenant ID read-only in detail mode ── */}
              {hasTenantField && !isAddMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant ID</label>
                  <InputText
                    value={formData.tenantId || '—'}
                    disabled
                    className="w-full bg-gray-100"
                  />
                </div>
              )}

            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default MasterDetailView;