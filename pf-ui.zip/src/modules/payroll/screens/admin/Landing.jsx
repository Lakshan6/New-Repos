import { ProgressBar } from 'primereact/progressbar';
import { Tag } from 'primereact/tag';

const DASHBOARD_DATA = {
    attendance: {
        month: 'January',
        year: 2026,
        percentage: 92,
        workingDays: 22,
        presentDays: 20,
        lateDays: 1,
        leaveDays: 1,
        updatedAt: '10:15 AM',
    },
    leave: {
        al: { used: 2, total: 22 },
        cl: { used: 10, total: 12 },
        sl: { used: 7, total: 20 },
        cycleEnd: '31 April 2026',
    },
    holidays: [
        {
            name: 'Makara Sankranti',
            date: '15 Jan 2026',
            daysLeft: 12,
            location: 'Bengaluru Office',
        },
        {
            name: 'Republic Day',
            date: '26 Jan 2026',
            daysLeft: 21,
            location: 'Bengaluru Office',
        },
    ],
    requests: {
        total: 2,
        pending: 1,
        lastUpdated: 'Yesterday',
        items: [
            {
                type: 'Leave Request',
                status: 'Pending',
                submittedOn: '12 Jan',
            },
            {
                type: 'Expense Claim',
                status: 'Under Review',
                submittedOn: '10 Jan',
            },
        ],
    },
};

const RECENT_ATTENDANCE = [
    { day: '01', status: 'P' },
    { day: '02', status: 'P' },
    { day: '03', status: 'L' },
    { day: '04', status: 'P' },
    { day: '05', status: 'P' },
    { day: '08', status: 'P' },
    { day: '09', status: 'P' },
    { day: '10', status: 'P' },
    { day: '11', status: 'A' },
    { day: '12', status: 'P' },
    { day: '15', status: 'P' },
    { day: '16', status: 'P' },
    { day: '17', status: 'P' },
    { day: '18', status: 'P' },
];

const ANNOUNCEMENTS = [
    {
        title: 'Revised Leave Policy',
        description: 'Updated leave rules effective from 1 Feb 2026.',
        date: '14 Jan 2026',
        type: 'Policy',
    },
    {
        title: 'IT Declaration Window Open',
        description: 'Submit your IT declaration before 31 Jan 2026.',
        date: '10 Jan 2026',
        type: 'Reminder',
    },
    {
        title: 'Annual Day Celebrations',
        description: 'Photos from Annual Day are now available.',
        date: '05 Jan 2026',
        type: 'General',
    },
];

const PAYROLL_DATA = {
    lastSalary: {
        month: 'December 2025',
        netPay: '₹82,450',
        payDate: '31 Dec 2025',
        status: 'Credited',
    },
    nextSalary: {
        expectedDate: '31 Jan 2026',
    },
};

const DOCUMENTS = [
    {
        name: 'Leave Policy',
        updatedOn: '01 Feb 2026',
    },
    {
        name: 'HR Handbook',
        updatedOn: '15 Dec 2025',
    },
    {
        name: 'IT Security Policy',
        updatedOn: '10 Jan 2026',
    },
    {
        name: 'Code of Conduct',
        updatedOn: '01 Apr 2025',
    },
];

const COMPLIANCE_DATA = {
    perks: ['Medical Insurance', 'Transport Facility', 'Canteen Services'],
    apr: {
        financialYear: '2025–26',
        status: 'Not Submitted',
        dueDate: '31 Jan 2026',
    },
    tax: {
        financialYear: '2025–26',
        status: 'Submitted',
        lastUpdated: '10 Jan 2026',
    },
};

const Landing = () => {
    const data = DASHBOARD_DATA;

    return (
        <div className="grid">
            {/* My Attendance */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-user text-green-500" />
                        <span className="font-medium text-900">
                            My Attendance ({data.attendance.month})
                        </span>
                    </div>

                    <div className="flex justify-content-between align-items-start">
                        <div>
                            <div className="text-4xl font-bold text-900 mb-1">
                                {data.attendance.percentage}%
                            </div>
                            <div className="text-sm text-500 mb-3">Monthly Attendance</div>
                        </div>
                        <div className="flex flex-column justify-content-center gap-2 text-sm text-600">
                            <span>
                                <strong>Present: </strong>
                                {data.attendance.presentDays}/{data.attendance.workingDays}
                            </span>
                            <span>
                                <strong>Leave: </strong>
                                {data.attendance.leaveDays}
                            </span>
                            <span>
                                <strong>Late: </strong>
                                {data.attendance.lateDays}
                            </span>
                        </div>
                    </div>

                    <ProgressBar value={data.attendance.percentage} />

                    <div className="text-xs text-500 mt-4">
                        Updated today at {data.attendance.updatedAt}
                    </div>
                </div>
            </div>

            {/* Leave Balance */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-briefcase text-orange-500" />
                        <span className="font-medium text-900">Leave Balance</span>
                    </div>

                    {/* Earned Leave */}
                    <div className="mb-4">
                        <div className="flex justify-content-between align-items-center text-sm mb-2">
                            <span className="text-900 font-medium">Annual Leave</span>
                            <span className="text-600">
                                {data.leave.al.used} / {data.leave.al.total}
                            </span>
                        </div>
                        {/* <ProgressBar value={(data.leave.el.used / data.leave.el.total) * 100} /> */}
                    </div>

                    {/* Casual Leave */}
                    <div className="mb-4">
                        <div className="flex justify-content-between align-items-center text-sm mb-2">
                            <span className="text-900 font-medium">Casual Leave</span>
                            <span className="text-600">
                                {data.leave.cl.used} / {data.leave.cl.total}
                            </span>
                        </div>
                        {/* <ProgressBar value={(data.leave.cl.used / data.leave.cl.total) * 100} /> */}
                    </div>

                    {/* Sick Leave */}
                    <div>
                        <div className="flex justify-content-between align-items-center text-sm mb-2">
                            <span className="text-900 font-medium">Sick Leave</span>
                            <span className="text-600">
                                {data.leave.sl.used} / {data.leave.sl.total}
                            </span>
                        </div>
                        {/* <ProgressBar value={(data.leave.sl.used / data.leave.sl.total) * 100} /> */}
                    </div>

                    <div className="text-xs text-500 mt-4">
                        Leave cycle ends on {data.leave.cycleEnd}
                    </div>
                </div>
            </div>

            {/* Upcoming Holidays */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-calendar text-blue-500" />
                        <span className="font-medium text-900">Upcoming Holidays</span>
                    </div>

                    {/* Primary (Nearest) Holiday */}
                    <div className="mb-4">
                        <div className="flex justify-content-between align-items-center mb-1">
                            <div>
                                <div className="text-lg font-semibold text-900">
                                    {data.holidays[0].name}
                                </div>
                                <div className="text-sm text-500">{data.holidays[0].date}</div>
                            </div>

                            <Tag
                                value={`In ${data.holidays[0].daysLeft} days`}
                                severity="warning"
                            />
                        </div>
                    </div>

                    {/* Secondary Holiday */}
                    <div className="border-top-1 surface-border pt-3">
                        <div className="flex justify-content-between align-items-center">
                            <div>
                                <div className="text-sm font-medium text-800">
                                    {data.holidays[1].name}
                                </div>
                                <div className="text-xs text-500">{data.holidays[1].date}</div>
                            </div>

                            <span className="text-xs text-500">
                                In {data.holidays[1].daysLeft} days
                            </span>
                        </div>
                    </div>

                    <div className="flex align-items-center gap-2 text-sm text-600 mt-4">
                        <i className="pi pi-map-marker" />
                        <span>{data.holidays[0].location}</span>
                    </div>
                </div>
            </div>

            {/* My Requests */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-file text-purple-500" />
                        <span className="font-medium text-900">My Requests</span>
                    </div>

                    <div className="flex gap-4">
                        {/* Left summary */}
                        <div className="flex-1">
                            <div className="text-4xl font-bold text-900 mb-1">
                                {data.requests.total}
                            </div>
                            <div className="text-sm text-500 mb-2">Active Requests</div>

                            <div className="text-sm text-600 mb-1">
                                <strong>Pending:</strong> {data.requests.pending}
                            </div>
                            <div className="text-xs text-500">
                                Updated {data.requests.lastUpdated}
                            </div>
                        </div>

                        {/* Right detailed list */}
                        <div className="flex-1">
                            <ul className="list-none p-0 m-0 text-sm">
                                {data.requests.items.map((req) => (
                                    <li key={req.type} className="mb-3">
                                        <div className="font-medium text-900">{req.type}</div>
                                        <div className="flex align-items-center gap-2 text-xs text-600">
                                            <span>{req.status}</span>
                                            <span>•</span>
                                            <span>{req.submittedOn}</span>
                                        </div>
                                    </li>
                                ))}
                            </ul>
                        </div>
                    </div>

                    <div className="border-top-1 surface-border mt-4 pt-3 flex justify-content-between align-items-center">
                        <Tag value={`${data.requests.pending} pending`} severity="warning" />
                        <span className="text-sm text-primary cursor-pointer">View all →</span>
                    </div>
                </div>
            </div>

            <div className="col-12 md:col-6">
                {/* Quick Actions */}
                <div className="card p-4 mb-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-bolt text-primary" />
                        <span className="font-medium text-900">Quick Actions</span>
                    </div>

                    <div className="flex flex-wrap gap-3">
                        {/* My Profile */}
                        <div className="flex align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-user text-blue-500 text-xl" />
                            <span className="font-medium">My Profile</span>
                        </div>

                        {/* Apply Leave */}
                        <div className="flex align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-calendar-plus text-primary text-xl" />
                            <span className="font-medium">Apply Leave</span>
                        </div>

                        {/* Regularize Attendance */}
                        <div className="flex align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-history text-orange-500 text-xl" />
                            <span className="font-medium">Regularize</span>
                        </div>

                        {/* Employee Directory */}
                        <div className="flex align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-users text-indigo-500 text-xl" />
                            <span className="font-medium">Employee Directory</span>
                        </div>
                    </div>
                </div>

                <div className="card p-4 mb-3">
                    <div className="flex align-items-center justify-content-between mb-4">
                        <div className="flex align-items-center gap-2">
                            <i className="pi pi-megaphone text-primary" />
                            <span className="font-medium text-900">Announcements</span>
                        </div>
                        <span className="text-sm text-primary cursor-pointer">View all →</span>
                    </div>

                    <ul className="list-none p-0 m-0">
                        {ANNOUNCEMENTS.map((item) => (
                            <li
                                key={item.title}
                                className="pb-3 mb-3 border-bottom-1 surface-border"
                            >
                                <div className="flex justify-content-between align-items-start mb-1">
                                    <span className="font-medium text-900">{item.title}</span>
                                    <span className="text-xs text-500">{item.date}</span>
                                </div>

                                <div className="text-sm text-600 mb-1">{item.description}</div>

                                <span className="text-xs text-primary">{item.type}</span>
                            </li>
                        ))}
                    </ul>
                </div>

                {/* Benefits & Compliance */}
                <div className="card p-4 mt-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-shield text-primary" />
                        <span className="font-medium text-900">Benefits & Compliance</span>
                    </div>

                    {/* Perks */}
                    <div className="flex mb-3 justify-content-between align-items-center">
                        <div className="text-sm font-medium text-900 mb-2">Perks & Benefits</div>
                        <ul className="flex list-none p-0 m-0 text-sm text-700 gap-4">
                            {COMPLIANCE_DATA.perks.map((perk) => (
                                <li key={perk} className="mb-1">
                                    {perk}
                                </li>
                            ))}
                        </ul>
                        <span className="text-sm text-primary cursor-pointer">View benefits →</span>
                    </div>

                    {/* APR */}
                    <div className="border-top-1 surface-border pt-3 mb-2">
                        <div className="flex justify-content-between gap-3 mb-2">
                            <div className="text-sm font-medium text-900 mb-1">
                                Annual Property Returns FY {COMPLIANCE_DATA.apr.financialYear}
                            </div>
                            <div className="text-sm text-700">
                                <span className="font-medium text-orange-600">
                                    {COMPLIANCE_DATA.apr.status}
                                </span>
                            </div>
                        </div>
                        <div className="text-xs text-500">Due by {COMPLIANCE_DATA.apr.dueDate}</div>
                    </div>

                    {/* Tax */}
                    <div className="border-top-1 surface-border pt-3">
                        <div className="flex justify-content-between gap-3 mb-2">
                            <div className="text-sm font-medium text-900 mb-1">
                                Tax Declaration FY {COMPLIANCE_DATA.tax.financialYear}
                            </div>
                            <div className="text-sm text-700">
                                <span className="font-medium text-green-600">
                                    {COMPLIANCE_DATA.tax.status}
                                </span>
                            </div>
                        </div>
                        <div className="text-xs text-500">
                            Last updated {COMPLIANCE_DATA.tax.lastUpdated}
                        </div>
                    </div>
                </div>
            </div>

            <div className="col-12 md:col-6">
                <div className="card p-4 mb-3">
                    <div className="flex align-items-center justify-content-between mb-4">
                        <div className="flex align-items-center gap-2">
                            <i className="pi pi-calendar text-primary" />
                            <span className="font-medium text-900">
                                Attendance Overview (Last 14 Days)
                            </span>
                        </div>
                        <span className="text-sm text-primary cursor-pointer">
                            View full attendance →
                        </span>
                    </div>

                    <div className="flex flex-wrap gap-3">
                        {RECENT_ATTENDANCE.map((item) => (
                            <div
                                key={item.day}
                                className="flex flex-column align-items-center gap-1"
                            >
                                <div
                                    className={`flex align-items-center justify-content-center border-round text-sm font-medium ${
                                        item.status === 'P'
                                            ? 'bg-green-100 text-green-700'
                                            : item.status === 'L'
                                              ? 'bg-orange-100 text-orange-700'
                                              : 'bg-red-100 text-red-700'
                                    }`}
                                    style={{ width: '2.5rem', height: '2.5rem' }}
                                >
                                    {item.status}
                                </div>
                                <span className="text-xs text-500">{item.day}</span>
                            </div>
                        ))}
                    </div>

                    <div className="flex gap-4 text-sm text-600 mt-4">
                        <span>
                            <span
                                className="inline-block bg-green-100 border-round mr-1"
                                style={{ width: '0.75rem', height: '0.75rem' }}
                            />{' '}
                            Present
                        </span>
                        <span>
                            <span
                                className="inline-block bg-orange-100 border-round mr-1"
                                style={{ width: '0.75rem', height: '0.75rem' }}
                            />{' '}
                            Leave
                        </span>
                        <span>
                            <span
                                className="inline-block bg-red-100 border-round mr-1"
                                style={{ width: '0.75rem', height: '0.75rem' }}
                            />{' '}
                            Absent
                        </span>
                    </div>
                </div>

                <div className="card p-4 mb-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-wallet text-primary" />
                        <span className="font-medium text-900">Payroll</span>
                    </div>

                    {/* Last Salary */}
                    <div className="mb-4">
                        <div className="text-sm text-500 mb-1">
                            Last Salary ({PAYROLL_DATA.lastSalary.month})
                        </div>

                        <div className="flex justify-content-between align-items-center">
                            <div className="text-3xl font-bold text-900">
                                {PAYROLL_DATA.lastSalary.netPay}
                            </div>
                            <Tag value={PAYROLL_DATA.lastSalary.status} severity="success" />
                        </div>

                        <div className="text-sm text-600 mt-2">
                            Credited on {PAYROLL_DATA.lastSalary.payDate}
                        </div>
                    </div>

                    {/* Next Salary */}
                    <div className="border-top-1 surface-border pt-3 mb-4">
                        <div className="text-sm text-500 mb-1">Next Salary Expected</div>
                        <div className="text-sm font-medium text-900">
                            {PAYROLL_DATA.nextSalary.expectedDate}
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3">
                        <span className="text-sm text-primary cursor-pointer">
                            Download Payslip →
                        </span>
                        <span className="text-sm text-primary cursor-pointer">
                            View Salary Details →
                        </span>
                    </div>
                </div>

                {/* Documents & Policies */}
                <div className="card p-4 mt-3">
                    <div className="flex align-items-center justify-content-between mb-4">
                        <div className="flex align-items-center gap-2">
                            <i className="pi pi-folder-open text-primary" />
                            <span className="font-medium text-900">Documents & Policies</span>
                        </div>
                        <span className="text-sm text-primary cursor-pointer">View all →</span>
                    </div>

                    <ul className="list-none p-0 m-0">
                        {DOCUMENTS.map((doc) => (
                            <li
                                key={doc.name}
                                className="flex justify-content-between align-items-center py-3 border-bottom-1 surface-border"
                            >
                                <div className="flex align-items-center gap-2">
                                    <i className="pi pi-file-pdf text-red-500" />
                                    <span className="text-sm text-900">{doc.name}</span>
                                </div>

                                <span className="text-xs text-500">Updated {doc.updatedOn}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>
        </div>
    );
};

export { Landing };
