import { Route, Routes, useNavigate, useLocation } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';

import Dashboard from '../screens/Dashboard';
import MasterListView from '../screens/master/MasterListView';

import MasterDetailView from '../screens/master/MasterDetailView';

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.PAYROLL}
            translationsAtom={translationsAtom}
        >
            <Routes>
                <Route index element={<Dashboard />} />

           <Route path="/:type" element={<MasterListView />} />
          <Route path="/:type/detail" element={<MasterDetailView />} />
<Route path="/:type/add" element={<MasterDetailView />} />


                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
