// src/hooks/master/usePayrollEnums.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

const SERVICE_PREFIX = '/erp-payroll-service';

const getHeaders = () => ({
  Authorization: `Bearer ${localStorage.getItem('authToken') ?? ''}`,
});

/**
 * Fetches multiple enum lists in a single API call.
 *
 * Usage:
 *   const { getOptions } = usePayrollEnums(['limitTypes', 'amountTypes']);
 *   <Dropdown options={getOptions('limitTypes')} ... />
 *
 * API response shape:
 *   { limitTypes: [{ value: 'STANDALONE', label: 'Standalone' }, ...] }
 *
 * @param {string[]} enumNames - list of enum keys to fetch
 */
export const usePayrollEnums = (enumNames = []) => {
  const sortedNames = [...enumNames].sort();

  const query = useQuery({
    queryKey: ['payroll-enums', sortedNames],
    enabled: Array.isArray(enumNames) && enumNames.length > 0,
    staleTime: 10 * 60 * 1000,
    refetchOnWindowFocus: false,

    queryFn: async () => {
      const res = await apiRequest({
        service: 'payroll',
        endpoint: `${SERVICE_PREFIX}/api/enums/by-names?enums=${enumNames.join(',')}`,
        method: 'GET',
        useGateway: true,
        headers: getHeaders(),
      });
      return res;
    },

    select: (res) => {
      if (!res || typeof res !== 'object') return {};

      // Unwrap if apiRequest wraps response under .data
      const actual =
        res?.data && typeof res.data === 'object' ? res.data : res;

      // API already returns { label, value } objects — use them directly
      // { limitTypes: [{ value: 'STANDALONE', label: 'Standalone' }, ...] }
      const result = {};
      Object.entries(actual).forEach(([key, values]) => {
        if (Array.isArray(values)) {
          result[key] = values; // ← no remapping needed, shape is already correct
        }
      });
      return result;
    },
  });

  const getOptions = (enumKey) => query.data?.[enumKey] ?? [];

  return {
    enumData: query.data ?? {},
    getOptions,
    isLoading: query.isLoading,
    isError: query.isError,
    error: query.error,
  };
};

export default usePayrollEnums;