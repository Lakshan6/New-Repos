// src/hooks/master/masterConfig.js
export const MASTER_CONFIG = {
  financialYear: {
    entityType: 'financialYear',
    listEndpoint: '/api/fy',
    baseendpoint: '/erp-payroll-service',
    title: 'Financial Year Master',

    columns: [
      { key: 'name', label: 'Financial Year', sortable: true },
      { key: 'startDate', label: 'Start Date', type: 'date', sortable: true },
      { key: 'endDate', label: 'End Date', type: 'date', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
      { key: 'isClosed', label: 'Closed', type: 'boolean', sortable: true },
      { key: 'tenantId', label: 'Tenant ID', sortable: true },
    ],

    formFields: [
      { key: 'name', label: 'Financial Year', type: 'text', editable: true },
      { key: 'startDate', label: 'Start Date', type: 'date', editable: true },
      { key: 'endDate', label: 'End Date', type: 'date', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
      { key: 'tenantId', label: 'Tenant ID', type: 'text', editable: true },
      { key: 'isClosed', label: 'Closed', type: 'checkbox', editable: true },
    ],
  },

  itSection: {
    entityType: 'itSection',
    listEndpoint: '/api/it-section',
    baseendpoint: '/erp-payroll-service',
    title: 'IT Section Master',

    columns: [
      { key: 'sectionCode', label: 'Section Code', sortable: true },
      { key: 'description', label: 'Description', sortable: true },
      { key: 'limitType', label: 'Limit Type', sortable: true },
      { key: 'maxLimitAmount', label: 'Max Limit Amount', type: 'number', sortable: true },
      { key: 'regimeAllowed', label: 'Regime Allowed', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
    ],

    formFields: [
      { key: 'financialYearId', label: 'Financial Year ID', type: 'number', editable: true },
      { key: 'sectionCode', label: 'Section Code', type: 'text', editable: true },
      { key: 'description', label: 'Description', type: 'text', editable: true },
      { key: 'limitType', label: 'Limit Type', type: 'select', enumKey: 'limitTypes', editable: true },
      { key: 'maxLimitAmount', label: 'Max Limit Amount', type: 'number', editable: true },
      { key: 'regimeAllowed', label: 'Regime Allowed', type: 'select', enumKey: 'regimeTypes', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
    ],
  },

  itInvestItem: {
    entityType: 'itInvestItem',
    listEndpoint: '/api/it-investItem',
    baseendpoint: '/erp-payroll-service',
    title: 'IT Investment Item Master',

    columns: [
      { key: 'sectionId', label: 'Section ID', sortable: true },
      { key: 'code', label: 'Item Code', sortable: true },
      { key: 'name', label: 'Item Name', sortable: true },
      { key: 'calculationLogic', label: 'Calculation Logic', sortable: true },
      { key: 'itemMaxLimit', label: 'Max Limit', type: 'number', sortable: true },
      { key: 'proofRequired', label: 'Proof Required', type: 'boolean', sortable: true },
    ],

    formFields: [
      { key: 'sectionId', label: 'Section ID', type: 'number', editable: true },
      { key: 'code', label: 'Item Code', type: 'text', editable: true },
      { key: 'name', label: 'Item Name', type: 'text', editable: true },
      { key: 'calculationLogic', label: 'Calculation Logic', type: 'select', enumKey: 'calculationLogics', editable: true },
      { key: 'itemMaxLimit', label: 'Max Limit', type: 'number', editable: true },
      { key: 'proofRequired', label: 'Proof Required', type: 'checkbox', editable: true },
    ],
  },

  SalaryComponentItem: {
    entityType: 'SalaryComponentItem',
    listEndpoint: '/api/sal-comp',
    baseendpoint: '/erp-payroll-service',
    title: 'Salary Item Master',

    columns: [
      { key: 'name', label: 'Item Name', sortable: true },
      { key: 'code', label: 'Item Code', sortable: true },
      { key: 'type', label: 'Type', sortable: true },
      { key: 'amountType', label: 'Amount Type', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
    ],

    formFields: [
      { key: 'name', label: 'Item Name', type: 'text', editable: true },
      { key: 'displayName', label: 'Display Name', type: 'text', editable: true },
      { key: 'code', label: 'Item Code', type: 'text', editable: true },
      { key: 'type', label: 'Type', type: 'select', enumKey: 'salaryComponentTypes', editable: true },
      { key: 'amountType', label: 'Amount Type', type: 'select', enumKey: 'amountTypes', editable: true },
      { key: 'formula', label: 'Formula', type: 'text', editable: true },
      { key: 'conditionExpression', label: 'Condition Expression', type: 'text', editable: true },
      { key: 'percentageValue', label: 'Percentage Value', type: 'number', editable: true },
      { key: 'roundOffType', label: 'Round Off Type', type: 'select', enumKey: 'roundOffTypes', editable: true },
      { key: 'roundToNearest', label: 'Round To Nearest', type: 'number', editable: true },
      { key: 'isProrated', label: 'Prorated', type: 'checkbox', editable: true },
      { key: 'isTaxable', label: 'Taxable', type: 'checkbox', editable: true },
      { key: 'includeInCtc', label: 'Include In CTC', type: 'checkbox', editable: true },
      { key: 'affectsPf', label: 'Affects PF', type: 'checkbox', editable: true },
      { key: 'affectsEsi', label: 'Affects ESI', type: 'checkbox', editable: true },
      { key: 'affectsPt', label: 'Affects PT', type: 'checkbox', editable: true },
      { key: 'affectsGratuity', label: 'Affects Gratuity', type: 'checkbox', editable: true },
      { key: 'isFlexibleBenefit', label: 'Flexible Benefit', type: 'checkbox', editable: true },
      { key: 'payAgainstClaim', label: 'Pay Against Claim', type: 'checkbox', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
      { key: 'tenantId', label: 'Tenant ID', type: 'text', editable: true },
    ],
  },

  itCategory: {
    entityType: 'itCategory',
    listEndpoint: '/api/it-category',
    baseendpoint: '/erp-payroll-service',
    title: 'Income Tax Category Master',

    columns: [
      { key: 'id', label: 'ID', sortable: true },
      { key: 'code', label: 'Category Code', sortable: true },
      { key: 'description', label: 'Description', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
      { key: 'qualificationRules', label: 'Qualification Rules', sortable: false },
      { key: 'createdBy', label: 'Created By', sortable: true },
    ],

    formFields: [
      { key: 'code', label: 'Category Code', type: 'text', editable: true },
      { key: 'description', label: 'Description_Text', type: 'text', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
      { key: 'qualificationRules', label: 'Qualification Rules (JSON)', type: 'text', editable: true },
    ],
  },

  itRegime: {
    entityType: 'itRegime',
    listEndpoint: '/api/it-regime',
    baseendpoint: '/erp-payroll-service',
    title: 'Income Tax Regime Master',

    columns: [
      { key: 'id', label: 'ID', sortable: true },
      { key: 'code', label: 'Regime Code', sortable: true },
      { key: 'description', label: 'Description', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
    ],

    formFields: [
      { key: 'code', label: 'Regime Code', type: 'text', editable: true },
      { key: 'description', label: 'Description', type: 'text', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
    ],
  },

  payPeriod: {
    entityType: 'payPeriod',
    listEndpoint: '/api/pay-period',
    baseendpoint: '/erp-payroll-service',
    title: 'Pay Period Master',

    columns: [
      { key: 'financialYearId', label: 'Financial Year ID', sortable: true },
      { key: 'name', label: 'Period Name', sortable: true },
      { key: 'startDate', label: 'Start Date', type: 'date', sortable: true },
      { key: 'endDate', label: 'End Date', type: 'date', sortable: true },
      { key: 'scheduledPayDate', label: 'Scheduled Pay Date', type: 'date', sortable: true },
    ],

    formFields: [
      { key: 'financialYearId', label: 'Financial Year ID', type: 'number', editable: true },
      { key: 'name', label: 'Period Name', type: 'text', editable: true },
      { key: 'periodSequence', label: 'Sequence', type: 'number', editable: true },
      { key: 'startDate', label: 'Start Date', type: 'date', editable: true },
      { key: 'endDate', label: 'End Date', type: 'date', editable: true },
      { key: 'scheduledPayDate', label: 'Scheduled Pay Date', type: 'date', editable: true },
      { key: 'status', label: 'Status', type: 'select', enumKey: 'payPeriodStatuses', editable: true },
      { key: 'tenantId', label: 'Tenant ID', type: 'text', editable: true },
    ],
  },

  paySettings: {
    entityType: 'paySettings',
    listEndpoint: '/api/pay-settings',
    baseendpoint: '/erp-payroll-service',
    title: 'Payroll Settings',

    columns: [
      { key: 'attendanceInputType', label: 'Attendance Type', sortable: true },
      { key: 'companyPan', label: 'Company PAN', sortable: true },
      { key: 'emailPayslip', label: 'Email Payslip', type: 'boolean', sortable: true },
      { key: 'netPayRoundingType', label: 'Rounding Type', sortable: true },
      { key: 'accountingGrouping', label: 'Accounting Grouping', sortable: true },
    ],

    formFields: [
      { key: 'tenantId', label: 'Tenant ID', type: 'text', editable: true },
      { key: 'attendanceInputType', label: 'Attendance Input Type', type: 'select', enumKey: 'attendanceInputTypes', editable: true },
      { key: 'payCycleStartDay', label: 'Pay Cycle Start Day', type: 'number', editable: true },
      { key: 'defaultDaysDivisor', label: 'Default Days Divisor', type: 'number', editable: true },
      { key: 'companyPan', label: 'Company PAN', type: 'text', editable: true },
      { key: 'companyTan', label: 'Company TAN', type: 'text', editable: true },
      { key: 'pfEstablishmentCode', label: 'PF Establishment Code', type: 'text', editable: true },
      { key: 'esiEstablishmentCode', label: 'ESI Establishment Code', type: 'text', editable: true },
      { key: 'emailPayslip', label: 'Email Payslip', type: 'checkbox', editable: true },
      { key: 'encryptPayslip', label: 'Encrypt Payslip', type: 'checkbox', editable: true },
      { key: 'ptEstablishmentCode', label: 'PT Establishment Code', type: 'text', editable: true },
      { key: 'payslipPasswordFormat', label: 'Payslip Password Format', type: 'select', enumKey: 'payslipPasswordFormats', editable: true },
      { key: 'netPayRoundingType', label: 'Net Pay Rounding Type', type: 'select', enumKey: 'roundOffTypes', editable: true },
      { key: 'netPayRoundingNearest', label: 'Round To Nearest', type: 'number', editable: true },
      { key: 'maxOvertimeHoursPerMonth', label: 'Max Overtime Hours / Month', type: 'number', editable: true },
      { key: 'accountingGrouping', label: 'Accounting Grouping', type: 'select', enumKey: 'accountingGroupings', editable: true },
    ],
  },

  ptState: {
    entityType: 'ptState',
    listEndpoint: '/api/pt-state',
    baseendpoint: '/erp-payroll-service',
    title: 'Professional Tax State Master',

    columns: [
      { key: 'stateCode', label: 'State Code', sortable: true },
      { key: 'stateName', label: 'State Name', sortable: true },
      { key: 'isPtApplicable', label: 'PT Applicable', type: 'boolean', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
    ],

    formFields: [
      { key: 'stateCode', label: 'State Code', type: 'text', editable: true },
      { key: 'stateName', label: 'State Name', type: 'text', editable: true },
      { key: 'isPtApplicable', label: 'PT Applicable', type: 'checkbox', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
    ],
  },

  costCenter: {
    entityType: 'costCenter',
    listEndpoint: '/api/cost-center',
    baseendpoint: '/erp-payroll-service',
    title: 'Cost Center Master',

    columns: [
      { key: 'id', label: 'ID', sortable: true },
      { key: 'code', label: 'Cost Center Code', sortable: true },
      { key: 'name', label: 'Cost Center Name', sortable: true },
      { key: 'description', label: 'Description', sortable: true },
      { key: 'isActive', label: 'Active', type: 'boolean', sortable: true },
    ],

    formFields: [
      { key: 'code', label: 'Cost Center Code', type: 'text', editable: true },
      { key: 'name', label: 'Cost Center Name', type: 'text', editable: true },
      { key: 'description', label: 'Description', type: 'text', editable: true },
      { key: 'isActive', label: 'Active', type: 'checkbox', editable: true },
    ],
  },
};