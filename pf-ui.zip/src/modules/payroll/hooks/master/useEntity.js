// src/hooks/master/useEntity.js

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

const SERVICE_PREFIX = '/erp-payroll-service';

/* ------------------ GENERIC HEADER ------------------ */

const getHeaders = (entityType, customHeaders = {}) => ({
  'X-Entity-Type': entityType,
  Authorization: `Bearer ${localStorage.getItem('authToken') ?? ''}`,
  ...customHeaders,
});

/* ================= LIST ================= */

export const useEntityList = ({ entityType, listEndpoint, customHeaders = {} }) => {
  return useQuery({
    queryKey: [entityType, 'list'],

    queryFn: async () => {
      const res = await apiRequest({
        service: 'payroll',
        endpoint: `${SERVICE_PREFIX}${listEndpoint}`,
        method: 'GET',
        useGateway: true,
        headers: getHeaders(entityType, customHeaders),
      });

      return res;
    },

    select: (res) => {
      if (Array.isArray(res)) return res;
      if (Array.isArray(res?.data)) return res.data;
      if (Array.isArray(res?.content)) return res.content;
      if (Array.isArray(res?.data?.content)) return res.data.content;
      return [];
    },

    staleTime: 300000,
    refetchOnWindowFocus: false,
  });
};

/* ================= DETAIL ================= */

export const useEntityDetail = ({ entityType, id, listEndpoint, customHeaders = {} }) => {
  return useQuery({
    queryKey: [entityType, 'detail', id],
    enabled: !!id,

    queryFn: async () => {
      const res = await apiRequest({
        service: 'payroll',
        endpoint: `${SERVICE_PREFIX}${listEndpoint}/${id}`,
        method: 'GET',
        headers: getHeaders(entityType, customHeaders),
      });

      return res?.data ?? res;
    },

    select: (item) => {
      if (!item) return null;

      return {
        ...item,
        validFrom: item.validFrom ?? null,
        validUpto: item.validUpto ?? null,
      };
    },

    staleTime: 300000,
    refetchOnWindowFocus: false,
  });
};


/* ================= CREATE ================= */

export const useCreateEntity = ({ entityType, listEndpoint, customHeaders = {} }) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (payload) =>
      apiRequest({
        service: 'payroll',
        endpoint: `${SERVICE_PREFIX}${listEndpoint}`,
        method: 'POST',
        headers: getHeaders(entityType, customHeaders),
        body: payload,
      }),

    onSuccess: () => {
      // Invalidate list query so the list refreshes automatically when going back
      queryClient.invalidateQueries([entityType, 'list']);
    },

    onError: (error) => {
      // Let the component handle the error display
      throw error;
    },
  });
};

/* ================= DELETE ================= */
export const useDeleteEntity = ({ entityType, listEndpoint, customHeaders = {} }) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: (id) =>
      apiRequest({
        service: 'payroll',
        endpoint: `${SERVICE_PREFIX}${listEndpoint}/${id}`,
        method: 'DELETE',
        headers: getHeaders(entityType, customHeaders),
      }),

    onSuccess: () => {
      queryClient.invalidateQueries([entityType, 'list']);
      queryClient.removeQueries([entityType, 'detail']);
    },

    onError: (error) => {
      throw error;
    },
  });
};

/* ================= UPDATE ================= */

export const useUpdateEntity = ({ entityType, listEndpoint, customHeaders = {} }) => {
  const queryClient = useQueryClient();

  return useMutation({
    mutationFn: ({ id, payload }) =>
      apiRequest({
        service: 'payroll',
        endpoint: `${SERVICE_PREFIX}${listEndpoint}/${id}`,
        method: 'PATCH',
        headers: getHeaders(entityType, customHeaders),
        body: payload,
      }),

    onSuccess: (_, { id }) => {
      queryClient.invalidateQueries([entityType, 'list']);
      queryClient.invalidateQueries([entityType, 'detail', id]);
    },
  });
};