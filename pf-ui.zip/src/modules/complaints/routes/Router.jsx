import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';
import { translationsAtom } from '../store/atoms';
import OverviewScreen from '../screens/OverviewScreen';
import RegisterComplaintScreen from '../screens/RegisterComplaintScreen';
import UpdateComplaintScreen from '../screens/UpdateComplaintScreen';

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.COMPLAINTS}
            translationsAtom={translationsAtom}
        >
            <Routes>
                <Route index element={<OverviewScreen />} />
                <Route path="overview" element={<OverviewScreen />} />
                <Route path="register" element={<RegisterComplaintScreen />} />
                <Route path="update" element={<UpdateComplaintScreen />} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
