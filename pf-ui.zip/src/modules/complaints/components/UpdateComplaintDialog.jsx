import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';

const FAULT_OPTIONS = [
    { label: 'Very high', value: 'Very high' },
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
];

const STATUS_OPTIONS = [
    { label: 'Complaint Opened', value: 'Complaint Opened' },
    { label: 'Complaint Inprogress', value: 'Complaint Inprogress' },
    { label: 'Complaint Closed', value: 'Complaint Closed' },
];

const BANNER_STYLES = {
    success: ['var(--green-50)', 'var(--green-200)', 'var(--green-800)', 'var(--green-500)'],
    warn: ['var(--yellow-50)', 'var(--yellow-200)', 'var(--yellow-800)', 'var(--yellow-500)'],
    info: ['var(--blue-50)', 'var(--blue-200)', 'var(--blue-800)', 'var(--blue-500)'],
};

const REQUIRED_UPDATE = ['description', 'nameOfEmployeeResp', 'faultClassification', 'statusDesc'];

const dialogStyle = { width: '54rem', maxWidth: '96vw' };
const dialogBreakpoints = { '900px': '90vw', '600px': '98vw' };
const dialogHeaderIconStyle = { fontSize: '1.15rem' };
const loadingSpinnerStyle = { width: 40, height: 40 };
const sectionDividerStyle = { borderBottom: '1px solid var(--surface-border)' };
const sectionIconStyle = { fontSize: '0.82rem' };
const sectionLabelStyle = {
    color: 'var(--text-color-secondary)',
    textTransform: 'uppercase',
    letterSpacing: '0.055em',
};
const fieldLabelStyle = { color: 'var(--text-color-secondary)' };
const fieldHintStyle = { opacity: 0.65 };
const fieldErrorStyle = { fontSize: '0.75rem' };
const fieldErrorIconStyle = { fontSize: '0.7rem' };
const readonlyStyle = {
    background: 'var(--surface-100)',
    color: 'var(--text-color-secondary)',
    cursor: 'not-allowed',
};

const makeBannerIconStyle = (iconColor) => ({
    color: iconColor,
    fontSize: '0.9rem',
    flexShrink: 0,
});
const makeBannerTextStyle = (textColor) => ({ color: textColor });

const getToken = () => localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) ?? '';

const buildEmptyFromComplaint = (complaint) => ({
    description: complaint?.description ?? '',
    nameOfEmployeeResp: complaint?.nameOfEmployeeResp ?? '',
    faultClassification: complaint?.faultClassification ?? null,
    statusDesc: complaint?.statusDesc ?? null,
    complaintCategory: complaint?.complaintCategory ?? null,
    complaintType: complaint?.complaintType ?? null,
    productType: complaint?.productType ?? null,
    problemType: complaint?.problemType ?? null,
    actionTaken: complaint?.actionTaken ?? '',
    problemOrDamageCode: complaint?.problemOrDamageCode ?? '',
    problemDamageDescription: complaint?.problemDamageDescription ?? '',
    notes: complaint?.notes ?? '',
});

function Sec({ label, icon }) {
    return (
        <div className="flex align-items-center gap-2 mt-4 mb-2 pb-1" style={sectionDividerStyle}>
            <i className={`pi ${icon} text-primary`} style={sectionIconStyle} />
            <span className="text-xs font-semibold" style={sectionLabelStyle}>
                {label}
            </span>
        </div>
    );
}

Sec.propTypes = { label: PropTypes.string.isRequired, icon: PropTypes.string.isRequired };

function Fld({ label, req, err, hint, col, children }) {
    return (
        <div className={`field col-12 md:col-${col}`}>
            <label className="block text-sm font-medium mb-1" style={fieldLabelStyle}>
                {label}
                {req && <span className="text-red-500 ml-1">*</span>}
                {hint && (
                    <span className="ml-2 text-xs font-normal" style={fieldHintStyle}>
                        ({hint})
                    </span>
                )}
            </label>
            {children}
            {err && (
                <small
                    className="p-error flex align-items-center gap-1 mt-1"
                    style={fieldErrorStyle}
                >
                    <i className="pi pi-exclamation-circle" style={fieldErrorIconStyle} />
                    {err}
                </small>
            )}
        </div>
    );
}

Fld.propTypes = {
    label: PropTypes.string.isRequired,
    req: PropTypes.bool,
    err: PropTypes.string,
    hint: PropTypes.string,
    col: PropTypes.number,
    children: PropTypes.node.isRequired,
};

Fld.defaultProps = { req: false, err: null, hint: null, col: 6 };

function Banner({ type, icon, html }) {
    const [bg, border, textColor, iconColor] = BANNER_STYLES[type] ?? BANNER_STYLES.info;

    const iconStyle = useMemo(() => makeBannerIconStyle(iconColor), [iconColor]);
    const textStyle = useMemo(() => makeBannerTextStyle(textColor), [textColor]);
    const containerStyle = useMemo(
        () => ({ background: bg, border: `1px solid ${border}` }),
        [bg, border],
    );
    const htmlContent = useMemo(() => ({ __html: html }), [html]);

    return (
        <div className="flex align-items-center gap-2 border-round p-3 mb-3" style={containerStyle}>
            <i className={`pi ${icon}`} style={iconStyle} />
            <span className="text-sm" style={textStyle} dangerouslySetInnerHTML={htmlContent} />
        </div>
    );
}

Banner.propTypes = {
    type: PropTypes.oneOf(['success', 'warn', 'info']).isRequired,
    icon: PropTypes.string.isRequired,
    html: PropTypes.string.isRequired,
};

export function UpdateComplaintDialog({ visible, onHide, complaint, onSuccess }) {
    const toast = useRef(null);

    const [form, setForm] = useState(() => buildEmptyFromComplaint(complaint));
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const [dropdowns, setDropdowns] = useState(null);
    const [ddLoading, setDdLoading] = useState(false);

    useEffect(() => {
        if (!visible || !complaint) return;
        setForm(buildEmptyFromComplaint(complaint));
        setErrors({});

        if (dropdowns) return;
        setDdLoading(true);
        apiRequest({
            method: 'GET',
            service: 'irs',
            endpoint: '/complaint/form/dropdowns',
            useGateway: true,
            headers: { Authorization: `Bearer ${getToken()}` },
        })
            .then((dd) => setDropdowns(dd ?? {}))
            .catch(() =>
                toast.current?.show({
                    severity: 'warn',
                    summary: 'Warning',
                    detail: 'Could not load dropdown options',
                }),
            )
            .finally(() => setDdLoading(false));
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [visible, complaint]);

    const set = useCallback((field, val) => {
        setForm((f) => ({ ...f, [field]: val }));
        setErrors((e) => ({ ...e, [field]: null }));
    }, []);

    const onDescriptionChange = useCallback((e) => set('description', e.target.value), [set]);
    const onNameOfEmployeeRespChange = useCallback(
        (e) => set('nameOfEmployeeResp', e.target.value),
        [set],
    );
    const onFaultClassificationChange = useCallback(
        (e) => set('faultClassification', e.value),
        [set],
    );
    const onStatusDescChange = useCallback((e) => set('statusDesc', e.value), [set]);
    const onComplaintCategoryChange = useCallback((e) => set('complaintCategory', e.value), [set]);
    const onComplaintTypeChange = useCallback((e) => set('complaintType', e.value), [set]);
    const onProductTypeChange = useCallback((e) => set('productType', e.value), [set]);
    const onProblemTypeChange = useCallback((e) => set('problemType', e.value), [set]);
    const onProblemOrDamageCodeChange = useCallback(
        (e) => set('problemOrDamageCode', e.target.value),
        [set],
    );
    const onProblemDamageDescChange = useCallback(
        (e) => set('problemDamageDescription', e.target.value),
        [set],
    );
    const onActionTakenChange = useCallback((e) => set('actionTaken', e.target.value), [set]);
    const onNotesChange = useCallback((e) => set('notes', e.target.value), [set]);

    const validate = useCallback(() => {
        const errs = {};
        REQUIRED_UPDATE.forEach((k) => {
            const v = form[k];
            if (v === null || v === undefined || (typeof v === 'string' && !v.trim())) {
                errs[k] = 'Required';
            }
        });
        setErrors(errs);
        return Object.keys(errs).length === 0;
    }, [form]);

    const doClose = useCallback(() => {
        setErrors({});
        onHide();
    }, [onHide]);

    const handleSubmit = useCallback(async () => {
        if (!validate()) {
            toast.current?.show({
                severity: 'error',
                summary: 'Validation Failed',
                detail: 'Fill in all required fields marked with *',
            });
            return;
        }

        const token = getToken();
        setSubmitting(true);
        try {
            const res = await apiRequest({
                method: 'POST',
                service: 'irs',
                endpoint: '/complaint/update',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${token}`,
                    'X-User-Id': form.nameOfEmployeeResp.trim(),
                },
                body: {
                    requestInfo: { authToken: token },
                    complaintNo: complaint.complaintNo,
                    description: form.description.trim(),
                    nameOfEmployeeResp: form.nameOfEmployeeResp.trim(),
                    faultClassification: form.faultClassification,
                    statusDesc: form.statusDesc,
                    complaintCategory: form.complaintCategory || undefined,
                    complaintType: form.complaintType || undefined,
                    productType: form.productType || undefined,
                    problemType: form.problemType || undefined,
                    actionTaken: form.actionTaken?.trim() || undefined,
                    problemOrDamageCode: form.problemOrDamageCode?.trim() || undefined,
                    problemDamageDescription: form.problemDamageDescription?.trim() || undefined,
                    notes: form.notes?.trim() || undefined,
                },
            });

            if (res?.success) {
                toast.current?.show({
                    severity: 'success',
                    summary: 'Complaint Updated',
                    detail:
                        res.message ?? `Complaint #${complaint.complaintNo} updated successfully`,
                    life: 4000,
                });
                setTimeout(() => {
                    doClose();
                    if (onSuccess) onSuccess();
                }, 700);
            } else {
                (res?.errors ?? ['Update failed']).forEach((msg) =>
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: msg }),
                );
            }
        } catch (err) {
            toast.current?.show({
                severity: 'error',
                summary: 'Server Error',
                detail: err?.message || 'Failed to update complaint. Please try again.',
            });
        } finally {
            setSubmitting(false);
        }
    }, [form, validate, doClose, onSuccess, complaint]);

    const toOpts = useCallback((arr) => (arr ?? []).map((v) => ({ label: v, value: v })), []);

    const footer = useMemo(
        () => (
            <div className="flex justify-content-end gap-2 pt-1">
                <Button
                    label="Cancel"
                    icon="pi pi-times"
                    outlined
                    severity="secondary"
                    onClick={doClose}
                    disabled={submitting}
                />
                <Button
                    label={submitting ? 'Updating…' : 'Save Changes'}
                    icon={submitting ? 'pi pi-spin pi-spinner' : 'pi pi-check'}
                    onClick={handleSubmit}
                    disabled={submitting || ddLoading}
                />
            </div>
        ),
        [submitting, ddLoading, doClose, handleSubmit],
    );

    const dialogHeader = useMemo(
        () => (
            <div className="flex align-items-center gap-2">
                <i className="pi pi-pencil text-primary" style={dialogHeaderIconStyle} />
                <span className="font-semibold text-lg">
                    Update Complaint {complaint?.complaintNo ? `#${complaint.complaintNo}` : ''}
                </span>
            </div>
        ),
        [complaint?.complaintNo],
    );

    return (
        <>
            <Toast ref={toast} position="top-right" />
            <Dialog
                visible={visible}
                onHide={doClose}
                header={dialogHeader}
                footer={footer}
                style={dialogStyle}
                breakpoints={dialogBreakpoints}
                modal
                draggable={false}
                resizable={false}
                closeOnEscape={!submitting}
                dismissableMask={!submitting}
            >
                {ddLoading ? (
                    <div className="flex flex-column align-items-center justify-content-center py-7 gap-3">
                        <ProgressSpinner style={loadingSpinnerStyle} />
                        <span className="text-color-secondary text-sm">Loading form data…</span>
                    </div>
                ) : (
                    <div className="p-fluid">
                        <Sec label="Complaint Identity" icon="pi-tag" />
                        <div className="formgrid grid">
                            <Fld label="Complaint Number" col={4} hint="read-only">
                                <InputText
                                    value={complaint?.complaintNo ?? ''}
                                    readOnly
                                    style={readonlyStyle}
                                />
                            </Fld>
                            <Fld label="Project Code" col={4} hint="read-only">
                                <InputText
                                    value={complaint?.projectCode ?? ''}
                                    readOnly
                                    style={readonlyStyle}
                                />
                            </Fld>
                            <Fld label="Customer" col={4} hint="read-only">
                                <InputText
                                    value={complaint?.customerName ?? complaint?.customerCode ?? ''}
                                    readOnly
                                    style={readonlyStyle}
                                />
                            </Fld>
                        </div>

                        <Sec label="Status & Classification" icon="pi-sliders-h" />
                        <div className="formgrid grid">
                            <Fld label="Status" req err={errors.statusDesc} col={6}>
                                <Dropdown
                                    value={form.statusDesc}
                                    options={STATUS_OPTIONS}
                                    onChange={onStatusDescChange}
                                    placeholder="Select status"
                                    className={errors.statusDesc ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld
                                label="Fault Classification"
                                req
                                err={errors.faultClassification}
                                col={6}
                            >
                                <Dropdown
                                    value={form.faultClassification}
                                    options={FAULT_OPTIONS}
                                    onChange={onFaultClassificationChange}
                                    placeholder="Select severity"
                                    className={errors.faultClassification ? 'p-invalid' : ''}
                                    showClear
                                />
                            </Fld>
                        </div>

                        <Sec label="Problem Details" icon="pi-exclamation-circle" />
                        <div className="formgrid grid">
                            <Fld label="Description" req err={errors.description} col={12}>
                                <InputTextarea
                                    value={form.description}
                                    onChange={onDescriptionChange}
                                    rows={3}
                                    autoResize
                                    placeholder="Describe the complaint clearly…"
                                    className={errors.description ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld label="Complaint Category" col={6}>
                                <Dropdown
                                    value={form.complaintCategory}
                                    options={toOpts(dropdowns?.complaintCategories)}
                                    onChange={onComplaintCategoryChange}
                                    placeholder="Select category"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Complaint Type" col={6}>
                                <Dropdown
                                    value={form.complaintType}
                                    options={toOpts(dropdowns?.complaintTypes)}
                                    onChange={onComplaintTypeChange}
                                    placeholder="Select type"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Product Type" col={6}>
                                <Dropdown
                                    value={form.productType}
                                    options={toOpts(dropdowns?.productTypes)}
                                    onChange={onProductTypeChange}
                                    placeholder="Select product type"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Problem Type" col={6}>
                                <Dropdown
                                    value={form.problemType}
                                    options={toOpts(dropdowns?.problemTypes)}
                                    onChange={onProblemTypeChange}
                                    placeholder="Select problem type"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Problem / Damage Code" col={6}>
                                <InputText
                                    value={form.problemOrDamageCode}
                                    onChange={onProblemOrDamageCodeChange}
                                    placeholder="e.g. OTHR"
                                />
                            </Fld>
                            <Fld label="Problem / Damage Description" col={6}>
                                <InputText
                                    value={form.problemDamageDescription}
                                    onChange={onProblemDamageDescChange}
                                    placeholder="Brief damage description"
                                />
                            </Fld>
                        </div>

                        <Sec label="Employee & Action" icon="pi-user" />
                        <div className="formgrid grid">
                            <Fld
                                label="Employee Responsible"
                                req
                                err={errors.nameOfEmployeeResp}
                                col={6}
                            >
                                <InputText
                                    value={form.nameOfEmployeeResp}
                                    onChange={onNameOfEmployeeRespChange}
                                    placeholder="Full name of responsible employee"
                                    className={errors.nameOfEmployeeResp ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld label="Action Taken" col={6}>
                                <InputText
                                    value={form.actionTaken}
                                    onChange={onActionTakenChange}
                                    placeholder="e.g. Replaced spare unit"
                                />
                            </Fld>
                            <Fld label="Notes" col={12}>
                                <InputTextarea
                                    value={form.notes}
                                    onChange={onNotesChange}
                                    rows={2}
                                    autoResize
                                    placeholder="Additional notes…"
                                />
                            </Fld>
                        </div>

                        <Banner
                            type="info"
                            icon="pi-info-circle"
                            html="Only editable fields are shown. Complaint number, project, and customer cannot be changed."
                        />
                    </div>
                )}
            </Dialog>
        </>
    );
}

UpdateComplaintDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
    complaint: PropTypes.shape({
        complaintNo: PropTypes.number,
        projectCode: PropTypes.string,
        customerCode: PropTypes.string,
        customerName: PropTypes.string,
        description: PropTypes.string,
        nameOfEmployeeResp: PropTypes.string,
        faultClassification: PropTypes.string,
        statusDesc: PropTypes.string,
        complaintCategory: PropTypes.string,
        complaintType: PropTypes.string,
        productType: PropTypes.string,
        problemType: PropTypes.string,
        actionTaken: PropTypes.string,
        problemOrDamageCode: PropTypes.string,
        problemDamageDescription: PropTypes.string,
        notes: PropTypes.string,
    }),
    onSuccess: PropTypes.func,
};

UpdateComplaintDialog.defaultProps = { complaint: null, onSuccess: null };
