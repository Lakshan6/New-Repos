import { useState, useEffect, useCallback, useRef, useMemo, memo } from 'react';
import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Tag } from 'primereact/tag';
import { Toast } from 'primereact/toast';
import { ProgressBar } from 'primereact/progressbar';
import { Toolbar } from 'primereact/toolbar';
import { OverlayPanel } from 'primereact/overlaypanel';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';
import { UpdateComplaintDialog } from '../components/UpdateComplaintDialog';

// ── Static maps & config ──────────────────────────────────────────────────────

const STATUS_SEVERITY_MAP = {
    'Complaint Opened': 'warning',
    'Complaint Closed': 'success',
    'Complaint Inprogress': 'info',
};

const FAULT_SEVERITY_MAP = {
    'Very high': 'danger',
    High: 'warning',
    Medium: 'info',
};

//const DESC_PREVIEW_LEN = 60;
const ROWS_PER_PAGE_OPTIONS = [7, 10, 20];

// ── Prop objects — module-level to satisfy react-perf/jsx-no-new-object-as-prop

const TOOLTIP_LEFT = { position: 'left' };
const TABLE_STYLE = { width: '100%', minWidth: 'unset' };
const PROGRESS_STYLE = { height: '3px' };
const WRAPPER_STYLE = { overflow: 'hidden' };

// ── Cell styles ───────────────────────────────────────────────────────────────

const truncSpanStyle = {
    display: 'block',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    maxWidth: '100%',
};

const truncBtnStyle = {
    display: 'block',
    width: '100%',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    cursor: 'pointer',
    color: 'var(--primary-color)',
    textDecoration: 'underline',
    textDecorationStyle: 'dotted',
    textUnderlineOffset: '2px',
    background: 'none',
    border: 'none',
    padding: 0,
    font: 'inherit',
    textAlign: 'left',
};

const overlayPStyle = {
    maxWidth: '360px',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
    lineHeight: 1.6,
    fontSize: 'inherit',
    color: 'var(--text-color)',
    margin: 0,
};

const descWrapStyle = {
    whiteSpace: 'normal',
    wordBreak: 'break-word',
    lineHeight: 1.5,
    fontSize: 'inherit',
};

// ── Column widths ─────────────────────────────────────────────────────────────

const COL_COMPLAINT_NO = { width: '100px', fontWeight: 600, overflow: 'hidden' };
const COL_PROJECT = { width: '110px', overflow: 'hidden' };
const COL_CUSTOMER = { width: '150px', overflow: 'hidden' };
const COL_DESCRIPTION = { width: '190px' };
const COL_EMPLOYEE = { width: '150px', overflow: 'hidden' };
const COL_STATUS = { width: '150px', overflow: 'hidden' };
const COL_FAULT = { width: '100px', overflow: 'hidden' };
const COL_DATE = { width: '110px', overflow: 'hidden' };
const COL_CITY = { width: '100px', overflow: 'hidden' };
const COL_ACTION = { width: '85px', textAlign: 'center', overflow: 'hidden' };

// ── Pure helpers ──────────────────────────────────────────────────────────────

const getToken = () => localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) ?? '';

const formatDate = (dateStr) => {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    });
};

// ── DescriptionCell ───────────────────────────────────────────────────────────
const DescriptionCell = memo(function DescriptionCell({ value }) {
    if (!value) return <span>—</span>;

    const truncated = value.length > 25 ? `${value.slice(0, 25)}...` : value;

    return <span style={descWrapStyle}>{truncated}</span>;
});

DescriptionCell.propTypes = { value: PropTypes.string };
DescriptionCell.defaultProps = { value: null };

// ── TruncatedCell — ellipsis + overlay on click ───────────────────────────────

const TruncatedCell = memo(function TruncatedCell({ value, maxLen }) {
    const op = useRef(null);
    const onToggle = useCallback((e) => {
        op.current?.toggle(e);
    }, []);

    if (!value) return <span>—</span>;
    if (value.length <= maxLen) return <span style={truncSpanStyle}>{value}</span>;

    return (
        <>
            <button
                type="button"
                style={truncBtnStyle}
                onClick={onToggle}
                title={value}
                aria-label="View full content"
            >
                {value}
            </button>
            <OverlayPanel ref={op} dismissable>
                <p style={overlayPStyle}>{value}</p>
            </OverlayPanel>
        </>
    );
});

TruncatedCell.propTypes = { value: PropTypes.string, maxLen: PropTypes.number };
TruncatedCell.defaultProps = { value: null, maxLen: 30 };

// ── PlainTruncatedCell — ellipsis only, no interaction ───────────────────────

const PlainTruncatedCell = memo(function PlainTruncatedCell({ value }) {
    if (!value) return <span>—</span>;
    return (
        <span style={truncSpanStyle} title={value}>
            {value}
        </span>
    );
});

PlainTruncatedCell.propTypes = { value: PropTypes.string };
PlainTruncatedCell.defaultProps = { value: null };

// ── UpdateComplaintScreen ─────────────────────────────────────────────────────

export default function UpdateComplaintScreen() {
    const toast = useRef(null);

    const [complaints, setComplaints] = useState([]);
    const [loading, setLoading] = useState(false);
    const [globalFilter, setGlobalFilter] = useState('');
    const [updateVisible, setUpdateVisible] = useState(false);
    const [selectedComplaint, setSelectedComplaint] = useState(null);

    const fetchComplaints = useCallback(() => {
        setLoading(true);
        apiRequest({
            method: 'GET',
            service: 'irs',
            endpoint: '/complaint/all',
            useGateway: true,
            headers: { Authorization: `Bearer ${getToken()}` },
        })
            .then((data) => setComplaints(data ?? []))
            .catch(() =>
                toast.current?.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load complaints. Please try again.',
                }),
            )
            .finally(() => setLoading(false));
    }, []);

    useEffect(() => {
        fetchComplaints();
    }, [fetchComplaints]);

    const onUpdateHide = useCallback(() => {
        setUpdateVisible(false);
        setSelectedComplaint(null);
    }, []);

    const onEditClick = useCallback((rowData) => {
        setSelectedComplaint(rowData);
        setUpdateVisible(true);
    }, []);

    const onUpdateSuccess = useCallback(() => {
        setUpdateVisible(false);
        setSelectedComplaint(null);
        fetchComplaints();
    }, [fetchComplaints]);

    const onGlobalFilterChange = useCallback((e) => setGlobalFilter(e.target.value), []);

    // ── Body templates ────────────────────────────────────────────────────────

    const projectBodyTemplate = useCallback(
        (rowData) => <TruncatedCell value={rowData.projectCode} maxLen={13} />,
        [],
    );
    const customerBodyTemplate = useCallback(
        (rowData) => <PlainTruncatedCell value={rowData.customerName} />,
        [],
    );
    const descriptionBodyTemplate = useCallback(
        (rowData) => <DescriptionCell value={rowData.description} />,
        [],
    );
    const employeeBodyTemplate = useCallback(
        (rowData) => <TruncatedCell value={rowData.nameOfEmployeeResp} maxLen={18} />,
        [],
    );
    const cityBodyTemplate = useCallback(
        (rowData) => <TruncatedCell value={rowData.city} maxLen={12} />,
        [],
    );

    const statusBodyTemplate = useCallback((rowData) => {
        const severity = STATUS_SEVERITY_MAP[rowData.statusDesc] ?? 'secondary';
        return <Tag value={rowData.statusDesc ?? '—'} severity={severity} />;
    }, []);

    const faultBodyTemplate = useCallback((rowData) => {
        if (!rowData.faultClassification) return <span>—</span>;
        const severity = FAULT_SEVERITY_MAP[rowData.faultClassification] ?? 'secondary';
        return <Tag value={rowData.faultClassification} severity={severity} />;
    }, []);

    const dateBodyTemplate = useCallback(
        (rowData) => <span>{formatDate(rowData.postingDateTs)}</span>,
        [],
    );

    const actionHandlersRef = useRef(new WeakMap());
    const actionBodyTemplate = useCallback(
        (rowData) => {
            if (!actionHandlersRef.current.has(rowData)) {
                actionHandlersRef.current.set(rowData, () => onEditClick(rowData));
            }
            return (
                <Button
                    label="Edit"
                    icon="pi pi-pencil"
                    size="small"
                    outlined
                    onClick={actionHandlersRef.current.get(rowData)}
                    aria-label={`Edit complaint ${rowData.complaintNo}`}
                />
            );
        },
        [onEditClick],
    );

    // ── Toolbar ───────────────────────────────────────────────────────────────

    const toolbarStart = useMemo(
        () => (
            <div className="flex align-items-center gap-2">
                <i className="pi pi-pencil text-primary text-lg" />
                <span className="text-xl font-semibold">Update Complaints</span>
                {!loading && (
                    <span className="text-color-secondary text-sm">
                        ({complaints.length} records)
                    </span>
                )}
            </div>
        ),
        [loading, complaints.length],
    );

    const toolbarEnd = useMemo(
        () => (
            <div className="flex align-items-center gap-2">
                <span className="p-input-icon-left w-20rem">
                    <i className="pi pi-search ml-2 text-color-secondary" />
                    <InputText
                        value={globalFilter}
                        onChange={onGlobalFilterChange}
                        placeholder="Search complaints..."
                        className="w-full pl-5 border-round-lg shadow-1"
                    />
                </span>
                <Button
                    icon="pi pi-refresh"
                    outlined
                    severity="secondary"
                    onClick={fetchComplaints}
                    loading={loading}
                    tooltip="Refresh"
                    tooltipOptions={TOOLTIP_LEFT}
                    aria-label="Refresh complaints"
                />
            </div>
        ),
        [globalFilter, onGlobalFilterChange, fetchComplaints, loading],
    );

    // ── Render ────────────────────────────────────────────────────────────────

    return (
        <div className="p-2" style={WRAPPER_STYLE}>
            <Toast ref={toast} position="top-right" />
            {loading && <ProgressBar mode="indeterminate" style={PROGRESS_STYLE} />}

            <UpdateComplaintDialog
                visible={updateVisible}
                onHide={onUpdateHide}
                complaint={selectedComplaint}
                onSuccess={onUpdateSuccess}
            />

            <Toolbar start={toolbarStart} end={toolbarEnd} className="mb-3" />

            <div className="surface-50 border-round p-1 mb-3 flex align-items-center gap-2">
                <i className="pi pi-info-circle text-color-secondary" />
                <span className="text-sm text-color-secondary">
                    Click <b>Edit</b> on any row to update complaint details.
                </span>
            </div>

            <DataTable
                value={complaints}
                paginator
                rows={9}
                rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
                globalFilter={globalFilter}
                loading={loading}
                emptyMessage="No complaints found."
                sortField="postingDate"
                sortOrder={-1}
                stripedRows
                showGridlines
                tableStyle={TABLE_STYLE}
                dataKey="complaintNo"
                selectionMode="single"
            >
                <Column
                    field="complaintNo"
                    header="Complaint #"
                    sortable
                    style={COL_COMPLAINT_NO}
                />
                <Column
                    header="Project Code"
                    body={projectBodyTemplate}
                    sortable
                    sortField="projectCode"
                    style={COL_PROJECT}
                />
                <Column
                    header="Customer"
                    body={customerBodyTemplate}
                    sortable
                    sortField="customerName"
                    style={COL_CUSTOMER}
                />
                <Column
                    header="Description"
                    body={descriptionBodyTemplate}
                    style={COL_DESCRIPTION}
                />
                <Column
                    header="Employee Responsible"
                    body={employeeBodyTemplate}
                    sortable
                    sortField="nameOfEmployeeResp"
                    style={COL_EMPLOYEE}
                />
                <Column
                    header="Status"
                    body={statusBodyTemplate}
                    sortable
                    sortField="statusDesc"
                    style={COL_STATUS}
                />
                <Column
                    header="Fault"
                    body={faultBodyTemplate}
                    sortField="faultClassification"
                    style={COL_FAULT}
                />
                <Column
                    header="Posted On"
                    body={dateBodyTemplate}
                    sortable
                    sortField="postingDate"
                    style={COL_DATE}
                />
                <Column
                    header="City"
                    body={cityBodyTemplate}
                    sortable
                    sortField="city"
                    style={COL_CITY}
                />
                <Column
                    header="Action"
                    body={actionBodyTemplate}
                    frozen
                    alignFrozen="right"
                    style={COL_ACTION}
                />
            </DataTable>
        </div>
    );
}
