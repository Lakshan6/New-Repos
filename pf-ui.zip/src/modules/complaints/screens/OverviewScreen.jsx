import { useState, useEffect, useCallback, useRef, useMemo, memo } from 'react';
import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Tag } from 'primereact/tag';
import { Toast } from 'primereact/toast';
import { ProgressBar } from 'primereact/progressbar';
import { Toolbar } from 'primereact/toolbar';
import { OverlayPanel } from 'primereact/overlaypanel';
import { Dialog } from 'primereact/dialog';
import { Divider } from 'primereact/divider';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';
import { ComplaintRegistrationDialog } from '../components/ComplaintRegistrationDialog';
import { UpdateComplaintDialog } from '../components/UpdateComplaintDialog';

// ── Static maps & config ──────────────────────────────────────────────────────

const STATUS_SEVERITY_MAP = {
    'Complaint Opened': 'warning',
    'Complaint Closed': 'success',
    'Complaint Inprogress': 'info',
};

const FAULT_SEVERITY_MAP = {
    'Very high': 'danger',
    High: 'warning',
    Medium: 'info',
};

//const DESC_PREVIEW_LEN = 50;
const ROWS_PER_PAGE_OPTIONS = [7, 10, 20];

// ── Prop objects — module-level to satisfy react-perf/jsx-no-new-object-as-prop

const TOOLTIP_LEFT = { position: 'left' };
const TABLE_STYLE = { width: '100%', minWidth: 'unset' };
const PROGRESS_STYLE = { height: '3px' };
const WRAPPER_STYLE = { overflow: 'hidden' };
const DIALOG_STYLE = { width: '56rem', maxWidth: '95vw' };

// ── Cell styles ───────────────────────────────────────────────────────────────

const truncSpanStyle = {
    display: 'block',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    maxWidth: '100%',
};

const truncBtnStyle = {
    display: 'block',
    width: '100%',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
    cursor: 'pointer',
    color: 'var(--primary-color)',
    textDecoration: 'underline',
    textDecorationStyle: 'dotted',
    textUnderlineOffset: '2px',
    background: 'none',
    border: 'none',
    padding: 0,
    font: 'inherit',
    textAlign: 'left',
};

const overlayPStyle = {
    maxWidth: '360px',
    whiteSpace: 'pre-wrap',
    wordBreak: 'break-word',
    lineHeight: 1.6,
    fontSize: 'inherit',
    color: 'var(--text-color)',
    margin: 0,
};

const descWrapStyle = {
    whiteSpace: 'normal',
    wordBreak: 'break-word',
    lineHeight: 1.5,
    fontSize: 'inherit',
};

const complaintNoBtnStyle = {
    background: 'none',
    border: 'none',
    padding: 0,
    cursor: 'pointer',
    color: 'var(--primary-color)',
    fontWeight: 700,
    font: 'inherit',
    textDecoration: 'underline',
    textDecorationStyle: 'solid',
    textUnderlineOffset: '2px',
};

// ── Detail dialog styles ──────────────────────────────────────────────────────

const detailGridStyle = {
    display: 'grid',
    gridTemplateColumns: '1fr 1fr',
    gap: '0.6rem 1.2rem',
};

const detailLabelStyle = {
    fontSize: '0.78rem',
    color: 'var(--text-color-secondary)',
    fontWeight: 600,
    textTransform: 'uppercase',
    letterSpacing: '0.03em',
    marginBottom: '2px',
};

const detailValueStyle = {
    fontSize: '0.92rem',
    color: 'var(--text-color)',
    wordBreak: 'break-word',
};

const detailFullRowStyle = { gridColumn: '1 / -1' };
const detailNormalStyle = {};

// ── Column widths ─────────────────────────────────────────────────────────────

const COL_COMPLAINT_NO = { width: '100px', fontWeight: 600, overflow: 'hidden' };
const COL_PROJECT = { width: '110px', overflow: 'hidden' };
const COL_CUSTOMER = { width: '145px', overflow: 'hidden' };
const COL_DESCRIPTION = { width: '180px' };
const COL_EMPLOYEE = { width: '145px', overflow: 'hidden' };
const COL_STATUS = { width: '150px', overflow: 'hidden' };
const COL_FAULT = { width: '100px', overflow: 'hidden' };
const COL_DATE = { width: '110px', overflow: 'hidden' };
const COL_CITY = { width: '100px', overflow: 'hidden' };
const COL_ACTION = { width: '65px', textAlign: 'center', overflow: 'hidden' };

// ── Pure helpers ──────────────────────────────────────────────────────────────

const getToken = () => localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) ?? '';

const formatDate = (dateStr) => {
    if (!dateStr) return '—';
    return new Date(dateStr).toLocaleDateString('en-IN', {
        day: '2-digit',
        month: 'short',
        year: 'numeric',
    });
};

const displayVal = (v) => (v !== null && v !== undefined && v !== '' ? v : '—');

// ── DetailField ───────────────────────────────────────────────────────────────

function DetailField({ label, value, fullRow }) {
    return (
        <div style={fullRow ? detailFullRowStyle : detailNormalStyle}>
            <div style={detailLabelStyle}>{label}</div>
            <div style={detailValueStyle}>{displayVal(value)}</div>
        </div>
    );
}

DetailField.propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    fullRow: PropTypes.bool,
};
DetailField.defaultProps = { value: null, fullRow: false };

// ── ComplaintDetailDialog ─────────────────────────────────────────────────────

const ComplaintDetailDialog = memo(function ComplaintDetailDialog({ complaint, onHide }) {
    const header = useMemo(() => {
        if (!complaint) return null;
        const sSev = STATUS_SEVERITY_MAP[complaint.statusDesc] ?? 'secondary';
        const fSev = FAULT_SEVERITY_MAP[complaint.faultClassification] ?? 'secondary';
        return (
            <div className="flex align-items-center gap-2">
                <span>Complaint #{complaint.complaintNo}</span>
                <Tag value={complaint.statusDesc ?? '—'} severity={sSev} />
                {complaint.faultClassification && (
                    <Tag value={complaint.faultClassification} severity={fSev} />
                )}
            </div>
        );
    }, [complaint]);

    if (!complaint) return null;

    return (
        <Dialog
            visible
            onHide={onHide}
            header={header}
            style={DIALOG_STYLE}
            modal
            draggable={false}
            resizable={false}
        >
            <p className="text-xs text-color-secondary font-semibold uppercase mb-2 mt-0">
                Project &amp; Customer
            </p>
            <div style={detailGridStyle}>
                <DetailField label="Project Code" value={complaint.projectCode} />
                <DetailField label="Project Name" value={complaint.projectName} />
                <DetailField label="Customer Code" value={complaint.customerCode} />
                <DetailField label="Customer Name" value={complaint.customerName} />
                <DetailField label="Customer Search 1" value={complaint.customerSearch1} />
                <DetailField label="Customer Search 2" value={complaint.customerSearch2} />
            </div>

            <Divider className="my-3" />

            <p className="text-xs text-color-secondary font-semibold uppercase mb-2 mt-0">
                Complaint Info
            </p>
            <div style={detailGridStyle}>
                <DetailField label="Category" value={complaint.complaintCategory} />
                <DetailField label="Complaint Type" value={complaint.complaintType} />
                <DetailField label="Problem Type" value={complaint.problemType} />
                <DetailField label="Fault Classification" value={complaint.faultClassification} />
                <DetailField label="Code Group Problem" value={complaint.codeGroupProblem} />
                <DetailField label="Problem / Damage Code" value={complaint.problemOrDamageCode} />
                <DetailField
                    label="Problem / Damage Desc"
                    value={complaint.problemDamageDescription}
                    fullRow
                />
                <DetailField label="Description" value={complaint.description} fullRow />
                <DetailField label="Notes" value={complaint.notes} fullRow />
                <DetailField label="Action Taken" value={complaint.actionTaken} fullRow />
            </div>

            <Divider className="my-3" />

            <p className="text-xs text-color-secondary font-semibold uppercase mb-2 mt-0">Dates</p>
            <div style={detailGridStyle}>
                <DetailField label="Posting Date" value={formatDate(complaint.postingDateTs)} />
                <DetailField label="Closed Date" value={formatDate(complaint.closedDateTs)} />
                <DetailField
                    label="Warranty Start"
                    value={formatDate(complaint.warrantyStartDateTs)}
                />
                <DetailField label="Warranty End" value={formatDate(complaint.warrantyEndDateTs)} />
            </div>

            <Divider className="my-3" />

            <p className="text-xs text-color-secondary font-semibold uppercase mb-2 mt-0">
                Product &amp; Service
            </p>
            <div style={detailGridStyle}>
                <DetailField label="Product ID" value={complaint.productId} />
                <DetailField label="Product Group" value={complaint.productGroup} />
                <DetailField label="Product Type" value={complaint.productType} />
                <DetailField label="Serial No" value={complaint.serialNo} />
                <DetailField label="Service Order No" value={complaint.serviceOrderNo} />
                <DetailField label="Repair Type" value={complaint.repairType} />
                <DetailField label="Ship / Sub Unit" value={complaint.shipOrSubUnit} />
                <DetailField label="Actual Cost" value={complaint.actualCost} />
                <DetailField
                    label="Product Description"
                    value={complaint.productDescription}
                    fullRow
                />
            </div>

            <Divider className="my-3" />

            <p className="text-xs text-color-secondary font-semibold uppercase mb-2 mt-0">
                Employee &amp; Organisation
            </p>
            <div style={detailGridStyle}>
                <DetailField label="Employee Responsible" value={complaint.nameOfEmployeeResp} />
                <DetailField label="Employee Code" value={complaint.employeeRespCode} />
                <DetailField label="Project Manager" value={complaint.projectManagerName} />
                <DetailField label="Created By" value={complaint.createdBy} />
                <DetailField label="Reported By" value={complaint.reportedBy} />
                <DetailField label="Validation Done" value={complaint.validationDone} />
                <DetailField label="Division Code" value={complaint.divisionCode} />
                <DetailField label="Division Descr" value={complaint.divisionDescr} />
                <DetailField label="SBU" value={complaint.sbu} />
                <DetailField label="SBU Description" value={complaint.sbuDescription} />
                <DetailField label="Sales Org R3" value={complaint.salesOrgR3} />
                <DetailField label="Distribution Channel" value={complaint.distributionChannel} />
                <DetailField label="Industry Code" value={complaint.industryCode} />
                <DetailField label="Industry Desc" value={complaint.industryDesc} />
                <DetailField label="Acc Indicator" value={complaint.accIndicator} />
            </div>

            <Divider className="my-3" />

            <p className="text-xs text-color-secondary font-semibold uppercase mb-2 mt-0">
                Location &amp; Contact
            </p>
            <div style={detailGridStyle}>
                <DetailField label="City" value={complaint.city} />
                <DetailField label="Current Location" value={complaint.currentLocation} />
                <DetailField label="Phone No" value={complaint.currentPhoneNo} />
                <DetailField label="Email" value={complaint.emailNumber} />
                <DetailField label="Total Time Taken (hrs)" value={complaint.totalTimeTaken} />
            </div>
        </Dialog>
    );
});

ComplaintDetailDialog.propTypes = {
    complaint: PropTypes.object,
    onHide: PropTypes.func.isRequired,
};
ComplaintDetailDialog.defaultProps = { complaint: null };

// ── DescriptionCell ───────────────────────────────────────────────────────────
const DescriptionCell = memo(function DescriptionCell({ value }) {
    if (!value) return <span>—</span>;

    const truncated = value.length > 25 ? `${value.slice(0, 25)}...` : value;

    return <span style={descWrapStyle}>{truncated}</span>;
});

DescriptionCell.propTypes = { value: PropTypes.string };
DescriptionCell.defaultProps = { value: null };

// ── TruncatedCell — ellipsis + overlay on click ───────────────────────────────

const TruncatedCell = memo(function TruncatedCell({ value, maxLen }) {
    const op = useRef(null);
    const onToggle = useCallback((e) => {
        op.current?.toggle(e);
    }, []);

    if (!value) return <span>—</span>;
    if (value.length <= maxLen) return <span style={truncSpanStyle}>{value}</span>;

    return (
        <>
            <button
                type="button"
                style={truncBtnStyle}
                onClick={onToggle}
                title={value}
                aria-label="View full content"
            >
                {value}
            </button>
            <OverlayPanel ref={op} dismissable>
                <p style={overlayPStyle}>{value}</p>
            </OverlayPanel>
        </>
    );
});

TruncatedCell.propTypes = { value: PropTypes.string, maxLen: PropTypes.number };
TruncatedCell.defaultProps = { value: null, maxLen: 30 };

// ── PlainTruncatedCell — ellipsis only, no interaction ───────────────────────

const PlainTruncatedCell = memo(function PlainTruncatedCell({ value }) {
    if (!value) return <span>—</span>;
    return (
        <span style={truncSpanStyle} title={value}>
            {value}
        </span>
    );
});

PlainTruncatedCell.propTypes = { value: PropTypes.string };
PlainTruncatedCell.defaultProps = { value: null };

// ── OverviewScreen ────────────────────────────────────────────────────────────

export default function OverviewScreen() {
    const toast = useRef(null);

    const [complaints, setComplaints] = useState([]);
    const [loading, setLoading] = useState(false);
    const [globalFilter, setGlobalFilter] = useState('');
    const [registerVisible, setRegisterVisible] = useState(false);
    const [updateVisible, setUpdateVisible] = useState(false);
    const [selectedComplaint, setSelectedComplaint] = useState(null);
    const [detailComplaint, setDetailComplaint] = useState(null);

    const fetchComplaints = useCallback(() => {
        setLoading(true);
        apiRequest({
            method: 'GET',
            service: 'irs',
            endpoint: '/complaint/all',
            useGateway: true,
            headers: { Authorization: `Bearer ${getToken()}` },
        })
            .then((data) => setComplaints(data ?? []))
            .catch(() =>
                toast.current?.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to load complaints.',
                }),
            )
            .finally(() => setLoading(false));
    }, []);

    useEffect(() => {
        fetchComplaints();
    }, [fetchComplaints]);

    const onRegisterOpen = useCallback(() => setRegisterVisible(true), []);
    const onRegisterHide = useCallback(() => setRegisterVisible(false), []);
    const onDetailHide = useCallback(() => setDetailComplaint(null), []);
    const onGlobalFilterChange = useCallback((e) => setGlobalFilter(e.target.value), []);

    const onUpdateHide = useCallback(() => {
        setUpdateVisible(false);
        setSelectedComplaint(null);
    }, []);

    const onEditClick = useCallback((rowData) => {
        setSelectedComplaint(rowData);
        setUpdateVisible(true);
    }, []);

    const onComplaintNoClick = useCallback((rowData) => {
        setDetailComplaint(rowData);
    }, []);

    const onRegisterSuccess = useCallback(() => {
        setRegisterVisible(false);
        fetchComplaints();
    }, [fetchComplaints]);

    const onUpdateSuccess = useCallback(() => {
        setUpdateVisible(false);
        setSelectedComplaint(null);
        fetchComplaints();
    }, [fetchComplaints]);

    // ── Body templates ────────────────────────────────────────────────────────

    const complaintNoHandlersRef = useRef(new WeakMap());
    const complaintNoBodyTemplate = useCallback(
        (rowData) => {
            if (!complaintNoHandlersRef.current.has(rowData)) {
                complaintNoHandlersRef.current.set(rowData, () => onComplaintNoClick(rowData));
            }
            return (
                <button
                    type="button"
                    style={complaintNoBtnStyle}
                    onClick={complaintNoHandlersRef.current.get(rowData)}
                    aria-label={`View details for complaint ${rowData.complaintNo}`}
                >
                    {rowData.complaintNo}
                </button>
            );
        },
        [onComplaintNoClick],
    );

    const projectBodyTemplate = useCallback(
        (rowData) => <TruncatedCell value={rowData.projectCode} maxLen={13} />,
        [],
    );
    const customerBodyTemplate = useCallback(
        (rowData) => <PlainTruncatedCell value={rowData.customerName} />,
        [],
    );
    const descriptionBodyTemplate = useCallback(
        (rowData) => <DescriptionCell value={rowData.description} />,
        [],
    );
    const employeeBodyTemplate = useCallback(
        (rowData) => <TruncatedCell value={rowData.nameOfEmployeeResp} maxLen={17} />,
        [],
    );
    const cityBodyTemplate = useCallback(
        (rowData) => <TruncatedCell value={rowData.city} maxLen={12} />,
        [],
    );

    const statusBodyTemplate = useCallback((rowData) => {
        const severity = STATUS_SEVERITY_MAP[rowData.statusDesc] ?? 'secondary';
        return <Tag value={rowData.statusDesc ?? '—'} severity={severity} />;
    }, []);

    const faultBodyTemplate = useCallback((rowData) => {
        if (!rowData.faultClassification) return <span>—</span>;
        const severity = FAULT_SEVERITY_MAP[rowData.faultClassification] ?? 'secondary';
        return <Tag value={rowData.faultClassification} severity={severity} />;
    }, []);

    const dateBodyTemplate = useCallback(
        (rowData) => <span>{formatDate(rowData.postingDateTs)}</span>,
        [],
    );
    const closedDateBodyTemplate = useCallback(
        (rowData) => <span>{formatDate(rowData.closedDateTs)}</span>,
        [],
    );

    const actionHandlersRef = useRef(new WeakMap());
    const actionBodyTemplate = useCallback(
        (rowData) => {
            if (!actionHandlersRef.current.has(rowData)) {
                actionHandlersRef.current.set(rowData, () => onEditClick(rowData));
            }
            return (
                <Button
                    icon="pi pi-pencil"
                    rounded
                    outlined
                    size="small"
                    severity="secondary"
                    onClick={actionHandlersRef.current.get(rowData)}
                    tooltip="Edit complaint"
                    tooltipOptions={TOOLTIP_LEFT}
                    aria-label="Edit complaint"
                />
            );
        },
        [onEditClick],
    );

    // ── Toolbar ───────────────────────────────────────────────────────────────

    const toolbarStart = useMemo(
        () => (
            <div className="flex align-items-center gap-2">
                <span className="text-xl font-semibold">All Complaints</span>
                {!loading && (
                    <span className="text-color-secondary text-sm">
                        ({complaints.length} records)
                    </span>
                )}
            </div>
        ),
        [loading, complaints.length],
    );

    const toolbarEnd = useMemo(
        () => (
            <div className="flex align-items-center gap-2">
                <span className="p-input-icon-left w-20rem">
                    <i className="pi pi-search ml-2 text-color-secondary" />
                    <InputText
                        value={globalFilter}
                        onChange={onGlobalFilterChange}
                        placeholder="Search complaints..."
                        className="w-full pl-5 border-round-lg shadow-1"
                    />
                </span>
                <Button label="Register Complaint" icon="pi pi-plus" onClick={onRegisterOpen} />
                <Button
                    icon="pi pi-refresh"
                    outlined
                    severity="secondary"
                    onClick={fetchComplaints}
                    loading={loading}
                    tooltip="Refresh"
                    tooltipOptions={TOOLTIP_LEFT}
                    aria-label="Refresh complaints"
                />
            </div>
        ),
        [globalFilter, onGlobalFilterChange, onRegisterOpen, fetchComplaints, loading],
    );

    // ── Render ────────────────────────────────────────────────────────────────

    return (
        <div className="p-2" style={WRAPPER_STYLE}>
            <Toast ref={toast} position="top-right" />
            {loading && <ProgressBar mode="indeterminate" style={PROGRESS_STYLE} />}

            <ComplaintRegistrationDialog
                visible={registerVisible}
                onHide={onRegisterHide}
                onSuccess={onRegisterSuccess}
            />
            <UpdateComplaintDialog
                visible={updateVisible}
                onHide={onUpdateHide}
                complaint={selectedComplaint}
                onSuccess={onUpdateSuccess}
            />
            <ComplaintDetailDialog complaint={detailComplaint} onHide={onDetailHide} />

            <Toolbar start={toolbarStart} end={toolbarEnd} className="mb-3" />

            <DataTable
                value={complaints}
                paginator
                rows={9}
                rowsPerPageOptions={ROWS_PER_PAGE_OPTIONS}
                globalFilter={globalFilter}
                loading={loading}
                emptyMessage="No complaints found."
                sortField="postingDate"
                sortOrder={-1}
                stripedRows
                showGridlines
                tableStyle={TABLE_STYLE}
                dataKey="complaintNo"
            >
                <Column
                    field="complaintNo"
                    header="Complaint #"
                    body={complaintNoBodyTemplate}
                    sortable
                    style={COL_COMPLAINT_NO}
                />
                <Column
                    header="Project Code"
                    body={projectBodyTemplate}
                    sortable
                    sortField="projectCode"
                    style={COL_PROJECT}
                />
                <Column
                    header="Customer"
                    body={customerBodyTemplate}
                    sortable
                    sortField="customerName"
                    style={COL_CUSTOMER}
                />
                <Column
                    header="Description"
                    body={descriptionBodyTemplate}
                    style={COL_DESCRIPTION}
                />
                <Column
                    header="Employee Responsible"
                    body={employeeBodyTemplate}
                    sortable
                    sortField="nameOfEmployeeResp"
                    style={COL_EMPLOYEE}
                />
                <Column
                    header="Status"
                    body={statusBodyTemplate}
                    sortable
                    sortField="statusDesc"
                    style={COL_STATUS}
                />
                <Column
                    header="Fault"
                    body={faultBodyTemplate}
                    sortField="faultClassification"
                    style={COL_FAULT}
                />
                <Column
                    header="Posted On"
                    body={dateBodyTemplate}
                    sortable
                    sortField="postingDate"
                    style={COL_DATE}
                />
                <Column
                    header="Closed On"
                    body={closedDateBodyTemplate}
                    sortable
                    sortField="closedDate"
                    style={COL_DATE}
                />
                <Column
                    header="City"
                    body={cityBodyTemplate}
                    sortable
                    sortField="city"
                    style={COL_CITY}
                />
                <Column
                    header="Actions"
                    body={actionBodyTemplate}
                    frozen
                    alignFrozen="right"
                    style={COL_ACTION}
                />
            </DataTable>
        </div>
    );
}
