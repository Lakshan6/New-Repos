import { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import { useNavigate } from 'react-router';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Divider } from 'primereact/divider';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';

const INDUSTRY_OPTIONS = [
    { label: 'Navy', value: 16 },
    { label: 'Air Force', value: 3 },
    { label: 'Army', value: 4 },
];

const FAULT_OPTIONS = [
    { label: 'Very high', value: 'Very high' },
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
];

const BANNER_STYLES = {
    success: ['var(--green-50)', 'var(--green-200)', 'var(--green-800)', 'var(--green-500)'],
    warn: ['var(--yellow-50)', 'var(--yellow-200)', 'var(--yellow-800)', 'var(--yellow-500)'],
    info: ['var(--blue-50)', 'var(--blue-200)', 'var(--blue-800)', 'var(--blue-500)'],
};

const EMPTY = {
    projectCode: '',
    customerCode: '',
    description: '',
    nameOfEmployeeResp: '',
    industryCode: null,
    complaintCategory: null,
    complaintType: null,
    productType: null,
    problemType: null,
    faultClassification: null,
    actionTaken: '',
    problemOrDamageCode: '',
    problemDamageDescription: '',
};

const REQUIRED_FIELDS = [
    'projectCode',
    'customerCode',
    'description',
    'nameOfEmployeeResp',
    'industryCode',
    'faultClassification',
];

// ── Styles ────────────────────────────────────────────────────
const sectionLblStyle = {
    color: 'var(--text-color-secondary)',
    textTransform: 'uppercase',
    letterSpacing: '0.055em',
};
const sectionIcoStyle = { fontSize: '0.82rem' };
const fieldLblStyle = { color: 'var(--text-color-secondary)' };
const fieldHintStyle = { opacity: 0.65 };
const fieldErrStyle = { fontSize: '0.75rem' };
const fieldErrIco = { fontSize: '0.7rem' };
const spinnerStyle = { width: 36, height: 36 };
const headerCircle = { width: 44, height: 44, flexShrink: 0 };
const headerIconStyle = { fontSize: '1.2rem' };
const successCircle = { width: 72, height: 72 };
const successIcon = { fontSize: '2.2rem' };
const centerPaneStyle = { minHeight: '60vh' };
const successCardStyle = { maxWidth: '480px' };

const descPreviewStyle = {
    cursor: 'pointer',
    color: 'var(--text-color-secondary)',
    fontSize: '0.875rem',
    padding: '0.5rem 0.75rem',
    border: '1px solid var(--surface-border)',
    borderRadius: 'var(--border-radius)',
    background: 'var(--surface-0)',
    display: 'block',
    lineHeight: 1.5,
    width: '100%',
    textAlign: 'left',
};
const descExpandIconStyle = { fontSize: '0.75rem', marginLeft: '0.35rem' };

// Separate card-style containers for each section
const sectionCardStyle = {
    border: '1px solid var(--surface-border)',
    borderRadius: 'var(--border-radius)',
    background: 'var(--surface-card)',
    padding: '1.25rem 1.75rem 1.5rem',
    marginBottom: '1rem',
};

const headerCardStyle = {
    border: '1px solid var(--surface-border)',
    borderRadius: 'var(--border-radius)',
    background: 'var(--surface-card)',
    padding: '1.25rem 1.75rem',
    marginBottom: '1rem',
};

const footerCardStyle = {
    border: '1px solid var(--surface-border)',
    borderRadius: 'var(--border-radius)',
    background: 'var(--surface-card)',
    padding: '1rem 1.75rem',
    marginBottom: '1rem',
};

const sectionHeadStyle = {
    borderBottom: '1px solid var(--surface-border)',
    paddingBottom: '0.5rem',
    marginBottom: '1rem',
};

const makeBannerIcoStyle = (c) => ({ color: c, fontSize: '0.9rem', flexShrink: 0 });
const makeBannerTxtStyle = (c) => ({ color: c });

const getToken = () => localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) ?? '';

// ── Sub-components ────────────────────────────────────────────────────────────
function Sec({ label, icon }) {
    return (
        <div className="flex align-items-center gap-2" style={sectionHeadStyle}>
            <i className={`pi ${icon} text-primary`} style={sectionIcoStyle} />
            <span className="text-xs font-semibold" style={sectionLblStyle}>
                {label}
            </span>
        </div>
    );
}
Sec.propTypes = { label: PropTypes.string.isRequired, icon: PropTypes.string.isRequired };

function Fld({ label, req, err, hint, col, children }) {
    return (
        <div className={`field col-12 md:col-${col}`}>
            <label className="block text-sm font-medium mb-1" style={fieldLblStyle}>
                {label}
                {req && <span className="text-red-500 ml-1">*</span>}
                {hint && (
                    <span className="ml-2 text-xs font-normal" style={fieldHintStyle}>
                        ({hint})
                    </span>
                )}
            </label>
            {children}
            {err && (
                <small className="p-error flex align-items-center gap-1 mt-1" style={fieldErrStyle}>
                    <i className="pi pi-exclamation-circle" style={fieldErrIco} />
                    {err}
                </small>
            )}
        </div>
    );
}
Fld.propTypes = {
    label: PropTypes.string.isRequired,
    req: PropTypes.bool,
    err: PropTypes.string,
    hint: PropTypes.string,
    col: PropTypes.number,
    children: PropTypes.node.isRequired,
};
Fld.defaultProps = { req: false, err: null, hint: null, col: 6 };

function Banner({ type, icon, html }) {
    const [bg, border, textColor, iconColor] = BANNER_STYLES[type] ?? BANNER_STYLES.info;
    const icoStyle = useMemo(() => makeBannerIcoStyle(iconColor), [iconColor]);
    const txtStyle = useMemo(() => makeBannerTxtStyle(textColor), [textColor]);
    const ctnStyle = useMemo(
        () => ({ background: bg, border: `1px solid ${border}` }),
        [bg, border],
    );
    const htmlDangerously = useMemo(() => ({ __html: html }), [html]);
    return (
        <div className="flex align-items-center gap-2 border-round p-3 mb-3" style={ctnStyle}>
            <i className={`pi ${icon}`} style={icoStyle} />
            <span className="text-sm" style={txtStyle} dangerouslySetInnerHTML={htmlDangerously} />
        </div>
    );
}
Banner.propTypes = {
    type: PropTypes.oneOf(['success', 'warn', 'info']).isRequired,
    icon: PropTypes.string.isRequired,
    html: PropTypes.string.isRequired,
};

function DescriptionField({ value, onChange, error }) {
    const [expanded, setExpanded] = useState(false);
    const onToggle = useCallback(() => setExpanded((v) => !v), []);

    const preview = value
        ? value.length > 80
            ? `${value.slice(0, 80)}…`
            : value
        : 'Click to enter description…';

    if (expanded) {
        return (
            <div>
                <InputTextarea
                    value={value}
                    onChange={onChange}
                    rows={4}
                    autoResize
                    placeholder="Describe the complaint clearly…"
                    className={error ? 'p-invalid' : ''}
                    onBlur={onToggle}
                />
                <small className="text-color-secondary text-xs">Click outside to collapse</small>
            </div>
        );
    }

    return (
        <button
            type="button"
            style={descPreviewStyle}
            onClick={onToggle}
            className={error ? 'p-invalid' : ''}
            aria-label="Click to enter description"
        >
            <span>{preview}</span>
            <i className="pi pi-chevron-down" style={descExpandIconStyle} />
        </button>
    );
}
DescriptionField.propTypes = {
    value: PropTypes.string.isRequired,
    onChange: PropTypes.func.isRequired,
    error: PropTypes.string,
};
DescriptionField.defaultProps = { error: null };

// ── Main Screen ───────────────────────────────────────────────────────────────
export default function RegisterComplaintScreen() {
    const toast = useRef(null);
    const navigate = useNavigate();

    const [form, setForm] = useState(EMPTY);
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);
    const [submitted, setSubmitted] = useState(false);
    const [lastNo, setLastNo] = useState(null);
    const [dropdowns, setDropdowns] = useState(null);
    const [ddLoading, setDdLoading] = useState(false);
    const [projects, setProjects] = useState([]);
    const [projLoading, setProjLoading] = useState(false);
    const [customers, setCustomers] = useState([]);
    const [custLoading, setCustLoading] = useState(false);
    const [resolvedPs, setResolvedPs] = useState(null);
    const [resolvedCity, setResolvedCity] = useState('');

    useEffect(() => {
        setDdLoading(true);
        setProjLoading(true);
        const authHeader = { Authorization: `Bearer ${getToken()}` };
        Promise.all([
            apiRequest({
                method: 'GET',
                service: 'irs',
                endpoint: '/complaint/form/dropdowns',
                useGateway: true,
                headers: authHeader,
            }),
            apiRequest({
                method: 'GET',
                service: 'irs',
                endpoint: '/complaint/form/projects',
                useGateway: true,
                headers: authHeader,
            }),
        ])
            .then(([dd, projs]) => {
                setDropdowns(dd ?? {});
                setProjects(projs ?? []);
            })
            .catch(() =>
                toast.current?.show({
                    severity: 'warn',
                    summary: 'Warning',
                    detail: 'Could not load some options from server',
                }),
            )
            .finally(() => {
                setDdLoading(false);
                setProjLoading(false);
            });
    }, []);

    const set = useCallback((field, val) => {
        setForm((f) => ({ ...f, [field]: val }));
        setErrors((e) => ({ ...e, [field]: null }));
    }, []);

    const onProjectChange = useCallback((code) => {
        setForm((f) => ({ ...f, projectCode: code, customerCode: '' }));
        setErrors((e) => ({ ...e, projectCode: null, customerCode: null }));
        setCustomers([]);
        setResolvedPs(null);
        setResolvedCity('');
        if (!code) return;
        setCustLoading(true);
        apiRequest({
            method: 'GET',
            service: 'irs',
            endpoint: `/complaint/form/customers?projectCode=${encodeURIComponent(code)}`,
            useGateway: true,
            headers: { Authorization: `Bearer ${getToken()}` },
        })
            .then((d) => setCustomers(d ?? []))
            .catch(() => setCustomers([]))
            .finally(() => setCustLoading(false));
    }, []);

    const onCustomerChange = useCallback(
        (code) => {
            const c = customers.find((x) => x.customerCode === code);
            setForm((f) => ({ ...f, customerCode: code }));
            setResolvedCity(c?.city ?? '');
            setResolvedPs(c?.psId ? { id: c.psId, name: c.psName } : null);
            setErrors((e) => ({ ...e, customerCode: null }));
        },
        [customers],
    );

    const onFaultChange = useCallback((e) => set('faultClassification', e.value), [set]);
    const onProjectDropChange = useCallback((e) => onProjectChange(e.value), [onProjectChange]);
    const onCustomerDropChange = useCallback((e) => onCustomerChange(e.value), [onCustomerChange]);
    const onDescChange = useCallback((e) => set('description', e.target.value), [set]);
    const onIndustryChange = useCallback((e) => set('industryCode', e.value), [set]);
    const onCategoryChange = useCallback((e) => set('complaintCategory', e.value), [set]);
    const onCTypeChange = useCallback((e) => set('complaintType', e.value), [set]);
    const onProdTypeChange = useCallback((e) => set('productType', e.value), [set]);
    const onProbTypeChange = useCallback((e) => set('problemType', e.value), [set]);
    const onProbCodeChange = useCallback((e) => set('problemOrDamageCode', e.target.value), [set]);
    const onProbDescChange = useCallback(
        (e) => set('problemDamageDescription', e.target.value),
        [set],
    );
    const onEmployeeChange = useCallback((e) => set('nameOfEmployeeResp', e.target.value), [set]);
    const onActionChange = useCallback((e) => set('actionTaken', e.target.value), [set]);

    const validate = useCallback(() => {
        const errs = {};
        REQUIRED_FIELDS.forEach((k) => {
            const v = form[k];
            if (v === null || v === undefined || (typeof v === 'string' && !v.trim()))
                errs[k] = 'Required';
        });
        setErrors(errs);
        return Object.keys(errs).length === 0;
    }, [form]);

    const handleReset = useCallback(() => {
        setForm(EMPTY);
        setErrors({});
        setCustomers([]);
        setResolvedPs(null);
        setResolvedCity('');
        setSubmitted(false);
        setLastNo(null);
    }, []);

    const handleSubmit = useCallback(async () => {
        if (!validate()) {
            toast.current?.show({
                severity: 'error',
                summary: 'Validation Failed',
                detail: 'Fill in all required fields marked with *',
            });
            return;
        }
        const token = getToken();
        setSubmitting(true);
        try {
            const res = await apiRequest({
                method: 'POST',
                service: 'irs',
                endpoint: '/complaint/register',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${token}`,
                    'X-User-Id': form.nameOfEmployeeResp.trim(),
                },
                body: {
                    requestInfo: { authToken: token },
                    projectCode: form.projectCode.trim(),
                    customerCode: form.customerCode,
                    description: form.description.trim(),
                    nameOfEmployeeResp: form.nameOfEmployeeResp.trim(),
                    industryCode: form.industryCode,
                    complaintCategory: form.complaintCategory || undefined,
                    complaintType: form.complaintType || undefined,
                    productType: form.productType || undefined,
                    problemType: form.problemType || undefined,
                    faultClassification: form.faultClassification,
                    actionTaken: form.actionTaken?.trim() || undefined,
                    problemOrDamageCode: form.problemOrDamageCode?.trim() || undefined,
                    problemDamageDescription: form.problemDamageDescription?.trim() || undefined,
                },
            });
            if (res?.success) {
                setLastNo(res.complaintNo);
                setSubmitted(true);
                res.warnings?.forEach((w) =>
                    toast.current?.show({
                        severity: 'warn',
                        summary: 'Note',
                        detail: w,
                        life: 7000,
                    }),
                );
            } else {
                (res?.errors ?? ['Registration failed']).forEach((msg) =>
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: msg }),
                );
            }
        } catch (err) {
            toast.current?.show({
                severity: 'error',
                summary: 'Server Error',
                detail: err?.message || 'Failed to register. Please try again.',
            });
        } finally {
            setSubmitting(false);
        }
    }, [form, validate]);

    const toOpts = useCallback((arr) => (arr ?? []).map((v) => ({ label: v, value: v })), []);

    const projOpts = useMemo(
        () =>
            projects.map((p) => ({
                label: p.projectName ? `${p.projectCode} — ${p.projectName}` : p.projectCode,
                value: p.projectCode,
            })),
        [projects],
    );

    const custOpts = useMemo(
        () =>
            customers.map((c) => ({
                label: c.customerName ? `${c.customerCode} — ${c.customerName}` : c.customerCode,
                value: c.customerCode,
            })),
        [customers],
    );

    const custPlaceholder = !form.projectCode
        ? 'Select a project first'
        : custLoading
          ? 'Loading…'
          : 'Select customer';

    const psBannerHtml = resolvedPs
        ? `<b>PS:</b> [${resolvedPs.id}] ${resolvedPs.name ?? '—'}${resolvedCity ? `&nbsp;&nbsp;·&nbsp;&nbsp;<b>City:</b> ${resolvedCity}` : ''}`
        : 'No PS mapping found. Complaint will be saved without PS assignment.';

    const goToOverview = useCallback(() => navigate('../overview'), [navigate]);

    if (submitted) {
        return (
            <div
                className="flex align-items-center justify-content-center p-5"
                style={centerPaneStyle}
            >
                <Toast ref={toast} position="top-right" />
                <div
                    className="text-center surface-card border-round shadow-2 p-5 w-full"
                    style={successCardStyle}
                >
                    <div className="flex flex-column align-items-center gap-3 py-4">
                        <div
                            className="flex align-items-center justify-content-center border-circle bg-green-50"
                            style={successCircle}
                        >
                            <i className="pi pi-check-circle text-green-500" style={successIcon} />
                        </div>
                        <span className="text-2xl font-bold text-900">Complaint Registered!</span>
                        <span className="text-color-secondary">
                            Complaint <b>#{lastNo}</b> has been registered successfully.
                        </span>
                        <div className="flex gap-3 mt-2">
                            <Button
                                label="Register Another"
                                icon="pi pi-plus"
                                outlined
                                onClick={handleReset}
                            />
                            <Button
                                label="View All Complaints"
                                icon="pi pi-list"
                                onClick={goToOverview}
                            />
                        </div>
                    </div>
                </div>
            </div>
        );
    }

    if (ddLoading || projLoading) {
        return (
            <div
                className="flex flex-column align-items-center justify-content-center"
                style={centerPaneStyle}
            >
                <Toast ref={toast} position="top-right" />
                <ProgressSpinner style={spinnerStyle} />
                <span className="text-color-secondary text-sm mt-3">Loading form data…</span>
            </div>
        );
    }

    return (
        <div className="p-2 pb-4">
            <Toast ref={toast} position="top-right" />

            {/* ── Header Card ─────────────────────────────────────────── */}
            <div style={headerCardStyle}>
                <div className="flex align-items-center gap-3">
                    <div
                        className="flex align-items-center justify-content-center border-circle bg-primary-50"
                        style={headerCircle}
                    >
                        <i className="pi pi-file-plus text-primary" style={headerIconStyle} />
                    </div>
                    <div>
                        <div className="text-xl font-bold text-900">Register Complaint</div>
                        <div className="text-sm text-color-secondary">
                            &nbsp;Fields marked <span className="text-red-500">*</span> are required
                        </div>
                    </div>
                </div>
            </div>

            {/* ── Section 1 : Project & Customer ───────────────────────── */}
            <div style={sectionCardStyle}>
                <Sec label="Project & Customer" icon="pi-sitemap" />
                <div className="p-fluid">
                    <div className="formgrid grid">
                        <Fld label="Project Code" req err={errors.projectCode} col={4}>
                            <Dropdown
                                value={form.projectCode}
                                options={projOpts}
                                onChange={onProjectDropChange}
                                filter
                                filterPlaceholder="Search project…"
                                placeholder="Select project"
                                className={errors.projectCode ? 'p-invalid' : ''}
                                showClear
                                emptyMessage="No projects found"
                            />
                        </Fld>
                        <Fld label="Customer" req err={errors.customerCode} col={5}>
                            <Dropdown
                                value={form.customerCode}
                                options={custOpts}
                                onChange={onCustomerDropChange}
                                placeholder={custPlaceholder}
                                disabled={!form.projectCode || custLoading}
                                loading={custLoading}
                                className={errors.customerCode ? 'p-invalid' : ''}
                                showClear
                                emptyMessage="No customers for this project"
                            />
                        </Fld>
                        <Fld
                            label="Fault Classification"
                            req
                            err={errors.faultClassification}
                            col={3}
                        >
                            <Dropdown
                                value={form.faultClassification}
                                options={FAULT_OPTIONS}
                                onChange={onFaultChange}
                                placeholder="Select severity"
                                className={errors.faultClassification ? 'p-invalid' : ''}
                                showClear
                            />
                        </Fld>
                    </div>

                    {form.customerCode && (
                        <Banner
                            type={resolvedPs ? 'success' : 'warn'}
                            icon={resolvedPs ? 'pi-check-circle' : 'pi-exclamation-triangle'}
                            html={psBannerHtml}
                        />
                    )}
                </div>
            </div>

            {/* ── Section 2 : Problem Details ──────────────────────────── */}
            <div style={sectionCardStyle}>
                <Sec label="Problem Details" icon="pi-exclamation-circle" />
                <div className="p-fluid">
                    <div className="formgrid grid">
                        <Fld label="Description" req err={errors.description} col={12}>
                            <DescriptionField
                                value={form.description}
                                onChange={onDescChange}
                                error={errors.description}
                            />
                        </Fld>

                        {/* Industry and Complaint Category — narrowed to col-3 */}
                        <Fld label="Industry" req err={errors.industryCode} col={3}>
                            <Dropdown
                                value={form.industryCode}
                                options={INDUSTRY_OPTIONS}
                                onChange={onIndustryChange}
                                placeholder="Select industry"
                                className={errors.industryCode ? 'p-invalid' : ''}
                            />
                        </Fld>
                        <Fld label="Complaint Category" col={3}>
                            <Dropdown
                                value={form.complaintCategory}
                                options={toOpts(dropdowns?.complaintCategories)}
                                onChange={onCategoryChange}
                                placeholder="Select category"
                                showClear
                                emptyMessage="No data yet"
                            />
                        </Fld>
                        <Fld label="Complaint Type" col={3}>
                            <Dropdown
                                value={form.complaintType}
                                options={toOpts(dropdowns?.complaintTypes)}
                                onChange={onCTypeChange}
                                placeholder="Select type"
                                showClear
                                emptyMessage="No data yet"
                            />
                        </Fld>
                        <Fld label="Product Type" col={3}>
                            <Dropdown
                                value={form.productType}
                                options={toOpts(dropdowns?.productTypes)}
                                onChange={onProdTypeChange}
                                placeholder="Select product type"
                                showClear
                                emptyMessage="No data yet"
                            />
                        </Fld>

                        <Fld label="Problem Type" col={4}>
                            <Dropdown
                                value={form.problemType}
                                options={toOpts(dropdowns?.problemTypes)}
                                onChange={onProbTypeChange}
                                placeholder="Select problem type"
                                showClear
                                emptyMessage="No data yet"
                            />
                        </Fld>
                        <Fld label="Problem / Damage Code" col={4}>
                            <InputText
                                value={form.problemOrDamageCode}
                                onChange={onProbCodeChange}
                                placeholder="e.g. OTHR"
                            />
                        </Fld>
                        <Fld label="Problem / Damage Description" col={4}>
                            <InputText
                                value={form.problemDamageDescription}
                                onChange={onProbDescChange}
                                placeholder="Brief damage description"
                            />
                        </Fld>
                    </div>
                </div>
            </div>

            {/* ── Section 3 : Employee & Action ────────────────────────── */}
            <div style={sectionCardStyle}>
                <Sec label="Employee & Action" icon="pi-user" />
                <div className="p-fluid">
                    <div className="formgrid grid">
                        <Fld
                            label="Employee Responsible"
                            req
                            err={errors.nameOfEmployeeResp}
                            col={6}
                        >
                            <InputText
                                value={form.nameOfEmployeeResp}
                                onChange={onEmployeeChange}
                                placeholder="Full name of responsible employee"
                                className={errors.nameOfEmployeeResp ? 'p-invalid' : ''}
                            />
                        </Fld>
                        <Fld label="Action Taken" col={6}>
                            <InputText
                                value={form.actionTaken}
                                onChange={onActionChange}
                                placeholder="e.g. Replaced spare unit"
                            />
                        </Fld>
                    </div>

                    <Banner
                        type="info"
                        icon="pi-info-circle"
                        html="Status → <b>Complaint Opened</b>&nbsp;&nbsp;·&nbsp;&nbsp;Division → <b>NS (R &amp; FCS)</b>&nbsp;&nbsp;·&nbsp;&nbsp;PS &amp; City resolved automatically."
                    />
                </div>
            </div>

            {/* ── Footer : Action Buttons (right-aligned, inside container) */}
            <div style={footerCardStyle}>
                <Divider className="mt-0 mb-3" />
                <div className="flex justify-content-end gap-2">
                    <Button
                        label="Clear Form"
                        icon="pi pi-refresh"
                        outlined
                        severity="secondary"
                        size="small"
                        onClick={handleReset}
                        disabled={submitting}
                    />
                    <Button
                        label={submitting ? 'Registering…' : 'Register Complaint'}
                        icon={submitting ? 'pi pi-spin pi-spinner' : 'pi pi-check'}
                        size="small"
                        onClick={handleSubmit}
                        disabled={submitting}
                    />
                </div>
            </div>
        </div>
    );
}
