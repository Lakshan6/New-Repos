import React, { useState, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { RadioButton } from 'primereact/radiobutton';
import { Checkbox } from 'primereact/checkbox';
import { Calendar } from 'primereact/calendar';
import { Tag } from 'primereact/tag';
import { TabView, TabPanel } from 'primereact/tabview';
import { ProgressSpinner } from 'primereact/progressspinner';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Divider } from 'primereact/divider';
import { useQuery } from '@tanstack/react-query';
import { useAtom } from 'jotai';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';
import { useMutationApi } from '@shared/hooks';
import { syncTriggerAtom } from '@modules/dashboard/store/atoms';

const formatDateTime = (date) => {
    const utc = new Date(date.getTime() - date.getTimezoneOffset() * 60000);
    return utc.toISOString().slice(0, 19);
};

const fmtDate = (s) => new Date(s).toLocaleDateString();
const fmtTime = (s) => new Date(s).toLocaleString();

const getAuthHeaders = () => {
    const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
    return token ? { Authorization: `Bearer ${token}` } : {};
};

const SYNC_OPTIONS = [
    { label: 'Full Sync', value: '1', icon: 'pi pi-refresh' },
    { label: 'Delete', value: '3', icon: 'pi pi-trash' },
];

const S = {
    itemWrap: { fontSize: '0.83rem' },
    tag: { fontSize: '0.7rem' },
    errMsg: { fontSize: '0.75rem' },
    spinner: { width: '1.75rem', height: '1.75rem' },
    inboxIcon: { fontSize: '2rem' },
    historyList: { maxHeight: '320px', overflowY: 'auto' },
    errorBanner: {
        background: 'var(--red-50)',
        borderColor: 'var(--red-200)',
        color: 'var(--red-800)',
    },
    letterSpacing: { letterSpacing: '0.05em' },
    radioIcon: { fontSize: '0.85rem' },
    calPanel: { zIndex: 9999 },
    statusSuccess: {
        background: 'var(--green-50)',
        borderColor: 'var(--green-200)',
        color: 'var(--green-800)',
    },
    statusError: {
        background: 'var(--red-50)',
        borderColor: 'var(--red-200)',
        color: 'var(--red-800)',
    },
    statusWarn: {
        background: 'var(--yellow-50)',
        borderColor: 'var(--yellow-200)',
        color: 'var(--yellow-800)',
    },
    dialog: { width: '620px' },
};

const STATUS_STYLE = { success: S.statusSuccess, error: S.statusError, warn: S.statusWarn };
const STATUS_ICON = {
    success: 'pi-check-circle',
    error: 'pi-times-circle',
    warn: 'pi-exclamation-triangle',
};

const TOOLTIP_OPTIONS = { position: 'bottom' };

// ─── HistoryItem ──────────────────────────────────────────────────────────────

const HistoryItem = ({ item }) => (
    <div
        className="border-1 border-round surface-border surface-ground p-3 mb-2"
        style={S.itemWrap}
    >
        <div className="flex align-items-center justify-content-between mb-2">
            <span className="flex align-items-center gap-2 text-color-secondary">
                <i className="pi pi-clock" />
                {fmtTime(item.executedAt)}
            </span>
            <Tag
                value={item.status}
                severity={item.status === 'SUCCESS' ? 'success' : 'danger'}
                style={S.tag}
            />
        </div>

        <div className="flex align-items-center gap-2 mb-1">
            <i className="pi pi-calendar text-primary" />
            <span>
                <strong>Range:</strong>&nbsp;
                {fmtDate(item.fromDatetime)} → {fmtDate(item.toDatetime)}
            </span>
        </div>

        <div className="flex align-items-center gap-2 text-color-secondary">
            <i className="pi pi-database" />
            Records processed: <strong className="ml-1">{item.recordsProcessed ?? 0}</strong>
        </div>

        <div className="flex align-items-center gap-2 text-color-secondary mt-1">
            <i className="pi pi-refresh" />
            Every Day:{' '}
            <strong className="ml-1">
                {item.everyDay == null ? 'null' : item.everyDay ? 'Yes' : 'No'}
            </strong>
        </div>

        {item.errorMessage && (
            <div className="mt-2 text-red-500" style={S.errMsg}>
                <i className="pi pi-exclamation-circle mr-1" />
                {item.errorMessage}
            </div>
        )}
    </div>
);

HistoryItem.propTypes = {
    item: PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
        executedAt: PropTypes.string.isRequired,
        status: PropTypes.string.isRequired,
        fromDatetime: PropTypes.string.isRequired,
        toDatetime: PropTypes.string.isRequired,
        recordsProcessed: PropTypes.number,
        everyDay: PropTypes.bool,
        errorMessage: PropTypes.string,
    }).isRequired,
};

// ─── HistoryPanel ─────────────────────────────────────────────────────────────

function HistoryPanel() {
    const {
        data: rawData,
        isLoading,
        isError,
        error,
        refetch,
    } = useQuery({
        queryKey: ['irs-sync-history'],
        queryFn: () =>
            apiRequest({
                method: 'GET',
                service: 'irs',
                endpoint: '/complaint/syncHistory',
                useGateway: true,
                headers: getAuthHeaders(),
            }),
        staleTime: 0,
        refetchOnMount: true,
        refetchOnWindowFocus: false,
        retry: 1,
    });

    const handleRetry = useCallback(() => refetch(), [refetch]);

    const list = useMemo(() => {
        if (Array.isArray(rawData)) return rawData;
        if (rawData && Array.isArray(rawData.data)) return rawData.data;
        if (rawData && Array.isArray(rawData.content)) return rawData.content;
        return [];
    }, [rawData]);

    const grouped = useMemo(() => {
        const g = { full: [], delta: [], delete: [] };
        list.forEach((item) => {
            const t = item.syncType;
            if (t === '1') g.full.push(item);
            else if (t === '2') g.delta.push(item);
            else if (t === '3' || t === 'DELETE') g.delete.push(item);
        });
        return g;
    }, [list]);

    if (isLoading) {
        return (
            <div className="flex align-items-center justify-content-center p-5 gap-3">
                <ProgressSpinner style={S.spinner} />
                <span className="text-color-secondary">Loading history…</span>
            </div>
        );
    }

    if (isError) {
        return (
            <div
                className="flex align-items-center gap-2 p-3 border-round border-1"
                style={S.errorBanner}
            >
                <i className="pi pi-exclamation-triangle" />
                <span>{error?.message || 'Failed to load history'}</span>
                <Button
                    label="Retry"
                    icon="pi pi-refresh"
                    size="small"
                    className="p-button-text p-button-sm ml-2"
                    onClick={handleRetry}
                />
            </div>
        );
    }

    const hasData = grouped.full.length || grouped.delta.length || grouped.delete.length;

    if (!hasData) {
        return (
            <div className="flex flex-column align-items-center justify-content-center gap-2 p-5 text-color-secondary">
                <i className="pi pi-inbox" style={S.inboxIcon} />
                <span>No history found</span>
            </div>
        );
    }

    const renderList = (items) =>
        items.length ? (
            <div style={S.historyList}>
                {items.map((item) => (
                    <HistoryItem key={item.id} item={item} />
                ))}
            </div>
        ) : (
            <div className="flex align-items-center justify-content-center p-4 text-color-secondary">
                No records
            </div>
        );

    return (
        <TabView>
            <TabPanel header={`Full Sync (${grouped.full.length})`}>
                {renderList(grouped.full)}
            </TabPanel>
            <TabPanel header={`Delta Sync (${grouped.delta.length})`}>
                {renderList(grouped.delta)}
            </TabPanel>
            <TabPanel header={`Delete (${grouped.delete.length})`}>
                {renderList(grouped.delete)}
            </TabPanel>
        </TabView>
    );
}

// ─── SyncForm ─────────────────────────────────────────────────────────────────

function SyncForm() {
    const [syncType, setSyncType] = useState('1');
    const [everyDay, setEveryDay] = useState(false);
    const [dateRange, setDateRange] = useState([null, new Date()]);
    const [status, setStatus] = useState(null);
    const [syncLoading, setSyncLoading] = useState(false);
    const [, setSyncTrigger] = useAtom(syncTriggerAtom);

    const handleSyncTypeChange = useCallback((e) => {
        setSyncType(e.value);
        setStatus(null);
    }, []);

    const handleFromChange = useCallback(
        (e) => setDateRange((prev) => [e.value, prev?.[1] ?? new Date()]),
        [],
    );

    const handleToChange = useCallback(
        (e) => setDateRange((prev) => [prev?.[0] ?? null, e.value]),
        [],
    );

    const handleEveryDayChange = useCallback((e) => {
        setEveryDay(e.checked);
        if (e.checked) {
            setDateRange((prev) => [prev?.[0] ?? null, new Date()]);
        }
    }, []);

    const { mutate: deleteRecords, isPending: deleteLoading } = useMutationApi({
        service: 'irs',
        endpoint: '/complaint/deleteByPostingDate',
        method: 'POST',
        useGateway: true,
        headers: getAuthHeaders(),
        options: {
            onSuccess: (result) => {
                const n = result?.deletedRecords ?? 0;
                setStatus({
                    type: 'success',
                    message: `Deleted successfully. ${n} record(s) removed.`,
                });
            },
            onError: (err) => {
                setStatus({ type: 'error', message: err?.message || 'Delete failed.' });
            },
        },
    });

    const loading = syncLoading || deleteLoading;

    const radioCardStyleMap = useMemo(() => {
        const map = {};
        SYNC_OPTIONS.forEach((opt) => {
            const active = syncType === opt.value;
            const isDanger = opt.value === '3';
            map[opt.value] = {
                borderColor: active
                    ? isDanger
                        ? 'var(--red-400)'
                        : 'var(--primary-600)'
                    : 'var(--surface-border)',
                background: active
                    ? isDanger
                        ? 'var(--red-50)'
                        : 'var(--primary-50)'
                    : 'var(--surface-ground)',
                color: active
                    ? isDanger
                        ? 'var(--red-600)'
                        : 'var(--primary-700)'
                    : 'var(--text-color)',
                fontWeight: active ? 600 : 400,
                fontSize: '0.85rem',
                userSelect: 'none',
            };
        });
        return map;
    }, [syncType]);

    const handleSync = useCallback(() => {
        if (!dateRange?.[0] || !dateRange?.[1]) {
            setStatus({ type: 'warn', message: 'Please select a date range.' });
            return;
        }

        const toDate = everyDay ? new Date() : dateRange[1];
        const fromDateTime = formatDateTime(dateRange[0]);
        const toDateTime = formatDateTime(toDate);
        setStatus(null);

        if (syncType === '3') {
            confirmDialog({
                message:
                    'This will permanently delete records in the selected date range. Continue?',
                header: 'Confirm Delete',
                icon: 'pi pi-exclamation-triangle',
                acceptClassName: 'p-button-danger',
                accept: () =>
                    deleteRecords({
                        requestInfo: { authToken: localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) },
                        fromDateTime,
                        toDateTime,
                    }),
            });
        } else {
            const params = new URLSearchParams({
                type: syncType,
                fromDateTime,
                toDateTime,
                everyDay,
            }).toString();

            setSyncLoading(true);
            apiRequest({
                method: 'GET',
                service: 'irs',
                endpoint: `/complaint/fetchFromSoap?${params}`,
                useGateway: true,
                headers: getAuthHeaders(),
            })
                .then((result) => {
                    const n = result?.records ?? 0;
                    setStatus({
                        type: 'success',
                        message: `Sync complete. ${n} record(s) processed.`,
                    });
                    setSyncTrigger((n) => n + 1);
                })
                .catch((err) => {
                    setStatus({ type: 'error', message: err?.message || 'Sync failed.' });
                })
                .finally(() => setSyncLoading(false));
        }
    }, [syncType, everyDay, dateRange, deleteRecords, setSyncTrigger]);

    const statusBannerStyle = status ? STATUS_STYLE[status.type] : null;

    return (
        <div className="flex flex-column gap-4">
            {/* Operation type selector */}
            <fieldset className="border-none p-0 m-0">
                <legend
                    className="text-xs font-semibold text-color-secondary uppercase mb-2 p-0"
                    style={S.letterSpacing}
                >
                    Operation Type
                </legend>
                <div className="flex gap-2">
                    {SYNC_OPTIONS.map((opt) => (
                        /* <label> is a native interactive element — satisfies a11y rules */
                        <label
                            key={opt.value}
                            htmlFor={`st-${opt.value}`}
                            className="flex-1 flex align-items-center justify-content-center gap-2 border-round border-1 p-2 cursor-pointer transition-all transition-duration-150"
                            style={radioCardStyleMap[opt.value]}
                        >
                            <RadioButton
                                inputId={`st-${opt.value}`}
                                value={opt.value}
                                checked={syncType === opt.value}
                                onChange={handleSyncTypeChange}
                            />
                            <i className={opt.icon} style={S.radioIcon} />
                            <span>{opt.label}</span>
                        </label>
                    ))}
                </div>
            </fieldset>

            {/* Date range */}
            <div className="flex gap-4">
                <div className="flex flex-column gap-2 flex-1">
                    <label
                        htmlFor="sync-date-from"
                        className="text-xs font-semibold text-color-secondary uppercase"
                        style={S.letterSpacing}
                    >
                        From
                    </label>
                    <Calendar
                        inputId="sync-date-from"
                        value={dateRange?.[0] ?? null}
                        onChange={handleFromChange}
                        dateFormat="dd-mm-yy"
                        placeholder="dd-mm-yyyy"
                        showIcon
                        maxDate={dateRange?.[1] ?? undefined}
                        readOnlyInput
                        className="w-full"
                        inputClassName="w-full"
                        panelStyle={S.calPanel}
                    />
                </div>

                <div className="flex flex-column gap-2 flex-1">
                    <label
                        htmlFor="sync-date-to"
                        className="text-xs font-semibold text-color-secondary uppercase"
                        style={S.letterSpacing}
                    >
                        To
                    </label>
                    <Calendar
                        inputId="sync-date-to"
                        value={everyDay ? new Date() : (dateRange?.[1] ?? null)}
                        onChange={handleToChange}
                        dateFormat="dd-mm-yy"
                        placeholder="dd-mm-yyyy"
                        showIcon
                        disabled={everyDay}
                        readOnlyInput
                        minDate={dateRange?.[0] ?? undefined}
                        className="w-full"
                        inputClassName="w-full"
                        panelStyle={S.calPanel}
                    />
                </div>
            </div>

            {syncType === '1' && (
                <div className="flex align-items-center gap-2">
                    <Checkbox
                        inputId="every-day"
                        checked={everyDay}
                        onChange={handleEveryDayChange}
                    />
                    <label htmlFor="every-day" className="text-sm cursor-pointer">
                        Every Day{' '}
                        <span className="text-color-secondary">(auto-set To date to today)</span>
                    </label>
                </div>
            )}

            {status && (
                <div
                    className="flex align-items-center gap-2 border-round border-1 px-3 py-2"
                    style={statusBannerStyle}
                >
                    <i className={`pi ${STATUS_ICON[status.type]}`} />
                    {status.message}
                </div>
            )}

            <Divider className="my-0" />

            <div className="flex justify-content-end">
                <Button
                    label={
                        loading ? 'Processing…' : syncType === '3' ? 'Delete Records' : 'Start Sync'
                    }
                    icon={
                        loading
                            ? 'pi pi-spin pi-spinner'
                            : syncType === '3'
                              ? 'pi pi-trash'
                              : 'pi pi-play'
                    }
                    severity={syncType === '3' ? 'danger' : 'primary'}
                    disabled={loading}
                    onClick={handleSync}
                />
            </div>
        </div>
    );
}

// ─── DataSync ─────────────────────────────────────────────────────────────────

function DataSync() {
    const [open, setOpen] = useState(false);
    const [view, setView] = useState('form');

    const openModal = useCallback(() => {
        setView('form');
        setOpen(true);
    }, []);
    const closeModal = useCallback(() => setOpen(false), []);
    const toggleView = useCallback(
        () => setView((v) => (v === 'history' ? 'form' : 'history')),
        [],
    );

    const headerEl = useMemo(
        () => (
            <div className="flex align-items-center justify-content-between w-full pr-3">
                <span className="flex align-items-center gap-2 font-semibold text-base">
                    <i className={view === 'history' ? 'pi pi-history' : 'pi pi-sync'} />
                    {view === 'history' ? 'Sync History' : 'Data Synchronization'}
                </span>
                <Button
                    label={view === 'history' ? 'Back to Sync' : 'View History'}
                    icon={view === 'history' ? 'pi pi-arrow-left' : 'pi pi-history'}
                    size="small"
                    severity="secondary"
                    className="p-button-text"
                    onClick={toggleView}
                />
            </div>
        ),
        [view, toggleView],
    );

    return (
        <>
            <ConfirmDialog />

            <Button
                type="button"
                tooltip="Synchronise data"
                tooltipOptions={TOOLTIP_OPTIONS}
                className="p-link layout-topbar-button text-primary-700 text-xl hover:bg-primary-50 hover:border-round p-2 transition-colors transition-duration-200"
                onClick={openModal}
            >
                <i className="pi pi-sync" />
            </Button>

            <Dialog
                visible={open}
                onHide={closeModal}
                header={headerEl}
                style={S.dialog}
                modal
                draggable={false}
                resizable={false}
            >
                {view === 'form' ? <SyncForm /> : <HistoryPanel />}
            </Dialog>
        </>
    );
}

export { DataSync };
