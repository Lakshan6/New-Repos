import React, { useMemo, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { TabView, TabPanel } from 'primereact/tabview';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';

const EXPORT_BTN_STYLE = {
    borderColor: '#0F3E66',
    color: '#0F3E66',
    height: '2rem',
    fontSize: '0.75rem',
};

const EXPORT_WRAPPER_STYLE = {
    top: 0,
    right: 0,
    height: '2.8rem',
};

const HEALTH_TABLE_PT = { wrapper: { style: { height: '30rem' } } };
const HEALTH_TABLE_STYLE = { width: '100%' };

const sortByDate = (e) => {
    const parseDate = (str) => {
        if (!str) return 0;
        const [dd, MM, yyyy] = str.split('-');
        return new Date(`${yyyy}-${MM}-${dd}`).getTime();
    };

    return [...e.data].sort((a, b) => {
        const diff = parseDate(a.updated_date) - parseDate(b.updated_date);
        return e.order * diff;
    });
};

const SystemHealthStatus = ({ fullOpsData, nonOpsData, restrictedOpsData }) => {
    const [search, setSearch] = useState('');
    const [activeIndex, setActiveIndex] = useState(0);

    const onSearchChange = useCallback((e) => {
        setSearch(e.target.value);
    }, []);

    const onTabChangeHandler = useCallback((e) => {
        setActiveIndex(e.index);
    }, []);

    const filterRows = useCallback(
        (rows) =>
            rows.filter((row) =>
                Object.values(row).join(' ').toLowerCase().includes(search.toLowerCase()),
            ),
        [search],
    );

    const fullOpsFiltered = useMemo(() => filterRows(fullOpsData), [filterRows, fullOpsData]);
    const nonOpsFiltered = useMemo(() => filterRows(nonOpsData), [filterRows, nonOpsData]);
    const restrictedOpsFiltered = useMemo(
        () => filterRows(restrictedOpsData),
        [filterRows, restrictedOpsData],
    );

    const handleExportAllOps = useCallback(async () => {
        const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        try {
            const blob = await apiRequest({
                service: 'irs',
                endpoint: '/complaint/exportAllOps',
                method: 'GET',
                useGateway: true,
                headers: token ? { Authorization: `Bearer ${token}` } : {},
            });

            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'ops_data.xlsx';
            a.click();
            URL.revokeObjectURL(url);
        } catch (e) {
            console.error('Ops export failed', e);
        }
    }, []);

    // ── Render ───────────────────────────────────────────────────────────────
    return (
        <div className="flex flex-column gap-3">
            <InputText placeholder="Search here..." value={search} onChange={onSearchChange} />

            <div className="relative">
                <TabView activeIndex={activeIndex} onTabChange={onTabChangeHandler}>
                    <TabPanel header="Non Ops">
                        <HealthTable value={nonOpsFiltered} />
                    </TabPanel>
                    <TabPanel header="Restricted Ops">
                        <HealthTable value={restrictedOpsFiltered} />
                    </TabPanel>
                    <TabPanel header="Full Ops">
                        <HealthTable value={fullOpsFiltered} />
                    </TabPanel>
                </TabView>

                {/* Export Button */}
                <div className="absolute flex align-items-center" style={EXPORT_WRAPPER_STYLE}>
                    <Button
                        icon="pi pi-file-excel"
                        label="Export Excel"
                        size="small"
                        outlined
                        onClick={handleExportAllOps}
                        style={EXPORT_BTN_STYLE}
                    />
                </div>
            </div>
        </div>
    );
};

// ── Table Component ──────────────────────────────────────────────────────────
const HealthTable = ({ value }) => {
    return (
        <DataTable
            value={value}
            paginator
            rows={10}
            rowsPerPageOptions={[10, 15, 20]}
            stripedRows
            showGridlines
            size="small"
            removableSort
            scrollable
            scrollHeight="30rem"
            style={HEALTH_TABLE_STYLE}
            pt={HEALTH_TABLE_PT}
        >
            <Column field="complaint_no" header="Complaint No" sortable className="text-sm" />
            <Column
                field="project_name"
                header="Project"
                sortable
                className="max-w-10rem text-sm"
            />
            <Column field="status_desc" header="Status" sortable className="text-sm" />
            <Column field="city" header="Location" sortable className="text-sm" />
            <Column field="sbu_description" header="SBU" sortable className="text-sm" />
            <Column
                field="updated_date"
                header="Updated"
                sortable
                sortFunction={sortByDate}
                className="text-sm"
            />
            <Column field="days" header="Days" sortable className="text-sm" />
        </DataTable>
    );
};

// ── PropTypes ────────────────────────────────────────────────────────────────
SystemHealthStatus.propTypes = {
    fullOpsData: PropTypes.array.isRequired,
    nonOpsData: PropTypes.array.isRequired,
    restrictedOpsData: PropTypes.array.isRequired,
};

HealthTable.propTypes = {
    value: PropTypes.array.isRequired,
};

export { SystemHealthStatus };
