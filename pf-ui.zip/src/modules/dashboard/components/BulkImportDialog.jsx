import React, { useState, useCallback, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { RadioButton } from 'primereact/radiobutton';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';

/* ─── config ─────────────────────────────────────────────────────────────── */

const BULK_MAP = {
    employee: {
        label: 'Employee',
        icon: 'pi pi-users',
        module: 'employee',
        endpoints: [
            {
                id: '_bulkCreateEmployeeMOData',
                label: 'Employee MO Data',
                template: 'mo-datasample.csv',
                dataType: 'EMPLOYEE_MO_DATA',
            },
            {
                id: '_bulkCreateStationedPeopleData',
                label: 'Stationed People Data',
                template: 'stationed-people-datasample.csv',
                dataType: 'STATIONED_PEOPLE_DATA',
            },
            {
                id: '_bulkCreateContigencyData',
                label: 'Contingency Data',
                template: 'contingency-datasample.csv',
                dataType: 'CONTIGENCY_DATA',
            },
        ],
    },
    customer: {
        label: 'Customer',
        icon: 'pi pi-building',
        module: 'customer',
        endpoints: [
            {
                id: '_bulkCreatePs',
                label: 'PS Data',
                template: 'ps-datasample.csv',
                dataType: 'PS_DATA',
            },
            {
                id: '_bulkCreateCustomers',
                label: 'Customer Master Data',
                template: 'cutomer-master-datasample.csv',
                dataType: 'CUSTOMER_DATA',
            },
            {
                id: '_bulkCreateProjectCustomerMapping',
                label: 'Project Customer Mapping Data',
                template: 'project-customer-mapping-datasample.csv',
                dataType: 'MAPPING_DATA',
            },
            {
                id: '_bulkCreateCityMaster',
                label: 'City Master Data',
                template: 'city-master-datasample.csv',
                dataType: 'CITY_MASTER_DATA',
            },
        ],
    },
    complaint: {
        label: 'Complaint',
        icon: 'pi pi-file',
        module: 'complaint',
        endpoints: [
            {
                id: '_bulkCreateV1',
                label: 'Complaint Data',
                template: 'crm-datasample.csv',
                dataType: 'COMPLAINT_DATA',
            },
        ],
    },
};

/* ─── helpers ────────────────────────────────────────────────────────────── */

function flattenObject(obj, prefix = '', target = {}) {
    if (!obj || typeof obj !== 'object') return target;
    Object.keys(obj).forEach((key) => {
        const value = obj[key];
        const flatKey = prefix ? `${prefix}_${key}` : key;
        if (value && typeof value === 'object' && !Array.isArray(value)) {
            flattenObject(value, flatKey, target);
        } else if (Array.isArray(value)) {
            target[flatKey] = value.join(', ');
        } else {
            target[flatKey] = value;
        }
    });
    return target;
}

function getSummaryEntries(result) {
    if (!result || typeof result !== 'object') return [];
    return Object.entries(result).filter(([, v]) => typeof v === 'number');
}

function findArrayKey(result, ...terms) {
    if (!result || typeof result !== 'object') return null;
    return (
        Object.keys(result).find((k) => {
            const v = result[k];
            const lower = k.toLowerCase();
            return Array.isArray(v) && v.length > 0 && terms.some((t) => lower.includes(t));
        }) || null
    );
}

function buildTableData(items) {
    if (!Array.isArray(items) || items.length === 0) return { headers: [], rows: [] };
    const flatItems = items.map((item) => flattenObject(item));
    const headers = [...new Set(flatItems.flatMap(Object.keys))];
    const rows = flatItems.map((flat, idx) => ({
        id: String(idx),
        ...Object.fromEntries(headers.map((h) => [h, flat[h] ?? ''])),
    }));
    return { headers, rows };
}

/* ─── static styles ──────────────────────────────────────────────────────── */

const S = {
    dialogStyle: { width: '50vw', maxWidth: '700px' },
    dialogContentStyle: { padding: 0 },
    dialogPt: { content: { style: { borderRadius: '0 0 8px 8px' } } },
    wrapper: { minHeight: '26rem' },
    leftPanel: {
        width: '260px',
        flexShrink: 0,
        padding: '1.5rem',
        background: '#f8fafc',
        borderRight: '1px solid #e2e8f0',
        borderRadius: '0 0 0 8px',
    },
    stepLabel: { letterSpacing: '0.07em' },
    rightPanel: { padding: '1.5rem', minWidth: 0 },
    downloadBtnStyle: { borderColor: '#0F3E66', color: '#0F3E66' },
    filePreviewBox: { background: '#f0fdf4', border: '1px solid #86efac' },
    filePreviewInner: { minWidth: 0 },
    hiddenInput: { display: 'none' },
    submitBtnStyle: { background: '#0F3E66', border: 'none', alignSelf: 'flex-start' },
    placeholderWrap: { color: '#cbd5e1' },
    placeholderIcon: { fontSize: '3.5rem' },
    placeholderText: { color: '#94a3b8', maxWidth: '200px' },
    errorBox: { background: '#fef2f2', border: '1px solid #fca5a5', color: '#b91c1c' },
    summaryLabel: { letterSpacing: '0.07em' },
    failedLabel: { letterSpacing: '0.07em', color: '#dc2626' },
    failedTableWrap: { height: '20rem', overflow: 'hidden' },
    failedTableStyle: { width: '100%' },
    errorsLabel: { letterSpacing: '0.07em', color: '#dc2626' },
    errorList: { color: '#b91c1c' },
    successBox: { background: '#f0fdf4', border: '1px solid #86efac', color: '#16a34a' },
    emptyState: { color: '#cbd5e1' },
    emptyStateText: { color: '#94a3b8' },
    browseStyle: { color: '#0F3E66' },
    columnStyle: { whiteSpace: 'nowrap' },
};

/* ─── item active / idle styles (static, reused across renders) ──────────── */

const ITEM_ACTIVE_STYLE = { background: '#daeaf8', border: '1px solid #0F3E66' };
const ITEM_IDLE_STYLE = { background: 'transparent', border: '1px solid transparent' };

/* ─── static dialog header ───────────────────────────────────────────────── */

const DIALOG_HEADER = (
    <div className="flex align-items-center gap-2">
        <i className="pi pi-cloud-upload text-primary-700 text-xl" />
        <span className="font-bold text-primary-700 text-lg">Bulk Data Import</span>
    </div>
);

/* ─── action-type options (static) ──────────────────────────────────────── */

const ACTION_ITEMS = [
    { value: 'UPDATE', label: 'Update only' },
    { value: 'DELETE_AND_UPDATE', label: 'Delete & update' },
];

/* ─── sub-components ─────────────────────────────────────────────────────── */

const ModuleItem = React.memo(({ itemKey, active, onSelect }) => {
    const handleClick = useCallback(() => onSelect(itemKey), [itemKey, onSelect]);
    const handleKeyDown = useCallback(
        (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect(itemKey);
            }
        },
        [itemKey, onSelect],
    );
    return (
        <div
            role="button"
            tabIndex={0}
            className="flex align-items-center gap-2 p-2 border-round cursor-pointer transition-colors transition-duration-150"
            style={active ? ITEM_ACTIVE_STYLE : ITEM_IDLE_STYLE}
            onClick={handleClick}
            onKeyDown={handleKeyDown}
        >
            <RadioButton
                inputId={`cat-${itemKey}`}
                value={itemKey}
                checked={active}
                onChange={handleClick}
            />
            <i
                className={`${BULK_MAP[itemKey].icon} text-sm ${active ? 'text-primary-700' : 'text-color-secondary'}`}
            />
            <label
                htmlFor={`cat-${itemKey}`}
                className={`cursor-pointer text-sm font-medium ${active ? 'text-primary-700' : ''}`}
            >
                {BULK_MAP[itemKey].label}
            </label>
        </div>
    );
});

ModuleItem.propTypes = {
    itemKey: PropTypes.string.isRequired,
    active: PropTypes.bool.isRequired,
    onSelect: PropTypes.func.isRequired,
};
ModuleItem.displayName = 'ModuleItem';

/* ─── ─── ─── ─── */

const EndpointItem = React.memo(({ ep, active, onSelect }) => {
    const handleClick = useCallback(() => onSelect(ep.id), [ep.id, onSelect]);
    const handleKeyDown = useCallback(
        (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect(ep.id);
            }
        },
        [ep.id, onSelect],
    );
    return (
        <div
            role="button"
            tabIndex={0}
            className="flex align-items-center gap-2 p-2 border-round cursor-pointer transition-colors transition-duration-150"
            style={active ? ITEM_ACTIVE_STYLE : ITEM_IDLE_STYLE}
            onClick={handleClick}
            onKeyDown={handleKeyDown}
        >
            <RadioButton inputId={ep.id} value={ep.id} checked={active} onChange={handleClick} />
            <label
                htmlFor={ep.id}
                className={`cursor-pointer text-sm ${active ? 'font-medium text-primary-700' : ''}`}
            >
                {ep.label}
            </label>
        </div>
    );
});

EndpointItem.propTypes = {
    ep: PropTypes.shape({ id: PropTypes.string, label: PropTypes.string }).isRequired,
    active: PropTypes.bool.isRequired,
    onSelect: PropTypes.func.isRequired,
};
EndpointItem.displayName = 'EndpointItem';

/* ─── ─── ─── ─── */

const ActionItem = React.memo(({ value, label, checked, onSelect }) => {
    const handleClick = useCallback(() => onSelect(value), [value, onSelect]);
    const handleKeyDown = useCallback(
        (e) => {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                onSelect(value);
            }
        },
        [value, onSelect],
    );
    return (
        <div
            role="button"
            tabIndex={0}
            className="flex align-items-center gap-2 p-2 border-round cursor-pointer"
            onClick={handleClick}
            onKeyDown={handleKeyDown}
        >
            <RadioButton
                inputId={`action-${value}`}
                value={value}
                checked={checked}
                onChange={handleClick}
            />
            <label htmlFor={`action-${value}`} className="cursor-pointer text-sm">
                {label}
            </label>
        </div>
    );
});

ActionItem.propTypes = {
    value: PropTypes.string.isRequired,
    label: PropTypes.string.isRequired,
    checked: PropTypes.bool.isRequired,
    onSelect: PropTypes.func.isRequired,
};
ActionItem.displayName = 'ActionItem';

/* ─── ─── ─── ─── */

const SummaryCard = React.memo(({ keyName, value }) => {
    const isGood =
        keyName.toLowerCase().includes('success') || keyName.toLowerCase().includes('created');
    const isBad = keyName.toLowerCase().includes('fail') || keyName.toLowerCase().includes('error');

    const cardStyle = useMemo(
        () => ({
            minWidth: '7rem',
            background: isGood ? '#f0fdf4' : isBad ? '#fef2f2' : '#f8fafc',
            border: `1px solid ${isGood ? '#86efac' : isBad ? '#fca5a5' : '#e2e8f0'}`,
        }),
        [isGood, isBad],
    );

    const valueStyle = useMemo(
        () => ({ color: isGood ? '#16a34a' : isBad ? '#dc2626' : '#0F3E66' }),
        [isGood, isBad],
    );

    return (
        <div className="flex flex-column align-items-center p-3 border-round" style={cardStyle}>
            <span className="text-2xl font-bold" style={valueStyle}>
                {value}
            </span>
            <span className="text-xs text-color-secondary mt-1 text-center">{keyName}</span>
        </div>
    );
});

SummaryCard.propTypes = {
    keyName: PropTypes.string.isRequired,
    value: PropTypes.number.isRequired,
};
SummaryCard.displayName = 'SummaryCard';

/* ─── component ──────────────────────────────────────────────────────────── */

const BulkImportDialog = ({ visible, onHide }) => {
    const [selectedModule, setSelectedModule] = useState('');
    const [selectedEndpoint, setSelectedEndpoint] = useState('');
    const [file, setFile] = useState(null);
    const [actionType, setActionType] = useState('UPDATE');
    const [result, setResult] = useState(null);
    const [loading, setLoading] = useState(false);
    const [downloadLoading, setDownloadLoading] = useState(false);
    const [dragOver, setDragOver] = useState(false);

    const fileInputRef = useRef(null);

    const handleModuleChange = useCallback((value) => {
        setSelectedModule(value);
        setSelectedEndpoint('');
        setFile(null);
        setResult(null);
    }, []);

    const handleEndpointChange = useCallback((value) => {
        setSelectedEndpoint(value);
        setResult(null);
    }, []);

    const handleFile = useCallback((f) => {
        if (f && (f.name.endsWith('.xlsx') || f.name.endsWith('.csv'))) {
            setFile(f);
            setResult(null);
        }
    }, []);

    const handleDrop = useCallback(
        (e) => {
            e.preventDefault();
            setDragOver(false);
            handleFile(e.dataTransfer.files?.[0]);
        },
        [handleFile],
    );

    const handleDragOver = useCallback((e) => {
        e.preventDefault();
        setDragOver(true);
    }, []);

    const handleDragLeave = useCallback(() => setDragOver(false), []);

    const handleDropZoneClick = useCallback(() => fileInputRef.current?.click(), []);

    const handleDropZoneKeyDown = useCallback((e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            fileInputRef.current?.click();
        }
    }, []);

    const handleFileInputChange = useCallback((e) => handleFile(e.target.files?.[0]), [handleFile]);

    const handleClearFile = useCallback(() => setFile(null), []);

    const handleDownloadTemplate = useCallback(async () => {
        if (!selectedModule || !selectedEndpoint) return;
        const ep = BULK_MAP[selectedModule].endpoints.find((e) => e.id === selectedEndpoint);
        if (!ep) return;
        const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        setDownloadLoading(true);
        try {
            const blob = await apiRequest({
                service: 'irs',
                endpoint: `/${BULK_MAP[selectedModule].module}/downloadTemplateExcel?dataType=${ep.dataType}`,
                method: 'GET',
                useGateway: true,
                headers: token ? { Authorization: `Bearer ${token}` } : {},
            });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = ep.dataType.toLowerCase() + '_template.xlsx';
            a.click();
            URL.revokeObjectURL(url);
        } catch (e) {
            console.error('Template download failed', e);
        } finally {
            setDownloadLoading(false);
        }
    }, [selectedModule, selectedEndpoint]);

    const handleSubmit = useCallback(async () => {
        if (!selectedModule || !selectedEndpoint || !file) return;
        setLoading(true);
        setResult(null);
        const formData = new FormData();
        formData.append('file', file);
        formData.append('actionType', actionType);
        const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        try {
            const res = await apiRequest({
                service: 'irs',
                endpoint: `/${BULK_MAP[selectedModule].module}/${selectedEndpoint}`,
                method: 'POST',
                useGateway: true,
                headers: token ? { Authorization: `Bearer ${token}` } : {},
                body: formData,
            });
            setResult(res ?? null);
        } catch (e) {
            setResult({ error: e.message || 'Upload failed' });
        } finally {
            setLoading(false);
        }
    }, [selectedModule, selectedEndpoint, file, actionType]);

    const handleClose = useCallback(() => {
        setSelectedModule('');
        setSelectedEndpoint('');
        setFile(null);
        setActionType('UPDATE');
        setResult(null);
        onHide();
    }, [onHide]);

    /* ── derived state ── */

    const summaryEntries = useMemo(() => getSummaryEntries(result), [result]);
    const failedKey = useMemo(() => findArrayKey(result, 'failed', 'notcreated'), [result]);
    const failedTable = useMemo(
        () => buildTableData(failedKey ? result[failedKey] : []),
        [result, failedKey],
    );
    const errorDescList = useMemo(
        () => (Array.isArray(result?.errorDescList) ? result.errorDescList : []),
        [result],
    );
    const hasResult = result !== null;
    const canSubmit = selectedModule && selectedEndpoint && file && !loading;

    /* ── dynamic styles ── */

    const dropZoneStyle = useMemo(
        () => ({
            border: `2px dashed ${dragOver ? '#0F3E66' : '#cbd5e1'}`,
            borderRadius: '10px',
            padding: '2.5rem 1rem',
            textAlign: 'center',
            cursor: 'pointer',
            background: dragOver ? '#f0f7ff' : '#fafbfc',
            transition: 'all 0.2s',
        }),
        [dragOver],
    );

    const dropZoneIconStyle = useMemo(
        () => ({ color: dragOver ? '#0F3E66' : '#94a3b8' }),
        [dragOver],
    );

    /* ── render ── */

    return (
        <Dialog
            header={DIALOG_HEADER}
            visible={visible}
            onHide={handleClose}
            modal
            draggable={false}
            style={S.dialogStyle}
            contentStyle={S.dialogContentStyle}
            pt={S.dialogPt}
        >
            <div className="flex" style={S.wrapper}>
                {/* ── Left panel ───────────────────────────────────── */}
                <div className="flex flex-column gap-3" style={S.leftPanel}>
                    {/* Step 1 */}
                    <div>
                        <p
                            className="text-xs font-bold text-color-secondary uppercase mb-2"
                            style={S.stepLabel}
                        >
                            1 · Data Category
                        </p>
                        <div className="flex flex-column gap-1">
                            {Object.keys(BULK_MAP).map((key) => (
                                <ModuleItem
                                    key={key}
                                    itemKey={key}
                                    active={selectedModule === key}
                                    onSelect={handleModuleChange}
                                />
                            ))}
                        </div>
                    </div>

                    {/* Step 2 */}
                    {selectedModule && (
                        <div>
                            <p
                                className="text-xs font-bold text-color-secondary uppercase mb-2"
                                style={S.stepLabel}
                            >
                                2 · Upload Type
                            </p>
                            <div className="flex flex-column gap-1">
                                {BULK_MAP[selectedModule].endpoints.map((ep) => (
                                    <EndpointItem
                                        key={ep.id}
                                        ep={ep}
                                        active={selectedEndpoint === ep.id}
                                        onSelect={handleEndpointChange}
                                    />
                                ))}
                            </div>
                        </div>
                    )}

                    {/* Action type */}
                    {file && (
                        <div>
                            <p
                                className="text-xs font-bold text-color-secondary uppercase mb-2"
                                style={S.stepLabel}
                            >
                                3 · Action Type
                            </p>
                            <div className="flex flex-column gap-1">
                                {ACTION_ITEMS.map(({ value, label }) => (
                                    <ActionItem
                                        key={value}
                                        value={value}
                                        label={label}
                                        checked={actionType === value}
                                        onSelect={setActionType}
                                    />
                                ))}
                            </div>
                        </div>
                    )}
                </div>

                {/* ── Right panel ───────────────────────────────────── */}
                <div className="flex flex-column flex-1" style={S.rightPanel}>
                    {/* Upload area (shown when endpoint selected) */}
                    {selectedEndpoint ? (
                        <div className="flex flex-column gap-3 mb-3">
                            <Button
                                icon={downloadLoading ? 'pi pi-spin pi-spinner' : 'pi pi-download'}
                                label={downloadLoading ? 'Processing…' : 'Download Existing Data'}
                                size="small"
                                outlined
                                disabled={downloadLoading}
                                onClick={handleDownloadTemplate}
                                className="align-self-start"
                                style={S.downloadBtnStyle}
                            />

                            {!file ? (
                                <div
                                    role="button"
                                    tabIndex={0}
                                    onClick={handleDropZoneClick}
                                    onKeyDown={handleDropZoneKeyDown}
                                    onDragOver={handleDragOver}
                                    onDragLeave={handleDragLeave}
                                    onDrop={handleDrop}
                                    style={dropZoneStyle}
                                >
                                    <i
                                        className="pi pi-cloud-upload text-4xl mb-3 block"
                                        style={dropZoneIconStyle}
                                    />
                                    <p className="m-0 text-sm text-color-secondary">
                                        Drag & drop your file here, or{' '}
                                        <span className="font-semibold" style={S.browseStyle}>
                                            browse
                                        </span>
                                    </p>
                                    <p className="m-0 mt-1 text-xs text-color-secondary">
                                        Supports .xlsx and .csv
                                    </p>
                                </div>
                            ) : (
                                <div
                                    className="flex align-items-center gap-3 p-3 border-round"
                                    style={S.filePreviewBox}
                                >
                                    <i className="pi pi-file-excel text-2xl text-green-600" />
                                    <div
                                        className="flex flex-column flex-1"
                                        style={S.filePreviewInner}
                                    >
                                        <span className="text-sm font-semibold text-green-800 text-overflow-ellipsis overflow-hidden white-space-nowrap">
                                            {file.name}
                                        </span>
                                        <span className="text-xs text-green-600">
                                            {(file.size / 1024).toFixed(1)} KB · Ready to upload
                                        </span>
                                    </div>
                                    <Button
                                        icon="pi pi-times"
                                        text
                                        rounded
                                        size="small"
                                        severity="danger"
                                        onClick={handleClearFile}
                                    />
                                </div>
                            )}

                            <input
                                ref={fileInputRef}
                                type="file"
                                accept=".xlsx,.csv"
                                style={S.hiddenInput}
                                onChange={handleFileInputChange}
                            />

                            <Button
                                label={loading ? 'Uploading…' : 'Submit'}
                                icon={loading ? 'pi pi-spin pi-spinner' : 'pi pi-upload'}
                                disabled={!canSubmit}
                                onClick={handleSubmit}
                                style={S.submitBtnStyle}
                            />
                        </div>
                    ) : (
                        /* Placeholder when nothing selected */
                        !hasResult && (
                            <div
                                className="flex flex-column align-items-center justify-content-center flex-1 gap-3"
                                style={S.placeholderWrap}
                            >
                                <i className="pi pi-cloud-upload" style={S.placeholderIcon} />
                                <p className="m-0 text-sm text-center" style={S.placeholderText}>
                                    Select a category and upload type to get started
                                </p>
                            </div>
                        )
                    )}

                    {/* Results */}
                    {hasResult && (
                        <div className="flex flex-column gap-3 flex-1 overflow-auto">
                            {result?.error && (
                                <div
                                    className="flex align-items-center gap-2 p-3 border-round text-sm"
                                    style={S.errorBox}
                                >
                                    <i className="pi pi-exclamation-triangle" />
                                    {result.error}
                                </div>
                            )}

                            {!result?.error && (
                                <>
                                    {summaryEntries.length > 0 && (
                                        <div>
                                            <p
                                                className="text-xs font-bold text-color-secondary uppercase mb-2"
                                                style={S.summaryLabel}
                                            >
                                                Summary
                                            </p>
                                            <div className="flex flex-wrap gap-2">
                                                {summaryEntries.map(([key, value]) => (
                                                    <SummaryCard
                                                        key={key}
                                                        keyName={key}
                                                        value={value}
                                                    />
                                                ))}
                                            </div>
                                        </div>
                                    )}

                                    {failedTable.headers.length > 0 && (
                                        <div className="flex flex-column gap-2">
                                            <p
                                                className="text-xs font-bold uppercase mb-0"
                                                style={S.failedLabel}
                                            >
                                                Failed Records
                                            </p>
                                            <div style={S.failedTableWrap}>
                                                <DataTable
                                                    value={failedTable.rows}
                                                    size="small"
                                                    stripedRows
                                                    showGridlines
                                                    removableSort
                                                    scrollable
                                                    scrollHeight="14rem"
                                                    style={S.failedTableStyle}
                                                    paginator
                                                    rows={8}
                                                >
                                                    {failedTable.headers.map((h) => (
                                                        <Column
                                                            key={h}
                                                            field={h}
                                                            header={h}
                                                            sortable
                                                            className="text-xs"
                                                            style={S.columnStyle}
                                                        />
                                                    ))}
                                                </DataTable>
                                            </div>
                                        </div>
                                    )}

                                    {errorDescList.length > 0 && (
                                        <div>
                                            <p
                                                className="text-xs font-bold uppercase mb-2"
                                                style={S.errorsLabel}
                                            >
                                                Errors
                                            </p>
                                            <ul className="m-0 pl-4 text-sm" style={S.errorList}>
                                                {errorDescList.map((err, i) => (
                                                    <li key={i}>{err}</li>
                                                ))}
                                            </ul>
                                        </div>
                                    )}

                                    {summaryEntries.length === 0 &&
                                        failedTable.headers.length === 0 &&
                                        errorDescList.length === 0 && (
                                            <div
                                                className="flex align-items-center gap-2 p-3 border-round text-sm"
                                                style={S.successBox}
                                            >
                                                <i className="pi pi-check-circle text-lg" />
                                                <span className="font-medium">
                                                    Upload completed successfully.
                                                </span>
                                            </div>
                                        )}
                                </>
                            )}
                        </div>
                    )}

                    {/* Empty right state when result pending */}
                    {!hasResult && selectedEndpoint && (
                        <div
                            className="flex align-items-center justify-content-center flex-1 gap-2"
                            style={S.emptyState}
                        >
                            <i className="pi pi-inbox text-4xl" />
                            <p className="m-0 text-sm" style={S.emptyStateText}>
                                Results will appear here after upload.
                            </p>
                        </div>
                    )}
                </div>
            </div>
        </Dialog>
    );
};

BulkImportDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
};

export { BulkImportDialog };
