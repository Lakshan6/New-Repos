import React, { useState, useEffect, useCallback, useRef, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { apiRequest, STORAGE_KEYS } from '@shared/utils';

const INDUSTRY_OPTIONS = [
    { label: 'Navy', value: 16 },
    { label: 'Air Force', value: 3 },
    { label: 'Army', value: 4 },
];

const FAULT_OPTIONS = [
    { label: 'Very high', value: 'Very high' },
    { label: 'High', value: 'High' },
    { label: 'Medium', value: 'Medium' },
];

const BANNER_STYLES = {
    success: ['var(--green-50)', 'var(--green-200)', 'var(--green-800)', 'var(--green-500)'],
    warn: ['var(--yellow-50)', 'var(--yellow-200)', 'var(--yellow-800)', 'var(--yellow-500)'],
    info: ['var(--blue-50)', 'var(--blue-200)', 'var(--blue-800)', 'var(--blue-500)'],
};

// ── Module-level style consts ─────────────────────────────────────────────────
const dialogStyle = { width: '54rem', maxWidth: '96vw' };
const dialogBreakpoints = { '900px': '90vw', '600px': '98vw' };
const dialogHeaderIconStyle = { fontSize: '1.15rem' };
const loadingSpinnerStyle = { width: 40, height: 40 };
const sectionDividerStyle = { borderBottom: '1px solid var(--surface-border)' };
const sectionIconStyle = { fontSize: '0.82rem' };
const sectionLabelStyle = {
    color: 'var(--text-color-secondary)',
    textTransform: 'uppercase',
    letterSpacing: '0.055em',
};
const fieldLabelStyle = { color: 'var(--text-color-secondary)' };
const fieldHintStyle = { opacity: 0.65 };
const fieldErrorStyle = { fontSize: '0.75rem' };
const fieldErrorIconStyle = { fontSize: '0.7rem' };

const makeBannerIconStyle = (iconColor) => ({
    color: iconColor,
    fontSize: '0.9rem',
    flexShrink: 0,
});
const makeBannerTextStyle = (text) => ({ color: text });

// ─── Helpers ──────────────────────────────────────────────────────────────────
const getToken = () => localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) ?? '';

const EMPTY = {
    complaintNo: '',
    projectCode: '',
    customerCode: '',
    description: '',
    nameOfEmployeeResp: '',
    industryCode: null,
    complaintCategory: null,
    complaintType: null,
    productType: null,
    problemType: null,
    faultClassification: null,
    actionTaken: '',
    problemOrDamageCode: '',
    problemDamageDescription: '',
};

const REQUIRED = [
    'complaintNo',
    'projectCode',
    'customerCode',
    'description',
    'nameOfEmployeeResp',
    'industryCode',
    'faultClassification',
];

export function ComplaintRegistrationDialog({ visible, onHide }) {
    const toast = useRef(null);

    const [form, setForm] = useState(EMPTY);
    const [errors, setErrors] = useState({});
    const [submitting, setSubmitting] = useState(false);

    const [dropdowns, setDropdowns] = useState(null);
    const [ddLoading, setDdLoading] = useState(false);
    const [projects, setProjects] = useState([]);
    const [projLoading, setProjLoading] = useState(false);
    const [customers, setCustomers] = useState([]);
    const [custLoading, setCustLoading] = useState(false);

    const [resolvedPs, setResolvedPs] = useState(null);
    const [resolvedCity, setResolvedCity] = useState('');

    useEffect(() => {
        if (!visible) return;

        setForm(EMPTY);

        if (dropdowns && projects.length > 0) return;

        setDdLoading(true);
        setProjLoading(true);

        Promise.all([
            apiRequest({
                method: 'GET',
                service: 'irs',
                endpoint: '/complaint/form/dropdowns',
                useGateway: true,
                headers: { Authorization: `Bearer ${getToken()}` },
            }),
            apiRequest({
                method: 'GET',
                service: 'irs',
                endpoint: '/complaint/form/projects',
                useGateway: true,
                headers: { Authorization: `Bearer ${getToken()}` },
            }),
        ])
            .then(([dd, projs]) => {
                setDropdowns(dd ?? {});
                setProjects(projs ?? []);
            })
            .catch(() =>
                toast.current?.show({
                    severity: 'warn',
                    summary: 'Warning',
                    detail: 'Could not load some options from server',
                }),
            )
            .finally(() => {
                setDdLoading(false);
                setProjLoading(false);
            });
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [visible]);

    const onProjectChange = useCallback((code) => {
        setForm((f) => ({ ...f, projectCode: code, customerCode: '' }));
        setErrors((e) => ({ ...e, projectCode: null, customerCode: null }));
        setCustomers([]);
        setResolvedPs(null);
        setResolvedCity('');

        if (!code) return;

        setCustLoading(true);
        apiRequest({
            method: 'GET',
            service: 'irs',
            endpoint: `/complaint/form/customers?projectCode=${encodeURIComponent(code)}`,
            useGateway: true,
            headers: { Authorization: `Bearer ${getToken()}` },
        })
            .then((d) => setCustomers(d ?? []))
            .catch(() => setCustomers([]))
            .finally(() => setCustLoading(false));
    }, []);

    const onCustomerChange = useCallback(
        (code) => {
            const c = customers.find((x) => x.customerCode === code);
            setForm((f) => ({ ...f, customerCode: code }));
            setResolvedCity(c?.city ?? '');
            setResolvedPs(c?.psId ? { id: c.psId, name: c.psName } : null);
            setErrors((e) => ({ ...e, customerCode: null }));
        },
        [customers],
    );

    const set = useCallback((field, val) => {
        setForm((f) => ({ ...f, [field]: val }));
        setErrors((e) => ({ ...e, [field]: null }));
    }, []);

    // ── Stable per-field handlers ─────────────────────────────────────────────
    const onComplaintNoChange = useCallback((e) => set('complaintNo', e.target.value), [set]);
    const onFaultClassificationChange = useCallback(
        (e) => set('faultClassification', e.value),
        [set],
    );
    const onProjectDropdownChange = useCallback((e) => onProjectChange(e.value), [onProjectChange]);
    const onCustomerDropdownChange = useCallback(
        (e) => onCustomerChange(e.value),
        [onCustomerChange],
    );
    const onDescriptionChange = useCallback((e) => set('description', e.target.value), [set]);
    const onIndustryChange = useCallback((e) => set('industryCode', e.value), [set]);
    const onComplaintCategoryChange = useCallback((e) => set('complaintCategory', e.value), [set]);
    const onComplaintTypeChange = useCallback((e) => set('complaintType', e.value), [set]);
    const onProductTypeChange = useCallback((e) => set('productType', e.value), [set]);
    const onProblemTypeChange = useCallback((e) => set('problemType', e.value), [set]);
    const onProblemOrDamageCodeChange = useCallback(
        (e) => set('problemOrDamageCode', e.target.value),
        [set],
    );
    const onProblemDamageDescChange = useCallback(
        (e) => set('problemDamageDescription', e.target.value),
        [set],
    );
    const onNameOfEmployeeRespChange = useCallback(
        (e) => set('nameOfEmployeeResp', e.target.value),
        [set],
    );
    const onActionTakenChange = useCallback((e) => set('actionTaken', e.target.value), [set]);

    // ── Validation ────────────────────────────────────────────────────────────
    const validate = useCallback(() => {
        const errs = {};
        REQUIRED.forEach((k) => {
            const v = form[k];
            if (v === null || v === undefined || (typeof v === 'string' && !v.trim())) {
                errs[k] = 'Required';
            }
        });

        if (form.complaintNo) {
            const n = Number(form.complaintNo);
            if (!Number.isInteger(n) || n <= 0) {
                errs.complaintNo = 'Must be a positive integer';
            }
        }

        setErrors(errs);
        return Object.keys(errs).length === 0;
    }, [form]);

    const doClose = useCallback(() => {
        setForm(EMPTY);
        setErrors({});
        setCustomers([]);
        setResolvedPs(null);
        setResolvedCity('');
        onHide();
    }, [onHide]);

    // ── Submit ────────────────────────────────────────────────────────────────
    const handleSubmit = useCallback(async () => {
        if (!validate()) {
            toast.current?.show({
                severity: 'error',
                summary: 'Validation Failed',
                detail: 'Fill in all required fields marked with *',
            });
            return;
        }

        const token = getToken();

        setSubmitting(true);
        try {
            const res = await apiRequest({
                method: 'POST',
                service: 'irs',
                endpoint: '/complaint/register',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${token}`,
                    'X-User-Id': form.nameOfEmployeeResp.trim(),
                },
                body: {
                    requestInfo: { authToken: token },
                    complaintNo: Number(form.complaintNo),
                    projectCode: form.projectCode.trim(),
                    customerCode: form.customerCode,
                    description: form.description.trim(),
                    nameOfEmployeeResp: form.nameOfEmployeeResp.trim(),
                    industryCode: form.industryCode,
                    complaintCategory: form.complaintCategory || undefined,
                    complaintType: form.complaintType || undefined,
                    productType: form.productType || undefined,
                    problemType: form.problemType || undefined,
                    faultClassification: form.faultClassification, // Now always sent as it's required
                    actionTaken: form.actionTaken?.trim() || undefined,
                    problemOrDamageCode: form.problemOrDamageCode?.trim() || undefined,
                    problemDamageDescription: form.problemDamageDescription?.trim() || undefined,
                },
            });

            if (res?.success) {
                toast.current?.show({
                    severity: 'success',
                    summary: 'Complaint Registered',
                    detail: res.message ?? `Complaint #${res.complaintNo} created successfully`,
                    life: 4000,
                });
                res.warnings?.forEach((w) =>
                    toast.current?.show({
                        severity: 'warn',
                        summary: 'Note',
                        detail: w,
                        life: 7000,
                    }),
                );
                setTimeout(() => {
                    doClose();
                    window.location.reload();
                }, 700);
            } else {
                (res?.errors ?? ['Registration failed']).forEach((msg) =>
                    toast.current?.show({ severity: 'error', summary: 'Error', detail: msg }),
                );
            }
        } catch (err) {
            toast.current?.show({
                severity: 'error',
                summary: 'Server Error',
                detail: err?.message || 'Failed to register complaint. Please try again.',
            });
        } finally {
            setSubmitting(false);
        }
    }, [form, validate, doClose]);

    const toOpts = useCallback((arr) => (arr ?? []).map((v) => ({ label: v, value: v })), []);

    const projOpts = useMemo(
        () =>
            projects.map((p) => ({
                label: p.projectName ? `${p.projectCode} — ${p.projectName}` : p.projectCode,
                value: p.projectCode,
            })),
        [projects],
    );

    const custOpts = useMemo(
        () =>
            customers.map((c) => ({
                label: c.customerName ? `${c.customerCode} — ${c.customerName}` : c.customerCode,
                value: c.customerCode,
            })),
        [customers],
    );

    const customerPlaceholder = !form.projectCode
        ? 'Select a project first'
        : custLoading
          ? 'Loading…'
          : 'Select customer';

    const footer = (
        <div className="flex justify-content-end gap-2 pt-1">
            <Button
                label="Cancel"
                icon="pi pi-times"
                outlined
                severity="secondary"
                onClick={doClose}
                disabled={submitting}
            />
            <Button
                label={submitting ? 'Registering…' : 'Register Complaint'}
                icon={submitting ? 'pi pi-spin pi-spinner' : 'pi pi-check'}
                onClick={handleSubmit}
                disabled={submitting || ddLoading}
            />
        </div>
    );

    return (
        <>
            <Toast ref={toast} position="top-right" />

            <Dialog
                visible={visible}
                onHide={doClose}
                header={
                    <div className="flex align-items-center gap-2">
                        <i className="pi pi-file-plus text-primary" style={dialogHeaderIconStyle} />
                        <span className="font-semibold text-lg">Register Complaint</span>
                    </div>
                }
                footer={footer}
                style={dialogStyle}
                breakpoints={dialogBreakpoints}
                modal
                draggable={false}
                resizable={false}
                closeOnEscape={!submitting}
                dismissableMask={!submitting}
            >
                {ddLoading || projLoading ? (
                    <div className="flex flex-column align-items-center justify-content-center py-7 gap-3">
                        <ProgressSpinner style={loadingSpinnerStyle} />
                        <span className="text-color-secondary text-sm">Loading form data…</span>
                    </div>
                ) : (
                    <div className="p-fluid">
                        {/* Complaint Identity */}
                        <Sec label="Complaint Identity" icon="pi-tag" />
                        <div className="formgrid grid">
                            <Fld label="Complaint Number" req err={errors.complaintNo} col={6}>
                                <InputText
                                    value={form.complaintNo}
                                    onChange={onComplaintNoChange}
                                    placeholder="e.g. 5042905"
                                    keyfilter="int"
                                    className={errors.complaintNo ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld
                                label="Fault Classification"
                                req
                                err={errors.faultClassification}
                                col={6}
                            >
                                <Dropdown
                                    value={form.faultClassification}
                                    options={FAULT_OPTIONS}
                                    onChange={onFaultClassificationChange}
                                    placeholder="Select severity"
                                    className={errors.faultClassification ? 'p-invalid' : ''}
                                    showClear
                                />
                            </Fld>
                        </div>

                        {/* Project & Customer */}
                        <Sec label="Project & Customer" icon="pi-sitemap" />
                        <div className="formgrid grid">
                            <Fld label="Project Code" req err={errors.projectCode} col={6}>
                                <Dropdown
                                    value={form.projectCode}
                                    options={projOpts}
                                    onChange={onProjectDropdownChange}
                                    filter
                                    filterPlaceholder="Search project…"
                                    placeholder={projLoading ? 'Loading…' : 'Select project'}
                                    loading={projLoading}
                                    className={errors.projectCode ? 'p-invalid' : ''}
                                    showClear
                                    emptyMessage="No projects found"
                                />
                            </Fld>
                            <Fld label="Customer" req err={errors.customerCode} col={6}>
                                <Dropdown
                                    value={form.customerCode}
                                    options={custOpts}
                                    onChange={onCustomerDropdownChange}
                                    placeholder={customerPlaceholder}
                                    disabled={!form.projectCode || custLoading}
                                    loading={custLoading}
                                    className={errors.customerCode ? 'p-invalid' : ''}
                                    showClear
                                    emptyMessage="No customers for this project"
                                />
                            </Fld>
                        </div>

                        {form.customerCode && (
                            <Banner
                                type={resolvedPs ? 'success' : 'warn'}
                                icon={resolvedPs ? 'pi-check-circle' : 'pi-exclamation-triangle'}
                                html={
                                    resolvedPs
                                        ? `<b>PS:</b> [${resolvedPs.id}] ${resolvedPs.name ?? '—'}${resolvedCity ? `&nbsp;&nbsp;·&nbsp;&nbsp;<b>City:</b> ${resolvedCity}` : ''}`
                                        : 'No PS mapping found. Complaint will be saved without PS assignment.'
                                }
                            />
                        )}

                        {/* Problem Details */}
                        <Sec label="Problem Details" icon="pi-exclamation-circle" />
                        <div className="formgrid grid">
                            <Fld label="Description" req err={errors.description} col={12}>
                                <InputTextarea
                                    value={form.description}
                                    onChange={onDescriptionChange}
                                    rows={3}
                                    autoResize
                                    placeholder="Describe the complaint clearly…"
                                    className={errors.description ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld label="Industry" req err={errors.industryCode} col={6}>
                                <Dropdown
                                    value={form.industryCode}
                                    options={INDUSTRY_OPTIONS}
                                    onChange={onIndustryChange}
                                    placeholder="Select industry"
                                    className={errors.industryCode ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld label="Complaint Category" col={6}>
                                <Dropdown
                                    value={form.complaintCategory}
                                    options={toOpts(dropdowns?.complaintCategories)}
                                    onChange={onComplaintCategoryChange}
                                    placeholder="Select category"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Complaint Type" col={4}>
                                <Dropdown
                                    value={form.complaintType}
                                    options={toOpts(dropdowns?.complaintTypes)}
                                    onChange={onComplaintTypeChange}
                                    placeholder="Select type"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Product Type" col={4}>
                                <Dropdown
                                    value={form.productType}
                                    options={toOpts(dropdowns?.productTypes)}
                                    onChange={onProductTypeChange}
                                    placeholder="Select product type"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Problem Type" col={4}>
                                <Dropdown
                                    value={form.problemType}
                                    options={toOpts(dropdowns?.problemTypes)}
                                    onChange={onProblemTypeChange}
                                    placeholder="Select problem type"
                                    showClear
                                    emptyMessage="No data yet"
                                />
                            </Fld>
                            <Fld label="Problem / Damage Code" col={6}>
                                <InputText
                                    value={form.problemOrDamageCode}
                                    onChange={onProblemOrDamageCodeChange}
                                    placeholder="e.g. OTHR"
                                />
                            </Fld>
                            <Fld label="Problem / Damage Description" col={6}>
                                <InputText
                                    value={form.problemDamageDescription}
                                    onChange={onProblemDamageDescChange}
                                    placeholder="Brief damage description"
                                />
                            </Fld>
                        </div>

                        {/* Employee & Action */}
                        <Sec label="Employee & Action" icon="pi-user" />
                        <div className="formgrid grid">
                            <Fld
                                label="Employee Responsible"
                                req
                                err={errors.nameOfEmployeeResp}
                                col={6}
                            >
                                <InputText
                                    value={form.nameOfEmployeeResp}
                                    onChange={onNameOfEmployeeRespChange}
                                    placeholder="Enter full name of responsible employee"
                                    className={errors.nameOfEmployeeResp ? 'p-invalid' : ''}
                                />
                            </Fld>
                            <Fld label="Action Taken" col={6}>
                                <InputText
                                    value={form.actionTaken}
                                    onChange={onActionTakenChange}
                                    placeholder="e.g. Replaced spare unit"
                                />
                            </Fld>
                        </div>

                        <Banner
                            type="info"
                            icon="pi-info-circle"
                            html="Status → <b>Complaint Opened</b>&nbsp;&nbsp;·&nbsp;&nbsp;Division → <b>NS (R &amp; FCS)</b>&nbsp;&nbsp;·&nbsp;&nbsp;PS &amp; City resolved automatically."
                        />
                    </div>
                )}
            </Dialog>
        </>
    );
}

ComplaintRegistrationDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
};

// Sub Components
function Sec({ label, icon }) {
    return (
        <div className="flex align-items-center gap-2 mt-4 mb-2 pb-1" style={sectionDividerStyle}>
            <i className={`pi ${icon} text-primary`} style={sectionIconStyle} />
            <span className="text-xs font-semibold" style={sectionLabelStyle}>
                {label}
            </span>
        </div>
    );
}

function Fld({ label, req = false, err = null, hint = null, col = 6, children }) {
    return (
        <div className={`field col-12 md:col-${col}`}>
            <label className="block text-sm font-medium mb-1" style={fieldLabelStyle}>
                {label}
                {req && <span className="text-red-500 ml-1">*</span>}
                {hint && (
                    <span className="ml-2 text-xs font-normal" style={fieldHintStyle}>
                        ({hint})
                    </span>
                )}
            </label>
            {children}
            {err && (
                <small
                    className="p-error flex align-items-center gap-1 mt-1"
                    style={fieldErrorStyle}
                >
                    <i className="pi pi-exclamation-circle" style={fieldErrorIconStyle} />
                    {err}
                </small>
            )}
        </div>
    );
}

function Banner({ type, icon, html }) {
    const [bg, border, text, iconColor] = BANNER_STYLES[type] ?? BANNER_STYLES.info;

    const iconStyle = useMemo(() => makeBannerIconStyle(iconColor), [iconColor]);
    const textStyle = useMemo(() => makeBannerTextStyle(text), [text]);
    const containerStyle = useMemo(
        () => ({
            background: bg,
            border: `1px solid ${border}`,
        }),
        [bg, border],
    );
    const htmlContent = useMemo(() => ({ __html: html }), [html]);

    return (
        <div className="flex align-items-center gap-2 border-round p-3 mb-3" style={containerStyle}>
            <i className={`pi ${icon}`} style={iconStyle} />
            <span className="text-sm" style={textStyle} dangerouslySetInnerHTML={htmlContent} />
        </div>
    );
}

Sec.propTypes = { label: PropTypes.string.isRequired, icon: PropTypes.string.isRequired };
Fld.propTypes = {
    label: PropTypes.string.isRequired,
    req: PropTypes.bool,
    err: PropTypes.string,
    hint: PropTypes.string,
    col: PropTypes.number,
    children: PropTypes.node.isRequired,
};
Banner.propTypes = {
    type: PropTypes.oneOf(['success', 'warn', 'info']).isRequired,
    icon: PropTypes.string.isRequired,
    html: PropTypes.string.isRequired,
};
