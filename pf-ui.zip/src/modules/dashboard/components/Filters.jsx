import React, { useCallback, useState, useMemo, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';

import { MultiSelect } from 'primereact/multiselect';
import { SelectButton } from 'primereact/selectbutton';
import { Button } from 'primereact/button';
import { useAtom } from 'jotai';
import { dashboardFiltersAtom } from '../store/atoms';
import { Calendar } from 'primereact/calendar';

// ─── Constants ────────────────────────────────────────────────────────────────
const ROW_HEIGHT = '3.0rem';
const VIRTUAL_SCROLLER_OPTIONS = { itemSize: 10 };
const CALENDAR_INPUT_STYLE = { height: ROW_HEIGHT };

const FORCE_OPTIONS = [
    { label: 'All', value: 'ALL', icon: '/web/all.svg' },
    { label: 'Army', value: '4', icon: '/web/army.svg' },
    { label: 'Navy', value: '16', icon: '/web/navy.svg' },
    { label: 'Air Force', value: '3', icon: '/web/airforce.svg' },
];

const NUM_BUTTONS = FORCE_OPTIONS.length; // 4

const THRESHOLD_FULL = 100; // >= 100px → full icon + label
const THRESHOLD_MEDIUM = 65; // >= 65px  → smaller icon + smaller label

const ICON_SIZES = {
    full: { All: '1.9rem', Army: '3.8rem', default: '3.5rem' },
    medium: { All: '1.5rem', Army: '2.4rem', default: '2.2rem' },
    icon: { All: '1.3rem', Army: '1.9rem', default: '1.7rem' },
};

const LABEL_FONT_SIZE = {
    full: '1.05rem',
    medium: '0.82rem',
    icon: null, // hidden
};

// Approximates #34568C
const SVG_FILTER_BRAND =
    'brightness(0) saturate(100%) invert(27%) sepia(45%) saturate(650%) hue-rotate(192deg) brightness(90%) contrast(95%)';

const SVG_FILTER_WHITE = 'brightness(0) invert(1)';

// ─── Layout styles ────────────────────────────────────────────────────────────

const ROW_STYLE = {
    display: 'flex',
    flexWrap: 'nowrap',
    alignItems: 'stretch',
    gap: '0.4rem',
    width: '100%',
    minWidth: 0,
};

const FORCE_WRAPPER_STYLE = {
    flex: '1 1 0',
    minWidth: 0,
    display: 'flex',
    overflow: 'hidden',
    borderRadius: '6px',
};

const DROPDOWN_WRAPPER_STYLE = {
    flex: '0 0 auto',
    minWidth: '9rem',
    display: 'flex',
    alignItems: 'stretch',
};

const CALENDAR_WRAPPER_STYLE = {
    flex: '0 0 auto',
    minWidth: '8.5rem',
    display: 'flex',
    alignItems: 'stretch',
};

const FORCE_PT = {
    root: { style: { display: 'flex', width: '100%', height: ROW_HEIGHT } },
    button: {
        style: {
            flex: '1 1 0',
            minWidth: 0,
            height: ROW_HEIGHT,
            padding: 0,
            display: 'flex',
            alignItems: 'center',
            justifyContent: 'center',
            overflow: 'hidden',
        },
    },
};

const FORCE_ITEM_INNER = {
    display: 'flex',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'center',
    gap: '0.3rem',
    padding: '0 0.35rem',
    width: '100%',
    overflow: 'hidden',
};

const GO_BTN_STYLE = { height: ROW_HEIGHT, width: ROW_HEIGHT };

function getDensity(wrapperPx) {
    const perBtn = wrapperPx / NUM_BUTTONS;
    if (perBtn >= THRESHOLD_FULL) return 'full';
    if (perBtn >= THRESHOLD_MEDIUM) return 'medium';
    return 'icon';
}

function resolveIconSize(label, density) {
    const map = ICON_SIZES[density];
    if (label === 'All') return map.All;
    if (label === 'Army') return map.Army;
    return map.default;
}

function buildOptions(density) {
    const fontSize = LABEL_FONT_SIZE[density]; // null = hidden

    return FORCE_OPTIONS.map((opt) => {
        const size = resolveIconSize(opt.label, density);

        const iconBase = {
            flexShrink: 0,
            width: size,
            height: size,
            transition: 'width 0.18s ease, height 0.18s ease, filter 0.15s ease',
        };

        const labelBase = {
            fontWeight: 600,
            whiteSpace: 'nowrap',
            overflow: 'hidden',
            flexShrink: 0,
            lineHeight: 1,
            maxWidth: fontSize ? '8rem' : '0px',
            fontSize: fontSize ?? '0px',
            opacity: fontSize ? 1 : 0,
            transition:
                'max-width 0.18s ease, font-size 0.18s ease, opacity 0.18s ease, color 0.15s ease',
        };

        return {
            ...opt,
            _iconStyle: { ...iconBase, filter: SVG_FILTER_BRAND },
            _iconStyleActive: { ...iconBase, filter: SVG_FILTER_WHITE },
            _labelStyle: { ...labelBase, color: '#34568C' },
            _labelStyleActive: { ...labelBase, color: '#ffffff' },
        };
    });
}

function makeForceItemTemplate(activeForce) {
    const Tmpl = (option) => {
        const isActive = option.value === activeForce;
        return (
            <div style={FORCE_ITEM_INNER}>
                <img
                    src={option.icon}
                    alt={option.label}
                    style={isActive ? option._iconStyleActive : option._iconStyle}
                />
                <span style={isActive ? option._labelStyleActive : option._labelStyle}>
                    {option.label}
                </span>
            </div>
        );
    };
    Tmpl.displayName = 'ForceItemTemplate';
    return Tmpl;
}

const Filters = ({
    locations,
    sbus,
    projects,
    onChange,
    enableDateRange,
    startDate: startProp,
    endDate: endProp,
    onDateChange,
    onGo,
}) => {
    const [filters, setFilters] = useAtom(dashboardFiltersAtom);
    const {
        locations: selectedLocations,
        sbu: selectedSbu,
        project: selectedProject,
        force,
    } = filters;

    const [startDate, setStartDate] = useState(startProp || null);
    const [endDate, setEndDate] = useState(endProp || null);

    const forceWrapperRef = useRef(null);
    const [density, setDensity] = useState('full');

    useEffect(() => {
        const el = forceWrapperRef.current;
        if (!el) return;

        const update = (w) => {
            setDensity((prev) => {
                const next = getDensity(w);
                return next !== prev ? next : prev;
            });
        };

        const ro = new ResizeObserver(([entry]) => update(entry.contentRect.width));
        ro.observe(el);
        update(el.getBoundingClientRect().width); // initial read

        return () => ro.disconnect();
    }, []);

    const enrichedOptions = useMemo(() => buildOptions(density), [density]);

    const forceItemTemplate = useMemo(() => makeForceItemTemplate(force), [force]);

    const locationById = useMemo(() => {
        const m = new Map();
        locations.forEach((l) => m.set(l.id, l));
        return m;
    }, [locations]);

    const locationOptions = useMemo(
        () => (locations ?? []).map((l) => ({ label: l.name, value: l.id, ...l })),
        [locations],
    );

    const sbuOptions = useMemo(
        () => (sbus ?? []).map((s) => ({ label: s.sbu_description, value: s.sbu, ...s })),
        [sbus],
    );

    const projectOptions = useMemo(
        () => (projects ?? []).map((p) => ({ label: p.project_name, value: p.project_name })),
        [projects],
    );

    const selectedValues = useMemo(() => selectedLocations.map((l) => l.id), [selectedLocations]);

    const handleForceChange = useCallback(
        (e) => {
            const value = e.value;
            setFilters((prev) => ({ ...prev, force: value }));
            onChange({
                locations: selectedLocations.map((l) => l.id),
                sbu: selectedSbu,
                project: selectedProject,
                force: value,
            });
        },
        [setFilters, selectedLocations, selectedSbu, selectedProject, onChange],
    );

    const handleLocationChange = useCallback(
        (e) => {
            const ids = e.value;
            const selected = ids.map((id) => locationById.get(id)).filter(Boolean);
            setFilters((prev) => ({ ...prev, locations: selected }));
            onChange({ locations: ids, sbu: selectedSbu, project: selectedProject, force });
        },
        [locationById, setFilters, onChange, selectedSbu, selectedProject, force],
    );

    const handleSbuChange = useCallback(
        (e) => {
            const value = e.value?.[0] ?? null;
            setFilters((prev) => ({ ...prev, sbu: value }));
            onChange({
                locations: selectedLocations.map((l) => l.id),
                sbu: value,
                project: selectedProject,
                force,
            });
        },
        [setFilters, selectedLocations, selectedProject, force, onChange],
    );

    const handleProjectChange = useCallback(
        (e) => {
            const value = e.value?.[0] ?? null;
            setFilters((prev) => ({ ...prev, project: value }));
            onChange({
                locations: selectedLocations.map((l) => l.id),
                sbu: selectedSbu,
                project: value,
                force,
            });
        },
        [setFilters, selectedLocations, selectedSbu, force, onChange],
    );

    const handleStartDate = useCallback(
        (e) => {
            setStartDate(e.value);
            onDateChange?.({ startDate: e.value, endDate });
        },
        [endDate, onDateChange],
    );

    const handleEndDate = useCallback(
        (e) => {
            setEndDate(e.value);
            onDateChange?.({ startDate, endDate: e.value });
        },
        [startDate, onDateChange],
    );

    useEffect(() => {
        onChange({
            locations: selectedLocations.map((l) => l.id),
            sbu: selectedSbu,
            project: selectedProject,
            force,
            ...(enableDateRange && startDate ? { startDate } : {}),
            ...(enableDateRange && endDate ? { endDate } : {}),
        });
    }, [
        selectedLocations,
        selectedSbu,
        selectedProject,
        force,
        startDate,
        endDate,
        enableDateRange,
        onChange,
    ]);

    return (
        <div title="Filters" style={ROW_STYLE} className="pointer-events-auto">
            {/* Force selector — shrinks first; ResizeObserver drives density */}
            <div ref={forceWrapperRef} style={FORCE_WRAPPER_STYLE}>
                <SelectButton
                    id="force-filter"
                    value={force}
                    options={enrichedOptions}
                    optionLabel="label"
                    optionValue="value"
                    onChange={handleForceChange}
                    itemTemplate={forceItemTemplate}
                    pt={FORCE_PT}
                    className="force-select-button w-full"
                />
            </div>

            {/* Location */}
            <div style={DROPDOWN_WRAPPER_STYLE} className="border-round">
                <MultiSelect
                    id="location-filter"
                    value={selectedValues}
                    options={locationOptions}
                    optionLabel="label"
                    optionValue="value"
                    placeholder="Select locations"
                    display="chip"
                    onChange={handleLocationChange}
                    virtualScrollerOptions={VIRTUAL_SCROLLER_OPTIONS}
                    maxSelectedLabels={3}
                    className="w-full"
                />
            </div>

            {/* SBU */}
            <div style={DROPDOWN_WRAPPER_STYLE} className="border-round">
                <MultiSelect
                    id="sbu-filter"
                    value={selectedSbu ? [selectedSbu] : []}
                    options={sbuOptions}
                    optionLabel="label"
                    optionValue="value"
                    placeholder="Select SBUs"
                    display="chip"
                    onChange={handleSbuChange}
                    selectionLimit={1}
                    className="w-full"
                />
            </div>

            {/* Project (conditional) */}
            {projectOptions.length > 0 && (
                <div style={DROPDOWN_WRAPPER_STYLE} className="border-round">
                    <MultiSelect
                        id="project-filter"
                        value={selectedProject ? [selectedProject] : []}
                        options={projectOptions}
                        optionLabel="label"
                        optionValue="value"
                        placeholder="Select Projects"
                        display="chip"
                        onChange={handleProjectChange}
                        selectionLimit={1}
                        filter
                        className="w-full"
                    />
                </div>
            )}

            {/* Date range (conditional) */}
            {enableDateRange && (
                <>
                    <div style={CALENDAR_WRAPPER_STYLE}>
                        <Calendar
                            value={startDate}
                            onChange={handleStartDate}
                            placeholder="Start Date"
                            showIcon
                            dateFormat="dd-mm-yy"
                            className="w-full"
                            inputStyle={CALENDAR_INPUT_STYLE}
                        />
                    </div>
                    <div style={CALENDAR_WRAPPER_STYLE}>
                        <Calendar
                            value={endDate}
                            onChange={handleEndDate}
                            placeholder="End Date"
                            showIcon
                            dateFormat="dd-mm-yy"
                            minDate={startDate}
                            className="w-full"
                            inputStyle={CALENDAR_INPUT_STYLE}
                        />
                    </div>
                    {onGo && (
                        <Button
                            icon="pi pi-play"
                            rounded
                            style={GO_BTN_STYLE}
                            onClick={onGo}
                            aria-label="Refresh dashboard"
                        />
                    )}
                </>
            )}
        </div>
    );
};

Filters.propTypes = {
    locations: PropTypes.array.isRequired,
    sbus: PropTypes.array.isRequired,
    projects: PropTypes.array,
    onChange: PropTypes.func.isRequired,
    enableDateRange: PropTypes.bool,
    startDate: PropTypes.instanceOf(Date),
    endDate: PropTypes.instanceOf(Date),
    onDateChange: PropTypes.func,
    onGo: PropTypes.func,
};

Filters.defaultProps = {
    enableDateRange: false,
};

export { Filters };
