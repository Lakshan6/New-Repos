import React, { useMemo, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { TabView, TabPanel } from 'primereact/tabview';
import { InputText } from 'primereact/inputtext';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

/* ---------------- helpers ---------------- */

const formatDistance = (nearestPs) => {
    if (!nearestPs || !Array.isArray(nearestPs) || nearestPs.length === 0) return '-----';
    const minEntry = nearestPs.reduce((a, b) => (a.distance < b.distance ? a : b));
    const km = (minEntry.distance / 1000).toFixed(1);
    return `${km} km (${minEntry.name || 'PS'})`;
};

/* ---------------- static helpers / styles ---------------- */

const S = {
    dialog: { width: '70vw' },
    tableWrap: { height: '35rem', overflow: 'hidden' },
    tableStyle: { width: '100%' },
};

const DIALOG_HEADER = (
    <div className="flex justify-content-between align-items-center w-full">
        <span className="font-semibold text-lg">Man Management</span>
    </div>
);

const renderDistance = (row) => formatDistance(row.nearestps);
const renderEmailDash = () => '-----';

/* ---------------- component ---------------- */

const ManMgmtDialog = ({ visible, onHide, activeTab, stationedData, moData }) => {
    const [search, setSearch] = useState('');

    const handleSearchChange = useCallback((e) => setSearch(e.target.value), []);

    const filteredStationed = useMemo(() => {
        if (!search) return stationedData;
        return stationedData.filter((row) =>
            row.name?.toLowerCase().includes(search.toLowerCase()),
        );
    }, [stationedData, search]);

    const filteredMO = useMemo(() => {
        if (!search) return moData;
        return moData.filter((row) => row.name?.toLowerCase().includes(search.toLowerCase()));
    }, [moData, search]);

    return (
        <Dialog
            visible={visible}
            header={DIALOG_HEADER}
            onHide={onHide}
            modal
            draggable={false}
            style={S.dialog}
        >
            <div className="flex flex-column gap-3">
                {/* Search */}
                <InputText
                    value={search}
                    onChange={handleSearchChange}
                    placeholder="Search here..."
                    className="w-full"
                />

                {/* Tabs */}
                <TabView activeIndex={activeTab}>
                    {/* Stationed */}
                    <TabPanel header="Personnel stationed">
                        <div className="flex justify-content-end mb-2">
                            {/* <Button
                                icon="pi pi-download"
                                label="Export Excel"
                                size="small"
                                outlined
                                onClick={() => exportToCSV(stationedData, 'personnel_stationed')}
                            /> */}
                        </div>
                        <div style={S.tableWrap}>
                            <DataTable
                                value={filteredStationed}
                                paginator
                                rows={5}
                                stripedRows
                                showGridlines
                                removableSort
                                scrollable
                                scrollHeight="28rem"
                                style={S.tableStyle}
                            >
                                <Column field="name" header="Name" sortable />
                                <Column field="staff_no" header="Staff No" sortable />
                                <Column field="designation" header="Designation" sortable />
                                <Column
                                    field="posting_location"
                                    header="Posting Location"
                                    sortable
                                />
                                <Column field="location" header="Location" sortable />
                                <Column header="Distance" body={renderDistance} />
                                <Column field="mobile_no" header="Phone No" sortable />
                                <Column header="Email ID" body={renderEmailDash} />
                            </DataTable>
                        </div>
                    </TabPanel>

                    {/* MO */}
                    <TabPanel header="Personnel on MO">
                        <div className="flex justify-content-end mb-2">
                            {/* <Button
                                icon="pi pi-download"
                                label="Export Excel"
                                size="small"
                                outlined
                                onClick={() => exportToCSV(moData, 'personnel_on_mo')}
                            /> */}
                        </div>
                        <div style={S.tableWrap}>
                            <DataTable
                                value={filteredMO}
                                paginator
                                rows={5}
                                stripedRows
                                showGridlines
                                removableSort
                                scrollable
                                scrollHeight="28rem"
                                style={S.tableStyle}
                            >
                                <Column field="name" header="Name" sortable />
                                <Column field="staff_no" header="Staff No" sortable />
                                <Column field="designation" header="Designation" sortable />
                                <Column field="current_place" header="Location" sortable />
                                <Column header="Distance" body={renderDistance} />
                                <Column field="mobile_no" header="Phone No" sortable />
                                <Column header="Email ID" body={renderEmailDash} />
                            </DataTable>
                        </div>
                    </TabPanel>
                </TabView>
            </div>
        </Dialog>
    );
};

ManMgmtDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
    activeTab: PropTypes.number.isRequired,
    stationedData: PropTypes.array.isRequired,
    moData: PropTypes.array.isRequired,
};

export { ManMgmtDialog };
