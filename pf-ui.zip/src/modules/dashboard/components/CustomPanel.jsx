import React, { useCallback, useRef } from 'react';
import PropTypes from 'prop-types';
import { Panel } from 'primereact/panel';
import { Menu } from 'primereact/menu';
import { Button } from 'primereact/button';

/* ---------------- component ---------------- */

const CustomPanel = ({
    title,
    menuItems,
    footer,
    toggleable,
    showSettings,
    onSettings,
    headerRight,
    children,
}) => {
    const menuRef = useRef(null);

    const handleMenuToggle = useCallback((event) => {
        menuRef.current?.toggle(event);
    }, []);

    const handleSettingsClick = useCallback(() => {
        onSettings?.();
    }, [onSettings]);

    const headerTemplate = useCallback(
        (options) => (
            <div
                className={`${options.className} flex align-items-center justify-content-between gap-3 bg-primary-50`}
            >
                {/* LEFT */}
                <span className="font-semibold text-base text-primary-700">{title}</span>

                {/* RIGHT */}
                <div className="flex align-items-center gap-2">
                    {/* custom injected UI */}
                    {headerRight &&
                        (typeof headerRight === 'function' ? headerRight(options) : headerRight)}

                    {/* Dropdown menu */}
                    {menuItems?.length > 0 && (
                        <>
                            <Menu model={menuItems} popup ref={menuRef} />
                            <Button
                                icon="pi pi-ellipsis-v"
                                text
                                rounded
                                size="small"
                                onClick={handleMenuToggle}
                            />
                        </>
                    )}

                    {/* Settings button */}
                    {showSettings && (
                        <button
                            onClick={handleSettingsClick}
                            className="p-panel-header-icon p-link mr-1"
                        >
                            <span className="pi pi-cog" />
                        </button>
                    )}

                    {/* Collapse / Expand */}
                    {toggleable && options.togglerElement}
                </div>
            </div>
        ),
        [
            title,
            menuItems,
            toggleable,
            showSettings,
            handleMenuToggle,
            handleSettingsClick,
            headerRight,
        ],
    );

    const footerTemplate = useCallback(
        () =>
            footer ? (
                <div className="flex align-items-center justify-content-between">{footer}</div>
            ) : null,
        [footer],
    );

    return (
        <Panel
            headerTemplate={headerTemplate}
            footerTemplate={footerTemplate}
            toggleable={toggleable}
            className="pointer-events-auto w-full shadow-1"
        >
            {children}
        </Panel>
    );
};

/* ---------------- prop validation ---------------- */

CustomPanel.propTypes = {
    title: PropTypes.string.isRequired,

    menuItems: PropTypes.arrayOf(
        PropTypes.shape({
            label: PropTypes.string.isRequired,
            icon: PropTypes.string,
            command: PropTypes.func,
        }),
    ),

    footer: PropTypes.node,

    toggleable: PropTypes.bool,

    showSettings: PropTypes.bool,

    onSettings: PropTypes.func,

    children: PropTypes.node.isRequired,

    headerRight: PropTypes.oneOfType([PropTypes.node, PropTypes.func]),
};

CustomPanel.defaultProps = {
    menuItems: [],
    footer: null,
    toggleable: false,
    showSettings: false,
    onSettings: null,
    headerRight: null,
};

export { CustomPanel };
