import React, { useMemo, useState, useCallback, useEffect } from 'react';
import { Filters } from './Filters';
import { CustomPanel } from './CustomPanel';
import { ManMgmt } from './ManMgmt';
import { SystemHealthStatus } from './SystemHealthStatus';
import { ContingencyMgmt } from './ContingencyMgmt';
import { ManManagementSettingsDialog } from './ManMgmtSettingsDialog';
import { useSetAtom, useAtomValue, useAtom } from 'jotai';
import { distance, mapPeopleMode } from '../store/atoms';
import { useReadApi } from '@shared/hooks';
import { getReqInfoObj, apiRequest, STORAGE_KEYS } from '@shared/utils'; // fix: removed unused exportToCSV
import { ManMgmtDialog } from './ManMgmtDialog';
import { Tag } from 'primereact/tag';
import '../styles/Overlay.scss';
import PropTypes from 'prop-types';

/* ─── static chip card config ────────────────────────────────────────────── */

const CHIPS_CONFIG = [
    { icon: 'pi pi-clipboard', accent: '#3B82F6', bg: '#EFF6FF' },
    { icon: 'pi pi-clock', accent: '#F59E0B', bg: '#FFFBEB' },
    { icon: 'pi pi-check', accent: '#10B981', bg: '#ECFDF5' },
];

const CHIP_CARD_BASE_STYLE = {
    display: 'flex',
    justifyContent: 'space-between',
    alignItems: 'center',
    padding: '0.85rem 0.75rem',
    borderRadius: '8px',
    background: '#ffffff',
    boxShadow: '0 2px 10px rgba(0,0,0,0.08)',
    border: 'none',
    transition: 'box-shadow 0.2s ease',
};

const CHIP_LABEL_STYLE = {
    fontWeight: 600,
    fontSize: '0.88rem',
    color: '#475569',
};

const CHIP_COUNT_BOX_BASE_STYLE = {
    minWidth: '5rem',
    padding: '0.45rem 0.7rem',
    textAlign: 'center',
    fontWeight: 700,
    fontSize: '1.05rem',
    borderRadius: '6px',
    display: 'inline-block',
    letterSpacing: '0.04em',
};

/* fix: pre-compute per-chip styles at module level so JSX never
   receives a freshly-created object as a prop (react-perf rule) */
const CHIP_CARD_STYLES = CHIPS_CONFIG.map((cfg) => ({
    ...CHIP_CARD_BASE_STYLE,
    borderTop: `3px solid ${cfg.accent}`,
}));

const CHIP_ICON_WRAPPER_STYLE = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.35rem',
};

const CHIP_ICON_STYLES = CHIPS_CONFIG.map((cfg) => ({
    color: cfg.accent,
    fontSize: '0.9rem',
}));

const CHIP_COUNT_STYLES = CHIPS_CONFIG.map((cfg) => ({
    ...CHIP_COUNT_BOX_BASE_STYLE,
    border: `2px solid ${cfg.accent}`,
    color: cfg.accent,
    background: cfg.bg,
}));

/* ─── static CRM header styles ───────────────────────────────────────────── */

const CRM_HEADER_STYLE = {
    display: 'flex',
    alignItems: 'center',
    gap: '0.5rem',
    borderLeft: '3px solid #1E40AF',
    paddingLeft: '0.6rem',
    marginBottom: '0.1rem',
};

const CRM_ICON_STYLE = { color: '#1E40AF', fontSize: '0.95rem' };

const CRM_TITLE_STYLE = { fontSize: '0.95rem', letterSpacing: '0.01em' };

const FILTER_ROW_STYLE = {
    marginLeft: '0.3rem',
    width: 'calc(100% - 0.3rem)',
};

/* ─── SystemHealthHeader ─────────────────────────────────────────────────── */

const SystemHealthHeader = ({ fullOpsData, nonOpsData, restrictedOpsData }) => {
    const fullCount = useMemo(() => fullOpsData?.length ?? 0, [fullOpsData]);
    const nonOpsCount = useMemo(() => nonOpsData?.length ?? 0, [nonOpsData]);
    const resOpsCount = useMemo(() => restrictedOpsData?.length ?? 0, [restrictedOpsData]);

    return (
        <div className="flex align-items-center gap-2">
            <Tag
                value={`Non Ops: ${nonOpsCount}`}
                severity="danger"
                className="text-sm bg-white text-red-600 p-2 border-1"
            />
            <Tag
                value={`Restricted Ops: ${resOpsCount}`}
                severity="warning"
                className="text-sm bg-white text-yellow-600 p-2 border-1"
            />
            <Tag
                value={`Full Ops: ${fullCount}`}
                severity="success"
                className="text-sm bg-white text-teal-700 p-2 border-1"
            />
        </div>
    );
};

/* ─── Overlay ────────────────────────────────────────────────────────────── */

const Overlay = ({ locations = [] }) => {
    const requestInfo = useMemo(() => getReqInfoObj(), []);
    const [showManMgmt, setShowManMgmt] = useState(false);
    const [activeTab, setActiveTab] = useState(0);
    const [showSettings, setShowSettings] = useState(false);
    const [distanceValue, setDistanceValue] = useAtom(distance);
    const setMapPeopleMode = useSetAtom(mapPeopleMode);
    const peopleMode = useAtomValue(mapPeopleMode);

    const [forceSelected, setForceSelected] = useState('ALL');
    const [locationsSelected, setLocationsSelected] = useState([]);
    const [sbuSelected, setSbuSelected] = useState(null);

    const apiBody = useMemo(
        () => ({
            ...requestInfo,
            ...(forceSelected !== 'ALL' ? { toIndustry: forceSelected } : {}),
            ...(locationsSelected.length ? { location: locationsSelected } : {}),
            ...(sbuSelected && sbuSelected !== '' ? { toSbu: sbuSelected } : {}),
        }),
        [requestInfo, forceSelected, locationsSelected, sbuSelected],
    );

    const {
        data: totalCount,
        isLoading: totalLoading,
        refetch: refetchTotal,
    } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Totalcomplaints',
        method: 'POST',
        body: apiBody,
    });

    const {
        data: progressCount,
        isLoading: progressLoading,
        refetch: refetchProgress,
    } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintsinprogress',
        method: 'POST',
        body: apiBody,
    });

    const {
        data: closedCount,
        isLoading: closedLoading,
        refetch: refetchClosed,
    } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintsclosed',
        method: 'POST',
        body: apiBody,
    });

    const {
        data: stationedResponse,
        isLoading: stationedLoading,
        refetch: refetchStationed,
    } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/personalStationedData',
        method: 'POST',
        body: apiBody,
    });

    const {
        data: moResponse,
        isLoading: moLoading,
        refetch: refetchMO,
    } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/moPeopleDetails',
        method: 'POST',
        body: apiBody,
    });

    const { data: fullOpsResponse, refetch: refetchFullOps } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/fullOpsData',
        method: 'POST',
        body: apiBody,
    });
    const { data: nonOpsResponse, refetch: refetchNonOps } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/nonOpsData',
        method: 'POST',
        body: apiBody,
    });
    const { data: restrictedOpsResponse, refetch: refetchRestrictedOps } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/restrictedOpsData',
        method: 'POST',
        body: apiBody,
    });

    const {
        data: contingencyResponse,
        isLoading: contingencyLoading,
        refetch: refetchContingency,
    } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/contigencyData',
        method: 'POST',
        body: apiBody,
    });

    const { data: sbuList } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Filtersbu',
        method: 'POST',
        body: apiBody,
    });

    const stationedCount = useMemo(() => stationedResponse?.data?.length ?? 0, [stationedResponse]);
    const moCount = useMemo(() => moResponse?.data?.length ?? 0, [moResponse]);

    const chips = useMemo(
        () => [
            {
                label: 'Total',
                // fix: optional chaining — totalCount may be undefined before the first response
                value: totalLoading ? '…' : (totalCount?.data?.[0]?.count ?? 0),
            },
            {
                label: 'Pending',
                value: progressLoading ? '…' : (progressCount?.data?.[0]?.count ?? 0),
            },
            {
                label: 'Closed',
                value: closedLoading ? '…' : (closedCount?.data?.[0]?.count ?? 0),
            },
        ],
        [totalCount, progressCount, closedCount, totalLoading, progressLoading, closedLoading],
    );

    const fullOpsData = fullOpsResponse?.data ?? [];
    const nonOpsData = nonOpsResponse?.data ?? [];
    const restrictedOpsData = restrictedOpsResponse?.data ?? [];
    const contingencyData = contingencyResponse?.data ?? [];

    /* ── handlers ── */

    const handleStationedView = useCallback(() => {
        setActiveTab(0);
        setShowManMgmt(true);
    }, []);
    const handleMOView = useCallback(() => {
        setActiveTab(1);
        setShowManMgmt(true);
    }, []);

    const handleStationedPlot = useCallback(() => {
        setMapPeopleMode((prev) => (prev === 'STATIONED' ? null : 'STATIONED'));
    }, [setMapPeopleMode]);

    const handleMOPlot = useCallback(() => {
        setMapPeopleMode((prev) => (prev === 'MO' ? null : 'MO'));
    }, [setMapPeopleMode]);

    // fix: extracted from JSX to avoid react-perf/jsx-no-new-function-as-prop
    const handleHideManMgmt = useCallback(() => setShowManMgmt(false), []);
    const handleCancelSettings = useCallback(() => setShowSettings(false), []);
    const handleSubmitSettings = useCallback(
        (newDistance) => {
            setDistanceValue(newDistance);
            setShowSettings(false);
        },
        [setDistanceValue],
    );

    const handleStationedDownload = useCallback(async () => {
        const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        try {
            const blob = await apiRequest({
                service: 'irs',
                endpoint: '/employee/exportStationed',
                method: 'GET',
                useGateway: true,
                headers: token ? { Authorization: `Bearer ${token}` } : {},
            });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'stationed_personnel.xlsx';
            a.click();
            URL.revokeObjectURL(url);
        } catch (e) {
            console.error('Stationed export failed', e);
        }
    }, []);

    const handleMODownload = useCallback(async () => {
        const token = localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN);
        try {
            const blob = await apiRequest({
                service: 'irs',
                endpoint: '/employee/exportMO',
                method: 'GET',
                useGateway: true,
                headers: token ? { Authorization: `Bearer ${token}` } : {},
            });
            const url = URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = 'mo_personnel.xlsx';
            a.click();
            URL.revokeObjectURL(url);
        } catch (e) {
            console.error('MO export failed', e);
        }
    }, []);

    const onFiltersChange = useCallback((data) => {
        setForceSelected(data.force || 'ALL');
        setLocationsSelected(data.locations || []);
        setSbuSelected(data.sbu || null);
    }, []);

    useEffect(() => {
        refetchTotal();
        refetchProgress();
        refetchClosed();
        refetchStationed();
        refetchMO();
        refetchFullOps();
        refetchNonOps();
        refetchRestrictedOps();
        refetchContingency();
    }, [
        forceSelected,
        locationsSelected,
        sbuSelected,
        refetchClosed,
        refetchContingency,
        refetchFullOps,
        refetchMO,
        refetchNonOps,
        refetchRestrictedOps,
        refetchProgress,
        refetchStationed,
        refetchTotal,
    ]);

    /* ── render ── */

    return (
        <div className="flex flex-column h-full overlay-container">
            {/* ── Filter row ── */}
            <div style={FILTER_ROW_STYLE}>
                <Filters
                    locations={locations ?? []}
                    sbus={sbuList?.data ?? []}
                    projects={[]}
                    onChange={onFiltersChange}
                />
            </div>

            {/* ── Right Panels ── */}
            <div className="flex justify-content-end mt-3 h-full overflow-hidden">
                <div className="card h-full w-6 pointer-events-auto">
                    <div className="custom-scrollpanel w-full h-full">
                        {/* fix: style object moved to module-level constant */}
                        <div style={CRM_HEADER_STYLE}>
                            <i className="pi pi-chart-bar" style={CRM_ICON_STYLE} />
                            <span
                                className="font-semibold text-primary-700"
                                style={CRM_TITLE_STYLE}
                            >
                                Customer Relationship Management
                            </span>
                        </div>

                        <div className="flex flex-column gap-3 align-items-end h-full mt-3">
                            <div className="grid w-full ml-0 mt-0 mr-0">
                                {/* fix: all per-chip styles come from pre-computed arrays — no new objects in JSX */}
                                {chips.map((chip, idx) => (
                                    <div className="col" key={chip.label}>
                                        <div style={CHIP_CARD_STYLES[idx]}>
                                            <div style={CHIP_ICON_WRAPPER_STYLE}>
                                                <i
                                                    className={CHIPS_CONFIG[idx].icon}
                                                    style={CHIP_ICON_STYLES[idx]}
                                                />
                                                <span style={CHIP_LABEL_STYLE}>{chip.label}</span>
                                            </div>
                                            <span style={CHIP_COUNT_STYLES[idx]}>{chip.value}</span>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <CustomPanel title="Man Management" toggleable>
                                <ManMgmt
                                    stationedCount={stationedLoading ? 0 : stationedCount}
                                    moCount={moLoading ? 0 : moCount}
                                    onStationedView={handleStationedView}
                                    onMOView={handleMOView}
                                    onStationedPlot={handleStationedPlot}
                                    onMOPlot={handleMOPlot}
                                    onStationedDownload={handleStationedDownload}
                                    onMODownload={handleMODownload}
                                    activeType={peopleMode}
                                />
                            </CustomPanel>

                            <CustomPanel
                                title="System Health Status"
                                toggleable
                                headerRight={
                                    <SystemHealthHeader
                                        fullOpsData={fullOpsData}
                                        nonOpsData={nonOpsData}
                                        restrictedOpsData={restrictedOpsData}
                                    />
                                }
                            >
                                <SystemHealthStatus
                                    fullOpsData={fullOpsData}
                                    nonOpsData={nonOpsData}
                                    restrictedOpsData={restrictedOpsData}
                                />
                            </CustomPanel>

                            <CustomPanel title="Contingency Management" toggleable>
                                <ContingencyMgmt
                                    data={contingencyData}
                                    loading={contingencyLoading}
                                />
                            </CustomPanel>
                        </div>
                    </div>
                </div>
            </div>

            {/* fix: inline arrow functions replaced with stable useCallback refs */}
            <ManMgmtDialog
                visible={showManMgmt}
                onHide={handleHideManMgmt}
                activeTab={activeTab}
                stationedData={stationedResponse?.data ?? []}
                moData={moResponse?.data ?? []}
            />
            <ManManagementSettingsDialog
                visible={showSettings}
                defaultDistance={distanceValue}
                onCancel={handleCancelSettings}
                onSubmit={handleSubmitSettings}
            />
        </div>
    );
};

Overlay.propTypes = {
    locations: PropTypes.array,
};

SystemHealthHeader.propTypes = {
    fullOpsData: PropTypes.array,
    nonOpsData: PropTypes.array,
    restrictedOpsData: PropTypes.array,
};

export { Overlay };
