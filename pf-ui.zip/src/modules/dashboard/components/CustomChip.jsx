import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { Chip } from 'primereact/chip';

const CustomChip = ({ label, value, valueClassName = '' }) => {
    const template = useMemo(
        () => (
            <div className="flex align-items-center justify-content-between w-full">
                <span className="font-bold">{label}</span>
                <div className="flex align-items-center justify-content-center h-3rem w-3rem bg-primary-50 border-1 border-primary border-round">
                    <span className={`chip-value font-bold ${valueClassName}`}>{value}</span>
                </div>
            </div>
        ),
        [label, value, valueClassName],
    );

    return (
        <Chip
            className="p-3 bg-white border-1 border-300 border-round-xl pointer-events-auto w-full shadow-1"
            template={template}
        />
    );
};

CustomChip.propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
    valueClassName: PropTypes.string,
};

export { CustomChip };
