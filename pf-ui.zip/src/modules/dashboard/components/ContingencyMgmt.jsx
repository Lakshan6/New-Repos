import React, { useMemo, useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Skeleton } from 'primereact/skeleton';
import { InputText } from 'primereact/inputtext';

const CONTINGENCY_TABLE_PT = { wrapper: { style: { height: '30rem' } } };
const CONTINGENCY_TABLE_STYLE = { width: '100%' };

const ContingencyMgmt = ({ data, loading }) => {
    const [search, setSearch] = useState('');

    const handleSearchChange = useCallback((e) => {
        setSearch(e.target.value);
    }, []);

    const filteredData = useMemo(() => {
        if (!search) return data;

        const term = search.toLowerCase();

        return data.filter((row) =>
            [row.staff_no, row.contact_person, row.designation, row.location, row.contact_no]
                .filter(Boolean)
                .join(' ')
                .toLowerCase()
                .includes(term),
        );
    }, [data, search]);

    if (loading) {
        return (
            <div className="flex flex-column gap-2">
                {[...Array(5)].map((_, i) => (
                    <Skeleton key={i} height="2rem" />
                ))}
            </div>
        );
    }

    return (
        <div className="flex flex-column gap-2">
            {/* Search */}
            <InputText
                value={search}
                onChange={handleSearchChange}
                placeholder="Search contingency..."
                className="w-full"
            />

            <DataTable
                value={filteredData}
                paginator
                rows={10}
                rowsPerPageOptions={[10, 15, 20]}
                stripedRows
                showGridlines
                removableSort
                emptyMessage="No contingency data available"
                scrollable
                scrollHeight="30rem"
                style={CONTINGENCY_TABLE_STYLE}
                pt={CONTINGENCY_TABLE_PT}
            >
                <Column field="staff_no" header="Staff No" sortable />
                <Column field="contact_person" header="Contact Person" sortable />
                <Column field="designation" header="Designation" sortable />
                <Column field="location" header="Location" sortable />
                <Column field="contact_no" header="Mobile" sortable />
            </DataTable>
        </div>
    );
};

ContingencyMgmt.propTypes = {
    data: PropTypes.arrayOf(
        PropTypes.shape({
            serial_no: PropTypes.number,
            staff_no: PropTypes.string,
            contact_person: PropTypes.string,
            designation: PropTypes.string,
            location: PropTypes.string,
            contact_no: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
            landline: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        }),
    ).isRequired,
    loading: PropTypes.bool,
};

ContingencyMgmt.defaultProps = {
    loading: false,
};

export { ContingencyMgmt };
