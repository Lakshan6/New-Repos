import React, { useCallback } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { classNames } from 'primereact/utils';
import { Divider } from 'primereact/divider';

// ── Constants ────────────────────────────────────────────────────────────────
const DOWNLOAD_BTN_STYLE = { color: '#0F3E66' };
const TOOLTIP_OPTIONS = { position: 'top' };

// ── Stat Row ────────────────────────────────────────────────────────────────
const StatRow = ({ title, count, onView, onDownload, onSettings }) => {
    const handleClick = useCallback(() => {
        onView();
    }, [onView]);

    const handleKeyDown = useCallback(
        (event) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                onView();
            }
        },
        [onView],
    );

    const handleDownloadClick = useCallback(
        (e) => {
            e.stopPropagation();
            onDownload?.();
        },
        [onDownload],
    );

    const handleSettingsClick = useCallback(
        (e) => {
            e.stopPropagation();
            onSettings?.();
        },
        [onSettings],
    );

    return (
        <div
            className="flex justify-content-between align-items-center cursor-pointer hover:bg-primary-50 p-2 border-round w-full"
            role="button"
            tabIndex={0}
            onClick={handleClick}
            onKeyDown={handleKeyDown}
        >
            <span>{title}</span>

            <div className="flex align-items-center gap-2">
                <span className="font-semibold">{count}</span>

                {onSettings && (
                    <Button
                        icon="pi pi-cog"
                        text
                        rounded
                        size="small"
                        className="p-0 w-2rem h-2rem"
                        tooltip="Settings"
                        tooltipOptions={TOOLTIP_OPTIONS}
                        onClick={handleSettingsClick}
                        aria-label={`Settings ${title}`}
                    />
                )}

                {onDownload && (
                    <Button
                        icon="pi pi-download"
                        text
                        rounded
                        size="small"
                        className="p-0 w-2rem h-2rem"
                        style={DOWNLOAD_BTN_STYLE}
                        tooltip="Download Excel"
                        tooltipOptions={TOOLTIP_OPTIONS}
                        onClick={handleDownloadClick}
                        aria-label={`Download ${title}`}
                    />
                )}
            </div>
        </div>
    );
};

StatRow.propTypes = {
    title: PropTypes.string.isRequired,
    count: PropTypes.number.isRequired,
    onView: PropTypes.func.isRequired,
    onDownload: PropTypes.func,
    onSettings: PropTypes.func,
};

// ── Main Component ───────────────────────────────────────────────────────────
const ManMgmt = ({
    stationedCount,
    moCount,
    activeType,
    onStationedView,
    onMOView,
    onStationedPlot,
    onMOPlot,
    onStationedDownload,
    onMODownload,
    onMOSettings,
}) => {
    return (
        <div className="flex flex-column pointer-events-auto">
            {/* Stationed */}
            <div className="flex align-items-center">
                <Button
                    text
                    className={classNames('w-2rem border-none', {
                        'bg-primary-100': activeType === 'STATIONED',
                    })}
                    onClick={onStationedPlot}
                    aria-label="Plot stationed personnel on map"
                    icon="pi pi-globe"
                />

                <StatRow
                    title="Personnel Stationed"
                    count={stationedCount}
                    onView={onStationedView}
                    onDownload={onStationedDownload}
                />
            </div>

            <Divider className="m-1" />

            {/* MO */}
            <div className="flex align-items-center">
                <Button
                    text
                    className={classNames('w-2rem border-none', {
                        'bg-primary-100': activeType === 'MO',
                    })}
                    onClick={onMOPlot}
                    aria-label="Plot MO personnel on map"
                    icon="pi pi-globe"
                />

                <StatRow
                    title="Personnel on MO"
                    count={moCount}
                    onView={onMOView}
                    onDownload={onMODownload}
                    onSettings={onMOSettings}
                />
            </div>
        </div>
    );
};

// ── PropTypes ────────────────────────────────────────────────────────────────
ManMgmt.propTypes = {
    stationedCount: PropTypes.number.isRequired,
    moCount: PropTypes.number.isRequired,
    activeType: PropTypes.oneOf(['STATIONED', 'MO', null]),
    onStationedView: PropTypes.func.isRequired,
    onMOView: PropTypes.func.isRequired,
    onStationedPlot: PropTypes.func.isRequired,
    onMOPlot: PropTypes.func.isRequired,
    onStationedDownload: PropTypes.func,
    onMODownload: PropTypes.func,
    onMOSettings: PropTypes.func,
};

ManMgmt.defaultProps = {
    activeType: null,
    onMOSettings: null,
};

export { ManMgmt };
