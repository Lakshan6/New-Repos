import React, { useCallback, useState } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { InputNumber } from 'primereact/inputnumber';

const ManManagementSettingsDialog = ({ visible, defaultDistance, onCancel, onSubmit }) => {
    const [distance, setDistance] = useState(defaultDistance);

    const handleSubmit = useCallback(() => {
        onSubmit(distance);
    }, [distance, onSubmit]);

    const handleCancel = useCallback(() => {
        setDistance(defaultDistance);
        onCancel();
    }, [defaultDistance, onCancel]);

    return (
        <Dialog
            visible={visible}
            header="Settings"
            onHide={handleCancel}
            modal
            draggable={false}
            style={{ width: '30rem' }}
        >
            <div className="flex flex-column gap-4">
                <div className="flex flex-column gap-2">
                    <label htmlFor="mo-distance" className="font-medium">
                        Show MO People within Distance (km)
                    </label>

                    <InputNumber
                        id="mo-distance"
                        value={distance}
                        onValueChange={(e) => setDistance(e.value)}
                        showButtons
                        step={10}
                        min={0}
                        inputClassName="w-full"
                        decrementButtonClassName="p-button-text"
                        incrementButtonClassName="p-button-text"
                    />
                </div>

                <div className="flex justify-content-end gap-2">
                    <Button label="Cancel" severity="secondary" onClick={handleCancel} />
                    <Button label="Submit" onClick={handleSubmit} />
                </div>
            </div>
        </Dialog>
    );
};

ManManagementSettingsDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    defaultDistance: PropTypes.number.isRequired,
    onCancel: PropTypes.func.isRequired,
    onSubmit: PropTypes.func.isRequired,
};

export { ManManagementSettingsDialog };
