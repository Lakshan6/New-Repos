import React, { useCallback, useEffect, useMemo, useState } from 'react';
import {
    MapContainer,
    GeoJSON,
    ImageOverlay,
    LayerGroup,
    Marker,
    Tooltip,
    Popup,
    ZoomControl,
} from 'react-leaflet';
import L from 'leaflet';
import 'leaflet/dist/leaflet.css';
import '../styles/Map.scss';
import {
    triggerMgmtMOSearch,
    triggerMgmtStationedSearch,
    mapPeopleMode,
    dashboardFiltersAtom,
    dashboardLocationsAtom,
    setDashboardLocationsAtom,
} from '../store/atoms';
import { useAtomValue, useSetAtom } from 'jotai';
import PropTypes from 'prop-types';
import { useReadApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils';
import locationBlueIcon from '../assets/location-blue.svg';
import locationRedIcon from '../assets/location-red.svg';
import starGreenIcon from '../assets/star-green.svg';
import circleQuarteredIcon from '../assets/circle-quartered.svg';
import blueCircleIcon from '../assets/blue-circle.svg';
import userIcon from '../assets/user.svg';
import backgroundMapImage from '../assets/indiamap1.png';

/* ---------------- constants ---------------- */

const CENTER = [24.618666473529174, 99.73312650385785];
const DEFAULT_ZOOM = 5;

const BASE_IMAGE_BOUNDS = [
    [7.1826999, 64.5597],
    [38.32, 93.345],
];

const GEOJSON_STYLE = {
    color: 'grey',
    weight: 0.5,
    fillOpacity: 0.1,
};

const ICON_MAP = {
    RPSC: blueCircleIcon,
    SNMC: circleQuarteredIcon,
    IACCS: starGreenIcon,
    WFS: locationRedIcon,
    default: locationBlueIcon,
};

const LEGEND_ITEMS = [
    { type: 'RPSC', icon: blueCircleIcon, label: 'RPSC' },
    { type: 'SNMC', icon: circleQuarteredIcon, label: 'SNMC' },
    { type: 'IACCS', icon: starGreenIcon, label: 'IACCS' },
    { type: 'WFS', icon: locationRedIcon, label: 'WFS' },
    { type: 'Other', icon: locationBlueIcon, label: 'Other' },
];

const STATIONED_ICON = L.icon({
    iconUrl: userIcon,
    iconSize: [22, 22],
    className: 'user-icon-stationed',
});

const MO_ICON = L.icon({
    iconUrl: userIcon,
    iconSize: [22, 22],
    className: 'user-icon-mo',
});

/* ---------------- helpers ---------------- */

const createIcon = (url, size, className) =>
    L.icon({
        iconUrl: url,
        iconSize: [size, size],
        className,
    });

/* ---------------- background image ---------------- */

function ScaledBackgroundImage({ scale, hStretch, vStretch, offset }) {
    const bounds = useMemo(() => {
        const [sw, ne] = BASE_IMAGE_BOUNDS;
        const latC = (sw[0] + ne[0]) / 2;
        const lngC = (sw[1] + ne[1]) / 2;

        const latRange = (ne[0] - sw[0]) * scale * vStretch;
        const lngRange = (ne[1] - sw[1]) * scale * hStretch;

        return [
            [latC - latRange / 2 + offset.lat, lngC - lngRange / 2 + offset.lng],
            [latC + latRange / 2 + offset.lat, lngC + lngRange / 2 + offset.lng],
        ];
    }, [scale, hStretch, vStretch, offset]);

    return <ImageOverlay url={backgroundMapImage} bounds={bounds} opacity={1} />;
}

/* ---------------- locations layer ---------------- */

function LocationsLayer({ data, faded }) {
    const selected = useAtomValue(dashboardLocationsAtom);
    const setSelected = useSetAtom(setDashboardLocationsAtom);

    const onClick = useCallback(
        (e) => {
            const point = e.target.options.dataPoint;
            if (!point) return;

            setSelected((prev) => {
                const exists = prev.some((p) => p.id === point.id || p.name === point.name);
                if (exists) {
                    return prev.filter((p) => p.id !== point.id && p.name !== point.name);
                }
                if (prev.length < 7) return [...prev, point];
                return prev;
            });
        },
        [setSelected],
    );

    const handlers = useMemo(() => ({ click: onClick }), [onClick]);

    return (
        <LayerGroup>
            {data?.map((p) => {
                if (
                    typeof p.latitude !== 'number' ||
                    typeof p.longitude !== 'number' ||
                    !isFinite(p.latitude) ||
                    !isFinite(p.longitude)
                )
                    return null;

                const isSelected = selected.some((s) => s.id === p.id);
                const size = isSelected ? 32 : 20;

                const icon = createIcon(ICON_MAP[p.type] ?? ICON_MAP.default, size, 'map-icon');

                return (
                    <Marker
                        key={p.id}
                        position={[p.latitude, p.longitude]}
                        icon={icon}
                        opacity={faded ? 0.2 : 1}
                        eventHandlers={handlers}
                        dataPoint={p}
                    >
                        {p.name && (
                            <Tooltip permanent direction="bottom" className="map-label-tooltip">
                                {p.name}
                            </Tooltip>
                        )}
                    </Marker>
                );
            })}
        </LayerGroup>
    );
}

/* ---------------- MO / Stationed layer ---------------- */
function PeopleLayer({ data, stationed }) {
    const icon = stationed ? STATIONED_ICON : MO_ICON;

    if (!data?.aggregate_count) return null;

    return (
        <LayerGroup>
            {Object.entries(data.aggregate_count).map(([place, info]) => {
                const lat = stationed ? info.ps_lat : info.lat;
                const lng = stationed ? info.ps_long : info.long;
                if (
                    typeof lat !== 'number' ||
                    typeof lng !== 'number' ||
                    !isFinite(lat) ||
                    !isFinite(lng)
                )
                    return null;

                return (
                    <Marker key={place} position={[lat, lng]} icon={icon}>
                        <Tooltip permanent direction="top">
                            {info.count}
                        </Tooltip>
                        <Popup>
                            <div>
                                <strong>{stationed ? 'Stationed' : 'On MO'}</strong>
                                <br />
                                {place}
                                <br />
                                Count: {info.count}
                            </div>
                        </Popup>
                    </Marker>
                );
            })}
        </LayerGroup>
    );
}

function MapLegend({ items }) {
    return (
        <div className="card absolute bottom-0 left-0 z-1 p-3">
            <div className="flex flex-column gap-2">
                {items.map((item) => (
                    <div key={item.type} className="flex align-items-center gap-2 text-sm">
                        <img src={item.icon} alt={item.label} className="h-1rem w-1rem" />
                        <span>{item.label}</span>
                    </div>
                ))}
            </div>
        </div>
    );
}

/* ---------------- reset zoom control ---------------- */

/* ---------------- main map ---------------- */

const Map = ({ locations = [], mapRef }) => {
    const filters = useAtomValue(dashboardFiltersAtom);

    const selectedLocationIds = useMemo(
        () => filters.locations.map((l) => l.id),
        [filters.locations],
    );

    const [fadeLocations, setFadeLocations] = useState(false);

    const triggerMO = useAtomValue(triggerMgmtMOSearch);
    const triggerStationed = useAtomValue(triggerMgmtStationedSearch);
    const peopleMode = useAtomValue(mapPeopleMode);

    const requestInfo = useMemo(() => {
        return {
            ...getReqInfoObj(),
            locations: selectedLocationIds,
            sbu: filters.sbu,
            force: filters.force,
        };
    }, [selectedLocationIds, filters.sbu, filters.force]);

    const { data: mapData } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/geojson',
        method: 'POST',
        body: requestInfo,
    });

    const { data: moData } = useReadApi({
        service: 'dashboard',
        endpoint: triggerMO ? '/_getData/moPeopleDetails' : '',
        method: 'POST',
        body: requestInfo,
    });

    const { data: stationedData } = useReadApi({
        service: 'dashboard',
        endpoint: triggerStationed ? '/_getData/personalStationedData' : '',
        method: 'POST',
        body: requestInfo,
    });

    useEffect(() => {
        setFadeLocations(Boolean(peopleMode));
    }, [peopleMode]);

    return (
        <div
            className="h-full w-full z-0 relative"
            // style={{ height: 'calc(100vh - var(--topbar-height) - 2.5rem)' }}
        >
            <MapContainer
                ref={mapRef}
                center={CENTER}
                zoom={DEFAULT_ZOOM}
                minZoom={3}
                maxZoom={18}
                zoomSnap={0.1}
                zoomDelta={0.1}
                zoomControl={false}
                className="w-full h-full bg-none"
            >
                <ZoomControl position="bottomright" />
                {mapData && <GeoJSON data={mapData} style={GEOJSON_STYLE} />}

                <LocationsLayer data={locations} faded={fadeLocations} />

                {peopleMode === 'STATIONED' && <PeopleLayer data={stationedData} stationed />}

                {peopleMode === 'MO' && <PeopleLayer data={moData} stationed={false} />}
            </MapContainer>

            <MapLegend items={LEGEND_ITEMS} />
        </div>
    );
};

Map.propTypes = {
    locations: PropTypes.array,
    mapRef: PropTypes.object,
};

ScaledBackgroundImage.propTypes = {
    scale: PropTypes.number.isRequired,
    hStretch: PropTypes.number.isRequired,
    vStretch: PropTypes.number.isRequired,
    offset: PropTypes.shape({
        lat: PropTypes.number.isRequired,
        lng: PropTypes.number.isRequired,
    }).isRequired,
};

LocationsLayer.propTypes = {
    faded: PropTypes.bool.isRequired,
    data: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            name: PropTypes.string,
            latitude: PropTypes.number.isRequired,
            longitude: PropTypes.number.isRequired,
            type: PropTypes.string,
        }),
    ),
};

PeopleLayer.propTypes = {
    stationed: PropTypes.bool.isRequired,
    data: PropTypes.shape({
        aggregate_count: PropTypes.objectOf(
            PropTypes.shape({
                lat: PropTypes.number,
                long: PropTypes.number,
                ps_lat: PropTypes.number,
                ps_long: PropTypes.number,
                count: PropTypes.number.isRequired,
            }),
        ),
    }),
};

MapLegend.propTypes = {
    items: PropTypes.arrayOf(
        PropTypes.shape({
            type: PropTypes.string.isRequired,
            icon: PropTypes.string.isRequired,
            label: PropTypes.string.isRequired,
            className: PropTypes.string,
        }),
    ).isRequired,
};

export { Map, CENTER, DEFAULT_ZOOM };
