import ChartDataLabels from 'chartjs-plugin-datalabels';
import { Chart as ChartJS } from 'chart.js';

// Register datalabels plugin globally
ChartJS.register(ChartDataLabels);

// ─── Number formatter (K / M abbreviation for large values) ──────────────────
function formatNumber(val) {
    if (val == null || isNaN(val)) return '';
    if (val >= 1_000_000) return (val / 1_000_000).toFixed(1).replace(/\.0$/, '') + 'M';
    if (val >= 1_000) return (val / 1_000).toFixed(1).replace(/\.0$/, '') + 'K';
    return String(val);
}

// ─── Label truncator — clips long labels to maxLen chars with ellipsis ───────
function truncateLabel(label, maxLen) {
    if (!label) return label;
    const str = String(label);
    return str.length > maxLen ? str.slice(0, maxLen - 1) + '…' : str;
}

// ─── Inherit the project's font so chart text matches the UI ─────────────────
// Chart.js draws on <canvas> and cannot inherit CSS. We read the computed font
// from the document body at module-load time so it picks up whatever font the
// project has already applied (PrimeReact theme, Tailwind base, etc.).
// Falls back to system-ui if the document is not yet available (SSR / tests).
const _bodyFont =
    typeof document !== 'undefined'
        ? getComputedStyle(document.body).fontFamily
        : 'system-ui, sans-serif';

ChartJS.defaults.font.family = _bodyFont;
ChartJS.defaults.font.size = 12;
ChartJS.defaults.color = '#4b5563'; // matches PrimeFlex text-600

// ─── Custom plugin: draw total count in doughnut center ───────────────────────
const centerTextPlugin = {
    id: 'centerText',
    beforeDraw(chart) {
        if (chart.config.type !== 'doughnut') return;
        const dataset = chart.data.datasets[0];
        if (!dataset) return;
        const total = dataset.data.reduce((sum, v) => sum + (v || 0), 0);
        const { top, bottom, left, right } = chart.chartArea;
        const cx = (left + right) / 2;
        const cy = (top + bottom) / 2;
        const { ctx } = chart;
        ctx.save();
        ctx.font = 'bold 1.4rem sans-serif';
        ctx.fillStyle = '#0F3E66';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText(formatNumber(total), cx, cy - 8);
        ctx.font = '0.75rem sans-serif';
        ctx.fillStyle = '#70747c';
        ctx.fillText('Defects', cx, cy + 10);
        ctx.restore();
    },
};
ChartJS.register(centerTextPlugin);

// ─── Custom plugin: native tooltip on axis tick label hover ──────────────────
const axisLabelTooltipPlugin = {
    id: 'axisLabelTooltip',
    afterEvent(chart, args) {
        const event = args.event;
        if (event.type !== 'mousemove') return;
        const canvas = chart.canvas;
        const xScale = chart.scales.x;
        const yScale = chart.scales.y;
        if (!xScale || !yScale) {
            canvas.title = '';
            return;
        }

        const x = event.x;
        const y = event.y;

        // Check x-axis labels (below chart area)
        if (xScale.type === 'category' && y > chart.chartArea.bottom) {
            const ticks = xScale.ticks;
            for (let i = 0; i < ticks.length; i++) {
                const pos = xScale.getPixelForTick(i);
                if (Math.abs(x - pos) < 30) {
                    canvas.title = xScale.getLabelForValue(ticks[i].value);
                    return;
                }
            }
        }

        // Check y-axis labels (left of chart area)
        if (yScale.type === 'category' && x < chart.chartArea.left) {
            const ticks = yScale.ticks;
            for (let i = 0; i < ticks.length; i++) {
                const pos = yScale.getPixelForTick(i);
                if (Math.abs(y - pos) < 15) {
                    canvas.title = yScale.getLabelForValue(ticks[i].value);
                    return;
                }
            }
        }

        canvas.title = '';
    },
};
ChartJS.register(axisLabelTooltipPlugin);

// ─── Colour palette ───────────────────────────────────────────────────────────
const DEFAULT_COLORS = [
    '#499CE4',
    '#97d7eb',
    '#448b84',
    '#F9A825',
    '#ec8482',
    '#7B1FA2',
    '#15568E',
    '#00ACC1',
    '#558B2F',
    '#546E7A',
];

// ─── Datalabels config per chart type ─────────────────────────────────────────
function getDatalabelsConfig(type) {
    if (type === 'doughnut' || type === 'pie') {
        return {
            // Place label outside the arc, past the ring edge
            anchor: 'end',
            align: 'end',
            offset: 1,
            color: '#374151',
            font: { weight: '600', size: 11 },
            formatter: (value, ctx) => {
                const dataset = ctx.chart.data.datasets[0];
                const total = dataset.data.reduce((sum, v) => sum + (v || 0), 0);
                if (total === 0 || !value) return null;
                const pct = ((value / total) * 100).toFixed(1);
                // Suppress label on very small slices to avoid crowding
                return Number(pct) < 4 ? null : `${pct}%`;
            },
            display: (ctx) => {
                const dataset = ctx.chart.data.datasets[0];
                const total = dataset.data.reduce((sum, v) => sum + (v || 0), 0);
                if (total === 0) return false;
                const pct = (ctx.dataset.data[ctx.dataIndex] / total) * 100;
                return pct >= 4;
            },
        };
    }
    if (type === 'bar') {
        return {
            anchor: 'end',
            align: 'end',
            clamp: true, // keep label inside canvas when bar reaches top
            color: '#333',
            font: { weight: 'bold', size: 11 },
            formatter: (value) => (value > 0 ? formatNumber(value) : ''),
        };
    }
    return { display: false };
}

// ─── Public API ───────────────────────────────────────────────────────────────

/**
 * Convert a Carbon-style chart descriptor into a Chart.js config.
 * Legend is always disabled inside options — use getLegendItems() +
 * the ChartLegend component to render a scrollable legend externally.
 */
export function mapCarbonToPrime(chart) {
    if (!chart || !chart.data) return null;

    const isStacked = chart.chartType === 'StackedBar';
    const isGrouped = chart.chartType === 'GroupBar' || isStacked;
    const isHorizontal = chart.chartOptions?.orientation === 'horizontal';

    return isGrouped
        ? buildGrouped(chart, isHorizontal, isStacked)
        : buildSingle(chart, isHorizontal);
}

/**
 * Derive legend items (label + colour) from a mapped Chart.js config so the
 * component can render a custom scrollable legend below each chart.
 *
 * @param {object} chartConfig – result of mapCarbonToPrime()
 * @returns {{ label: string, color: string }[]}
 */
export function getLegendItems(chartConfig) {
    if (!chartConfig) return [];

    const { data } = chartConfig;

    // Grouped / multi-dataset charts → one item per dataset
    if (data.datasets.length > 1) {
        return data.datasets.map((ds) => ({
            label: ds.label ?? '',
            color: Array.isArray(ds.backgroundColor)
                ? ds.backgroundColor[0]
                : (ds.backgroundColor ?? '#999'),
        }));
    }

    // Single-dataset charts → one item per label
    const colors = data.datasets[0]?.backgroundColor;
    return (data.labels ?? []).map((label, i) => ({
        label: String(label),
        color: Array.isArray(colors)
            ? colors[i % colors.length]
            : (colors ?? DEFAULT_COLORS[i % DEFAULT_COLORS.length]),
    }));
}

// ─── Internal builders ────────────────────────────────────────────────────────

function buildSingle(chart, isHorizontal) {
    const bottom = chart.chartOptions?.axes?.bottom;
    const left = chart.chartOptions?.axes?.left;

    const xAxis = isHorizontal ? left : bottom;
    const yAxis = isHorizontal ? bottom : left;

    const xKey = xAxis?.mapsTo || 'group';
    const yKey = yAxis?.mapsTo || 'value';

    let fullLabels = chart.data.map((d) => String(d[xKey] ?? ''));
    let values = chart.data.map((d) => d[yKey] ?? 0);

    const type = mapType(chart.chartType);

    // Downsample line charts to at most 200 points to avoid canvas clutter
    const MAX_LINE_POINTS = 200;
    if (type === 'line' && fullLabels.length > MAX_LINE_POINTS) {
        const step = Math.ceil(fullLabels.length / MAX_LINE_POINTS);
        fullLabels = fullLabels.filter((_, i) => i % step === 0);
        values = values.filter((_, i) => i % step === 0);
    }

    return {
        type,
        data: {
            labels: fullLabels,
            datasets: buildDatasets(type, values, chart.chartType),
        },
        options: buildOptions(chart.chartOptions, type, fullLabels),
    };
}

function buildGrouped(chart, isHorizontal, isStacked = false) {
    const bottom = chart.chartOptions?.axes?.bottom;
    const left = chart.chartOptions?.axes?.left;
    const groupKey = bottom?.mapsTo || 'group';
    const seriesKey = chart.chartOptions?.data?.groupMapsTo || 'key';
    const valueKey = left?.mapsTo || 'value';

    const groups = [...new Set(chart.data.map((d) => d[groupKey]))];
    const series = [...new Set(chart.data.map((d) => d[seriesKey]))];

    const datasets = series.map((s, i) => ({
        label: s,
        backgroundColor: DEFAULT_COLORS[i % DEFAULT_COLORS.length],
        maxBarThickness: 48,
        data: groups.map((g) => {
            const row = chart.data.find((d) => d[groupKey] === g && d[seriesKey] === s);
            return row ? row[valueKey] : 0;
        }),
    }));

    return {
        type: 'bar',
        data: { labels: groups, datasets },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            indexAxis: isHorizontal ? 'y' : 'x',
            plugins: {
                legend: { display: false },
                datalabels: getDatalabelsConfig('bar'),
                tooltip: {
                    callbacks: {
                        // Show full (un-truncated) group label on hover
                        title: (items) => groups[items[0]?.dataIndex] ?? items[0]?.label ?? '',
                    },
                },
            },
            layout: { padding: { top: 28 } },
            scales: {
                x: {
                    stacked: isStacked,
                    title: bottom?.title ? { display: true, text: bottom.title } : undefined,
                    ticks: {
                        maxRotation: 35,
                        minRotation: 0,
                        autoSkip: true,
                        maxTicksLimit: 12,
                        callback: function (value) {
                            if (isHorizontal) return formatNumber(value);
                            return truncateLabel(this.getLabelForValue(value), 14);
                        },
                    },
                },
                y: {
                    stacked: isStacked,
                    title: left?.title ? { display: true, text: left.title } : undefined,
                    ticks: {
                        callback: function (value) {
                            if (!isHorizontal) return formatNumber(value);
                            return truncateLabel(this.getLabelForValue(value), 18);
                        },
                    },
                },
            },
        },
    };
}

function mapType(carbonType) {
    switch (carbonType) {
        case 'donut':
            return 'doughnut';
        case 'pie':
            return 'pie';
        case 'bar':
            return 'bar';
        case 'line':
            return 'line';
        case 'lollipop':
        case 'stacked-bar':
        default:
            return 'bar';
    }
}

function buildDatasets(type, values, carbonType) {
    if (carbonType === 'lollipop') {
        return [
            {
                data: values,
                backgroundColor: values.map((_, i) => DEFAULT_COLORS[i % DEFAULT_COLORS.length]),
                borderRadius: 10,
                barThickness: 10,
            },
        ];
    }
    if (type === 'line') {
        return [
            {
                data: values,
                fill: false,
                tension: 0.4,
                borderColor: DEFAULT_COLORS[0],
                pointBackgroundColor: DEFAULT_COLORS[0],
            },
        ];
    }
    return [{ data: values, backgroundColor: DEFAULT_COLORS, maxBarThickness: 48 }];
}

function buildOptions(carbonOptions = {}, type, fullLabels = []) {
    const bottom = carbonOptions?.axes?.bottom;
    const left = carbonOptions?.axes?.left;
    const isHorizontal = carbonOptions?.orientation === 'horizontal';

    const xScale =
        bottom?.scaleType === 'time'
            ? 'time'
            : bottom?.scaleType === 'labels'
              ? 'category'
              : 'linear';

    const yScale = left?.scaleType === 'labels' ? 'category' : 'linear';

    // Tooltip title shows full original label (before truncation)
    const tooltipCallbacks =
        fullLabels.length > 0
            ? {
                  title: (items) => {
                      const idx = items[0]?.dataIndex ?? 0;
                      return fullLabels[idx] ?? items[0]?.label ?? '';
                  },
              }
            : undefined;

    return {
        responsive: true,
        maintainAspectRatio: false,
        indexAxis: isHorizontal ? 'y' : 'x',
        plugins: {
            legend: { display: false },
            datalabels: getDatalabelsConfig(type),
            ...(tooltipCallbacks && { tooltip: { callbacks: tooltipCallbacks } }),
        },
        scales:
            type === 'bar' || type === 'line'
                ? {
                      x: {
                          type: xScale,
                          // For time scales: show only the date portion, never timestamp
                          ...(xScale === 'time' && {
                              time: {
                                  unit: 'day',
                                  displayFormats: { day: 'dd MMM yyyy' },
                                  tooltipFormat: 'dd MMM yyyy',
                              },
                          }),
                          title: bottom?.title ? { display: true, text: bottom.title } : undefined,
                          ticks: {
                              maxRotation: 45,
                              minRotation: xScale === 'time' ? 45 : 0,
                              autoSkip: true,
                              maxTicksLimit: xScale === 'time' ? 8 : 10,
                              callback: function (value) {
                                  if (isHorizontal) return formatNumber(value);
                                  if (xScale === 'time') return this.getLabelForValue(value);
                                  return truncateLabel(this.getLabelForValue(value), 14);
                              },
                          },
                      },
                      y: {
                          type: yScale,
                          title: left?.title ? { display: true, text: left.title } : undefined,
                          ticks: {
                              callback: function (value) {
                                  if (!isHorizontal) return formatNumber(value);
                                  return truncateLabel(this.getLabelForValue(value), 18);
                              },
                          },
                      },
                  }
                : undefined,
        cutout: type === 'doughnut' ? '68%' : undefined,
        // Reserves canvas-edge inset so datalabels are never clipped by the
        // canvas boundary. Doughnut/pie need extra all-round space for external
        // percentage labels; bar/line only need top padding for above-bar values.
        layout: {
            padding:
                type === 'doughnut' || type === 'pie'
                    ? { top: 30, bottom: 30, left: 40, right: 40 }
                    : { top: 28 },
        },
    };
}
