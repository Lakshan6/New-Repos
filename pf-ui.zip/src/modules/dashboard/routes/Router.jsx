import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';
import DashboardHome from '../screens/DashboardHome';
import { DefectReports } from '../screens/DefectReports';

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.DASHBOARD}
            translationsAtom={translationsAtom}
        >
            <Routes>
                <Route index element={<DashboardHome />} />
                <Route path="/defect-reports" element={<DefectReports />} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
