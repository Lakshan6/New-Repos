import { atom } from 'jotai';
import { selectAtom } from 'jotai/utils';

const translationsAtom = atom({});

const selectedLocationOnMap = atom([]);

const triggerMgmtMOSearch = atom(true);

const triggerMgmtStationedSearch = atom(true);

const distance = atom(100000); // default 100 kms , keep this in sync with backend

const mapPeopleMode = atom(null);

const syncTriggerAtom = atom(0); // increments after each successful sync → topbar re-fetches

const dashboardFiltersAtom = atom({
    locations: [],
    sbu: null,
    project: null,
    force: 'ALL',
    startDate: null,
    endDate: null,
});

const dashboardLocationsAtom = selectAtom(dashboardFiltersAtom, (filters) => filters.locations);

const setDashboardLocationsAtom = atom(null, (get, set, updater) => {
    const prev = get(dashboardFiltersAtom);
    const nextLocations = typeof updater === 'function' ? updater(prev.locations) : updater;

    set(dashboardFiltersAtom, {
        ...prev,
        locations: nextLocations,
    });
});

export {
    translationsAtom,
    selectedLocationOnMap,
    triggerMgmtMOSearch,
    triggerMgmtStationedSearch,
    distance,
    mapPeopleMode,
    dashboardFiltersAtom,
    dashboardLocationsAtom,
    setDashboardLocationsAtom,
    syncTriggerAtom,
};
