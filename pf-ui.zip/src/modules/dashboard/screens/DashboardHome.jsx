import { useCallback, useMemo, useRef } from 'react';
import { Map, DEFAULT_ZOOM, CENTER } from '../components/Map';
import { Overlay } from '../components/Overlay';
import { useReadApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils';

const RESET_BTN_STYLE = {
    position: 'absolute',
    top: '4.5rem',
    right: 'calc(50% + 0.5rem)',
    zIndex: 999,
    width: '2.2rem',
    height: '2.2rem',
    background: '#ffffff',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: 0,
    boxShadow: '0 1px 4px rgba(0,0,0,0.2)',
    transition: 'background 0.15s ease',
    outline: 'none',
};
const RESET_ICON_STYLE = { fontSize: '1.1rem', fontWeight: 700, color: '#1b3a5c' };

const DashboardHome = () => {
    const mapRef = useRef(null);
    const handleResetZoom = useCallback(() => {
        mapRef.current?.setView(CENTER, DEFAULT_ZOOM);
    }, []);
    const requestInfo = useMemo(() => getReqInfoObj(), []);

    const { data: locationsData } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/FileterLocationPsList',
        method: 'POST',
        body: requestInfo,
    });

    if (!locationsData?.data?.length) {
        return null; // or a loader
    }

    return (
        <div className="w-full h-full relative">
            <Map locations={locationsData.data} mapRef={mapRef} />

            <div className="absolute top-0 left-0 w-full h-full pointer-events-none">
                <Overlay locations={locationsData.data} />
            </div>

            <button title="Reset to default zoom" style={RESET_BTN_STYLE} onClick={handleResetZoom}>
                <i className="pi pi-home" style={RESET_ICON_STYLE} />
            </button>
        </div>
    );
};

export default DashboardHome;
