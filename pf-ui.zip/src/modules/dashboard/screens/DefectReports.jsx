import 'chartjs-adapter-date-fns';
import PropTypes from 'prop-types';
import { useMemo, useState, useCallback, useEffect } from 'react';
import { useAtom } from 'jotai';
import { useReadApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils';
import { Chart } from 'primereact/chart';
import { mapCarbonToPrime, getLegendItems } from '../utils/chartAdapter';
import { Filters } from '../components/Filters';
import { dashboardFiltersAtom } from '../store/atoms';

// Fix: removed unused CHART_HEIGHT_WIDE
const CHART_HEIGHT_NARROW = 350;

const metricCardStyle = { border: '1px solid #e5e7eb', borderRadius: '8px', minHeight: '3.5rem' };
const metricCountBoxStyle = {
    minWidth: '6.5rem',
    border: '2px solid #0F3E66',
    borderRadius: '6px',
    background: '#daeaf8',
    color: '#0F3E66',
    letterSpacing: '0.04em',
};

const StyledMetricCard = ({ label, value }) => (
    <div
        className="flex justify-content-between align-items-center px-3 py-3"
        style={metricCardStyle}
    >
        <span className="text-lg font-semibold text-700">{label}</span>
        <span className="text-lg font-bold text-center px-3 py-2" style={metricCountBoxStyle}>
            {value ?? '–'}
        </span>
    </div>
);
StyledMetricCard.propTypes = {
    label: PropTypes.string.isRequired,
    value: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
};

const legendSwatchBaseStyle = {
    width: '0.75rem',
    height: '0.75rem',
    borderRadius: '3px',
    flexShrink: 0,
};

// Fix: useMemo inside component so object identity is stable when color unchanged
const LegendSwatch = ({ color }) => {
    const style = useMemo(() => ({ ...legendSwatchBaseStyle, background: color }), [color]);
    return <span style={style} />;
};
LegendSwatch.propTypes = { color: PropTypes.string };

const legendItemStyle = { flex: '0 1 auto', maxWidth: '8rem' };
const legendLabelStyle = { overflow: 'hidden', textOverflow: 'ellipsis', whiteSpace: 'nowrap' };

const LegendItem = ({ label, color }) => (
    <div className="flex align-items-center gap-1" style={legendItemStyle} title={label}>
        <LegendSwatch color={color} />
        <span className="text-sm text-600" style={legendLabelStyle}>
            {label}
        </span>
    </div>
);
LegendItem.propTypes = { label: PropTypes.string, color: PropTypes.string };

const ChartLegend = ({ items }) => {
    if (!items || items.length === 0) return null;
    return (
        <div className="flex flex-wrap align-items-center gap-2 pt-2">
            {items.map((item, i) => (
                <LegendItem key={i} label={item.label} color={item.color} />
            ))}
        </div>
    );
};
ChartLegend.propTypes = {
    items: PropTypes.arrayOf(PropTypes.shape({ label: PropTypes.string, color: PropTypes.string })),
};

const chartTitleStyle = { marginTop: 0 };
const chartHeightFill = { height: '100%' };
const legendScrollStyle = { maxHeight: '65px', overflowY: 'auto', overflowX: 'hidden' };
const flexOneStyle = { flex: 1 };

const chartCanvasWrapperStyle = (height) => ({
    position: 'relative',
    height: `${height}px`,
    overflow: 'hidden',
});

const ChartCard = ({ title, chartConfig, height, hideLegend }) => {
    const legendItems = useMemo(() => getLegendItems(chartConfig), [chartConfig]);
    const canvasWrapperStyle = useMemo(() => chartCanvasWrapperStyle(height), [height]);
    return (
        <div className="card mb-3 flex flex-column h-full w-full">
            {title && (
                <h5 className="text-base font-semibold text-900 mb-2" style={chartTitleStyle}>
                    {title}
                </h5>
            )}
            {chartConfig && (
                <>
                    <div style={canvasWrapperStyle}>
                        <Chart
                            type={chartConfig.type}
                            data={chartConfig.data}
                            options={chartConfig.options}
                            style={chartHeightFill}
                        />
                    </div>
                    {!hideLegend && (
                        <div style={legendScrollStyle}>
                            <ChartLegend items={legendItems} />
                        </div>
                    )}
                </>
            )}
            <div style={flexOneStyle} />
        </div>
    );
};
ChartCard.propTypes = {
    title: PropTypes.string,
    hideLegend: PropTypes.bool,
    chartConfig: PropTypes.object,
    height: PropTypes.number.isRequired,
};

const DefectReports = () => {
    const requestInfo = useMemo(() => getReqInfoObj(), []);
    const [filters, setFilters] = useAtom(dashboardFiltersAtom);
    const [forceSelected, setForceSelected] = useState('ALL');
    const [locationsSelected, setLocationsSelected] = useState([]);
    const [sbuSelected, setSbuSelected] = useState(null);
    const [projectSelected, setProjectSelected] = useState(null);

    const startDate = filters.startDate;
    const endDate = filters.endDate;
    const setStartDate = useCallback(
        (d) => setFilters((prev) => ({ ...prev, startDate: d })),
        [setFilters],
    );
    const setEndDate = useCallback(
        (d) => setFilters((prev) => ({ ...prev, endDate: d })),
        [setFilters],
    );

    const [committedDates, setCommittedDates] = useState(() => {
        const d = {};
        if (filters.startDate) d.fromDate = filters.startDate.getTime();
        if (filters.endDate) d.toDate = filters.endDate.getTime();
        return d;
    });

    const filterPayload = useMemo(
        () => ({
            ...requestInfo,
            ...(forceSelected !== 'ALL' ? { toIndustry: forceSelected } : {}),
            ...(locationsSelected.length ? { location: locationsSelected } : {}),
            ...(sbuSelected ? { toSbu: sbuSelected } : {}),
            ...(projectSelected ? { toProject: projectSelected } : {}),
            ...committedDates,
        }),
        [
            requestInfo,
            forceSelected,
            locationsSelected,
            sbuSelected,
            projectSelected,
            committedDates,
        ],
    );

    const { data: totalCount, refetch: refetchTotal } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Totalcomplaints',
        method: 'POST',
        body: filterPayload,
    });
    const { data: progressCount, refetch: refetchProgress } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintsinprogress',
        method: 'POST',
        body: filterPayload,
    });
    const { data: closedCount, refetch: refetchClosed } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintsclosed',
        method: 'POST',
        body: filterPayload,
    });
    const { data: avgResolutionTime, refetch: refetchAvgResolution } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Avgresolutiontime',
        method: 'POST',
        body: filterPayload,
    });
    const { data: complaintsByStatus, refetch: refetchComplaintsByStatus } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintbystatus',
        method: 'POST',
        body: filterPayload,
    });
    const { data: complaintsByCloseTime, refetch: refetchComplaintsByCloseTime } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintbyclosertime',
        method: 'POST',
        body: filterPayload,
    });
    const { data: closureTimeNonOps, refetch: refetchClosureNonOps } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/ClosuretimeNonops',
        method: 'POST',
        body: filterPayload,
    });
    const { data: closureTimeRestrictedOps, refetch: refetchClosureRestrictedOps } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/ClosuretimeRestrictedops',
        method: 'POST',
        body: filterPayload,
    });
    const { data: complaintsByProductType, refetch: refetchComplaintsByProductType } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintbyproducttype',
        method: 'POST',
        body: filterPayload,
    });
    const { data: complaintsTimeline, refetch: refetchComplaintsTimeline } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complainttimeline',
        method: 'POST',
        body: filterPayload,
    });
    const { data: topProblemTypes, refetch: refetchTopProblemTypes } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Topproblemtype',
        method: 'POST',
        body: filterPayload,
    });
    const { data: complaintsByProductName, refetch: refetchComplaintsByProductName } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintbyproductname',
        method: 'POST',
        body: filterPayload,
    });
    const { data: complaintsByIndustryType, refetch: refetchComplaintsByIndustryType } = useReadApi(
        {
            service: 'dashboard',
            endpoint: '/_getData/Complaintbyindustrytype',
            method: 'POST',
            body: filterPayload,
        },
    );
    const { data: complaintsBySbu, refetch: refetchComplaintsBySbu } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Complaintbysbu',
        method: 'POST',
        body: filterPayload,
    });
    const { data: openDefectsByAge, refetch: refetchOpenDefectsByAge } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Opendefectsbyage',
        method: 'POST',
        body: filterPayload,
    });
    const { data: locationsData } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/FileterLocationPsList',
        method: 'POST',
        body: filterPayload,
    });
    const { data: sbuList } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Filtersbu',
        method: 'POST',
        body: filterPayload,
    });
    const { data: projectList } = useReadApi({
        service: 'dashboard',
        endpoint: '/_getData/Filterproject',
        method: 'POST',
        body: filterPayload,
    });

    const statusChart = useMemo(() => mapCarbonToPrime(complaintsByStatus), [complaintsByStatus]);
    const productTypeChart = useMemo(
        () => mapCarbonToPrime(complaintsByProductType),
        [complaintsByProductType],
    );
    const sbuChart = useMemo(() => mapCarbonToPrime(complaintsBySbu), [complaintsBySbu]);
    const closeTimeChart = useMemo(
        () => mapCarbonToPrime(complaintsByCloseTime),
        [complaintsByCloseTime],
    );
    const nonOpsCloseChart = useMemo(
        () => mapCarbonToPrime(closureTimeNonOps),
        [closureTimeNonOps],
    );
    const restrictedOpsCloseChart = useMemo(
        () => mapCarbonToPrime(closureTimeRestrictedOps),
        [closureTimeRestrictedOps],
    );
    const timelineChart = useMemo(() => mapCarbonToPrime(complaintsTimeline), [complaintsTimeline]);
    const topProblemsChart = useMemo(() => mapCarbonToPrime(topProblemTypes), [topProblemTypes]);
    const productNameChart = useMemo(
        () => mapCarbonToPrime(complaintsByProductName),
        [complaintsByProductName],
    );
    const industryTypeChart = useMemo(
        () => mapCarbonToPrime(complaintsByIndustryType),
        [complaintsByIndustryType],
    );
    const openDefectsByAgeChart = useMemo(() => {
        const cfg = mapCarbonToPrime(openDefectsByAge);
        if (cfg?.options?.plugins) cfg.options.plugins.datalabels = { display: false };
        return cfg;
    }, [openDefectsByAge]);

    useEffect(() => {
        refetchTotal();
        refetchProgress();
        refetchClosed();
        refetchAvgResolution();
        refetchComplaintsByCloseTime();
        refetchClosureNonOps();
        refetchClosureRestrictedOps();
        refetchComplaintsByIndustryType();
        refetchComplaintsByProductName();
        refetchComplaintsByProductType();
        refetchComplaintsBySbu();
        refetchComplaintsByStatus();
        refetchComplaintsTimeline();
        refetchOpenDefectsByAge();
        refetchTopProblemTypes();
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [forceSelected, locationsSelected, sbuSelected, projectSelected]);

    const handleGo = useCallback(() => {
        const newDates = {};
        if (startDate) newDates.fromDate = startDate.getTime();
        if (endDate) newDates.toDate = endDate.getTime();
        setCommittedDates(newDates);
    }, [startDate, endDate]);

    const onFiltersChange = useCallback(
        (data) => {
            setForceSelected(data.force || 'ALL');
            setLocationsSelected(data.locations || []);
            setSbuSelected(data.sbu || null);
            setProjectSelected(data.project || null);
            if ('startDate' in data) setStartDate(data.startDate || null);
            if ('endDate' in data) setEndDate(data.endDate || null);
        },
        [setStartDate, setEndDate],
    );

    return (
        <div className="">
            {locationsData?.data?.length && (
                <div className="w-full mb-3">
                    <Filters
                        locations={locationsData?.data ?? []}
                        sbus={sbuList?.data ?? []}
                        projects={projectList?.data ?? []}
                        enableDateRange
                        startDate={startDate}
                        endDate={endDate}
                        onChange={onFiltersChange}
                        onGo={handleGo}
                    />
                </div>
            )}
            <div className="grid overflow-hidden">
                <div className="col-12 lg:col-6 xl:col-3">
                    <StyledMetricCard label="Total Defects" value={totalCount?.data[0]?.count} />
                </div>
                <div className="col-12 lg:col-6 xl:col-3">
                    <StyledMetricCard
                        label="Defects Pending"
                        value={progressCount?.data[0]?.count}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-3">
                    <StyledMetricCard label="Defects Closed" value={closedCount?.data[0]?.count} />
                </div>
                <div className="col-12 lg:col-6 xl:col-3">
                    <StyledMetricCard
                        label="Avg Resolution Time (Days)"
                        value={avgResolutionTime?.data[0]?.count}
                    />
                </div>

                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsByStatus?.chartName}
                        chartConfig={statusChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={openDefectsByAge?.chartName}
                        chartConfig={openDefectsByAgeChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsByProductName?.chartName}
                        chartConfig={productNameChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>

                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={closureTimeNonOps?.chartName}
                        chartConfig={nonOpsCloseChart}
                        height={CHART_HEIGHT_NARROW}
                        hideLegend
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsByCloseTime?.chartName}
                        chartConfig={closeTimeChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={closureTimeRestrictedOps?.chartName}
                        chartConfig={restrictedOpsCloseChart}
                        height={CHART_HEIGHT_NARROW}
                        hideLegend
                    />
                </div>

                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={topProblemTypes?.chartName}
                        chartConfig={topProblemsChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsByIndustryType?.chartName}
                        chartConfig={industryTypeChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsByProductType?.chartName}
                        chartConfig={productTypeChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>

                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsBySbu?.chartName}
                        chartConfig={sbuChart}
                        height={CHART_HEIGHT_NARROW}
                    />
                </div>
                <div className="col-12 lg:col-6 xl:col-4 flex">
                    <ChartCard
                        title={complaintsTimeline?.chartName}
                        chartConfig={timelineChart}
                        height={CHART_HEIGHT_NARROW}
                        hideLegend
                    />
                </div>
            </div>
        </div>
    );
};

export { DefectReports };
