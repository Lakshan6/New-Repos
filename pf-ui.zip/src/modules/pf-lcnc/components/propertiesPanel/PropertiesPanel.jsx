import React from 'react';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Checkbox } from 'primereact/checkbox';
import { Divider } from 'primereact/divider';
import { Card } from 'primereact/card';

// Field type options
const fieldTypeOptions = [
    { label: 'Short Text', value: 'text', icon: 'pi pi-file' },
    { label: 'Long Text', value: 'textarea', icon: 'pi pi-align-left' },
    { label: 'Number', value: 'number', icon: 'pi pi-hashtag' },
    { label: 'Integer', value: 'int', icon: 'pi pi-hashtag' },
    { label: 'Currency', value: 'currency', icon: 'pi pi-dollar' },
    { label: 'Checkbox', value: 'checkbox', icon: 'pi pi-check-square' },
    { label: 'Date', value: 'date', icon: 'pi pi-calendar' },
    { label: 'Date & Time', value: 'datetime', icon: 'pi pi-clock' },
    { label: 'Dropdown', value: 'select', icon: 'pi pi-angle-down' },
    { label: 'Link', value: 'link', icon: 'pi pi-link' },
    { label: 'Radio Button', value: 'radio', icon: 'pi pi-circle' },
    { label: 'Button', value: 'button', icon: 'pi pi-box' },
    { label: 'Table', value: 'table', icon: 'pi pi-table' },
];

// Field types that support text input validation
const TEXT_INPUT_FIELD_TYPES = ['text', 'textarea'];

// ============================================================
// TAB PROPERTIES PANEL
// ============================================================
const TabProperties = ({ tab, onUpdate }) => {
    if (!tab) return null;

    return (
        <div className="flex flex-column gap-4">
            <div className="flex align-items-center gap-2 mb-2">
                <h4 className="m-0 text-lg font-semibold">Tab Properties</h4>
            </div>

            {/* Tab Label */}
            <div className="flex flex-column gap-2">
                <label htmlFor="tab-label" className="text-sm font-medium">
                    Label
                </label>
                <InputText
                    id="tab-label"
                    value={tab.label || ''}
                    onChange={(e) => onUpdate({ label: e.target.value })}
                    placeholder="Enter tab label"
                    className="w-full"
                />
            </div>

            {/* Tab Fieldname */}
            <div className="flex flex-column gap-2">
                <label htmlFor="tab-fieldname" className="text-sm font-medium">
                    Fieldname
                </label>
                <InputText
                    id="tab-fieldname"
                    value={tab.name || ''}
                    onChange={(e) => onUpdate({ name: e.target.value })}
                    placeholder="Enter tab fieldname"
                    className="w-full"
                />
                <small className="text-color-secondary">Used internally for identification</small>
            </div>

            {/* Tab Statistics */}
            <Card className="mt-3 surface-100 border-1 surface-border">
                <h5 className="text-sm font-semibold mb-3 text-color">Tab Statistics</h5>
                <div className="flex flex-column gap-2">
                    <div className="flex justify-content-between align-items-center">
                        <span className="text-sm text-color-secondary">Sections:</span>
                        <span className="text-sm font-medium">{tab.sections?.length || 0}</span>
                    </div>
                    <div className="flex justify-content-between align-items-center">
                        <span className="text-sm text-color-secondary">Total Fields:</span>
                        <span className="text-sm font-medium">
                            {tab.sections?.reduce(
                                (acc, sec) => acc + (sec.fields?.length || 0),
                                0,
                            ) || 0}
                        </span>
                    </div>
                </div>
            </Card>

            {/* Tip */}
            <div className="mt-3 p-3 bg-blue-50 border-round border-1 border-blue-200">
                <p className="text-xs text-blue-700 m-0">
                    <i className="pi pi-info-circle mr-2" />
                    Double-click the tab label in the header to rename it inline.
                </p>
            </div>
        </div>
    );
};

// ============================================================
// SECTION PROPERTIES PANEL
// ============================================================
const SectionProperties = ({ section, onUpdate }) => {
    if (!section) return null;

    return (
        <div className="flex flex-column gap-4">
            <div className="flex align-items-center gap-2 mb-2">
                <h4 className="m-0 text-lg font-semibold">Section Properties</h4>
            </div>

            {/* Section Label */}
            <div className="flex flex-column gap-2">
                <label htmlFor="section-label" className="text-sm font-medium">
                    Label
                </label>
                <InputText
                    id="section-label"
                    value={section.label || ''}
                    onChange={(e) => onUpdate({ label: e.target.value })}
                    placeholder="Enter section label"
                    className="w-full"
                />
            </div>

            {/* Section Fieldname */}
            <div className="flex flex-column gap-2">
                <label htmlFor="section-fieldname" className="text-sm font-medium">
                    Fieldname
                </label>
                <InputText
                    id="section-fieldname"
                    value={section.name || ''}
                    onChange={(e) => onUpdate({ name: e.target.value })}
                    placeholder="Enter section fieldname"
                    className="w-full"
                />
                <small className="text-color-secondary">Used internally for identification</small>
            </div>

            {/* Section Statistics */}
            <Card className="mt-3 surface-100 border-1 surface-border">
                <h5 className="text-sm font-semibold mb-3 text-color">Section Statistics</h5>
                <div className="flex justify-content-between align-items-center">
                    <span className="text-sm text-color-secondary">Fields:</span>
                    <span className="text-sm font-medium">{section.fields?.length || 0}</span>
                </div>
            </Card>

            {/* Tip */}
            <div className="mt-3 p-3 bg-blue-50 border-round border-1 border-blue-200">
                <p className="text-xs text-blue-700 m-0">
                    <i className="pi pi-info-circle mr-2" />
                    Double-click the section header to rename it inline.
                </p>
            </div>
        </div>
    );
};

// ============================================================
// FIELD PROPERTIES PANEL
// ============================================================
const FieldProperties = ({ field, onUpdate, availableDoctypes, doctypeFieldsMap }) => {
    if (!field) return null;

    // Check if this field type supports text input validation
    const isTextInputField = TEXT_INPUT_FIELD_TYPES.includes(field.type);

    // Custom item template with icon
    const fieldTypeItemTemplate = (option) => (
        <div className="flex align-items-center gap-2">
            <i className={`${option.icon} text-color-secondary`} />
            <span>{option.label}</span>
        </div>
    );

    // Value template (selected value display)
    const fieldTypeValueTemplate = (option) => {
        if (!option) return <span>Select Type</span>;
        return (
            <div className="flex align-items-center gap-2">
                <i className={`${option.icon} text-color-secondary`} />
                <span>{option.label}</span>
            </div>
        );
    };

    // Handle textarea keydown to allow Enter for new lines
    const handleTextareaKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.stopPropagation();
        }
    };

    return (
        <div className="flex flex-column gap-4">
            <div className="flex align-items-center gap-2 mb-2">
                <h4 className="m-0 text-lg font-semibold">Field Properties</h4>
            </div>

            {/* Field Type */}
            <div className="flex flex-column gap-2">
                <label htmlFor="field-type" className="text-sm font-medium">
                    Field Type
                </label>
                <Dropdown
                    inputId="field-type"
                    value={field.type}
                    options={fieldTypeOptions}
                    onChange={(e) => onUpdate({ type: e.value })}
                    optionLabel="label"
                    optionValue="value"
                    itemTemplate={fieldTypeItemTemplate}
                    valueTemplate={fieldTypeValueTemplate}
                    placeholder="Select Type"
                    className="w-full"
                />
            </div>

            {/* Label */}
            <div className="flex flex-column gap-2">
                <label htmlFor="field-label" className="text-sm font-medium">
                    Label
                </label>
                <InputText
                    id="field-label"
                    value={field.label || ''}
                    onChange={(e) => onUpdate({ label: e.target.value })}
                    placeholder="Enter field label"
                    className="w-full"
                />
            </div>

            {/* Fieldname */}
            <div className="flex flex-column gap-2">
                <label htmlFor="field-fieldname" className="text-sm font-medium">
                    Fieldname
                </label>
                <InputText
                    id="field-fieldname"
                    value={field.fieldname || ''}
                    onChange={(e) => onUpdate({ fieldname: e.target.value })}
                    placeholder="Enter fieldname"
                    className="w-full"
                />
            </div>

            {/* ForeignReference (only for 'link' type) */}
            {field.type === 'link' && (
                <>
                    <div className="flex flex-column gap-2">
                        <label htmlFor="foreign-reference" className="text-sm font-medium">
                            ForeignReference
                        </label>
                        <Dropdown
                            inputId="foreign-reference"
                            value={field.foreignReference || ''}
                            options={(availableDoctypes || []).map((dt) => ({
                                label: dt,
                                value: dt,
                            }))}
                            onChange={(e) =>
                                onUpdate({ foreignReference: e.value, foreignReferenceKey: null })
                            }
                            placeholder="Select Doctype"
                            filter
                            showClear
                            className="w-full"
                        />
                        <small className="text-color-secondary">The table to fetch data from</small>
                    </div>

                    <div className="flex flex-column gap-2">
                        <label htmlFor="foreign-reference-key" className="text-sm font-medium">
                            ForeignReferenceKey
                        </label>
                        <Dropdown
                            inputId="foreign-reference-key"
                            value={field.foreignReferenceKey || ''}
                            options={
                                doctypeFieldsMap?.[field.foreignReference]
                                    ? doctypeFieldsMap[field.foreignReference].map((col) => ({
                                          label: col,
                                          value: col,
                                      }))
                                    : []
                            }
                            onChange={(e) => onUpdate({ foreignReferenceKey: e.value })}
                            disabled={!field.foreignReference}
                            placeholder="Select field"
                            filter
                            showClear
                            className="w-full"
                        />
                        <small className="text-color-secondary">
                            The column to display in dropdown
                        </small>
                    </div>
                </>
            )}

            {/* Options (only for 'select' and 'radio' types) */}
            {(field.type === 'select' || field.type === 'radio') && (
                <div className="flex flex-column gap-2">
                    <label htmlFor="field-options" className="text-sm font-medium">
                        Options
                    </label>
                    <InputTextarea
                        id="field-options"
                        value={(field.options || []).join('\n')}
                        onChange={(e) =>
                            onUpdate({
                                options: e.target.value.split('\n').filter((opt) => opt.trim()),
                            })
                        }
                        onKeyDown={handleTextareaKeyDown}
                        onClick={(e) => e.stopPropagation()}
                        onMouseDown={(e) => e.stopPropagation()}
                        placeholder="Enter each option on a new line"
                        rows={4}
                        className="w-full"
                    />
                    <small className="text-color-secondary">One option per line</small>
                </div>
            )}

            <Divider />

            {/* Validation Options */}
            <h5 className="text-sm font-semibold text-color m-0">Validation</h5>

            {/* Required Checkbox */}
            <div className="flex align-items-center gap-2">
                <Checkbox
                    inputId="field-required"
                    checked={field.required || false}
                    onChange={(e) => onUpdate({ required: e.checked })}
                />
                <label htmlFor="field-required" className="text-sm font-medium cursor-pointer">
                    Required
                </label>
            </div>

            {/* Unique Checkbox */}
            <div className="flex align-items-center gap-2">
                <Checkbox
                    inputId="field-unique"
                    checked={field.unique || false}
                    onChange={(e) => onUpdate({ unique: e.checked })}
                />
                <label htmlFor="field-unique" className="text-sm font-medium cursor-pointer">
                    Unique
                </label>
            </div>

            {/* Read Only Checkbox */}
            <div className="flex align-items-center gap-2">
                <Checkbox
                    inputId="field-readonly"
                    checked={field.read_only || false}
                    onChange={(e) => onUpdate({ read_only: e.checked })}
                />
                <label htmlFor="field-readonly" className="text-sm font-medium cursor-pointer">
                    Read Only
                </label>
            </div>

            {/* Text Input Validation - Only show for text/textarea fields */}
            {isTextInputField && (
                <>
                    <Divider />
                    <h5 className="text-sm font-semibold text-color m-0">Text Validation</h5>

                    {/* Regex Pattern */}
                    <div className="flex flex-column gap-2">
                        <label htmlFor="field-regex" className="text-sm font-medium">
                            Regex Pattern
                        </label>
                        <InputText
                            id="field-regex"
                            value={field.regex_pattern || ''}
                            onChange={(e) =>
                                onUpdate({
                                    regex_pattern: e.target.value || null,
                                })
                            }
                            placeholder="e.g., ^[A-Z]{3}-\d{4}$"
                            className="w-full"
                        />
                        <small className="text-color-secondary">
                            JavaScript regular expression pattern for validation
                        </small>
                    </div>

                    {/* Min Length */}
                    <div className="flex flex-column gap-2">
                        <label htmlFor="field-min-length" className="text-sm font-medium">
                            Minimum Length
                        </label>
                        <InputText
                            id="field-min-length"
                            type="number"
                            value={field.min_length || ''}
                            onChange={(e) =>
                                onUpdate({
                                    min_length: e.target.value ? parseInt(e.target.value) : null,
                                })
                            }
                            placeholder="Minimum characters"
                            className="w-full"
                            min="0"
                        />
                    </div>

                    {/* Max Length */}
                    <div className="flex flex-column gap-2">
                        <label htmlFor="field-max-length" className="text-sm font-medium">
                            Maximum Length
                        </label>
                        <InputText
                            id="field-max-length"
                            type="number"
                            value={field.max_length || ''}
                            onChange={(e) =>
                                onUpdate({
                                    max_length: e.target.value ? parseInt(e.target.value) : null,
                                })
                            }
                            placeholder="Maximum characters"
                            className="w-full"
                            min="0"
                        />
                    </div>
                </>
            )}

            <Divider />

            {/* Default Value */}
            <div className="flex flex-column gap-2">
                <label htmlFor="field-default" className="text-sm font-medium">
                    Default Value
                </label>
                <InputText
                    id="field-default"
                    value={field.default || ''}
                    onChange={(e) => onUpdate({ default: e.target.value })}
                    placeholder="Enter default value"
                    className="w-full"
                />
            </div>

            {/* Placeholder */}
            <div className="flex flex-column gap-2">
                <label htmlFor="field-placeholder" className="text-sm font-medium">
                    Placeholder
                </label>
                <InputText
                    id="field-placeholder"
                    value={field.ui?.placeholder || ''}
                    onChange={(e) =>
                        onUpdate({
                            ui: { ...field.ui, placeholder: e.target.value },
                        })
                    }
                    placeholder="Enter placeholder text"
                    className="w-full"
                />
            </div>

            {/* Help Text */}
            <div className="flex flex-column gap-2">
                <label htmlFor="field-helptext" className="text-sm font-medium">
                    Help Text
                </label>
                <InputText
                    id="field-helptext"
                    value={field.ui?.helpText || ''}
                    onChange={(e) =>
                        onUpdate({
                            ui: { ...field.ui, helpText: e.target.value },
                        })
                    }
                    placeholder="Enter help text"
                    className="w-full"
                />
            </div>
        </div>
    );
};

// ============================================================
// EMPTY STATE (No selection)
// ============================================================
const EmptyState = () => (
    <div className="flex flex-column align-items-center justify-content-center h-full text-center p-4">
        <i className="pi pi-info-circle text-4xl text-color-secondary mb-4" />
        <h4 className="text-lg font-semibold text-color m-0">Properties</h4>
        <p className="text-sm text-color-secondary mt-2" style={{ maxWidth: '300px' }}>
            Select a tab, section, or field to view and edit its properties.
        </p>
    </div>
);

// ============================================================
// MAIN PROPERTIES PANEL COMPONENT
// ============================================================
export default function PropertiesPanel({
    type, // 'tab' | 'section' | 'field' | null
    data, // The selected item data (tab, section, or field object)
    onUpdate, // Update handler
    availableDoctypes, // For link fields
    doctypeFieldsMap, // For link fields
}) {
    // Handle legacy API (backward compatibility)
    // If 'field' prop is passed directly (old usage), treat it as field type
    if (arguments[0]?.field !== undefined) {
        const {
            field,
            onUpdate: onFieldUpdate,
            availableDoctypes: doctypes,
            doctypeFieldsMap: fieldsMap,
        } = arguments[0];
        return (
            <FieldProperties
                field={field}
                onUpdate={onFieldUpdate}
                availableDoctypes={doctypes}
                doctypeFieldsMap={fieldsMap}
            />
        );
    }

    // Render based on type
    switch (type) {
        case 'tab':
            return <TabProperties tab={data} onUpdate={onUpdate} />;

        case 'section':
            return <SectionProperties section={data} onUpdate={onUpdate} />;

        case 'field':
            return (
                <FieldProperties
                    field={data}
                    onUpdate={onUpdate}
                    availableDoctypes={availableDoctypes}
                    doctypeFieldsMap={doctypeFieldsMap}
                />
            );

        default:
            return <EmptyState />;
    }
}

// Export individual components for flexibility
export { TabProperties, SectionProperties, FieldProperties, EmptyState };
