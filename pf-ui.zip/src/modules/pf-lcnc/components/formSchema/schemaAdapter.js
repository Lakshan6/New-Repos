// components/formSchema/schemaAdapter.js
import { mapFromBackendFieldType } from '../autoSchema/fieldTypeReverseMapping';

// --------------------------------------------------
// Helpers
// --------------------------------------------------

const createDefaultTab = (label = 'General') => ({
    id: crypto.randomUUID(),
    name: 'default_tab',
    label,
    sections: [],
});

const createDefaultSection = (label = 'Details') => ({
    id: crypto.randomUUID(),
    name: 'default_section',
    label,
    fields: [],
});

export const validateSchema = (schema) => {
    if (!schema || !Array.isArray(schema.fields)) {
        return { valid: false, isEmpty: true };
    }
    return { valid: true, isEmpty: schema.fields.length === 0 };
};

// --------------------------------------------------
// Field mapping
// --------------------------------------------------

const parseFieldToUI = (field) => {
    const fieldType = mapFromBackendFieldType(field.fieldtype);

    return {
        id: crypto.randomUUID(),
        name: field.fieldname,
        fieldname: field.fieldname,
        label: field.label || field.fieldname,
        type: fieldType,
        fieldtype: field.fieldtype, // Keep original for mapper type detection

        // Validation flags - keep both formats for compatibility
        required: !!field.reqd,
        reqd: !!field.reqd, // Keep original for mapper
        unique: !!field.unique,
        read_only: !!field.read_only,
        hidden: !!field.hidden,
        default: field.default ?? null,

        // String validation constraints (flattened, snake_case for mapper)
        min_length: field.min_length ?? null,
        max_length: field.max_length ?? null,
        regex_pattern: field.regex_pattern ?? null,

        // Number validation constraints
        min: field.min ?? null,
        max: field.max ?? null,

        // Date constraints
        min_date: field.min_date ?? null,
        max_date: field.max_date ?? null,
        no_past_dates: !!field.no_past_dates,
        no_future_dates: !!field.no_future_dates,

        // Select/Radio options
        options:
            (fieldType === 'select' || fieldType === 'radio') && field.options
                ? field.options.split('\n').filter((opt) => opt.trim())
                : undefined,

        // Link field configuration
        foreignReference: field.foreignReference ?? field.options ?? null,
        foreignReferenceKey: field.foreignReferenceKey ?? null,

        // UI metadata (kept separate since not used for validation)
        ui: {
            width: field.columns || 12,
            placeholder: field.placeholder || '',
            helpText: field.description || '',
        },
    };
};

// --------------------------------------------------
// MAIN PARSER
// --------------------------------------------------

export const parseSchemaToUI = (schema) => {
    const { valid, isEmpty } = validateSchema(schema);
    if (!valid || isEmpty) return [];

    const tabs = [];
    let currentTab = null;
    let currentSection = null;

    const sorted = [...schema.fields].sort((a, b) => (a.idx || 0) - (b.idx || 0));

    for (const field of sorted) {
        switch (field.fieldtype) {
            case 'Tab Break':
                currentTab = {
                    id: crypto.randomUUID(),
                    label: field.label || field.fieldname,
                    sections: [],
                };
                tabs.push(currentTab);
                currentSection = null;
                break;

            case 'Section Break':
                if (!currentTab) {
                    currentTab = createDefaultTab();
                    tabs.push(currentTab);
                }
                currentSection = {
                    id: crypto.randomUUID(),
                    label: field.label || 'Section',
                    fields: [],
                };
                currentTab.sections.push(currentSection);
                break;

            case 'Column Break':
                break;

            default:
                if (!currentTab) {
                    currentTab = createDefaultTab();
                    tabs.push(currentTab);
                }
                if (!currentSection) {
                    currentSection = createDefaultSection();
                    currentTab.sections.push(currentSection);
                }
                currentSection.fields.push(parseFieldToUI(field));
        }
    }

    return tabs;
};

// --------------------------------------------------
// Extras
// --------------------------------------------------

export const buildRelatedDataMap = (tabs, fetcher) => {
    const map = {};
    tabs.forEach((tab) =>
        tab.sections.forEach((section) =>
            section.fields.forEach((field) => {
                if (field.type === 'link' && field.foreignReference) {
                    map[field.fieldname] = fetcher(field.foreignReference);
                }
            }),
        ),
    );
    return map;
};

export const extractDefaultValues = (tabs) => {
    const defaults = {};
    tabs.forEach((tab) =>
        tab.sections.forEach((section) =>
            section.fields.forEach((field) => {
                if (field.default !== null && field.default !== undefined) {
                    defaults[field.fieldname] = field.default;
                }
            }),
        ),
    );
    return defaults;
};
