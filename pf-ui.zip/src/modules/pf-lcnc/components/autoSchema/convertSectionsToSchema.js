import { mapToBackendFieldType } from './fieldTypeMapping.js';

export const convertSectionsToSchema = (sections, doctypeName, module, doctype) => {
    let idx = 1;
    const flatFields = [];

    // ✅ SINGLE TAB
    flatFields.push({
        fieldtype: 'Tab Break',
        fieldname: 'main_tab',
        label: 'Main',
        idx: idx++,
    });

    sections.forEach((section) => {
        // ✅ SECTION BREAK
        flatFields.push({
            fieldtype: 'Section Break',
            fieldname: section.name,
            label: section.label,
            idx: idx++,
        });

        // ✅ REAL FIELDS
        section.fields.forEach((field) => {
            flatFields.push({
                fieldtype: mapToBackendFieldType(field.type),
                fieldname: field.fieldname,
                label: field.label,
                reqd: field.required ? 1 : 0,
                unique: field.unique ? 1 : 0,
                read_only: field.read_only ? 1 : 0,
                default: field.default ?? null,
                idx: idx++,
            });
        });
    });

    return {
        id: doctype?.id ?? null,
        doctypeName: doctypeName,
        module,

        custom: 1,
        fields: flatFields,
    };
};
