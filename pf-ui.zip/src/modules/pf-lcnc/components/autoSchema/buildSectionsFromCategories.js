import { inferFieldType } from './inferFieldType.js';

export const buildSectionsFromCategories = (categories, fieldMap) => {
    const sections = [];

    const addSection = (label, keys) => {
        if (!keys.length) return;

        sections.push({
            id: crypto.randomUUID(),
            label: `${label} Details`,
            name: `${label.toLowerCase()}_section`,
            fields: keys.map((key) => {
                const info = fieldMap[key];
                const uiType = inferFieldType(info.samples, key);

                return {
                    id: crypto.randomUUID(), // internal UUID
                    name: crypto.randomUUID(), // immutable identity (DocField.name style)
                    fieldname: key, // DB + render key
                    label: key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
                    type: uiType,
                    required: info.required,
                    unique: false,
                    read_only: false,
                    default: null,
                    ui: { width: 12 },
                    validation: {},
                };
            }),
        });
    };

    addSection('Basic', categories.basic);
    addSection('Status', categories.status);
    addSection('Numbers', categories.numbers);
    addSection('Dates', categories.dates);
    addSection('Description', categories.description);
    addSection('Relations', categories.relations);
    addSection('Other Fields', categories.other);

    return sections;
};
