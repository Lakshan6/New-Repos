/**
 * Maps your backend field types → UI field types used for schema rendering.
 *
 * Keep it identical to the FormRenderer mapping for consistency.
 */

export const mapFromBackendFieldType = (backendType) => {
    const map = {
        Data: 'text',
        'Small Text': 'textarea',
        Float: 'number',
        Currency: 'currency',
        Int: 'number',
        Check: 'checkbox',
        Date: 'date',
        Datetime: 'datetime',
        Select: 'select',
        Link: 'link',
        Button: 'button',
        Table: 'table',
    };

    return map[backendType] || 'text';
};
