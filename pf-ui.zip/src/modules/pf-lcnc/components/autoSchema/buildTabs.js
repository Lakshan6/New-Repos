// utils/autoSchema/buildTabs.js

import { inferFieldType } from './inferFieldType.js';

export const buildTabsFromCategories = (categories, fieldMap) => {
    const tabs = [];

    const addTab = (label, keys) => {
        if (!keys.length) return;

        const tabId = crypto.randomUUID();
        const sectionId = crypto.randomUUID();

        tabs.push({
            id: tabId,
            label,
            name: `${label.toLowerCase()}_tab`,
            sections: [
                {
                    id: sectionId,
                    label: `${label} Details`,
                    name: `${label.toLowerCase()}_section`,
                    fields: keys.map((key) => {
                        const info = fieldMap[key];
                        const uiType = inferFieldType(info.samples, key);

                        return {
                            id: crypto.randomUUID(),
                            name: key,
                            fieldname: key,
                            label: key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
                            type: uiType,
                            required: info.required,
                            unique: false,
                            read_only: false,
                            default: null,
                            ui: { width: 12 },
                            validation: {},
                        };
                    }),
                },
            ],
        });
    };

    addTab('Basic', categories.basic);
    addTab('Status', categories.status);
    addTab('Numbers', categories.numbers);
    addTab('Dates', categories.dates);
    addTab('Description', categories.description);
    addTab('Relations', categories.relations);
    addTab('Other Fields', categories.other);

    return tabs;
};
