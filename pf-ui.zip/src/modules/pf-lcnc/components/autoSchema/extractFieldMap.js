// utils/autoSchema/extractFieldMap.js

export const extractFieldMap = (rows) => {
    const fieldMap = {};

    rows.forEach((row) => {
        Object.entries(row).forEach(([key, value]) => {
            if (!fieldMap[key]) {
                fieldMap[key] = { samples: [], required: true };
            }

            fieldMap[key].samples.push(value);

            if (value === null || value === undefined) {
                fieldMap[key].required = false;
            }
        });

        // detect missing keys
        Object.keys(fieldMap).forEach((key) => {
            if (!(key in row)) {
                fieldMap[key].required = false;
            }
        });
    });

    return fieldMap;
};
