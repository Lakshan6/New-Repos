/**
 * Generate default listview_config from record data
 * shared/schemas/generateListViewConfigFromData.js
 */

// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

const displayMaxColumns = 4;

const EXCLUDED_FIELDS = new Set([]);

const HUMAN_FIELD_PRIORITY = ['name', 'title', 'label', 'displayName', 'fullName'];
const NAME_SUFFIX_REGEX = /name$/i;
const DATE_FIELD_REGEX = /(date|time|at)$/i;

// -----------------------------------------------------------------------------
// HELPERS
// -----------------------------------------------------------------------------

const prettifyHeader = (field) =>
    field
        .replace(/_/g, ' ')
        .replace(/([a-z])([A-Z])/g, '$1 $2')
        .replace(/\b\w/g, (c) => c.toUpperCase());

function inferObjectDisplayField(obj) {
    if (!obj || typeof obj !== 'object' || Array.isArray(obj)) return null;

    const keys = Object.keys(obj);

    for (const key of HUMAN_FIELD_PRIORITY) {
        if (keys.includes(key) && obj[key]) return key;
    }

    const suffixMatch = keys.find((k) => NAME_SUFFIX_REGEX.test(k) && obj[k]);
    if (suffixMatch) return suffixMatch;

    if (keys.includes('code') && obj.code) return 'code';
    if (keys.includes('number') && obj.number) return 'number';

    return null;
}

// -----------------------------------------------------------------------------
// MAIN GENERATOR
// -----------------------------------------------------------------------------

export function generateListViewConfigFromData(records, options = {}) {
    const { maxColumns = displayMaxColumns, excludeFields = [] } = options;

    if (!Array.isArray(records) || records.length === 0) {
        return { columns: [] };
    }

    const excluded = new Set([...EXCLUDED_FIELDS, ...excludeFields]);
    const addedFields = new Set(); // Track fields we've already added a column for
    const columns = [];

    // Gather all fields and compute stats
    const allFields = Object.keys(records.reduce((acc, r) => ({ ...acc, ...r }), {}));

    const stats = allFields.map((field) => {
        const values = records.map((r) => r[field]);
        const sample = values.find((v) => v !== null && v !== undefined && v !== '');

        return {
            field,
            sample,
            nonEmpty: sample !== undefined,
            isString: typeof sample === 'string',
            isObject: typeof sample === 'object' && sample !== null && !Array.isArray(sample),
            isArray: Array.isArray(sample),
            isNumber: typeof sample === 'number',
            isDateLike: DATE_FIELD_REGEX.test(field),
        };
    });

    const usable = stats.filter((f) => f.nonEmpty && !excluded.has(f.field));

    // Helper to add a column and mark field as used
    const addColumn = (config) => {
        if (!addedFields.has(config.field)) {
            columns.push(config);
            addedFields.add(config.field);
        }
    };

    // -------------------------------------------------------------------------
    // 1️⃣ Primary human identifier (e.g., name, title)
    // -------------------------------------------------------------------------

    const primary =
        usable.find((f) => HUMAN_FIELD_PRIORITY.includes(f.field)) ||
        usable.find((f) => NAME_SUFFIX_REGEX.test(f.field));

    if (primary) {
        addColumn({
            field: primary.field,
            header: prettifyHeader(primary.field),
            sortable: true,
            visible: false,
            source: 'auto',
        });
    }

    // -------------------------------------------------------------------------
    // 2️⃣ Special: Status column (only once, with fixed header)
    // -------------------------------------------------------------------------

    const statusStat = usable.find((f) => f.field === 'status');
    if (statusStat && !addedFields.has('status')) {
        addColumn({
            field: 'status',
            header: 'Status', // Fixed human-readable header
            sortable: true,
            visible: false,
            source: 'auto',
        });
    }

    // -------------------------------------------------------------------------
    // 3️⃣ Flat string fields (excluding dates and already added)
    // -------------------------------------------------------------------------

    usable
        .filter((f) => !addedFields.has(f.field) && f.isString && !f.isDateLike)
        .forEach((f) => {
            addColumn({
                field: f.field,
                header: prettifyHeader(f.field),
                sortable: true,
                visible: false,
                source: 'auto',
            });
        });

    // -------------------------------------------------------------------------
    // 4️⃣ One-to-one nested objects (e.g., customer.name)
    // -------------------------------------------------------------------------

    usable
        .filter((f) => f.isObject && !addedFields.has(f.field))
        .forEach((nested) => {
            const childKey = inferObjectDisplayField(nested.sample);
            if (!childKey) return;

            const dottedField = `${nested.field}.${childKey}`;
            if (addedFields.has(dottedField)) return;

            addColumn({
                field: dottedField,
                header: prettifyHeader(nested.field),
                sortable: false,
                visible: false,
                source: 'auto',
                isReferenced: true,
            });
            addedFields.add(dottedField);
        });

    // -------------------------------------------------------------------------
    // 5️⃣ Numeric fields
    // -------------------------------------------------------------------------

    usable
        .filter((f) => f.isNumber && !addedFields.has(f.field))
        .forEach((f) => {
            addColumn({
                field: f.field,
                header: prettifyHeader(f.field),
                sortable: true,
                visible: false,
                source: 'auto',
            });
        });

    // -------------------------------------------------------------------------
    // 6️⃣ One-to-many arrays (show count)
    // -------------------------------------------------------------------------

    usable
        .filter((f) => f.isArray && !addedFields.has(`__${f.field}_count`))
        .forEach((f) => {
            const countField = `__${f.field}_count`;
            addColumn({
                field: countField,
                header: prettifyHeader(f.field),
                sortable: true,
                visible: false,
                source: 'auto',
                isReferenced: true,
                compute: {
                    source: f.field,
                    operation: 'count',
                },
            });
            addedFields.add(countField);
        });

    // -------------------------------------------------------------------------
    // 7️⃣ Date/time fields (last, so they don't crowd primary columns)
    // -------------------------------------------------------------------------

    usable
        .filter((f) => f.isDateLike && !addedFields.has(f.field))
        .forEach((f) => {
            addColumn({
                field: f.field,
                header: prettifyHeader(f.field),
                sortable: true,
                visible: false,
                source: 'auto',
            });
        });

    // -------------------------------------------------------------------------
    // FINAL: Set visibility based on maxColumns
    // -------------------------------------------------------------------------

    const finalColumns = columns.map((col, index) => ({
        ...col,
        visible: index < maxColumns,
    }));

    return {
        columns: finalColumns,
    };
}
