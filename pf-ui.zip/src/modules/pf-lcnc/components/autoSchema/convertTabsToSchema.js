// utils/autoSchema/convertTabsToSchema.js

import { mapToBackendFieldType } from './fieldTypeMapping.js';

export const convertTabsToSchema = (tabs, doctypeName) => {
    let idx = 1;
    const flatFields = [];

    tabs.forEach((tab) => {
        flatFields.push({
            fieldtype: 'Tab Break',
            fieldname: tab.name,
            label: tab.label,
            idx: idx++,
        });

        tab.sections.forEach((section) => {
            flatFields.push({
                fieldtype: 'Section Break',
                fieldname: section.name,
                label: section.label,
                idx: idx++,
            });

            section.fields.forEach((field) => {
                flatFields.push({
                    fieldtype: mapToBackendFieldType(field.type),
                    fieldname: field.fieldname,
                    label: field.label,
                    reqd: field.required ? 1 : 0,
                    unique: 0,
                    read_only: 0,
                    default: null,
                    idx: idx++,
                });
            });
        });
    });

    return {
        doctype: doctypeName,
        module: 'Auto',
        custom: 1,
        fields: flatFields,
    };
};
