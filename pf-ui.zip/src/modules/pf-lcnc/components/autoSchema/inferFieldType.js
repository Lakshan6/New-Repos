// utils/autoSchema/inferFieldType.js

export const inferFieldType = (samples, key) => {
    const value = samples.find((v) => v !== null && v !== undefined);

    if (value === undefined) return 'text';

    // boolean → checkbox
    if (typeof value === 'boolean') return 'checkbox';

    // numbers
    if (typeof value === 'number') return 'number';

    // detect ISO date
    if (typeof value === 'string' && /^\d{4}-\d{2}-\d{2}$/.test(value)) {
        return 'date';
    }

    // detect datetime
    if (typeof value === 'string' && !isNaN(Date.parse(value))) {
        return 'datetime';
    }

    // url pattern
    if (typeof value === 'string' && value.startsWith('http')) {
        return 'link';
    }

    // email pattern
    if (/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(value)) {
        return 'text';
    }

    // long text
    if (typeof value === 'string' && value.length > 120) {
        return 'textarea';
    }

    // nested objects
    if (typeof value === 'object' && !Array.isArray(value)) {
        return 'table'; // table or child document
    }

    return 'text';
};
