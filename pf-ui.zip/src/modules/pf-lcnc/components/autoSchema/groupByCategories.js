// utils/autoSchema/groupByCategories.js

import { inferFieldType } from './inferFieldType.js';

export const detectCategory = (key, uiType) => {
    key = key.toLowerCase();

    if (uiType === 'checkbox') return 'status';

    if (uiType === 'number' || key.match(/(amount|price|salary|qty|total|value|rate)/))
        return 'numbers';

    if (uiType === 'date' || uiType === 'datetime' || key.match(/(date|time|created|updated|dob)/))
        return 'dates';

    if (uiType === 'textarea' || key.includes('description') || key.includes('notes'))
        return 'description';

    if (uiType === 'table') return 'relations';

    return 'basic';
};

export const groupByCategories = (fieldMap) => {
    const categories = {
        basic: [],
        status: [],
        numbers: [],
        dates: [],
        description: [],
        relations: [],
        other: [],
    };

    Object.entries(fieldMap).forEach(([key, info]) => {
        const uiType = inferFieldType(info.samples, key);
        const category = detectCategory(key, uiType);

        if (!categories[category]) categories.other.push(key);
        else categories[category].push(key);
    });

    return categories;
};
