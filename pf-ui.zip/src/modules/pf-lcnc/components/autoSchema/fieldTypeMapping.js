// utils/autoSchema/fieldTypeMapping.js

/**
 * Maps your UI field types → backend field types used for schema rendering.
 *
 * Keep it identical to the FormRenderer mapping for consistency.
 */
export const mapToBackendFieldType = (uiType) => {
    const map = {
        text: 'Data',
        textarea: 'Small Text',
        number: 'Float',
        currency: 'Currency',
        int: 'Int',
        checkbox: 'Check',
        date: 'Date',
        datetime: 'Datetime',
        select: 'Select',
        link: 'Link',
        button: 'Button',
        table: 'Table',
    };

    return map[uiType] || 'Data';
};
