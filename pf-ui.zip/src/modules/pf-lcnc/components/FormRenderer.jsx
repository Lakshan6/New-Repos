import React, { useMemo, useState, useEffect, useCallback } from 'react';
import { Button } from 'primereact/button';
import { Skeleton } from 'primereact/skeleton';
import { Message } from 'primereact/message';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';
import Section from '@shared/components/Section';
import { useNavigate } from 'react-router';
import { useForm } from 'react-hook-form';

import { mapFromBackendFieldType } from './autoSchema/fieldTypeReverseMapping';
import '../styles/FormRenderer.scss';

// ============================================================================
// SECTION 1: CONSTANTS & CONFIGURATION
// ============================================================================

const FORM_STATUS = {
    NOT_SAVED: 'Not Saved',
    MODIFIED: 'Modified',
    SAVING: 'Saving',
    SAVED: 'Saved',
    LOADED: 'Loaded',
    ERROR: 'Error',
};

const MOCK_TABLE_DATA = {
    Customer: [
        { id: 1, full_name: 'John Doe', email: 'john@example.com', phone: '123-456' },
        { id: 2, full_name: 'Jane Smith', email: 'jane@example.com', phone: '789-012' },
        { id: 3, full_name: 'Bob Wilson', email: 'bob@example.com', phone: '345-678' },
    ],
    Item: [
        { id: 101, item_name: 'Laptop', sku: 'LAP-001', price: 999.99 },
        { id: 102, item_name: 'Mouse', sku: 'MOU-002', price: 29.99 },
        { id: 103, item_name: 'Keyboard', sku: 'KEY-003', price: 79.99 },
    ],
    Order: [
        { id: 1001, order_number: 'ORD-001', order_date: '2024-01-15', customer: 1 },
        { id: 1002, order_number: 'ORD-002', order_date: '2024-01-16', customer: 2 },
    ],
    Address: [
        { id: 1, line1: '123 Main St', city: 'New York', postal_code: '10001' },
        { id: 2, line1: '456 Oak Ave', city: 'Los Angeles', postal_code: '90001' },
    ],
    User: [
        { id: 1, username: 'admin', role: 'Admin', status: 'Active' },
        { id: 2, username: 'editor', role: 'Editor', status: 'Active' },
        { id: 3, username: 'viewer', role: 'Viewer', status: 'Inactive' },
    ],
};
// ============================================================================
// SECTION 2: UTILITY FUNCTIONS
// ============================================================================

const isEmptyObject = (obj) => {
    if (!obj) return true;
    if (typeof obj !== 'object') return true;
    return Object.keys(obj).length === 0;
};

const createDefaultTab = (label = 'General') => ({
    id: crypto.randomUUID(),
    name: 'default_tab',
    label,
    sections: [],
});

const createDefaultSection = (label = 'Details') => ({
    id: crypto.randomUUID(),
    name: 'default_section',
    label,
    fields: [],
});

const fetchRelatedData = (doctype) => {
    return MOCK_TABLE_DATA[doctype] || [];
};

// ============================================================================
// SECTION 3: SCHEMA VALIDATION
// ============================================================================

const validateSchema = (schema) => {
    const errors = [];
    const warnings = [];

    if (!schema) {
        return { valid: false, errors: ['No schema provided'], warnings: [], isEmpty: true };
    }

    if (typeof schema !== 'object' || Array.isArray(schema)) {
        errors.push('Schema must be a plain object');
        return { valid: false, errors, warnings, isEmpty: false };
    }

    if (!schema.fields) {
        return {
            valid: false,
            errors: ['Schema is missing fields array'],
            warnings: [],
            isEmpty: true,
        };
    }

    if (!Array.isArray(schema.fields)) {
        errors.push('Schema.fields must be an array');
        return { valid: false, errors, warnings, isEmpty: false };
    }

    if (schema.fields.length === 0) {
        return { valid: true, errors: [], warnings: ['Schema has no fields'], isEmpty: true };
    }

    schema.fields.forEach((field, index) => {
        if (!field || typeof field !== 'object') {
            errors.push(`Field at index ${index} is not a valid object`);
            return;
        }
        if (!field.fieldname) {
            warnings.push(`Field at index ${index} is missing 'fieldname'`);
        }
        if (!field.fieldtype) {
            warnings.push(`Field at index ${index} is missing 'fieldtype'`);
        }
    });

    return { valid: errors.length === 0, errors, warnings, isEmpty: false };
};

// ============================================================================
// SECTION 4: SCHEMA PARSING (Backend → UI)
// ============================================================================

const parseFieldToUI = (field) => {
    const fieldType = mapFromBackendFieldType(field.fieldtype);

    return {
        id: crypto.randomUUID(),
        name: field.fieldname,
        fieldname: field.fieldname,
        label: field.label || field.fieldname,
        type: fieldType,
        fieldtype: field.fieldtype, // Keep original for mapper type detection

        // Validation flags - keep both formats for compatibility
        required: !!field.reqd,
        reqd: !!field.reqd, // Keep original for mapper
        unique: !!field.unique,
        read_only: !!field.read_only,
        hidden: !!field.hidden,
        default: field.default ?? null,

        // String validation constraints (flattened, snake_case for mapper)
        min_length: field.min_length ?? null,
        max_length: field.max_length ?? null,
        regex_pattern: field.regex_pattern ?? null,

        // Number validation constraints
        min: field.min ?? null,
        max: field.max ?? null,

        // Date constraints
        min_date: field.min_date ?? null,
        max_date: field.max_date ?? null,
        no_past_dates: !!field.no_past_dates,
        no_future_dates: !!field.no_future_dates,

        // Select/Radio options
        options:
            (fieldType === 'select' || fieldType === 'radio') && field.options
                ? field.options.split('\n').filter((opt) => opt.trim())
                : undefined,

        // Link field configuration
        foreignReference: field.foreignReference ?? field.options ?? null,
        foreignReferenceKey: field.foreignReferenceKey ?? null,

        // UI metadata (kept separate since not used for validation)
        ui: {
            width: field.columns || 12,
            placeholder: field.placeholder || '',
            helpText: field.description || '',
        },
    };
};

const parseSchemaToUI = (schema) => {
    const validation = validateSchema(schema);

    if (!validation.valid || validation.isEmpty) {
        if (validation.errors.length > 0) {
            console.warn('Schema parsing errors:', validation.errors);
        }
        return [];
    }

    if (validation.warnings.length > 0) {
        console.warn('Schema parsing warnings:', validation.warnings);
    }

    const tabs = [];
    let currentTab = null;
    let currentSection = null;

    const sorted = [...schema.fields].sort((a, b) => (a.idx || 0) - (b.idx || 0));

    for (const field of sorted) {
        switch (field.fieldtype) {
            case 'Tab Break': {
                currentTab = {
                    id: crypto.randomUUID(),
                    name: field.fieldname,
                    label: field.label || field.fieldname,
                    sections: [],
                };
                tabs.push(currentTab);
                currentSection = null;
                break;
            }

            case 'Section Break': {
                if (!currentTab) {
                    currentTab = createDefaultTab();
                    tabs.push(currentTab);
                }
                currentSection = {
                    id: crypto.randomUUID(),
                    name: field.fieldname,
                    label: field.label || 'Section',
                    collapsible: !!field.collapsible,
                    collapsed: !!field.collapsed,
                    fields: [],
                };
                currentTab.sections.push(currentSection);
                break;
            }

            case 'Column Break': {
                break;
            }

            default: {
                if (!currentTab) {
                    currentTab = createDefaultTab();
                    tabs.push(currentTab);
                }
                if (!currentSection) {
                    currentSection = createDefaultSection();
                    currentTab.sections.push(currentSection);
                }
                currentSection.fields.push(parseFieldToUI(field));
                break;
            }
        }
    }

    return tabs;
};

const buildRelatedDataMap = (tabs) => {
    const relatedDataMap = {};

    tabs.forEach((tab) => {
        tab.sections.forEach((section) => {
            section.fields.forEach((field) => {
                if (field.type === 'link' && field.foreignReference) {
                    relatedDataMap[field.fieldname] = fetchRelatedData(field.foreignReference);
                }
            });
        });
    });

    return relatedDataMap;
};

const extractDefaultValues = (tabs) => {
    const defaults = {};

    tabs.forEach((tab) => {
        tab.sections.forEach((section) => {
            section.fields.forEach((field) => {
                if (field.default !== null && field.default !== undefined) {
                    defaults[field.fieldname] = field.default;
                }
            });
        });
    });

    return defaults;
};

// ============================================================================
// SECTION 5: SUB-COMPONENTS
// ============================================================================

const FormRendererHeader = ({
    title,
    subtitle,
    status,
    isDirty,
    isSaving,
    onSave,
    onEdit,
    onDelete,
    showEditButton,
    readOnly,
    isEditing,
    onToggleEdit,
    onCancelEdit, // ✅ NEW
}) => {
    const getStatusStyle = useCallback(() => {
        switch (status) {
            case FORM_STATUS.SAVED:
                return 'bg-green-100 text-green-700';
            case FORM_STATUS.MODIFIED:
                return 'bg-yellow-100 text-yellow-700';
            case FORM_STATUS.LOADED:
                return 'bg-blue-100 text-blue-700';
            case FORM_STATUS.ERROR:
                return 'bg-red-100 text-red-700';
            case FORM_STATUS.SAVING:
                return 'bg-blue-100 text-blue-700';
            default:
                return 'bg-gray-100 text-gray-600';
        }
    }, [status]);

    return (
        <header className="form-renderer-header surface-card border-1 border-round-md surface-border px-4 py-3">
            <div className="flex flex-row justify-content-between align-items-start w-full">
                {/* LEFT SIDE: Title + Subtitle + Badges */}
                <div className="flex flex-column gap-1">
                    {/* Title row with status and editing badges */}
                    <div className="flex flex-row align-items-center gap-3">
                        <h1 className="m-0 text-3xl font-semibold text-900">{title}</h1>
                        <span className={`text-sm px-2 py-1 border-round ${getStatusStyle()}`}>
                            {status}
                        </span>
                        {isEditing && (
                            <span className="text-sm px-2 py-1 border-round bg-orange-100 text-orange-700">
                                <i
                                    className="pi pi-pencil mr-1"
                                    style={{ fontSize: '0.75rem' }}
                                ></i>
                                Editing
                            </span>
                        )}
                    </div>

                    {/* Subtitle - now clearly below the title */}
                    {subtitle && (
                        <div className="text-lg font-medium text-400 mt-1">{subtitle}</div>
                    )}
                </div>

                {/* RIGHT SIDE: Buttons */}
                <div className="flex flex-row align-items-center gap-2">
                    {/* Edit Doctype button */}
                    {showEditButton && !readOnly && !isEditing && (
                        <Button
                            label="Edit Form UI"
                            icon="pi pi-pencil"
                            className="p-button-outlined p-button-sm"
                            onClick={onEdit}
                        />
                    )}

                    {/* Edit/Save/Cancel controls */}
                    {!readOnly &&
                        (isEditing ? (
                            <div className="flex flex-row align-items-center gap-2">
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    className="p-button-outlined p-button-sm p-button-secondary"
                                    onClick={onCancelEdit}
                                    disabled={isSaving}
                                />
                                <Button
                                    label={isSaving ? 'Saving...' : 'Save'}
                                    icon={isSaving ? 'pi pi-spin pi-spinner' : 'pi pi-save'}
                                    className="p-button-sm p-button-success"
                                    onClick={onSave}
                                    disabled={!isDirty || isSaving}
                                />
                            </div>
                        ) : (
                            <Button
                                label="Edit Data"
                                icon="pi pi-pencil"
                                className="p-button-sm"
                                onClick={onToggleEdit}
                            />
                        ))}

                    {/* Delete button - always visible in view mode (next to Edit Data) */}
                    {!readOnly && !isEditing && onDelete && (
                        <Button
                            label="Delete"
                            icon="pi pi-trash"
                            className="p-button-danger p-button-sm p-button-outlined"
                            onClick={onDelete}
                            severity="danger"
                        />
                    )}
                </div>
            </div>
        </header>
    );
};

const FormRendererSkeleton = () => (
    <div className="form-renderer-container">
        <div className="form-renderer-content p-4">
            <Skeleton width="30%" height="2rem" className="mb-4" />
            <Skeleton width="100%" height="3rem" className="mb-3" />
            <Skeleton width="100%" height="3rem" className="mb-3" />
            <Skeleton width="100%" height="3rem" className="mb-3" />
            <Skeleton width="60%" height="3rem" className="mb-3" />
        </div>
    </div>
);

const FormRendererMessage = ({ message, severity = 'warn' }) => (
    <div className="form-renderer-container">
        <div className="form-renderer-content p-4">
            <Message severity={severity} text={message} className="w-full" />
        </div>
    </div>
);

const FormRendererEmpty = ({ message = 'No displayable fields found in the schema.' }) => (
    <div className="form-renderer-container">
        <div
            className="form-renderer-content p-4 flex flex-column align-items-center justify-content-center"
            style={{ minHeight: '300px' }}
        >
            <i className="pi pi-inbox text-4xl text-gray-400 mb-3"></i>
            <Message severity="info" text={message} className="w-full max-w-30rem" />
        </div>
    </div>
);

// ============================================================================
// SECTION 6: MAIN COMPONENT
// ============================================================================

const FormRenderer = ({
    schema,
    data,
    onSave,
    onDelete,
    loading = false,
    readOnly = false,
    showEditButton = true,
    recordIdentifier,
    recordIdentifierLabel = 'ID', // ← Optional label, e.g., "Invoice No:" or "ID:"
}) => {
    const navigate = useNavigate();

    // -------------------------------------------------------------------------
    // MEMOIZED PARSING
    // -------------------------------------------------------------------------

    const tabs = useMemo(() => parseSchemaToUI(schema), [schema]);
    const relatedData = useMemo(() => buildRelatedDataMap(tabs), [tabs]);
    const defaultValues = useMemo(() => extractDefaultValues(tabs), [tabs]);
    const documentTitle = useMemo(
        () => schema?.doctypeName || schema?.name || 'Untitled Document',
        [schema],
    );
    const schemaValidation = useMemo(() => validateSchema(schema), [schema]);

    // -------------------------------------------------------------------------
    // INITIAL FORM DATA
    // -------------------------------------------------------------------------

    const computeInitialFormData = useCallback(() => {
        let initialData = { ...defaultValues };

        if (!isEmptyObject(schema?.data)) {
            initialData = { ...initialData, ...schema.data };
        }

        if (!isEmptyObject(data)) {
            initialData = { ...initialData, ...data };
        }

        return initialData;
    }, [data, schema?.data, defaultValues]);

    // -------------------------------------------------------------------------
    // STATE
    // -------------------------------------------------------------------------

    // Inside component
    const {
        control,
        handleSubmit,
        reset,
        watch,
        formState: { errors, isDirty, isSubmitting },
        trigger, // optional: manual validation trigger
    } = useForm({
        defaultValues: computeInitialFormData(),
        mode: 'onChange', // validates as user types
    });

    const [activeTab, setActiveTab] = useState(null);
    const [status, setStatus] = useState(() => {
        if (!isEmptyObject(data) || !isEmptyObject(schema?.data)) {
            return FORM_STATUS.LOADED;
        }
        return FORM_STATUS.NOT_SAVED;
    });
    const [isSaving, setIsSaving] = useState(false);
    const [isEditing, setIsEditing] = useState(false);

    // -------------------------------------------------------------------------
    // COMPUTED VALUES
    // -------------------------------------------------------------------------

    const activeTabData = useMemo(
        () => tabs.find((t) => t.id === activeTab) || null,
        [tabs, activeTab],
    );

    const formTabs = useMemo(
        () =>
            tabs.map((tab) => ({
                label: tab.label,
                value: tab.id,
                active: activeTab === tab.id,
                onClick: () => setActiveTab(tab.id),
            })),
        [tabs, activeTab],
    );

    // -------------------------------------------------------------------------
    // EFFECTS
    // -------------------------------------------------------------------------
    useEffect(() => {
        reset(computeInitialFormData());
        setStatus(
            !isEmptyObject(data) || !isEmptyObject(schema?.data)
                ? FORM_STATUS.LOADED
                : FORM_STATUS.NOT_SAVED,
        );
        setIsEditing(false);
    }, [data, schema?.data, reset, computeInitialFormData]);

    useEffect(() => {
        if (tabs.length > 0 && !activeTab) {
            setActiveTab(tabs[0].id);
        }
    }, [tabs, activeTab]);

    useEffect(() => {
        if (activeTab && tabs.length > 0) {
            const tabExists = tabs.some((t) => t.id === activeTab);
            if (!tabExists) {
                setActiveTab(tabs[0].id);
            }
        }
    }, [tabs, activeTab]);

    // -------------------------------------------------------------------------
    // HANDLERS
    // -------------------------------------------------------------------------

    const handleSave = async (values) => {
        setIsSaving(true);
        setStatus(FORM_STATUS.SAVING);

        try {
            await onSave?.(values); // ← RHF gives final JSON
            setStatus(FORM_STATUS.SAVED);
            reset(values); // ← resets dirty state
            setIsEditing(false);
        } catch (error) {
            console.error('Save failed:', error);
            setStatus(FORM_STATUS.ERROR);
        } finally {
            setIsSaving(false);
        }
    };

    const handleToggleEdit = useCallback(() => {
        setIsEditing(true);
        // Don't change status here - keep it as LOADED until changes are made
    }, []);

    const handleCancelEdit = useCallback(() => {
        reset(); // ← restores last committed values
        setIsEditing(false);
        setStatus(FORM_STATUS.LOADED);
    }, [reset]);

    const handleEditDoctype = useCallback(() => {
        navigate('/web/landing/form-builder', { state: { schema } }); //Send the built schema to the form builder, contains everything.
    }, [navigate, schema]);

    // -------------------------------------------------------------------------
    // RENDER - LOADING
    // -------------------------------------------------------------------------

    if (loading) {
        return <FormRendererSkeleton />;
    }

    // -------------------------------------------------------------------------
    // RENDER - ERROR STATES
    // -------------------------------------------------------------------------

    const ValidationErrorsSummary = ({ errors }) => {
        if (!errors || Object.keys(errors).length === 0) return null;

        return (
            <div className="form-renderer-errors p-3 mx-3 mb-3">
                <Message
                    severity="error"
                    className="w-full"
                    content={
                        <div className="flex flex-column gap-1">
                            <span className="font-semibold">Please fix the following errors:</span>
                            <ul className="m-0 pl-4">
                                {Object.entries(errors).map(([field, err]) => (
                                    <li key={field}>{err.message}</li>
                                ))}
                            </ul>
                        </div>
                    }
                />
            </div>
        );
    };

    if (!schema) {
        return (
            <FormRendererMessage
                message="No schema provided. Please provide a valid schema to render the form."
                severity="warn"
            />
        );
    }

    if (!schemaValidation.valid && !schemaValidation.isEmpty) {
        return (
            <FormRendererMessage
                message={`Invalid schema: ${schemaValidation.errors.join(', ')}`}
                severity="error"
            />
        );
    }

    if (schemaValidation.isEmpty) {
        return (
            <FormRendererMessage
                message="No schema provided. Please provide a valid schema to render the form."
                severity="warn"
            />
        );
    }

    if (tabs.length === 0) {
        return <FormRendererEmpty />;
    }

    // -------------------------------------------------------------------------
    // RENDER - MAIN
    // -------------------------------------------------------------------------

    return (
        <div className="form-renderer-container">
            <FormRendererHeader
                title={documentTitle}
                subtitle={recordIdentifier ? `${recordIdentifier}` : undefined}
                status={status}
                isDirty={isDirty}
                isSaving={isSaving}
                onSave={handleSubmit(handleSave)}
                onEdit={handleEditDoctype}
                onDelete={onDelete}
                showEditButton={showEditButton}
                readOnly={readOnly}
                isEditing={isEditing}
                onToggleEdit={handleToggleEdit}
                onCancelEdit={handleCancelEdit} // ✅ Pass cancel handler
            />

            <ValidationErrorsSummary errors={errors} />

            <div className="form-renderer-content p-3">
                <TabbedSectionCard tabs={formTabs}>
                    <div className="form-renderer-tab-content">
                        {activeTabData?.sections.map((section) => (
                            <Section
                                key={section.id}
                                id={section.id}
                                label={section.label}
                                fields={section.fields}
                                isPreview={true}
                                isCollapsible={section.collapsible}
                                isCollapsed={section.collapsed}
                                onAddField={() => {}}
                                onDeleteField={() => {}}
                                onRenameSection={() => {}}
                                onRenameField={() => {}}
                                onAddSection={() => {}}
                                onDeleteSection={() => {}}
                                onReorderFields={() => {}}
                                onSelectField={() => {}}
                                onSelectSection={() => {}}
                                isSelected={false}
                                relatedData={relatedData}
                                readOnly={readOnly || !isEditing} // ✅ Fields are readOnly when not editing
                                control={control}
                            />
                        ))}
                    </div>
                </TabbedSectionCard>
            </div>
        </div>
    );
};

export default FormRenderer;
