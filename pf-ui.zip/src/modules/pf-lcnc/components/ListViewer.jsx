import React, { useState, useMemo } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Tag } from 'primereact/tag';
import { ProgressSpinner } from 'primereact/progressspinner';
import get from 'lodash.get';

/**
 * Reusable ListViewer Component - Matches ResourceList styling
 *
 * @param {Object} props
 * @param {Array} props.data - Array of data objects to display
 * @param {Array} props.columns - Column configuration array
 * @param {Function} props.onRowClick - Callback when row is clicked
 * @param {Function} props.onRefresh - Callback for refresh action
 * @param {Function} props.onCreate - Callback for create action
 * @param {Boolean} props.loading - Loading state
 * @param {String} props.emptyMessage - Message to show when no data
 * @param {String} props.title - Title of the list
 * @param {String} props.createButtonLabel - Label for create button
 * @param {Boolean} props.showCreateButton - Whether to show create button
 * @param {Boolean} props.showRefreshButton - Whether to show refresh button
 * @param {Boolean} props.showSearch - Whether to show search input
 * @param {Object} props.customActions - Custom action buttons array
 * @param {Boolean} props.paginator - Enable pagination
 * @param {Number} props.rows - Rows per page
 * @param {Array} props.rowsPerPageOptions - Options for rows per page
 * @param {String} props.tableHeight - Total height for the component (e.g., "600px")
 */

const ListViewer = ({
    data = [],
    columns = [],
    onRowClick,
    onRefresh,
    onCreate,
    loading = false,
    emptyMessage = 'No data available',
    title,
    createButtonLabel = 'Create New',
    showCreateButton = true,
    showRefreshButton = true,
    showSearch = true,
    customActions = [],
    paginator = true,
    rows = 10,
    rowsPerPageOptions = [10, 25, 50, 100],
    headerContent,
    footerContent,
    tableHeight = '600px',
}) => {
    const [globalFilter, setGlobalFilter] = useState('');

    /*Helper to resolve dotted path - LATER WILL IMPLEMENT JSONPath*/
    const resolveValue = (rowData, field) => {
        const value = get(rowData, field);
        return value !== undefined && value !== null && value !== '' ? value : '—';
    };

    // -------------------------------------------------------------------------
    // CALCULATE SCROLL HEIGHT
    // tableHeight is the TOTAL available height for the component
    // scrollHeight should be the height for just the scrollable body
    // We need to subtract header, column headers, and paginator heights
    // -------------------------------------------------------------------------
    const scrollHeight = useMemo(() => {
        if (!tableHeight) return '400px';

        // Heights of DataTable components (approximate values)
        const HEADER_HEIGHT = 60; // Search bar + action buttons row
        const COLUMN_HEADER_HEIGHT = 46; // Table column headers
        const PAGINATOR_HEIGHT = 56; // Paginator row
        const BUFFER = 10; // Extra buffer for borders/margins

        const TOTAL_FIXED_HEIGHT = HEADER_HEIGHT + COLUMN_HEADER_HEIGHT + PAGINATOR_HEIGHT + BUFFER;

        // Handle "500px" string format
        if (typeof tableHeight === 'string' && tableHeight.endsWith('px')) {
            const totalHeight = parseInt(tableHeight, 10);
            const bodyHeight = totalHeight - TOTAL_FIXED_HEIGHT;
            return `${Math.max(bodyHeight, 150)}px`;
        }

        // Handle number format
        if (typeof tableHeight === 'number') {
            const bodyHeight = tableHeight - TOTAL_FIXED_HEIGHT;
            return `${Math.max(bodyHeight, 150)}px`;
        }

        // For other CSS values (calc, vh, etc.), return a reasonable default
        return '400px';
    }, [tableHeight]);

    // Default body templates for common field types
    const defaultBodyTemplates = {
        status: (rowData, column) => {
            const value = rowData[column.field];
            const severityMap = {
                active: 'success',
                draft: 'warning',
                published: 'success',
                submitted: 'info',
                approved: 'success',
                rejected: 'danger',
                cancelled: 'danger',
                pending: 'warning',
            };
            const severity = severityMap[value?.toLowerCase()] || 'info';
            return <Tag value={value} severity={severity} />;
        },
        tag: (rowData, column) => {
            const value = rowData[column.field];
            return <Tag value={value} className="p-tag-rounded" />;
        },
        tags: (rowData, column) => {
            const values = rowData[column.field] || [];
            return (
                <div className="flex gap-1 flex-wrap">
                    {values.length > 0 ? (
                        values.map((val, idx) => (
                            <Tag key={idx} value={val} severity="info" className="text-xs" />
                        ))
                    ) : (
                        <span className="text-500">—</span>
                    )}
                </div>
            );
        },
        date: (rowData, column) => {
            const value = rowData[column.field];
            return value ? new Date(value).toLocaleDateString() : '—';
        },
        datetime: (rowData, column) => {
            const value = rowData[column.field];
            return value ? new Date(value).toLocaleString() : '—';
        },
        boolean: (rowData, column) => {
            const value = rowData[column.field];
            return (
                <i className={`pi ${value ? 'pi-check text-green-500' : 'pi-times text-500'}`}></i>
            );
        },
        icon: (rowData, column) => {
            const icon = rowData[column.field];
            const color = rowData[column.colorField] || '#6366f1';
            return <i className={icon} style={{ fontSize: '1.5rem', color }}></i>;
        },
    };

    // Render column body based on type
    const renderColumnBody = (column) => {
        if (column.body) {
            return column.body;
        }

        if (column.type && defaultBodyTemplates[column.type]) {
            return (rowData) => defaultBodyTemplates[column.type](rowData, column);
        }

        // ✅ DEFAULT: dot-path-safe rendering
        return (rowData) => resolveValue(rowData, column.field);
    };

    // Header with search and actions
    const renderHeader = () => {
        return (
            <div className="flex justify-content-between align-items-center gap-3 flex-wrap">
                <div className="flex-1">
                    {showSearch && (
                        <span className="p-input-icon-left" style={{ maxWidth: '400px' }}>
                            <InputText
                                value={globalFilter}
                                onChange={(e) => setGlobalFilter(e.target.value)}
                                placeholder="Search..."
                                className="w-full"
                            />
                        </span>
                    )}
                </div>
                <div className="flex gap-2">
                    {customActions.map((action, idx) => (
                        <Button
                            key={idx}
                            label={action.label}
                            icon={action.icon}
                            className={action.className}
                            onClick={action.onClick}
                            tooltip={action.tooltip}
                        />
                    ))}
                    {showRefreshButton && onRefresh && (
                        <Button
                            icon="pi pi-refresh"
                            className="p-button-outlined"
                            onClick={onRefresh}
                            tooltip="Refresh"
                            tooltipOptions={{ position: 'top' }}
                        />
                    )}
                    {showCreateButton && onCreate && (
                        <Button label={createButtonLabel} icon="pi pi-plus" onClick={onCreate} />
                    )}
                </div>
            </div>
        );
    };

    if (loading && data.length === 0) {
        return (
            <div className="text-center py-6">
                <ProgressSpinner />
                <p className="text-color-secondary mt-3">Loading...</p>
            </div>
        );
    }

    return (
        <div className="list-viewer">
            {title && (
                <div className="mb-3">
                    <h2 className="text-2xl font-bold m-0">{title}</h2>
                </div>
            )}

            {headerContent && <div className="mb-3">{headerContent}</div>}

            <DataTable
                value={data}
                lazy={false}
                paginator={paginator}
                rows={rows}
                rowsPerPageOptions={rowsPerPageOptions}
                loading={loading}
                paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords} entries"
                stripedRows
                className="list-viewer-table"
                emptyMessage={emptyMessage}
                paginatorClassName="border-top-1 surface-border"
                responsiveLayout="scroll"
                scrollable
                scrollHeight={scrollHeight}
                globalFilter={globalFilter}
                header={renderHeader()}
                onRowClick={(e) => onRowClick && onRowClick(e.data)}
                rowHover
            >
                {columns
                    .filter((col) => col.visible !== false) // ← THIS LINE DOES THE MAGIC
                    .map((col, index) => (
                        <Column
                            key={index} // Safe and recommended
                            field={col.field}
                            header={col.header}
                            body={renderColumnBody(col)}
                            sortable={col.sortable !== false}
                            filter={col.filter}
                            filterPlaceholder={col.filterPlaceholder}
                            style={col.style}
                            className={col.className}
                            frozen={col.frozen}
                            alignFrozen={col.alignFrozen}
                        />
                    ))}
            </DataTable>

            {footerContent && <div className="mt-3">{footerContent}</div>}
        </div>
    );
};

export default ListViewer;
