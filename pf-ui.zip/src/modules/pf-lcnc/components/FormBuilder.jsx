import React, { useState, useRef, useEffect, useMemo, useCallback } from 'react';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';
import Section from '@shared/components/Section';
import { Splitter, SplitterPanel } from 'primereact/splitter';
import { useLocation, useNavigate } from 'react-router';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { classNames } from 'primereact/utils';

import {
    DndContext,
    closestCenter,
    KeyboardSensor,
    PointerSensor,
    useSensor,
    useSensors,
} from '@dnd-kit/core';
import { arrayMove, SortableContext, verticalListSortingStrategy } from '@dnd-kit/sortable';
import { useSortable } from '@dnd-kit/sortable';
import { CSS } from '@dnd-kit/utilities';

import PropertiesPanel from './propertiesPanel/PropertiesPanel';
import { mapFromBackendFieldType } from './autoSchema/fieldTypeReverseMapping';
import { useDoctypeSchemaPersistence } from '../hooks/useDoctypeSchemaPersistence';
import { useDoctypeSchemaLoader } from '../hooks/useDoctypeSchemaLoader';
import ListViewConfigEditor from '../screens/ListViewConfigEditor';

import '../styles/FormBuilder.scss';

// ============================================================================
// SECTION 1: CONSTANTS & CONFIGURATION
// ============================================================================

const EDITOR_MODES = {
    CREATE: 'create',
    EDIT: 'edit',
    TEMPLATE: 'template',
};

const SAVE_STATUS = {
    NOT_SAVED: 'Not Saved',
    MODIFIED: 'Modified',
    SAVING: 'Saving',
    SAVED: 'Saved',
    LOADED: 'Loaded',
    ERROR: 'Error',
};

const FIELD_TYPE_MAP = {
    text: 'Data',
    textarea: 'Small Text',
    number: 'Float',
    currency: 'Currency',
    int: 'Int',
    checkbox: 'Check',
    date: 'Date',
    datetime: 'Datetime',
    select: 'Select',
    link: 'Link',
    button: 'Button',
    table: 'Table',
    radio: 'Radio',
};

// Mock data - Replace with real API
const AVAILABLE_DOCTYPES = ['Customer', 'Item', 'Order', 'Address', 'User'];

const DOCTYPE_FIELDS_MAP = {
    Customer: ['full_name', 'email', 'phone'],
    Item: ['item_name', 'sku', 'price'],
    Order: ['order_number', 'order_date', 'customer'],
    Address: ['line1', 'city', 'postal_code'],
    User: ['username', 'role', 'status'],
};

// ============================================================================
// SECTION 2: UTILITY FUNCTIONS
// ============================================================================

/**
 * Converts a label to a valid field name
 */
const toFieldName = (label, type) => {
    if (!label || typeof label !== 'string') {
        return `${type || 'field'}_${crypto.randomUUID().slice(0, 8)}`;
    }

    return label
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, '_')
        .concat(`_${type || 'field'}`);
};

/**
 * Converts a label to a valid tab name
 */
const toTabName = (label) => {
    if (!label || typeof label !== 'string') {
        return `tab_${crypto.randomUUID().slice(0, 8)}`;
    }

    return label
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, '_');
};

/**
 * Converts a label to a valid section name
 */
const toSectionName = (label) => {
    if (!label || typeof label !== 'string') {
        return `section_${crypto.randomUUID().slice(0, 8)}`;
    }

    return label
        .trim()
        .toLowerCase()
        .replace(/[^a-z0-9\s]/g, '')
        .replace(/\s+/g, '_')
        .concat('_section');
};

/**
 * Ensures field name is unique within a collection
 */
const ensureUniqueFieldName = (baseName, existingFields = []) => {
    const existing = new Set(existingFields.map((f) => f.fieldname));

    if (!existing.has(baseName)) {
        return baseName;
    }

    let counter = 2;
    let uniqueName = `${baseName}_${counter}`;

    while (existing.has(uniqueName)) {
        counter += 1;
        uniqueName = `${baseName}_${counter}`;
    }

    return uniqueName;
};

/**
 * Creates a new tab with default structure
 */
const createTab = (label = 'Tab', order = 1) => ({
    id: crypto.randomUUID(),
    name: toTabName(label),
    label,
    order,
    sections: [],
});

/**
 * Creates a new section with default structure
 */
const createSection = (label = 'Section') => ({
    id: crypto.randomUUID(),
    name: toSectionName(label),
    label,
    order: 0,
    fields: [],
});

/**
 * Creates a new field with default structure
 */
const createField = ({ label, type, existingFields = [] }) => {
    const id = crypto.randomUUID();
    const baseFieldName = toFieldName(label, type);
    const uniqueFieldName = ensureUniqueFieldName(baseFieldName, existingFields);

    return {
        id,
        name: id,
        fieldname: uniqueFieldName,
        label,
        type,

        required: false,
        unique: false,
        read_only: false,
        indexed: false,

        default: null,
        options: [],

        foreignReference: null,
        foreignReferenceKey: null,

        ui: {
            width: 12,
            placeholder: '',
            helpText: '',
        },

        validation: {
            minLength: null,
            maxLength: null,
            regex: null,
            min: null,
            max: null,
        },
    };
};

/**
 * Generates default ListView configuration from fields
 */
const generateDefaultListViewConfig = (fields) => {
    // Get only regular fields (exclude structural fields)
    const regularFields = fields.filter(
        (f) => !['Tab Break', 'Section Break', 'Column Break'].includes(f.fieldtype),
    );

    // Take first 5-6 fields as default visible columns
    const defaultColumns = regularFields.slice(0, 6).map((field) => ({
        fieldname: field.fieldname,
        label: field.label,
        visible: true,
    }));

    return {
        columns: defaultColumns,
    };
};

// ============================================================================
// SECTION 3: SCHEMA VALIDATION
// ============================================================================

/**
 * Validates incoming schema structure
 */
const validateSchema = (schema) => {
    const errors = [];
    const warnings = [];

    if (!schema) {
        return { valid: true, errors: [], warnings: [], isEmpty: true };
    }

    if (typeof schema !== 'object' || Array.isArray(schema)) {
        errors.push('Schema must be a plain object');
        return { valid: false, errors, warnings, schema: null };
    }

    if (schema.fields !== undefined) {
        if (!Array.isArray(schema.fields)) {
            errors.push('Schema.fields must be an array');
            return { valid: false, errors, warnings, schema: null };
        }

        schema.fields.forEach((field, index) => {
            if (!field || typeof field !== 'object') {
                errors.push(`Field at index ${index} is not a valid object`);
                return;
            }

            if (!field.fieldname) {
                errors.push(`Field at index ${index} is missing 'fieldname'`);
            }

            if (!field.fieldtype) {
                errors.push(
                    `Field at index ${index} (${field.fieldname || 'unnamed'}) is missing 'fieldtype'`,
                );
            }

            if (!field.label) {
                warnings.push(`Field '${field.fieldname}' is missing 'label', will use fieldname`);
            }
        });
    }

    if (schema.doctypeName && typeof schema.doctypeName !== 'string') {
        errors.push("Doctype's Name must be a string");
    }

    return {
        valid: errors.length === 0,
        errors,
        warnings,
        isEmpty: false,
    };
};

/**
 * Validates schema before saving
 */
const validateSchemaForSave = (schema) => {
    const errors = [];

    if (!schema.doctypeName || schema.doctypeName.trim() === '') {
        errors.push('Doctype name is required');
    }

    if (schema.doctypeName && schema.doctypeName.trim() === 'New Doctype') {
        errors.push('Please provide a meaningful doctype name');
    }

    if (!schema.fields || schema.fields.length === 0) {
        errors.push('At least one field is required');
    }

    // Check for duplicate fieldnames
    const fieldnames = schema.fields?.map((f) => f.fieldname) || [];
    const duplicates = fieldnames.filter((name, idx) => fieldnames.indexOf(name) !== idx);

    if (duplicates.length > 0) {
        errors.push(`Duplicate field names found: ${[...new Set(duplicates)].join(', ')}`);
    }

    return { valid: errors.length === 0, errors };
};

// ============================================================================
// SECTION 4: SCHEMA IMPORT (Backend → UI)
// ============================================================================

/**
 * Parses a single field from backend format to UI format
 */
const parseFieldToUI = (field) => ({
    id: crypto.randomUUID(), //GENERATING RANDOM UUID FOR EACH FIELD
    name: field.fieldname,
    fieldname: field.fieldname, //USED AS THE FIELD IN THE LISTVIEW CONFIG
    label: field.label || field.fieldname, //USED AS THE LABEL IN THE LISTVIEW CONFIG
    type: mapFromBackendFieldType(field.fieldtype),

    required: !!field.reqd,
    unique: !!field.unique,
    read_only: !!field.read_only,
    indexed: !!field.search_index,
    default: field.default ?? null,

    options:
        (field.fieldtype === 'Select' || field.fieldtype === 'Radio') && field.options
            ? field.options.split('\n').filter((opt) => opt.trim())
            : [],

    foreignReference: field.foreignReference ?? field.options ?? null,
    foreignReferenceKey: field.foreignReferenceKey ?? null,

    width: field.columns || 12,
    placeholder: field.placeholder || '',
    helpText: field.description || '',

    minLength: field.min_length ?? null,
    maxLength: field.max_length ?? null,
    regex: field.regex_pattern ?? null,
    min: field.min ?? null,
    max: field.max ?? null,
});

/**
 * Imports a backend schema and converts it to UI structure
 */
const importSchemaToUI = (schema) => {
    // Validate first
    const validation = validateSchema(schema);

    if (!validation.valid) {
        console.error('Schema validation failed:', validation.errors);
        return { tabs: null, errors: validation.errors, warnings: validation.warnings };
    }

    if (validation.isEmpty || !schema?.fields?.length) {
        return { tabs: null, errors: [], warnings: [], isEmpty: true };
    }

    if (validation.warnings.length > 0) {
        console.warn('Schema import warnings:', validation.warnings);
    }

    // Sort by idx
    const sorted = [...schema.fields].sort((a, b) => (a.idx || 0) - (b.idx || 0));

    const tabs = [];
    let currentTab = null;
    let currentSection = null;

    for (const field of sorted) {
        // Handle Tab Break
        if (field.fieldtype === 'Tab Break') {
            currentTab = {
                id: crypto.randomUUID(),
                name: field.fieldname,
                label: field.label || field.fieldname,
                sections: [],
            };
            tabs.push(currentTab);
            currentSection = null;
            continue;
        }

        // Handle Section Break
        if (field.fieldtype === 'Section Break') {
            if (!currentTab) {
                currentTab = {
                    id: crypto.randomUUID(),
                    name: 'tab_1',
                    label: 'Tab 1',
                    sections: [],
                };
                tabs.push(currentTab);
            }

            currentSection = {
                id: crypto.randomUUID(),
                name: field.fieldname,
                label: field.label || 'Section',
                fields: [],
            };
            currentTab.sections.push(currentSection);
            continue;
        }

        // Handle Column Break (skip for layout purposes)
        if (field.fieldtype === 'Column Break') {
            continue;
        }

        // Handle regular fields - ensure we have a tab and section
        if (!currentTab) {
            currentTab = {
                id: crypto.randomUUID(),
                name: 'tab_1',
                label: 'Tab 1',
                sections: [],
            };
            tabs.push(currentTab);
        }

        if (!currentSection) {
            currentSection = {
                id: crypto.randomUUID(),
                name: 'section_default',
                label: 'Details',
                fields: [],
            };
            currentTab.sections.push(currentSection);
        }

        currentSection.fields.push(parseFieldToUI(field));
    }

    return {
        tabs: tabs.length > 0 ? tabs : null,
        errors: [],
        warnings: validation.warnings,
    };
};

/**
 * Extracts doctype metadata from schema
 */
const extractDoctypeMeta = (schema) => {
    if (!schema) return null;

    const now = new Date().toISOString();

    return {
        id: schema.id ?? null,
        doctypeName: schema.doctypeName ?? schema.doctypeName ?? 'New Doctype',
        module: schema.module ?? 'UN-ASSIGNED',
        description: schema.description ?? '',

        is_submittable: schema.is_submittable ?? 0,
        is_tree: schema.is_tree ?? 0,
        issingle: schema.issingle ?? 0,
        istable: schema.istable ?? 0,

        track_changes: schema.track_changes ?? 1,
        track_seen: schema.track_seen ?? 0,
        track_views: schema.track_views ?? 0,

        allow_rename: schema.allow_rename ?? 1,
        allow_copy: schema.allow_copy ?? 1,
        allow_import: schema.allow_import ?? 1,
        allow_events_in_timeline: schema.allow_events_in_timeline ?? 1,
        allow_auto_repeat: schema.allow_auto_repeat ?? 0,

        custom: schema.custom ?? 1,

        creation: schema.creation ?? now,
        modified: schema.modified ?? now,
        modified_by: schema.modified_by ?? 'Administrator',
        owner: schema.owner ?? 'Administrator',
    };
};

// ============================================================================
// SECTION 5: SCHEMA EXPORT (UI → Backend)
// ============================================================================

/**
 * Maps UI field type to backend field type
 */
const mapToBackendFieldType = (uiType) => {
    return FIELD_TYPE_MAP[uiType] || 'Data';
};

/**
 * Generates complete schema from UI state
 */
const generateRenderSchema = ({ tabs, doctypeMeta, listViewConfig }) => {
    const flatFields = [];
    let idx = 1;

    if (!tabs || tabs.length === 0) {
        return {
            ...doctypeMeta,
            fields: [],
            listview_config: listViewConfig || { columns: [] },
        };
    }

    for (const tab of tabs) {
        // Filter sections that have at least one field
        const sectionsWithFields = (tab.sections || []).filter(
            (section) => section.fields && section.fields.length > 0,
        );

        // Skip tab if no sections with fields
        if (sectionsWithFields.length === 0) {
            continue;
        }

        // Add Tab Break
        flatFields.push({
            fieldname: tab.name,
            label: tab.label,
            fieldtype: 'Tab Break',
            idx: idx++,
        });

        for (const section of sectionsWithFields) {
            // Add Section Break
            flatFields.push({
                fieldname: section.name,
                label: section.label,
                fieldtype: 'Section Break',
                idx: idx++,
            });

            // Add fields
            for (const field of section.fields) {
                const fieldData = {
                    fieldname: field.fieldname,
                    label: field.label,
                    fieldtype: mapToBackendFieldType(field.type),

                    reqd: field.required ? 1 : 0,
                    unique: field.unique ? 1 : 0,
                    read_only: field.read_only ? 1 : 0,
                    search_index: field.indexed ? 1 : 0,

                    default: field.default ?? null,
                    idx: idx++,

                    foreignReference: field.foreignReference ?? null,
                    foreignReferenceKey: field.foreignReferenceKey ?? null,

                    placeholder: field.ui?.placeholder ?? null,
                    description: field.ui?.helpText ?? null,
                    columns: field.ui?.width ?? null,

                    min_length: field.validation?.minLength ?? null,
                    max_length: field.validation?.maxLength ?? null,
                    regex_pattern: field.validation?.regex ?? null,
                    min: field.validation?.min ?? null,
                    max: field.validation?.max ?? null,
                };

                // Handle select/radio options
                if (
                    (field.type === 'select' || field.type === 'radio') &&
                    Array.isArray(field.options) &&
                    field.options.length > 0
                ) {
                    fieldData.options = field.options.join('\n');
                }

                // Handle link field options
                if (field.type === 'link' && field.foreignReference) {
                    fieldData.options = field.foreignReference;
                }

                flatFields.push(fieldData);
            }
        }
    }

    return {
        id: doctypeMeta.id ?? null,

        // ✅ NEW FIELD
        doctypeName: doctypeMeta.doctypeName,

        module: doctypeMeta.module,
        description: doctypeMeta.description,

        is_submittable: doctypeMeta.is_submittable,
        is_tree: doctypeMeta.is_tree,
        issingle: doctypeMeta.issingle,
        istable: doctypeMeta.istable,

        track_changes: doctypeMeta.track_changes,
        track_seen: doctypeMeta.track_seen,
        track_views: doctypeMeta.track_views,

        allow_rename: doctypeMeta.allow_rename,
        allow_copy: doctypeMeta.allow_copy,
        allow_import: doctypeMeta.allow_import,
        allow_events_in_timeline: doctypeMeta.allow_events_in_timeline,
        allow_auto_repeat: doctypeMeta.allow_auto_repeat,

        custom: doctypeMeta.custom,
        creation: doctypeMeta.creation,
        modified_by: doctypeMeta.modified_by,
        owner: doctypeMeta.owner,

        modified: new Date().toISOString(),
        fields: flatFields,
        listview_config: listViewConfig || generateDefaultListViewConfig(flatFields),
    };
};

// ============================================================================
// SECTION 6: INITIALIZATION HELPERS
// ============================================================================

/**
 * Determines the editor mode based on initial schema
 */
const determineEditorMode = (schema) => {
    if (!schema) return EDITOR_MODES.CREATE;
    if (schema.id) return EDITOR_MODES.EDIT;
    if (schema.fields?.length > 0) return EDITOR_MODES.TEMPLATE;
    return EDITOR_MODES.CREATE;
};

/**
 * Creates initial state from schema (used for lazy initialization)
 */
const createInitialState = (schema) => {
    const mode = determineEditorMode(schema);

    // Try to import schema
    const { tabs: importedTabs, errors, warnings } = importSchemaToUI(schema);

    if (errors.length > 0) {
        console.error('Schema import errors:', errors);
    }

    // Create default tab if no tabs imported
    const defaultTab = createTab('Tab 1', 1);
    const tabs = importedTabs && importedTabs.length > 0 ? importedTabs : [defaultTab];
    const firstTabId = tabs[0].id;

    // Extract metadata (single source of truth for doctype name)
    const doctypeMeta = extractDoctypeMeta(schema) || {
        id: null,
        doctype: 'New Doctype',
        module: 'UN-ASSIGNED',
        description: '',
        is_submittable: 0,
        is_tree: 0,
        issingle: 0,
        istable: 0,
        track_changes: 1,
        track_seen: 0,
        track_views: 0,
        allow_rename: 1,
        allow_copy: 1,
        allow_import: 1,
        allow_events_in_timeline: 1,
        allow_auto_repeat: 0,
        custom: 1,
        creation: new Date().toISOString(),
        modified: new Date().toISOString(),
        modified_by: 'Administrator',
        owner: 'Administrator',
    };

    // Extract or generate default ListView config
    const listViewConfig =
        schema?.listview_config || generateDefaultListViewConfig(schema?.fields || []);

    return {
        tabs,
        activeTab: firstTabId,
        selectedItem: { type: 'tab', id: firstTabId },
        listViewConfig,
        doctypeMeta,
        editorMode: mode,
        saveStatus: mode === EDITOR_MODES.EDIT ? SAVE_STATUS.LOADED : SAVE_STATUS.NOT_SAVED,
    };
};

// ============================================================================
// SECTION 7: SUB-COMPONENTS
// ============================================================================

/**
 * Editable Tab Label Component
 */
const EditableTabLabel = ({ value, onSave, isPreview }) => {
    const [editing, setEditing] = useState(false);
    const [tempValue, setTempValue] = useState(value);
    const inputRef = useRef(null);

    useEffect(() => {
        if (editing && inputRef.current) {
            inputRef.current.focus();
            inputRef.current.select();
        }
    }, [editing]);

    useEffect(() => {
        setTempValue(value);
    }, [value]);

    const handleSave = () => {
        const trimmed = tempValue.trim();
        if (trimmed && trimmed !== value) {
            onSave?.(trimmed);
        } else {
            setTempValue(value);
        }
        setEditing(false);
    };

    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            handleSave();
        } else if (e.key === 'Escape') {
            setTempValue(value);
            setEditing(false);
        }
        e.stopPropagation();
    };

    if (editing && !isPreview) {
        return (
            <input
                ref={inputRef}
                type="text"
                value={tempValue}
                onChange={(e) => setTempValue(e.target.value)}
                onBlur={handleSave}
                onKeyDown={handleKeyDown}
                onClick={(e) => e.stopPropagation()}
                className="px-2 py-1 border border-primary rounded text-sm font-medium bg-white min-w-[80px] max-w-[150px]"
                style={{ outline: 'none' }}
            />
        );
    }

    return (
        <span
            onDoubleClick={(e) => {
                if (!isPreview) {
                    e.stopPropagation();
                    setEditing(true);
                }
            }}
            className={!isPreview ? 'cursor-text hover:text-primary' : ''}
            title={!isPreview ? 'Double-click to rename' : undefined}
        >
            {value}
        </span>
    );
};

/**
 * Sortable Section Wrapper Component
 */
const SortableSectionWrapper = ({ children, sectionId, isPreview }) => {
    const { attributes, listeners, setNodeRef, transform, transition, isDragging } = useSortable({
        id: sectionId,
        disabled: isPreview,
    });

    const style = {
        transform: CSS.Transform.toString(transform),
        transition,
        position: 'relative',
        pointerEvents: isDragging ? 'none' : 'auto',
        opacity: isDragging ? 0.8 : 1,
        zIndex: isDragging ? 10 : 1,
    };

    return (
        <div ref={setNodeRef} style={style} {...attributes} {...listeners} className="mb-4">
            {children}
        </div>
    );
};

/**
 * ListView Configurator Component
 */
const ListViewConfigurator = ({ allFields, listViewConfig, onUpdate }) => {
    // Get all regular fields from tabs (UI format uses 'type' not 'fieldtype')
    const availableFields = useMemo(() => {
        console.log('[FORM BUILDER FIELDS ⚠️:]', allFields);
        return allFields.filter((f) => f.type); // Just filter out any null/undefined types
    }, [allFields]);

    const handleToggleColumn = (fieldname) => {
        const columns = listViewConfig?.columns || [];
        const existingIndex = columns.findIndex((c) => c.fieldname === fieldname);

        if (existingIndex !== -1) {
            // Remove column
            const newColumns = columns.filter((c) => c.fieldname !== fieldname);
            onUpdate({ columns: newColumns });
        } else {
            // Add column
            const field = availableFields.find((f) => f.fieldname === fieldname);
            if (field) {
                const newColumns = [
                    ...columns,
                    {
                        fieldname: field.fieldname,
                        label: field.label,
                        visible: true,
                    },
                ];
                onUpdate({ columns: newColumns });
            }
        }
    };

    const isColumnVisible = (fieldname) => {
        return listViewConfig?.columns?.some((c) => c.fieldname === fieldname) || false;
    };

    if (availableFields.length === 0) {
        return (
            <div
                className="flex align-items-center justify-content-center"
                style={{ minHeight: '400px' }}
            >
                <div className="text-center">
                    <i className="pi pi-inbox text-6xl text-400 mb-4"></i>
                    <h3 className="text-xl font-semibold text-700 mb-2">No Fields Available</h3>
                    <p className="text-600 mb-4">
                        Add fields in the Form tab first to configure the list view.
                    </p>
                </div>
            </div>
        );
    }

    const selectedCount = listViewConfig?.columns?.length || 0;

    return (
        <div className="p-4">
            {/* Header Section */}
            <div className="mb-4">
                <h2 className="text-2xl font-bold text-900 mb-2">List View Configuration</h2>
                <p className="text-600 text-base">
                    Select which fields should be visible as columns in the record list table.
                </p>
            </div>

            {/* Stats Card */}
            <div className="surface-card shadow-2 border-round p-4 mb-4">
                <div className="flex align-items-center justify-content-between">
                    <div className="flex align-items-center gap-3">
                        <div className="bg-primary border-round p-3">
                            <i className="pi pi-table text-white text-2xl"></i>
                        </div>
                        <div>
                            <div className="text-500 text-sm mb-1">Selected Columns</div>
                            <div className="text-900 font-bold text-xl">
                                {selectedCount} of {availableFields.length}
                            </div>
                        </div>
                    </div>
                    <div className="text-right">
                        <div className="text-500 text-sm mb-1">Available Fields</div>
                        <div className="text-900 font-semibold text-lg">
                            {availableFields.length}
                        </div>
                    </div>
                </div>
            </div>

            {/* Fields List */}
            <div className="surface-card shadow-2 border-round overflow-hidden">
                {/* List Header */}
                <div className="bg-primary-50 px-4 py-3 border-bottom-1 surface-border">
                    <div className="flex align-items-center justify-content-between">
                        <h3 className="text-900 font-semibold text-lg m-0">Available Fields</h3>
                        <span className="text-600 text-sm">Click to toggle visibility</span>
                    </div>
                </div>

                {/* Scrollable List */}
                <div className="overflow-y-auto" style={{ maxHeight: '500px' }}>
                    {availableFields.map((field, index) => {
                        const isVisible = isColumnVisible(field.fieldname);
                        const fieldType = mapToBackendFieldType(field.type);

                        return (
                            <div
                                key={field.fieldname}
                                className={`
                                    px-4 py-3 
                                    border-bottom-1 surface-border
                                    hover:surface-100
                                    cursor-pointer
                                    transition-colors transition-duration-150
                                    ${isVisible ? 'bg-primary-50' : ''}
                                `}
                                onClick={() => handleToggleColumn(field.fieldname)}
                            >
                                <div className="flex align-items-center gap-3">
                                    {/* Checkbox */}
                                    <div className="flex align-items-center">
                                        <div
                                            className={`
                                                border-2 border-round 
                                                w-1rem h-1rem 
                                                flex align-items-center justify-content-center
                                                transition-all transition-duration-150
                                                ${
                                                    isVisible
                                                        ? 'bg-primary border-primary'
                                                        : 'border-300 bg-white'
                                                }
                                            `}
                                        >
                                            {isVisible && (
                                                <i className="pi pi-check text-white text-xs"></i>
                                            )}
                                        </div>
                                    </div>

                                    {/* Field Info */}
                                    <div className="flex-1">
                                        <div className="flex align-items-center gap-2 mb-1">
                                            <span className="text-900 font-semibold">
                                                {field.label}
                                            </span>
                                            {isVisible && (
                                                <span className="bg-primary text-white px-2 py-1 border-round text-xs font-semibold">
                                                    VISIBLE
                                                </span>
                                            )}
                                        </div>
                                        <div className="flex align-items-center gap-3">
                                            <span className="text-600 text-sm">
                                                <i className="pi pi-tag text-400 mr-1"></i>
                                                {field.fieldname}
                                            </span>
                                            <span className="text-500 text-sm">
                                                <i className="pi pi-database text-400 mr-1"></i>
                                                {fieldType}
                                            </span>
                                        </div>
                                    </div>

                                    {/* Required Badge */}
                                    {field.required && (
                                        <span className="bg-orange-100 text-orange-900 px-2 py-1 border-round text-xs font-semibold">
                                            REQUIRED
                                        </span>
                                    )}

                                    {/* Toggle Icon */}
                                    <div className="text-400">
                                        <i
                                            className={`pi ${isVisible ? 'pi-eye' : 'pi-eye-slash'}`}
                                        ></i>
                                    </div>
                                </div>
                            </div>
                        );
                    })}
                </div>
            </div>

            {/* Info Message */}
            <div className="mt-4 surface-card shadow-1 border-round border-1 border-primary-200 p-4">
                <div className="flex align-items-start gap-3">
                    <div className="flex-shrink-0">
                        <i className="pi pi-info-circle text-primary text-xl"></i>
                    </div>
                    <div>
                        <h4 className="text-primary font-semibold text-base m-0 mb-2">
                            List View Tips
                        </h4>
                        <ul className="text-600 text-sm m-0 pl-3" style={{ lineHeight: '1.8' }}>
                            <li>Selected fields will appear as columns in the record list table</li>
                            <li>Click on any field to toggle its visibility</li>
                            <li>The order shown here will be the default column order</li>
                            <li>You can always modify this configuration later</li>
                        </ul>
                    </div>
                </div>
            </div>

            {/* Quick Actions */}
            <div className="mt-4 flex gap-2">
                <button
                    className="p-button p-component p-button-outlined flex-1"
                    onClick={() => {
                        // Select all fields
                        const allColumns = availableFields.map((f) => ({
                            fieldname: f.fieldname,
                            label: f.label,
                            visible: true,
                        }));
                        onUpdate({ columns: allColumns });
                    }}
                >
                    <i className="pi pi-check-square mr-2"></i>
                    Select All
                </button>
                <button
                    className="p-button p-component p-button-outlined p-button-secondary flex-1"
                    onClick={() => {
                        // Clear all selections
                        onUpdate({ columns: [] });
                    }}
                >
                    <i className="pi pi-times mr-2"></i>
                    Clear All
                </button>
            </div>
        </div>
    );
};

/**
 * Form Builder Header Component
 */
const FormBuilderHeader = ({
    doctypeName,
    saveStatus,
    isPreview,
    isSaving,
    onTogglePreview,
    onSave,
    onGoToRecordList,
}) => {
    /**
     * Maps save status to PrimeReact Tag severity
     */
    const getStatusSeverity = () => {
        switch (saveStatus) {
            case SAVE_STATUS.SAVED:
                return 'success';
            case SAVE_STATUS.LOADED:
                return 'info';
            case SAVE_STATUS.ERROR:
                return 'danger';
            case SAVE_STATUS.MODIFIED:
                return 'warning';
            case SAVE_STATUS.SAVING:
                return 'info';
            default:
                return 'secondary'; // NOT_SAVED
        }
    };

    /**
     * Gets the appropriate icon for the status
     */
    const getStatusIcon = () => {
        switch (saveStatus) {
            case SAVE_STATUS.SAVED:
                return 'pi pi-check-circle';
            case SAVE_STATUS.LOADED:
                return 'pi pi-cloud-download';
            case SAVE_STATUS.ERROR:
                return 'pi pi-exclamation-circle';
            case SAVE_STATUS.MODIFIED:
                return 'pi pi-pencil';
            case SAVE_STATUS.SAVING:
                return 'pi pi-spin pi-spinner';
            default:
                return 'pi pi-circle';
        }
    };

    return (
        <header className="form-builder-header surface-card px-4 py-3 border-1 surface-border border-round-md">
            <div className="flex align-items-center justify-content-between flex-wrap gap-3">
                {/* Left Side - Title and Status */}
                <div className="flex align-items-center gap-3">
                    <h1 className="form-builder-header__title m-0 text-l font-semibold text-900">
                        {doctypeName}
                    </h1>
                    <Tag
                        value={saveStatus}
                        severity={getStatusSeverity()}
                        icon={getStatusIcon()}
                        className="text-sm"
                    />
                </div>

                {/* Right Side - Action Buttons */}
                <div className="flex align-items-center gap-2 flex-wrap">
                    {/* Go to List Button */}
                    <Button
                        label={`Go to ${doctypeName} List`}
                        icon="pi pi-list"
                        className="p-button-outlined p-button-sm"
                        onClick={onGoToRecordList}
                    />

                    {/* Preview Toggle Button */}
                    <Button
                        label={isPreview ? 'Edit Mode' : 'Show Preview'}
                        icon={isPreview ? 'pi pi-pencil' : 'pi pi-eye'}
                        className={classNames('p-button-sm', {
                            'p-button-outlined': !isPreview,
                            'p-button-warning': isPreview,
                        })}
                        onClick={onTogglePreview}
                    />

                    {/* Navigation Buttons */}
                    <div className="flex align-items-center gap-1">
                        <Button
                            icon="pi pi-chevron-left"
                            className="p-button-text p-button-sm p-button-secondary"
                            tooltip="Previous"
                            tooltipOptions={{ position: 'bottom' }}
                            aria-label="Previous"
                        />

                        <Button
                            icon="pi pi-chevron-right"
                            className="p-button-text p-button-sm p-button-secondary"
                            tooltip="Next"
                            tooltipOptions={{ position: 'bottom' }}
                            aria-label="Next"
                        />
                    </div>

                    {/* Utility Buttons */}
                    <div className="flex align-items-center gap-1">
                        <Button
                            icon="pi pi-print"
                            className="p-button-text p-button-sm p-button-secondary"
                            tooltip="Print"
                            tooltipOptions={{ position: 'bottom' }}
                            aria-label="Print"
                        />

                        <Button
                            icon="pi pi-ellipsis-v"
                            className="p-button-text p-button-sm p-button-secondary"
                            tooltip="More options"
                            tooltipOptions={{ position: 'bottom' }}
                            aria-label="More options"
                        />
                    </div>

                    {/* Save Button */}
                    <Button
                        label={isSaving ? 'Saving...' : 'Save'}
                        icon={isSaving ? 'pi pi-spin pi-spinner' : 'pi pi-save'}
                        className="p-button-sm p-button-success"
                        onClick={onSave}
                        disabled={isSaving}
                        loading={isSaving}
                    />
                </div>
            </div>
        </header>
    );
};

// ============================================================================
// SECTION 8: MAIN COMPONENT
// ============================================================================

export default function FormBuilder() {
    // -------------------------------------------------------------------------
    // 8.1: INITIALIZATION
    // -------------------------------------------------------------------------

    const { state: locationState } = useLocation();
    const navigate = useNavigate();

    const initialSchema = locationState?.schema || null;

    // Lazy state initialization - only runs once
    const [state, setState] = useState(() => createInitialState(initialSchema));

    // Destructure state
    const { tabs, activeTab, selectedItem, doctypeMeta, editorMode, saveStatus, listViewConfig } =
        state;

    // Derived doctype name from meta (SINGLE SOURCE OF TRUTH)
    const doctypeName = doctypeMeta.doctypeName;

    // Local UI state
    const [activeMainTab, setActiveMainTab] = useState('form');
    const [hoveredTab, setHoveredTab] = useState(null);
    const [isPreview, setIsPreview] = useState(false);
    const [isSaving, setIsSaving] = useState(false);

    // Refs
    const formCanvasRef = useRef(null);

    // External hooks
    const { saveUISchema } = useDoctypeSchemaPersistence();

    // DnD sensors
    const sensors = useSensors(
        useSensor(PointerSensor, { activationConstraint: { distance: 10 } }),
        useSensor(KeyboardSensor),
    );

    // -------------------------------------------------------------------------
    // 8.2: COMPUTED VALUES (MEMOIZED)
    // -------------------------------------------------------------------------

    const activeTabData = useMemo(
        () => tabs.find((t) => t.id === activeTab) || null,
        [tabs, activeTab],
    );

    const selectedTab = useMemo(() => {
        if (selectedItem.type !== 'tab') return null;
        return tabs.find((t) => t.id === selectedItem.id) || null;
    }, [selectedItem, tabs]);

    const selectedSection = useMemo(() => {
        if (selectedItem.type !== 'section') return null;
        return activeTabData?.sections.find((s) => s.id === selectedItem.id) || null;
    }, [selectedItem, activeTabData]);

    const selectedField = useMemo(() => {
        if (selectedItem.type !== 'field') return null;
        const section = activeTabData?.sections.find((s) => s.id === selectedItem.sectionId);
        return section?.fields.find((f) => f.id === selectedItem.fieldId) || null;
    }, [selectedItem, activeTabData]);

    const selectedData = useMemo(() => {
        switch (selectedItem.type) {
            case 'tab':
                return selectedTab;
            case 'section':
                return selectedSection;
            case 'field':
                return selectedField;
            default:
                return null;
        }
    }, [selectedItem.type, selectedTab, selectedSection, selectedField]);

    // -------------------------------------------------------------------------
    // 8.3: STATE UPDATE HELPERS
    // -------------------------------------------------------------------------

    const goToRecordList = useCallback(() => {
        console.log(doctypeMeta.doctypeName);
        console.log(doctypeMeta.module);
        navigate('/web/landing/form-builder/record-list-view', {
            state: {
                doctypeId: doctypeMeta.id,
            },
        });
    }, [navigate, doctypeMeta]);

    const setTabs = useCallback((updater) => {
        setState((prev) => ({
            ...prev,
            tabs: typeof updater === 'function' ? updater(prev.tabs) : updater,
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const setActiveTab = useCallback((tabId) => {
        setState((prev) => ({
            ...prev,
            activeTab: tabId,
        }));
    }, []);

    const setSelectedItem = useCallback((item) => {
        setState((prev) => ({
            ...prev,
            selectedItem: item,
        }));
    }, []);

    const setSaveStatus = useCallback((status) => {
        setState((prev) => ({
            ...prev,
            saveStatus: status,
        }));
    }, []);

    const setDoctypeMeta = useCallback((updater) => {
        setState((prev) => ({
            ...prev,
            doctypeMeta: typeof updater === 'function' ? updater(prev.doctypeMeta) : updater,
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const setListViewConfig = useCallback((updater) => {
        setState((prev) => ({
            ...prev,
            listViewConfig: typeof updater === 'function' ? updater(prev.listViewConfig) : updater,
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    // -------------------------------------------------------------------------
    // 8.4: EFFECTS
    // -------------------------------------------------------------------------

    // Click outside handler
    useEffect(() => {
        const handleClickOutside = (event) => {
            const propertiesPanel = event.target.closest('.properties-panel');
            if (propertiesPanel) return;

            if (formCanvasRef.current && !formCanvasRef.current.contains(event.target)) {
                setSelectedItem({ type: 'tab', id: activeTab });
            }
        };

        document.addEventListener('mousedown', handleClickOutside);
        return () => document.removeEventListener('mousedown', handleClickOutside);
    }, [activeTab, setSelectedItem]);

    // -------------------------------------------------------------------------
    // 8.5: TAB ACTIONS
    // -------------------------------------------------------------------------

    const addTab = useCallback(() => {
        const newTabLabel = `Tab ${tabs.length + 1}`;
        const newTab = createTab(newTabLabel, tabs.length + 1);

        setState((prev) => ({
            ...prev,
            tabs: [...prev.tabs, newTab],
            activeTab: newTab.id,
            selectedItem: { type: 'tab', id: newTab.id },
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, [tabs.length]);

    const deleteTab = useCallback((tabId, e) => {
        if (e) e.stopPropagation();

        setState((prev) => {
            if (prev.tabs.length <= 1) {
                console.warn('Cannot delete the last tab');
                return prev;
            }

            const newTabs = prev.tabs.filter((t) => t.id !== tabId);
            const wasActive = prev.activeTab === tabId;
            const newActiveTab = wasActive ? newTabs[newTabs.length - 1].id : prev.activeTab;

            return {
                ...prev,
                tabs: newTabs,
                activeTab: newActiveTab,
                selectedItem: wasActive ? { type: 'tab', id: newActiveTab } : prev.selectedItem,
                saveStatus: SAVE_STATUS.MODIFIED,
            };
        });
    }, []);

    const renameTab = useCallback((tabId, newLabel) => {
        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) =>
                tab.id === tabId ? { ...tab, label: newLabel, name: toTabName(newLabel) } : tab,
            ),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const updateTabProperties = useCallback((tabId, updates) => {
        const { id, ...safeUpdates } = updates;

        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => (tab.id === tabId ? { ...tab, ...safeUpdates } : tab)),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const selectTab = useCallback((tabId) => {
        setState((prev) => ({
            ...prev,
            activeTab: tabId,
            selectedItem: { type: 'tab', id: tabId },
        }));
    }, []);

    // -------------------------------------------------------------------------
    // 8.6: SECTION ACTIONS
    // -------------------------------------------------------------------------

    const addSection = useCallback((tabId, afterSectionId = null) => {
        const newSection = createSection('Section');

        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => {
                if (tab.id !== tabId) return tab;

                const sections = [...tab.sections];

                if (afterSectionId) {
                    const index = sections.findIndex((s) => s.id === afterSectionId);
                    sections.splice(index + 1, 0, newSection);
                } else {
                    sections.push(newSection);
                }

                return { ...tab, sections };
            }),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));

        return newSection.id;
    }, []);

    const deleteSection = useCallback((tabId, sectionId) => {
        setState((prev) => {
            const wasSelected =
                prev.selectedItem.type === 'section' && prev.selectedItem.id === sectionId;

            return {
                ...prev,
                tabs: prev.tabs.map((tab) =>
                    tab.id === tabId
                        ? { ...tab, sections: tab.sections.filter((s) => s.id !== sectionId) }
                        : tab,
                ),
                selectedItem: wasSelected ? { type: 'tab', id: prev.activeTab } : prev.selectedItem,
                saveStatus: SAVE_STATUS.MODIFIED,
            };
        });
    }, []);

    const renameSection = useCallback((sectionId, newLabel) => {
        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => ({
                ...tab,
                sections: tab.sections.map((sec) =>
                    sec.id === sectionId
                        ? { ...sec, label: newLabel, name: toSectionName(newLabel) }
                        : sec,
                ),
            })),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const updateSectionProperties = useCallback((sectionId, updates) => {
        const { id, ...safeUpdates } = updates;

        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => ({
                ...tab,
                sections: tab.sections.map((sec) =>
                    sec.id === sectionId ? { ...sec, ...safeUpdates } : sec,
                ),
            })),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const selectSection = useCallback(
        (sectionId) => {
            setSelectedItem({ type: 'section', id: sectionId });
        },
        [setSelectedItem],
    );

    const handleSectionDragEnd = useCallback((event) => {
        const { active, over } = event;
        if (!over || active.id === over.id) return;

        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => {
                if (tab.id !== prev.activeTab) return tab;

                const oldIndex = tab.sections.findIndex((s) => s.id === active.id);
                const newIndex = tab.sections.findIndex((s) => s.id === over.id);

                if (oldIndex === -1 || newIndex === -1) return tab;

                return {
                    ...tab,
                    sections: arrayMove(tab.sections, oldIndex, newIndex),
                };
            }),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    // -------------------------------------------------------------------------
    // 8.7: FIELD ACTIONS
    // -------------------------------------------------------------------------

    const addField = useCallback((sectionId, fieldType = 'text') => {
        setState((prev) => {
            // Find the section to get existing fields
            let existingFields = [];
            for (const tab of prev.tabs) {
                const section = tab.sections.find((s) => s.id === sectionId);
                if (section) {
                    existingFields = section.fields;
                    break;
                }
            }

            const fieldLabel = `Field ${existingFields.length + 1}`;
            const newField = createField({
                label: fieldLabel,
                type: fieldType,
                existingFields,
            });

            return {
                ...prev,
                tabs: prev.tabs.map((tab) => ({
                    ...tab,
                    sections: tab.sections.map((sec) =>
                        sec.id === sectionId ? { ...sec, fields: [...sec.fields, newField] } : sec,
                    ),
                })),
                selectedItem: {
                    type: 'field',
                    sectionId,
                    fieldId: newField.id,
                },
                saveStatus: SAVE_STATUS.MODIFIED,
            };
        });
    }, []);

    const deleteField = useCallback((sectionId, fieldId) => {
        setState((prev) => {
            const wasSelected =
                prev.selectedItem.type === 'field' &&
                prev.selectedItem.sectionId === sectionId &&
                prev.selectedItem.fieldId === fieldId;

            return {
                ...prev,
                tabs: prev.tabs.map((tab) => ({
                    ...tab,
                    sections: tab.sections.map((sec) =>
                        sec.id === sectionId
                            ? { ...sec, fields: sec.fields.filter((f) => f.id !== fieldId) }
                            : sec,
                    ),
                })),
                selectedItem: wasSelected ? { type: 'tab', id: prev.activeTab } : prev.selectedItem,
                saveStatus: SAVE_STATUS.MODIFIED,
            };
        });
    }, []);

    const renameField = useCallback((sectionId, fieldId, newLabel) => {
        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => ({
                ...tab,
                sections: tab.sections.map((sec) => {
                    if (sec.id !== sectionId) return sec;

                    const otherFields = sec.fields.filter((f) => f.id !== fieldId);

                    return {
                        ...sec,
                        fields: sec.fields.map((field) => {
                            if (field.id !== fieldId) return field;

                            const baseFieldName = toFieldName(newLabel, field.type);
                            const uniqueFieldName = ensureUniqueFieldName(
                                baseFieldName,
                                otherFields,
                            );

                            return {
                                ...field,
                                label: newLabel,
                                fieldname: uniqueFieldName,
                            };
                        }),
                    };
                }),
            })),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const updateFieldProperties = useCallback((sectionId, fieldId, updates) => {
        const { id, ...safeUpdates } = updates;

        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => ({
                ...tab,
                sections: tab.sections.map((sec) => {
                    if (sec.id !== sectionId) return sec;

                    return {
                        ...sec,
                        fields: sec.fields.map((field) =>
                            field.id === fieldId ? { ...field, ...safeUpdates } : field,
                        ),
                    };
                }),
            })),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const reorderFields = useCallback((sectionId, newFields) => {
        setState((prev) => ({
            ...prev,
            tabs: prev.tabs.map((tab) => ({
                ...tab,
                sections: tab.sections.map((sec) =>
                    sec.id === sectionId ? { ...sec, fields: newFields } : sec,
                ),
            })),
            saveStatus: SAVE_STATUS.MODIFIED,
        }));
    }, []);

    const selectField = useCallback(
        (sectionId, fieldId) => {
            setSelectedItem({ type: 'field', sectionId, fieldId });
        },
        [setSelectedItem],
    );

    // -------------------------------------------------------------------------
    // 8.8: SCHEMA & SAVE OPERATIONS
    // -------------------------------------------------------------------------

    const handleSave = useCallback(async () => {
        const schema = generateRenderSchema({
            tabs,
            doctypeMeta,
            listViewConfig: state.listViewConfig,
        });

        // Validate before saving
        const validation = validateSchemaForSave(schema);

        if (!validation.valid) {
            console.error('Validation errors:', validation.errors);
            alert(`Cannot save:\n${validation.errors.join('\n')}`);
            return;
        }

        setIsSaving(true);
        setSaveStatus(SAVE_STATUS.SAVING);

        try {
            await saveUISchema(schema);

            console.log('Schema saved successfully');
            console.log(JSON.stringify(schema, null, 2));

            setSaveStatus(SAVE_STATUS.SAVED);
        } catch (err) {
            console.error('Failed to save schema', err);
            setSaveStatus(SAVE_STATUS.ERROR);
        } finally {
            setIsSaving(false);
        }
    }, [tabs, doctypeMeta, state.listViewConfig, saveUISchema, setSaveStatus]);

    const handlePropertyUpdate = useCallback(
        (updates) => {
            if (selectedItem.type === 'tab') {
                updateTabProperties(selectedItem.id, updates);
            } else if (selectedItem.type === 'section') {
                updateSectionProperties(selectedItem.id, updates);
            } else if (selectedItem.type === 'field') {
                updateFieldProperties(selectedItem.sectionId, selectedItem.fieldId, updates);
            }
        },
        [selectedItem, updateTabProperties, updateSectionProperties, updateFieldProperties],
    );

    // -------------------------------------------------------------------------
    // 8.9: RENDER CONFIGURATION
    // -------------------------------------------------------------------------

    const mainTabs = useMemo(
        () => [
            {
                label: 'Form',
                active: activeMainTab === 'form',
                onClick: () => setActiveMainTab('form'),
            },
            {
                label: 'Settings',
                active: activeMainTab === 'settings',
                onClick: () => setActiveMainTab('settings'),
            },
            {
                label: 'Connections',
                active: activeMainTab === 'connections',
                onClick: () => setActiveMainTab('connections'),
            },
        ],
        [activeMainTab],
    );

    const formTabs = useMemo(
        () =>
            tabs.map((tab) => ({
                label: (
                    <div
                        className="flex items-center gap-2"
                        onMouseEnter={() => setHoveredTab(tab.id)}
                        onMouseLeave={() => setHoveredTab(null)}
                    >
                        <EditableTabLabel
                            value={tab.label}
                            onSave={(newLabel) => renameTab(tab.id, newLabel)}
                            isPreview={isPreview}
                        />

                        {hoveredTab === tab.id && tabs.length > 1 && !isPreview && (
                            <button
                                onClick={(e) => deleteTab(tab.id, e)}
                                className="ml-1 text-red-500 hover:text-red-700 transition-colors"
                                style={{ fontSize: '0.7rem' }}
                                title="Delete tab"
                            >
                                ×
                            </button>
                        )}
                    </div>
                ),
                value: tab.id,
                active: activeTab === tab.id,
                onClick: () => selectTab(tab.id),
            })),
        [tabs, activeTab, hoveredTab, isPreview, renameTab, deleteTab, selectTab],
    );

    const tabActions = useMemo(
        () =>
            isPreview
                ? []
                : [
                      {
                          icon: 'pi pi-plus',
                          label: 'Add tab',
                          onClick: addTab,
                          tooltip: 'Add another tab/page',
                      },
                  ],
        [isPreview, addTab],
    );

    // -------------------------------------------------------------------------
    // 8.10: RENDER
    // -------------------------------------------------------------------------

    return (
        <div className="flex-col min-h-screen bg-surface-50">
            {/* Header */}
            <FormBuilderHeader
                doctypeName={doctypeName}
                saveStatus={saveStatus}
                isPreview={isPreview}
                isSaving={isSaving}
                onTogglePreview={() => setIsPreview(!isPreview)}
                onSave={handleSave}
                onGoToRecordList={goToRecordList}
            />

            <TabbedSectionCard tabs={mainTabs}>
                {/* FORM TAB */}
                {activeMainTab === 'form' && (
                    <Splitter className="w-full h-full border-none">
                        {/* Form Canvas */}
                        <SplitterPanel className="flex flex-col" size={65} minSize={65}>
                            <TabbedSectionCard
                                key={activeTab}
                                tabs={formTabs}
                                actions={tabActions}
                                className="w-full h-full"
                            >
                                <div ref={formCanvasRef} className="flex-1 overflow-auto p-0">
                                    {!activeTabData?.sections?.length ? (
                                        /* Empty State */
                                        <div className="flex items-center justify-center h-96">
                                            <button
                                                onClick={() => addSection(activeTab)}
                                                className="w-full py-4 border-2 border-dashed border-gray-300 border-round-md text-gray-600 bg-transparent hover:bg-primary-50 hover:border-primary hover:text-primary transition-all duration-200 font-medium text-center cursor-pointer"
                                            >
                                                <i className="pi pi-plus mr-2"></i>
                                                Add Section
                                            </button>
                                        </div>
                                    ) : (
                                        /* Sections with DnD */
                                        <DndContext
                                            sensors={sensors}
                                            collisionDetection={closestCenter}
                                            onDragEnd={handleSectionDragEnd}
                                        >
                                            <SortableContext
                                                items={activeTabData.sections.map((s) => s.id)}
                                                strategy={verticalListSortingStrategy}
                                            >
                                                {activeTabData.sections.map((section) => (
                                                    <SortableSectionWrapper
                                                        key={section.id}
                                                        sectionId={section.id}
                                                        isPreview={isPreview}
                                                    >
                                                        <Section
                                                            id={section.id}
                                                            label={section.label}
                                                            fields={section.fields}
                                                            onAddField={addField}
                                                            onDeleteField={deleteField}
                                                            onRenameSection={renameSection}
                                                            onRenameField={renameField}
                                                            onAddSection={(sectionId) =>
                                                                addSection(activeTab, sectionId)
                                                            }
                                                            onDeleteSection={(sectionId) =>
                                                                deleteSection(activeTab, sectionId)
                                                            }
                                                            isPreview={isPreview}
                                                            selectedItem={selectedItem}
                                                            onSelectField={(fieldId) =>
                                                                selectField(section.id, fieldId)
                                                            }
                                                            onReorderFields={reorderFields}
                                                            isSelected={
                                                                selectedItem.type === 'section' &&
                                                                selectedItem.id === section.id
                                                            }
                                                            onSelectSection={() =>
                                                                selectSection(section.id)
                                                            }
                                                        />
                                                    </SortableSectionWrapper>
                                                ))}
                                            </SortableContext>
                                        </DndContext>
                                    )}
                                </div>
                            </TabbedSectionCard>
                        </SplitterPanel>

                        {/* Properties Panel */}
                        <SplitterPanel
                            className="flex flex-col bg-surface-50 properties-panel"
                            size={35}
                            minSize={20}
                            onClick={(e) => e.stopPropagation()}
                            onMouseDown={(e) => e.stopPropagation()}
                        >
                            <div className="h-full overflow-auto">
                                <div
                                    className="p-6"
                                    onClick={(e) => e.stopPropagation()}
                                    onMouseDown={(e) => e.stopPropagation()}
                                >
                                    <PropertiesPanel
                                        type={selectedItem.type}
                                        data={selectedData}
                                        onUpdate={handlePropertyUpdate}
                                        availableDoctypes={AVAILABLE_DOCTYPES}
                                        doctypeFieldsMap={DOCTYPE_FIELDS_MAP}
                                    />
                                </div>
                            </div>
                        </SplitterPanel>
                    </Splitter>
                )}

                {/* SETTINGS TAB */}
                {activeMainTab === 'settings' && (
                    <div className="p-4">
                        <div className="mb-4">
                            <h2 className="text-2xl font-bold text-900 mb-2">
                                List View Configuration
                            </h2>
                            <p className="text-600">
                                Configure the fields to appear in the list view.
                            </p>
                        </div>

                        <ListViewConfigEditor
                            // Pass all fields from tabs in a flat structure
                            allFields={tabs.flatMap((tab) =>
                                tab.sections.flatMap((section) => section.fields),
                            )}
                            // Pass current listview config
                            listViewConfig={state.listViewConfig}
                            // Handle config updates
                            onConfigChange={(newConfig) => {
                                setListViewConfig(newConfig);
                            }}
                            // Embedded mode - no header/navigation
                            showHeader={false}
                        />
                    </div>
                )}

                {/* CONNECTIONS TAB */}
                {activeMainTab === 'connections' && (
                    <div className="p-8 text-center text-gray-500">
                        <p>Connections content goes here</p>
                    </div>
                )}
            </TabbedSectionCard>
        </div>
    );
}
