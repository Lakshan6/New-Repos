// components/ListViewConfigEditor/ListViewConfigEditor.jsx

import React, { useState, useEffect, useMemo, useRef, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { Button } from 'primereact/button';
import { Checkbox } from 'primereact/checkbox';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import { Dropdown } from 'primereact/dropdown';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Panel } from 'primereact/panel';
import { Toast } from 'primereact/toast';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Tag } from 'primereact/tag';
import { Message } from 'primereact/message';
import { Skeleton } from 'primereact/skeleton';

import { generateListViewConfigFromData } from '../components/autoSchema/generateListViewConfigFromData';
import { useDoctypeSchemaLoader } from '../hooks/useDoctypeSchemaLoader';
import { useDoctypeSchemaPersistence } from '../hooks/useDoctypeSchemaPersistence';
import useFetchDoctype from '../hooks/useFetchDoctype';

// -----------------------------------------------------------------------------
// CONSTANTS
// -----------------------------------------------------------------------------

const COLUMN_TYPE_OPTIONS = [
    { label: 'Text', value: 'text' },
    { label: 'Number', value: 'number' },
    { label: 'Date', value: 'date' },
    { label: 'DateTime', value: 'datetime' },
    { label: 'Status/Tag', value: 'status' },
    { label: 'Boolean', value: 'boolean' },
    { label: 'Link', value: 'link' },
    { label: 'Count', value: 'count' },
];

// -----------------------------------------------------------------------------
// UTILITY FUNCTIONS
// -----------------------------------------------------------------------------

const get = (obj, path, defaultValue = undefined) => {
    if (!obj || !path) return defaultValue;
    const keys = path.split('.');
    let result = obj;
    for (const key of keys) {
        if (result === null || result === undefined) return defaultValue;
        result = result[key];
    }
    return result !== undefined ? result : defaultValue;
};

const prettifyHeader = (fieldPath) => {
    if (!fieldPath) return '';
    const parts = fieldPath.split('.');
    const lastPart = parts[parts.length - 1];

    if (lastPart.startsWith('__') && lastPart.endsWith('_count')) {
        const source = lastPart.replace(/^__/, '').replace(/_count$/, '');
        return `${prettifyHeader(source)}`;
    }

    return lastPart
        .replace(/([A-Z])/g, ' $1')
        .replace(/_/g, ' ')
        .replace(/\b\w/g, (c) => c.toUpperCase())
        .trim();
};

const extractNestedFieldOptions = (records = []) => {
    const nestedFields = {};

    if (!records.length) return nestedFields;

    records.forEach((record) => {
        Object.entries(record).forEach(([key, value]) => {
            if (value && typeof value === 'object' && !Array.isArray(value)) {
                if (!nestedFields[key]) {
                    nestedFields[key] = new Set();
                }
                Object.keys(value).forEach((childKey) => {
                    nestedFields[key].add(childKey);
                });
            }
        });
    });

    Object.keys(nestedFields).forEach((key) => {
        nestedFields[key] = Array.from(nestedFields[key]);
    });

    return nestedFields;
};

const normalizeColumn = (col, idx) => {
    // Support both formats when reading
    const field = col.field || col.fieldname;
    const label = col.header || col.label || prettifyHeader(field);

    const isNested = field?.includes('.') && !field.startsWith('__');
    const isComputedCount = field?.startsWith('__') && field?.endsWith('_count');

    let nestedParent = null;
    let nestedChild = null;

    if (isNested) {
        const parts = field.split('.');
        nestedParent = parts[0];
        nestedChild = parts.slice(1).join('.');
    }

    return {
        id: col.id || `col-${idx}-${Date.now()}-${Math.random().toString(36).substr(2, 9)}`,
        field,
        fieldname: field, // Keep for internal compatibility
        label, // Internal use
        header: label, // Internal use (same as label)
        visible: col.visible !== false,
        sortable: col.sortable !== false,
        width: col.width || null,
        type: col.type || 'text',
        frozen: col.frozen || false,
        source: col.source || 'auto',
        compute: col.compute || null,
        isNested,
        isComputedCount,
        isReferenced: col.isReferenced || isNested || isComputedCount,
        nestedParent,
        nestedChild,
        idx,
    };
};
const exportColumn = (col) => {
    const exported = {
        field: col.field,
        header: col.label || col.header, // Use label from internal state, fallback to header
        visible: col.visible,
        sortable: col.sortable,
        type: col.type,
        source: col.source,
    };

    if (col.width) exported.width = col.width;
    if (col.frozen) exported.frozen = col.frozen;
    if (col.compute) exported.compute = col.compute;
    if (col.isNested || col.isComputedCount) exported.isReferenced = true;

    return exported;
};

const buildSchemaForPersistence = (
    existingSchema,
    doctypeId,
    doctypeName,
    moduleName,
    listviewConfig,
) => {
    const now = new Date().toISOString();

    if (existingSchema && Object.keys(existingSchema).length > 0) {
        return {
            ...existingSchema,
            listview_config: listviewConfig,
            modified: now,
        };
    }

    return {
        id: doctypeId,
        doctypeName: doctypeName,
        module: moduleName,
        listview_config: listviewConfig,
        created: now,
        modified: now,
    };
};

const hasValidListviewConfig = (schema) => {
    return (
        schema?.listview_config &&
        typeof schema.listview_config === 'object' &&
        Array.isArray(schema.listview_config.columns) &&
        schema.listview_config.columns.length > 0
    );
};

const mapFieldTypeToColumnType = (fieldType) => {
    const typeMap = {
        text: 'text',
        textarea: 'text',
        number: 'number',
        int: 'number',
        currency: 'number',
        date: 'date',
        datetime: 'datetime',
        checkbox: 'boolean',
        select: 'text',
        radio: 'text',
        link: 'link',
        button: 'text',
        table: 'text',
    };
    return typeMap[fieldType] || 'text';
};

/**
 * Merge existing config with current fields
 * - Keeps existing column settings (visibility, order, etc.)
 * - Adds new fields that aren't in config
 * - Removes columns for fields that no longer exist
 *
 * Config format uses: { field, header, visible, sortable, type, source }
 */
const mergeConfigWithFields = (existingConfig, allFields) => {
    if (!allFields || allFields.length === 0) {
        return { columns: [], source: 'empty' };
    }

    const currentFieldnames = new Set(allFields.map((f) => f.fieldname));

    // If no existing config, generate from fields
    if (!existingConfig?.columns || existingConfig.columns.length === 0) {
        const columns = allFields.map((field, idx) => ({
            field: field.fieldname,
            header: field.label,
            visible: idx < 6, // First 6 visible by default
            sortable: true,
            type: mapFieldTypeToColumnType(field.type),
            source: 'fields',
        }));
        return { columns, source: 'auto' };
    }

    // Start with existing columns, but filter out deleted fields
    const existingFieldnames = new Set();
    let mergedColumns = existingConfig.columns
        .filter((col) => {
            // Support both 'field' and 'fieldname' for reading
            const fieldname = col.field || col.fieldname;
            const exists = currentFieldnames.has(fieldname);
            if (exists) {
                existingFieldnames.add(fieldname);
            }
            return exists;
        })
        .map((col) => {
            // Normalize to standard format and update label if field label changed
            const fieldname = col.field || col.fieldname;
            const field = allFields.find((f) => f.fieldname === fieldname);
            const currentHeader = col.header || col.label;

            // Build normalized column
            const normalized = {
                field: fieldname,
                header: field?.label || currentHeader,
                visible: col.visible !== false,
                sortable: col.sortable !== false,
                type: col.type || 'text',
                source: col.source || 'auto',
            };

            // Preserve optional properties
            if (col.width) normalized.width = col.width;
            if (col.frozen) normalized.frozen = col.frozen;
            if (col.compute) normalized.compute = col.compute;
            if (col.isReferenced) normalized.isReferenced = col.isReferenced;

            return normalized;
        });

    // Add new fields that aren't in existing config
    allFields.forEach((field) => {
        if (!existingFieldnames.has(field.fieldname)) {
            mergedColumns.push({
                field: field.fieldname,
                header: field.label,
                visible: true, // New fields visible by default
                sortable: true,
                type: mapFieldTypeToColumnType(field.type),
                source: 'fields',
            });
        }
    });

    return { columns: mergedColumns, source: 'merged' };
};

// -----------------------------------------------------------------------------
// SUB-COMPONENTS
// -----------------------------------------------------------------------------

const EditorHeader = ({
    doctypeName,
    onSave,
    onCancel,
    isSaving,
    hasChanges,
    configSource,
    columnsCount,
    showBackButton = true,
    saveLabel = 'Save Configuration',
}) => (
    <div className="surface-card border-1 surface-border border-round-md px-4 py-3 mb-3 flex justify-content-between align-items-center">
        <div className="flex align-items-center gap-3">
            {showBackButton && (
                <Button
                    icon="pi pi-arrow-left"
                    text
                    rounded
                    onClick={onCancel}
                    tooltip="Back"
                    tooltipOptions={{ position: 'bottom' }}
                    disabled={isSaving}
                />
            )}
            <div>
                <h2 className="m-0 text-xl font-semibold text-900">Configure List View</h2>
                <div className="flex align-items-center gap-2 mt-1">
                    <p className="m-0 text-500 text-sm">{doctypeName}</p>
                    {configSource && (
                        <Tag
                            value={
                                configSource === 'schema'
                                    ? 'From Schema'
                                    : configSource === 'merged'
                                      ? 'Synced'
                                      : 'Auto-generated'
                            }
                            severity={
                                configSource === 'schema' || configSource === 'merged'
                                    ? 'success'
                                    : 'info'
                            }
                            className="text-xs"
                        />
                    )}
                </div>
            </div>
        </div>
        <div className="flex align-items-center gap-2">
            {hasChanges && <Tag value="Unsaved Changes" severity="warning" className="mr-2" />}
            {showBackButton && (
                <Button
                    label="Cancel"
                    icon="pi pi-times"
                    outlined
                    onClick={onCancel}
                    disabled={isSaving}
                />
            )}
            <Button
                label={isSaving ? 'Saving...' : saveLabel}
                icon={isSaving ? 'pi pi-spin pi-spinner' : 'pi pi-check'}
                onClick={onSave}
                disabled={isSaving || columnsCount === 0}
            />
        </div>
    </div>
);

const LoadingSkeleton = ({ message = 'Loading...' }) => (
    <div className="p-4">
        <div className="flex align-items-center gap-2 mb-4 text-500">
            <i className="pi pi-spin pi-spinner"></i>
            <span>{message}</span>
        </div>
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="100%" height="4rem" className="mb-2" />
        <Skeleton width="100%" height="4rem" className="mb-2" />
        <Skeleton width="100%" height="4rem" className="mb-2" />
        <Skeleton width="80%" height="4rem" />
    </div>
);

const ErrorState = ({ message, onRetry, onBack }) => (
    <div className="surface-ground p-4">
        <Message severity="error" text={message} className="w-full mb-3" />
        <div className="flex gap-2">
            {onBack && <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={onBack} />}
            {onRetry && <Button label="Retry" icon="pi pi-refresh" onClick={onRetry} />}
        </div>
    </div>
);

const NestedFieldSelector = ({ column, nestedFieldOptions, onChange, sampleRecords }) => {
    const childOptions = useMemo(() => {
        if (!column.nestedParent || !nestedFieldOptions[column.nestedParent]) {
            return [];
        }
        return nestedFieldOptions[column.nestedParent].map((key) => ({
            label: prettifyHeader(key),
            value: key,
        }));
    }, [column.nestedParent, nestedFieldOptions]);

    const sampleValue = useMemo(() => {
        if (!sampleRecords?.length || !column.field) return null;
        const value = get(sampleRecords[0], column.field);
        if (value === null || value === undefined) return null;
        const str = String(value);
        return str.length > 20 ? str.substring(0, 20) + '...' : str;
    }, [sampleRecords, column.field]);

    const handleChildChange = (newChild) => {
        const newField = `${column.nestedParent}.${newChild}`;
        onChange({
            field: newField,
            fieldname: newField,
            nestedChild: newChild,
            label: prettifyHeader(column.nestedParent),
            header: prettifyHeader(column.nestedParent),
        });
    };

    return (
        <div className="flex align-items-center gap-2">
            <span className="text-500 font-mono text-sm">{column.nestedParent}.</span>
            <Dropdown
                value={column.nestedChild}
                options={childOptions}
                onChange={(e) => handleChildChange(e.value)}
                placeholder="Select field"
                className="p-inputtext-sm"
                style={{ minWidth: '120px' }}
            />
            {sampleValue && (
                <span className="text-xs text-400 ml-2" title={sampleValue}>
                    → {sampleValue}
                </span>
            )}
        </div>
    );
};

const ColumnRow = ({
    column,
    index,
    onUpdate,
    onMoveUp,
    onMoveDown,
    isFirst,
    isLast,
    sampleRecords,
    nestedFieldOptions,
    expanded,
    onToggleExpand,
    disabled,
}) => {
    const sampleValue = useMemo(() => {
        if (!sampleRecords?.length || !column.field) return null;

        if (column.isComputedCount && column.compute) {
            const arr = sampleRecords[0]?.[column.compute.source];
            return Array.isArray(arr) ? `${arr.length} items` : '0 items';
        }

        const value = get(sampleRecords[0], column.field);
        if (value === null || value === undefined) return '—';
        const str = String(value);
        return str.length > 25 ? str.substring(0, 25) + '...' : str;
    }, [sampleRecords, column]);

    return (
        <div
            className={`surface-card border-1 border-round mb-2 overflow-hidden transition-all transition-duration-200 ${
                column.visible ? 'surface-border' : 'border-300 opacity-70'
            } ${disabled ? 'pointer-events-none opacity-50' : ''}`}
        >
            <div className="p-3 flex align-items-center gap-3">
                <div className="flex flex-column gap-1">
                    <Button
                        icon="pi pi-chevron-up"
                        text
                        rounded
                        size="small"
                        disabled={isFirst || disabled}
                        onClick={() => onMoveUp(index)}
                        className="p-button-sm"
                        style={{ width: '1.5rem', height: '1.5rem' }}
                    />
                    <Button
                        icon="pi pi-chevron-down"
                        text
                        rounded
                        size="small"
                        disabled={isLast || disabled}
                        onClick={() => onMoveDown(index)}
                        className="p-button-sm"
                        style={{ width: '1.5rem', height: '1.5rem' }}
                    />
                </div>

                <Checkbox
                    checked={column.visible}
                    onChange={(e) => onUpdate(index, { visible: e.checked })}
                    tooltip={column.visible ? 'Visible in list' : 'Hidden from list'}
                    tooltipOptions={{ position: 'top' }}
                    disabled={disabled}
                />

                <div className="flex-1 min-w-0">
                    <div className="flex align-items-center gap-2 mb-1">
                        {column.isNested ? (
                            <NestedFieldSelector
                                column={column}
                                nestedFieldOptions={nestedFieldOptions}
                                onChange={(updates) => onUpdate(index, updates)}
                                sampleRecords={sampleRecords}
                            />
                        ) : (
                            <code className="text-sm surface-100 px-2 py-1 border-round">
                                {column.field}
                            </code>
                        )}

                        {column.isComputedCount && (
                            <Tag value="Count" severity="warning" className="text-xs" />
                        )}
                        {column.frozen && (
                            <Tag value="Frozen" severity="info" className="text-xs" />
                        )}
                    </div>

                    <div className="text-xs text-500">
                        <i className="pi pi-eye mr-1"></i>
                        {sampleValue}
                    </div>
                </div>

                <div style={{ width: '150px' }}>
                    <InputText
                        value={column.label}
                        onChange={(e) =>
                            onUpdate(index, { label: e.target.value, header: e.target.value })
                        }
                        className="w-full p-inputtext-sm"
                        placeholder="Label"
                        disabled={disabled}
                    />
                </div>

                <div style={{ width: '100px' }}>
                    <Dropdown
                        value={column.type}
                        options={COLUMN_TYPE_OPTIONS}
                        onChange={(e) => onUpdate(index, { type: e.value })}
                        className="w-full p-inputtext-sm"
                        disabled={column.isComputedCount || disabled}
                    />
                </div>

                <Button
                    icon={expanded ? 'pi pi-chevron-up' : 'pi pi-cog'}
                    text
                    rounded
                    size="small"
                    onClick={() => onToggleExpand(column.id)}
                    tooltip="More options"
                    tooltipOptions={{ position: 'top' }}
                    disabled={disabled}
                />
            </div>

            {expanded && (
                <div className="px-3 pb-3 pt-0 border-top-1 surface-border bg-gray-50">
                    <div className="flex align-items-center gap-4 pt-3">
                        <div className="flex align-items-center gap-2">
                            <Checkbox
                                inputId={`sort-${column.id}`}
                                checked={column.sortable}
                                onChange={(e) => onUpdate(index, { sortable: e.checked })}
                                disabled={disabled}
                            />
                            <label htmlFor={`sort-${column.id}`} className="text-sm">
                                Sortable
                            </label>
                        </div>

                        <div className="flex align-items-center gap-2">
                            <Checkbox
                                inputId={`freeze-${column.id}`}
                                checked={column.frozen}
                                onChange={(e) => onUpdate(index, { frozen: e.checked })}
                                disabled={disabled}
                            />
                            <label htmlFor={`freeze-${column.id}`} className="text-sm">
                                Freeze Column
                            </label>
                        </div>

                        <div className="flex align-items-center gap-2">
                            <label className="text-sm text-500">Width:</label>
                            <InputNumber
                                value={column.width}
                                onChange={(e) => onUpdate(index, { width: e.value })}
                                placeholder="Auto"
                                className="p-inputtext-sm"
                                style={{ width: '80px' }}
                                min={50}
                                max={500}
                                suffix="px"
                                disabled={disabled}
                            />
                        </div>
                    </div>
                </div>
            )}
        </div>
    );
};

const PreviewPanel = ({ columns, sampleData }) => {
    const visibleColumns = columns.filter((c) => c.visible);

    const previewData = useMemo(() => {
        if (sampleData?.length > 0) {
            return sampleData.slice(0, 3);
        }
        return [];
    }, [sampleData]);

    const bodyTemplate = (rowData, options) => {
        const column = visibleColumns.find((c) => c.field === options.field);

        if (column?.isComputedCount && column?.compute) {
            const sourceArray = rowData[column.compute.source];
            return Array.isArray(sourceArray) ? sourceArray.length : 0;
        }

        const value = get(rowData, options.field);

        if (value === null || value === undefined) {
            return <span className="text-400">—</span>;
        }

        if (column?.type === 'status') {
            return <Tag value={String(value)} />;
        }

        return String(value);
    };

    if (visibleColumns.length === 0) {
        return (
            <Panel header="Preview" className="mt-3">
                <Message severity="warn" text="No visible columns selected" className="w-full" />
            </Panel>
        );
    }

    return (
        <Panel header="Preview" className="mt-3">
            <DataTable
                value={previewData}
                size="small"
                stripedRows
                className="text-sm"
                emptyMessage="No sample data available"
                scrollable
                scrollHeight="180px"
            >
                {visibleColumns.map((col) => (
                    <Column
                        key={col.id}
                        field={col.field}
                        header={col.label}
                        frozen={col.frozen}
                        style={col.width ? { width: `${col.width}px` } : { minWidth: '100px' }}
                        body={(rowData) => bodyTemplate(rowData, { field: col.field })}
                    />
                ))}
            </DataTable>
            <div className="mt-2 text-500 text-sm">
                <i className="pi pi-info-circle mr-1"></i>
                Showing {visibleColumns.length} visible columns
            </div>
        </Panel>
    );
};

// -----------------------------------------------------------------------------
// MAIN COMPONENT
// -----------------------------------------------------------------------------

const ListViewConfigEditor = ({
    // EMBEDDED MODE PROPS
    allFields,
    listViewConfig: initialListViewConfig,
    onConfigChange,

    // STANDALONE MODE PROPS
    doctypeId: propDoctypeId,
    records: propRecords,
    onExport,
    showHeader = true,
}) => {
    // -------------------------------------------------------------------------
    // DETERMINE MODE
    // -------------------------------------------------------------------------

    const isEmbeddedWithFields = allFields !== undefined;
    const isEmbeddedWithRecords = propDoctypeId !== undefined || propRecords !== undefined;
    const isEmbedded = isEmbeddedWithFields || isEmbeddedWithRecords;

    // -------------------------------------------------------------------------
    // ROUTING & INITIAL DATA
    // -------------------------------------------------------------------------

    const location = useLocation();
    const navigate = useNavigate();
    const toast = useRef(null);

    const { doctypeId: locationDoctypeId, records: locationRecords = [] } = location.state || {};
    const doctypeId = propDoctypeId ?? locationDoctypeId;
    const sampleRecords = propRecords ?? locationRecords;

    // -------------------------------------------------------------------------
    // REFS FOR INITIALIZATION TRACKING
    // -------------------------------------------------------------------------

    const initializedRef = useRef(false);
    const hasUserEditedRef = useRef(false);
    const notifyTimeoutRef = useRef(null);
    const doctypeFetchedRef = useRef(false);
    const schemaFetchedFor = useRef(null);
    const prevFieldnamesRef = useRef(new Set());

    // -------------------------------------------------------------------------
    // CONVERT FIELDS TO MOCK RECORDS
    // -------------------------------------------------------------------------

    const mockRecordsFromFields = useMemo(() => {
        if (!allFields || allFields.length === 0) return [];

        const mockRecord = {};
        allFields.forEach((field) => {
            switch (field.type) {
                case 'text':
                case 'textarea':
                    mockRecord[field.fieldname] = `Sample ${field.label}`;
                    break;
                case 'number':
                case 'int':
                case 'currency':
                    mockRecord[field.fieldname] = 100;
                    break;
                case 'checkbox':
                    mockRecord[field.fieldname] = true;
                    break;
                case 'date':
                    mockRecord[field.fieldname] = '2024-01-01';
                    break;
                case 'datetime':
                    mockRecord[field.fieldname] = '2024-01-01T12:00:00Z';
                    break;
                case 'select':
                case 'radio':
                    mockRecord[field.fieldname] = field.options?.[0] || 'Option 1';
                    break;
                case 'link':
                    mockRecord[field.fieldname] = field.foreignReference
                        ? `${field.foreignReference} Record`
                        : 'Linked Record';
                    break;
                case 'button':
                    mockRecord[field.fieldname] = 'Action';
                    break;
                case 'table':
                    mockRecord[field.fieldname] = '3 rows';
                    break;
                default:
                    mockRecord[field.fieldname] = `Sample ${field.label}`;
            }
        });

        return [mockRecord];
    }, [allFields]);

    const effectiveSampleRecords = useMemo(() => {
        if (isEmbeddedWithFields) {
            return mockRecordsFromFields;
        }
        return sampleRecords;
    }, [isEmbeddedWithFields, mockRecordsFromFields, sampleRecords]);

    // -------------------------------------------------------------------------
    // STATE
    // -------------------------------------------------------------------------

    const [schemaLoadRequested, setSchemaLoadRequested] = useState(false);
    const [columns, setColumns] = useState([]);
    const [originalColumns, setOriginalColumns] = useState([]);
    const [expandedColumnId, setExpandedColumnId] = useState(null);
    const [configSource, setConfigSource] = useState(null);
    const [initialized, setInitialized] = useState(false);

    // -------------------------------------------------------------------------
    // FETCH DOCTYPE HOOK
    // -------------------------------------------------------------------------

    const {
        fetchDoctype,
        data: doctype,
        isPending: doctypeLoading,
        isError: doctypeError,
        error: doctypeErrorObj,
    } = useFetchDoctype();

    useEffect(() => {
        if (isEmbeddedWithFields) return;

        if (doctypeId && !doctypeFetchedRef.current) {
            doctypeFetchedRef.current = true;
            fetchDoctype(doctypeId);
        }
    }, [doctypeId, fetchDoctype, isEmbeddedWithFields]);

    useEffect(() => {
        doctypeFetchedRef.current = false;
        schemaFetchedFor.current = null;
        initializedRef.current = false;
        hasUserEditedRef.current = false;
        prevFieldnamesRef.current = new Set();
        setSchemaLoadRequested(false);
        setInitialized(false);
    }, [doctypeId]);

    const doctypeName = doctype?.doctypeName || 'Form Builder';
    const moduleName = doctype?.module || 'Custom';

    // -------------------------------------------------------------------------
    // FETCH SCHEMA HOOK
    // -------------------------------------------------------------------------

    const {
        loadUISchema,
        data: schema,
        loading: schemaLoading,
        isError: schemaError,
    } = useDoctypeSchemaLoader();

    useEffect(() => {
        if (isEmbeddedWithFields) return;

        const cacheKey = `${doctypeName}:${moduleName}`;

        if (
            doctypeName &&
            moduleName &&
            doctypeName !== 'Form Builder' &&
            schemaFetchedFor.current !== cacheKey &&
            !schemaLoading
        ) {
            schemaFetchedFor.current = cacheKey;
            setSchemaLoadRequested(true);
            loadUISchema({ doctypeName, module: moduleName });
        }
    }, [doctypeName, moduleName, loadUISchema, schemaLoading, isEmbeddedWithFields]);

    // -------------------------------------------------------------------------
    // SAVE SCHEMA HOOK
    // -------------------------------------------------------------------------

    const {
        saveUISchema,
        saving: isSaving,
        isError: saveError,
        error: saveErrorObj,
    } = useDoctypeSchemaPersistence();

    // -------------------------------------------------------------------------
    // SCHEMA SETTLED STATE
    // -------------------------------------------------------------------------

    const schemaSettled = useMemo(() => {
        if (isEmbeddedWithFields) return true;
        if (doctypeLoading) return false;
        if (doctypeError) return true;
        if (!doctypeName || !moduleName || doctypeName === 'Form Builder') return false;
        if (!schemaLoadRequested) return false;
        if (schemaLoading) return false;
        return true;
    }, [
        isEmbeddedWithFields,
        doctypeLoading,
        doctypeError,
        doctypeName,
        moduleName,
        schemaLoadRequested,
        schemaLoading,
    ]);

    // -------------------------------------------------------------------------
    // DERIVED STATE
    // -------------------------------------------------------------------------

    const nestedFieldOptions = useMemo(() => {
        return extractNestedFieldOptions(effectiveSampleRecords);
    }, [effectiveSampleRecords]);

    const hasChanges = useMemo(() => {
        return JSON.stringify(columns) !== JSON.stringify(originalColumns);
    }, [columns, originalColumns]);

    const visibleCount = useMemo(() => columns.filter((c) => c.visible).length, [columns]);

    // -------------------------------------------------------------------------
    // STABLE onConfigChange REF
    // -------------------------------------------------------------------------

    const onConfigChangeRef = useRef(onConfigChange);
    useEffect(() => {
        onConfigChangeRef.current = onConfigChange;
    }, [onConfigChange]);

    // -------------------------------------------------------------------------
    // ✅ FIXED INITIALIZATION - Now merges config with current fields
    // -------------------------------------------------------------------------

    useEffect(() => {
        if (initializedRef.current) {
            return;
        }

        if (!schemaSettled) {
            return;
        }

        initializedRef.current = true;

        let configColumns = [];
        let source = null;

        if (isEmbeddedWithFields) {
            // ✅ Use merge function to combine existing config with current fields
            const merged = mergeConfigWithFields(initialListViewConfig, allFields);
            configColumns = merged.columns;
            source = merged.source;

            // Initialize previous fieldnames ref
            if (allFields) {
                prevFieldnamesRef.current = new Set(allFields.map((f) => f.fieldname));
            }
        } else if (hasValidListviewConfig(schema)) {
            configColumns = schema.listview_config.columns;
            source = 'schema';
        } else if (effectiveSampleRecords.length > 0) {
            const autoConfig = generateListViewConfigFromData(effectiveSampleRecords);
            configColumns = autoConfig.columns;
            source = 'auto';
        }

        if (configColumns.length > 0) {
            const normalized = configColumns.map(normalizeColumn);
            setColumns(normalized);
            setOriginalColumns(normalized);
            setConfigSource(source);
        }

        setInitialized(true);
    }, [
        schemaSettled,
        schema,
        effectiveSampleRecords,
        isEmbeddedWithFields,
        allFields,
        initialListViewConfig,
    ]);

    // -------------------------------------------------------------------------
    // ✅ SYNC COLUMNS WITH ALLFIELDS CHANGES (for live updates while mounted)
    // -------------------------------------------------------------------------

    useEffect(() => {
        if (!isEmbeddedWithFields || !initialized) {
            return;
        }

        if (!allFields || allFields.length === 0) {
            return;
        }

        const currentFieldnames = new Set(allFields.map((f) => f.fieldname));
        const previousFieldnames = prevFieldnamesRef.current;

        // Skip on first run (handled by init effect)
        if (previousFieldnames.size === 0) {
            prevFieldnamesRef.current = currentFieldnames;
            return;
        }

        const newFieldnames = [...currentFieldnames].filter((fn) => !previousFieldnames.has(fn));
        const removedFieldnames = [...previousFieldnames].filter(
            (fn) => !currentFieldnames.has(fn),
        );

        if (newFieldnames.length === 0 && removedFieldnames.length === 0) {
            return;
        }

        console.log('[ListViewConfigEditor] Field changes detected:', {
            added: newFieldnames,
            removed: removedFieldnames,
        });

        setColumns((prevColumns) => {
            let updatedColumns = [...prevColumns];

            // Remove columns for deleted fields
            if (removedFieldnames.length > 0) {
                updatedColumns = updatedColumns.filter(
                    (col) => !removedFieldnames.includes(col.field),
                );
            }

            // Add new columns for new fields
            if (newFieldnames.length > 0) {
                newFieldnames.forEach((fieldname) => {
                    const exists = updatedColumns.some((col) => col.field === fieldname);
                    if (exists) return;

                    const field = allFields.find((f) => f.fieldname === fieldname);
                    if (!field) return;

                    // In the sync effect, when creating new column:
                    const newColumn = normalizeColumn(
                        {
                            field: field.fieldname,
                            header: field.label,
                            visible: true,
                            sortable: true,
                            type: mapFieldTypeToColumnType(field.type),
                            source: 'fields',
                        },
                        updatedColumns.length,
                    );

                    updatedColumns.push(newColumn);
                });
            }

            return updatedColumns;
        });

        hasUserEditedRef.current = true;
        prevFieldnamesRef.current = currentFieldnames;
    }, [allFields, isEmbeddedWithFields, initialized]);

    // -------------------------------------------------------------------------
    // NOTIFY PARENT - Debounced, only on user edits
    // -------------------------------------------------------------------------

    useEffect(() => {
        if (!hasUserEditedRef.current) {
            return;
        }

        if (!onConfigChangeRef.current) {
            return;
        }

        if (columns.length === 0) {
            return;
        }

        if (notifyTimeoutRef.current) {
            clearTimeout(notifyTimeoutRef.current);
        }

        notifyTimeoutRef.current = setTimeout(() => {
            const exportedConfig = {
                columns: columns.map(exportColumn),
            };
            onConfigChangeRef.current(exportedConfig);
        }, 150);

        return () => {
            if (notifyTimeoutRef.current) {
                clearTimeout(notifyTimeoutRef.current);
            }
        };
    }, [columns]);

    // -------------------------------------------------------------------------
    // HANDLERS
    // -------------------------------------------------------------------------

    const handleUpdateColumn = useCallback((index, updates) => {
        hasUserEditedRef.current = true;
        setColumns((prev) => {
            const newColumns = [...prev];
            newColumns[index] = { ...newColumns[index], ...updates };
            return newColumns;
        });
    }, []);

    const handleMoveUp = useCallback((index) => {
        if (index === 0) return;
        hasUserEditedRef.current = true;
        setColumns((prev) => {
            const newColumns = [...prev];
            [newColumns[index - 1], newColumns[index]] = [newColumns[index], newColumns[index - 1]];
            return newColumns;
        });
    }, []);

    const handleMoveDown = useCallback((index) => {
        hasUserEditedRef.current = true;
        setColumns((prev) => {
            if (index === prev.length - 1) return prev;
            const newColumns = [...prev];
            [newColumns[index], newColumns[index + 1]] = [newColumns[index + 1], newColumns[index]];
            return newColumns;
        });
    }, []);

    const handleToggleExpand = useCallback((columnId) => {
        setExpandedColumnId((prev) => (prev === columnId ? null : columnId));
    }, []);

    const handleReset = useCallback(() => {
        confirmDialog({
            message: 'Reset to the original configuration?',
            header: 'Reset Configuration',
            icon: 'pi pi-refresh',
            accept: () => {
                hasUserEditedRef.current = true;
                setColumns([...originalColumns]);
                toast.current?.show({
                    severity: 'info',
                    summary: 'Reset',
                    detail: 'Configuration reset to original state',
                    life: 2000,
                });
            },
        });
    }, [originalColumns]);

    const handleShowAllVisible = useCallback(() => {
        hasUserEditedRef.current = true;
        setColumns((prev) => prev.map((col) => ({ ...col, visible: true })));
    }, []);

    const handleHideAllVisible = useCallback(() => {
        hasUserEditedRef.current = true;
        setColumns((prev) => prev.map((col) => ({ ...col, visible: false })));
    }, []);

    const handleSave = useCallback(async () => {
        const exportedColumns = columns.map(exportColumn);
        const listviewConfig = { columns: exportedColumns };

        if (isEmbeddedWithFields || onExport) {
            if (onExport) {
                onExport(listviewConfig);
            }
            if (onConfigChangeRef.current) {
                onConfigChangeRef.current(listviewConfig);
            }
            setOriginalColumns([...columns]);
            hasUserEditedRef.current = false;
            toast.current?.show({
                severity: 'success',
                summary: 'Updated',
                detail: 'List view configuration updated',
                life: 2000,
            });
            return;
        }

        if (!doctypeName || !moduleName || doctypeName === 'Form Builder') {
            toast.current?.show({
                severity: 'error',
                summary: 'Error',
                detail: 'Missing doctype name or module. Cannot save.',
                life: 5000,
            });
            return;
        }

        try {
            const schemaToSave = buildSchemaForPersistence(
                schema,
                doctypeId,
                doctypeName,
                moduleName,
                listviewConfig,
            );

            await saveUISchema(schemaToSave);

            setOriginalColumns([...columns]);
            setConfigSource('schema');
            hasUserEditedRef.current = false;

            toast.current?.show({
                severity: 'success',
                summary: 'Success',
                detail: 'List view configuration saved successfully',
                life: 3000,
            });

            setTimeout(() => {
                navigate(-1);
            }, 500);
        } catch (error) {
            console.error('[ListViewConfigEditor] Failed to save:', error);
            toast.current?.show({
                severity: 'error',
                summary: 'Save Failed',
                detail: error.message || 'Failed to save configuration. Please try again.',
                life: 5000,
            });
        }
    }, [
        columns,
        onExport,
        isEmbeddedWithFields,
        schema,
        doctypeId,
        doctypeName,
        moduleName,
        saveUISchema,
        navigate,
    ]);

    const handleCancel = useCallback(() => {
        if (isEmbedded) return;

        if (hasChanges) {
            confirmDialog({
                message: 'You have unsaved changes. Are you sure you want to leave?',
                header: 'Unsaved Changes',
                icon: 'pi pi-exclamation-triangle',
                accept: () => navigate(-1),
            });
        } else {
            navigate(-1);
        }
    }, [hasChanges, navigate, isEmbedded]);

    const handleRetryDoctype = useCallback(() => {
        doctypeFetchedRef.current = false;
        schemaFetchedFor.current = null;
        initializedRef.current = false;
        hasUserEditedRef.current = false;
        prevFieldnamesRef.current = new Set();
        setSchemaLoadRequested(false);
        setInitialized(false);
        if (doctypeId) {
            fetchDoctype(doctypeId);
        }
    }, [doctypeId, fetchDoctype]);

    // -------------------------------------------------------------------------
    // RENDER - EMBEDDED MODE WITH FIELDS
    // -------------------------------------------------------------------------

    if (isEmbeddedWithFields) {
        if (!allFields || allFields.length === 0) {
            return (
                <div className="p-4">
                    <Toast ref={toast} />
                    <Message
                        severity="info"
                        className="w-full"
                        content={
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-info-circle text-lg"></i>
                                <span>
                                    No fields available yet. Add fields in the Form tab first to
                                    configure the list view.
                                </span>
                            </div>
                        }
                    />
                </div>
            );
        }

        if (!initialized) {
            return (
                <div className="p-4">
                    <LoadingSkeleton message="Initializing list view configuration..." />
                </div>
            );
        }

        return (
            <div className="p-4">
                <Toast ref={toast} />
                <ConfirmDialog />

                {hasChanges && (
                    <Message
                        severity="info"
                        className="mb-3 w-full"
                        content={
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-info-circle text-lg"></i>
                                <span>Changes will be included when you save the form.</span>
                            </div>
                        }
                    />
                )}

                {configSource === 'auto' && !hasChanges && (
                    <Message
                        severity="secondary"
                        className="mb-3 w-full"
                        content="Configuration generated from your form fields. Customize which fields appear in the list view."
                    />
                )}

                <Panel
                    header={
                        <div className="flex justify-content-between align-items-center w-full">
                            <div className="flex align-items-center gap-2">
                                <span>List View Columns</span>
                                <Tag
                                    value={`${visibleCount} visible`}
                                    severity="success"
                                    className="text-xs"
                                />
                                <Tag
                                    value={`${columns.length - visibleCount} hidden`}
                                    severity="secondary"
                                    className="text-xs"
                                />
                            </div>
                            <div className="flex align-items-center gap-2">
                                <Button
                                    label="Show All"
                                    icon="pi pi-eye"
                                    text
                                    size="small"
                                    onClick={handleShowAllVisible}
                                />
                                <Button
                                    label="Hide All"
                                    icon="pi pi-eye-slash"
                                    text
                                    size="small"
                                    onClick={handleHideAllVisible}
                                />
                                <Button
                                    label="Reset"
                                    icon="pi pi-refresh"
                                    text
                                    size="small"
                                    onClick={handleReset}
                                    disabled={!hasChanges}
                                />
                            </div>
                        </div>
                    }
                >
                    <div style={{ maxHeight: '450px', overflowY: 'auto' }}>
                        {columns.map((column, index) => (
                            <ColumnRow
                                key={column.id}
                                column={column}
                                index={index}
                                onUpdate={handleUpdateColumn}
                                onMoveUp={handleMoveUp}
                                onMoveDown={handleMoveDown}
                                isFirst={index === 0}
                                isLast={index === columns.length - 1}
                                sampleRecords={effectiveSampleRecords}
                                nestedFieldOptions={nestedFieldOptions}
                                expanded={expandedColumnId === column.id}
                                onToggleExpand={handleToggleExpand}
                                disabled={false}
                            />
                        ))}
                    </div>
                </Panel>

                <PreviewPanel columns={columns} sampleData={effectiveSampleRecords} />
            </div>
        );
    }

    // -------------------------------------------------------------------------
    // RENDER - STANDALONE MODE CHECKS
    // -------------------------------------------------------------------------

    if (!doctypeId) {
        return (
            <ErrorState
                message="No doctype ID provided. Please go back and try again."
                onBack={isEmbedded ? null : () => navigate(-1)}
            />
        );
    }

    if (doctypeLoading) {
        return (
            <div className="surface-ground p-3">
                <div className="surface-card border-1 surface-border border-round-md px-4 py-3 mb-3">
                    <Skeleton width="200px" height="1.5rem" className="mb-2" />
                    <Skeleton width="150px" height="1rem" />
                </div>
                <LoadingSkeleton message="Loading doctype information..." />
            </div>
        );
    }

    if (doctypeError) {
        return (
            <ErrorState
                message={`Failed to load doctype: ${doctypeErrorObj?.message || 'Unknown error'}`}
                onRetry={handleRetryDoctype}
                onBack={isEmbedded ? null : () => navigate(-1)}
            />
        );
    }

    if (!schemaSettled || !initialized) {
        return (
            <div className="surface-ground p-3">
                <div className="surface-card border-1 surface-border border-round-md px-4 py-3 mb-3">
                    <div className="flex align-items-center gap-3">
                        {!isEmbedded && (
                            <Button
                                icon="pi pi-arrow-left"
                                text
                                rounded
                                onClick={() => navigate(-1)}
                            />
                        )}
                        <div>
                            <h2 className="m-0 text-xl font-semibold text-900">
                                Configure List View
                            </h2>
                            <p className="m-0 mt-1 text-500 text-sm">{doctypeName}</p>
                        </div>
                    </div>
                </div>
                <LoadingSkeleton
                    message={!schemaSettled ? 'Loading schema...' : 'Initializing...'}
                />
            </div>
        );
    }

    if (columns.length === 0) {
        return (
            <div className="surface-ground p-3">
                <Toast ref={toast} />
                {showHeader && (
                    <EditorHeader
                        doctypeName={doctypeName || 'Unknown Doctype'}
                        onSave={handleSave}
                        onCancel={handleCancel}
                        isSaving={isSaving}
                        hasChanges={hasChanges}
                        configSource={configSource}
                        columnsCount={columns.length}
                        showBackButton={!isEmbedded}
                        saveLabel={onExport ? 'Export Config' : 'Save Configuration'}
                    />
                )}
                <Message
                    severity="warn"
                    className="w-full"
                    content={
                        <div className="flex align-items-center gap-2">
                            <i className="pi pi-exclamation-triangle text-lg"></i>
                            <span>
                                No columns available. The schema has no listview configuration and
                                no sample records were provided to auto-generate columns.
                            </span>
                        </div>
                    }
                />
                {!isEmbedded && (
                    <Button
                        label="Go Back"
                        icon="pi pi-arrow-left"
                        className="mt-3"
                        onClick={() => navigate(-1)}
                    />
                )}
            </div>
        );
    }

    // -------------------------------------------------------------------------
    // RENDER - STANDALONE MODE MAIN EDITOR
    // -------------------------------------------------------------------------

    return (
        <div className="surface-ground">
            <Toast ref={toast} />
            <ConfirmDialog />

            <div className="p-3">
                {showHeader && (
                    <EditorHeader
                        doctypeName={doctypeName || 'Unknown Doctype'}
                        onSave={handleSave}
                        onCancel={handleCancel}
                        isSaving={isSaving}
                        hasChanges={hasChanges}
                        configSource={configSource}
                        columnsCount={columns.length}
                        showBackButton={!isEmbedded}
                        saveLabel={onExport ? 'Export Config' : 'Save Configuration'}
                    />
                )}

                {saveError && (
                    <Message
                        severity="error"
                        className="mb-3 w-full"
                        content={
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-times-circle text-lg"></i>
                                <span>
                                    Failed to save: {saveErrorObj?.message || 'Unknown error'}
                                </span>
                            </div>
                        }
                    />
                )}

                {configSource === 'schema' && (
                    <Message
                        severity="success"
                        className="mb-3 w-full"
                        content={
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-check-circle text-lg"></i>
                                <span>Using saved list view configuration from schema.</span>
                            </div>
                        }
                    />
                )}

                {configSource === 'auto' && (
                    <Message
                        severity="info"
                        className="mb-3 w-full"
                        content={
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-info-circle text-lg"></i>
                                <span>
                                    This configuration was auto-generated from sample data.
                                    {!onExport && ' Save to persist your changes to the schema.'}
                                </span>
                            </div>
                        }
                    />
                )}

                {Object.keys(nestedFieldOptions).length > 0 && (
                    <Message
                        severity="secondary"
                        className="mb-3 w-full"
                        content={
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-sitemap text-lg"></i>
                                <span>
                                    Nested objects detected:{' '}
                                    <strong>{Object.keys(nestedFieldOptions).join(', ')}</strong>.
                                    Use the dropdown to change which property is displayed.
                                </span>
                            </div>
                        }
                    />
                )}

                <Panel
                    header={
                        <div className="flex justify-content-between align-items-center w-full">
                            <div className="flex align-items-center gap-2">
                                <span>All Columns</span>
                                <Tag
                                    value={`${visibleCount} visible`}
                                    severity="success"
                                    className="text-xs"
                                />
                                <Tag
                                    value={`${columns.length - visibleCount} hidden`}
                                    severity="secondary"
                                    className="text-xs"
                                />
                            </div>
                            <div className="flex align-items-center gap-2">
                                <Button
                                    label="Show All"
                                    icon="pi pi-eye"
                                    text
                                    size="small"
                                    onClick={handleShowAllVisible}
                                    disabled={isSaving}
                                />
                                <Button
                                    label="Hide All"
                                    icon="pi pi-eye-slash"
                                    text
                                    size="small"
                                    onClick={handleHideAllVisible}
                                    disabled={isSaving}
                                />
                                <Button
                                    label="Reset"
                                    icon="pi pi-refresh"
                                    text
                                    size="small"
                                    onClick={handleReset}
                                    disabled={isSaving || !hasChanges}
                                />
                            </div>
                        </div>
                    }
                >
                    <div style={{ maxHeight: '450px', overflowY: 'auto' }}>
                        {columns.map((column, index) => (
                            <ColumnRow
                                key={column.id}
                                column={column}
                                index={index}
                                onUpdate={handleUpdateColumn}
                                onMoveUp={handleMoveUp}
                                onMoveDown={handleMoveDown}
                                isFirst={index === 0}
                                isLast={index === columns.length - 1}
                                sampleRecords={effectiveSampleRecords}
                                nestedFieldOptions={nestedFieldOptions}
                                expanded={expandedColumnId === column.id}
                                onToggleExpand={handleToggleExpand}
                                disabled={isSaving}
                            />
                        ))}
                    </div>
                </Panel>

                <PreviewPanel columns={columns} sampleData={effectiveSampleRecords} />
            </div>
        </div>
    );
};

export default ListViewConfigEditor;
