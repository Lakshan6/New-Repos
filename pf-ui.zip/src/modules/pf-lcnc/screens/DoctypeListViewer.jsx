import React, { useState, useRef, useEffect } from 'react';
import { useNavigate } from 'react-router';
import ListViewer from '../components/ListViewer';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { Checkbox } from 'primereact/checkbox';
import { Toast } from 'primereact/toast';
import { Tag } from 'primereact/tag';
import { InputTextarea } from 'primereact/inputtextarea';
import { Divider } from 'primereact/divider';
import { Card } from 'primereact/card';
import { Message } from 'primereact/message';
import { Skeleton } from 'primereact/skeleton';

import DynamicHeightWrapper from '@shared/components/DynamicHeightWrapper';
import { useDoctypeSchemaPersistence } from '../hooks/useDoctypeSchemaPersistence';
import { useDoctypeSchemaLoader } from '../hooks/useDoctypeSchemaLoader';
import { useGetDoctypes } from '../hooks/useGetDoctypes';

// ============================================================================
// SECTION 1: CONSTANTS
// ============================================================================

const MODULES = [
    { label: 'HRMS', value: 'hrms' },
    { label: 'Accounts', value: 'accounts' },
    { label: 'Stock', value: 'stock' },
    { label: 'CRM', value: 'crm' },
    { label: 'Projects', value: 'projects' },
];

const DEFAULT_FORM_STATE = {
    name: '',
    module: 'hrms',
    isSubmittable: false,
    isTree: false,
    isSingle: false,
    isChild: false,
    trackChanges: true,
    trackSeen: false,
    trackViews: false,
    allowRename: true,
    description: '',
};

// Column configuration for the doctype list
const DOCTYPE_COLUMNS = [
    {
        field: 'doctypeName',
        header: 'Name',
        sortable: true,
        style: { minWidth: '200px' },
    },
    {
        field: 'module',
        header: 'Module',
        sortable: true,
        style: { width: '200px' },
    },
    {
        field: 'createdAt',
        header: 'Created',
        type: 'date',
        sortable: true,
        style: { width: '200px' },
    },
    {
        field: 'updatedAt',
        header: 'Last Updated',
        type: 'datetime',
        sortable: true,
        style: { width: '250px' },
    },
];

// ============================================================================
// SECTION 2: UTILITY FUNCTIONS
// ============================================================================

/**
 * Format doctype data for list display
 */
const formatDoctypeForList = (doctype) => ({
    ...doctype,
    id: doctype.id || doctype.doctypeName,
    fieldCount: doctype.fields?.length || 0,
    module: doctype.module || 'UN-ASSIGNED',
});

// ============================================================================
// SECTION 3: SUB-COMPONENTS
// ============================================================================

/**
 * Header Component
 */
const DoctypeListHeader = ({ title, count, loading }) => (
    <div className="surface-card border-1 border-round-md surface-border px-4 py-3 flex justify-content-between align-items-center">
        <div>
            <h1 className="text-2xl font-bold m-0 text-900">{title}</h1>
            <p className="text-600 m-0 mt-1">
                Manage document types across all modules
                {!loading && count > 0 && <span className="ml-2">({count} total)</span>}
            </p>
        </div>
    </div>
);

/**
 * Loading Skeleton
 */
const LoadingSkeleton = () => (
    <div className="p-4">
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="80%" height="3rem" />
    </div>
);

/**
 * Empty State
 */
const EmptyState = ({ onCreate }) => (
    <div className="flex flex-column align-items-center justify-content-center p-6">
        <i className="pi pi-inbox text-6xl text-400 mb-4"></i>
        <h3 className="text-600 mb-2 mt-0">No doctypes found</h3>
        <p className="text-500 mb-4 mt-0">Get started by creating your first doctype</p>
        <Button label="Create Doctype" icon="pi pi-plus" onClick={onCreate} />
    </div>
);

/**
 * Error State
 */
const ErrorState = ({ error, onRetry }) => (
    <div className="flex flex-column align-items-center justify-content-center p-6">
        <Message severity="error" text={'Failed to load doctypes'} className="mb-4 w-full" />
        <Button label="Try Again" icon="pi pi-refresh" outlined onClick={onRetry} />
    </div>
);

/**
 * Doctype Details Dialog
 */
const DoctypeDetailsDialog = ({ doctype, visible, onHide, onViewJson, onEdit }) => {
    if (!doctype) return null;

    return (
        <Dialog
            header={doctype.doctypeName}
            visible={visible}
            style={{ width: '600px' }}
            modal
            onHide={onHide}
            footer={
                <div className="flex justify-content-end gap-2">
                    <Button label="Close" icon="pi pi-times" text onClick={onHide} />
                    <Button label="View JSON" icon="pi pi-code" outlined onClick={onViewJson} />
                    <Button label="Edit Form" icon="pi pi-pencil" onClick={onEdit} />
                </div>
            }
        >
            <div>
                <div className="mb-4">
                    <div className="flex align-items-center gap-3 mb-3">
                        <div>
                            <h3 className="m-0">{doctype.doctypeName}</h3>
                            <Tag value={doctype.module?.toUpperCase()} className="mt-1" />
                        </div>
                    </div>
                    {doctype.description && <p className="text-600 mb-3">{doctype.description}</p>}
                </div>

                <Card className="mb-3">
                    <div className="flex align-items-center gap-2 mb-3">
                        <i className="pi pi-sliders-h text-primary"></i>
                        <h4 className="m-0">Properties</h4>
                    </div>
                    <Divider className="mt-0 mb-3" />
                    <div className="grid">
                        <div className="col-6">
                            <div className="flex align-items-center gap-2 mb-2">
                                <i
                                    className={
                                        doctype.is_submittable
                                            ? 'pi pi-check text-green-500'
                                            : 'pi pi-times text-500'
                                    }
                                ></i>
                                <span>Submittable</span>
                            </div>
                            <div className="flex align-items-center gap-2 mb-2">
                                <i
                                    className={
                                        doctype.is_tree
                                            ? 'pi pi-check text-green-500'
                                            : 'pi pi-times text-500'
                                    }
                                ></i>
                                <span>Tree Structure</span>
                            </div>
                            <div className="flex align-items-center gap-2">
                                <i
                                    className={
                                        doctype.issingle
                                            ? 'pi pi-check text-green-500'
                                            : 'pi pi-times text-500'
                                    }
                                ></i>
                                <span>Single Doctype</span>
                            </div>
                        </div>
                        <div className="col-6">
                            <div className="flex align-items-center gap-2 mb-2">
                                <i
                                    className={
                                        doctype.track_changes
                                            ? 'pi pi-check text-green-500'
                                            : 'pi pi-times text-500'
                                    }
                                ></i>
                                <span>Track Changes</span>
                            </div>
                            <div className="flex align-items-center gap-2 mb-2">
                                <i
                                    className={
                                        doctype.allow_rename
                                            ? 'pi pi-check text-green-500'
                                            : 'pi pi-times text-500'
                                    }
                                ></i>
                                <span>Allow Rename</span>
                            </div>
                            <div className="flex align-items-center gap-2">
                                <i
                                    className={
                                        doctype.istable
                                            ? 'pi pi-check text-green-500'
                                            : 'pi pi-times text-500'
                                    }
                                ></i>
                                <span>Child Table</span>
                            </div>
                        </div>
                    </div>
                </Card>

                <Card>
                    <div className="flex align-items-center gap-2 mb-3">
                        <i className="pi pi-info-circle text-primary"></i>
                        <h4 className="m-0">Metadata</h4>
                    </div>
                    <Divider className="mt-0 mb-3" />
                    <div className="grid">
                        <div className="col-12 md:col-4">
                            <label className="block text-500 font-medium mb-1 text-sm">
                                Created
                            </label>
                            <div className="text-900">
                                {new Date(doctype.creation).toLocaleString()}
                            </div>
                        </div>
                        <div className="col-12 md:col-4">
                            <label className="block text-500 font-medium mb-1 text-sm">
                                Last Modified
                            </label>
                            <div className="text-900">
                                {new Date(doctype.modified).toLocaleString()}
                            </div>
                        </div>
                        <div className="col-12 md:col-4">
                            <label className="block text-500 font-medium mb-1 text-sm">
                                Fields Count
                            </label>
                            <div className="text-900">{doctype.fields?.length || 0}</div>
                        </div>
                    </div>
                </Card>
            </div>
        </Dialog>
    );
};

/**
 * JSON Preview Dialog
 */
const JsonPreviewDialog = ({ json, visible, onHide, onCopy }) => (
    <Dialog
        header="Generated DocType JSON"
        visible={visible}
        style={{ width: '700px' }}
        modal
        onHide={onHide}
        footer={
            <div className="flex justify-content-end gap-2">
                <Button label="Copy to Clipboard" icon="pi pi-copy" outlined onClick={onCopy} />
                <Button label="Close" icon="pi pi-times" text onClick={onHide} />
            </div>
        }
    >
        <pre
            className="surface-100 p-3 border-round overflow-auto"
            style={{ maxHeight: '500px', fontSize: '12px' }}
        >
            {JSON.stringify(json, null, 2)}
        </pre>
    </Dialog>
);

/**
 * Create Doctype Dialog
 */
const CreateDoctypeDialog = ({
    visible,
    onHide,
    doctypeForm,
    setDoctypeForm,
    onPreviewJson,
    onCreate,
}) => {
    const resetAndClose = () => {
        setDoctypeForm(DEFAULT_FORM_STATE);
        onHide();
    };

    return (
        <Dialog
            header="Create New Doctype"
            visible={visible}
            style={{ width: '600px' }}
            modal
            onHide={resetAndClose}
            footer={
                <div className="flex justify-content-between">
                    <Button
                        label="Preview JSON"
                        icon="pi pi-code"
                        outlined
                        onClick={onPreviewJson}
                    />
                    <div className="flex gap-2">
                        <Button label="Cancel" icon="pi pi-times" text onClick={resetAndClose} />
                        <Button
                            label="Create & Open Form Builder"
                            icon="pi pi-check"
                            onClick={onCreate}
                        />
                    </div>
                </div>
            }
        >
            <div className="p-fluid">
                {/* Basic Info Section */}
                <div className="mb-4">
                    <h3 className="text-xl mb-3 flex align-items-center gap-2">
                        <i className="pi pi-info-circle"></i>
                        Basic Information
                    </h3>

                    <div className="grid">
                        <div className="col-6">
                            <div className="field">
                                <label htmlFor="name" className="font-medium">
                                    Doctype Name <span className="text-red-500">*</span>
                                </label>
                                <InputText
                                    id="name"
                                    value={doctypeForm.name}
                                    onChange={(e) =>
                                        setDoctypeForm({ ...doctypeForm, name: e.target.value })
                                    }
                                    placeholder="e.g., Employee, Leave Application"
                                    className="w-full"
                                />
                                <small className="text-500">
                                    This will be the document type name
                                </small>
                            </div>
                        </div>
                        <div className="col-6">
                            <div className="field">
                                <label htmlFor="module" className="font-medium">
                                    Module
                                </label>
                                <Dropdown
                                    id="module"
                                    value={doctypeForm.module}
                                    options={MODULES}
                                    onChange={(e) =>
                                        setDoctypeForm({ ...doctypeForm, module: e.value })
                                    }
                                    placeholder="Select Module"
                                    className="w-full"
                                />
                            </div>
                        </div>
                    </div>

                    <div className="field">
                        <label htmlFor="description" className="font-medium">
                            Description
                        </label>
                        <InputTextarea
                            id="description"
                            value={doctypeForm.description}
                            onChange={(e) =>
                                setDoctypeForm({ ...doctypeForm, description: e.target.value })
                            }
                            rows={2}
                            placeholder="Brief description of this doctype"
                            className="w-full"
                        />
                    </div>
                </div>

                {/* Doctype Properties */}
                <div className="mb-4">
                    <h3 className="text-xl mb-3 flex align-items-center gap-2">
                        <i className="pi pi-sliders-h"></i>
                        Doctype Properties
                    </h3>

                    <div className="grid">
                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="isSubmittable"
                                    checked={doctypeForm.isSubmittable}
                                    onChange={(e) =>
                                        setDoctypeForm({
                                            ...doctypeForm,
                                            isSubmittable: e.checked,
                                        })
                                    }
                                />
                                <label htmlFor="isSubmittable" className="ml-2">
                                    Is Submittable
                                </label>
                            </div>
                            <small className="text-500 block ml-4">
                                Documents can be submitted for approval
                            </small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="isTree"
                                    checked={doctypeForm.isTree}
                                    onChange={(e) =>
                                        setDoctypeForm({ ...doctypeForm, isTree: e.checked })
                                    }
                                />
                                <label htmlFor="isTree" className="ml-2">
                                    Is Tree
                                </label>
                            </div>
                            <small className="text-500 block ml-4">
                                Hierarchical structure with parent-child
                            </small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="isSingle"
                                    checked={doctypeForm.isSingle}
                                    onChange={(e) =>
                                        setDoctypeForm({ ...doctypeForm, isSingle: e.checked })
                                    }
                                />
                                <label htmlFor="isSingle" className="ml-2">
                                    Is Single
                                </label>
                            </div>
                            <small className="text-500 block ml-4">
                                Only one record of this type (Settings)
                            </small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="isChild"
                                    checked={doctypeForm.isChild}
                                    onChange={(e) =>
                                        setDoctypeForm({ ...doctypeForm, isChild: e.checked })
                                    }
                                />
                                <label htmlFor="isChild" className="ml-2">
                                    Is Child Table
                                </label>
                            </div>
                            <small className="text-500 block ml-4">
                                Used as a table within other doctypes
                            </small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="trackChanges"
                                    checked={doctypeForm.trackChanges}
                                    onChange={(e) =>
                                        setDoctypeForm({
                                            ...doctypeForm,
                                            trackChanges: e.checked,
                                        })
                                    }
                                />
                                <label htmlFor="trackChanges" className="ml-2">
                                    Track Changes
                                </label>
                            </div>
                            <small className="text-500 block ml-4">Maintain change history</small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="allowRename"
                                    checked={doctypeForm.allowRename}
                                    onChange={(e) =>
                                        setDoctypeForm({
                                            ...doctypeForm,
                                            allowRename: e.checked,
                                        })
                                    }
                                />
                                <label htmlFor="allowRename" className="ml-2">
                                    Allow Rename
                                </label>
                            </div>
                            <small className="text-500 block ml-4">Allow renaming documents</small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="trackViews"
                                    checked={doctypeForm.trackViews}
                                    onChange={(e) =>
                                        setDoctypeForm({
                                            ...doctypeForm,
                                            trackViews: e.checked,
                                        })
                                    }
                                />
                                <label htmlFor="trackViews" className="ml-2">
                                    Track Views
                                </label>
                            </div>
                            <small className="text-500 block ml-4">Track document view count</small>
                        </div>

                        <div className="col-6">
                            <div className="field-checkbox">
                                <Checkbox
                                    inputId="trackSeen"
                                    checked={doctypeForm.trackSeen}
                                    onChange={(e) =>
                                        setDoctypeForm({
                                            ...doctypeForm,
                                            trackSeen: e.checked,
                                        })
                                    }
                                />
                                <label htmlFor="trackSeen" className="ml-2">
                                    Track Seen
                                </label>
                            </div>
                            <small className="text-500 block ml-4">
                                Track who has seen the document
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </Dialog>
    );
};

// ============================================================================
// SECTION 4: MAIN COMPONENT
// ============================================================================

const DoctypeListViewer = () => {
    const navigate = useNavigate();
    const toast = useRef(null);

    // -------------------------------------------------------------------------
    // HOOKS
    // -------------------------------------------------------------------------

    const { saveUISchema } = useDoctypeSchemaPersistence();
    const { loadUISchema } = useDoctypeSchemaLoader();

    const { data: doctypes, loading, error, isEmpty, refresh, addItem, count } = useGetDoctypes();

    // -------------------------------------------------------------------------
    // LOCAL STATE
    // -------------------------------------------------------------------------

    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [selectedDoctype, setSelectedDoctype] = useState(null);
    const [showJsonPreview, setShowJsonPreview] = useState(false);
    const [generatedJson, setGeneratedJson] = useState(null);
    const [doctypeForm, setDoctypeForm] = useState(DEFAULT_FORM_STATE);

    // -------------------------------------------------------------------------
    // COMPUTED VALUES
    // -------------------------------------------------------------------------

    const formattedDoctypes = React.useMemo(() => doctypes.map(formatDoctypeForList), [doctypes]);

    // -------------------------------------------------------------------------
    // EFFECTS
    // -------------------------------------------------------------------------

    useEffect(() => {
        if (error) {
            toast.current?.show({
                severity: 'error',
                summary: 'Error',
                detail: 'Failed to load doctypes',
                life: 5000,
            });
        }
    }, [error]);

    // -------------------------------------------------------------------------
    // VALIDATION
    // -------------------------------------------------------------------------

    const validateForm = () => {
        if (!doctypeForm.name.trim()) {
            toast.current.show({
                severity: 'warn',
                summary: 'Validation Error',
                detail: 'Doctype name is required',
                life: 3000,
            });
            return false;
        }

        const nameRegex = /^[a-zA-Z][a-zA-Z0-9 _]*$/;
        if (!nameRegex.test(doctypeForm.name)) {
            toast.current.show({
                severity: 'warn',
                summary: 'Validation Error',
                detail: 'Name must start with a letter and contain only letters, numbers, spaces, and underscores',
                life: 3000,
            });
            return false;
        }

        const nameExists = doctypes.some(
            (dt) => dt.doctype?.toLowerCase() === doctypeForm.name.toLowerCase(),
        );

        if (nameExists) {
            toast.current.show({
                severity: 'warn',
                summary: 'Validation Error',
                detail: 'A doctype with this name already exists',
                life: 3000,
            });
            return false;
        }

        return true;
    };

    // -------------------------------------------------------------------------
    // GENERATORS
    // -------------------------------------------------------------------------

    const generateDefaultFields = () => {
        const fields = [];
        let idx = 0;

        if (doctypeForm.isSubmittable) {
            fields.push({
                idx: ++idx,
                fieldname: 'status',
                label: 'Status',
                fieldtype: 'Select',
                options: 'Draft\nPending\nApproved\nRejected\nCancelled',
                default: 'Draft',
                in_list_view: 1,
                in_standard_filter: 1,
                read_only: 1,
            });

            fields.push({
                idx: ++idx,
                fieldname: 'amended_from',
                label: 'Amended From',
                fieldtype: 'Link',
                options: doctypeForm.name,
                read_only: 1,
                hidden: 1,
            });
        }

        if (doctypeForm.isTree) {
            fields.push({
                idx: ++idx,
                fieldname: 'parent_' + doctypeForm.name.toLowerCase().replace(/\s+/g, '_'),
                label: 'Parent ' + doctypeForm.name,
                fieldtype: 'Link',
                options: doctypeForm.name,
                in_list_view: 0,
            });

            fields.push({
                idx: ++idx,
                fieldname: 'is_group',
                label: 'Is Group',
                fieldtype: 'Check',
                default: 0,
            });
        }

        return fields;
    };

    const generateDoctypeJson = () => {
        const timestamp = new Date().toISOString();
        const doctypeId = `doctype-${doctypeForm.name.replace(/\s+/g, '_').toLowerCase()}-${Date.now()}`;

        return {
            id: doctypeId,
            doctype: doctypeForm.name,
            module: doctypeForm.module,
            description: doctypeForm.description,
            is_submittable: doctypeForm.isSubmittable ? 1 : 0,
            is_tree: doctypeForm.isTree ? 1 : 0,
            issingle: doctypeForm.isSingle ? 1 : 0,
            istable: doctypeForm.isChild ? 1 : 0,
            track_changes: doctypeForm.trackChanges ? 1 : 0,
            track_seen: doctypeForm.trackSeen ? 1 : 0,
            track_views: doctypeForm.trackViews ? 1 : 0,
            allow_rename: doctypeForm.allowRename ? 1 : 0,
            custom: 1,
            editable_grid: 1,
            quick_entry: 0,
            allow_copy: 1,
            allow_import: 1,
            allow_events_in_timeline: 1,
            allow_auto_repeat: 0,
            fields: generateDefaultFields(),
            creation: timestamp,
            modified: timestamp,
            modified_by: 'Administrator',
            owner: 'Administrator',
        };
    };

    // -------------------------------------------------------------------------
    // HANDLERS
    // -------------------------------------------------------------------------

    const handleRowClick = async (doctype) => {
        try {
            toast.current?.show({
                severity: 'info',
                summary: 'Loading',
                detail: `Loading ${doctype.doctypeName} form schema...`,
                life: 1500,
            });

            navigate('/web/landing/form-builder/record-list-view', {
                state: {
                    doctypeId: doctype.id, // Pass the whole doctype object
                },
            });
        } catch (err) {
            toast.current?.show({
                severity: 'error',
                summary: 'Error',
                detail: 'Failed to load form schema',
                life: 4000,
            });
        }
    };

    const handleAddDoctype = () => {
        setShowCreateDialog(true);
    };

    const handlePreviewJson = () => {
        if (!validateForm()) return;
        const doctypeJson = generateDoctypeJson();
        setGeneratedJson(doctypeJson);
        setShowJsonPreview(true);
    };

    const handleCreateDoctype = async () => {
        if (!validateForm()) return;
        const doctypeJson = generateDoctypeJson();

        try {
            await saveUISchema(doctypeJson);

            addItem(doctypeJson);
            setShowCreateDialog(false);
            setDoctypeForm(DEFAULT_FORM_STATE);

            toast.current.show({
                severity: 'success',
                summary: 'Success',
                detail: 'Doctype created successfully',
                life: 3000,
            });

            navigate('/web/landing/form-builder', {
                state: { schema: doctypeJson },
            });
        } catch (err) {
            console.error('Failed to save schema', err);
            toast.current.show({
                severity: 'error',
                summary: 'Error',
                detail: 'Failed to create doctype',
                life: 5000,
            });
        }
    };

    const handleCopyJson = () => {
        navigator.clipboard.writeText(JSON.stringify(generatedJson, null, 2));
        toast.current.show({
            severity: 'success',
            summary: 'Copied',
            detail: 'JSON copied to clipboard',
            life: 2000,
        });
    };

    const handleOpenFormBuilder = (doctype) => {
        toast.current.show({
            severity: 'info',
            summary: 'Opening Form Builder',
            detail: `Opening form builder for ${doctype.doctypeName}`,
            life: 2000,
        });

        navigate('/web/landing/form-builder', {
            state: { schema: doctype },
        });
    };

    // -------------------------------------------------------------------------
    // RENDER
    // -------------------------------------------------------------------------

    return (
        <div className="surface-ground p-1">
            <Toast ref={toast} appendTo={document.body} />

            {/* Header */}
            <DoctypeListHeader title="Doctypes" count={count} loading={loading} />

            {/* Content */}
            <div className="p-1 mt-3">
                {/* Loading State */}
                {loading && doctypes.length === 0 && <LoadingSkeleton />}

                {/* Error State */}
                {error && !loading && <ErrorState error={error} onRetry={refresh} />}

                {/* Empty State */}
                {!loading && !error && isEmpty && <EmptyState onCreate={handleAddDoctype} />}

                {/* List View with Dynamic Height */}
                {!loading && !error && !isEmpty && (
                    <DynamicHeightWrapper>
                        {(height) => (
                            <ListViewer
                                data={formattedDoctypes}
                                columns={DOCTYPE_COLUMNS}
                                loading={loading}
                                onRowClick={handleRowClick}
                                onRefresh={refresh}
                                onCreate={handleAddDoctype}
                                showSearch={true}
                                showCreateButton={true}
                                showRefreshButton={true}
                                createButtonLabel="Create Doctype"
                                paginator={true}
                                rows={10}
                                rowsPerPageOptions={[10, 25, 50, 100]}
                                emptyMessage="No doctypes found. Create your first doctype to get started."
                                tableHeight={height}
                            />
                        )}
                    </DynamicHeightWrapper>
                )}
            </div>

            {/* Create Doctype Dialog */}
            <CreateDoctypeDialog
                visible={showCreateDialog}
                onHide={() => setShowCreateDialog(false)}
                doctypeForm={doctypeForm}
                setDoctypeForm={setDoctypeForm}
                onPreviewJson={handlePreviewJson}
                onCreate={handleCreateDoctype}
            />

            {/* JSON Preview Dialog */}
            <JsonPreviewDialog
                json={generatedJson}
                visible={showJsonPreview}
                onHide={() => setShowJsonPreview(false)}
                onCopy={handleCopyJson}
            />

            {/* Doctype Details Dialog */}
            <DoctypeDetailsDialog
                doctype={selectedDoctype}
                visible={!!selectedDoctype}
                onHide={() => setSelectedDoctype(null)}
                onViewJson={() => {
                    setGeneratedJson(selectedDoctype);
                    setShowJsonPreview(true);
                }}
                onEdit={() => {
                    handleOpenFormBuilder(selectedDoctype);
                    setSelectedDoctype(null);
                }}
            />
        </div>
    );
};

export default DoctypeListViewer;
