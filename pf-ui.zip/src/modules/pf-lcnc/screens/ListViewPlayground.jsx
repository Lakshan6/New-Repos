// components/ListViewerPlayground/ListViewerPlayground.jsx

import React, { useState, useMemo, useCallback, useRef } from 'react';
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { InputTextarea } from 'primereact/inputtextarea';
import { Divider } from 'primereact/divider';
import { Message } from 'primereact/message';
import { Tag } from 'primereact/tag';
import { TabView, TabPanel } from 'primereact/tabview';
import { Dropdown } from 'primereact/dropdown';
import { Panel } from 'primereact/panel';
import { Toast } from 'primereact/toast';
import { InputText } from 'primereact/inputtext';

import ListViewer from '../components/ListViewer';
import ListViewConfigEditor from '../screens/ListViewConfigEditor';

// ============================================================================
// SAMPLE DATA SETS
// ============================================================================

const SAMPLE_DATASETS = {
    customers: {
        label: 'Customers',
        description: 'Customer records with contact info',
        data: [
            {
                id: 1,
                name: 'John Doe',
                email: 'john@example.com',
                phone: '123-456-7890',
                status: 'Active',
                created_at: '2024-01-15T10:30:00Z',
                is_verified: true,
                credit_limit: 5000.0,
            },
            {
                id: 2,
                name: 'Jane Smith',
                email: 'jane@example.com',
                phone: '098-765-4321',
                status: 'Pending',
                created_at: '2024-02-20T14:45:00Z',
                is_verified: false,
                credit_limit: 3000.0,
            },
            {
                id: 3,
                name: 'Bob Wilson',
                email: 'bob@example.com',
                phone: '555-123-4567',
                status: 'Inactive',
                created_at: '2024-03-10T09:15:00Z',
                is_verified: true,
                credit_limit: 10000.0,
            },
        ],
    },
    orders: {
        label: 'Orders (Nested)',
        description: 'Order records with nested customer data',
        data: [
            {
                id: 'ORD-001',
                order_date: '2024-01-20',
                customer: { name: 'John Doe', id: 1, email: 'john@example.com' },
                items: [
                    { name: 'Laptop', qty: 1 },
                    { name: 'Mouse', qty: 2 },
                ],
                total: 1299.99,
                status: 'Completed',
                shipping_address: {
                    line1: '123 Main St',
                    city: 'New York',
                    zip: '10001',
                },
            },
            {
                id: 'ORD-002',
                order_date: '2024-01-22',
                customer: { name: 'Jane Smith', id: 2, email: 'jane@example.com' },
                items: [{ name: 'Keyboard', qty: 1 }],
                total: 79.99,
                status: 'Processing',
                shipping_address: {
                    line1: '456 Oak Ave',
                    city: 'Los Angeles',
                    zip: '90001',
                },
            },
            {
                id: 'ORD-003',
                order_date: '2024-01-25',
                customer: { name: 'Bob Wilson', id: 3, email: 'bob@example.com' },
                items: [
                    { name: 'Monitor', qty: 2 },
                    { name: 'Webcam', qty: 1 },
                ],
                total: 549.99,
                status: 'Pending',
                shipping_address: {
                    line1: '789 Pine Rd',
                    city: 'Chicago',
                    zip: '60601',
                },
            },
        ],
    },
    products: {
        label: 'Products',
        description: 'Product catalog with pricing',
        data: [
            {
                sku: 'LAP-001',
                name: 'MacBook Pro',
                category: 'Electronics',
                price: 2499.0,
                stock: 50,
                is_active: true,
                tags: ['laptop', 'apple', 'premium'],
                rating: 4.8,
            },
            {
                sku: 'MOU-002',
                name: 'Wireless Mouse',
                category: 'Accessories',
                price: 29.99,
                stock: 200,
                is_active: true,
                tags: ['mouse', 'wireless'],
                rating: 4.2,
            },
            {
                sku: 'KEY-003',
                name: 'Mechanical Keyboard',
                category: 'Accessories',
                price: 149.0,
                stock: 0,
                is_active: false,
                tags: ['keyboard', 'mechanical', 'gaming'],
                rating: 4.6,
            },
        ],
    },
    employees: {
        label: 'Employees',
        description: 'Employee records with department info',
        data: [
            {
                employee_id: 'EMP-001',
                first_name: 'Alice',
                last_name: 'Johnson',
                email: 'alice@company.com',
                department: 'Engineering',
                role: 'Senior Developer',
                salary: 120000,
                hire_date: '2020-03-15',
                is_manager: true,
            },
            {
                employee_id: 'EMP-002',
                first_name: 'Bob',
                last_name: 'Williams',
                email: 'bob@company.com',
                department: 'Marketing',
                role: 'Marketing Manager',
                salary: 95000,
                hire_date: '2019-07-01',
                is_manager: true,
            },
            {
                employee_id: 'EMP-003',
                first_name: 'Carol',
                last_name: 'Davis',
                email: 'carol@company.com',
                department: 'Engineering',
                role: 'Junior Developer',
                salary: 75000,
                hire_date: '2023-01-10',
                is_manager: false,
            },
        ],
    },
};

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const formatJSON = (obj) => {
    try {
        return JSON.stringify(obj, null, 2);
    } catch {
        return 'Error formatting JSON';
    }
};

const parseJSON = (str) => {
    try {
        const parsed = JSON.parse(str);
        return { success: true, data: parsed, error: null };
    } catch (e) {
        return { success: false, data: null, error: e.message };
    }
};

// ============================================================================
// SUB-COMPONENTS
// ============================================================================

const PlaygroundHeader = () => (
    <div className="surface-card px-4 py-3 border-bottom-1 surface-border mb-3">
        <div className="flex align-items-center gap-3">
            <i className="pi pi-th-large text-primary text-2xl"></i>
            <div>
                <h1 className="m-0 text-xl font-semibold text-900">ListView Config Playground</h1>
                <p className="m-0 text-500 text-sm">
                    Test and configure list views with custom JSON data
                </p>
            </div>
        </div>
    </div>
);

const DatasetSelector = ({ selected, onSelect, options }) => {
    const itemTemplate = (option) => (
        <div className="flex flex-column">
            <span className="font-medium">{option.label}</span>
            <span className="text-500 text-sm">{option.description}</span>
        </div>
    );

    return (
        <Dropdown
            value={selected}
            options={options}
            onChange={(e) => onSelect(e.value)}
            placeholder="Select a sample dataset..."
            className="w-full md:w-20rem"
            itemTemplate={itemTemplate}
        />
    );
};

const JSONEditor = ({ value, onChange, error }) => (
    <div className="flex flex-column h-full">
        <InputTextarea
            value={value}
            onChange={(e) => onChange(e.target.value)}
            rows={25}
            className={`w-full font-mono text-sm flex-grow-1 ${error ? 'p-invalid' : ''}`}
            style={{ resize: 'none', minHeight: '500px' }}
            placeholder='[{"id": 1, "name": "Example"}]'
        />
        {error && <Message severity="error" text={error} className="mt-2 w-full" />}
    </div>
);

// ============================================================================
// MAIN COMPONENT
// ============================================================================

const ListViewPlayground = () => {
    const toast = useRef(null);

    // -------------------------------------------------------------------------
    // STATE
    // -------------------------------------------------------------------------

    const [selectedDataset, setSelectedDataset] = useState('orders');
    const [jsonInput, setJsonInput] = useState(formatJSON(SAMPLE_DATASETS.orders.data));
    const [parseError, setParseError] = useState(null);
    const [activeTabIndex, setActiveTabIndex] = useState(0);
    const [exportedConfig, setExportedConfig] = useState(null);

    // Doctype ID input
    const [doctypeId, setDoctypeId] = useState('');

    // State to hold valid parsed records to pass to the Editor
    const [editorRecords, setEditorRecords] = useState([]);

    // Key to force re-mount the editor when data changes
    const [editorKey, setEditorKey] = useState(0);

    // -------------------------------------------------------------------------
    // COMPUTED
    // -------------------------------------------------------------------------

    const datasetOptions = useMemo(() => {
        return Object.entries(SAMPLE_DATASETS).map(([key, value]) => ({
            value: key,
            label: value.label,
            description: value.description,
        }));
    }, []);

    // -------------------------------------------------------------------------
    // HANDLERS
    // -------------------------------------------------------------------------

    const handleDatasetSelect = useCallback((datasetKey) => {
        setSelectedDataset(datasetKey);
        if (datasetKey && SAMPLE_DATASETS[datasetKey]) {
            const rawData = SAMPLE_DATASETS[datasetKey].data;
            setJsonInput(formatJSON(rawData));
            setEditorRecords(rawData);
            setExportedConfig(null);
            setEditorKey((prev) => prev + 1);
        }
    }, []);

    const handleJsonChange = useCallback((value) => {
        setJsonInput(value);
    }, []);

    const handleFormatJson = useCallback(() => {
        try {
            const parsed = JSON.parse(jsonInput);
            setJsonInput(JSON.stringify(parsed, null, 2));
            setParseError(null);
        } catch (error) {
            setParseError(error.message);
        }
    }, [jsonInput]);

    const handleLoadData = useCallback(() => {
        const result = parseJSON(jsonInput);

        if (!result.success) {
            setParseError(result.error);
            toast.current?.show({
                severity: 'error',
                summary: 'Invalid JSON',
                detail: result.error,
                life: 3000,
            });
            return;
        }

        if (!Array.isArray(result.data)) {
            const msg = 'Input must be a JSON array';
            setParseError(msg);
            toast.current?.show({
                severity: 'error',
                summary: 'Invalid Data',
                detail: msg,
                life: 3000,
            });
            return;
        }

        setParseError(null);
        setEditorRecords(result.data);
        setExportedConfig(null);
        setEditorKey((prev) => prev + 1);
        setActiveTabIndex(1);

        toast.current?.show({
            severity: 'success',
            summary: 'Data Loaded',
            detail: `Loaded ${result.data.length} records into Editor`,
            life: 2000,
        });
    }, [jsonInput]);

    const handleExport = useCallback((config) => {
        setExportedConfig(config);
        setActiveTabIndex(2);

        const configStr = JSON.stringify(config, null, 2);
        navigator.clipboard?.writeText(configStr);

        toast.current?.show({
            severity: 'success',
            summary: 'Config Exported',
            detail: 'Configuration copied to clipboard',
            life: 3000,
        });
    }, []);

    const handleCopyOutput = useCallback(() => {
        if (exportedConfig) {
            navigator.clipboard?.writeText(JSON.stringify(exportedConfig, null, 2));
            toast.current?.show({
                severity: 'info',
                summary: 'Copied',
                detail: 'Configuration copied to clipboard',
                life: 2000,
            });
        }
    }, [exportedConfig]);

    // -------------------------------------------------------------------------
    // RENDER
    // -------------------------------------------------------------------------

    return (
        <div className="surface-ground min-h-screen">
            <Toast ref={toast} />
            <PlaygroundHeader />

            <div className="p-3">
                {/* Controls Bar */}
                <Card className="mb-3">
                    <div className="flex align-items-center justify-content-between flex-wrap gap-3">
                        <div className="flex align-items-center gap-3 flex-wrap">
                            <DatasetSelector
                                selected={selectedDataset}
                                onSelect={handleDatasetSelect}
                                options={datasetOptions}
                            />

                            <Divider layout="vertical" className="hidden md:block" />

                            {/* Doctype ID Input */}
                            <div className="flex align-items-center gap-2">
                                <label className="text-sm text-500 white-space-nowrap">
                                    Doctype ID:
                                </label>
                                <InputText
                                    value={doctypeId}
                                    onChange={(e) => setDoctypeId(e.target.value)}
                                    className="p-inputtext-sm"
                                    style={{ width: '280px' }}
                                    placeholder="e.g., e5e2b01c-ac42-4a68-a6dc-52cf2fbfe844"
                                />
                            </div>
                        </div>

                        <div className="flex align-items-center gap-2">
                            <Button
                                label="Format JSON"
                                icon="pi pi-align-left"
                                size="small"
                                outlined
                                onClick={handleFormatJson}
                            />
                            <Button
                                label="Load & Configure"
                                icon="pi pi-cog"
                                size="small"
                                onClick={handleLoadData}
                            />
                        </div>
                    </div>

                    {/* Show active doctypeId if entered */}
                    {doctypeId.trim() && (
                        <div className="mt-3 pt-3 border-top-1 surface-border">
                            <div className="flex align-items-center gap-2">
                                <i className="pi pi-database text-primary"></i>
                                <span className="text-500">Active Doctype ID:</span>
                                <code className="surface-100 px-2 py-1 border-round text-sm font-mono">
                                    {doctypeId.trim()}
                                </code>
                                <Tag
                                    value="Will be used for schema fetch"
                                    severity="info"
                                    className="text-xs"
                                />
                            </div>
                        </div>
                    )}
                </Card>

                {/* Main Content Tabs */}
                <TabView
                    activeIndex={activeTabIndex}
                    onTabChange={(e) => setActiveTabIndex(e.index)}
                >
                    {/* Tab 1: JSON Input */}
                    <TabPanel
                        header={
                            <span className="flex align-items-center gap-2">
                                <i className="pi pi-code"></i>
                                <span>JSON Input</span>
                            </span>
                        }
                    >
                        <JSONEditor
                            value={jsonInput}
                            onChange={handleJsonChange}
                            error={parseError}
                        />
                    </TabPanel>

                    {/* Tab 2: Config Editor (Embedded) */}
                    <TabPanel
                        header={
                            <span className="flex align-items-center gap-2">
                                <i className="pi pi-sliders-h"></i>
                                <span>Config Editor</span>
                                {editorRecords.length > 0 && (
                                    <Tag
                                        value={editorRecords.length}
                                        severity="info"
                                        className="text-xs"
                                    />
                                )}
                            </span>
                        }
                    >
                        {editorRecords.length === 0 ? (
                            <div className="flex flex-column align-items-center justify-content-center p-6">
                                <i className="pi pi-inbox text-5xl text-400 mb-3"></i>
                                <h3 className="text-600 m-0 mb-2">No Data Loaded</h3>
                                <p className="text-500 m-0 mb-3">
                                    Enter valid JSON data in the Input tab and click "Load &
                                    Configure"
                                </p>
                                <Button
                                    label="Go to JSON Input"
                                    icon="pi pi-arrow-left"
                                    outlined
                                    onClick={() => setActiveTabIndex(0)}
                                />
                            </div>
                        ) : (
                            <ListViewConfigEditor
                                key={`editor-${editorKey}`}
                                // Pass doctypeId if provided, otherwise null
                                doctypeId={doctypeId.trim() || null}
                                // Pass the sample records
                                records={editorRecords}
                                // Callback when config is exported
                                onExport={handleExport}
                                // Show header
                                showHeader={true}
                                // Optional: callback for live changes
                                onConfigChange={(cfg) => console.log('Live Config:', cfg)}
                            />
                        )}
                    </TabPanel>

                    {/* Tab 3: Output */}
                    <TabPanel
                        header={
                            <span className="flex align-items-center gap-2">
                                <i className="pi pi-file-export"></i>
                                <span>Output</span>
                                {exportedConfig && (
                                    <i className="pi pi-check-circle text-green-500"></i>
                                )}
                            </span>
                        }
                    >
                        {!exportedConfig ? (
                            <div className="flex flex-column align-items-center justify-content-center p-6">
                                <i className="pi pi-file-export text-5xl text-400 mb-3"></i>
                                <h3 className="text-600 m-0 mb-2">No Configuration Exported</h3>
                                <p className="text-500 m-0 mb-3">
                                    Configure your columns in the Editor tab and click "Export
                                    Config"
                                </p>
                                <Button
                                    label="Go to Editor"
                                    icon="pi pi-arrow-left"
                                    outlined
                                    onClick={() => setActiveTabIndex(1)}
                                />
                            </div>
                        ) : (
                            <div>
                                <div className="flex justify-content-between align-items-center mb-3">
                                    <h3 className="m-0 text-lg font-semibold">
                                        Exported listview_config
                                    </h3>
                                    <Button
                                        label="Copy to Clipboard"
                                        icon="pi pi-copy"
                                        outlined
                                        size="small"
                                        onClick={handleCopyOutput}
                                    />
                                </div>

                                <Panel header="JSON Output" className="mb-3">
                                    <pre
                                        className="text-sm bg-gray-900 text-green-400 p-3 border-round overflow-auto m-0"
                                        style={{ maxHeight: '400px' }}
                                    >
                                        {JSON.stringify(exportedConfig, null, 2)}
                                    </pre>
                                </Panel>

                                <Message
                                    severity="info"
                                    className="w-full mb-3"
                                    content={
                                        <div>
                                            <strong>Usage:</strong> Add this configuration to your
                                            doctype schema under the <code>listview_config</code>{' '}
                                            key.
                                        </div>
                                    }
                                />

                                {/* Preview with exported config */}
                                {editorRecords.length > 0 && (
                                    <Panel
                                        header={
                                            <div className="flex align-items-center gap-2">
                                                <i className="pi pi-eye"></i>
                                                <span>Final Result Preview</span>
                                                <Tag
                                                    value={`${editorRecords.length} records`}
                                                    severity="info"
                                                    className="ml-2"
                                                />
                                            </div>
                                        }
                                        toggleable
                                    >
                                        <ListViewer
                                            data={editorRecords}
                                            columns={exportedConfig.columns}
                                            loading={false}
                                            showSearch={true}
                                            showCreateButton={false}
                                            showRefreshButton={false}
                                            paginator={true}
                                            rows={5}
                                            rowsPerPageOptions={[5, 10, 25]}
                                            emptyMessage="No data to display"
                                            tableHeight="300px"
                                            onRowClick={(row) => {
                                                console.log('Row clicked:', row);
                                            }}
                                        />
                                    </Panel>
                                )}
                            </div>
                        )}
                    </TabPanel>
                </TabView>
            </div>
        </div>
    );
};

export default ListViewPlayground;
