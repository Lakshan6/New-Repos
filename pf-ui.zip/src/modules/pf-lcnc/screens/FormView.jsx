// views/FormView.jsx

import React, { useMemo, useCallback, useRef, useEffect } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { Toast } from 'primereact/toast';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Skeleton } from 'primereact/skeleton';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import FormRenderer from '../components/FormRenderer';
import { useDoctypeSchemaLoader } from '../hooks/useDoctypeSchemaLoader';
import { useRecordData } from '../hooks/useRecordData';
import { generateAutoSchema } from '../components/autoSchema/generateAutoSchema';
import useFetchDoctype from '../hooks/useFetchDoctype';
import { useDeleteRecord } from '../hooks/useDeleteRecord';
import { useSaveRecord } from '../hooks/useSaveRecord';

// ============================================================================
// HELPER FUNCTIONS
// ============================================================================

const isSchemaEmpty = (schema) => {
    if (!schema) return true;
    if (typeof schema !== 'object') return true;
    if (!schema.fields) return true;
    if (!Array.isArray(schema.fields)) return true;
    if (schema.fields.length === 0) return true;
    return false;
};

const isDataEmpty = (data) => {
    if (!data) return true;
    if (typeof data !== 'object') return true;
    if (Array.isArray(data)) return data.length === 0;
    return Object.keys(data).length === 0;
};

// ============================================================================
// SUB COMPONENTS
// ============================================================================

const LoadingScreen = ({ message }) => (
    <div className="surface-ground min-h-screen">
        <div className="surface-card px-4 py-3 border-bottom-1 surface-border">
            <Skeleton width="200px" height="2rem" />
        </div>
        <div className="p-4">
            <Card>
                <div className="flex flex-column align-items-center py-6">
                    <ProgressSpinner />
                    <p className="mt-3 text-600">{message}</p>
                </div>
            </Card>
        </div>
    </div>
);

const ErrorScreen = ({ title, message, details, onBack, onRetry }) => (
    <div className="surface-ground min-h-screen p-4">
        <Card className="text-center">
            <i className="pi pi-exclamation-circle text-red-500 text-5xl mb-3" />
            <h3 className="m-0">{title}</h3>
            <p className="text-600 mb-2">{message}</p>
            {details && <p className="text-500 text-sm mb-4">{details}</p>}
            <div className="flex justify-content-center gap-2">
                <Button label="Back" icon="pi pi-arrow-left" onClick={onBack} />
                {onRetry && (
                    <Button label="Retry" icon="pi pi-refresh" outlined onClick={onRetry} />
                )}
            </div>
        </Card>
    </div>
);

const UnsupportedApiScreen = ({ doctypeName, onBack }) => (
    <div className="surface-ground min-h-screen p-4">
        <Card className="text-center">
            <i className="pi pi-info-circle text-blue-500 text-5xl mb-3" />
            <h3 className="m-0">API Not Configured</h3>
            <p className="text-600 mb-4">
                The doctype <strong>{doctypeName}</strong> does not have an API endpoint configured.
            </p>
            <Button label="Back" icon="pi pi-arrow-left" onClick={onBack} />
        </Card>
    </div>
);

// ============================================================================
// MAIN COMPONENT
// ============================================================================

const FormView = () => {
    const location = useLocation();
    const navigate = useNavigate();
    const toast = useRef(null);

    // ---------------------------------------------------------------------
    // ROUTE INPUTS (FROM LOCATION STATE)
    // ---------------------------------------------------------------------

    const { doctypeId, recordId } = location.state || {};
    const isNewRecord = !recordId || recordId === 'new';

    // ---------------------------------------------------------------------
    // HOOK 1: FETCH DOCTYPE
    // ---------------------------------------------------------------------

    const {
        fetchDoctype,
        data: doctype,
        isPending: doctypeLoading,
        isError: doctypeError,
        error: doctypeErrorObj,
    } = useFetchDoctype();

    useEffect(() => {
        if (doctypeId) fetchDoctype(doctypeId);
    }, [doctypeId, fetchDoctype]);

    const registryId = doctype?.id;
    const doctypeName = doctype?.doctypeName;
    const moduleName = doctype?.module;

    // ---------------------------------------------------------------------
    // HOOK 2: FETCH SCHEMA
    // ---------------------------------------------------------------------

    const {
        loadUISchema,
        data: schema,
        loading: schemaLoading,
        error: schemaError,
    } = useDoctypeSchemaLoader();

    useEffect(() => {
        if (doctypeName && moduleName) {
            loadUISchema({
                doctypeName,
                module: moduleName,
            });
        }
    }, [doctypeName, moduleName, loadUISchema]);

    // ---------------------------------------------------------------------
    // HOOK 3: FETCH RECORD DATA (for viewing/editing existing records)
    // ---------------------------------------------------------------------

    const shouldFetchRecord = !!registryId && !!recordId && !isNewRecord;

    const {
        data,
        isLoading: dataLoading,
        error: dataError,
        refresh,
        supported,
    } = useRecordData({
        registryId,
        recordId,
        enabled: shouldFetchRecord,
    });

    // ---------------------------------------------------------------------
    // HOOK 4: SAVE RECORD (Imperative)
    // ---------------------------------------------------------------------

    const { saveRecord, isSaving, error: saveError } = useSaveRecord();

    // ---------------------------------------------------------------------
    // HOOK 5: DELETE RECORD (Imperative)
    // ---------------------------------------------------------------------

    const { deleteRecord, isDeleting, error: deleteError } = useDeleteRecord();

    // ---------------------------------------------------------------------
    // FINAL SCHEMA RESOLUTION
    // ---------------------------------------------------------------------

    const finalSchema = useMemo(() => {
        if (!isSchemaEmpty(schema)) {
            return schema;
        }

        if (!isDataEmpty(data)) {
            return generateAutoSchema(
                Array.isArray(data) ? data : [data],
                doctypeName || 'Record',
                moduleName,
                doctype,
            );
        }

        return null;
    }, [schema, data, doctypeName, moduleName, doctype]);

    // ---------------------------------------------------------------------
    // CALLBACKS
    // ---------------------------------------------------------------------

    const handleBack = useCallback(() => navigate(-1), [navigate]);

    const handleSave = useCallback(
        async (formData) => {
            try {
                const result = await saveRecord({
                    registryId,
                    recordId: isNewRecord ? null : recordId,
                    formData,
                    isNew: isNewRecord,
                });

                toast.current?.show({
                    severity: 'success',
                    summary: 'Success',
                    detail: isNewRecord
                        ? 'Record created successfully'
                        : 'Record updated successfully',
                    life: 3000,
                });

                // For new records, navigate to the created record's form view
                if (isNewRecord && (result?.id || result?.name)) {
                    const newRecordId = result.id || result.name;
                    navigate('/web/landing/form-builder/form-view', {
                        replace: true,
                        state: {
                            doctypeId,
                            recordId: newRecordId,
                        },
                    });
                } else if (!isNewRecord) {
                    // For updates, refresh the data
                    refresh?.();
                }

                return result;
            } catch (error) {
                console.error('Save failed:', error);
                toast.current?.show({
                    severity: 'error',
                    summary: 'Save Failed',
                    detail: error?.message || 'An error occurred while saving the record.',
                    life: 5000,
                });
                throw error; // Re-throw so FormRenderer can handle it if needed
            }
        },
        [saveRecord, registryId, recordId, isNewRecord, navigate, doctypeId, refresh],
    );

    const handleDelete = useCallback(() => {
        if (isNewRecord) return;

        confirmDialog({
            message: `Are you sure you want to permanently delete this ${doctypeName || 'record'}?`,
            header: 'Delete Confirmation',
            icon: 'pi pi-exclamation-triangle',
            acceptClassName: 'p-button-danger',
            rejectClassName: 'p-button-secondary p-button-outlined',
            acceptLabel: 'Yes, Delete',
            rejectLabel: 'Cancel',
            accept: async () => {
                try {
                    await deleteRecord({
                        registryId,
                        recordId,
                    });

                    toast.current?.show({
                        severity: 'success',
                        summary: 'Deleted Successfully',
                        detail: `${doctypeName || 'Record'} has been deleted.`,
                        life: 3000,
                    });

                    setTimeout(() => navigate(-1), 600);
                } catch (error) {
                    console.error('Delete failed:', error);
                    toast.current?.show({
                        severity: 'error',
                        summary: 'Delete Failed',
                        detail: error?.message || 'An error occurred while deleting the record.',
                        life: 5000,
                    });
                }
            },
            reject: () => {
                toast.current?.show({
                    severity: 'info',
                    summary: 'Cancelled',
                    detail: 'Delete operation was cancelled.',
                    life: 2000,
                });
            },
        });
    }, [doctypeName, registryId, recordId, deleteRecord, navigate, isNewRecord]);

    // ---------------------------------------------------------------------
    // COMPUTED STATES FOR GUARDS
    // ---------------------------------------------------------------------

    const isLoading =
        doctypeLoading ||
        schemaLoading ||
        (shouldFetchRecord && dataLoading) ||
        isDeleting ||
        isSaving; // ← ADD isSaving to loading state

    const apiNotSupported = shouldFetchRecord && !dataLoading && supported === false;

    // ---------------------------------------------------------------------
    // RENDER GUARDS
    // ---------------------------------------------------------------------

    // 0. No navigation state provided
    if (!doctypeId) {
        return (
            <ErrorScreen
                title="Missing Information"
                message="No doctype information provided."
                details="Please navigate from a valid list view."
                onBack={handleBack}
            />
        );
    }

    // 1. Loading state
    if (isLoading) {
        return <LoadingScreen message="Loading..." />;
    }

    // 2. Doctype error
    if (doctypeError) {
        return (
            <ErrorScreen
                title="Failed to load Doctype"
                message={doctypeErrorObj?.message}
                onBack={handleBack}
            />
        );
    }

    // 3. No doctype found
    if (!doctype) {
        return (
            <ErrorScreen
                title="Doctype Not Found"
                message="The requested doctype does not exist."
                onBack={handleBack}
            />
        );
    }

    // 4. API not supported
    if (apiNotSupported) {
        return <UnsupportedApiScreen doctypeName={doctypeName} onBack={handleBack} />;
    }

    // 5. Record not found
    if (!isNewRecord && !data && !dataLoading) {
        return (
            <ErrorScreen
                title="Record Not Found"
                message={`Record ${recordId} does not exist`}
                onBack={handleBack}
            />
        );
    }

    // ---------------------------------------------------------------------
    // MAIN RENDER
    // ---------------------------------------------------------------------

    const displayValue = data?.[doctype?.title_field] || data?.name || data?.id || recordId;
    const displayLabel = doctype?.title_field
        ? doctype.title_field.replace(/_/g, ' ').toTitleCase()
        : 'ID';

    return (
        <div className="surface-ground min-h-screen">
            <Toast ref={toast} />
            <ConfirmDialog />
            <FormRenderer
                schema={finalSchema}
                data={data || {}}
                doctypeName={doctypeName}
                doctypeRegistry={doctype}
                onSave={handleSave}
                onDelete={!isNewRecord ? handleDelete : undefined}
                readOnly={false}
                showEditButton={!isNewRecord}
                recordIdentifier={displayValue}
                recordIdentifierLabel={displayLabel}
                isSaving={isSaving} // ← Pass saving state to show loading indicator
            />
        </div>
    );
};

export default FormView;
