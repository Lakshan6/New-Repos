import React, { useState, useRef, useCallback, useEffect, useMemo } from 'react';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Dropdown } from 'primereact/dropdown';
import { Tag } from 'primereact/tag';
import { Card } from 'primereact/card';
import { Toast } from 'primereact/toast';
import { Message } from 'primereact/message';
import { Skeleton } from 'primereact/skeleton';
import { Divider } from 'primereact/divider';
import { useLocation, useNavigate } from 'react-router';

import ListViewer from '../components/ListViewer';
import DynamicHeightWrapper from '@shared/components/DynamicHeightWrapper';
import { useGetRecords } from '../hooks/useGetRecords';
import useFetchDoctype from '../hooks/useFetchDoctype';
import { useDoctypeSchemaLoader } from '../hooks/useDoctypeSchemaLoader';
import { generateListViewConfigFromData } from '../components/autoSchema/generateListViewConfigFromData';

// ============================================================================
// SECTION 1: CONSTANTS
// ============================================================================

const STATUS_SEVERITY_MAP = {
    Active: 'success',
    Inactive: 'warning',
    Draft: 'info',
    Submitted: 'success',
    Pending: 'warning',
    Processing: 'info',
    Completed: 'success',
    Approved: 'success',
    Rejected: 'danger',
    Cancelled: 'danger',
};

const DEFAULT_COLUMNS = [
    { field: 'id', header: 'ID', sortable: true },
    { field: 'name', header: 'Name', sortable: true },
    { field: 'updatedAt', header: 'Last Modified', sortable: true },
];

// ============================================================================
// SECTION 2: UTILITY FUNCTIONS
// ============================================================================

const getStatusSeverity = (status) => STATUS_SEVERITY_MAP[status] || 'info';

const formatDisplayValue = (value) => {
    if (value === null || value === undefined || value === '') return '—';
    return String(value);
};

const formatRecordForList = (record) => ({
    id: record.name || record.id,
    name: record.name || record.employee_name || record.customer_name || record.id,
    status: record.status || 'Active',
    updatedAt: record.modified
        ? new Date(record.modified).toLocaleString()
        : new Date().toLocaleString(),
    ...record,
});

// ============================================================================
// SECTION 3: SUB-COMPONENTS (unchanged - keeping for completeness)
// ============================================================================

const RecordListHeader = ({ title, onEditListView }) => (
    <div className="surface-card border-1 border-round-md surface-border px-4 py-3 flex justify-content-between align-items-center">
        <h1 className="text-2xl font-bold m-0 text-900">{title || 'Records'}</h1>
        <Button
            label="Edit List View"
            icon="pi pi-pencil"
            outlined
            size="small"
            onClick={onEditListView}
        />
    </div>
);

const LoadingSkeleton = () => (
    <div className="p-4">
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="100%" height="3rem" className="mb-3" />
        <Skeleton width="80%" height="3rem" />
    </div>
);

const EmptyState = ({ doctypeName, onAddRecord }) => (
    <div className="flex flex-column align-items-center justify-content-center p-6">
        <i className="pi pi-inbox text-6xl text-400 mb-4"></i>
        <h3 className="text-600 mb-2 mt-0">No {doctypeName} records found</h3>
        <p className="text-500 mb-4 mt-0">Get started by creating your first record</p>
        <Button label="Create Record" icon="pi pi-plus" onClick={onAddRecord} />
    </div>
);

const ErrorState = ({ error, onRetry }) => (
    <div className="flex flex-column align-items-center justify-content-center p-6">
        <Message severity="error" text={'Failed to load records'} className="mb-4 w-full" />
        <Button label="Try Again" icon="pi pi-refresh" outlined onClick={onRetry} />
    </div>
);

const NoDoctypeState = () => (
    <div className="surface-ground min-h-screen flex align-items-center justify-content-center p-4">
        <Card className="w-full max-w-30rem text-center">
            <i className="pi pi-exclamation-triangle text-5xl text-yellow-500 mb-3"></i>
            <h3 className="mt-0 mb-2 text-900">No Doctype Selected</h3>
            <p className="text-600 m-0">Please select a doctype to view records.</p>
        </Card>
    </div>
);

const RecordDetailView = ({ record, schema, doctype, onBack, onEdit, onDelete }) => {
    const displayFields = useMemo(() => {
        if (schema?.fields) {
            return schema.fields
                .filter(
                    (f) => !['Tab Break', 'Section Break', 'Column Break'].includes(f.fieldtype),
                )
                .map((f) => ({
                    key: f.fieldname,
                    label: f.label || f.fieldname,
                    type: f.fieldtype,
                }));
        }

        return Object.keys(record)
            .filter((key) => !['id', 'owner', 'modified_by'].includes(key))
            .map((key) => ({
                key,
                label: key.replace(/_/g, ' ').replace(/\b\w/g, (c) => c.toUpperCase()),
                type: 'Data',
            }));
    }, [schema, record]);

    const recordTitle = schema?.doctypeName || doctype?.doctypeName || 'Doctype';

    return (
        <div className="surface-ground min-h-screen">
            <div className="surface-card border-bottom-1 surface-border px-4 py-3 flex align-items-center gap-3">
                <Button
                    icon="pi pi-arrow-left"
                    text
                    rounded
                    onClick={onBack}
                    tooltip="Back to list"
                    tooltipOptions={{ position: 'bottom' }}
                />
                <h2 className="m-0 flex-grow-1 text-900">{recordTitle}</h2>
                {record.status && (
                    <Tag value={record.status} severity={getStatusSeverity(record.status)} />
                )}
                <Divider layout="vertical" className="mx-2" />
                <Button
                    icon="pi pi-pencil"
                    outlined
                    size="small"
                    onClick={() => onEdit?.(record)}
                    tooltip="Edit"
                    tooltipOptions={{ position: 'bottom' }}
                />
                <Button
                    icon="pi pi-trash"
                    outlined
                    severity="danger"
                    size="small"
                    onClick={() => onDelete?.(record.name || record.id)}
                    tooltip="Delete"
                    tooltipOptions={{ position: 'bottom' }}
                />
            </div>

            <div className="p-4">
                <Card className="mb-4">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-file text-primary text-xl"></i>
                        <h3 className="m-0 text-900">Record Details</h3>
                    </div>
                    <Divider className="mt-0" />
                    <div className="grid">
                        {displayFields.map(({ key, label }) => {
                            const value = record[key];
                            if (value === undefined) return null;

                            return (
                                <div key={key} className="col-12 md:col-6 lg:col-4 mb-3">
                                    <label className="block text-500 font-medium mb-1 text-sm">
                                        {label}
                                    </label>
                                    <div className="text-900">
                                        {key === 'status' ? (
                                            <Tag
                                                value={value}
                                                severity={getStatusSeverity(value)}
                                            />
                                        ) : (
                                            formatDisplayValue(value)
                                        )}
                                    </div>
                                </div>
                            );
                        })}
                    </div>
                </Card>

                <Card>
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-info-circle text-primary text-xl"></i>
                        <h3 className="m-0 text-900">System Information</h3>
                    </div>
                    <Divider className="mt-0" />
                    <div className="grid">
                        <div className="col-12 md:col-4">
                            <label className="block text-500 font-medium mb-1 text-sm">ID</label>
                            <div className="text-900 font-mono">{record.name || record.id}</div>
                        </div>
                        <div className="col-12 md:col-4">
                            <label className="block text-500 font-medium mb-1 text-sm">
                                Modified
                            </label>
                            <div className="text-900">
                                {record.modified ? new Date(record.modified).toLocaleString() : '—'}
                            </div>
                        </div>
                        <div className="col-12 md:col-4">
                            <label className="block text-500 font-medium mb-1 text-sm">Owner</label>
                            <div className="text-900">{record.owner || 'Administrator'}</div>
                        </div>
                    </div>
                </Card>
            </div>
        </div>
    );
};

const NewRecordDialog = ({ visible, doctypeName, schema, onHide, onSubmit, isSubmitting }) => {
    const [formData, setFormData] = useState({});

    const formFields = useMemo(() => {
        if (schema?.fields) {
            return schema.fields
                .filter(
                    (f) => !['Tab Break', 'Section Break', 'Column Break'].includes(f.fieldtype),
                )
                .filter((f) => !f.read_only)
                .slice(0, 10);
        }

        return [
            { fieldname: 'name', label: 'Name', fieldtype: 'Data', reqd: 1 },
            {
                fieldname: 'status',
                label: 'Status',
                fieldtype: 'Select',
                options: 'Draft\nActive\nInactive',
            },
        ];
    }, [schema]);

    const handleSubmit = () => {
        onSubmit(formData);
        setFormData({});
    };

    const handleHide = () => {
        setFormData({});
        onHide();
    };

    const updateField = (fieldname, value) => {
        setFormData((prev) => ({ ...prev, [fieldname]: value }));
    };

    const renderFieldInput = (field) => {
        const value = formData[field.fieldname] || '';

        switch (field.fieldtype) {
            case 'Small Text':
            case 'Text':
            case 'Long Text':
                return (
                    <InputTextarea
                        value={value}
                        onChange={(e) => updateField(field.fieldname, e.target.value)}
                        rows={3}
                        className="w-full"
                        autoResize
                    />
                );

            case 'Select': {
                const options = field.options
                    ? field.options.split('\n').map((opt) => ({
                          label: opt.trim(),
                          value: opt.trim(),
                      }))
                    : [];
                return (
                    <Dropdown
                        value={value}
                        options={options}
                        onChange={(e) => updateField(field.fieldname, e.value)}
                        placeholder="Select..."
                        className="w-full"
                    />
                );
            }

            case 'Int':
            case 'Float':
            case 'Currency':
                return (
                    <InputText
                        type="number"
                        value={value}
                        onChange={(e) => updateField(field.fieldname, e.target.value)}
                        className="w-full"
                    />
                );

            case 'Date':
                return (
                    <InputText
                        type="date"
                        value={value}
                        onChange={(e) => updateField(field.fieldname, e.target.value)}
                        className="w-full"
                    />
                );

            default:
                return (
                    <InputText
                        value={value}
                        onChange={(e) => updateField(field.fieldname, e.target.value)}
                        className="w-full"
                    />
                );
        }
    };

    const dialogFooter = (
        <div className="flex justify-content-end gap-2">
            <Button
                label="Cancel"
                icon="pi pi-times"
                text
                onClick={handleHide}
                disabled={isSubmitting}
            />
            <Button
                label="Create"
                icon={isSubmitting ? 'pi pi-spin pi-spinner' : 'pi pi-check'}
                onClick={handleSubmit}
                disabled={isSubmitting}
            />
        </div>
    );

    return (
        <Dialog
            header={`New ${doctypeName || 'Record'}`}
            visible={visible}
            style={{ width: '50vw' }}
            breakpoints={{ '960px': '75vw', '641px': '95vw' }}
            maximizable
            modal
            onHide={handleHide}
            footer={dialogFooter}
        >
            <div className="grid">
                {formFields.map((field) => (
                    <div key={field.fieldname} className="col-12 md:col-6 mb-3">
                        <label className="block font-medium mb-2 text-900">
                            {field.label || field.fieldname}
                            {field.reqd ? <span className="text-red-500 ml-1">*</span> : null}
                        </label>
                        {renderFieldInput(field)}
                    </div>
                ))}
            </div>
        </Dialog>
    );
};

// ============================================================================
// SECTION 4: MAIN COMPONENT
// ============================================================================

const RecordListViewer = () => {
    // -------------------------------------------------------------------------
    // ROUTING & PARAMS
    // -------------------------------------------------------------------------

    const location = useLocation();
    const navigate = useNavigate();
    const { doctypeId } = location.state || {};

    // -------------------------------------------------------------------------
    // REFS
    // -------------------------------------------------------------------------

    const toast = useRef(null);

    // KEY FIX: Track if schema fetch has been initiated for current params
    const schemaFetchedFor = useRef(null);

    // -------------------------------------------------------------------------
    // USE FETCH DOCTYPE HOOK
    // -------------------------------------------------------------------------

    const {
        fetchDoctype,
        data: doctype,
        isPending: doctypeLoading,
        isError: doctypeError,
        error: doctypeErrorObj,
    } = useFetchDoctype();

    useEffect(() => {
        if (doctypeId) {
            fetchDoctype(doctypeId);
        }
    }, [doctypeId, fetchDoctype]);

    const registryId = doctype?.id || doctypeId;
    const doctypeName = doctype?.doctypeName;
    const moduleName = doctype?.module || null;

    // -------------------------------------------------------------------------
    // USE SCHEMA LOADER HOOK
    // -------------------------------------------------------------------------

    const {
        loadUISchema,
        data: schema,
        loading: schemaLoading,
        isError: schemaError,
    } = useDoctypeSchemaLoader();

    // KEY FIX: Only fetch schema once per doctypeName+moduleName combination
    useEffect(() => {
        const cacheKey = `${doctypeName}:${moduleName}`;

        // Only fetch if:
        // 1. We have both required params
        // 2. We haven't already fetched for this combination
        // 3. Not currently loading
        if (doctypeName && moduleName && schemaFetchedFor.current !== cacheKey && !schemaLoading) {
            schemaFetchedFor.current = cacheKey;
            loadUISchema({ doctypeName, module: moduleName });
        }
    }, [doctypeName, moduleName, loadUISchema, schemaLoading]);

    // Reset the ref when doctypeId changes (navigating to different doctype)
    useEffect(() => {
        schemaFetchedFor.current = null;
    }, [doctypeId]);

    // -------------------------------------------------------------------------
    // RECORD LIST HOOK
    // -------------------------------------------------------------------------

    const {
        data: records,
        loading,
        error,
        isEmpty,
        refresh,
        addItem,
        removeItem,
    } = useGetRecords({
        registryId,
        enabled: !!registryId,
    });

    // -------------------------------------------------------------------------
    // LOCAL STATE
    // -------------------------------------------------------------------------

    const [selectedRecord, setSelectedRecord] = useState(null);
    const [showNewRecordDialog, setShowNewRecordDialog] = useState(false);
    const [isSubmitting, setIsSubmitting] = useState(false);

    // -------------------------------------------------------------------------
    // COMPUTED VALUES
    // -------------------------------------------------------------------------

    const listRecords = useMemo(() => records.map(formatRecordForList), [records]);

    const documentTitle = useMemo(
        () => schema?.doctype || doctypeName || 'Records',
        [schema, doctypeName],
    );

    // KEY FIX: Determine if schema has "settled" (finished loading, success or failure)
    const schemaSettled = useMemo(() => {
        // Schema is settled when:
        // 1. Not currently loading AND
        // 2. Either we have schema data OR there was an error
        return !schemaLoading && (schema !== undefined || schemaError);
    }, [schemaLoading, schema, schemaError]);

    // KEY FIX: Only generate fallback columns after schema has settled
    const allColumns = useMemo(() => {
        // Still loading schema - return default columns (don't auto-generate yet)
        if (schemaLoading) {
            return DEFAULT_COLUMNS;
        }

        // Schema loaded successfully with columns
        if (schema?.listview_config?.columns?.length) {
            return schema.listview_config.columns;
        }

        // Schema settled (loaded but no columns, or error) - now we can fallback
        if (schemaSettled && records.length > 0) {
            return generateListViewConfigFromData(records).columns;
        }

        // Fallback to defaults
        return DEFAULT_COLUMNS;
    }, [schema, records, schemaLoading, schemaSettled]);

    // -------------------------------------------------------------------------
    // HANDLERS (unchanged)
    // -------------------------------------------------------------------------

    const handleEditListView = useCallback(() => {
        const currentConfig = schema?.listview_config?.columns?.length
            ? schema.listview_config
            : generateListViewConfigFromData(records);

        navigate('/web/landing/form-builder/listview-config-editor', {
            state: {
                //schema: schema,
                //listviewConfig: currentConfig,
                doctypeId: doctype?.id || doctypeId,
                records: records.slice(0, 5),
            },
        });
    }, [schema, records, doctype, doctypeId, navigate]);

    const handleRowClick = useCallback(
        (row) => {
            const recordId = row.id;
            navigate('/web/landing/form-builder/form-view', {
                state: {
                    doctypeId: doctype.id,
                    recordId,
                },
            });
        },
        [navigate, doctype],
    );

    const handleAddRecord = useCallback(() => {
        setShowNewRecordDialog(true);
    }, []);

    const handleCreateRecord = useCallback(
        async (data) => {
            setIsSubmitting(true);
            try {
                const newRecord = {
                    name: `${doctypeName?.toUpperCase().slice(0, 4) || 'REC'}-${Date.now()}`,
                    ...data,
                    status: data.status || 'Draft',
                    created: new Date().toISOString(),
                    modified: new Date().toISOString(),
                    owner: 'Administrator',
                };

                addItem(newRecord);
                setShowNewRecordDialog(false);

                toast.current?.show({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Record created successfully',
                    life: 3000,
                });
            } catch (err) {
                toast.current?.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: err.message || 'Failed to create record',
                    life: 5000,
                });
            } finally {
                setIsSubmitting(false);
            }
        },
        [doctypeName, addItem],
    );

    const handleDeleteRecord = useCallback(
        async (recordId) => {
            try {
                removeItem(recordId);

                if (selectedRecord?.name === recordId || selectedRecord?.id === recordId) {
                    setSelectedRecord(null);
                }

                toast.current?.show({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Record deleted successfully',
                    life: 3000,
                });
            } catch (err) {
                toast.current?.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: err.message || 'Failed to delete record',
                    life: 5000,
                });
            }
        },
        [removeItem, selectedRecord],
    );

    const handleEditRecord = useCallback(
        (record) => {
            navigate('/web/landing/form-renderer', {
                state: { schema, data: record },
            });
        },
        [navigate, schema],
    );

    const handleBack = useCallback(() => {
        setSelectedRecord(null);
    }, []);

    // -------------------------------------------------------------------------
    // RENDER CONDITIONS
    // -------------------------------------------------------------------------

    // Show loading while doctype is loading
    if (doctypeLoading) {
        return <LoadingSkeleton />;
    }

    if (doctypeError) {
        return <ErrorState error={doctypeErrorObj} onRetry={() => fetchDoctype(doctypeId)} />;
    }

    if (!doctype || !registryId) {
        return <NoDoctypeState />;
    }

    if (selectedRecord) {
        return (
            <div className="surface-ground min-h-screen">
                <Toast ref={toast} />
                <RecordDetailView
                    record={selectedRecord}
                    doctype={doctype}
                    schema={schema}
                    onBack={handleBack}
                    onEdit={handleEditRecord}
                    onDelete={handleDeleteRecord}
                />
            </div>
        );
    }

    // -------------------------------------------------------------------------
    // MAIN RENDER
    // -------------------------------------------------------------------------

    // Combined loading state - show skeleton if either doctype or schema is loading
    const isInitialLoading = doctypeLoading || (schemaLoading && !schema);

    return (
        <div className="surface-ground p-1">
            <Toast ref={toast} />

            <RecordListHeader title={documentTitle} onEditListView={handleEditListView} />

            <div className="p-1 mt-3">
                {/* Show loading for initial load OR if records are loading with no data */}
                {(isInitialLoading || (loading && records.length === 0)) && <LoadingSkeleton />}

                {error && !loading && <ErrorState error={error} onRetry={refresh} />}

                {!loading && !error && isEmpty && !isInitialLoading && (
                    <EmptyState doctypeName={doctypeName} onAddRecord={handleAddRecord} />
                )}

                {!loading && !error && !isEmpty && !isInitialLoading && (
                    <DynamicHeightWrapper>
                        {(height) => (
                            <ListViewer
                                data={listRecords}
                                columns={allColumns}
                                loading={loading || schemaLoading}
                                onRowClick={handleRowClick}
                                onRefresh={refresh}
                                onCreate={handleAddRecord}
                                showSearch={true}
                                showCreateButton={true}
                                showRefreshButton={true}
                                createButtonLabel="Add Record"
                                paginator={true}
                                rows={10}
                                rowsPerPageOptions={[10, 25, 50, 100]}
                                emptyMessage={`No ${doctypeName} records found`}
                                tableHeight={height}
                            />
                        )}
                    </DynamicHeightWrapper>
                )}
            </div>

            <NewRecordDialog
                visible={showNewRecordDialog}
                doctypeName={doctypeName}
                schema={schema}
                onHide={() => setShowNewRecordDialog(false)}
                onSubmit={handleCreateRecord}
                isSubmitting={isSubmitting}
            />
        </div>
    );
};

export default RecordListViewer;
