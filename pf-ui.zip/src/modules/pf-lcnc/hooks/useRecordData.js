import { useCallback, useEffect, useMemo } from 'react';
import { useReadApi } from '@shared/hooks';

export function useRecordData({ registryId, recordId, enabled = true }) {
    const authToken = localStorage.getItem('authToken') ?? '';

    // ---------------------------------------------------------------------
    // 1️⃣ RESOLVE API
    // ---------------------------------------------------------------------

    const shouldResolve = enabled && !!registryId && !!recordId;

    console.log('[USE RECORD DATA] Resolve RegisteryId:', registryId);

    const {
        data: resolveResponse,
        isLoading: resolving,
        error: resolveError,
    } = useReadApi({
        service: 'mdms',
        endpoint: `/doctypes/${registryId}/resolve`,
        method: 'GET',
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: shouldResolve,
    });

    const resolvedApiUrl = resolveResponse?.apiUrl;
    const supported = resolveResponse?.supported === true;

    // ---------------------------------------------------------------------
    // 2️⃣ FETCH RECORD
    // ---------------------------------------------------------------------

    const shouldFetchRecord = shouldResolve && supported && !!resolvedApiUrl;

    const {
        data: apiResponse,
        isLoading: loadingRecord,
        error: fetchError,
        refetch,
    } = useReadApi({
        service: 'gateway',
        endpoint: `${resolvedApiUrl}/${recordId}`, // SINGLE RECORD
        method: 'GET',
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: shouldFetchRecord,
    });

    // ---------------------------------------------------------------------
    // 3️⃣ NORMALIZE
    // ---------------------------------------------------------------------

    const data = useMemo(() => {
        if (!apiResponse) return null;
        if (apiResponse.data) return apiResponse.data;
        return apiResponse;
    }, [apiResponse]);

    // ---------------------------------------------------------------------
    // 4️⃣ SAVE (stub for now)
    // ---------------------------------------------------------------------

    const saveRecord = useCallback(async (payload) => {
        // PUT / PATCH later
        return payload;
    }, []);

    // ---------------------------------------------------------------------
    // RETURN
    // ---------------------------------------------------------------------

    return {
        data,
        isLoading: resolving || loadingRecord,
        error: resolveError || fetchError,
        refresh: refetch,
        saveRecord,
        resolvedApiUrl,
        supported,
    };
}
