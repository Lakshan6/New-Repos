import { useState, useCallback } from 'react';
import { apiRequest } from '@shared/utils';

/**
 * Imperative hook for deleting records.
 */
export function useDeleteRecord() {
    const [isDeleting, setIsDeleting] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState(null);

    const deleteRecord = useCallback(async ({ registryId, recordId }) => {
        // ---------------------------------------------------------------------
        // VALIDATION
        // ---------------------------------------------------------------------
        if (!registryId || !recordId) {
            const validationError = new Error('registryId and recordId are required');
            setError(validationError);
            throw validationError;
        }

        const authToken = localStorage.getItem('authToken') ?? '';

        setIsDeleting(true);
        setError(null);
        setData(null);

        try {
            // -----------------------------------------------------------------
            // STEP 1: Resolve API endpoint for the doctype
            // -----------------------------------------------------------------
            console.log('[useDeleteRecord] Resolving API for registryId:', registryId);

            const resolveResponse = await apiRequest({
                service: 'mdms',
                endpoint: `/doctypes/${registryId}/resolve`,
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${authToken}`,
                },
                useGateway: true,
            });

            const resolvedApiUrl = resolveResponse?.apiUrl;
            const supported = resolveResponse?.supported === true;

            console.log('[useDeleteRecord] Resolved API URL:', resolvedApiUrl);
            console.log('[useDeleteRecord] Delete supported:', supported);

            if (!supported) {
                throw new Error('Delete operation is not supported for this doctype');
            }

            if (!resolvedApiUrl) {
                throw new Error('Could not resolve API URL for this doctype');
            }

            // -----------------------------------------------------------------
            // STEP 2: Perform DELETE request
            // -----------------------------------------------------------------
            const deleteUrl = `${resolvedApiUrl}/${recordId}`;
            console.log('[useDeleteRecord] Deleting record at:', deleteUrl);

            const deleteResponse = await apiRequest({
                service: 'gateway',
                endpoint: deleteUrl,
                method: 'DELETE',
                headers: {
                    Authorization: `Bearer ${authToken}`,
                },
                useGateway: true,
            });

            setData(deleteResponse || { success: true });
            console.log('[useDeleteRecord] Delete successful:', deleteResponse);

            return deleteResponse || { success: true };
        } catch (err) {
            console.error('[useDeleteRecord] Delete error:', err);
            setError(err instanceof Error ? err : new Error(String(err)));
            throw err;
        } finally {
            setIsDeleting(false);
        }
    }, []);

    const reset = useCallback(() => {
        setIsDeleting(false);
        setError(null);
        setData(null);
    }, []);

    return {
        deleteRecord,
        isDeleting,
        error,
        data,
        reset,
    };
}
