import { useCallback, useEffect, useMemo, useState } from 'react';
import { useReadApi } from '@shared/hooks';

export function useGetRecords(options = {}) {
    const { registryId, enabled = true } = options;

    const authToken = localStorage.getItem('authToken') ?? '';

    // ---------------------------------------------------------------------
    // LOCAL STATE (optimistic updates)
    // ---------------------------------------------------------------------
    const [localData, setLocalData] = useState([]);
    const [hasLocalChanges, setHasLocalChanges] = useState(false);

    // ---------------------------------------------------------------------
    // 1️⃣ RESOLVE API ENDPOINT
    // ---------------------------------------------------------------------
    const shouldResolve = enabled && !!registryId;

    const {
        data: resolveResponse,
        isLoading: resolving,
        error: resolveError,
    } = useReadApi({
        service: 'mdms',
        endpoint: `/doctypes/${registryId}/resolve`,
        method: 'GET',
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: shouldResolve,
    });

    const resolvedApiUrl = resolveResponse?.apiUrl;
    const serviceModule = resolveResponse?.module || 'gateway';
    const supported = resolveResponse?.supported === true;

    // Debug log
    useEffect(() => {
        if (resolveResponse) {
            console.log('[LCNC] Resolve response:', resolveResponse);
            if (supported) {
                console.log('[LCNC] Resolved API URL:', resolvedApiUrl);
            }
        }
    }, [resolveResponse, supported, resolvedApiUrl]);

    // ---------------------------------------------------------------------
    // 2️⃣ FETCH RECORDS
    // ---------------------------------------------------------------------
    const shouldFetchRecords = enabled && supported && !!resolvedApiUrl;

    const {
        data: apiResponse,
        isLoading: loadingRecords,
        isError,
        error: fetchError,
        refetch,
    } = useReadApi({
        service: 'gateway',
        endpoint: resolvedApiUrl,
        method: 'GET',
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: shouldFetchRecords,
    });

    // ---------------------------------------------------------------------
    // 3️⃣ NORMALIZE RESPONSE
    // ---------------------------------------------------------------------
    const apiData = useMemo(() => {
        if (!apiResponse) return [];
        if (Array.isArray(apiResponse)) return apiResponse;
        return apiResponse.records ?? apiResponse.data ?? [];
    }, [apiResponse]);

    // ---------------------------------------------------------------------
    // 4️⃣ SYNC API → LOCAL
    // ---------------------------------------------------------------------
    useEffect(() => {
        if (!hasLocalChanges) {
            setLocalData(apiData);
        }
    }, [apiData, hasLocalChanges]);

    const data = hasLocalChanges ? localData : apiData;

    // ---------------------------------------------------------------------
    // 5️⃣ OPTIMISTIC HELPERS
    // ---------------------------------------------------------------------
    const addItem = useCallback((item) => {
        setLocalData((prev) => [...prev, item]);
        setHasLocalChanges(true);
    }, []);

    const updateItem = useCallback((id, updates) => {
        setLocalData((prev) =>
            prev.map((item) =>
                item.id === id || item.name === id ? { ...item, ...updates } : item,
            ),
        );
        setHasLocalChanges(true);
    }, []);

    const removeItem = useCallback((id) => {
        setLocalData((prev) => prev.filter((item) => item.id !== id && item.name !== id));
        setHasLocalChanges(true);
    }, []);

    const clearData = useCallback(() => {
        setLocalData([]);
        setHasLocalChanges(true);
    }, []);

    // ---------------------------------------------------------------------
    // 6️⃣ REFRESH
    // ---------------------------------------------------------------------
    const refresh = useCallback(async () => {
        setHasLocalChanges(false);
        return refetch();
    }, [refetch]);

    // ---------------------------------------------------------------------
    // RETURN
    // ---------------------------------------------------------------------
    return {
        data,
        loading: resolving || loadingRecords,
        error: resolveError || fetchError,
        isError: !!resolveError || isError,
        refresh,
        addItem,
        updateItem,
        removeItem,
        clearData,
        isEmpty: data.length === 0,
        count: data.length,
        // Meta info
        resolvedApiUrl,
        supported,
    };
}

export default useGetRecords;
