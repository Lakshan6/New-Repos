import { useCallback, useEffect, useMemo, useState } from 'react';
import { useReadApi } from '@shared/hooks';

export function useGetDoctypes(options = {}) {
    const { enabled = true } = options;

    const authToken = localStorage.getItem('authToken') ?? '';

    // ---------------------------------------------------------------------
    // LOCAL STATE (optimistic updates)
    // ---------------------------------------------------------------------
    const [localData, setLocalData] = useState([]);
    const [hasLocalChanges, setHasLocalChanges] = useState(false);

    // ---------------------------------------------------------------------
    // FETCH DOCTYPES
    // ---------------------------------------------------------------------
    const {
        data: apiResponse,
        isLoading: loading,
        isError,
        error,
        refetch,
    } = useReadApi({
        service: 'mdms',
        endpoint: '/doctypes',
        method: 'GET',
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled,
    });

    // ---------------------------------------------------------------------
    // NORMALIZE RESPONSE
    // ---------------------------------------------------------------------
    const apiData = useMemo(() => {
        if (!apiResponse) return [];
        if (Array.isArray(apiResponse)) return apiResponse;
        return apiResponse.doctypes ?? apiResponse.data ?? [];
    }, [apiResponse]);

    // ---------------------------------------------------------------------
    // SYNC API → LOCAL
    // ---------------------------------------------------------------------
    useEffect(() => {
        if (!hasLocalChanges) {
            setLocalData((prev) => (prev === apiData ? prev : apiData));
        }
    }, [apiData, hasLocalChanges]);

    const data = hasLocalChanges ? localData : apiData;

    // ---------------------------------------------------------------------
    // OPTIMISTIC HELPERS
    // ---------------------------------------------------------------------
    const addItem = useCallback((item) => {
        setLocalData((prev) => [...prev, item]);
        setHasLocalChanges(true);
    }, []);

    const updateItem = useCallback((id, updates) => {
        setLocalData((prev) =>
            prev.map((item) =>
                item.id === id || item.name === id ? { ...item, ...updates } : item,
            ),
        );
        setHasLocalChanges(true);
    }, []);

    const removeItem = useCallback((id) => {
        setLocalData((prev) => prev.filter((item) => item.id !== id && item.name !== id));
        setHasLocalChanges(true);
    }, []);

    const clearData = useCallback(() => {
        setLocalData([]);
        setHasLocalChanges(true);
    }, []);

    // ---------------------------------------------------------------------
    // REFRESH
    // ---------------------------------------------------------------------
    const refresh = useCallback(async () => {
        setHasLocalChanges(false);
        return refetch();
    }, [refetch]);

    // ---------------------------------------------------------------------
    // RETURN
    // ---------------------------------------------------------------------
    return {
        data,
        loading,
        error,
        isError,
        refresh,
        addItem,
        updateItem,
        removeItem,
        clearData,
        isEmpty: data.length === 0,
        count: data.length,
    };
}

export default useGetDoctypes;
