// hooks/useFetchDoctype.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';
import { useCallback } from 'react';

export const useFetchDoctype = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'mdms',
        endpoint: '/doctypes/fetch', // 🔁 change if your endpoint differs
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch a doctype by id
     * @param {string} doctypeId
     */

    const fetchDoctype = useCallback(
        async (doctypeId) => {
            if (!doctypeId) {
                throw new Error('doctypeId is required');
            }

            const requestInfo = getReqInfoObj();

            const requestBody = {
                ...requestInfo,
                //doctypeSearchDto: {
                id: doctypeId,
                //},
            };

            const response = await mutateAsync(requestBody);
            return response?.data ?? response;
        },
        [mutateAsync],
    );

    return {
        fetchDoctype,
        isPending,
        isError,
        error,
        data,
    };
};

export default useFetchDoctype;
