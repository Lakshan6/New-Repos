import { useState, useCallback } from 'react';
import { apiRequest } from '@shared/utils';

// Fields that should be excluded from the request body (system/read-only fields)
const SYSTEM_FIELDS = [];

/**
 * Sanitizes form data by removing system/read-only fields
 * @param {Object} formData - The raw form data
 * @param {boolean} isUpdate - Whether this is an update operation
 * @returns {Object} Cleaned form data
 */
const sanitizeFormData = (formData, isUpdate = false) => {
    if (!formData || typeof formData !== 'object') {
        return {};
    }

    const sanitized = {};

    Object.entries(formData).forEach(([key, value]) => {
        // Skip system fields
        if (SYSTEM_FIELDS.includes(key)) {
            return;
        }

        // For updates, optionally skip 'id' if you don't want it in the body
        // (depends on your API design - some APIs want id in body, some don't)
        // if (isUpdate && key === 'id') {
        //     return;
        // }

        // Skip undefined values, but keep null (explicit clearing)
        if (value === undefined) {
            return;
        }

        sanitized[key] = value;
    });

    return sanitized;
};

/**
 * Imperative hook for saving (creating/updating) records.
 */
export function useSaveRecord() {
    const [isSaving, setIsSaving] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState(null);

    const saveRecord = useCallback(async ({ registryId, recordId, formData, isNew = false }) => {
        // ---------------------------------------------------------------------
        // VALIDATION
        // ---------------------------------------------------------------------
        if (!registryId) {
            const validationError = new Error('registryId is required');
            setError(validationError);
            throw validationError;
        }

        if (!isNew && !recordId) {
            const validationError = new Error('recordId is required for updates');
            setError(validationError);
            throw validationError;
        }

        if (!formData || typeof formData !== 'object') {
            const validationError = new Error('formData is required');
            setError(validationError);
            throw validationError;
        }

        const authToken = localStorage.getItem('authToken') ?? '';

        setIsSaving(true);
        setError(null);
        setData(null);

        try {
            // -----------------------------------------------------------------
            // STEP 1: Resolve API endpoint for the doctype
            // -----------------------------------------------------------------
            console.log('[useSaveRecord] Resolving API for registryId:', registryId);

            const resolveResponse = await apiRequest({
                service: 'mdms',
                endpoint: `/doctypes/${registryId}/resolve`,
                method: 'GET',
                headers: {
                    Authorization: `Bearer ${authToken}`,
                },
                useGateway: true,
            });

            const resolvedApiUrl = resolveResponse?.apiUrl;
            const supported = resolveResponse?.supported === true;

            console.log('[useSaveRecord] Resolved API URL:', resolvedApiUrl);
            console.log('[useSaveRecord] Save supported:', supported);

            if (!supported) {
                throw new Error('Save operation is not supported for this doctype');
            }

            if (!resolvedApiUrl) {
                throw new Error('Could not resolve API URL for this doctype');
            }

            // -----------------------------------------------------------------
            // STEP 2: Prepare request based on create vs update
            // -----------------------------------------------------------------
            const isUpdate = !isNew && !!recordId;
            const method = isUpdate ? 'PATCH' : 'POST';
            const endpoint = isUpdate ? `${resolvedApiUrl}/${recordId}` : resolvedApiUrl;

            // Sanitize form data - remove system fields
            const requestBody = sanitizeFormData(formData, isUpdate);

            console.log('[useSaveRecord] Operation:', isUpdate ? 'UPDATE' : 'CREATE');
            console.log('[useSaveRecord] Endpoint:', endpoint);
            console.log('[useSaveRecord] Method:', method);
            console.log('[useSaveRecord] Request Body:', requestBody);

            // -----------------------------------------------------------------
            // STEP 3: Perform the API request
            // -----------------------------------------------------------------
            const saveResponse = await apiRequest({
                service: 'gateway',
                endpoint,
                method,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'Content-Type': 'application/json',
                },
                useGateway: true,
                body: requestBody,
            });

            setData(saveResponse || { success: true });
            console.log('[useSaveRecord] Save successful:', saveResponse);

            return saveResponse || { success: true };
        } catch (err) {
            console.error('[useSaveRecord] Save error:', err);
            const errorObj = err instanceof Error ? err : new Error(String(err));
            setError(errorObj);
            throw errorObj;
        } finally {
            setIsSaving(false);
        }
    }, []);

    const reset = useCallback(() => {
        setIsSaving(false);
        setError(null);
        setData(null);
    }, []);

    return {
        saveRecord,
        isSaving,
        error,
        data,
        reset,
    };
}
