// hooks/useDoctypeSchemaLoader.js

import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook responsible for loading UI schema for a doctype
 * Fetches config from gateway → /get-config
 */
export const useDoctypeSchemaLoader = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const {
        mutateAsync,
        isPending: loading,
        isError,
        error,
        data,
    } = useMutationApi({
        service: 'gateway',
        endpoint: '/get-config',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch UI schema for a doctype
     * @param {Object} params
     * @param {string} params.doctypeName
     * @param {string} params.module
     */
    const loadUISchema = useCallback(
        async ({ doctypeName, module }) => {
            console.log('[SCHEMA LOADER] invoked'); //REMOVE
            console.log('[SCHEMA LOADER] doctypeName:', doctypeName); //REMOVE
            console.log('[SCHEMA LOADER] module:', module); //REMOVE

            if (!doctypeName || !module) {
                throw new Error('Doctype name and module name are required');
            }

            const requestInfo = getReqInfoObj();
            console.log('[SCHEMA LOADER] Request sent by ', doctypeName); //REMOVE
            const requestBody = {
                ...requestInfo,
                doctypeName,
                module,
            };

            console.log('[SCHEMA LOADER] requestBody:', requestBody); //REMOVE

            const response = await mutateAsync(requestBody);

            console.log('[SCHEMA LOADER] raw response:', response); //REMOVE

            return response;
        },
        [mutateAsync],
    );

    return {
        loadUISchema, // imperative fetch
        data, // schema
        loading,
        isError,
        error,
    };
};

export default useDoctypeSchemaLoader;
