import { Route, Routes } from 'react-router';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';
import FormBuilder from '../components/FormBuilder';
import RecordListViewer from '../screens/RecordListViewer';
import FormRendererPlayground from '../screens/FormRendererPlayground';
import ListViewPlayground from '../screens/ListViewPlayground';
import DoctypeListViewer from '../screens/DoctypeListViewer';
import FormView from '../screens/FormView';
import ListViewConfigEditor from '../screens/ListViewConfigEditor';
const Router = () => {
    return (
        <Routes>
            <Route index element={<FormBuilder />} />
            <Route path="/form-builder" element={<FormBuilder />} />
            <Route path="/form-view" element={<FormView />} />
            <Route path="/form-renderer" element={<FormRendererPlayground />} />
            <Route path="/list-view-pg" element={<ListViewPlayground />} />
            <Route path="/record-list-view" element={<RecordListViewer />} />
            <Route path="/doctype-list-view" element={<DoctypeListViewer />} />
            <Route path="/listview-config-editor" element={<ListViewConfigEditor />} />
            <Route path="*" element={<NotFoundPage />} />
        </Routes>
    );
};

export default Router;
