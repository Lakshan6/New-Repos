// ActionConfirmationDialog.jsx
import React, { useState, useCallback } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { Divider } from 'primereact/divider';
import { AttachmentTable } from '@shared/components/AttachmentTable';

/**
 * Custom confirmation dialog for workflow actions with assignee and document support
 *
 * @param {boolean} visible - Whether the dialog is visible
 * @param {function} onHide - Callback when dialog is hidden
 * @param {function} onConfirm - Callback when user confirms (receives { action, assignee, supportingDocuments })
 * @param {object} action - Action details { actionCode, nextState, requiresAssignee, requiresDocuments }
 * @param {array} availableAssignees - List of assignees { label, value, email, role }
 * @param {object} candidate - Current candidate info
 * @param {number} uploadedDocCount - Count of already uploaded documents
 */
const ActionConfirmationDialog = ({
    visible,
    onHide,
    onConfirm,
    action = {},
    availableAssignees = [],
    candidate = {},
    uploadedDocCount = 0,
}) => {
    const {
        actionCode = '',
        nextState = '',
        nextStateName = '',
        requiresAssignee = false,
        requiresDocuments = false,
    } = action;

    // Default description prefix using the current action
    const actionName = actionCode || 'this action';
    const defaultDescription = `Supporting documents for ${actionName}`;

    // Human-readable next state (fallback to technical name or nothing)
    const displayNextState = nextStateName || nextState || 'the next stage';

    // State
    const [selectedAssignee, setSelectedAssignee] = useState(null);
    const [supportingDocs, setSupportingDocs] = useState([
        {
            srNo: 1,
            documentName: 'Supporting Documents',
            documentDescriptionType: 'input',
            enteredDesc: defaultDescription, // ← start with default
            files: [],
            multiple: true,
        },
    ]);
    const [isProcessing, setIsProcessing] = useState(false);
    const [validationErrors, setValidationErrors] = useState({});

    // Validation
    const validate = useCallback(() => {
        const errors = {};

        if (requiresAssignee && !selectedAssignee) {
            errors.assignee = 'Assignee is required for this action';
        }

        // Check if supporting documents are being uploaded
        const uploadingDocs = supportingDocs[0]?.files.some((f) => f.uploadStatus === 'pending');
        if (uploadingDocs) {
            errors.documents = 'Please wait for documents to finish uploading';
        }

        // Check for failed uploads
        const failedDocs = supportingDocs[0]?.files.some((f) => f.uploadStatus === 'failed');
        if (failedDocs) {
            errors.documents = 'Some documents failed to upload. Please remove and re-upload them.';
        }

        setValidationErrors(errors);
        return Object.keys(errors).length === 0;
    }, [requiresAssignee, selectedAssignee, supportingDocs]);

    // Handle confirm
    const handleConfirm = useCallback(async () => {
        if (!validate()) {
            return;
        }

        setIsProcessing(true);

        try {
            const currentDesc = supportingDocs[0]?.enteredDesc?.trim() || '';

            // Build final description:
            // - If user typed something → append " <ACTION>"
            // - If empty → use default "Supporting documents for <ACTION>"
            const finalDescription = currentDesc
                ? `${currentDesc} (${actionName})`
                : defaultDescription;

            // Get supporting document fileStoreIds - outdated
            const supportingDocIds =
                supportingDocs[0]?.files
                    .filter((f) => f.fileStoreId && f.uploadStatus === 'success')
                    .map((f) => f.fileStoreId) || [];

            // Get supporting documents and create a rich object that contains all the info about the supporting document
            const supportingDocuments =
                supportingDocs[0]?.files
                    .filter((f) => f.fileStoreId && f.uploadStatus === 'success')
                    .map((f) => ({
                        fileStoreId: f.fileStoreId,
                        fileName: f.name || `supporting-document-${Date.now()}`,
                        mimeType: f.type || null,
                        fileSize: f.size ?? null,
                        // You can decide: use enteredDesc for ALL or allow per-file descriptions later
                        documentDescription:
                            supportingDocs[0].enteredDesc?.trim() || defaultDescription,
                    })) || [];

            await onConfirm({
                action, // Pass the full action object
                assignee: selectedAssignee,
                supportingDocuments: supportingDocuments,
            });

            // Reset form
            setSelectedAssignee(null);
            setSupportingDocs([
                {
                    srNo: 1,
                    documentName: 'Supporting Documents',
                    documentDescriptionType: 'input',
                    files: [],
                    multiple: true,
                },
            ]);
            setValidationErrors({});
        } catch (err) {
            console.error('Action confirmation error:', err);
        } finally {
            setIsProcessing(false);
        }
    }, [validate, onConfirm, selectedAssignee, supportingDocs]);

    // Handle cancel
    const handleCancel = useCallback(() => {
        setSelectedAssignee(null);
        setSupportingDocs([
            {
                srNo: 1,
                documentName: 'Supporting Documents',
                documentDescriptionType: 'input',
                enteredDesc: defaultDescription, // ← restore default
                files: [],
                multiple: true,
            },
        ]);
        setValidationErrors({});
        onHide();
    }, [onHide]);

    // Get supporting doc count
    const supportingDocCount = supportingDocs[0]?.files.length || 0;

    // Footer
    const footer = (
        <div className="flex justify-content-end gap-2">
            <Button
                label="Cancel"
                icon="pi pi-times"
                onClick={handleCancel}
                className="p-button-text"
                disabled={isProcessing}
            />
            <Button
                label={isProcessing ? 'Processing...' : 'Confirm'}
                icon={isProcessing ? 'pi pi-spin pi-spinner' : 'pi pi-check'}
                onClick={handleConfirm}
                className={actionCode === 'REJECT' ? 'p-button-danger' : 'p-button-success'}
                disabled={isProcessing}
                autoFocus
            />
        </div>
    );

    return (
        <Dialog
            visible={visible}
            onHide={handleCancel}
            header={
                <div className="flex align-items-center gap-2">
                    <i className="pi pi-exclamation-triangle text-orange-500" />
                    <span>Confirm {actionCode}</span>
                </div>
            }
            footer={footer}
            style={{ width: '700px' }}
            modal
            draggable={false}
            closable={!isProcessing}
        >
            <div className="flex flex-column gap-4">
                {/* Main confirmation message */}
                <div className="p-3 bg-blue-50 border-round">
                    <p className="m-0 line-height-3">
                        Are you sure you want to take action{' '}
                        <strong>{actionCode.toLowerCase()}</strong> on{' '}
                        <strong>{candidate.fullName || 'this candidate'}</strong>?
                    </p>
                    {nextState && (
                        <p className="m-0 mt-2 text-sm text-600">
                            This will move the state to <strong>{displayNextState}</strong>.
                        </p>
                    )}
                </div>

                {/* Document summary */}
                {uploadedDocCount > 0 && (
                    <div className="p-3 surface-100 border-round">
                        <div className="flex align-items-center gap-2">
                            <i className="pi pi-paperclip text-600" />
                            <span className="text-600">
                                <strong>{uploadedDocCount}</strong> document
                                {uploadedDocCount > 1 ? 's' : ''} will be submitted
                            </span>
                        </div>
                    </div>
                )}

                <Divider className="my-2" />

                {/* Assignee Selection */}
                <div className="field">
                    <label htmlFor="assignee" className="block font-semibold mb-2">
                        Assignee {requiresAssignee && <span className="text-red-500">*</span>}
                    </label>
                    <Dropdown
                        id="assignee"
                        value={selectedAssignee}
                        onChange={(e) => {
                            setSelectedAssignee(e.value);
                            setValidationErrors((prev) => ({ ...prev, assignee: null }));
                        }}
                        options={availableAssignees}
                        optionLabel="label"
                        optionValue="value"
                        placeholder={
                            requiresAssignee
                                ? 'Select an assignee (required)'
                                : 'Select an assignee (optional)'
                        }
                        className={`w-full ${validationErrors.assignee ? 'p-invalid' : ''}`}
                        filter
                        showClear={!requiresAssignee}
                        disabled={isProcessing}
                        emptyMessage="No assignees available"
                        itemTemplate={(option) => (
                            <div className="flex flex-column">
                                <span className="font-semibold">{option.label}</span>
                                {option.email && (
                                    <span className="text-sm text-600">{option.email}</span>
                                )}
                                {option.role && (
                                    <span className="text-xs text-500">{option.role}</span>
                                )}
                            </div>
                        )}
                    />
                    {validationErrors.assignee && (
                        <small className="p-error block mt-1">{validationErrors.assignee}</small>
                    )}
                    {!requiresAssignee && (
                        <small className="text-500 block mt-1">
                            Optional: Assign this task to a specific person
                        </small>
                    )}
                </div>

                {/* Supporting Documents */}
                <div className="field">
                    <label className="block font-semibold mb-2">
                        Supporting Documents
                        <span className="text-500 font-normal ml-2">
                            ({supportingDocCount} file{supportingDocCount !== 1 ? 's' : ''})
                        </span>
                    </label>
                    <div className="border-1 surface-border border-round p-3">
                        <AttachmentTable
                            attachments={supportingDocs}
                            setAttachments={setSupportingDocs}
                            readOnly={false}
                        />
                    </div>
                    {validationErrors.documents && (
                        <small className="p-error block mt-1">{validationErrors.documents}</small>
                    )}
                    <small className="text-500 block mt-1">
                        Optional: Upload additional documents to support this action
                    </small>
                </div>
            </div>
        </Dialog>
    );
};

export default ActionConfirmationDialog;
