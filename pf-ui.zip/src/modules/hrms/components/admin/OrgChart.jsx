import React, { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { OrganizationChart } from 'primereact/organizationchart';
import { TransformWrapper, TransformComponent } from 'react-zoom-pan-pinch';
import { useReadApi, useMutationApi, useSafeContext, useT } from '@shared/hooks';
import { AuthContext, getReqInfoObj } from '@shared/utils';
import { Button } from 'primereact/button';
import { useAppToast } from '@shared/components/Toast';
import { SelectButton } from 'primereact/selectbutton';
import { TreeTable } from 'primereact/treetable';
import { Column } from 'primereact/column';
import { AutoComplete } from 'primereact/autocomplete';
import { debounce } from 'lodash';
import PropTypes from 'prop-types';

const TABLE_STYLE = { minWidth: '40rem' };
const WRAPPER_STYLE = { width: '100%', height: '100%' };
const WHEEL = { step: 0.05 };
const TOOLTIP_OPTIONS = { position: 'left' };

const ZoomControls = ({ zoomIn, zoomOut, centerView }) => {
    const handleZoomIn = zoomIn;
    const handleZoomOut = zoomOut;

    const handleCenterView = useCallback(() => {
        setTimeout(centerView, 50, 1, 100);
    }, [centerView]);

    return (
        <div className="absolute z-5 right-0 flex flex-column gap-2 mr-2 mt-1">
            <Button
                onClick={handleZoomIn}
                icon="pi pi-plus"
                outlined
                severity="secondary"
                tooltip="Zoom In"
                tooltipOptions={TOOLTIP_OPTIONS}
            />
            <Button
                onClick={handleZoomOut}
                icon="pi pi-minus"
                outlined
                severity="secondary"
                tooltip="Zoom Out"
                tooltipOptions={TOOLTIP_OPTIONS}
            />
            <Button
                onClick={handleCenterView}
                icon="pi pi-bullseye"
                outlined
                severity="secondary"
                tooltip="Re-center"
                tooltipOptions={TOOLTIP_OPTIONS}
            />
        </div>
    );
};

const OrgChart = ({ rootTenantId = '' }) => {
    const options = [
        { name: 'Org Chart', value: 1 },
        { name: 'Tree Table', value: 2 },
    ];
    const [value, setValue] = useState(options[0].value);
    const [selection, setSelection] = useState([]);
    const [tenantId, setTenantId] = useState(null);
    const [hierarchy, setHierarchy] = useState(null);
    const [nodes, setNodes] = useState([]);
    const [expandedKeys, setExpandedKeys] = useState({});
    const { authToken } = useSafeContext(AuthContext);
    const reqInfoObj = useMemo(() => getReqInfoObj(), []);
    const [inputValue, setInputValue] = useState('');
    const [searchSuggestions, setSearchSuggestions] = useState([]);
    const [searchQuery, setSearchQuery] = useState('');
    const skipNextSearch = useRef(false);
    const [selectedTenantFromDropDown, setSelectedTenantFromDropDown] = useState(null);
    const [highlightedNodeId, setHighlightedNodeId] = useState(null);
    const { t } = useT();
    const toast = useAppToast();

    const { data: rootTenant } = useReadApi({
        service: 'mdms',
        endpoint: `/tenant/_search?id=${encodeURIComponent(rootTenantId)}`,
        method: 'POST',
        body: reqInfoObj,
    });

    const { mutate: fetchChildTenants } = useMutationApi({
        service: 'mdms',
        endpoint: `/tenant/_getChildTenants?parentTenantId=${tenantId}`,
        method: 'POST',
        headers: { Authorization: `Bearer ${authToken}` },
        options: {
            onSuccess: (res) => {
                if (Array.isArray(res) && !res.length) {
                    toast.info('Sorry!', 'No child tenants available for this tenant.');
                }

                setHierarchy((prev) => {
                    if (!prev) return prev;
                    const updateChildren = (nodes, parentId) =>
                        nodes.map((node) => {
                            if (node.id === parentId) {
                                setExpandedKeys((prevKeys) => ({
                                    ...prevKeys,
                                    [parentId]: true,
                                }));
                                return {
                                    ...node,
                                    children: res.map((tenant) => ({
                                        id: tenant.id,
                                        label: tenant.name,
                                        expanded: true,
                                        children: [],
                                        style: { borderRadius: '6px' },
                                    })),
                                };
                            }
                            if (node.children?.length)
                                return {
                                    ...node,
                                    children: updateChildren(node.children, parentId),
                                };
                            return node;
                        });
                    return updateChildren(prev, tenantId);
                });

                setNodes((prev) => {
                    if (!prev) return prev;
                    const updateNodes = (nodes, parentId) =>
                        nodes.map((node) => {
                            if (node.key === parentId) {
                                const children = res.map((tenant) => ({
                                    key: tenant.id,
                                    data: {
                                        id: tenant.id,
                                        name: tenant.name,
                                        code: tenant.code || '',
                                        description: tenant.description || '',
                                    },
                                    leaf: false,
                                    children: [],
                                }));
                                return { ...node, children, leaf: children.length === 0 };
                            }
                            if (node.children?.length)
                                return { ...node, children: updateNodes(node.children, parentId) };
                            return node;
                        });
                    return updateNodes(prev, tenantId);
                });
            },
            onError: (err) => console.error(err),
        },
    });

    const { mutate: fetchSearchResults } = useMutationApi({
        service: 'mdms',
        endpoint: `/tenant/_getSearchSuggestion?searchQuery=${encodeURIComponent(searchQuery)}`,
        method: 'GET',
        headers: { Authorization: `Bearer ${authToken}` },
        options: {
            onSuccess: (data) => {
                const tenants = Array.isArray(data) ? data : [];
                setSearchSuggestions(
                    tenants.map((t) => ({
                        label: `${t.name} - ${t.code}`,
                        name: t.name,
                        code: t.code,
                        id: t.id,
                        value: String(t.code ?? ''),
                    })),
                );
            },
            onError: () => setSearchSuggestions([]),
        },
    });

    const { mutate: fetchHierarchy } = useMutationApi({
        service: 'mdms',
        endpoint: `/tenant/_getHierarchy?tenantId=${encodeURIComponent(selectedTenantFromDropDown)}&rootTenantId=${encodeURIComponent(rootTenantId)}`,
        method: 'GET',
        headers: { Authorization: `Bearer ${authToken}` },
        options: {
            onSuccess: (res) => {
                if (!Array.isArray(res) || res.length === 0) {
                    toast.info('Sorry!', 'No hierarchy found for the selected tenant.');
                    return;
                }

                const rootNode = res.find((d) => !d.parentTenantId);

                // ---------- ORG CHART ----------

                const buildOrgTree = (data, excludeChildrenForId) => {
                    const map = {};
                    data.forEach((item) => {
                        map[item.id] = {
                            id: item.id,
                            label: `${item.name}`,
                            expanded: true,
                            style: { borderRadius: '6px' },
                            children: [],
                        };
                    });
                    data.forEach((item) => {
                        if (item.id === excludeChildrenForId) return;
                        if (item.children?.length) {
                            item.children.forEach((child) => {
                                if (map[child.id]) {
                                    map[item.id].children.push(map[child.id]);
                                } else {
                                    map[item.id].children.push({
                                        id: child.id,
                                        label: `${child.name}`,
                                        expanded: true,
                                        style: { borderRadius: '6px' },
                                        children: [],
                                    });
                                }
                            });
                        }
                    });
                    const root = data.find((x) => !x.parentTenantId);
                    return root ? [map[root.id]] : [];
                };

                const orgData = rootNode ? buildOrgTree(res, selectedTenantFromDropDown) : [];
                setHierarchy(orgData);

                // ---------- TREE TABLE ----------
                const buildTreeTable = (data, excludeChildrenForId) => {
                    const map = {};
                    const roots = [];
                    const expanded = {};

                    // Step 1: Create a node map
                    data.forEach((item) => {
                        map[item.id] = map[item.id] || {
                            key: item.id,
                            data: {
                                id: item.id,
                                name: item.name,
                                code: item.code,
                                description: item.description,
                            },
                            children: [],
                            leaf: false,
                        };
                    });

                    // Step 2: Merge inline children (ensure all are represented in map)
                    data.forEach((item) => {
                        if (item.id === excludeChildrenForId) return;
                        const parentNode = map[item.id];
                        if (Array.isArray(item.children) && item.children.length > 0) {
                            item.children.forEach((child) => {
                                // Ensure child node exists in map
                                if (!map[child.id]) {
                                    map[child.id] = {
                                        key: child.id,
                                        data: {
                                            id: child.id,
                                            name: child.name,
                                            code: child.code,
                                            description: child.description,
                                        },
                                        children: [],
                                        leaf: false,
                                    };
                                }
                                // Attach to parent's children if not already present
                                if (!parentNode.children.some((n) => n.key === child.id)) {
                                    parentNode.children.push(map[child.id]);
                                }
                                expanded[item.id] = true; // parent has children → expand
                            });
                        }
                    });

                    // Step 3: Link parents via parentTenantId
                    data.forEach((item) => {
                        if (item.parentTenantId && map[item.parentTenantId]) {
                            const parent = map[item.parentTenantId];
                            if (!parent.children.some((n) => n.key === item.id)) {
                                parent.children.push(map[item.id]);
                            }
                            expanded[item.parentTenantId] = true;
                        } else if (!item.parentTenantId) {
                            roots.push(map[item.id]);
                        }
                    });

                    return { roots, expanded };
                };

                const { roots, expanded } = buildTreeTable(res, selectedTenantFromDropDown);
                setNodes(roots);
                setExpandedKeys(expanded);
            },

            onError: () => setSearchSuggestions([]),
        },
    });

    useEffect(() => {
        if (rootTenant && Array.isArray(rootTenant) && rootTenant[0]?.id) {
            const rt = rootTenant[0];
            setHierarchy([
                {
                    id: rt.id,
                    label: rt.name,
                    expanded: true,
                    children: [],
                    style: { borderRadius: '6px' },
                },
            ]);
            setNodes([
                {
                    key: rt.id,
                    data: {
                        id: rt.id,
                        name: rt.name,
                        code: rt.code || '',
                        description: rt.description || '',
                    },
                    children: [],
                    leaf: false,
                },
            ]);
        } else {
            setHierarchy(null);
            setNodes([]);
        }
    }, [rootTenant]);

    useEffect(() => {
        if (tenantId) fetchChildTenants(reqInfoObj);
    }, [fetchChildTenants, reqInfoObj, tenantId]);

    const debouncedSearch = useRef(
        debounce((query) => {
            if (query.trim().length > 0) fetchSearchResults();
        }, 400),
    ).current;

    useEffect(() => {
        if (skipNextSearch.current) {
            skipNextSearch.current = false;
            return;
        }
        searchQuery.trim() ? debouncedSearch(searchQuery) : setSearchSuggestions([]);
    }, [searchQuery, debouncedSearch]);

    useEffect(() => {
        if (selection.length && selection[selection.length - 1]?.id) {
            setTenantId(selection[selection.length - 1].id);
        }
    }, [selection]);

    useEffect(() => {
        if (selectedTenantFromDropDown && rootTenantId) {
            fetchHierarchy();
        }
    }, [fetchHierarchy, rootTenantId, selectedTenantFromDropDown]);

    const onAutoCompleteChange = useCallback((e) => {
        const v = String(e.value ?? '');
        setInputValue(v);
        if (!v.trim()) {
            setSearchQuery('');
            setSearchSuggestions([]);
        }
    }, []);

    const onAutoCompleteComplete = useCallback((e) => {
        const q = String(e.query ?? '');
        setInputValue(q);
        setSearchQuery(q);
    }, []);

    const onAutoCompleteSelect = useCallback((e) => {
        const { name, code, value, id } = e.value || {};
        const label = `${name} - ${code}`;
        setInputValue(label);
        setSearchQuery(value);
        skipNextSearch.current = true;
        if (id) {
            setSelectedTenantFromDropDown(id);
            setHighlightedNodeId(id);
            setTimeout(() => setHighlightedNodeId(null), 2000); // remove after 2 seconds
        }
    }, []);

    const SearchComponent = useMemo(
        () => (
            <AutoComplete
                dropdown
                value={inputValue}
                suggestions={searchSuggestions}
                field="label"
                onChange={onAutoCompleteChange}
                completeMethod={onAutoCompleteComplete}
                onSelect={onAutoCompleteSelect}
                placeholder={t('SEARCH_TENANT', { fallbackText: 'Search tenant...' })}
                className="w-20rem"
            />
        ),
        [
            inputValue,
            searchSuggestions,
            onAutoCompleteChange,
            onAutoCompleteComplete,
            onAutoCompleteSelect,
            t,
        ],
    );

    const onExpand = useCallback((e) => {
        const node = e.node;
        if (node && (!node.children || node.children.length === 0)) {
            setTenantId(node.key);
        }
    }, []);

    const onSelect = useCallback((e) => {
        setValue(e.value);
    }, []);

    const onSelectionChange = useCallback((e) => {
        setSelection(e.data);
    }, []);

    const onToggle = useCallback((e) => {
        setExpandedKeys(e.value);
    }, []);

    const nodeTemplate = useCallback(
        (node) => {
            const isHighlighted = node.id === highlightedNodeId;
            return (
                <div className="flex flex-column align-items-center justify-content-center">
                    <span
                        className={`font-semibold transition-colors transition-duration-300 ${
                            isHighlighted ? 'text-primary-500' : 'text-700'
                        }`}
                    >
                        {node.label}
                    </span>
                </div>
            );
        },
        [highlightedNodeId],
    );

    const nameBodyTemplate = useCallback((node) => node.data.name, []);
    const codeBodyTemplate = useCallback((node) => node.data.code, []);
    const descBodyTemplate = useCallback((node) => node.data.description, []);
    const rowClassName = useCallback(
        (node) => (node.key === highlightedNodeId ? 'p-highlight' : ''),
        [highlightedNodeId],
    );

    return (
        <div className="relative w-full h-full border rounded-lg overflow-hidden">
            <div className="flex align-items-center justify-content-between mb-2">
                <h3 className="mb-0 font-semibold">
                    {t('ORGANISATION_HIERARCHY', { fallbackText: 'Organisation hierarchy' })}
                </h3>

                <div className="flex align-items-center gap-3 mr-2 mt-1">
                    <div>{SearchComponent}</div>
                    <SelectButton
                        value={value}
                        onChange={onSelect}
                        options={options}
                        optionLabel="name"
                    />
                </div>
            </div>

            {value === 1 ? (
                <TransformWrapper
                    minScale={0.5}
                    maxScale={2}
                    initialScale={1}
                    wheel={WHEEL}
                    limitToBounds={false}
                    centerOnInit
                >
                    {(controls) => (
                        <>
                            <ZoomControls {...controls} />
                            <TransformComponent wrapperStyle={WRAPPER_STYLE}>
                                <div className="flex justify-center items-center p-8 min-h-[600px]">
                                    {Array.isArray(hierarchy) && hierarchy.length > 0 ? (
                                        <OrganizationChart
                                            value={hierarchy}
                                            nodeTemplate={nodeTemplate}
                                            selection={selection}
                                            selectionMode="multiple"
                                            onSelectionChange={onSelectionChange}
                                            className="orgchart-custom"
                                        />
                                    ) : (
                                        <div className="p-4 text-center text-muted">
                                            No hierarchy data available.
                                        </div>
                                    )}
                                </div>
                            </TransformComponent>
                        </>
                    )}
                </TransformWrapper>
            ) : (
                <TreeTable
                    value={nodes}
                    scrollHeight="73vh"
                    scrollable
                    showGridlines
                    tableStyle={TABLE_STYLE}
                    rows={5}
                    expandedKeys={expandedKeys}
                    onToggle={onToggle}
                    onExpand={onExpand}
                    rowClassName={rowClassName}
                >
                    <Column field="name" header="Name" body={nameBodyTemplate} sortable expander />
                    <Column field="code" header="Code" body={codeBodyTemplate} sortable />
                    <Column
                        field="description"
                        header="Description"
                        body={descBodyTemplate}
                        sortable
                    />
                </TreeTable>
            )}
        </div>
    );
};

OrgChart.propTypes = {
    rootTenantId: PropTypes.string,
};

ZoomControls.propTypes = {
    zoomIn: PropTypes.func.isRequired,
    zoomOut: PropTypes.func.isRequired,
    centerView: PropTypes.func.isRequired,
};

export { OrgChart };
