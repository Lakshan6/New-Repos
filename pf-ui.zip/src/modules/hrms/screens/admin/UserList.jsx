import React, { useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate } from 'react-router';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { TabView, TabPanel } from 'primereact/tabview';
import { Tag } from 'primereact/tag';
import { useGetMyReportingOrPeerUser } from '../../hooks/admin/useGetMyReportingOrPeerUser';
import { useGetMyReportingAndPeerUsers } from '../../hooks/admin/useGetMyReportingAndPeerUsers';
import { getReqInfoObj } from '@shared/utils/common';
import { useT } from '@shared/hooks/useT';
import SearchCard from '@shared/components/SearchCard';
import '../../styles/admin/UserList.css';
import PropTypes from 'prop-types';

const TOOLTIP_OPTIONS = { position: 'top' };

const UserList = () => {
    const navigate = useNavigate();
    const { fetchUserById } = useGetMyReportingOrPeerUser();
    const { mutate, data, isPending, isError, error } = useGetMyReportingAndPeerUsers();

    const [activeTab, setActiveTab] = useState('same-tenant');
    const [isAdmin, setIsAdmin] = useState(false);

    const [cache, setCache] = useState({});
    const [lastRequestTab, setLastRequestTab] = useState(null);

    const [paginationState, setPaginationState] = useState({
        'same-tenant': { page: 0, rows: 10, totalRecords: 0 },
        'subordinate-tenant': { page: 0, rows: 10, totalRecords: 0 },
    });

    /*Translation purpose*/
    const { t } = useT();

    const [nameFilter, setNameFilter] = useState('');
    const [usernameFilter, setUsernameFilter] = useState('');
    const [roleFilter, setRoleFilter] = useState('');
    const [tenantFilter, setTenantFilter] = useState('');

    const [appliedFilters, setAppliedFilters] = useState({
        name: '',
        username: '',
        role: '',
        tenant: '',
    });

    const handleUserClick = useCallback(
        async (uuid) => {
            try {
                const userDetails = await fetchUserById(uuid);
                navigate(`${uuid}`, { state: { userDetails } });
            } catch (err) {
                console.error('Error fetching user details:', err);
                alert('Could not load user details');
            }
        },
        [fetchUserById, navigate],
    );

    useEffect(() => {
        const selectedRoleIds = JSON.parse(localStorage.getItem('selectedRoleIds') || '[]');
        const adminRole = selectedRoleIds.some((roleString) => {
            if (typeof roleString === 'string') {
                const roles = roleString.split(',').map((r) => r.trim());
                return roles.some((role) => role.toUpperCase().endsWith('.ADMIN'));
            }
            return false;
        });
        setIsAdmin(adminRole);
    }, []);

    const fetchData = useCallback(
        (page, rows, tab, filters = appliedFilters) => {
            const requestInfo = getReqInfoObj();

            setLastRequestTab(tab);

            const requestBody = {
                ...requestInfo,
                sameTenant: tab === 'same-tenant',
                pagination: {
                    page: page + 1,
                    limit: rows,
                    offset: page * rows,
                },
                filters: {
                    name: filters.name || undefined,
                    username: filters.username || undefined,
                    role: filters.role || undefined,
                    tenant: filters.tenant || undefined,
                },
                sortBy: 'username',
                sortOrder: 'ASC',
            };

            mutate(requestBody);
        },
        [appliedFilters, mutate],
    );

    useEffect(() => {
        const currentPagination = paginationState[activeTab];
        const cacheKey = `${activeTab}-page${currentPagination.page}-rows${currentPagination.rows}`;

        if (!cache[cacheKey]) {
            fetchData(currentPagination.page, currentPagination.rows, activeTab);
        }
    }, [activeTab, cache, fetchData, paginationState]);

    useEffect(() => {
        if (data && lastRequestTab) {
            const { users, totalRecords, currentPage, pageSize } = data;

            const cacheKey = `${lastRequestTab}-page${currentPage - 1}-rows${pageSize}`;
            setCache((prev) => ({
                ...prev,
                [cacheKey]: users || [],
            }));

            setPaginationState((prev) => ({
                ...prev,
                [lastRequestTab]: {
                    ...prev[lastRequestTab],
                    totalRecords: totalRecords || 0,
                },
            }));
        }
    }, [data, lastRequestTab]);

    const onPageChange = useCallback(
        (event) => {
            const { page, rows } = event;

            setPaginationState((prev) => ({
                ...prev,
                [activeTab]: { ...prev[activeTab], page, rows },
            }));

            const cacheKey = `${activeTab}-page${page}-rows${rows}`;

            if (!cache[cacheKey]) {
                fetchData(page, rows, activeTab);
            }
        },
        [activeTab, cache, fetchData],
    );

    const handleClearSearch = useCallback(() => {
        setNameFilter('');
        setUsernameFilter('');
        setRoleFilter('');
        setTenantFilter('');
        setAppliedFilters({
            name: '',
            username: '',
            role: '',
            tenant: '',
        });
        const newCache = { ...cache };
        Object.keys(newCache).forEach((key) => {
            if (key.startsWith(activeTab)) delete newCache[key];
        });
        setCache(newCache);
        fetchData(0, paginationState[activeTab].rows, activeTab, {});
    }, [activeTab, cache, fetchData, paginationState]);

    const handleSubmitFilters = useCallback(
        (filters) => {
            const newFilters = {
                name: filters?.name || nameFilter,
                username: filters?.username || usernameFilter,
                role: filters?.role || roleFilter,
                tenant: filters?.tenant || tenantFilter,
            };
            setAppliedFilters(newFilters);

            const newCache = { ...cache };
            Object.keys(newCache).forEach((key) => {
                if (key.startsWith(activeTab)) delete newCache[key];
            });
            setCache(newCache);

            fetchData(0, paginationState[activeTab].rows, activeTab, newFilters);
        },
        [
            activeTab,
            cache,
            fetchData,
            nameFilter,
            paginationState,
            roleFilter,
            tenantFilter,
            usernameFilter,
        ],
    );

    const currentDisplayData = useMemo(() => {
        const currentPagination = paginationState[activeTab];
        const cacheKey = `${activeTab}-page${currentPagination.page}-rows${currentPagination.rows}`;
        return cache[cacheKey] || [];
    }, [activeTab, paginationState, cache]);

    const getFiltersForActiveTab = () => {
        const baseFilters = [
            {
                type: 'InputText',
                label: t('Name'),
                name: 'name',
                placeholder: t('Search by name...'),
            },
            {
                type: 'InputText',
                label: 'Username',
                name: 'username',
                placeholder: 'Search by username...',
            },
            {
                type: 'InputText',
                label: t('Role'),
                name: 'role',
                placeholder: t('Search by role...'),
            },
        ];

        if (isAdmin && activeTab === 'subordinate-tenant') {
            baseFilters.push({
                type: 'InputText',
                label: t('Tenant'),
                name: 'tenant',
                placeholder: t('Search by tenant...'),
            });
        }

        return baseFilters;
    };

    const getViewUserHandler = useCallback(
        (uuid) => {
            return () => {
                handleUserClick(uuid);
            };
        },
        [handleUserClick],
    );

    const actionBodyTemplate = useCallback(
        (rowData) => {
            const onViewClick = getViewUserHandler(rowData.uuid);

            return (
                <Button
                    icon="pi pi-eye"
                    rounded
                    outlined
                    tooltip="View User Details"
                    tooltipOptions={TOOLTIP_OPTIONS}
                    onClick={onViewClick}
                />
            );
        },
        [getViewUserHandler],
    );

    const handleTabChange = useCallback((e) => {
        setActiveTab(e.index === 0 ? 'same-tenant' : 'subordinate-tenant');
    }, []);

    const handleSearchSubmit = useCallback(
        (values) => {
            setNameFilter(values.name || '');
            setUsernameFilter(values.username || '');
            setRoleFilter(values.role || '');
            setTenantFilter(values.tenant || '');
            handleSubmitFilters(values);
        },
        [handleSubmitFilters],
    );

    return (
        <div className="p-1">
            <SearchCard
                filters={getFiltersForActiveTab()}
                onSubmit={handleSearchSubmit}
                onClear={handleClearSearch}
            />

            <div>
                {isAdmin ? (
                    <TabView
                        activeIndex={activeTab === 'same-tenant' ? 0 : 1}
                        onTabChange={handleTabChange}
                    >
                        <TabPanel header={t('SAME TENANT')}>
                            <TenantUserTable
                                displayData={currentDisplayData}
                                isPending={isPending}
                                isError={isError}
                                error={error}
                                actionBodyTemplate={actionBodyTemplate}
                                appliedFilters={appliedFilters}
                                paginationState={paginationState[activeTab]}
                                onPageChange={onPageChange}
                            />
                        </TabPanel>

                        <TabPanel header={t('SUB-TENANT (DIRECT LEVEL UNDER)')}>
                            <TenantUserTable
                                displayData={currentDisplayData}
                                isPending={isPending}
                                isError={isError}
                                error={error}
                                actionBodyTemplate={actionBodyTemplate}
                                appliedFilters={appliedFilters}
                                paginationState={paginationState[activeTab]}
                                onPageChange={onPageChange}
                            />
                        </TabPanel>
                    </TabView>
                ) : (
                    <TenantUserTable
                        displayData={currentDisplayData}
                        isPending={isPending}
                        isError={isError}
                        error={error}
                        actionBodyTemplate={actionBodyTemplate}
                        appliedFilters={appliedFilters}
                        paginationState={paginationState[activeTab]}
                        onPageChange={onPageChange}
                    />
                )}
            </div>
        </div>
    );
};

const fullNameBodyTemplate = (rowData) => {
    const parts = [rowData.firstName, rowData.middleName, rowData.lastName].filter(Boolean);
    return parts.join(' ') || '-';
};

const roleBodyTemplate = (rowData) => {
    const rolesString = rowData.role_ids || '';

    const roles = rolesString
        .split(',')
        .map((role) => role.trim())
        .filter(Boolean);

    if (roles.length === 0) return '-';

    return (
        <div className="flex flex-column gap-2 align-items-start py-1">
            {roles.map((role, index) => (
                <Tag key={index} value={role} className="role-tag-outlined" />
            ))}
        </div>
    );
};

const tenantBodyTemplate = (rowData) => {
    const tenantString = rowData.tenant_ids || '';

    const tenants = tenantString
        .split(',')
        .map((t) => t.trim())
        .filter(Boolean);

    if (tenants.length === 0) return '-';

    return (
        <div className="flex flex-column gap-2 align-items-start py-1">
            {tenants.map((tenant, index) => (
                <Tag key={index} value={tenant} className="tenant-tag-outlined" />
            ))}
        </div>
    );
};

const TenantUserTable = ({
    displayData,
    isPending,
    isError,
    error,
    actionBodyTemplate,
    appliedFilters,
    paginationState,
    onPageChange,
}) => {
    if (isPending) {
        return <p className="p-3 text-color-secondary">Loading users...</p>;
    }

    if (isError) {
        return <p className="p-3 text-red-500">Error: {error?.message}</p>;
    }

    const hasActiveFilters = appliedFilters.name || appliedFilters.username || appliedFilters.role;

    const emptyMessage = hasActiveFilters
        ? 'No users found matching your search criteria. Please try different filters.'
        : 'No users found.';

    return (
        <div>
            <DataTable
                value={displayData}
                lazy
                paginator
                first={paginationState.page * paginationState.rows}
                rows={paginationState.rows}
                totalRecords={paginationState.totalRecords}
                onPage={onPageChange}
                paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords} users"
                rowsPerPageOptions={[10, 20, 50, 100]}
                stripedRows
                className="user-list-table"
                emptyMessage={emptyMessage}
                paginatorClassName="border-top-1 surface-border"
                responsiveLayout="scroll"
            >
                <Column field="fullName" header="Full Name" body={fullNameBodyTemplate} sortable />
                <Column field="username" header="Username" sortable />
                <Column field="tenant_ids" header="Tenant ID" body={tenantBodyTemplate} sortable />
                <Column field="role_ids" header="Role ID" body={roleBodyTemplate} sortable />
                <Column header="View" body={actionBodyTemplate} />
            </DataTable>
        </div>
    );
};

TenantUserTable.propTypes = {
    displayData: PropTypes.array.isRequired,
    isPending: PropTypes.bool.isRequired,
    isError: PropTypes.bool.isRequired,
    error: PropTypes.object,
    actionBodyTemplate: PropTypes.func.isRequired,
    appliedFilters: PropTypes.shape({
        name: PropTypes.string,
        username: PropTypes.string,
        role: PropTypes.string,
        tenant: PropTypes.string,
    }).isRequired,
    paginationState: PropTypes.shape({
        page: PropTypes.number,
        rows: PropTypes.number,
        totalRecords: PropTypes.number,
    }).isRequired,
    onPageChange: PropTypes.func.isRequired,
};

export { UserList };
