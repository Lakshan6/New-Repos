import { Outlet } from 'react-router';

const AdminLayout = () => {
    return (
        <div className="h-full">
            <Outlet />
        </div>
    );
};

export { AdminLayout };
