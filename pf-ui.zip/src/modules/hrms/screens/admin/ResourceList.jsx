import React, { useEffect, useState, useCallback, useRef } from 'react';
import { useNavigate } from 'react-router';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { useResourceSearch, useGetResourceAccessDetails } from '../../hooks/admin';
import { getReqInfoObj } from '@shared/utils/common';
import { useT } from '@shared/hooks/useT';
import SearchCard from '@shared/components/SearchCard';
import DynamicHeightWrapper from '@shared/components/DynamicHeightWrapper'; // Import the wrapper
import PropTypes from 'prop-types';
import '../../styles/admin/ResourceList.css';

const TOOLTIP_STYLE = { position: 'top' };
const STYLES = { minHeight: { minHeight: '400px' }, fontSize: { fontSize: '3rem' } };

const ResourceList = () => {
    const navigate = useNavigate();
    const { fetchResourceAccessById } = useGetResourceAccessDetails();
    const { searchResources, isPending, isError, error } = useResourceSearch();
    const { t } = useT();

    const [cache, setCache] = useState({});
    const [paginationState, setPaginationState] = useState({
        page: 0,
        rows: 10,
        totalRecords: 0,
    });
    const [fetchError, setFetchError] = useState(null);
    const attemptCountRef = useRef(0);
    const maxAttempts = 2;

    // Filter states
    const [displayNameFilter, setDisplayNameFilter] = useState('');
    const [typeFilter, setTypeFilter] = useState('');
    const [enabledFilter, setEnabledFilter] = useState('');

    const [appliedFilters, setAppliedFilters] = useState({
        displayName: '',
        type: '',
        enabled: '',
    });

    const buildRequestBody = (page, rows, filters) => {
        const requestInfo = getReqInfoObj();

        return {
            ...requestInfo,
            resourceSearchDto: {
                ...(filters.displayName && { displayName: filters.displayName }),
                ...(filters.type && { type: filters.type }),
                ...(filters.enabled !== '' && { enabled: filters.enabled === 'true' }),
                limit: rows,
                offset: page * rows,
            },
        };
    };

    const fetchData = useCallback(
        async (page, rows, filters = appliedFilters) => {
            if (attemptCountRef.current >= maxAttempts) {
                return;
            }

            try {
                attemptCountRef.current += 1;
                setFetchError(null);

                const requestBody = buildRequestBody(page, rows, filters);
                const { data, totalRecords } = await searchResources(requestBody);

                const cacheKey = `page${page}-rows${rows}`;
                setCache((prev) => ({
                    ...prev,
                    [cacheKey]: data || [],
                }));

                setPaginationState((prev) => ({
                    ...prev,
                    totalRecords: totalRecords || 0,
                }));

                attemptCountRef.current = 0;
            } catch (err) {
                console.error('Failed to load resources:', err);

                if (attemptCountRef.current >= maxAttempts) {
                    setFetchError(
                        "Resources couldn't be fetched. Please refresh the page to try again.",
                    );
                } else {
                    setTimeout(() => {
                        fetchData(page, rows, filters);
                    }, 1000);
                }
            }
        },
        [searchResources, appliedFilters],
    );

    useEffect(() => {
        const cacheKey = `page${paginationState.page}-rows${paginationState.rows}`;
        if (!cache[cacheKey] && !fetchError) {
            fetchData(paginationState.page, paginationState.rows);
        }
    }, [paginationState.page, paginationState.rows, cache, fetchData, fetchError]);

    const onPageChange = (event) => {
        const { page, rows } = event;

        setPaginationState((prev) => ({
            ...prev,
            page,
            rows,
        }));

        const cacheKey = `page${page}-rows${rows}`;
        if (!cache[cacheKey]) {
            attemptCountRef.current = 0;
            fetchData(page, rows);
        }
    };

    const handleClearSearch = useCallback(() => {
        setDisplayNameFilter('');
        setTypeFilter('');
        setEnabledFilter('');
        setAppliedFilters({
            displayName: '',
            type: '',
            enabled: '',
        });
        setCache({});
        setFetchError(null);
        attemptCountRef.current = 0;
        setPaginationState((prev) => ({ ...prev, page: 0 }));
        fetchData(0, paginationState.rows, {
            displayName: '',
            type: '',
            enabled: '',
        });
    }, [fetchData, paginationState.rows]);

    const handleSubmitFilters = useCallback(
        (filters) => {
            const newFilters = {
                displayName: filters?.displayName || displayNameFilter,
                type: filters?.type || typeFilter,
                enabled: filters?.enabled !== undefined ? filters.enabled : enabledFilter,
            };
            setAppliedFilters(newFilters);
            setCache({});
            setFetchError(null);
            attemptCountRef.current = 0;
            setPaginationState((prev) => ({ ...prev, page: 0 }));
            fetchData(0, paginationState.rows, newFilters);
        },
        [displayNameFilter, enabledFilter, fetchData, paginationState.rows, typeFilter],
    );

    const handleRefresh = () => {
        setFetchError(null);
        attemptCountRef.current = 0;
        setCache({});
        fetchData(paginationState.page, paginationState.rows);
    };

    const handleViewResourceDetails = async (resourceId) => {
        try {
            const resourceAccessDetails = await fetchResourceAccessById(resourceId);
            navigate(`${resourceId}`, {
                state: { resourceAccessDetails },
            });
        } catch (err) {
            console.error('Error fetching resource details:', err);
            alert('Could not load resource details');
        }
    };

    const getCurrentDisplayData = () => {
        const cacheKey = `page${paginationState.page}-rows${paginationState.rows}`;
        return cache[cacheKey] || [];
    };

    const searchFilters = [
        {
            type: 'InputText',
            label: t('Display Name'),
            name: 'displayName',
            placeholder: t('Search by display name...'),
        },
        {
            type: 'InputText',
            label: t('Type'),
            name: 'type',
            placeholder: t('Search by type...'),
        },
        {
            type: 'Dropdown',
            label: t('Status'),
            name: 'enabled',
            placeholder: t('Select status...'),
            options: [
                { label: 'Enabled', value: 'true' },
                { label: 'Disabled', value: 'false' },
            ],
        },
    ];

    const handleSearchSubmit = useCallback(
        (values) => {
            setDisplayNameFilter(values.displayName || '');
            setTypeFilter(values.type || '');
            setEnabledFilter(values.enabled || '');
            handleSubmitFilters(values);
        },
        [handleSubmitFilters],
    );

    if (fetchError) {
        return (
            <div className="p-4">
                <div
                    className="flex flex-column align-items-center justify-content-center"
                    style={STYLES.minHeight}
                >
                    <i
                        className="pi pi-exclamation-triangle text-red-500"
                        style={STYLES.fontSize}
                    ></i>
                    <p className="text-red-500 text-xl mt-3 mb-3">{fetchError}</p>
                    <Button
                        label="Refresh"
                        icon="pi pi-refresh"
                        onClick={handleRefresh}
                        className="p-button-outlined"
                    />
                </div>
            </div>
        );
    }

    return (
        <div className="p-1">
            <SearchCard
                filters={searchFilters}
                onSubmit={handleSearchSubmit}
                onClear={handleClearSearch}
            />

            <DynamicHeightWrapper>
                {(tableHeight) => (
                    <ResourceTable
                        displayData={getCurrentDisplayData()}
                        isPending={isPending}
                        isError={isError}
                        error={error}
                        appliedFilters={appliedFilters}
                        paginationState={paginationState}
                        onPageChange={onPageChange}
                        onViewResourceDetails={handleViewResourceDetails}
                        tableHeight={tableHeight}
                    />
                )}
            </DynamicHeightWrapper>
        </div>
    );
};

const ResourceTable = ({
    displayData,
    isPending,
    isError,
    error,
    appliedFilters,
    paginationState,
    onPageChange,
    onViewResourceDetails,
    tableHeight,
}) => {
    const hasActiveFilters =
        appliedFilters.displayName || appliedFilters.type || appliedFilters.enabled;

    const emptyMessage = hasActiveFilters
        ? 'No resources found matching your search criteria. Please try different filters.'
        : 'No resources found.';

    const statusBodyTemplate = useCallback((rowData) => {
        return (
            <Tag
                value={rowData.enabled ? 'Enabled' : 'Disabled'}
                severity={rowData.enabled ? 'success' : 'danger'}
            />
        );
    }, []);

    const createViewHandler = useCallback(
        (id) => () => {
            onViewResourceDetails(id);
        },
        [onViewResourceDetails],
    );

    const actionBodyTemplate = useCallback(
        (rowData) => {
            const onClick = createViewHandler(rowData.id);

            return (
                <Button
                    icon="pi pi-eye"
                    rounded
                    outlined
                    tooltip="View Resource Details"
                    tooltipOptions={TOOLTIP_STYLE}
                    onClick={onClick}
                />
            );
        },
        [createViewHandler],
    );

    if (isPending && displayData.length === 0) {
        return <p className="p-3 text-color-secondary">Loading resources...</p>;
    }

    if (isError) {
        return <p className="p-3 text-red-500">Error: {error?.message}</p>;
    }

    return (
        <div>
            <DataTable
                value={displayData}
                lazy
                paginator
                first={paginationState.page * paginationState.rows}
                rows={paginationState.rows}
                totalRecords={paginationState.totalRecords}
                onPage={onPageChange}
                loading={isPending}
                paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                currentPageReportTemplate="Showing {first} to {last} of {totalRecords} resources"
                rowsPerPageOptions={[10, 25, 50, 100]}
                stripedRows
                className="resource-list-table"
                emptyMessage={emptyMessage}
                paginatorClassName="border-top-1 surface-border"
                responsiveLayout="scroll"
                scrollable
                scrollHeight={tableHeight}
            >
                <Column field="id" header="ID" sortable className="min-w-12rem" />
                <Column field="displayName" header="Display Name" sortable />
                <Column field="type" header="Type" sortable />
                <Column field="apiEndpoint" header="API Endpoint" />
                <Column field="enabled" header="Status" body={statusBodyTemplate} sortable />
                <Column header="View" body={actionBodyTemplate} className="w-8rem" />
            </DataTable>
        </div>
    );
};

ResourceTable.propTypes = {
    displayData: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]).isRequired,
            displayName: PropTypes.string,
            type: PropTypes.string,
            apiEndpoint: PropTypes.string,
            enabled: PropTypes.bool,
        }),
    ).isRequired,

    isPending: PropTypes.bool.isRequired,
    isError: PropTypes.bool.isRequired,
    error: PropTypes.shape({
        message: PropTypes.string,
    }),

    appliedFilters: PropTypes.shape({
        displayName: PropTypes.string,
        type: PropTypes.string,
        enabled: PropTypes.oneOfType([PropTypes.string, PropTypes.bool]),
    }).isRequired,

    paginationState: PropTypes.shape({
        page: PropTypes.number.isRequired,
        rows: PropTypes.number.isRequired,
        totalRecords: PropTypes.number.isRequired,
    }).isRequired,

    onPageChange: PropTypes.func.isRequired,
    onViewResourceDetails: PropTypes.func.isRequired,

    tableHeight: PropTypes.oneOfType([
        PropTypes.string, // e.g. "600px"
        PropTypes.number, // PrimeReact also allows number
    ]),
};

export { ResourceList };
