import React, { useEffect, useState, useCallback } from 'react';
import { useLocation, useNavigate } from 'react-router';
import { useForm, Controller } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { userSchema } from '@shared/schemas/userSchema';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { Message } from 'primereact/message';
import { InputText } from 'primereact/inputtext';
import { MultiSelect } from 'primereact/multiselect';
import { useAppToast } from '@shared/components/Toast';
import { useUpdateUserByAdmin } from '../../hooks/admin/';
import { getReqInfoObj } from '@shared/utils/common';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import { useT } from '@shared/hooks/useT';
import PropTypes from 'prop-types';
import '../../styles/admin/UserDetails.css';

const STYLES = { fontSize: '0.7rem' };

const UserDetails = () => {
    const { state } = useLocation();
    const navigate = useNavigate();

    const [isAdmin, setIsAdmin] = useState(false);
    const [user, setUser] = useState(state?.userDetails);
    const [isEditing, setIsEditing] = useState(false);
    const [roleOptions, setRoleOptions] = useState([]);
    const [tenantOptions, setTenantOptions] = useState([]);
    const [isSaving, setIsSaving] = useState(false);

    const { mutate: updateUser } = useUpdateUserByAdmin();

    /* Provision of lanuage translation */
    const { t } = useT();
    const toast = useAppToast();

    const {
        control,
        handleSubmit,
        formState: { dirtyFields, errors, isValid },
        reset,
        getValues,
    } = useForm({
        resolver: zodResolver(userSchema),
        defaultValues: user || {},
        mode: 'onChange',
    });

    // Initialize admin status and options
    useEffect(() => {
        const selectedRoleIds = JSON.parse(localStorage.getItem('selectedRoleIds') || '[]');
        const adminRole = selectedRoleIds.some((role) => role?.endsWith('.ADMIN'));
        setIsAdmin(adminRole);

        if (user?.assignableRoleIds) {
            setRoleOptions(
                user.assignableRoleIds.map((roleId) => ({ label: roleId, value: roleId })),
            );
        }

        if (user?.assignableTenantIds) {
            setTenantOptions(
                user.assignableTenantIds.map((tenantId) => ({ label: tenantId, value: tenantId })),
            );
        }
    }, [user]);

    // Reset form when user data changes
    useEffect(() => {
        if (user) {
            reset(user);
        }
    }, [user, reset]);

    const onClickBack = useCallback(() => {
        navigate(-1);
    }, [navigate]);

    const fullName =
        [user.firstName, user.middleName, user.lastName].filter(Boolean).join(' ') || 'User';

    const handleEditClick = useCallback(() => setIsEditing(true), []);

    const handleCancelEdit = useCallback(() => {
        setIsEditing(false);
        reset(user);
        toast.info('Cancelled', 'Changes discarded');
    }, [reset, user, toast]);

    const buildRequestBody = useCallback(
        (formData, forceDelete = false) => {
            const requestInfo = getReqInfoObj();

            const requestBody = {
                ...requestInfo,
                forceDelete,
                userUpdatesDto: {
                    uuid: user.uuid,
                    firstName: formData.firstName,
                    middleName: formData.middleName || null,
                    lastName: formData.lastName,
                    phoneNo: formData.phoneNo,
                    altPhoneNo: formData.altPhoneNo || null,
                    emailId: formData.emailId,
                    username: formData.username,
                    gender: formData.gender || null,
                    address1: formData.address1 || null,
                    address2: formData.address2 || null,
                    city: formData.city || null,
                    state: formData.state || null,
                    zip: formData.pincode || null,
                    roleIds: formData.roleIds || [],
                    tenantIds: formData.tenantIds || [],
                    picture: null,
                    status: formData.status || null,
                    userStatusNote: formData.userStatusNote || null,
                },
            };

            return requestBody;
        },
        [user.uuid],
    );

    const onSubmit = (formData) => {
        setIsSaving(true);
        const requestBody = buildRequestBody(formData);

        updateUser(requestBody, {
            onSuccess: () => {
                setUser(formData);
                reset(formData);
                setIsEditing(false);
                setIsSaving(false);
                toast.success('Saved', 'User details updated successfully!');
            },
            onError: (error) => {
                setIsSaving(false);
                toast.error('Error', error?.response?.data?.message || 'Failed to update user');
            },
        });
    };

    const onSubmitError = () => {
        toast.error('Validation Error', 'Please fix all form errors before saving');
    };

    const handleDeleteClick = useCallback(() => {
        if (!window.confirm(`Delete ${fullName}?`)) return;

        setIsSaving(true);
        const formData = getValues();
        const requestBody = buildRequestBody(formData, true);

        updateUser(requestBody, {
            onSuccess: () => {
                setIsSaving(false);
                toast.success('Deleted', 'User has been deleted!');
                setTimeout(onClickBack, 1200);
            },
            onError: (error) => {
                setIsSaving(false);
                toast.error('Error', error?.response?.data?.message || 'Delete failed');
            },
        });
    }, [buildRequestBody, fullName, getValues, onClickBack, updateUser, toast]);

    return !user ? (
        <div className="flex flex-column align-items-center justify-content-center min-h-screen p-4">
            <Message severity="warn" text="No user data available." />
            <Button
                label="Go Back"
                icon="pi pi-arrow-left"
                className="mt-3 p-button-text"
                onClick={onClickBack}
            />
        </div>
    ) : (
        <div className="flex min-h-screen bg-surface-50">
            <div className="w-full border-1 surface-border border-round-lg overflow-hidden mb-4 page-bg">
                {/* HEADER */}
                <div className="user-details-header">
                    <div className="flex align-items-center justify-content-between h-full px-3">
                        <div className="flex align-items-center gap-2">
                            <button onClick={onClickBack} className="back-button">
                                <i className="pi pi-arrow-left" />
                            </button>

                            <div className="user-avatar">
                                <i className="pi pi-user"></i>
                            </div>

                            <h2 className="user-name">{fullName}</h2>
                        </div>

                        <div className="flex align-items-center gap-2">
                            {isAdmin && (
                                <>
                                    {isEditing ? (
                                        <>
                                            <Button
                                                label="Save"
                                                icon="pi pi-check"
                                                className="p-button-success p-button-sm"
                                                onClick={handleSubmit(onSubmit, onSubmitError)}
                                                loading={isSaving}
                                                disabled={!isValid}
                                            />
                                            <Button
                                                label="Cancel"
                                                icon="pi pi-times"
                                                className="p-button-secondary p-button-sm"
                                                onClick={handleCancelEdit}
                                                disabled={isSaving}
                                            />
                                        </>
                                    ) : (
                                        <>
                                            <Button
                                                label="Edit"
                                                icon="pi pi-pencil"
                                                className="p-button-sm"
                                                onClick={handleEditClick}
                                                disabled={isSaving}
                                            />
                                            <Button
                                                icon="pi pi-trash"
                                                label="Delete"
                                                className="p-button-danger p-button-outlined p-button-sm"
                                                onClick={handleDeleteClick}
                                                loading={isSaving}
                                            />
                                        </>
                                    )}
                                </>
                            )}
                        </div>
                    </div>
                    <div className="header-divider" />
                </div>

                {/* BODY */}
                <form id="user-form" className="pl-4 pr-4 pt-4 pb-4 mt-1">
                    <SectionCardWithHeader title={t('Basic Details')}>
                        <div className="sc-grid-2">
                            <FormField
                                label={t('First Name')}
                                name="firstName"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.firstName}
                                error={errors.firstName}
                            />
                            <FormField
                                label={t('Middle Name')}
                                name="middleName"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.middleName}
                            />
                            <FormField
                                label={t('Last Name')}
                                name="lastName"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.lastName}
                                error={errors.lastName}
                            />
                            <FormField
                                label={t('Username')}
                                name="username"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.username}
                                error={errors.username}
                            />
                            <FormField
                                label={t('Gender')}
                                name="gender"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.gender}
                            />
                            <FormField
                                label={t('UUID')}
                                name="uuid"
                                control={control}
                                isEditing={false}
                            />
                        </div>
                    </SectionCardWithHeader>

                    <SectionCardWithHeader title="Contact Information">
                        <div className="sc-grid-2">
                            <FormField
                                label={t('Phone Number')}
                                name="phoneNo"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.phoneNo}
                                error={errors.phoneNo}
                                type="tel"
                            />
                            <FormField
                                label={t('Alternative Phone Number')}
                                name="altPhoneNo"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.altPhoneNo}
                                error={errors.altPhoneNo}
                                type="tel"
                            />
                            <FormField
                                label={t('Email Id')}
                                name="emailId"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.emailId}
                                error={errors.emailId}
                                type="email"
                            />
                        </div>
                    </SectionCardWithHeader>

                    <SectionCardWithHeader title="Address">
                        <div className="sc-grid-2">
                            <FormField
                                label={t('Address 1')}
                                name="address1"
                                control={control}
                                isEditing={isEditing}
                            />
                            <FormField
                                label={t('Address 2')}
                                name="address2"
                                control={control}
                                isEditing={isEditing}
                            />
                            <FormField
                                label={t('City')}
                                name="city"
                                control={control}
                                isEditing={isEditing}
                            />
                            <FormField
                                label={t('State')}
                                name="state"
                                control={control}
                                isEditing={isEditing}
                            />
                            <FormField
                                label={t('Pincode')}
                                name="pincode"
                                control={control}
                                isEditing={isEditing}
                            />
                        </div>
                    </SectionCardWithHeader>

                    <SectionCardWithHeader title={t('Roles & Tenant Information')}>
                        <div className="sc-grid-2">
                            <RoleField
                                label={t('Role Id')}
                                name="roleIds"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.roleIds}
                                roleOptions={roleOptions}
                                error={errors.roleIds}
                            />
                            <TenantField
                                label={t('Tenant Id')}
                                name="tenantIds"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.tenantIds}
                                tenantOptions={tenantOptions}
                                error={errors.tenantIds}
                            />
                        </div>
                    </SectionCardWithHeader>

                    <SectionCardWithHeader title={t('Other Details & Status')}>
                        <div className="sc-grid-2">
                            <FormField
                                label={t('User Status Note')}
                                name="userStatusNote"
                                control={control}
                                isEditing={isEditing}
                                isDirty={dirtyFields.userStatusNote}
                            />
                            <FormField
                                label={t('Status')}
                                name="status"
                                control={control}
                                isEditing={false}
                            />
                        </div>
                    </SectionCardWithHeader>
                </form>
            </div>
        </div>
    );
};

/* ------------------------------------------------------------
   FORM FIELD COMPONENT
------------------------------------------------------------ */

const FormField = ({
    label,
    name,
    control,
    isEditing,
    isDirty,
    error,
    type = 'text',
    rules,
    fullWidth = false,
}) => {
    const renderFormField = useCallback(
        ({ field }) => {
            const isNA =
                !isEditing &&
                (field.value === undefined || field.value === null || field.value === '');
            const displayValue = isNA ? 'N/A' : field.value || '';

            return (
                <div className={fullWidth ? 'full-width-field' : 'half-width-field'}>
                    <label className="block text-sm font-medium text-color-secondary mb-1">
                        {label}
                    </label>

                    {isEditing ? (
                        <InputText
                            {...field}
                            type={type}
                            value={displayValue}
                            className="w-full form-field-input"
                            invalid={!!error}
                        />
                    ) : (
                        <div className="form-field-display">{displayValue}</div>
                    )}

                    <div className="form-field-status flex align-items-center pt-2">
                        {isEditing && isDirty && !error && (
                            <small className="text-primary-500 ml-auto" style={STYLES}>
                                Modified
                            </small>
                        )}
                        {error && (
                            <small className="text-red-500 ml-auto" style={STYLES}>
                                {error.message}
                            </small>
                        )}
                    </div>
                </div>
            );
        },
        [label, isEditing, isDirty, error, type, fullWidth],
    );

    return <Controller name={name} control={control} rules={rules} render={renderFormField} />;
};

/* ------------------------------------------------------------
   ROLE FIELD
------------------------------------------------------------ */

const RoleField = ({ label, name, control, isEditing, isDirty, roleOptions, error }) => {
    const renderRoleField = useCallback(
        ({ field }) => {
            const roles = Array.isArray(field.value) ? field.value : [];

            return (
                <div className="col-12 lg:col-6 p-0 fixed-field">
                    <label className="block text-sm font-medium text-color-secondary mb-1">
                        {label}
                    </label>

                    {isEditing ? (
                        <MultiSelect
                            {...field}
                            value={roles}
                            options={roleOptions}
                            display="chip"
                            placeholder="Select roles"
                            className="w-full multiselect-ellipsis"
                            filter
                        />
                    ) : (
                        <div className="flex flex-wrap gap-2 tag-container">
                            {roles.length
                                ? roles.map((r) => <Tag key={r} value={r} className="role-tag" />)
                                : 'N/A'}
                        </div>
                    )}

                    <div className="form-field-status">
                        {isEditing && isDirty && !error && (
                            <small className="text-primary-500" style={STYLES}>
                                Modified
                            </small>
                        )}
                        {error && (
                            <small className="text-red-500" style={STYLES}>
                                {error.message}
                            </small>
                        )}
                    </div>
                </div>
            );
        },
        [label, isEditing, isDirty, error, roleOptions],
    );

    return <Controller name={name} control={control} render={renderRoleField} />;
};

/* ------------------------------------------------------------
   TENANT FIELD
------------------------------------------------------------ */

const TenantField = ({ label, name, control, isEditing, isDirty, tenantOptions, error }) => {
    const renderTenantField = useCallback(
        ({ field }) => {
            const tenants = Array.isArray(field.value) ? field.value : [];

            return (
                <div className="col-12 lg:col-6 p-0 fixed-field">
                    <label className="block text-sm font-medium text-color-secondary mb-1">
                        {label}
                    </label>

                    {isEditing ? (
                        <MultiSelect
                            {...field}
                            value={tenants}
                            options={tenantOptions}
                            display="chip"
                            placeholder="Select tenants"
                            className="w-full multiselect-ellipsis"
                            filter
                        />
                    ) : (
                        <div className="flex flex-wrap gap-2 tag-container">
                            {tenants.length
                                ? tenants.map((t) => (
                                      <Tag key={t} value={t} className="tenant-tag" />
                                  ))
                                : 'N/A'}
                        </div>
                    )}

                    <div className="form-field-status">
                        {isEditing && isDirty && !error && (
                            <small className="text-primary-500" style={STYLES}>
                                Modified
                            </small>
                        )}
                        {error && (
                            <small className="text-red-500" style={STYLES}>
                                {error.message}
                            </small>
                        )}
                    </div>
                </div>
            );
        },
        [label, isEditing, isDirty, error, tenantOptions],
    );

    return <Controller name={name} control={control} render={renderTenantField} />;
};

FormField.propTypes = {
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    control: PropTypes.object.isRequired, // react-hook-form control
    isEditing: PropTypes.bool.isRequired,
    isDirty: PropTypes.bool,
    error: PropTypes.shape({
        message: PropTypes.string,
    }),
    type: PropTypes.string,
    rules: PropTypes.object,
    fullWidth: PropTypes.bool,
};

FormField.defaultProps = {
    type: 'text',
    rules: {},
    fullWidth: false,
    isDirty: false,
    error: null,
};

RoleField.propTypes = {
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    control: PropTypes.object.isRequired,
    isEditing: PropTypes.bool.isRequired,
    isDirty: PropTypes.bool,
    roleOptions: PropTypes.arrayOf(
        PropTypes.shape({
            label: PropTypes.string.isRequired,
            value: PropTypes.string.isRequired,
        }),
    ).isRequired,
    error: PropTypes.shape({
        message: PropTypes.string,
    }),
};

RoleField.defaultProps = {
    isDirty: false,
    error: null,
};

TenantField.propTypes = {
    label: PropTypes.string.isRequired,
    name: PropTypes.string.isRequired,
    control: PropTypes.object.isRequired,
    isEditing: PropTypes.bool.isRequired,
    isDirty: PropTypes.bool,
    tenantOptions: PropTypes.arrayOf(
        PropTypes.shape({
            label: PropTypes.string.isRequired,
            value: PropTypes.string.isRequired,
        }),
    ).isRequired,
    error: PropTypes.shape({
        message: PropTypes.string,
    }),
};

TenantField.defaultProps = {
    isDirty: false,
    error: null,
};

export { UserDetails };
