import React, { useCallback } from 'react';
import { useLocation, useParams, useNavigate } from 'react-router';
import { Message } from 'primereact/message';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import SimpleSectionCard from '@shared/components/SimpleSectionCard';
import { useT } from '@shared/hooks/useT';
import '../../styles/admin/UserDetails.css';
import PropTypes from 'prop-types';

const ResourceAccessDetails = () => {
    const { state } = useLocation();
    const { resourceId } = useParams();
    const navigate = useNavigate();
    const { t } = useT();

    const resourceData = state?.resourceAccessDetails;

    const onClickBack = useCallback(() => {
        navigate(-1);
    }, [navigate]);

    if (!resourceData) {
        return (
            <div className="flex flex-column align-items-center justify-content-center min-h-screen p-4">
                <Message
                    severity="warn"
                    text="No resource data available. Please go back and try again."
                />
                <Button
                    label="Go Back"
                    icon="pi pi-arrow-left"
                    className="mt-3"
                    onClick={onClickBack}
                />
            </div>
        );
    }

    // Handler for delete click
    const handleRoleAccessDelete = (roleId, accessUuid, resourceId) => {
        // In real app: you'd open a confirmation dialog or API call here
        alert(
            `Deleting access for Role: ${roleId}\nAccess UUID: ${accessUuid}\nFor Resource with Id: ${resourceId}`,
        );
    };

    // Early return if no data
    if (!resourceData || !Array.isArray(resourceData) || resourceData.length === 0) {
        return (
            <div className="flex flex-column align-items-center justify-content-center min-h-screen p-4">
                <Message severity="warn" text="No resource access data available." />
                <Button
                    label="Go Back"
                    icon="pi pi-arrow-left"
                    className="mt-3 p-button-text"
                    onClick={onClickBack}
                />
            </div>
        );
    }

    // Extract resource information from first record (common across all)
    const resourceInfo = resourceData[0]?.resource || {};
    const resourceName = resourceInfo.displayName || resourceInfo.id || 'Resource';

    // Format date helper
    const formatDate = (timestamp) => {
        if (!timestamp) return 'N/A';
        return new Date(timestamp).toLocaleString('en-IN', {
            dateStyle: 'medium',
            timeStyle: 'short',
        });
    };

    return (
        <div className="flex min-h-screen bg-surface-50">
            <div className="w-full border-1 surface-border border-round-lg overflow-hidden mb-4 page-bg">
                {/* HEADER */}
                <div className="user-details-header">
                    <div className="flex align-items-center justify-content-between h-full px-3">
                        <div className="flex align-items-center gap-2">
                            <button onClick={onClickBack} className="back-button">
                                <i className="pi pi-arrow-left" />
                            </button>

                            <div className="user-avatar">
                                <i className={`pi ${resourceInfo.icon || 'pi-shield'}`}></i>
                            </div>

                            <h2 className="user-name">{resourceName}</h2>

                            {resourceInfo.enabled ? (
                                <Tag value="Enabled" severity="success" />
                            ) : (
                                <Tag value="Disabled" severity="danger" />
                            )}
                        </div>
                    </div>
                    <div className="header-divider" />
                </div>

                {/* BODY */}
                <div className="pl-4 pr-4 pt-4 pb-4 mt-1">
                    {/* Resource Information */}
                    <SectionCardWithHeader title={t('Resource Information')}>
                        <div className="sc-grid-2">
                            <DetailField label={t('Resource ID')} value={resourceInfo.id} />
                            <DetailField
                                label={t('Display Name')}
                                value={resourceInfo.displayName}
                            />
                            <DetailField label={t('Type')} value={resourceInfo.type} />
                            <DetailField label={t('Path')} value={resourceInfo.path} />
                            <DetailField label={t('Order No')} value={resourceInfo.orderNo} />
                            <DetailField label={t('Icon')} value={resourceInfo.icon} />
                            <DetailField
                                label={t('Status')}
                                value={resourceInfo.enabled ? 'Enabled' : 'Disabled'}
                            />
                            <DetailField label={t('Link')} value={resourceInfo.link} />
                            <DetailField
                                label={t('API Endpoint')}
                                value={resourceInfo.apiEndpoint}
                                fullWidth
                            />
                        </div>
                    </SectionCardWithHeader>

                    <SectionCardWithHeader title="Audit details">
                        {resourceInfo.auditDetails && (
                            <div className="sc-grid-2">
                                <DetailField
                                    label={t('Created Time')}
                                    value={formatDate(resourceInfo.auditDetails?.createdTime)}
                                />
                                <DetailField
                                    label={t('Last Modified Time')}
                                    value={formatDate(resourceInfo.auditDetails?.lastModifiedTime)}
                                />
                            </div>
                        )}
                    </SectionCardWithHeader>

                    {/* Roles with Access */}
                    <SectionCardWithHeader
                        title={`${t('Roles with Access')} (${resourceData.length})`}
                    >
                        <div className="flex flex-column gap-3">
                            {resourceData.map((accessRecord, index) => {
                                const role = accessRecord.role || {};
                                return (
                                    <SimpleSectionCard
                                        key={accessRecord.uuid || index}
                                        title={role.id || 'Unknown Role'}
                                        actions={[
                                            {
                                                label: t('REMOVE'),
                                                onClick: () =>
                                                    handleRoleAccessDelete(
                                                        role.id,
                                                        accessRecord.uuid,
                                                        resourceInfo.id,
                                                    ),
                                                tooltip: t("Remove this role's access"),
                                                className:
                                                    'p-button-danger p-button-outlined p-button-rounded p-button-sm p-button-xs',
                                            },
                                        ]}
                                    >
                                        <div className="sc-grid-2">
                                            <DetailField
                                                label={t('Role Name')}
                                                value={role.name}
                                                compact
                                            />
                                            <DetailField
                                                label={t('Access UUID')}
                                                value={accessRecord.uuid}
                                                compact
                                            />
                                            <DetailField
                                                label={t('Description')}
                                                value={role.description}
                                                fullWidth
                                                compact
                                            />
                                            <DetailField
                                                label={t('Role Created')}
                                                value={formatDate(role.auditDetails?.createdTime)}
                                                compact
                                            />
                                            <DetailField
                                                label={t('Role Modified')}
                                                value={formatDate(
                                                    role.auditDetails?.lastModifiedTime,
                                                )}
                                                compact
                                            />
                                        </div>
                                    </SimpleSectionCard>
                                );
                            })}
                        </div>
                    </SectionCardWithHeader>
                </div>
            </div>
        </div>
    );
};

/* ------------------------------------------------------------
   DETAIL FIELD COMPONENT
------------------------------------------------------------ */

const DetailField = ({ label, value, fullWidth = false, compact = false, small = false }) => {
    const isNA = value === undefined || value === null || value === '';
    const displayValue = isNA ? 'N/A' : value;

    return (
        <div className={fullWidth ? 'full-width-field' : 'half-width-field'}>
            <label
                className={`block font-medium text-color-secondary ${small ? 'text-xs mb-0' : 'text-sm mb-1'}`}
            >
                {label}
            </label>
            <div
                className={`form-field-display ${compact ? 'py-1' : ''} ${small ? 'text-sm' : ''}`}
            >
                {displayValue}
            </div>
        </div>
    );
};

DetailField.propTypes = {
    label: PropTypes.oneOfType([PropTypes.string, PropTypes.node]).isRequired,

    value: PropTypes.oneOfType([
        PropTypes.string,
        PropTypes.number,
        PropTypes.bool,
        PropTypes.node,
    ]),

    fullWidth: PropTypes.bool,
    compact: PropTypes.bool,
    small: PropTypes.bool,
};

export { ResourceAccessDetails };
