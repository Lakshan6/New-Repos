import { useMemo } from 'react';
import { ProgressBar } from 'primereact/progressbar';
import { Tag } from 'primereact/tag';
import { Chart } from 'primereact/chart';
import { useReadApi } from '@shared/hooks';
import { Skeleton } from 'primereact/skeleton';

const DASHBOARD_DATA = {
    leave: {
        al: { used: 0, total: 22 },
        cl: { used: 2, total: 12 },
        sl: { used: 3, total: 20 },
        cycleEnd: '31 March 2026',
        month: 'January',
    },
    holidays: [
        {
            name: 'Makara Sankranti',
            date: '15 Jan 2026',
            daysLeft: 12,
            location: 'Bengaluru Office',
        },
        {
            name: 'Republic Day',
            date: '26 Jan 2026',
            daysLeft: 21,
            location: 'Bengaluru Office',
        },
    ],
    todayAttendance: {
        totalEmployees: 8000,
        present: 6550,
        onLeave: 820,
        OnMO: 630,
        percentage: Number((6258 / 8000) * 100).toFixed(1),
        lastUpdated: '10:30 AM',
    },
};

const BAR_COLORS = [
    'rgba(241, 175, 99, 0.5)',
    'rgba(79, 70, 229, 0.5)',
    'rgba(14, 165, 233, 0.5)',
    'rgba(20, 184, 166, 0.5)',
    'rgba(224, 39, 132, 0.5)',
];

const designationChartOptions = {
    indexAxis: 'x', // vertical bars
    maintainAspectRatio: true,
    plugins: {
        legend: {
            display: false,
        },
        datalabels: {
            anchor: 'end',
            align: 'end',
            color: '#374151', // gray-700
            font: {
                weight: '600',
                size: 11,
            },
            formatter: (value) => value.toLocaleString(),
        },
    },
    scales: {
        x: {
            ticks: {
                color: '#6B7280', // gray-500
            },
        },
        y: {
            ticks: {
                callback: (value) => Number(value).toLocaleString(),
                color: '#6B7280',
            },
        },
    },
};

const ANNOUNCEMENTS = [
    {
        title: 'Revised Leave Policy',
        description: 'Updated leave rules effective from 1 Feb 2026.',
        date: '14 Jan 2026',
        type: 'Policy',
    },
    {
        title: 'IT Declaration Window Open',
        description: 'Submit your IT declaration before 31 Jan 2026.',
        date: '10 Jan 2026',
        type: 'Reminder',
    },
    {
        title: 'Annual Day Celebrations',
        description: 'Photos from Annual Day are now available.',
        date: '05 Jan 2026',
        type: 'General',
    },
];

const PAYROLL_DATA = {
    lastSalary: {
        month: 'January 2026',
        netPay: '₹114.8 Cr',
        payDate: '31 Jan 2026',
        status: 'Credited',
    },
    nextSalary: {
        expectedDate: '28 Feb 2026',
    },
};

const COMPLIANCE_DATA = {
    perks: ['Medical Insurance', 'Transport Facility', 'Canteen Services'],
    apr: {
        financialYear: '2025–26',
        status: 'Not Submitted',
        dueDate: '31 Jan 2026',
    },
    tax: {
        financialYear: '2025–26',
        status: 'Submitted',
        lastUpdated: '10 Jan 2026',
    },
};

const AdminLanding = () => {
    const data = DASHBOARD_DATA;

    /** Dashboard (employee summary) */
    const { data: dashboardData, isLoading: isDashboardLoading } = useReadApi({
        service: 'erp_hrms',
        endpoint: '/api/employees/dashboard',
        method: 'POST',
        body: {
            requestInfo: {
                userInfo: {
                    userDetails: {
                        uuid: 'd0404b4a-0489-44ca-801d-a9c1a4fb1c1d',
                        firstName: 'PRINCIPAL',
                        lastName: 'TEST',
                        username: 'TEST_UNIVERSITY_COLLEGE_PRINCIPAL',
                        phoneNo: '3683601601',
                        emailId: 'test_cplx_hr_subordinate@example.com',
                    },
                    tenantIds: ['BG_CX'],
                    selectedRoleIds: ['COMPANY.UNIT.HR_EXECUTIVE'],
                },
            },
        },
    });

    /** Employees by designation */
    const { data: designationResponse, isLoading: isDesignationLoading } = useReadApi({
        service: 'erp_hrms',
        endpoint: '/api/employees/designation-count',
        method: 'GET',
        body: {
            requestInfo: {
                authToken: '007032fd-0b51-4dd9-872b-450178250220',
                userInfo: {
                    userDetails: {
                        uuid: '29972cc9-ecaf-4ef2-9727-ae1950235285',
                        firstName: 'PRINCIPAL',
                        lastName: 'TEST',
                        username: 'TEST_UNIVERSITY_COLLEGE_PRINCIPAL',
                        phoneNo: '3683601601',
                        emailId: 'test_cplx_hr_subordinate@example.com',
                    },
                    tenantIds: ['BG_CX'],
                    selectedRoleIds: ['COMPANY.UNIT.HR_EXECUTIVE'],
                },
            },
        },
    });

    const ORG_HEADCOUNT = useMemo(() => {
        const total = dashboardData?.departmentTotalEmployees ?? 0;
        const active = dashboardData?.departmentActiveEmployees ?? 0;

        return {
            sanctioned: total,
            active,
            vacancies: total - active,
            lastUpdated: 'Today',
        };
    }, [dashboardData?.departmentTotalEmployees, dashboardData?.departmentActiveEmployees]);

    const employeesByDesignation = useMemo(() => {
        return (designationResponse ?? []).map((item) => ({
            label: item.designationName,
            count: item.employeeCount,
        }));
    }, [designationResponse]);

    const designationChartData = useMemo(() => {
        return {
            labels: employeesByDesignation.map((d) => d.label),
            datasets: [
                {
                    data: employeesByDesignation.map((d) => d.count),
                    backgroundColor: BAR_COLORS,
                    borderRadius: 6,
                    barThickness: 40,
                },
            ],
        };
    }, [employeesByDesignation]);

    return (
        <div className="grid">
            {/* Employees Present Today */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-users text-green-600" />
                        <span className="font-medium text-900">Employees Present Today</span>
                    </div>

                    <div className="flex gap-4">
                        {/* Left summary */}
                        <div className="flex-1">
                            <div className="text-4xl font-bold text-900 mb-1">
                                <div className="text-4xl font-bold text-900 mb-1">
                                    {DASHBOARD_DATA.todayAttendance.present.toLocaleString()}
                                </div>
                            </div>
                            <div className="flex align-items-center text-sm text-500 mb-2">
                                Present out of{' '}
                                {isDashboardLoading ? (
                                    <Skeleton width="3rem" height="1rem" className="ml-2" />
                                ) : (
                                    DASHBOARD_DATA.todayAttendance.totalEmployees.toLocaleString()
                                )}
                            </div>

                            <div className="text-sm text-600 mb-1">
                                <strong>Attendance:</strong>{' '}
                                {DASHBOARD_DATA.todayAttendance.percentage}%
                            </div>
                            <div className="text-xs text-500">
                                Updated at {DASHBOARD_DATA.todayAttendance.lastUpdated}
                            </div>
                        </div>

                        {/* Right breakdown */}
                        <div className="flex-1">
                            <ul className="list-none p-0 m-0 text-sm">
                                <li className="mb-3">
                                    <div className="font-medium text-900">On Leave</div>
                                    <div className="text-xs text-600">
                                        {DASHBOARD_DATA.todayAttendance.onLeave.toLocaleString()}{' '}
                                        employees
                                    </div>
                                </li>

                                <li className="mb-3">
                                    <div className="font-medium text-900">On Movement</div>
                                    <div className="text-xs text-600">
                                        {DASHBOARD_DATA.todayAttendance.OnMO.toLocaleString()}{' '}
                                        employees
                                    </div>
                                </li>
                            </ul>
                        </div>
                    </div>

                    <div className="border-top-1 surface-border mt-4 pt-3 flex justify-content-between align-items-center">
                        <Tag
                            value={`${DASHBOARD_DATA.todayAttendance.percentage}% present`}
                            severity="success"
                        />
                        <span className="text-sm text-primary cursor-pointer">
                            View attendance →
                        </span>
                    </div>
                </div>
            </div>

            {/* Active Employees */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-users text-indigo-600" />
                        <span className="font-medium text-900">Employees On Board</span>
                    </div>

                    <div className="mb-3">
                        <div className="text-4xl font-bold text-900 mb-1">
                            <div className="text-4xl font-bold text-900 mb-1">
                                {isDashboardLoading ? (
                                    <Skeleton width="6rem" height="2.5rem" />
                                ) : (
                                    ORG_HEADCOUNT.active.toLocaleString()
                                )}
                            </div>
                        </div>
                        <div className="text-sm text-500">
                            <div className="text-sm text-500">
                                {isDashboardLoading ? (
                                    <Skeleton width="10rem" height="1rem" />
                                ) : (
                                    <>
                                        Out of {ORG_HEADCOUNT.sanctioned.toLocaleString()}{' '}
                                        sanctioned
                                    </>
                                )}
                            </div>
                        </div>
                    </div>

                    {isDashboardLoading ? (
                        <Skeleton width="100%" height="0.75rem" />
                    ) : (
                        <ProgressBar
                            value={Number(
                                ((ORG_HEADCOUNT.active / ORG_HEADCOUNT.sanctioned) * 100).toFixed(
                                    1,
                                ),
                            )}
                        />
                    )}

                    <div className="text-xs text-500 mt-4">
                        Vacancies: {ORG_HEADCOUNT.vacancies.toLocaleString()} • Updated{' '}
                        {ORG_HEADCOUNT.lastUpdated}
                    </div>
                </div>
            </div>

            {/* Leave Utilization */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-briefcase text-orange-500" />
                        <span className="font-medium text-900">
                            Avg Leave Utilization / Employee ({data.leave.month})
                        </span>
                    </div>

                    {/* Earned Leave */}
                    <div className="mb-4">
                        <div className="flex justify-content-between align-items-center text-sm mb-2">
                            <span className="text-900 font-medium">Annual Leave</span>
                            <span className="text-600">
                                {data.leave.al.used} / {data.leave.al.total}
                            </span>
                        </div>
                        {/* <ProgressBar value={(data.leave.el.used / data.leave.el.total) * 100} /> */}
                    </div>

                    {/* Casual Leave */}
                    <div className="mb-4">
                        <div className="flex justify-content-between align-items-center text-sm mb-2">
                            <span className="text-900 font-medium">Casual Leave</span>
                            <span className="text-600">
                                {data.leave.cl.used} / {data.leave.cl.total}
                            </span>
                        </div>
                        {/* <ProgressBar value={(data.leave.cl.used / data.leave.cl.total) * 100} /> */}
                    </div>

                    {/* Sick Leave */}
                    <div>
                        <div className="flex justify-content-between align-items-center text-sm mb-2">
                            <span className="text-900 font-medium">Sick Leave</span>
                            <span className="text-600">
                                {data.leave.sl.used} / {data.leave.sl.total}
                            </span>
                        </div>
                        {/* <ProgressBar value={(data.leave.sl.used / data.leave.sl.total) * 100} /> */}
                    </div>

                    <div className="text-xs text-500 mt-4">
                        Leave cycle ends on {data.leave.cycleEnd}
                    </div>
                </div>
            </div>

            {/* Upcoming Holidays */}
            <div className="col-12 lg:col-6 xl:col-3">
                <div className="card p-4 h-full">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-calendar text-blue-500" />
                        <span className="font-medium text-900">Upcoming Holidays</span>
                    </div>

                    {/* Primary (Nearest) Holiday */}
                    <div className="mb-4">
                        <div className="flex justify-content-between align-items-center mb-1">
                            <div>
                                <div className="text-lg font-semibold text-900">
                                    {data.holidays[0].name}
                                </div>
                                <div className="text-sm text-500">{data.holidays[0].date}</div>
                            </div>

                            <Tag
                                value={`In ${data.holidays[0].daysLeft} days`}
                                severity="warning"
                            />
                        </div>
                    </div>

                    {/* Secondary Holiday */}
                    <div className="border-top-1 surface-border pt-3">
                        <div className="flex justify-content-between align-items-center">
                            <div>
                                <div className="text-sm font-medium text-800">
                                    {data.holidays[1].name}
                                </div>
                                <div className="text-xs text-500">{data.holidays[1].date}</div>
                            </div>

                            <span className="text-xs text-500">
                                In {data.holidays[1].daysLeft} days
                            </span>
                        </div>
                    </div>

                    <div className="flex align-items-center gap-2 text-sm text-600 mt-4">
                        <i className="pi pi-map-marker" />
                        <span>{data.holidays[0].location}</span>
                    </div>
                </div>
            </div>

            <div className="col-12 md:col-6">
                {/* Quick Actions */}
                <div className="card p-4 mb-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-bolt text-primary" />
                        <span className="font-medium text-900">Quick Actions</span>
                    </div>

                    <div className="flex flex-wrap gap-3 mb-3">
                        {/* My Profile */}
                        <div className="flex flex-1 align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-wallet text-green-500 text-xl" />
                            <span className="font-medium">Run Payroll</span>
                        </div>

                        {/* Apply Leave */}
                        <div className="flex flex-1 align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-user-plus text-blue-500 text-xl" />
                            <span className="font-medium">Onboard Employee</span>
                        </div>

                        {/* Regularize Attendance */}
                        <div className="flex flex-1 align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-megaphone text-orange-500 text-xl" />
                            <span className="font-medium">Publish Announcement</span>
                        </div>
                    </div>

                    <div className="flex flex-wrap gap-3">
                        {/* Employee Directory */}
                        <div className="flex flex-1 align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-users text-indigo-500 text-xl" />
                            <span className="font-medium">Employee Directory</span>
                        </div>

                        {/* Upload Policies */}
                        <div className="flex flex-1 align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-file text-teal-500 text-xl" />
                            <span className="font-medium">Upload Policies</span>
                        </div>

                        {/*Manage Holidays*/}
                        <div className="flex flex-1 align-items-center gap-2 px-4 py-3 border-round surface-hover cursor-pointer">
                            <i className="pi pi-calendar text-purple-500 text-xl" />
                            <span className="font-medium">Manage Holidays</span>
                        </div>
                    </div>
                </div>

                <div className="card p-4 mb-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-wallet text-primary" />
                        <span className="font-medium text-900">Payroll</span>
                    </div>

                    {/* Last Salary */}
                    <div className="mb-4">
                        <div className="text-sm text-500 mb-1">
                            Last Salary ({PAYROLL_DATA.lastSalary.month})
                        </div>

                        <div className="flex justify-content-between align-items-center">
                            <div className="text-3xl font-bold text-900">
                                {PAYROLL_DATA.lastSalary.netPay}
                            </div>
                            <Tag value={PAYROLL_DATA.lastSalary.status} severity="success" />
                        </div>

                        <div className="text-sm text-600 mt-2">
                            Credited on {PAYROLL_DATA.lastSalary.payDate}
                        </div>
                    </div>

                    {/* Next Salary */}
                    <div className="border-top-1 surface-border pt-3 mb-4">
                        <div className="text-sm text-500 mb-1">Next Salary Expected</div>
                        <div className="text-sm font-medium text-900">
                            {PAYROLL_DATA.nextSalary.expectedDate}
                        </div>
                    </div>

                    {/* Actions */}
                    <div className="flex gap-3">
                        <span className="text-sm text-primary cursor-pointer">Email Payslips</span>
                        <span className="text-sm text-primary cursor-pointer">
                            View Salary Details
                        </span>
                    </div>
                </div>

                <div className="card p-4 mb-3">
                    <div className="flex align-items-center justify-content-between mb-4">
                        <div className="flex align-items-center gap-2">
                            <i className="pi pi-megaphone text-primary" />
                            <span className="font-medium text-900">Announcements</span>
                        </div>
                        <span className="text-sm text-primary cursor-pointer">View all →</span>
                    </div>

                    <ul className="list-none p-0 m-0">
                        {ANNOUNCEMENTS.map((item) => (
                            <li
                                key={item.title}
                                className="pb-3 mb-3 border-bottom-1 surface-border"
                            >
                                <div className="flex justify-content-between align-items-start mb-1">
                                    <span className="font-medium text-900">{item.title}</span>
                                    <span className="text-xs text-500">{item.date}</span>
                                </div>

                                <div className="text-sm text-600 mb-1">{item.description}</div>

                                <span className="text-xs text-primary">{item.type}</span>
                            </li>
                        ))}
                    </ul>
                </div>
            </div>

            <div className="col-12 md:col-6">
                {/* Employees by Designation */}
                <div className="card p-4 mb-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-users text-primary" />
                        <span className="font-medium text-900">Employees By Designation</span>
                    </div>
                    {isDesignationLoading ? (
                        <Skeleton width="100%" height="354px" />
                    ) : (
                        <Chart
                            type="bar"
                            data={designationChartData}
                            options={designationChartOptions}
                            height="180"
                        />
                    )}
                </div>

                {/* Benefits & Compliance */}
                <div className="card p-4 mt-3">
                    <div className="flex align-items-center gap-2 mb-4">
                        <i className="pi pi-shield text-primary" />
                        <span className="font-medium text-900">Benefits & Compliance</span>
                    </div>

                    {/* Perks */}
                    <div className="flex mb-3 justify-content-between align-items-center">
                        <div className="text-sm font-medium text-900 mb-2">Perks & Benefits</div>
                        <ul className="flex list-none p-0 m-0 text-sm text-700 gap-4">
                            {COMPLIANCE_DATA.perks.map((perk) => (
                                <li key={perk} className="mb-1">
                                    {perk}
                                </li>
                            ))}
                        </ul>
                        <span className="text-sm text-primary cursor-pointer">View benefits →</span>
                    </div>

                    {/* APR */}
                    <div className="border-top-1 surface-border pt-3 mb-2">
                        <div className="flex justify-content-between gap-3 mb-2">
                            <div className="text-sm font-medium text-900 mb-1">
                                Annual Property Returns FY {COMPLIANCE_DATA.apr.financialYear}
                            </div>
                            <div className="text-sm text-700">
                                <span className="font-medium text-orange-600">
                                    {COMPLIANCE_DATA.apr.status}
                                </span>
                            </div>
                        </div>
                        <div className="text-xs text-500">Due by {COMPLIANCE_DATA.apr.dueDate}</div>
                    </div>

                    {/* Tax */}
                    <div className="border-top-1 surface-border pt-3">
                        <div className="flex justify-content-between gap-3 mb-2">
                            <div className="text-sm font-medium text-900 mb-1">
                                Tax Declaration FY {COMPLIANCE_DATA.tax.financialYear}
                            </div>
                            <div className="text-sm text-700">
                                <span className="font-medium text-green-600">
                                    {COMPLIANCE_DATA.tax.status}
                                </span>
                            </div>
                        </div>
                        <div className="text-xs text-500">
                            Last updated {COMPLIANCE_DATA.tax.lastUpdated}
                        </div>
                    </div>
                </div>
            </div>
        </div>
    );
};

export { AdminLanding };
