// src/pages/LeaveApprovals.jsx  —  PrimeReact + Sakai + PrimeFlex
import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';
import { Tag } from 'primereact/tag';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Dialog } from 'primereact/dialog';
import { InputTextarea } from 'primereact/inputtextarea';
import { Toast } from 'primereact/toast';
import { Avatar } from 'primereact/avatar';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toolbar } from 'primereact/toolbar';
import { SelectButton } from 'primereact/selectbutton';
import { Message } from 'primereact/message';
import { Divider } from 'primereact/divider';
import { MeterGroup } from 'primereact/metergroup';
import { Knob } from 'primereact/knob';
import { Skeleton } from 'primereact/skeleton';
import { InputText } from 'primereact/inputtext';
import { useNavigate } from 'react-router';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';
import SimpleSectionCard from '@shared/components/SimpleSectionCard';
import { useGetLeaveRequestHistoryForApprover } from '../../hooks/Leaves/useGetLeaveRequestHistoryForApprover';
import { useGetLeaveTypes } from '../../hooks/Leaves/useGetLeaveTypes';
import { useLeaveDecision } from '../../hooks/Leaves/useLeaveDecision';

// ─── Visual config ────────────────────────────────────────────────────────────
const LEAVE_TYPE_VISUAL = {
    sick: { icon: 'pi pi-exclamation-triangle', cssKey: 'sick' },
    vacation: { icon: 'pi pi-send', cssKey: 'vacation' },
    casual: { icon: 'pi pi-calendar', cssKey: 'casual' },
    maternity: { icon: 'pi pi-users', cssKey: 'maternity' },
    paternity: { icon: 'pi pi-users', cssKey: 'paternity' },
    unpaid: { icon: 'pi pi-minus-circle', cssKey: 'unpaid' },
    bereavement: { icon: 'pi pi-heart', cssKey: 'bereavement' },
    annual: { icon: 'pi pi-sun', cssKey: 'vacation' },
    optional: { icon: 'pi pi-star', cssKey: 'casual' },
    loss: { icon: 'pi pi-minus-circle', cssKey: 'unpaid' },
    default: { icon: 'pi pi-bookmark', cssKey: 'default' },
};

const resolveVisual = (nameOrId) => {
    const key = (nameOrId || '').toLowerCase().replace(/[^a-z]/g, '');
    if (LEAVE_TYPE_VISUAL[key]) return LEAVE_TYPE_VISUAL[key];
    const matched = Object.keys(LEAVE_TYPE_VISUAL).find((k) => key.includes(k));
    return LEAVE_TYPE_VISUAL[matched] || LEAVE_TYPE_VISUAL.default;
};

// ─── Helpers ──────────────────────────────────────────────────────────────────
const normalizeStatus = (apiStatus) => {
    switch ((apiStatus || '').toUpperCase()) {
        case 'SUBMITTED':
        case 'PENDING':
            return 'Pending';
        case 'APPROVED':
            return 'Approved';
        case 'REJECTED':
            return 'Rejected';
        case 'CANCELLED':
            return 'Cancelled';
        default:
            return apiStatus || 'Unknown';
    }
};

const getStatusSeverity = (status) => {
    switch (status?.toLowerCase()) {
        case 'approved':
            return 'success';
        case 'rejected':
            return 'danger';
        case 'pending':
            return 'warning';
        case 'cancelled':
            return 'secondary';
        default:
            return 'info';
    }
};

const getInitials = (name) => {
    const parts = (name || '').trim().split(/\s+/);
    if (parts.length >= 2) return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    return (name || '??').substring(0, 2).toUpperCase();
};

const resolveLeaveTypeKey = (name) => {
    const key = (name || '').toLowerCase().replace(/[^a-z]/g, '');
    const known = Object.keys(LEAVE_TYPE_VISUAL);
    return known.find((k) => key.includes(k)) || 'default';
};

const AVATAR_COLORS = ['indigo', 'teal', 'amber', 'purple', 'pink', 'blue', 'orange', 'cyan'];

const mapLeaveRequest = (apiReq, index) => ({
    id: apiReq.id,
    employeeId: apiReq.employeeId,
    employeeName: apiReq.employeeName || 'Employee',
    initials: getInitials(apiReq.employeeName || 'EMP'),
    avatarKey: AVATAR_COLORS[index % AVATAR_COLORS.length],
    department: apiReq.department || '—',
    leaveType: apiReq.leaveTypeName,
    leaveTypeId: resolveLeaveTypeKey(apiReq.leaveTypeName),
    dateFrom: apiReq.dateFrom,
    dateTo: apiReq.dateTo,
    days: Number(apiReq.days),
    reason: apiReq.reason || '—',
    submittedOn: apiReq.submittedOn
        ? new Date(apiReq.submittedOn).toLocaleDateString('en-GB', {
              day: '2-digit',
              month: 'short',
              year: 'numeric',
          })
        : '—',
    status: normalizeStatus(apiReq.status),
    attachment: false,
    isDirectReport: true,
    workflowInstanceId: apiReq.workflowInstanceId,
});

// ─── Review Dialog ────────────────────────────────────────────────────────────
const ReviewDialog = ({ visible, onHide, request, onDecision, isSubmitting }) => {
    const [comment, setComment] = useState('');
    if (!request) return null;

    const visual = resolveVisual(request.leaveTypeId || request.leaveType);
    const isPending = request.status === 'Pending';

    const handleDecision = (action) => {
        onDecision({
            requestId: request.id,
            action,
            comment,
            workflowInstanceId: request.workflowInstanceId,
        });
        setComment('');
    };
    const handleHide = () => {
        if (isSubmitting) return; // block dismiss while in-flight
        setComment('');
        onHide();
    };

    const footer = (
        <div className="flex justify-content-end gap-2">
            {isPending ? (
                <>
                    <Button
                        label="Reject"
                        icon="pi pi-times"
                        className="p-button-danger p-button-outlined"
                        onClick={() => handleDecision('REJECT')}
                        disabled={isSubmitting}
                    />
                    <Button
                        label="Approve"
                        icon="pi pi-check"
                        className="p-button-success"
                        onClick={() => handleDecision('APPROVE')}
                        loading={isSubmitting}
                    />
                </>
            ) : (
                <Button
                    label="Close"
                    icon="pi pi-times"
                    className="p-button-text"
                    onClick={handleHide}
                />
            )}
        </div>
    );

    return (
        <Dialog
            header={
                <span>
                    <i className="pi pi-file-edit mr-2" />
                    Leave Request
                </span>
            }
            visible={visible}
            onHide={handleHide}
            footer={footer}
            style={{ width: '520px' }}
            breakpoints={{ '768px': '95vw' }}
            modal
            draggable={false}
            closable={!isSubmitting}
        >
            <div className="pt-1">
                {/* Employee strip */}
                <div className="flex align-items-center gap-3">
                    <Avatar
                        label={request.initials}
                        className={`avatar--${request.avatarKey}`}
                        shape="circle"
                        size="large"
                    />
                    <div>
                        <div className="font-semibold text-lg">{request.employeeName}</div>
                        <div className="text-color-secondary text-sm">{request.department}</div>
                    </div>
                    <Tag
                        value={request.status}
                        severity={getStatusSeverity(request.status)}
                        className="ml-auto"
                    />
                </div>

                <Divider className="my-3" />

                {/* Detail rows */}
                <div className="flex flex-column gap-2">
                    {[
                        {
                            label: 'Leave Type',
                            value: (
                                <span
                                    className={`leave-type-badge leave-type-badge--${visual.cssKey}`}
                                >
                                    <i className={visual.icon} />
                                    {request.leaveType}
                                </span>
                            ),
                        },
                        {
                            label: 'Duration',
                            value: (
                                <span className="text-sm">
                                    {request.dateFrom === request.dateTo
                                        ? request.dateFrom
                                        : `${request.dateFrom} – ${request.dateTo}`}
                                    <Tag
                                        value={`${request.days} day${request.days > 1 ? 's' : ''}`}
                                        severity="info"
                                        className="ml-2"
                                    />
                                </span>
                            ),
                        },
                        {
                            label: 'Submitted On',
                            value: <span className="text-sm">{request.submittedOn}</span>,
                        },
                    ].map(({ label, value }) => (
                        <div key={label} className="flex align-items-center gap-4">
                            <span
                                className="detail-label text-xs font-medium text-color-secondary uppercase flex-shrink-0"
                                style={{ minWidth: '100px' }}
                            >
                                {label}
                            </span>
                            {value}
                        </div>
                    ))}
                </div>

                {/* Reason */}
                <div className="reason-block p-3 mt-3">
                    <div className="detail-label text-xs font-medium text-color-secondary uppercase mb-1">
                        Reason
                    </div>
                    <div className="text-sm line-height-3">{request.reason}</div>
                </div>

                {request.attachment && (
                    <div className="flex align-items-center mt-3">
                        <i className="pi pi-paperclip mr-2 text-color-secondary" />
                        <Button
                            label="View Attachment"
                            className="p-button-text p-button-sm"
                            icon="pi pi-download"
                        />
                    </div>
                )}

                {!isPending && (
                    <Message
                        severity={request.status === 'Approved' ? 'success' : 'warn'}
                        text={`This request has already been ${request.status.toLowerCase()}.`}
                        className="w-full mt-3"
                    />
                )}

                {isPending && (
                    <>
                        <Divider className="my-3" />
                        <div className="field">
                            <label className="block text-sm font-medium mb-2">
                                Comment <span className="text-color-secondary">(optional)</span>
                            </label>
                            <InputTextarea
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                rows={3}
                                placeholder="Add a note for the employee…"
                                className="w-full"
                                maxLength={400}
                                disabled={isSubmitting}
                            />
                            <div className="flex justify-content-end mt-1">
                                <small className="text-color-secondary">{comment.length}/400</small>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </Dialog>
    );
};

// ─── Team Requests Tab ────────────────────────────────────────────────────────
const TeamRequestsTab = ({ requests, leaveTypeNames, onDecision, isDeciding }) => {
    const [statusFilter, setStatusFilter] = useState('Pending');
    const [typeFilter, setTypeFilter] = useState(null);
    const [globalFilter, setGlobalFilter] = useState('');
    const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
    const [selectedRequest, setSelectedRequest] = useState(null);

    const pendingCount = requests.filter((r) => r.status === 'Pending').length;
    const typeOptions = useMemo(() => ['All', ...leaveTypeNames], [leaveTypeNames]);

    const statusOptions = [
        { label: `All (${requests.length})`, value: 'All' },
        {
            label: `Pending (${requests.filter((r) => r.status === 'Pending').length})`,
            value: 'Pending',
        },
        {
            label: `Approved (${requests.filter((r) => r.status === 'Approved').length})`,
            value: 'Approved',
        },
        {
            label: `Rejected (${requests.filter((r) => r.status === 'Rejected').length})`,
            value: 'Rejected',
        },
    ];

    const filtered = useMemo(
        () =>
            requests.filter((r) => {
                if (statusFilter && statusFilter !== 'All' && r.status !== statusFilter)
                    return false;
                if (typeFilter && typeFilter !== 'All' && r.leaveType !== typeFilter) return false;
                if (globalFilter) {
                    const q = globalFilter.toLowerCase();
                    return (
                        r.employeeName.toLowerCase().includes(q) ||
                        r.department.toLowerCase().includes(q) ||
                        r.leaveType.toLowerCase().includes(q)
                    );
                }
                return true;
            }),
        [requests, statusFilter, typeFilter, globalFilter],
    );

    // ── Handlers ──────────────────────────────────────────────────────────────
    const openDetail = (row) => {
        setSelectedRequest(requests.find((r) => r.id === row.id) || row);
        setReviewDialogOpen(true);
    };

    const handleQuickAction = (row, action) => {
        const isApprove = action === 'APPROVE';
        confirmDialog({
            message: `${isApprove ? 'Approve' : 'Reject'} ${row.employeeName}'s ${row.leaveType} request (${row.days} day${row.days > 1 ? 's' : ''})?`,
            header: `Confirm ${isApprove ? 'Approval' : 'Rejection'}`,
            icon: isApprove ? 'pi pi-check-circle' : 'pi pi-times-circle',
            acceptClassName: isApprove ? 'p-button-success' : 'p-button-danger',
            rejectClassName: 'p-button-text',
            accept: () =>
                onDecision({
                    requestId: row.id,
                    action,
                    comment: '',
                    workflowInstanceId: row.workflowInstanceId,
                }),
        });
    };

    // ── Column templates ──────────────────────────────────────────────────────
    const employeeTemplate = (row) => (
        <div className="flex align-items-center gap-2">
            <Avatar
                label={row.initials}
                className={`avatar--${row.avatarKey}`}
                shape="circle"
                style={{ width: '2rem', height: '2rem', fontSize: '0.7rem' }}
            />
            <div>
                <div className="font-medium text-sm">{row.employeeName}</div>
                <div className="text-color-secondary text-xs">{row.department}</div>
            </div>
        </div>
    );

    const leaveTypeTemplate = (row) => {
        const v = resolveVisual(row.leaveTypeId || row.leaveType);
        return (
            <span className={`leave-type-badge leave-type-badge--${v.cssKey}`}>
                <i className={v.icon} />
                {row.leaveType}
            </span>
        );
    };

    const datesTemplate = (row) => (
        <div className="flex align-items-center flex-wrap gap-1 text-sm">
            <span>
                {row.dateFrom === row.dateTo ? row.dateFrom : `${row.dateFrom} – ${row.dateTo}`}
            </span>
            <Tag
                value={`${row.days} day${row.days > 1 ? 's' : ''}`}
                severity="info"
                className="text-xs"
            />
        </div>
    );

    const actionsTemplate = (row) => (
        <div className="flex align-items-center gap-1">
            {row.status === 'Pending' && (
                <>
                    <Button
                        icon="pi pi-check"
                        className="p-button-rounded p-button-success p-button-text p-button-sm"
                        tooltip="Quick Approve"
                        tooltipOptions={{ position: 'top' }}
                        onClick={() => handleQuickAction(row, 'APPROVE')}
                        disabled={isDeciding}
                    />
                    <Button
                        icon="pi pi-times"
                        className="p-button-rounded p-button-danger p-button-text p-button-sm"
                        tooltip="Quick Reject"
                        tooltipOptions={{ position: 'top' }}
                        onClick={() => handleQuickAction(row, 'REJECT')}
                        disabled={isDeciding}
                    />
                </>
            )}
            <Button
                icon="pi pi-eye"
                className="p-button-rounded p-button-secondary p-button-text p-button-sm"
                tooltip="View Details"
                tooltipOptions={{ position: 'top' }}
                onClick={() => openDetail(row)}
            />
        </div>
    );

    return (
        <div>
            <ReviewDialog
                visible={reviewDialogOpen}
                onHide={() => {
                    setReviewDialogOpen(false);
                    setSelectedRequest(null);
                }}
                request={selectedRequest}
                onDecision={(params) => {
                    onDecision(params);
                    setReviewDialogOpen(false);
                    setSelectedRequest(null);
                }}
                isSubmitting={isDeciding}
            />

            <Toolbar
                start={
                    <div className="flex align-items-center gap-3">
                        <span className="font-semibold text-xl">Team Leave Requests</span>
                        {pendingCount > 0 && (
                            <Tag
                                value={`${pendingCount} pending`}
                                severity="warning"
                                className="text-xs"
                            />
                        )}
                    </div>
                }
                end={
                    <div className="flex gap-2 align-items-center">
                        <InputText
                            value={globalFilter}
                            onChange={(e) => setGlobalFilter(e.target.value)}
                            placeholder="Search employee…"
                            className="p-inputtext-sm w-12rem"
                        />
                        <Dropdown
                            options={typeOptions}
                            value={typeFilter}
                            onChange={(e) => setTypeFilter(e.value)}
                            placeholder="Leave type"
                            className="w-10rem"
                            showClear
                        />
                    </div>
                }
                className="border-none px-0 mb-3 surface-transparent"
            />

            <div className="mb-3">
                <SelectButton
                    options={statusOptions}
                    value={statusFilter}
                    onChange={(e) => e.value && setStatusFilter(e.value)}
                    pt={{ button: { className: 'text-xs px-3 py-2' } }}
                />
            </div>

            <div className="border-1 border-solid surface-border border-round">
                <DataTable
                    value={filtered}
                    paginator
                    rows={10}
                    rowsPerPageOptions={[5, 10, 25]}
                    emptyMessage={
                        <div className="flex flex-column align-items-center py-5 text-color-secondary">
                            <i className="pi pi-inbox text-4xl mb-2" />
                            <div>No requests match the selected filters</div>
                        </div>
                    }
                    rowClassName={(row) => (row.status === 'Pending' ? 'row-pending' : '')}
                >
                    <Column
                        header="Employee"
                        body={employeeTemplate}
                        style={{ minWidth: '180px' }}
                    />
                    <Column
                        header="Leave Type"
                        body={leaveTypeTemplate}
                        style={{ minWidth: '150px' }}
                    />
                    <Column header="Dates" body={datesTemplate} style={{ minWidth: '200px' }} />
                    <Column field="submittedOn" header="Submitted" style={{ minWidth: '120px' }} />
                    <Column
                        header="Status"
                        body={(r) => (
                            <Tag value={r.status} severity={getStatusSeverity(r.status)} />
                        )}
                        style={{ width: '110px' }}
                    />
                    <Column header="Actions" body={actionsTemplate} style={{ width: '130px' }} />
                </DataTable>
            </div>
        </div>
    );
};

// ─── Team Analytics Tab ───────────────────────────────────────────────────────
const TeamAnalyticsTab = ({ requests, leaveTypeNames }) => {
    const total = requests.length;
    const approved = requests.filter((r) => r.status === 'Approved').length;
    const rejected = requests.filter((r) => r.status === 'Rejected').length;
    const pending = requests.filter((r) => r.status === 'Pending').length;
    const approvalRate =
        approved + rejected > 0 ? Math.round((approved / (approved + rejected)) * 100) : 0;

    const meterValues = [
        {
            label: 'Approved',
            value: total > 0 ? Math.round((approved / total) * 100) : 0,
            color: 'var(--green-500)',
        },
        {
            label: 'Pending',
            value: total > 0 ? Math.round((pending / total) * 100) : 0,
            color: 'var(--yellow-500)',
        },
        {
            label: 'Rejected',
            value: total > 0 ? Math.round((rejected / total) * 100) : 0,
            color: 'var(--red-500)',
        },
    ];

    const byType = useMemo(
        () =>
            leaveTypeNames
                .map((lt) => ({
                    leaveType: lt,
                    leaveTypeId: resolveLeaveTypeKey(lt),
                    total: requests.filter((r) => r.leaveType === lt).length,
                    approved: requests.filter((r) => r.leaveType === lt && r.status === 'Approved')
                        .length,
                    pending: requests.filter((r) => r.leaveType === lt && r.status === 'Pending')
                        .length,
                    rejected: requests.filter((r) => r.leaveType === lt && r.status === 'Rejected')
                        .length,
                }))
                .sort((a, b) => b.total - a.total),
        [leaveTypeNames, requests],
    );

    const statCards = [
        { label: 'Total Requests', value: total, icon: 'pi pi-inbox', mod: 'info' },
        { label: 'Approved', value: approved, icon: 'pi pi-check-circle', mod: 'success' },
        { label: 'Pending Review', value: pending, icon: 'pi pi-clock', mod: 'warning' },
        { label: 'Rejected', value: rejected, icon: 'pi pi-times-circle', mod: 'danger' },
    ];

    const leaveTypeColTemplate = (row) => {
        const v = resolveVisual(row.leaveTypeId || row.leaveType);
        return (
            <span className={`leave-type-badge leave-type-badge--${v.cssKey}`}>
                <i className={v.icon} />
                {row.leaveType}
            </span>
        );
    };

    const countTemplate = (field, severity) => (row) =>
        row[field] > 0 ? (
            <Tag value={row[field]} severity={severity} />
        ) : (
            <span className="text-color-secondary">—</span>
        );

    return (
        <div>
            <div className="flex align-items-baseline gap-2 mb-4">
                <span className="font-semibold text-xl">Team Overview</span>
                <span className="text-color-secondary text-sm">
                    Year-to-date · {total} total requests
                </span>
            </div>

            <div className="grid mb-4">
                {statCards.map((s) => (
                    <div key={s.label} className="col-12 sm:col-6 lg:col-3">
                        <div
                            className={`stat-tile stat-tile--${s.mod} flex align-items-center gap-3 p-3 border-round-xl border-1 h-full`}
                        >
                            <div
                                className="flex align-items-center justify-content-center border-circle flex-shrink-0"
                                style={{ width: '2.5rem', height: '2.5rem' }}
                            >
                                <i className={`${s.icon} text-lg stat-tile__icon`} />
                            </div>
                            <div>
                                <div className="text-xs text-color-secondary mb-1 stat-tile__label">
                                    {s.label}
                                </div>
                                <div className="text-4xl font-bold line-height-1 stat-tile__value">
                                    {s.value}
                                </div>
                            </div>
                        </div>
                    </div>
                ))}
            </div>

            <div className="grid mb-4">
                <div className="col-12 md:col-9">
                    <div className="surface-card border-1 surface-border border-round-xl p-4 h-full">
                        <div className="font-semibold mb-3">Status Distribution</div>
                        <MeterGroup values={meterValues} />
                    </div>
                </div>
                <div className="col-12 md:col-3">
                    <div className="surface-card border-1 surface-border border-round-xl p-4 flex flex-column align-items-center justify-content-center h-full">
                        <div className="font-semibold mb-3">Approval Rate</div>
                        <Knob
                            value={approvalRate}
                            valueTemplate="{value}%"
                            size={120}
                            strokeWidth={10}
                            valueColor="var(--green-500)"
                            rangeColor="var(--surface-200)"
                            readOnly
                        />
                        <div className="text-color-secondary text-sm mt-2 text-center">
                            of decided requests
                        </div>
                    </div>
                </div>
            </div>

            <div className="surface-card border-1 surface-border border-round-xl p-4">
                <div className="font-semibold mb-3">Breakdown by Leave Type</div>
                <DataTable value={byType} size="small">
                    <Column header="Leave Type" body={leaveTypeColTemplate} />
                    <Column
                        field="total"
                        header="Total"
                        body={countTemplate('total', 'info')}
                        style={{ width: '90px', textAlign: 'center' }}
                    />
                    <Column
                        field="approved"
                        header="Approved"
                        body={countTemplate('approved', 'success')}
                        style={{ width: '100px', textAlign: 'center' }}
                    />
                    <Column
                        field="pending"
                        header="Pending"
                        body={countTemplate('pending', 'warning')}
                        style={{ width: '100px', textAlign: 'center' }}
                    />
                    <Column
                        field="rejected"
                        header="Rejected"
                        body={countTemplate('rejected', 'danger')}
                        style={{ width: '100px', textAlign: 'center' }}
                    />
                </DataTable>
            </div>
        </div>
    );
};

// ─── Main Page ────────────────────────────────────────────────────────────────
const LeaveApprovals = () => {
    const navigate = useNavigate();
    const toast = useRef(null);

    const [activeTab, setActiveTab] = useState(0);
    const [requestOverrides, setRequestOverrides] = useState({});

    // ── Hooks ──────────────────────────────────────────────────────────────────
    const {
        fetchApproverLeaveHistory,
        data: approverHistoryData,
        isPending: historyLoading,
    } = useGetLeaveRequestHistoryForApprover();

    const { data: leaveTypesData, isLoading: leaveTypesLoading } = useGetLeaveTypes();

    const { decideLeave, isPending: isDeciding } = useLeaveDecision();

    useEffect(() => {
        fetchApproverLeaveHistory().catch((err) =>
            console.error('Error fetching approver leave history:', err),
        );
    }, []);

    // ── Derived data ───────────────────────────────────────────────────────────
    const leaveTypeNames = useMemo(
        () => (leaveTypesData?.content ?? []).map((t) => t.leaveTypeName),
        [leaveTypesData],
    );

    const rawRequests = useMemo(() => {
        const raw = approverHistoryData?.content ?? [];
        return raw.map((r, i) => mapLeaveRequest(r, i));
    }, [approverHistoryData]);

    const teamRequests = useMemo(
        () =>
            rawRequests.map((r) =>
                requestOverrides[r.id] ? { ...r, status: requestOverrides[r.id] } : r,
            ),
        [rawRequests, requestOverrides],
    );

    const pendingCount = teamRequests.filter((r) => r.status === 'Pending').length;

    // ── Handlers ───────────────────────────────────────────────────────────────
    const handleDecision = async ({ requestId, action, comment, workflowInstanceId }) => {
        const displayStatus = action === 'APPROVE' ? 'Approved' : 'Rejected';
        try {
            await decideLeave({ wfInstanceId: workflowInstanceId, action, comment });

            // Optimistic update — use friendly display status in the UI
            setRequestOverrides((prev) => ({ ...prev, [requestId]: displayStatus }));

            toast.current.show({
                severity: action === 'APPROVE' ? 'success' : 'warn',
                summary: `Request ${displayStatus}`,
                detail: `Leave request has been ${displayStatus.toLowerCase()} and synced.${comment ? ` Note: "${comment}"` : ''}`,
                life: 4000,
            });
        } catch (err) {
            toast.current.show({
                severity: 'error',
                summary: 'Action Failed',
                detail: err?.message || 'Could not process the leave decision. Please try again.',
                life: 5000,
            });
        }
    };

    // ── Nav ────────────────────────────────────────────────────────────────────
    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        {
            label: 'Time & Attendance',
            command: () => navigate('/web/landing/hrms/time-n-attendance'),
        },
        { label: 'Leave Approvals' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/web/landing') };

    const tabs = [
        {
            label: 'Pending Approval',
            icon: 'pi pi-clock',
            active: activeTab === 0,
            onClick: () => setActiveTab(0),
        },
        {
            label: 'Team Overview',
            icon: 'pi pi-chart-bar',
            active: activeTab === 1,
            onClick: () => setActiveTab(1),
        },
    ];

    const isLoading = historyLoading || leaveTypesLoading;

    // ── Render ─────────────────────────────────────────────────────────────────
    return (
        <div className="p-0 bg-white">
            <Toast ref={toast} />
            <ConfirmDialog />

            <BreadCrumb model={breadcrumbItems} home={home} className="mb-3" />

            <SimpleSectionCard>
                <div className="flex align-items-start justify-content-between gap-3">
                    <div>
                        <h2 className="text-2xl font-bold m-0 mb-1">Leave Approvals</h2>
                        <p className="m-0 text-color-secondary text-sm">
                            Review and action requests from your direct and indirect reports
                        </p>
                    </div>
                    <Button
                        label="Refresh"
                        icon="pi pi-refresh"
                        className="p-button-outlined p-button-sm flex-shrink-0"
                        onClick={() => fetchApproverLeaveHistory().catch(console.error)}
                        loading={historyLoading}
                    />
                </div>

                <Divider className="my-3" />

                {pendingCount > 0 && (
                    <Message
                        severity="warn"
                        text={`${pendingCount} leave request${pendingCount > 1 ? 's' : ''} awaiting your review`}
                        className="pending-message border-round-xl mb-4 w-full"
                    />
                )}

                {isLoading ? (
                    <div className="flex flex-column gap-3">
                        <Skeleton height="60px" />
                        <Skeleton height="400px" />
                    </div>
                ) : (
                    <TabbedSectionCard tabs={tabs} whiteBack={true}>
                        {activeTab === 0 && (
                            <TeamRequestsTab
                                requests={teamRequests}
                                leaveTypeNames={leaveTypeNames}
                                onDecision={handleDecision}
                                isDeciding={isDeciding}
                            />
                        )}
                        {activeTab === 1 && (
                            <TeamAnalyticsTab
                                requests={teamRequests}
                                leaveTypeNames={leaveTypeNames}
                            />
                        )}
                    </TabbedSectionCard>
                )}
            </SimpleSectionCard>
        </div>
    );
};

export default LeaveApprovals;
