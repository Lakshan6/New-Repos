// src/pages/Leaves.jsx
// PrimeReact + Sakai + PrimeFlex

import React, { useState, useRef, useEffect, useMemo } from 'react';
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dropdown } from 'primereact/dropdown';
import { Tag } from 'primereact/tag';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Dialog } from 'primereact/dialog';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { FileUpload } from 'primereact/fileupload';
import { Toast } from 'primereact/toast';
import { Avatar } from 'primereact/avatar';
import { ProgressBar } from 'primereact/progressbar';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { Toolbar } from 'primereact/toolbar';
import { SelectButton } from 'primereact/selectbutton';
import { Message } from 'primereact/message';
import { Divider } from 'primereact/divider';
import { MeterGroup } from 'primereact/metergroup';
import { Knob } from 'primereact/knob';
import { Skeleton } from 'primereact/skeleton';
import { useNavigate } from 'react-router';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';
import SimpleSectionCard from '@shared/components/SimpleSectionCard';
import { useGetLeaveTypes } from '../../hooks/Leaves/useGetLeaveTypes';
import { useGetLeaveBalance } from '../../hooks/Leaves/useGetLeaveBalance';
import { useSubmitLeaveRequest } from '../../hooks/Leaves/useSubmitLeaveRequest';
import { useGetLeaveRequestHistoryForEmployee } from '../../hooks/Leaves/useGetLeaveRequestHistoryForEmployee';
import { useGetLeaveRequestHistoryForApprover } from '../../hooks/Leaves/useGetLeaveRequestHistoryForApprover';
import '../../styles/Leaves/Leaves.scss';

// ─── Visual config — icon + cssKey only (colors live entirely in SCSS) ────────

const LEAVE_TYPE_VISUAL = {
    sick: { icon: 'pi pi-exclamation-triangle', cssKey: 'sick' },
    vacation: { icon: 'pi pi-send', cssKey: 'vacation' },
    casual: { icon: 'pi pi-calendar', cssKey: 'casual' },
    maternity: { icon: 'pi pi-users', cssKey: 'maternity' },
    paternity: { icon: 'pi pi-users', cssKey: 'paternity' },
    unpaid: { icon: 'pi pi-minus-circle', cssKey: 'unpaid' },
    bereavement: { icon: 'pi pi-heart', cssKey: 'bereavement' },
    annual: { icon: 'pi pi-sun', cssKey: 'vacation' },
    optional: { icon: 'pi pi-star', cssKey: 'casual' },
    default: { icon: 'pi pi-bookmark', cssKey: 'default' },
};

const resolveVisual = (nameOrId) => {
    const key = (nameOrId || '').toLowerCase().replace(/[^a-z]/g, '');
    if (LEAVE_TYPE_VISUAL[key]) return LEAVE_TYPE_VISUAL[key];
    const matched = Object.keys(LEAVE_TYPE_VISUAL).find((k) => key.includes(k));
    return LEAVE_TYPE_VISUAL[matched] || LEAVE_TYPE_VISUAL.default;
};

// ─── Mock data (no hook available) ───────────────────────────────────────────
const upcomingLeaves = [
    { type: 'Vacation', dates: 'May 10–May 14', days: 5, status: 'Approved' },
    { type: 'Casual', dates: 'May 22', days: 1, status: 'Pending' },
];

const companyHolidays = [
    { name: 'Labour Day', date: 'May 1, 2025', day: 'Thursday', type: 'National' },
    { name: 'Eid ul-Adha', date: 'Jun 7–9, 2025', day: 'Sat–Mon', type: 'Religious' },
    { name: 'Independence Day', date: 'Aug 14, 2025', day: 'Thursday', type: 'National' },
    { name: 'Iqbal Day', date: 'Nov 9, 2025', day: 'Sunday', type: 'National' },
    { name: 'Christmas Day', date: 'Dec 25, 2025', day: 'Thursday', type: 'Religious' },
    { name: "Quaid's Birthday", date: 'Dec 25, 2025', day: 'Thursday', type: 'National' },
];

// ─── Data transform helpers ───────────────────────────────────────────────────

const mapLeaveType = (apiType) => ({
    id: apiType.id,
    label: apiType.leaveTypeName,
    carryForward: apiType.isCarryForward ? (apiType.encashmentThresholdDays ?? 0) : 0,
    encashable: !!apiType.encashmentThresholdDays,
    requiresAttachment: apiType.applicableAfter > 0,
    maxDays: apiType.maxLeavesAllowed,
    isEarned: apiType.isEarnedLeave,
    isOptional: apiType.isOptionalLeave,
    tenantId: apiType.tenantId,
});

const mergeLeaveData = (leaveTypes, balances) =>
    leaveTypes.map((type) => {
        const balance = balances.find((b) => b.leaveTypeId === type.id);
        return {
            ...type,
            used: balance ? Number(balance.totalDebited) : null,
            total: balance ? Number(balance.totalCredited) : null,
            remaining: balance ? Number(balance.remaining) : null,
            isEntitled: !!balance,
        };
    });

const normalizeStatus = (apiStatus) => {
    switch ((apiStatus || '').toUpperCase()) {
        case 'SUBMITTED':
        case 'PENDING':
            return 'Pending';
        case 'APPROVED':
            return 'Approved';
        case 'REJECTED':
            return 'Rejected';
        case 'CANCELLED':
            return 'Cancelled';
        default:
            return apiStatus || 'Unknown';
    }
};

const getInitials = (name) => {
    const parts = (name || '').trim().split(/\s+/);
    if (parts.length >= 2) return `${parts[0][0]}${parts[parts.length - 1][0]}`.toUpperCase();
    return (name || '??').substring(0, 2).toUpperCase();
};

const resolveLeaveTypeKey = (name) => {
    const key = (name || '').toLowerCase().replace(/[^a-z]/g, '');
    const known = Object.keys(LEAVE_TYPE_VISUAL);
    return known.find((k) => key.includes(k)) || 'default';
};

const mapLeaveRequest = (apiReq, index) => {
    const avatarKeys = ['indigo', 'teal', 'amber', 'purple', 'pink', 'blue'];
    return {
        id: apiReq.id,
        // Employee history fields
        type: apiReq.leaveTypeName,
        dates:
            apiReq.dateFrom === apiReq.dateTo
                ? apiReq.dateFrom
                : `${apiReq.dateFrom}–${apiReq.dateTo}`,
        reason: apiReq.reason || '—',
        submitted: apiReq.submittedOn
            ? new Date(apiReq.submittedOn).toLocaleDateString('en-GB', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
              })
            : '—',
        status: normalizeStatus(apiReq.status),
        assignedTo: apiReq.approverId ? 'Assigned' : 'N/A',
        // Team/manager review fields
        employeeId: apiReq.employeeId,
        employeeName: apiReq.employeeName || 'Employee',
        initials: getInitials(apiReq.employeeName || 'EMP'),
        avatarKey: avatarKeys[index % avatarKeys.length],
        department: apiReq.department || '—',
        leaveType: apiReq.leaveTypeName,
        leaveTypeId: resolveLeaveTypeKey(apiReq.leaveTypeName),
        dateFrom: apiReq.dateFrom,
        dateTo: apiReq.dateTo,
        days: Number(apiReq.days),
        submittedOn: apiReq.submittedOn
            ? new Date(apiReq.submittedOn).toLocaleDateString('en-GB', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
              })
            : '—',
        coveragePerson: null,
        attachment: false,
        isDirectReport: true,
        workflowInstanceId: apiReq.workflowInstanceId,
    };
};

// ─── Status helpers ───────────────────────────────────────────────────────────

const getStatusSeverity = (status) => {
    switch (status?.toLowerCase()) {
        case 'approved':
            return 'success';
        case 'rejected':
            return 'danger';
        case 'pending':
            return 'warning';
        default:
            return 'info';
    }
};

// ─── Leave Balance Card ───────────────────────────────────────────────────────

const LeaveBalanceCard = ({ entry }) => {
    const visual = resolveVisual(entry.label);
    const remaining = entry.isEntitled ? entry.remaining : null;
    const pct =
        entry.isEntitled && entry.total > 0 ? Math.round((entry.used / entry.total) * 100) : 0;
    const isExhausted = entry.isEntitled && remaining === 0;

    return (
        <div
            className={`lbc lbc--${visual.cssKey}${!entry.isEntitled ? ' lbc--disabled' : ''}${isExhausted ? ' lbc--exhausted' : ''}`}
        >
            <div className="flex justify-content-between align-items-start mb-2">
                <span className="font-semibold text-sm text-800">{entry.label}</span>
                <i className={`${visual.icon} lbc__icon text-xl`} />
            </div>

            {entry.isEntitled ? (
                <>
                    <div className="lbc__days font-bold mb-1">
                        {remaining}
                        <span className="lbc__days-label text-500 font-normal ml-1">
                            {' '}
                            days left
                        </span>
                    </div>
                    <div className="text-500 text-xs mb-2">
                        {entry.used} used of {entry.total} total
                    </div>
                    <div className="lbc__progress-wrap mb-3">
                        <ProgressBar
                            value={pct}
                            showValue={false}
                            pt={{
                                root: { className: 'lbc__progress-root' },
                                value: { className: 'lbc__progress-value' },
                            }}
                        />
                    </div>
                    <div className="flex gap-1 flex-wrap">
                        {entry.carryForward > 0 && (
                            <span className="lbc__badge lbc__badge--carry">
                                <i className="pi pi-arrow-right-arrow-left mr-1" />
                                {entry.carryForward}d carry-forward
                            </span>
                        )}
                        {entry.encashable && (
                            <span className="lbc__badge lbc__badge--encash">
                                <i className="pi pi-wallet mr-1" />
                                Encashable
                            </span>
                        )}
                        {isExhausted && (
                            <span className="lbc__badge lbc__badge--exhausted">
                                <i className="pi pi-exclamation-circle mr-1" />
                                Balance exhausted
                            </span>
                        )}
                        {!entry.carryForward && !entry.encashable && !isExhausted && (
                            <span className="text-400 text-xs">No carry-forward</span>
                        )}
                    </div>
                </>
            ) : (
                <div className="flex align-items-center gap-2 mt-2 text-400 text-sm">
                    <i className="pi pi-lock" />
                    <span>Not entitled</span>
                </div>
            )}
        </div>
    );
};

const LeaveBalanceSkeleton = () => (
    <div className="grid mb-0">
        {[1, 2, 3, 4].map((i) => (
            <div key={i} className="col-12 sm:col-6 lg:col-3">
                <div className="lbc lbc--default">
                    <Skeleton height="120px" />
                </div>
            </div>
        ))}
    </div>
);

// ─── Apply Leave Dialog ───────────────────────────────────────────────────────

const ApplyLeaveDialog = ({ visible, onHide, onSubmit, mergedLeaveData, isSubmitting }) => {
    const initialForm = {
        leaveType: null,
        dateRange: null,
        reason: '',
        halfDay: false,
        emergency: false,
    };
    const [form, setForm] = useState(initialForm);
    const [errors, setErrors] = useState({});
    const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

    const calcDays = () => {
        if (!form.dateRange?.[0]) return 0;
        const diff =
            Math.ceil(((form.dateRange[1] || form.dateRange[0]) - form.dateRange[0]) / 86400000) +
            1;
        return form.halfDay ? 0.5 : diff;
    };

    const validate = () => {
        const e = {};
        if (!form.leaveType) e.leaveType = 'Leave type is required.';
        if (!form.dateRange?.[0]) e.dateRange = 'Please select dates.';
        if (!form.reason.trim()) e.reason = 'Reason is required.';
        setErrors(e);
        return !Object.keys(e).length;
    };

    const handleSubmit = () => {
        if (!validate()) return;
        onSubmit(form);
        setForm(initialForm);
        setErrors({});
    };

    const days = calcDays();
    const entitledTypes = mergedLeaveData
        .filter((e) => e.isEntitled)
        .map((e) => ({ label: e.label, value: e }));
    const selectedEntry = mergedLeaveData.find((e) => e.id === form.leaveType?.id);
    const remaining = selectedEntry?.isEntitled ? selectedEntry.remaining : null;

    const footer = (
        <div className="flex justify-content-end gap-2 pt-2">
            <Button
                label="Cancel"
                icon="pi pi-times"
                outlined
                severity="secondary"
                onClick={onHide}
                disabled={isSubmitting}
            />
            <Button
                label="Submit Request"
                icon="pi pi-check"
                onClick={handleSubmit}
                loading={isSubmitting}
            />
        </div>
    );

    return (
        <Dialog
            header={
                <div className="flex align-items-center gap-2">
                    <i className="pi pi-plus-circle text-primary text-xl" />
                    <span className="text-lg font-semibold">Apply for Leave</span>
                </div>
            }
            visible={visible}
            onHide={onHide}
            footer={footer}
            className="leave-dialog"
            breakpoints={{ '768px': '95vw' }}
            modal
            draggable={false}
        >
            <div className="flex flex-column gap-4 pt-2">
                {/* Leave Type */}
                <div className="flex flex-column gap-1">
                    <label className="font-medium text-sm text-700">
                        Leave Type <span className="text-red-500">*</span>
                    </label>
                    <Dropdown
                        value={form.leaveType}
                        options={entitledTypes}
                        onChange={(e) => set('leaveType', e.value)}
                        placeholder="Select leave type"
                        className={`w-full ${errors.leaveType ? 'p-invalid' : ''}`}
                    />
                    {errors.leaveType ? (
                        <small className="text-red-500">{errors.leaveType}</small>
                    ) : (
                        form.leaveType &&
                        remaining !== null && (
                            <small className="text-500 flex align-items-center gap-1">
                                <i className="pi pi-info-circle" />
                                You have <strong className="text-700 mx-1">
                                    {remaining} days
                                </strong>{' '}
                                remaining for {form.leaveType.label}.
                                {remaining === 0 && (
                                    <span className="text-red-500 font-medium ml-1">
                                        (Balance exhausted)
                                    </span>
                                )}
                            </small>
                        )
                    )}
                </div>

                {/* Dates */}
                <div className="flex flex-column gap-1">
                    <label className="font-medium text-sm text-700">
                        Date(s) <span className="text-red-500">*</span>
                    </label>
                    <Calendar
                        value={form.dateRange}
                        onChange={(e) => set('dateRange', e.value)}
                        selectionMode={form.halfDay ? 'single' : 'range'}
                        readOnlyInput
                        showIcon
                        minDate={new Date()}
                        className={`w-full ${errors.dateRange ? 'p-invalid' : ''}`}
                        placeholder={form.halfDay ? 'Select date' : 'Select date range'}
                    />
                    {errors.dateRange && <small className="text-red-500">{errors.dateRange}</small>}
                </div>

                {/* Checkboxes */}
                <div className="flex gap-4 flex-wrap">
                    <div className="flex align-items-center gap-2">
                        <input
                            type="checkbox"
                            id="halfDay"
                            className="leave-checkbox"
                            checked={form.halfDay}
                            onChange={(e) => set('halfDay', e.target.checked)}
                        />
                        <label htmlFor="halfDay" className="text-sm text-700 cursor-pointer">
                            Half Day
                        </label>
                    </div>
                    <div className="flex align-items-center gap-2">
                        <input
                            type="checkbox"
                            id="emergency"
                            className="leave-checkbox"
                            checked={form.emergency}
                            onChange={(e) => set('emergency', e.target.checked)}
                        />
                        <label htmlFor="emergency" className="text-sm text-700 cursor-pointer">
                            Emergency Leave
                        </label>
                    </div>
                </div>

                {/* Days pill */}
                {days > 0 && (
                    <div className="days-pill flex align-items-center justify-content-center gap-2">
                        <i className="pi pi-clock days-pill__icon" />
                        <span className="days-pill__text font-semibold text-sm">
                            {days} day{days !== 1 ? 's' : ''} requested
                        </span>
                    </div>
                )}

                {/* Attachment notice */}
                {form.leaveType?.requiresAttachment && (
                    <div className="attach-notice flex align-items-center gap-2 px-3 py-2 border-round-lg">
                        <i className="pi pi-paperclip flex-shrink-0" />
                        <span className="text-sm">
                            A supporting document is required for{' '}
                            <strong>{form.leaveType.label}</strong>.
                        </span>
                    </div>
                )}

                {/* Reason */}
                <div className="flex flex-column gap-1">
                    <label className="font-medium text-sm text-700">
                        Reason <span className="text-red-500">*</span>
                    </label>
                    <InputTextarea
                        value={form.reason}
                        onChange={(e) => set('reason', e.target.value)}
                        rows={3}
                        placeholder="Briefly describe the reason for your leave..."
                        className={`w-full ${errors.reason ? 'p-invalid' : ''}`}
                        maxLength={300}
                    />
                    <div className="flex justify-content-between">
                        <small className="text-red-500">{errors.reason || ''}</small>
                        <small className="text-400">{form.reason.length}/300</small>
                    </div>
                </div>

                {/* Attachment */}
                <div className="flex flex-column gap-1">
                    <label className="font-medium text-sm text-700">
                        Attachment{' '}
                        {form.leaveType?.requiresAttachment && (
                            <span className="text-red-500 ml-1">*</span>
                        )}
                    </label>
                    <FileUpload
                        mode="basic"
                        accept=".pdf,.png,.jpg,.jpeg"
                        maxFileSize={2000000}
                        chooseLabel="Upload Document"
                        chooseIcon="pi pi-paperclip"
                        className="w-full"
                        auto={false}
                    />
                    <small className="text-400">
                        {form.leaveType?.requiresAttachment
                            ? 'Required — please attach a supporting document.'
                            : 'Optional — medical cert, travel docs, etc. Max 2 MB.'}
                    </small>
                </div>
            </div>
        </Dialog>
    );
};

// ─── Review Dialog ────────────────────────────────────────────────────────────

const ReviewDialog = ({ visible, onHide, request, onDecision }) => {
    const [comment, setComment] = useState('');
    if (!request) return null;

    const visual = resolveVisual(request.leaveTypeId || request.leaveType);
    const isPending = request.status === 'Pending';

    const handleDecision = (action) => {
        onDecision({ requestId: request.id, action, comment });
        setComment('');
    };
    const handleHide = () => {
        setComment('');
        onHide();
    };

    const footer = (
        <div className="flex justify-content-end gap-2">
            {isPending ? (
                <>
                    <Button
                        label="Cancel"
                        icon="pi pi-times"
                        text
                        severity="secondary"
                        onClick={handleHide}
                    />
                    <Button
                        label="Reject"
                        icon="pi pi-times-circle"
                        outlined
                        severity="danger"
                        onClick={() => handleDecision('Rejected')}
                    />
                    <Button
                        label="Approve"
                        icon="pi pi-check-circle"
                        severity="success"
                        onClick={() => handleDecision('Approved')}
                    />
                </>
            ) : (
                <Button
                    label="Close"
                    icon="pi pi-times"
                    text
                    severity="secondary"
                    onClick={handleHide}
                />
            )}
        </div>
    );

    return (
        <Dialog
            header={
                <div className="flex align-items-center gap-2">
                    <i className="pi pi-file-check text-primary text-xl" />
                    <span className="text-lg font-semibold">Leave Request</span>
                </div>
            }
            visible={visible}
            onHide={handleHide}
            footer={footer}
            className="review-dialog"
            breakpoints={{ '768px': '95vw' }}
            modal
            draggable={false}
        >
            <div className="flex flex-column gap-4 pt-2">
                {/* Employee strip */}
                <div className="flex align-items-center gap-3 p-3 border-round-lg surface-50 border-1 surface-border">
                    <Avatar
                        label={request.initials}
                        size="large"
                        shape="circle"
                        className={`avatar--${request.avatarKey} flex-shrink-0`}
                    />
                    <div className="flex flex-column gap-1 flex-1">
                        <span className="font-bold text-900 text-base">{request.employeeName}</span>
                        <span className="text-500 text-sm">{request.department}</span>
                    </div>
                    <Tag value={request.status} severity={getStatusSeverity(request.status)} />
                </div>

                {/* Leave details grid */}
                <div className="grid">
                    {[
                        {
                            label: 'Leave Type',
                            value: (
                                <span className="flex align-items-center gap-2">
                                    <i
                                        className={`${visual.icon} text-sm lbc__icon lbc--${visual.cssKey}`}
                                    />
                                    {request.leaveType}
                                </span>
                            ),
                        },
                        {
                            label: 'Duration',
                            value: (
                                <span className="flex align-items-center gap-2">
                                    {request.dateFrom === request.dateTo
                                        ? request.dateFrom
                                        : `${request.dateFrom} – ${request.dateTo}`}
                                    <Tag
                                        value={`${request.days}d`}
                                        severity="info"
                                        className="text-xs"
                                    />
                                </span>
                            ),
                        },
                        { label: 'Submitted On', value: request.submittedOn },
                    ].map((item, i) => (
                        <div key={i} className="col-12 md:col-4">
                            <div className="flex flex-column gap-1 p-2 border-round surface-50">
                                <span className="detail-label text-400 text-xs font-medium uppercase">
                                    {item.label}
                                </span>
                                <span className="text-800 text-sm font-medium">{item.value}</span>
                            </div>
                        </div>
                    ))}

                    {/* Reason — full width */}
                    <div className="col-12">
                        <div className="flex flex-column gap-1 p-2 border-round surface-50">
                            <span className="detail-label text-400 text-xs font-medium uppercase">
                                Reason
                            </span>
                            <span className="text-800 text-sm">{request.reason}</span>
                        </div>
                    </div>

                    {request.attachment && (
                        <div className="col-12">
                            <Button
                                label="View Attached Document"
                                icon="pi pi-paperclip"
                                text
                                size="small"
                                className="p-0 text-primary"
                            />
                        </div>
                    )}
                </div>

                {/* Already-decided notice */}
                {!isPending && (
                    <Message
                        severity={request.status === 'Approved' ? 'success' : 'error'}
                        text={`This request has already been ${request.status.toLowerCase()}.`}
                        icon={`pi ${request.status === 'Approved' ? 'pi-check-circle' : 'pi-times-circle'}`}
                        className="w-full border-round-xl"
                    />
                )}

                {/* Decision comment */}
                {isPending && (
                    <>
                        <Divider className="my-0" />
                        <div className="flex flex-column gap-1">
                            <label className="text-700 text-sm font-medium">
                                Comment <span className="text-400 font-normal">(optional)</span>
                            </label>
                            <InputTextarea
                                value={comment}
                                onChange={(e) => setComment(e.target.value)}
                                rows={3}
                                placeholder="Add a note for the employee…"
                                className="w-full"
                                maxLength={400}
                            />
                            <div className="flex justify-content-end">
                                <span className="text-400 text-xs">{comment.length}/400</span>
                            </div>
                        </div>
                    </>
                )}
            </div>
        </Dialog>
    );
};

// ─── History Tab ──────────────────────────────────────────────────────────────

const HistoryTab = ({ leaveHistory, isLoading }) => {
    const [statusFilter, setStatusFilter] = useState(null);
    const [typeFilter, setTypeFilter] = useState(null);

    const typeFilterOptions = useMemo(
        () => ['All', ...new Set(leaveHistory.map((r) => r.type))],
        [leaveHistory],
    );

    const filtered = leaveHistory.filter((r) => {
        if (statusFilter && statusFilter !== 'All' && r.status !== statusFilter) return false;
        if (typeFilter && typeFilter !== 'All' && r.type !== typeFilter) return false;
        return true;
    });

    const STATUS_CHIPS = [
        { label: 'Approved', mod: 'approved' },
        { label: 'Pending', mod: 'pending' },
        { label: 'Rejected', mod: 'rejected' },
    ];

    const statusTemplate = (row) => (
        <Tag value={row.status} severity={getStatusSeverity(row.status)} className="text-sm" />
    );

    const actionTemplate = (row) => (
        <div className="flex gap-1">
            {row.status === 'Pending' && (
                <Button
                    icon="pi pi-times"
                    text
                    rounded
                    severity="danger"
                    size="small"
                    tooltip="Withdraw"
                    tooltipOptions={{ position: 'top' }}
                />
            )}
            <Button
                icon="pi pi-ellipsis-v"
                text
                rounded
                severity="secondary"
                size="small"
                tooltip="More options"
                tooltipOptions={{ position: 'top' }}
            />
        </div>
    );

    if (isLoading) return <Skeleton height="200px" />;

    return (
        <>
            <div className="flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
                <h4 className="pl-2 m-0 font-semibold">Leave Request History</h4>
                <div className="flex gap-2 align-items-center flex-wrap">
                    <Dropdown
                        placeholder="All Statuses"
                        options={['All', 'Pending', 'Approved', 'Rejected']}
                        value={statusFilter}
                        onChange={(e) => setStatusFilter(e.value)}
                        className="w-10rem"
                        showClear
                    />
                    <Dropdown
                        placeholder="All Types"
                        options={typeFilterOptions}
                        value={typeFilter}
                        onChange={(e) => setTypeFilter(e.value)}
                        className="w-10rem"
                        showClear
                    />
                </div>
            </div>
            <div className="border-top-1 surface-border mb-3" />
            <div className="flex gap-2 flex-wrap mb-3">
                {STATUS_CHIPS.map(({ label, mod }) => {
                    const count = leaveHistory.filter((r) => r.status === label).length;
                    const isActive = statusFilter === label;
                    return (
                        <span
                            key={label}
                            className={`status-chip status-chip--${mod}${isActive ? ' status-chip--active' : ''} px-3 py-1 border-round-lg border-1 text-sm cursor-pointer`}
                            onClick={() => setStatusFilter(isActive ? null : label)}
                        >
                            {label}: <strong>{count}</strong>
                        </span>
                    );
                })}
            </div>
            <div className="border-1 border-solid surface-border">
                <DataTable
                    value={filtered}
                    responsiveLayout="scroll"
                    stripedRows
                    showGridlines={false}
                    emptyMessage="No leave requests match the selected filters."
                    scrollable
                >
                    <Column field="type" header="Leave Type" />
                    <Column field="dates" header="Dates Requested" />
                    <Column field="reason" header="Reason" />
                    <Column field="submitted" header="Submitted On" />
                    <Column
                        field="status"
                        header="Status"
                        body={statusTemplate}
                        style={{ width: '140px' }}
                    />
                    <Column field="assignedTo" header="Coverage" />
                    <Column header="Actions" body={actionTemplate} style={{ width: '100px' }} />
                </DataTable>
            </div>
        </>
    );
};

// ─── Calendar Tab ─────────────────────────────────────────────────────────────

const CalendarTab = () => (
    <div>
        <div className="flex align-items-center justify-content-between mb-2">
            <h4 className="pl-2 mt-2 mb-2 font-semibold">Calendar</h4>
        </div>
        <div className="border-top-1 surface-border mb-3" />
        <div className="flex gap-4 flex-wrap">
            <div className="cal-wrapper flex-1">
                <Calendar
                    inline
                    className="w-full"
                    dateTemplate={(date) => {
                        const approvedDays = [15, 16, 17, 18, 25];
                        const upcomingDays = [10, 11, 12, 13, 14];
                        if (approvedDays.includes(date.day) && date.month === 3)
                            return <span className="cal-date cal-date--approved">{date.day}</span>;
                        if (upcomingDays.includes(date.day) && date.month === 4)
                            return <span className="cal-date cal-date--upcoming">{date.day}</span>;
                        return date.day;
                    }}
                />
            </div>
            <div className="flex flex-column gap-2 pt-2 cal-legend">
                <span className="font-semibold text-sm text-700 mb-1">Legend</span>
                {[
                    { mod: 'approved', label: 'Approved Leave' },
                    { mod: 'pending', label: 'Pending Leave' },
                    { mod: 'upcoming', label: 'Upcoming Leave' },
                    { mod: 'rejected', label: 'Rejected' },
                ].map((l) => (
                    <div key={l.mod} className="flex align-items-center gap-2 text-sm text-700">
                        <span
                            className={`legend-dot legend-dot--${l.mod} border-circle flex-shrink-0`}
                        />
                        {l.label}
                    </div>
                ))}
            </div>
        </div>
    </div>
);

// ─── Holidays Tab ─────────────────────────────────────────────────────────────

const HolidaysTab = () => (
    <>
        <div className="flex align-items-center justify-content-between mb-2">
            <h4 className="pl-2 mt-2 mb-2 font-semibold">Holidays List</h4>
            <span className="text-sm text-500">{companyHolidays.length} holidays this year</span>
        </div>
        <div className="border-top-1 surface-border mb-3" />
        <div className="flex flex-column gap-2">
            {companyHolidays.map((h, i) => {
                const isPast = i < 1;
                const mod = isPast ? 'past' : h.type.toLowerCase();
                return (
                    <div
                        key={i}
                        className={`holiday-row holiday-row--${mod} flex align-items-center gap-3 px-3 py-2 border-round-lg border-1`}
                    >
                        <span
                            className={`holiday-dot holiday-dot--${mod} border-circle flex-shrink-0`}
                        />
                        <div className="flex flex-column gap-1 flex-1">
                            <div className="flex align-items-center gap-2 flex-wrap">
                                <span className="font-semibold text-sm text-800">{h.name}</span>
                                <span
                                    className={`holiday-badge holiday-badge--${mod} px-2 py-1 border-round text-xs`}
                                >
                                    {h.type}
                                </span>
                                {isPast && (
                                    <span className="text-400 text-xs font-italic">Past</span>
                                )}
                            </div>
                            <span className="text-500 text-xs">{h.day}</span>
                        </div>
                        <span className="text-sm font-medium text-700 white-space-nowrap">
                            {h.date}
                        </span>
                    </div>
                );
            })}
        </div>
        <div className="flex align-items-center gap-2 mt-3 px-3 py-2 border-round border-1 surface-border surface-50">
            <i className="pi pi-download text-primary text-sm" />
            <span className="text-xs text-500">Need the full holiday calendar?</span>
            <Button label="Download PDF" text size="small" className="p-0 ml-1 text-xs" />
        </div>
    </>
);

// ─── Main Page ────────────────────────────────────────────────────────────────

const Leaves = () => {
    const navigate = useNavigate();
    const toast = useRef(null);

    const [applyVisible, setApplyVisible] = useState(false);
    const [activeTab, setActiveTab] = useState(0);
    const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
    const [selectedRequest, setSelectedRequest] = useState(null);
    // Optimistic status overrides until a real wf-action hook is wired
    const [teamRequestOverrides, setTeamRequestOverrides] = useState({});

    // ── Hooks ────────────────────────────────────────────────────────────────
    const { data: leaveTypesData, isLoading: leaveTypesLoading } = useGetLeaveTypes();

    const {
        fetchLeaveBalance,
        data: leaveBalanceData,
        isPending: balanceLoading,
    } = useGetLeaveBalance();

    const {
        fetchLeaveHistory,
        data: employeeHistoryData,
        isPending: historyLoading,
    } = useGetLeaveRequestHistoryForEmployee();

    const { fetchApproverLeaveHistory, data: approverHistoryData } =
        useGetLeaveRequestHistoryForApprover();

    const { submitLeaveRequest, isPending: isSubmitting } = useSubmitLeaveRequest();

    // ── Fetch all data on mount ───────────────────────────────────────────────
    useEffect(() => {
        fetchLeaveBalance().catch((err) => console.error('Error fetching leave balance:', err));
        fetchLeaveHistory().catch((err) => console.error('Error fetching leave history:', err));
        fetchApproverLeaveHistory().catch((err) =>
            console.error('Error fetching approver leave history:', err),
        );
    }, []); //The user ID is sent through requestInfo that is mapped to an employee

    // ── Derived data ─────────────────────────────────────────────────────────

    const leaveTypes = useMemo(() => {
        const content = leaveTypesData?.content ?? [];
        return content.map(mapLeaveType);
    }, [leaveTypesData]);

    const leaveBalances = useMemo(() => leaveBalanceData ?? [], [leaveBalanceData]);

    const mergedLeaveData = useMemo(
        () => mergeLeaveData(leaveTypes, leaveBalances),
        [leaveTypes, leaveBalances],
    );

    const leaveHistory = useMemo(() => {
        const raw = Array.isArray(employeeHistoryData)
            ? employeeHistoryData
            : (employeeHistoryData?.content ?? []); // ← add this
        return raw.map((r, i) => mapLeaveRequest(r, i));
    }, [employeeHistoryData]);

    // ── Handlers ─────────────────────────────────────────────────────────────

    const handleApplySubmit = async (form) => {
        try {
            const dateFrom = form.dateRange[0].toISOString().split('T')[0];
            const dateTo = (form.dateRange[1] || form.dateRange[0]).toISOString().split('T')[0];
            const days = form.halfDay
                ? 0.5
                : Math.ceil(
                      ((form.dateRange[1] || form.dateRange[0]) - form.dateRange[0]) / 86400000,
                  ) + 1;

            await submitLeaveRequest({
                // ← was createLeaveRequest
                leaveTypeId: form.leaveType.id, // ← workflowId is gone, hook handles it
                dateFrom,
                dateTo,
                days,
                startSession: form.halfDay ? 'FIRST_HALF' : 'FULL',
                endSession: form.halfDay ? 'FIRST_HALF' : 'FULL',
                reason: form.reason,
                tenantId: form.leaveType.tenantId,
            });

            setApplyVisible(false);
            toast.current.show({
                severity: 'success',
                summary: 'Leave Submitted',
                detail: `Your ${form.leaveType.label} leave request has been submitted.`,
                life: 4000,
            });
            fetchLeaveHistory().catch((err) => console.error('Error fetching leave history:', err));
        } catch (err) {
            toast.current.show({
                severity: 'error',
                summary: 'Submission Failed',
                detail: err?.message || 'Could not submit leave request. Please try again.',
                life: 5000,
            });
        }
    };

    const handleDecision = ({ requestId, action, comment }) => {
        // Optimistic update — wire a real wf-action hook here when available
        setTeamRequestOverrides((prev) => ({ ...prev, [requestId]: action }));
        setReviewDialogOpen(false);
        setSelectedRequest(null);
        toast.current.show({
            severity: action === 'Approved' ? 'success' : 'warn',
            summary: `Request ${action}`,
            detail: `Leave request has been ${action.toLowerCase()}.${comment ? ` Note: "${comment}"` : ''}`,
            life: 4000,
        });
    };

    // ── Nav / Tabs ────────────────────────────────────────────────────────────

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        {
            label: 'Time & Attendance',
            command: () => navigate('/web/landing/hrms/time-n-attendance'),
        },
        { label: 'Leaves' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/web/landing') };

    const employeeTabs = [
        {
            label: 'Request History',
            icon: 'pi pi-list',
            active: activeTab === 0,
            onClick: () => setActiveTab(0),
        },
        {
            label: 'My Calendar',
            icon: 'pi pi-calendar',
            active: activeTab === 1,
            onClick: () => setActiveTab(1),
        },
        {
            label: 'Holidays',
            icon: 'pi pi-star',
            active: activeTab === 2,
            onClick: () => setActiveTab(2),
        },
    ];

    // ── Render ────────────────────────────────────────────────────────────────

    return (
        <div className="leaves-page">
            <Toast ref={toast} />
            <ConfirmDialog />

            <ApplyLeaveDialog
                visible={applyVisible}
                onHide={() => setApplyVisible(false)}
                onSubmit={handleApplySubmit}
                mergedLeaveData={mergedLeaveData}
                isSubmitting={isSubmitting}
            />
            <ReviewDialog
                visible={reviewDialogOpen}
                onHide={() => {
                    setReviewDialogOpen(false);
                    setSelectedRequest(null);
                }}
                request={selectedRequest}
                onDecision={handleDecision}
            />

            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {/* Upcoming banner (mock) */}
            {upcomingLeaves.length > 0 && (
                <div className="upcoming-banner flex align-items-center gap-3 flex-wrap px-3 py-2 border-round-lg mb-3 border-1">
                    <i className="pi pi-calendar-plus text-xl flex-shrink-0 upcoming-banner__icon" />
                    <div className="flex flex-column gap-1 flex-1">
                        <span className="font-semibold text-sm upcoming-banner__title">
                            Upcoming Approved Leaves
                        </span>
                        <div className="flex gap-3 flex-wrap">
                            {upcomingLeaves.map((l, i) => (
                                <span
                                    key={i}
                                    className="flex align-items-center gap-1 text-sm text-700"
                                >
                                    <Tag
                                        value={l.type}
                                        severity={getStatusSeverity(l.status)}
                                        className="text-xs"
                                    />
                                    {l.dates} ({l.days} day{l.days > 1 ? 's' : ''})
                                </span>
                            ))}
                        </div>
                    </div>
                </div>
            )}

            {/* Leave Balance */}
            <Card className="mt-2">
                <div className="flex align-items-center justify-content-between mb-3">
                    <h4 className="m-0 font-semibold">Leave Balance</h4>
                    <Button
                        label="Apply Leave"
                        icon="pi pi-plus"
                        size="small"
                        onClick={() => setApplyVisible(true)}
                        disabled={leaveTypesLoading || balanceLoading}
                    />
                </div>
                <div className="border-top-1 surface-border mb-3" />

                {leaveTypesLoading || balanceLoading ? (
                    <LeaveBalanceSkeleton />
                ) : (
                    <div className="grid mb-0">
                        {mergedLeaveData.map((entry) => (
                            <div key={entry.id} className="col-12 sm:col-6 lg:col-3">
                                <LeaveBalanceCard entry={entry} />
                            </div>
                        ))}
                    </div>
                )}

                <div className="flex align-items-center gap-2 mt-3 px-3 py-2 border-round border-1 surface-border surface-50">
                    <i className="pi pi-info-circle text-400 text-sm flex-shrink-0" />
                    <span className="text-xs text-500">ANY NOTICE COMES HERE!</span>
                </div>
            </Card>

            {/* Employee tabs */}
            <div className="mt-4">
                <TabbedSectionCard tabs={employeeTabs} whiteBack={true}>
                    {activeTab === 0 && (
                        <HistoryTab leaveHistory={leaveHistory} isLoading={historyLoading} />
                    )}
                    {activeTab === 1 && <CalendarTab />}
                    {activeTab === 2 && <HolidaysTab />}
                </TabbedSectionCard>
            </div>
        </div>
    );
};

export default Leaves;

//------------------------------------------SAMPLE WITH MOCK DATA-------------------------------------------------------------

// import React, { useState, useRef } from 'react';
// import { Card } from 'primereact/card';
// import { Button } from 'primereact/button';
// import { DataTable } from 'primereact/datatable';
// import { Column } from 'primereact/column';
// import { Dropdown } from 'primereact/dropdown';
// import { Tag } from 'primereact/tag';
// import { BreadCrumb } from 'primereact/breadcrumb';
// import { Dialog } from 'primereact/dialog';
// import { InputTextarea } from 'primereact/inputtextarea';
// import { Calendar } from 'primereact/calendar';
// import { FileUpload } from 'primereact/fileupload';
// import { Toast } from 'primereact/toast';
// import { Avatar } from 'primereact/avatar';
// import { ProgressBar } from 'primereact/progressbar';
// import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
// import { Toolbar } from 'primereact/toolbar';
// import { SelectButton } from 'primereact/selectbutton';
// import { Message } from 'primereact/message';
// import { Divider } from 'primereact/divider';
// import { MeterGroup } from 'primereact/metergroup';
// import { Knob } from 'primereact/knob';
// import { useNavigate } from 'react-router';
// import TabbedSectionCard from '@shared/components/TabbedSectionCard';
// import SimpleSectionCard from '@shared/components/SimpleSectionCard';
// import '../../styles/Leaves/Leaves.scss';

// // ─── Visual config — icon + cssKey only (colors live entirely in SCSS) ────────

// const LEAVE_TYPE_VISUAL = {
//     sick: { icon: 'pi pi-exclamation-triangle', cssKey: 'sick' },
//     vacation: { icon: 'pi pi-send', cssKey: 'vacation' },
//     casual: { icon: 'pi pi-calendar', cssKey: 'casual' },
//     maternity: { icon: 'pi pi-users', cssKey: 'maternity' },
//     paternity: { icon: 'pi pi-users', cssKey: 'paternity' },
//     unpaid: { icon: 'pi pi-minus-circle', cssKey: 'unpaid' },
//     bereavement: { icon: 'pi pi-heart', cssKey: 'bereavement' },
//     default: { icon: 'pi pi-bookmark', cssKey: 'default' },
// };
// const resolveVisual = (typeId) => {
//     const key = (typeId || '').toLowerCase().replace(/[^a-z]/g, '');
//     return LEAVE_TYPE_VISUAL[key] || LEAVE_TYPE_VISUAL.default;
// };

// // ─── Mock: Current User ───────────────────────────────────────────────────────
// const currentUser = { id: 'emp-001', name: 'Ali Hassan', isManager: true };

// // ─── Mock: Leave Types ────────────────────────────────────────────────────────
// const leaveTypes = [
//     {
//         id: 'sick',
//         label: 'Sick Leave',
//         carryForward: 2,
//         encashable: false,
//         requiresAttachment: false,
//     },
//     {
//         id: 'vacation',
//         label: 'Vacation',
//         carryForward: 5,
//         encashable: true,
//         requiresAttachment: false,
//     },
//     {
//         id: 'casual',
//         label: 'Casual Leave',
//         carryForward: 0,
//         encashable: false,
//         requiresAttachment: false,
//     },
//     {
//         id: 'maternity',
//         label: 'Maternity/Paternity',
//         carryForward: 0,
//         encashable: false,
//         requiresAttachment: true,
//     },
//     {
//         id: 'bereavement',
//         label: 'Bereavement Leave',
//         carryForward: 0,
//         encashable: false,
//         requiresAttachment: true,
//     },
//     {
//         id: 'unpaid',
//         label: 'Unpaid Leave',
//         carryForward: 0,
//         encashable: false,
//         requiresAttachment: false,
//     },
// ];

// // ─── Mock: Employee Leave Balances ────────────────────────────────────────────
// const employeeLeaveBalances = [
//     { leaveTypeId: 'sick', used: 10, total: 10 },
//     { leaveTypeId: 'vacation', used: 3, total: 10 },
//     { leaveTypeId: 'casual', used: 6, total: 10 },
//     { leaveTypeId: 'maternity', used: 2, total: 10 },
// ];

// // ─── Mock: Leave History ──────────────────────────────────────────────────────
// const leaveHistory = [
//     {
//         type: 'Sick',
//         dates: 'Apr 25',
//         reason: 'Flu recovery',
//         submitted: 'Apr 25',
//         status: 'Pending',
//         assignedTo: 'N/A',
//     },
//     {
//         type: 'Casual',
//         dates: 'Apr 15–Apr 18',
//         reason: 'Home shifting',
//         submitted: 'Apr 07',
//         status: 'Approved',
//         assignedTo: 'Sarah M.',
//     },
//     {
//         type: 'Vacation',
//         dates: 'Mar 30',
//         reason: 'Going out of station',
//         submitted: 'Mar 29',
//         status: 'Pending',
//         assignedTo: 'N/A',
//     },
//     {
//         type: 'Sick',
//         dates: 'Mar 02',
//         reason: 'Fever recovery',
//         submitted: 'Mar 02',
//         status: 'Rejected',
//         assignedTo: 'Danish Ali',
//     },
//     {
//         type: 'Casual',
//         dates: 'Feb 14',
//         reason: 'Personal errand',
//         submitted: 'Feb 12',
//         status: 'Approved',
//         assignedTo: 'Sarah M.',
//     },
//     {
//         type: 'Vacation',
//         dates: 'Jan 02–Jan 05',
//         reason: 'New Year trip',
//         submitted: 'Dec 28',
//         status: 'Approved',
//         assignedTo: 'Omar K.',
//     },
// ];

// const upcomingLeaves = [
//     { type: 'Vacation', dates: 'May 10–May 14', days: 5, status: 'Approved' },
//     { type: 'Casual', dates: 'May 22', days: 1, status: 'Pending' },
// ];

// const companyHolidays = [
//     { name: 'Labour Day', date: 'May 1, 2025', day: 'Thursday', type: 'National' },
//     { name: 'Eid ul-Adha', date: 'Jun 7–9, 2025', day: 'Sat–Mon', type: 'Religious' },
//     { name: 'Independence Day', date: 'Aug 14, 2025', day: 'Thursday', type: 'National' },
//     { name: 'Iqbal Day', date: 'Nov 9, 2025', day: 'Sunday', type: 'National' },
//     { name: 'Christmas Day', date: 'Dec 25, 2025', day: 'Thursday', type: 'Religious' },
//     { name: "Quaid's Birthday", date: 'Dec 25, 2025', day: 'Thursday', type: 'National' },
// ];

// // ─── Mock: Team Leave Requests ────────────────────────────────────────────────
// const teamLeaveRequests = [
//     {
//         id: 'req-101',
//         employeeName: 'Sarah Mitchell',
//         employeeId: 'emp-012',
//         initials: 'SM',
//         avatarKey: 'indigo',
//         department: 'Engineering',
//         leaveType: 'Sick Leave',
//         leaveTypeId: 'sick',
//         dateFrom: 'May 5, 2025',
//         dateTo: 'May 5, 2025',
//         days: 1,
//         reason: 'Fever and flu, doctor advised rest.',
//         submittedOn: 'May 5, 2025',
//         status: 'Pending',
//         attachment: false,
//     },
//     {
//         id: 'req-102',
//         employeeName: 'Omar Khan',
//         employeeId: 'emp-019',
//         initials: 'OK',
//         avatarKey: 'teal',
//         department: 'Product',
//         leaveType: 'Vacation',
//         leaveTypeId: 'vacation',
//         dateFrom: 'May 12, 2025',
//         dateTo: 'May 16, 2025',
//         days: 5,
//         reason: 'Annual family vacation, planned 3 weeks in advance.',
//         submittedOn: 'Apr 28, 2025',
//         status: 'Pending',
//         attachment: false,
//     },
//     {
//         id: 'req-103',
//         employeeName: 'Hina Riaz',
//         employeeId: 'emp-034',
//         initials: 'HR',
//         avatarKey: 'amber',
//         department: 'Design',
//         leaveType: 'Casual Leave',
//         leaveTypeId: 'casual',
//         dateFrom: 'May 8, 2025',
//         dateTo: 'May 8, 2025',
//         days: 1,
//         reason: 'Home renovation — plumber appointment.',
//         submittedOn: 'May 6, 2025',
//         status: 'Pending',
//         attachment: false,
//     },
//     {
//         id: 'req-104',
//         employeeName: 'Danish Ali',
//         employeeId: 'emp-007',
//         initials: 'DA',
//         avatarKey: 'purple',
//         department: 'Engineering',
//         leaveType: 'Maternity/Paternity',
//         leaveTypeId: 'maternity',
//         dateFrom: 'Jun 1, 2025',
//         dateTo: 'Jun 10, 2025',
//         days: 8,
//         reason: 'Paternity leave for newborn.',
//         submittedOn: 'May 2, 2025',
//         status: 'Approved',
//         attachment: true,
//     },
//     {
//         id: 'req-105',
//         employeeName: 'Zara Siddiqui',
//         employeeId: 'emp-041',
//         initials: 'ZS',
//         avatarKey: 'pink',
//         department: 'Marketing',
//         leaveType: 'Sick Leave',
//         leaveTypeId: 'sick',
//         dateFrom: 'Apr 30, 2025',
//         dateTo: 'Apr 30, 2025',
//         days: 1,
//         reason: 'Migraine — could not attend office.',
//         submittedOn: 'Apr 30, 2025',
//         status: 'Rejected',
//         attachment: false,
//     },
//     {
//         id: 'req-106',
//         employeeName: 'Kamran Yousuf',
//         employeeId: 'emp-055',
//         initials: 'KY',
//         avatarKey: 'blue',
//         department: 'Engineering',
//         leaveType: 'Vacation',
//         leaveTypeId: 'vacation',
//         dateFrom: 'May 20, 2025',
//         dateTo: 'May 23, 2025',
//         days: 4,
//         reason: 'Road trip with family over the long weekend.',
//         submittedOn: 'May 8, 2025',
//         status: 'Pending',
//         attachment: false,
//     },
// ];

// // ─── Helpers ──────────────────────────────────────────────────────────────────

// const getStatusSeverity = (status) => {
//     switch (status?.toLowerCase()) {
//         case 'approved':
//             return 'success';
//         case 'rejected':
//             return 'danger';
//         case 'pending':
//             return 'warning';
//         default:
//             return 'info';
//     }
// };

// const mergeLeaveData = (types, balances) =>
//     types.map((type) => {
//         const balance = balances.find((b) => b.leaveTypeId === type.id);
//         return {
//             ...type,
//             used: balance?.used ?? null,
//             total: balance?.total ?? null,
//             isEntitled: !!balance,
//         };
//     });

// // ─── Leave Balance Card ───────────────────────────────────────────────────────

// const LeaveBalanceCard = ({ entry }) => {
//     const visual = resolveVisual(entry.id);
//     const remaining = entry.isEntitled ? entry.total - entry.used : null;
//     const pct = entry.isEntitled ? Math.round((entry.used / entry.total) * 100) : 0;
//     const isExhausted = entry.isEntitled && remaining === 0;

//     return (
//         <div
//             className={`lbc lbc--${visual.cssKey}${!entry.isEntitled ? ' lbc--disabled' : ''}${isExhausted ? ' lbc--exhausted' : ''}`}
//         >
//             <div className="flex justify-content-between align-items-start mb-2">
//                 <span className="font-semibold text-sm text-800">{entry.label}</span>
//                 <i className={`${visual.icon} lbc__icon text-xl`} />
//             </div>
//             {entry.isEntitled ? (
//                 <>
//                     <div className="lbc__days font-bold mb-1">
//                         {remaining}
//                         <span className="lbc__days-label text-500 font-normal ml-1">
//                             {' '}
//                             days left
//                         </span>
//                     </div>
//                     <div className="text-500 text-xs mb-2">
//                         {entry.used} used of {entry.total} total
//                     </div>
//                     <div className="lbc__progress-wrap mb-3">
//                         <ProgressBar
//                             value={pct}
//                             showValue={false}
//                             pt={{
//                                 root: { className: 'lbc__progress-root' },
//                                 value: { className: 'lbc__progress-value' },
//                             }}
//                         />
//                     </div>
//                     <div className="flex gap-1 flex-wrap">
//                         {entry.carryForward > 0 && (
//                             <span className="lbc__badge lbc__badge--carry">
//                                 <i className="pi pi-arrow-right-arrow-left mr-1" />
//                                 {entry.carryForward}d carry-forward
//                             </span>
//                         )}
//                         {entry.encashable && (
//                             <span className="lbc__badge lbc__badge--encash">
//                                 <i className="pi pi-wallet mr-1" />
//                                 Encashable
//                             </span>
//                         )}
//                         {isExhausted && (
//                             <span className="lbc__badge lbc__badge--exhausted">
//                                 <i className="pi pi-exclamation-circle mr-1" />
//                                 Balance exhausted
//                             </span>
//                         )}
//                         {!entry.carryForward && !entry.encashable && !isExhausted && (
//                             <span className="text-400 text-xs">No carry-forward</span>
//                         )}
//                     </div>
//                 </>
//             ) : (
//                 <div className="flex align-items-center gap-2 mt-2 text-400 text-sm">
//                     <i className="pi pi-lock" />
//                     <span>Not entitled</span>
//                 </div>
//             )}
//         </div>
//     );
// };

// // ─── Apply Leave Dialog ───────────────────────────────────────────────────────

// const ApplyLeaveDialog = ({ visible, onHide, onSubmit, mergedLeaveData }) => {
//     const initialForm = {
//         leaveType: null,
//         dateRange: null,
//         reason: '',
//         halfDay: false,
//         emergency: false,
//     };
//     const [form, setForm] = useState(initialForm);
//     const [errors, setErrors] = useState({});
//     const set = (key, val) => setForm((f) => ({ ...f, [key]: val }));

//     const calcDays = () => {
//         if (!form.dateRange?.[0]) return 0;
//         const diff =
//             Math.ceil(((form.dateRange[1] || form.dateRange[0]) - form.dateRange[0]) / 86400000) +
//             1;
//         return form.halfDay ? 0.5 : diff;
//     };
//     const validate = () => {
//         const e = {};
//         if (!form.leaveType) e.leaveType = 'Leave type is required.';
//         if (!form.dateRange?.[0]) e.dateRange = 'Please select dates.';
//         if (!form.reason.trim()) e.reason = 'Reason is required.';
//         setErrors(e);
//         return !Object.keys(e).length;
//     };
//     const handleSubmit = () => {
//         if (!validate()) return;
//         onSubmit(form);
//         setForm(initialForm);
//         setErrors({});
//     };

//     const days = calcDays();
//     const entitledTypes = mergedLeaveData
//         .filter((e) => e.isEntitled)
//         .map((e) => ({ label: e.label, value: e }));
//     const selectedEntry = mergedLeaveData.find((e) => e.id === form.leaveType?.id);
//     const remaining = selectedEntry?.isEntitled ? selectedEntry.total - selectedEntry.used : null;

//     const footer = (
//         <div className="flex justify-content-end gap-2 pt-2">
//             <Button
//                 label="Cancel"
//                 icon="pi pi-times"
//                 outlined
//                 severity="secondary"
//                 onClick={onHide}
//             />
//             <Button label="Submit Request" icon="pi pi-check" onClick={handleSubmit} />
//         </div>
//     );

//     return (
//         <Dialog
//             header={
//                 <div className="flex align-items-center gap-2">
//                     <i className="pi pi-plus-circle text-primary text-xl" />
//                     <span className="text-lg font-semibold">Apply for Leave</span>
//                 </div>
//             }
//             visible={visible}
//             onHide={onHide}
//             footer={footer}
//             className="leave-dialog"
//             breakpoints={{ '768px': '95vw' }}
//             modal
//             draggable={false}
//         >
//             <div className="flex flex-column gap-4 pt-2">
//                 {/* Leave Type */}
//                 <div className="flex flex-column gap-1">
//                     <label className="font-medium text-sm text-700">
//                         Leave Type <span className="text-red-500">*</span>
//                     </label>
//                     <Dropdown
//                         value={form.leaveType}
//                         options={entitledTypes}
//                         onChange={(e) => set('leaveType', e.value)}
//                         placeholder="Select leave type"
//                         className={`w-full ${errors.leaveType ? 'p-invalid' : ''}`}
//                     />
//                     {errors.leaveType ? (
//                         <small className="text-red-500">{errors.leaveType}</small>
//                     ) : (
//                         form.leaveType &&
//                         remaining !== null && (
//                             <small className="text-500 flex align-items-center gap-1">
//                                 <i className="pi pi-info-circle" />
//                                 You have <strong className="text-700 mx-1">
//                                     {remaining} days
//                                 </strong>{' '}
//                                 remaining for {form.leaveType.label}.
//                                 {remaining === 0 && (
//                                     <span className="text-red-500 font-medium ml-1">
//                                         (Balance exhausted)
//                                     </span>
//                                 )}
//                             </small>
//                         )
//                     )}
//                 </div>

//                 {/* Dates */}
//                 <div className="flex flex-column gap-1">
//                     <label className="font-medium text-sm text-700">
//                         Date(s) <span className="text-red-500">*</span>
//                     </label>
//                     <Calendar
//                         value={form.dateRange}
//                         onChange={(e) => set('dateRange', e.value)}
//                         selectionMode={form.halfDay ? 'single' : 'range'}
//                         readOnlyInput
//                         showIcon
//                         minDate={new Date()}
//                         className={`w-full ${errors.dateRange ? 'p-invalid' : ''}`}
//                         placeholder={form.halfDay ? 'Select date' : 'Select date range'}
//                     />
//                     {errors.dateRange && <small className="text-red-500">{errors.dateRange}</small>}
//                 </div>

//                 {/* Checkboxes */}
//                 <div className="flex gap-4 flex-wrap">
//                     <div className="flex align-items-center gap-2">
//                         <input
//                             type="checkbox"
//                             id="halfDay"
//                             className="leave-checkbox"
//                             checked={form.halfDay}
//                             onChange={(e) => set('halfDay', e.target.checked)}
//                         />
//                         <label htmlFor="halfDay" className="text-sm text-700 cursor-pointer">
//                             Half Day
//                         </label>
//                     </div>
//                     <div className="flex align-items-center gap-2">
//                         <input
//                             type="checkbox"
//                             id="emergency"
//                             className="leave-checkbox"
//                             checked={form.emergency}
//                             onChange={(e) => set('emergency', e.target.checked)}
//                         />
//                         <label htmlFor="emergency" className="text-sm text-700 cursor-pointer">
//                             Emergency Leave
//                         </label>
//                     </div>
//                 </div>

//                 {/* Days pill */}
//                 {days > 0 && (
//                     <div className="days-pill flex align-items-center justify-content-center gap-2">
//                         <i className="pi pi-clock days-pill__icon" />
//                         <span className="days-pill__text font-semibold text-sm">
//                             {days} day{days !== 1 ? 's' : ''} requested
//                         </span>
//                     </div>
//                 )}

//                 {/* Attachment notice */}
//                 {form.leaveType?.requiresAttachment && (
//                     <div className="attach-notice flex align-items-center gap-2 px-3 py-2 border-round-lg">
//                         <i className="pi pi-paperclip flex-shrink-0" />
//                         <span className="text-sm">
//                             A supporting document is required for{' '}
//                             <strong>{form.leaveType.label}</strong>.
//                         </span>
//                     </div>
//                 )}

//                 {/* Reason */}
//                 <div className="flex flex-column gap-1">
//                     <label className="font-medium text-sm text-700">
//                         Reason <span className="text-red-500">*</span>
//                     </label>
//                     <InputTextarea
//                         value={form.reason}
//                         onChange={(e) => set('reason', e.target.value)}
//                         rows={3}
//                         placeholder="Briefly describe the reason for your leave..."
//                         className={`w-full ${errors.reason ? 'p-invalid' : ''}`}
//                         maxLength={300}
//                     />
//                     <div className="flex justify-content-between">
//                         <small className="text-red-500">{errors.reason || ''}</small>
//                         <small className="text-400">{form.reason.length}/300</small>
//                     </div>
//                 </div>

//                 {/* Attachment */}
//                 <div className="flex flex-column gap-1">
//                     <label className="font-medium text-sm text-700">
//                         Attachment{' '}
//                         {form.leaveType?.requiresAttachment && (
//                             <span className="text-red-500 ml-1">*</span>
//                         )}
//                     </label>
//                     <FileUpload
//                         mode="basic"
//                         accept=".pdf,.png,.jpg,.jpeg"
//                         maxFileSize={2000000}
//                         chooseLabel="Upload Document"
//                         chooseIcon="pi pi-paperclip"
//                         className="w-full"
//                         auto={false}
//                     />
//                     <small className="text-400">
//                         {form.leaveType?.requiresAttachment
//                             ? 'Required — please attach a supporting document.'
//                             : 'Optional — medical cert, travel docs, etc. Max 2 MB.'}
//                     </small>
//                 </div>
//             </div>
//         </Dialog>
//     );
// };

// // ─── Review Dialog ────────────────────────────────────────────────────────────

// const ReviewDialog = ({ visible, onHide, request, onDecision }) => {
//     const [comment, setComment] = useState('');
//     if (!request) return null;

//     const visual = resolveVisual(request.leaveTypeId);
//     const isPending = request.status === 'Pending';

//     const handleDecision = (action) => {
//         onDecision({ requestId: request.id, action, comment });
//         setComment('');
//     };
//     const handleHide = () => {
//         setComment('');
//         onHide();
//     };

//     const footer = (
//         <div className="flex justify-content-end gap-2">
//             {isPending ? (
//                 <>
//                     <Button
//                         label="Cancel"
//                         icon="pi pi-times"
//                         text
//                         severity="secondary"
//                         onClick={handleHide}
//                     />
//                     <Button
//                         label="Reject"
//                         icon="pi pi-times-circle"
//                         outlined
//                         severity="danger"
//                         onClick={() => handleDecision('Rejected')}
//                     />
//                     <Button
//                         label="Approve"
//                         icon="pi pi-check-circle"
//                         severity="success"
//                         onClick={() => handleDecision('Approved')}
//                     />
//                 </>
//             ) : (
//                 <Button
//                     label="Close"
//                     icon="pi pi-times"
//                     text
//                     severity="secondary"
//                     onClick={handleHide}
//                 />
//             )}
//         </div>
//     );

//     return (
//         <Dialog
//             header={
//                 <div className="flex align-items-center gap-2">
//                     <i className="pi pi-file-check text-primary text-xl" />
//                     <span className="text-lg font-semibold">Leave Request</span>
//                 </div>
//             }
//             visible={visible}
//             onHide={handleHide}
//             footer={footer}
//             className="review-dialog"
//             breakpoints={{ '768px': '95vw' }}
//             modal
//             draggable={false}
//         >
//             <div className="flex flex-column gap-4 pt-2">
//                 {/* Employee strip */}
//                 <div className="flex align-items-center gap-3 p-3 border-round-lg surface-50 border-1 surface-border">
//                     <Avatar
//                         label={request.initials}
//                         size="large"
//                         shape="circle"
//                         className={`avatar--${request.avatarKey} flex-shrink-0`}
//                     />
//                     <div className="flex flex-column gap-1 flex-1">
//                         <span className="font-bold text-900 text-base">{request.employeeName}</span>
//                         <span className="text-500 text-sm">{request.department}</span>
//                     </div>
//                     <Tag value={request.status} severity={getStatusSeverity(request.status)} />
//                 </div>

//                 {/* Leave details */}
//                 <div className="grid">
//                     {[
//                         {
//                             label: 'Leave Type',
//                             value: (
//                                 <span className="flex align-items-center gap-2">
//                                     <i
//                                         className={`${visual.icon} text-sm lbc__icon lbc--${visual.cssKey}`}
//                                     />
//                                     {request.leaveType}
//                                 </span>
//                             ),
//                         },
//                         {
//                             label: 'Duration',
//                             value: (
//                                 <span className="flex align-items-center gap-2">
//                                     {request.dateFrom === request.dateTo
//                                         ? request.dateFrom
//                                         : `${request.dateFrom} – ${request.dateTo}`}
//                                     <Tag
//                                         value={`${request.days}d`}
//                                         severity="info"
//                                         className="text-xs"
//                                     />
//                                 </span>
//                             ),
//                         },
//                         { label: 'Submitted On', value: request.submittedOn },
//                     ].map((item, i) => (
//                         <div key={i} className="col-12 md:col-4">
//                             <div className="flex flex-column gap-1 p-2 border-round surface-50">
//                                 <span className="detail-label text-400 text-xs font-medium uppercase">
//                                     {item.label}
//                                 </span>
//                                 <span className="text-800 text-sm font-medium">{item.value}</span>
//                             </div>
//                         </div>
//                     ))}

//                     {/* Reason — full width */}
//                     <div className="col-12">
//                         <div className="flex flex-column gap-1 p-2 border-round surface-50">
//                             <span className="detail-label text-400 text-xs font-medium uppercase">
//                                 Reason
//                             </span>
//                             <span className="text-800 text-sm">{request.reason}</span>
//                         </div>
//                     </div>

//                     {/* Attachment */}
//                     {request.attachment && (
//                         <div className="col-12">
//                             <Button
//                                 label="View Attached Document"
//                                 icon="pi pi-paperclip"
//                                 text
//                                 size="small"
//                                 className="p-0 text-primary"
//                             />
//                         </div>
//                     )}
//                 </div>

//                 {/* Already-decided notice */}
//                 {!isPending && (
//                     <Message
//                         severity={request.status === 'Approved' ? 'success' : 'error'}
//                         text={`This request has already been ${request.status.toLowerCase()}.`}
//                         icon={`pi ${request.status === 'Approved' ? 'pi-check-circle' : 'pi-times-circle'}`}
//                         className="w-full border-round-xl"
//                     />
//                 )}

//                 {/* Decision comment */}
//                 {isPending && (
//                     <>
//                         <Divider className="my-0" />
//                         <div className="flex flex-column gap-1">
//                             <label className="text-700 text-sm font-medium">
//                                 Comment <span className="text-400 font-normal">(optional)</span>
//                             </label>
//                             <InputTextarea
//                                 value={comment}
//                                 onChange={(e) => setComment(e.target.value)}
//                                 rows={3}
//                                 placeholder="Add a note for the employee…"
//                                 className="w-full"
//                                 maxLength={400}
//                             />
//                             <div className="flex justify-content-end">
//                                 <span className="text-400 text-xs">{comment.length}/400</span>
//                             </div>
//                         </div>
//                     </>
//                 )}
//             </div>
//         </Dialog>
//     );
// };

// // ─── Team Requests Tab ────────────────────────────────────────────────────────

// const TeamRequestsTab = ({ requests, onReview }) => {
//     const [statusFilter, setStatusFilter] = useState('Pending');
//     const [typeFilter, setTypeFilter] = useState(null);

//     const filtered = requests.filter((r) => {
//         if (statusFilter && statusFilter !== 'All' && r.status !== statusFilter) return false;
//         if (typeFilter && typeFilter !== 'All' && r.leaveType !== typeFilter) return false;
//         return true;
//     });

//     const pendingCount = requests.filter((r) => r.status === 'Pending').length;
//     const typeOptions = ['All', ...new Set(requests.map((r) => r.leaveType))];
//     const statusOptions = [
//         { label: `All (${requests.length})`, value: 'All' },
//         {
//             label: `Pending (${requests.filter((r) => r.status === 'Pending').length})`,
//             value: 'Pending',
//         },
//         {
//             label: `Approved (${requests.filter((r) => r.status === 'Approved').length})`,
//             value: 'Approved',
//         },
//         {
//             label: `Rejected (${requests.filter((r) => r.status === 'Rejected').length})`,
//             value: 'Rejected',
//         },
//     ];

//     const toolbarLeft = (
//         <div className="flex align-items-center gap-2">
//             <span className="font-semibold text-800">Team Leave Requests</span>
//             {pendingCount > 0 && (
//                 <Tag value={`${pendingCount} pending`} severity="warning" className="text-xs" />
//             )}
//         </div>
//     );
//     const toolbarRight = (
//         <Dropdown
//             placeholder="Leave Type"
//             options={typeOptions}
//             value={typeFilter}
//             onChange={(e) => setTypeFilter(e.value)}
//             className="w-10rem"
//             showClear
//         />
//     );

//     // ── Column body templates ─────────────────────────────────────────────────

//     const employeeTemplate = (row) => (
//         <div className="flex align-items-center gap-2">
//             <Avatar
//                 label={row.initials}
//                 size="normal"
//                 shape="circle"
//                 className={`avatar--${row.avatarKey} avatar--md`}
//             />
//             <div className="flex flex-column">
//                 <span className="font-semibold text-sm text-800">{row.employeeName}</span>
//                 <span className="text-xs text-500">{row.department}</span>
//             </div>
//         </div>
//     );

//     const leaveTypeTemplate = (row) => {
//         const v = resolveVisual(row.leaveTypeId);
//         return (
//             <div className="flex align-items-center gap-2">
//                 <span
//                     className={`lt-bubble lt-bubble--${v.cssKey} flex align-items-center justify-content-center border-circle flex-shrink-0`}
//                 >
//                     <i className={`${v.icon} text-xs`} />
//                 </span>
//                 <span className="text-sm">{row.leaveType}</span>
//             </div>
//         );
//     };

//     const datesTemplate = (row) => (
//         <div className="flex flex-column gap-1">
//             <span className="text-sm font-medium text-800">
//                 {row.dateFrom === row.dateTo ? row.dateFrom : `${row.dateFrom} – ${row.dateTo}`}
//             </span>
//             <Tag
//                 value={`${row.days} day${row.days > 1 ? 's' : ''}`}
//                 severity="info"
//                 className="days-tag"
//             />
//         </div>
//     );

//     const statusTemplate = (row) => (
//         <Tag value={row.status} severity={getStatusSeverity(row.status)} />
//     );

//     const actionsTemplate = (row) => (
//         <div className="flex gap-1 align-items-center">
//             {row.status === 'Pending' && (
//                 <>
//                     <Button
//                         icon="pi pi-check"
//                         rounded
//                         text
//                         severity="success"
//                         size="small"
//                         tooltip="Quick Approve"
//                         tooltipOptions={{ position: 'top' }}
//                         onClick={() => onReview(row, 'quick-approve')}
//                     />
//                     <Button
//                         icon="pi pi-times"
//                         rounded
//                         text
//                         severity="danger"
//                         size="small"
//                         tooltip="Quick Reject"
//                         tooltipOptions={{ position: 'top' }}
//                         onClick={() => onReview(row, 'quick-reject')}
//                     />
//                 </>
//             )}
//             <Button
//                 icon="pi pi-eye"
//                 rounded
//                 text
//                 severity="secondary"
//                 size="small"
//                 tooltip="View Details"
//                 tooltipOptions={{ position: 'top' }}
//                 onClick={() => onReview(row, 'detail')}
//             />
//         </div>
//     );

//     return (
//         <div className="flex flex-column gap-3">
//             <Toolbar
//                 start={toolbarLeft}
//                 end={toolbarRight}
//                 pt={{
//                     root: {
//                         className: 'surface-50 border-round-xl border-1 surface-border py-2 px-3',
//                     },
//                 }}
//             />
//             <div className="flex justify-content-center">
//                 <SelectButton
//                     value={statusFilter}
//                     options={statusOptions}
//                     onChange={(e) => e.value && setStatusFilter(e.value)}
//                     pt={{ button: { className: 'text-xs px-3 py-2' } }}
//                 />
//             </div>
//             <DataTable
//                 value={filtered}
//                 stripedRows
//                 showGridlines={false}
//                 responsiveLayout="scroll"
//                 scrollable
//                 emptyMessage={
//                     <div className="flex flex-column align-items-center gap-2 py-4">
//                         <i className="pi pi-inbox text-4xl text-300" />
//                         <span className="text-500">No requests match the selected filters</span>
//                     </div>
//                 }
//                 rowClassName={(row) => (row.status === 'Pending' ? 'font-medium' : '')}
//             >
//                 <Column header="Employee" body={employeeTemplate} style={{ minWidth: '180px' }} />
//                 <Column
//                     header="Leave Type"
//                     body={leaveTypeTemplate}
//                     style={{ minWidth: '150px' }}
//                 />
//                 <Column header="Dates" body={datesTemplate} style={{ minWidth: '160px' }} />
//                 <Column header="Status" body={statusTemplate} style={{ width: '120px' }} />
//                 <Column header="Actions" body={actionsTemplate} style={{ width: '130px' }} />
//             </DataTable>
//         </div>
//     );
// };

// // ─── Team Analytics Tab ───────────────────────────────────────────────────────

// const TeamAnalyticsTab = ({ requests }) => {
//     const total = requests.length;
//     const approved = requests.filter((r) => r.status === 'Approved').length;
//     const rejected = requests.filter((r) => r.status === 'Rejected').length;
//     const pending = requests.filter((r) => r.status === 'Pending').length;
//     const approvalRate = total > 0 ? Math.round((approved / (approved + rejected)) * 100) : 0;

//     const meterValues = [
//         {
//             label: 'Approved',
//             value: total > 0 ? Math.round((approved / total) * 100) : 0,
//             color: 'var(--green-500)',
//         },
//         {
//             label: 'Pending',
//             value: total > 0 ? Math.round((pending / total) * 100) : 0,
//             color: 'var(--yellow-500)',
//         },
//         {
//             label: 'Rejected',
//             value: total > 0 ? Math.round((rejected / total) * 100) : 0,
//             color: 'var(--red-500)',
//         },
//     ];

//     const byType = leaveTypes
//         .map((t) => ({
//             leaveType: t.label,
//             leaveTypeId: t.id,
//             total: requests.filter((r) => r.leaveTypeId === t.id).length,
//             approved: requests.filter((r) => r.leaveTypeId === t.id && r.status === 'Approved')
//                 .length,
//             pending: requests.filter((r) => r.leaveTypeId === t.id && r.status === 'Pending')
//                 .length,
//             rejected: requests.filter((r) => r.leaveTypeId === t.id && r.status === 'Rejected')
//                 .length,
//         }))
//         .filter((x) => x.total > 0);

//     const statCards = [
//         { label: 'Total Requests', value: total, icon: 'pi pi-inbox', mod: 'info' },
//         { label: 'Approved', value: approved, icon: 'pi pi-check-circle', mod: 'success' },
//         { label: 'Pending Review', value: pending, icon: 'pi pi-clock', mod: 'warning' },
//         { label: 'Rejected', value: rejected, icon: 'pi pi-times-circle', mod: 'danger' },
//     ];

//     const leaveTypeColTemplate = (row) => {
//         const v = resolveVisual(row.leaveTypeId);
//         return (
//             <div className="flex align-items-center gap-2">
//                 <i className={`${v.icon} text-sm lbc__icon lbc--${v.cssKey}`} />
//                 <span className="text-sm font-medium">{row.leaveType}</span>
//             </div>
//         );
//     };
//     const countTemplate = (field, severity) => (row) =>
//         row[field] > 0 ? (
//             <Tag value={row[field]} severity={severity} className="text-xs" />
//         ) : (
//             <span className="text-300 text-sm">—</span>
//         );

//     return (
//         <div className="flex flex-column gap-4">
//             <div className="flex align-items-center justify-content-between">
//                 <span className="font-semibold text-800">Team Overview</span>
//                 <span className="text-xs text-400">Year-to-date · {total} total requests</span>
//             </div>

//             {/* Stat tiles */}
//             <div className="grid">
//                 {statCards.map((s) => (
//                     <div key={s.mod} className="col-6 lg:col-3">
//                         <div
//                             className={`stat-tile stat-tile--${s.mod} flex flex-column gap-2 p-3 border-round-xl border-1 h-full`}
//                         >
//                             <div className="flex align-items-center justify-content-between">
//                                 <span className="text-xs font-medium stat-tile__label">
//                                     {s.label}
//                                 </span>
//                                 <i className={`${s.icon} text-xl stat-tile__icon`} />
//                             </div>
//                             <span className="stat-tile__value text-3xl font-bold">{s.value}</span>
//                         </div>
//                     </div>
//                 ))}
//             </div>

//             {/* Status distribution */}
//             <SimpleSectionCard title="Request Status Distribution">
//                 <div className="flex align-items-center gap-4 flex-wrap">
//                     <div className="flex-1">
//                         <MeterGroup values={meterValues} />
//                     </div>
//                     <Divider layout="vertical" className="mx-1 hidden md:flex" />
//                     <div className="flex flex-column align-items-center gap-1 flex-shrink-0">
//                         <Knob
//                             value={approvalRate}
//                             size={90}
//                             readOnly
//                             valueColor="var(--green-500)"
//                             rangeColor="var(--surface-300)"
//                             valueTemplate="{value}%"
//                             pt={{ value: { className: 'knob-value-text' } }}
//                         />
//                         <span className="text-xs text-500">Approval Rate</span>
//                     </div>
//                 </div>
//             </SimpleSectionCard>

//             {/* Breakdown by type */}
//             <SimpleSectionCard title="Breakdown by Leave Type">
//                 <DataTable value={byType} showGridlines={false} stripedRows size="small">
//                     <Column
//                         header="Leave Type"
//                         body={leaveTypeColTemplate}
//                         style={{ minWidth: '160px' }}
//                     />
//                     <Column field="total" header="Total" style={{ width: '80px' }} />
//                     <Column
//                         header="Approved"
//                         body={countTemplate('approved', 'success')}
//                         style={{ width: '100px' }}
//                     />
//                     <Column
//                         header="Pending"
//                         body={countTemplate('pending', 'warning')}
//                         style={{ width: '100px' }}
//                     />
//                     <Column
//                         header="Rejected"
//                         body={countTemplate('rejected', 'danger')}
//                         style={{ width: '100px' }}
//                     />
//                 </DataTable>
//             </SimpleSectionCard>
//         </div>
//     );
// };

// // ─── History Tab ──────────────────────────────────────────────────────────────

// const HistoryTab = ({ leaveTypes: types }) => {
//     const [statusFilter, setStatusFilter] = useState(null);
//     const [typeFilter, setTypeFilter] = useState(null);
//     const typeFilterOptions = ['All', ...types.map((t) => t.label)];

//     const filtered = leaveHistory.filter((r) => {
//         if (statusFilter && statusFilter !== 'All' && r.status !== statusFilter) return false;
//         if (typeFilter && typeFilter !== 'All' && r.type !== typeFilter) return false;
//         return true;
//     });

//     const STATUS_CHIPS = [
//         { label: 'Approved', mod: 'approved' },
//         { label: 'Pending', mod: 'pending' },
//         { label: 'Rejected', mod: 'rejected' },
//     ];

//     const statusTemplate = (row) => (
//         <Tag value={row.status} severity={getStatusSeverity(row.status)} className="text-sm" />
//     );
//     const actionTemplate = (row) => (
//         <div className="flex gap-1">
//             {row.status === 'Pending' && (
//                 <Button
//                     icon="pi pi-times"
//                     text
//                     rounded
//                     severity="danger"
//                     size="small"
//                     tooltip="Withdraw"
//                     tooltipOptions={{ position: 'top' }}
//                 />
//             )}
//             <Button
//                 icon="pi pi-ellipsis-v"
//                 text
//                 rounded
//                 severity="secondary"
//                 size="small"
//                 tooltip="More options"
//                 tooltipOptions={{ position: 'top' }}
//             />
//         </div>
//     );

//     return (
//         <>
//             <div className="flex align-items-center justify-content-between mb-2 flex-wrap gap-2">
//                 <h4 className="pl-2 m-0 font-semibold">Leave Request History</h4>
//                 <div className="flex gap-2 align-items-center flex-wrap">
//                     <Dropdown
//                         placeholder="All Statuses"
//                         options={['All', 'Pending', 'Approved', 'Rejected']}
//                         value={statusFilter}
//                         onChange={(e) => setStatusFilter(e.value)}
//                         className="w-10rem"
//                         showClear
//                     />
//                     <Dropdown
//                         placeholder="All Types"
//                         options={typeFilterOptions}
//                         value={typeFilter}
//                         onChange={(e) => setTypeFilter(e.value)}
//                         className="w-10rem"
//                         showClear
//                     />
//                 </div>
//             </div>
//             <div className="border-top-1 surface-border mb-3" />
//             <div className="flex gap-2 flex-wrap mb-3">
//                 {STATUS_CHIPS.map(({ label, mod }) => {
//                     const count = leaveHistory.filter((r) => r.status === label).length;
//                     const isActive = statusFilter === label;
//                     return (
//                         <span
//                             key={label}
//                             className={`status-chip status-chip--${mod}${isActive ? ' status-chip--active' : ''} px-3 py-1 border-round-lg border-1 text-sm cursor-pointer`}
//                             onClick={() => setStatusFilter(isActive ? null : label)}
//                         >
//                             {label}: <strong>{count}</strong>
//                         </span>
//                     );
//                 })}
//             </div>
//             <DataTable
//                 value={filtered}
//                 responsiveLayout="scroll"
//                 stripedRows
//                 showGridlines={false}
//                 emptyMessage="No leave requests match the selected filters."
//                 scrollable
//             >
//                 <Column field="type" header="Leave Type" />
//                 <Column field="dates" header="Dates Requested" />
//                 <Column field="reason" header="Reason" />
//                 <Column field="submitted" header="Submitted On" />
//                 <Column
//                     field="status"
//                     header="Status"
//                     body={statusTemplate}
//                     style={{ width: '140px' }}
//                 />
//                 <Column field="assignedTo" header="Coverage" />
//                 <Column header="Actions" body={actionTemplate} style={{ width: '100px' }} />
//             </DataTable>
//         </>
//     );
// };

// // ─── Calendar Tab ─────────────────────────────────────────────────────────────

// const CalendarTab = () => (
//     <div>
//         <div className="flex align-items-center justify-content-between mb-2">
//             <h4 className="pl-2 mt-2 mb-2 font-semibold">Calendar</h4>
//         </div>
//         <div className="border-top-1 surface-border mb-3" />
//         <div className="flex gap-4 flex-wrap">
//             <div className="cal-wrapper flex-1">
//                 <Calendar
//                     inline
//                     className="w-full"
//                     dateTemplate={(date) => {
//                         const approvedDays = [15, 16, 17, 18, 25];
//                         const upcomingDays = [10, 11, 12, 13, 14];
//                         if (approvedDays.includes(date.day) && date.month === 3)
//                             return <span className="cal-date cal-date--approved">{date.day}</span>;
//                         if (upcomingDays.includes(date.day) && date.month === 4)
//                             return <span className="cal-date cal-date--upcoming">{date.day}</span>;
//                         return date.day;
//                     }}
//                 />
//             </div>
//             <div className="flex flex-column gap-2 pt-2 cal-legend">
//                 <span className="font-semibold text-sm text-700 mb-1">Legend</span>
//                 {[
//                     { mod: 'approved', label: 'Approved Leave' },
//                     { mod: 'pending', label: 'Pending Leave' },
//                     { mod: 'upcoming', label: 'Upcoming Leave' },
//                     { mod: 'rejected', label: 'Rejected' },
//                 ].map((l) => (
//                     <div key={l.mod} className="flex align-items-center gap-2 text-sm text-700">
//                         <span
//                             className={`legend-dot legend-dot--${l.mod} border-circle flex-shrink-0`}
//                         />
//                         {l.label}
//                     </div>
//                 ))}
//             </div>
//         </div>
//     </div>
// );

// // ─── Holidays Tab ─────────────────────────────────────────────────────────────

// const HolidaysTab = () => (
//     <>
//         <div className="flex align-items-center justify-content-between mb-2">
//             <h4 className="pl-2 mt-2 mb-2 font-semibold">Holidays List</h4>
//             <span className="text-sm text-500">{companyHolidays.length} holidays this year</span>
//         </div>
//         <div className="border-top-1 surface-border mb-3" />
//         <div className="flex flex-column gap-2">
//             {companyHolidays.map((h, i) => {
//                 const isPast = i < 1;
//                 const mod = isPast ? 'past' : h.type.toLowerCase();
//                 return (
//                     <div
//                         key={i}
//                         className={`holiday-row holiday-row--${mod} flex align-items-center gap-3 px-3 py-2 border-round-lg border-1`}
//                     >
//                         <span
//                             className={`holiday-dot holiday-dot--${mod} border-circle flex-shrink-0`}
//                         />
//                         <div className="flex flex-column gap-1 flex-1">
//                             <div className="flex align-items-center gap-2 flex-wrap">
//                                 <span className="font-semibold text-sm text-800">{h.name}</span>
//                                 <span
//                                     className={`holiday-badge holiday-badge--${mod} px-2 py-1 border-round text-xs`}
//                                 >
//                                     {h.type}
//                                 </span>
//                                 {isPast && (
//                                     <span className="text-400 text-xs font-italic">Past</span>
//                                 )}
//                             </div>
//                             <span className="text-500 text-xs">{h.day}</span>
//                         </div>
//                         <span className="text-sm font-medium text-700 white-space-nowrap">
//                             {h.date}
//                         </span>
//                     </div>
//                 );
//             })}
//         </div>
//         <div className="flex align-items-center gap-2 mt-3 px-3 py-2 border-round border-1 surface-border surface-50">
//             <i className="pi pi-download text-primary text-sm" />
//             <span className="text-xs text-500">Need the full holiday calendar?</span>
//             <Button label="Download PDF" text size="small" className="p-0 ml-1 text-xs" />
//         </div>
//     </>
// );

// // ─── Main Page ────────────────────────────────────────────────────────────────

// const Leaves = () => {
//     const navigate = useNavigate();
//     const toast = useRef(null);

//     const [applyVisible, setApplyVisible] = useState(false);
//     const [activeTab, setActiveTab] = useState(0);
//     const [activeManagerTab, setActiveManagerTab] = useState(0);
//     const [reviewDialogOpen, setReviewDialogOpen] = useState(false);
//     const [selectedRequest, setSelectedRequest] = useState(null);
//     const [teamRequests, setTeamRequests] = useState(teamLeaveRequests);

//     const mergedLeaveData = mergeLeaveData(leaveTypes, employeeLeaveBalances);
//     const pendingTeamCount = teamRequests.filter((r) => r.status === 'Pending').length;

//     const breadcrumbItems = [
//         { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
//         {
//             label: 'Time & Attendance',
//             command: () => navigate('/web/landing/hrms/time-n-attendance'),
//         },
//         { label: 'Leaves' },
//     ];
//     const home = { icon: 'pi pi-home', command: () => navigate('/web/landing') };

//     const handleApplySubmit = (form) => {
//         setApplyVisible(false);
//         toast.current.show({
//             severity: 'success',
//             summary: 'Leave Submitted',
//             detail: `Your ${form.leaveType.label} leave request has been submitted.`,
//             life: 4000,
//         });
//     };

//     const handleDecision = ({ requestId, action, comment }) => {
//         setTeamRequests((prev) =>
//             prev.map((r) => (r.id === requestId ? { ...r, status: action } : r)),
//         );
//         setReviewDialogOpen(false);
//         setSelectedRequest(null);
//         toast.current.show({
//             severity: action === 'Approved' ? 'success' : 'warn',
//             summary: `Request ${action}`,
//             detail: `Leave request has been ${action.toLowerCase()}.${comment ? ` Note: "${comment}"` : ''}`,
//             life: 4000,
//         });
//     };

//     const handleReview = (row, mode) => {
//         if (mode === 'detail') {
//             setSelectedRequest(teamRequests.find((r) => r.id === row.id) || row);
//             setReviewDialogOpen(true);
//             return;
//         }
//         confirmDialog({
//             message: `${mode === 'quick-approve' ? 'Approve' : 'Reject'} ${row.employeeName}'s ${row.leaveType} request (${row.days} day${row.days > 1 ? 's' : ''})?`,
//             header: mode === 'quick-approve' ? 'Confirm Approval' : 'Confirm Rejection',
//             icon: mode === 'quick-approve' ? 'pi pi-check-circle' : 'pi pi-times-circle',
//             acceptClassName: mode === 'quick-approve' ? 'p-button-success' : 'p-button-danger',
//             rejectClassName: 'p-button-text',
//             accept: () =>
//                 handleDecision({
//                     requestId: row.id,
//                     action: mode === 'quick-approve' ? 'Approved' : 'Rejected',
//                     comment: '',
//                 }),
//         });
//     };

//     const employeeTabs = [
//         {
//             label: 'Request History',
//             icon: 'pi pi-list',
//             active: activeTab === 0,
//             onClick: () => setActiveTab(0),
//         },
//         {
//             label: 'My Calendar',
//             icon: 'pi pi-calendar',
//             active: activeTab === 1,
//             onClick: () => setActiveTab(1),
//         },
//         {
//             label: 'Holidays',
//             icon: 'pi pi-star',
//             active: activeTab === 2,
//             onClick: () => setActiveTab(2),
//         },
//     ];
//     const employeeTabActions = [
//         {
//             label: 'Apply Leave',
//             icon: 'pi pi-plus',
//             onClick: () => setApplyVisible(true),
//             className: 'p-button-xs p-button-primary',
//         },
//     ];
//     const managerTabs = [
//         {
//             label: 'Pending Approval',
//             icon: 'pi pi-clock',
//             active: activeManagerTab === 0,
//             onClick: () => setActiveManagerTab(0),
//         },
//         {
//             label: 'Team Overview',
//             icon: 'pi pi-chart-bar',
//             active: activeManagerTab === 1,
//             onClick: () => setActiveManagerTab(1),
//         },
//     ];

//     return (
//         <div className="leaves-page">
//             <Toast ref={toast} />
//             <ConfirmDialog />

//             <ApplyLeaveDialog
//                 visible={applyVisible}
//                 onHide={() => setApplyVisible(false)}
//                 onSubmit={handleApplySubmit}
//                 mergedLeaveData={mergedLeaveData}
//             />
//             <ReviewDialog
//                 visible={reviewDialogOpen}
//                 onHide={() => {
//                     setReviewDialogOpen(false);
//                     setSelectedRequest(null);
//                 }}
//                 request={selectedRequest}
//                 onDecision={handleDecision}
//             />

//             <div className="mb-3">
//                 <BreadCrumb model={breadcrumbItems} home={home} />
//             </div>

//             {/* Upcoming banner */}
//             {upcomingLeaves.length > 0 && (
//                 <div className="upcoming-banner flex align-items-center gap-3 flex-wrap px-3 py-2 border-round-lg mb-3 border-1">
//                     <i className="pi pi-calendar-plus text-xl flex-shrink-0 upcoming-banner__icon" />
//                     <div className="flex flex-column gap-1 flex-1">
//                         <span className="font-semibold text-sm upcoming-banner__title">
//                             LEAVE NOTIFICATIONS
//                         </span>
//                         <div className="flex gap-3 flex-wrap">
//                             {upcomingLeaves.map((l, i) => (
//                                 <span
//                                     key={i}
//                                     className="flex align-items-center gap-1 text-sm text-700"
//                                 >
//                                     <Tag
//                                         value={l.type}
//                                         severity={getStatusSeverity(l.status)}
//                                         className="text-xs"
//                                     />
//                                     {l.dates} ({l.days} day{l.days > 1 ? 's' : ''})
//                                 </span>
//                             ))}
//                         </div>
//                     </div>
//                 </div>
//             )}

//             {/* Leave Balance */}
//             <Card className="mt-2">
//                 <div className="flex align-items-center justify-content-between mb-3">
//                     <h4 className="m-0 font-semibold">Leave Balance</h4>
//                     <Button
//                         label="Apply Leave"
//                         icon="pi pi-plus"
//                         size="small"
//                         onClick={() => setApplyVisible(true)}
//                     />
//                 </div>
//                 <div className="border-top-1 surface-border mb-3" />
//                 <div className="grid mb-0">
//                     {mergedLeaveData.map((entry) => (
//                         <div key={entry.id} className="col-12 sm:col-6 lg:col-3">
//                             <LeaveBalanceCard entry={entry} />
//                         </div>
//                     ))}
//                 </div>
//                 <div className="flex align-items-center gap-2 mt-3 px-3 py-2 border-round border-1 surface-border surface-50">
//                     <i className="pi pi-info-circle text-400 text-sm flex-shrink-0" />
//                     <span className="text-xs text-500">ANY NOTICE COMES HERE!</span>
//                 </div>
//             </Card>

//             {/* Employee tabs */}
//             <div className="mt-4">
//                 <TabbedSectionCard tabs={employeeTabs}>
//                     {activeTab === 0 && <HistoryTab leaveTypes={leaveTypes} />}
//                     {activeTab === 1 && <CalendarTab />}
//                     {activeTab === 2 && <HolidaysTab />}
//                 </TabbedSectionCard>
//             </div>

//             {/* Manager Section */}
//             {currentUser.isManager && (
//                 <div className="mt-4">
//                     <div className="flex align-items-center justify-content-between mb-3 flex-wrap gap-2">
//                         <div className="flex align-items-center gap-3">
//                             <div className="manager-icon-wrap flex align-items-center justify-content-center border-circle bg-primary">
//                                 <i className="pi pi-users text-white text-lg" />
//                             </div>
//                             <div>
//                                 <div className="font-bold text-900 text-lg">
//                                     Team Leave Approvals
//                                 </div>
//                                 <div className="text-500 text-sm">
//                                     Review and action requests from your direct and indirect reports
//                                 </div>
//                             </div>
//                         </div>
//                         {pendingTeamCount > 0 && (
//                             <Message
//                                 severity="warn"
//                                 icon="pi pi-clock"
//                                 text={`${pendingTeamCount} request${pendingTeamCount > 1 ? 's' : ''} awaiting your review`}
//                                 className="border-round-xl pending-message"
//                             />
//                         )}
//                     </div>
//                     <TabbedSectionCard tabs={managerTabs}>
//                         {activeManagerTab === 0 && (
//                             <TeamRequestsTab requests={teamRequests} onReview={handleReview} />
//                         )}
//                         {activeManagerTab === 1 && <TeamAnalyticsTab requests={teamRequests} />}
//                     </TabbedSectionCard>
//                 </div>
//             )}
//         </div>
//     );
// };

// export default Leaves;
