// src/hrms/components/OnboardingCandidateCreateView.jsx
import React, { useRef, useState } from 'react';
import { useNavigate } from 'react-router';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Toast } from 'primereact/toast';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Divider } from 'primereact/divider';
import { Message } from 'primereact/message';
import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';
import { useCreateCandidateWithOnboarding } from '../hooks/useCreateCandidateWithOnboarding';
import { useCreateWorkflowInstance } from '../hooks/useCreateWorkflowInstance';
import { useGetTenantIds } from '../hooks/useGetTenantIds';

// Initial form state
const INITIAL_FORM_DATA = {
    // Basic Information
    candidateCode: '',
    fullName: '',
    firstName: '',
    lastName: '',
    gender: '',
    dateOfBirth: null,

    // Recruitment specific
    applicationDate: new Date(),
    expectedJoinDate: null,
    source: '',
    applicationData: '',
    status: 'APPLIED',

    // Contact Information
    cellNumber: '',
    personalEmail: '',
    currentAddress: '',

    // Organizational (tentative) - UUIDs
    company: '',
    tentativeDepartment: '',
    tentativeDesignation: '',
    tentativeEmploymentType: '',
    tentativeReportingTo: '',

    // Multi-tenancy & Audit
    tenantId: '',
    tenantRole: '',
    module: 'HRMS',
};

// Dropdown options
const GENDER_OPTIONS = [
    { label: 'Male', value: 'Male' },
    { label: 'Female', value: 'Female' },
    { label: 'Other', value: 'Other' },
];

const SOURCE_OPTIONS = [
    { label: 'Naukri', value: 'NAUKRI' },
    { label: 'LinkedIn', value: 'LINKEDIN' },
    { label: 'Referral', value: 'REFERRAL' },
    { label: 'Campus', value: 'CAMPUS' },
    { label: 'Company Website', value: 'WEBSITE' },
    { label: 'Walk-in', value: 'WALKIN' },
    { label: 'Other', value: 'OTHER' },
];

const STATUS_OPTIONS = [
    { label: 'Applied', value: 'APPLIED' },
    { label: 'Screening', value: 'SCREENING' },
    { label: 'Interview', value: 'INTERVIEW' },
    { label: 'Selected', value: 'SELECTED' },
    { label: 'Offer Extended', value: 'OFFER_EXTENDED' },
];

const INITIAL_ATTACHMENTS = [
    {
        srNo: 1,
        documentName: 'Resume/CV',
        documentDescriptionType: 'dropdown',
        documents: [
            { label: 'PDF', value: 'pdf' },
            { label: 'Word Document', value: 'doc' },
        ],
        selectedDoc: 'pdf',
        files: [],
        multiple: false,
    },
    {
        srNo: 2,
        documentName: 'Identity Proof',
        documentDescriptionType: 'dropdown',
        documents: [
            { label: 'Aadhar Card', value: 'aadhar' },
            { label: 'Passport', value: 'passport' },
            { label: 'Driving License', value: 'license' },
        ],
        selectedDoc: 'aadhar',
        files: [],
        multiple: true,
    },
];

const OnboardingCandidateCreateView = () => {
    const toast = useRef(null);
    const navigate = useNavigate();
    // 1. Ensure you destructure 'tenants' (the data) and not 'fet'
    const { tenants, isLoading: isTenantsLoading } = useGetTenantIds();

    // 2. Map the options (tenants will be an empty array [] by default from the hook)
    const tenantOptions = tenants.map((t) => ({
        label: t.description || t.name || t.id, // 'description' gives human-readable names like "Bharat Electronics Limited"
        value: t.id, // ✅ fix: was t.tenantId, should be t.id
    }));

    // Form state
    const [formData, setFormData] = useState(INITIAL_FORM_DATA);
    const [workflowInstanceId, setWorkflowInstanceId] = useState('');
    const [attachments, setAttachments] = useState(INITIAL_ATTACHMENTS);
    const [errors, setErrors] = useState({});

    // UI state
    const [activeTab, setActiveTab] = useState('basic');

    // Create hook
    const { createCandidate, isPending } = useCreateCandidateWithOnboarding();
    const { createWorkflowInstance, isPending: isWfCreating } = useCreateWorkflowInstance();

    // Breadcrumb items
    const breadcrumbItems = [
        {
            label: 'HRMS',
            command: () => navigate('/web/landing/hrms'),
        },
        {
            label: 'Onboarding',
            command: () => navigate('/web/landing/hrms/onboarding'),
        },
        {
            label: 'Create Candidate',
        },
    ];

    const home = {
        icon: 'pi pi-home',
        command: () => navigate('/'),
    };

    // Tabs configuration
    const tabs = [
        {
            label: 'Basic Info',
            icon: 'pi pi-user',
            active: activeTab === 'basic',
            onClick: () => setActiveTab('basic'),
        },
        {
            label: 'Organization',
            icon: 'pi pi-building',
            active: activeTab === 'organization',
            onClick: () => setActiveTab('organization'),
        },
    ];

    // Toast helper
    const showToast = (severity, summary, detail) => {
        toast.current?.show({ severity, summary, detail, life: 3000 });
    };

    // Navigation
    const handleBack = () => navigate(-1);

    // Form field change handler
    const handleInputChange = (field, value) => {
        setFormData((prev) => ({
            ...prev,
            [field]: value,
        }));
        // Clear error when field is modified
        if (errors[field]) {
            setErrors((prev) => ({ ...prev, [field]: null }));
        }
    };

    // Auto-generate full name from first and last name
    const handleNameChange = (field, value) => {
        setFormData((prev) => {
            const updated = { ...prev, [field]: value };
            if (field === 'firstName' || field === 'lastName') {
                updated.fullName = `${updated.firstName} ${updated.lastName}`.trim();
            }
            return updated;
        });
        if (errors[field]) {
            setErrors((prev) => ({ ...prev, [field]: null }));
        }
    };

    // Format date to LocalDate string (YYYY-MM-DD)
    const formatDate = (date) => {
        if (!date) return null;
        const d = new Date(date);
        return d.toISOString().split('T')[0];
    };

    // Validation
    const validateForm = () => {
        const newErrors = {};

        if (!formData.firstName?.trim()) {
            newErrors.firstName = 'First name is required';
        }
        if (!formData.personalEmail?.trim()) {
            newErrors.personalEmail = 'Email is required';
        } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.personalEmail)) {
            newErrors.personalEmail = 'Invalid email format';
        }
        if (!formData.applicationDate) {
            newErrors.applicationDate = 'Application date is required';
        }
        if (!formData.tenantId?.trim()) {
            newErrors.tenantId = 'Tenant ID is required';
        }
        if (!formData.dateOfBirth) {
            newErrors.dateOfBirth = 'Date of birth is required';
        }
        if (!formData.cellNumber?.trim()) {
            newErrors.cellNumber = 'Mobile number is required';
        } else if (!/^\d{10}$/.test(formData.cellNumber)) {
            newErrors.cellNumber = 'Mobile number must be exactly 10 digits';
        }

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    };

    // Build candidate object for API
    const buildCandidatePayload = () => {
        return {
            // Basic Information
            candidateCode: formData.candidateCode || null,
            fullName: formData.fullName || `${formData.firstName} ${formData.lastName}`.trim(),
            firstName: formData.firstName,
            lastName: formData.lastName || null,
            gender: formData.gender || null,
            dateOfBirth: formatDate(formData.dateOfBirth),

            // Recruitment specific
            applicationDate: formatDate(formData.applicationDate),
            expectedJoinDate: formatDate(formData.expectedJoinDate),
            source: formData.source || null,
            applicationData: formData.applicationData || null,
            status: formData.status || 'APPLIED',

            // Contact Information
            cellNumber: formData.cellNumber || null,
            personalEmail: formData.personalEmail,
            currentAddress: formData.currentAddress || null,

            // Organizational (tentative) - only include if valid UUID
            company: formData.company || null,
            tentativeDepartment: formData.tentativeDepartment || null,
            tentativeDesignation: formData.tentativeDesignation || null,
            tentativeEmploymentType: formData.tentativeEmploymentType || null,
            tentativeReportingTo: formData.tentativeReportingTo || null,

            // Multi-tenancy & Audit
            tenantId: formData.tenantId,
            tenantRole: formData.tenantRole || null,
            module: formData.module || 'HRMS',
            validFrom: null,
            validUpto: null,
            revId: null,
        };
    };

    // Submit handler
    const handleSubmit = async () => {
        if (!validateForm()) {
            showToast('warn', 'Validation Error', 'Please fill all required fields');
            return;
        }

        try {
            /** STEP 1: Create Workflow Instance */
            const wfResponse = await createWorkflowInstance({
                workFlowDef: 'ONBOARDING_WF',
                action: 'OPEN',
                // tenantRoleAndTenantMap: {
                //     'COMPANY.UNIT': formData.tenantId,
                // },
            });

            const wfInstanceId = wfResponse?.uuid;

            if (!wfInstanceId) {
                throw new Error('Workflow instance creation failed');
            }

            setWorkflowInstanceId(wfInstanceId);

            /** STEP 2: Build Candidate Payload */
            const candidate = buildCandidatePayload();

            /** STEP 3: Create Candidate with WF Instance ID */
            await createCandidate({
                candidate,
                workflowInstanceId: wfInstanceId,
            });

            showToast('success', 'Success', 'Candidate created successfully!');

            setTimeout(() => {
                navigate('/web/landing/hrms/onboarding', { replace: true });
            }, 1500);
        } catch (err) {
            console.error('Create failed:', err);
            showToast('error', 'Creation Failed', err?.message || 'Unable to create candidate');
        }
    };

    // Reset form
    const handleReset = () => {
        setFormData(INITIAL_FORM_DATA);
        setWorkflowInstanceId('');
        setAttachments(INITIAL_ATTACHMENTS);
        setErrors({});
        showToast('info', 'Reset', 'Form has been reset');
    };

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />

            {/* Breadcrumb */}
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {/* Main Content Card */}
            <PageContentCard padding="md" rounded="lg" shadow="sm">
                {/* Header */}
                <div className="flex align-items-center justify-content-between mt-1 mb-1 px-3 py-1">
                    {/* LEFT SIDE */}
                    <div className="flex align-items-center gap-3">
                        <Button icon="pi pi-arrow-left" text rounded onClick={handleBack} />
                        <div className="flex align-items-center gap-3">
                            <h4 className="m-0 text-2xl font-semibold">Create New Candidate</h4>
                            <i className="pi pi-user-plus text-primary text-xl" />
                        </div>
                    </div>

                    {/* RIGHT SIDE – Actions */}
                    <div className="flex align-items-center gap-2">
                        <Button
                            label="Cancel"
                            icon="pi pi-times"
                            outlined
                            size="small"
                            severity="secondary"
                            onClick={handleBack}
                            disabled={isPending}
                        />
                        <Button
                            label="Reset Form"
                            icon="pi pi-refresh"
                            outlined
                            size="small"
                            onClick={handleReset}
                            disabled={isPending}
                        />
                        <Button
                            label="Create Candidate"
                            icon="pi pi-check"
                            severity="success"
                            size="small"
                            onClick={handleSubmit}
                            loading={isPending || isWfCreating}
                        />
                        {/* <Button
                            label="Reset"
                            icon="pi pi-refresh"
                            outlined
                            severity="secondary"
                            onClick={handleReset}
                            disabled={isPending}
                            size="small"
                        />
                        <Button
                            label="Create Candidate"
                            icon="pi pi-check"
                            severity="success"
                            onClick={handleSubmit}
                            loading={isPending}
                            size="small"
                        /> */}
                    </div>
                </div>

                {/* Divider Line */}
                <div className="border-top-1 surface-border mb-1" />

                {/* TABBED SECTION CARD */}
                <TabbedSectionCard tabs={tabs} transparentBorder={true}>
                    {/* TAB: Basic Info */}
                    {activeTab === 'basic' && (
                        <div className="flex flex-column gap-4">
                            {/* Personal Information */}
                            <SectionCardWithHeader title="Personal Information">
                                <div className="sc-grid-2">
                                    <div>
                                        <label className="block text-600 mb-1">
                                            First Name <span className="text-red-500">*</span>
                                        </label>
                                        <InputText
                                            value={formData.firstName}
                                            onChange={(e) =>
                                                handleNameChange('firstName', e.target.value)
                                            }
                                            placeholder="Enter first name"
                                            className={`w-full ${errors.firstName ? 'p-invalid' : ''}`}
                                        />
                                        {errors.firstName && (
                                            <small className="p-error">{errors.firstName}</small>
                                        )}
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Last Name</label>
                                        <InputText
                                            value={formData.lastName}
                                            onChange={(e) =>
                                                handleNameChange('lastName', e.target.value)
                                            }
                                            placeholder="Enter last name"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Full Name</label>
                                        <InputText
                                            value={formData.fullName}
                                            onChange={(e) =>
                                                handleInputChange('fullName', e.target.value)
                                            }
                                            placeholder="Auto-generated from first & last name"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Candidate Code
                                        </label>
                                        <InputText
                                            value={formData.candidateCode}
                                            onChange={(e) =>
                                                handleInputChange('candidateCode', e.target.value)
                                            }
                                            placeholder="e.g., CAND-001"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Gender</label>
                                        <Dropdown
                                            value={formData.gender}
                                            options={GENDER_OPTIONS}
                                            onChange={(e) => handleInputChange('gender', e.value)}
                                            placeholder="Select gender"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Date of Birth <span className="text-red-500">*</span>
                                        </label>
                                        <Calendar
                                            value={formData.dateOfBirth}
                                            onChange={(e) =>
                                                handleInputChange('dateOfBirth', e.value)
                                            }
                                            dateFormat="dd/mm/yy"
                                            showIcon
                                            placeholder="Select date"
                                            className={`w-full ${errors.dateOfBirth ? 'p-invalid' : ''}`}
                                            maxDate={new Date()}
                                        />
                                        {errors.applicationDate && (
                                            <small className="p-error">
                                                {errors.applicationDate}
                                            </small>
                                        )}
                                    </div>
                                </div>
                            </SectionCardWithHeader>

                            {/* Contact Information */}
                            <SectionCardWithHeader title="Contact Information">
                                <div className="sc-grid-2">
                                    <div>
                                        <label className="block text-600 mb-1">
                                            Personal Email <span className="text-red-500">*</span>
                                        </label>
                                        <InputText
                                            value={formData.personalEmail}
                                            onChange={(e) =>
                                                handleInputChange('personalEmail', e.target.value)
                                            }
                                            placeholder="candidate@email.com"
                                            className={`w-full ${errors.personalEmail ? 'p-invalid' : ''}`}
                                            keyfilter="email"
                                        />
                                        {errors.personalEmail && (
                                            <small className="p-error">
                                                {errors.personalEmail}
                                            </small>
                                        )}
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Mobile Number <span className="text-red-500">*</span>
                                        </label>
                                        <InputText
                                            value={formData.cellNumber}
                                            onChange={(e) =>
                                                handleInputChange('cellNumber', e.target.value)
                                            }
                                            placeholder="10-digit mobile number"
                                            className={`w-full ${errors.cellNumber ? 'p-invalid' : ''}`}
                                            keyfilter="num" // Restricts input to numbers only
                                            maxLength={10} // Prevents typing more than 10 digits
                                        />
                                        {errors.cellNumber && (
                                            <small className="p-error">{errors.cellNumber}</small>
                                        )}
                                    </div>

                                    <div className="sc-span-2">
                                        <label className="block text-600 mb-1">
                                            Current Address
                                        </label>
                                        <InputTextarea
                                            value={formData.currentAddress}
                                            onChange={(e) =>
                                                handleInputChange('currentAddress', e.target.value)
                                            }
                                            placeholder="Enter current address"
                                            rows={3}
                                            className="w-full"
                                            autoResize
                                        />
                                    </div>
                                </div>
                            </SectionCardWithHeader>

                            {/* Application Details */}
                            <SectionCardWithHeader title="Application Details">
                                <div className="sc-grid-2">
                                    <div>
                                        <label className="block text-600 mb-1">
                                            Application Date <span className="text-red-500">*</span>
                                        </label>
                                        <Calendar
                                            value={formData.applicationDate}
                                            onChange={(e) =>
                                                handleInputChange('applicationDate', e.value)
                                            }
                                            dateFormat="dd/mm/yy"
                                            showIcon
                                            placeholder="Select date"
                                            className={`w-full ${errors.applicationDate ? 'p-invalid' : ''}`}
                                        />
                                        {errors.applicationDate && (
                                            <small className="p-error">
                                                {errors.applicationDate}
                                            </small>
                                        )}
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Expected Join Date
                                        </label>
                                        <Calendar
                                            value={formData.expectedJoinDate}
                                            onChange={(e) =>
                                                handleInputChange('expectedJoinDate', e.value)
                                            }
                                            dateFormat="dd/mm/yy"
                                            showIcon
                                            placeholder="Select expected joining date"
                                            className="w-full"
                                            minDate={new Date()}
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Source</label>
                                        <Dropdown
                                            value={formData.source}
                                            options={SOURCE_OPTIONS}
                                            onChange={(e) => handleInputChange('source', e.value)}
                                            placeholder="Select source"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Status</label>
                                        <Dropdown
                                            value={formData.status}
                                            options={STATUS_OPTIONS}
                                            onChange={(e) => handleInputChange('status', e.value)}
                                            placeholder="Select status"
                                            className="w-full"
                                        />
                                    </div>

                                    <div className="sc-span-2">
                                        <label className="block text-600 mb-1">
                                            Application Notes
                                        </label>
                                        <InputTextarea
                                            value={formData.applicationData}
                                            onChange={(e) =>
                                                handleInputChange('applicationData', e.target.value)
                                            }
                                            placeholder="Any additional notes about the application..."
                                            rows={3}
                                            className="w-full"
                                            autoResize
                                        />
                                    </div>
                                </div>
                            </SectionCardWithHeader>
                        </div>
                    )}

                    {/* TAB: Organization */}
                    {activeTab === 'organization' && (
                        <div className="flex flex-column gap-4">
                            <Message
                                severity="info"
                                text="These are tentative assignments. Final assignments will be made during onboarding process."
                                className="mb-3"
                            />

                            <SectionCardWithHeader title="Tentative Organization Details">
                                <div className="sc-grid-2">
                                    <div>
                                        <label className="block text-600 mb-1">Company ID</label>
                                        <InputText
                                            value={formData.company}
                                            onChange={(e) =>
                                                handleInputChange('company', e.target.value)
                                            }
                                            placeholder="Enter company UUID"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Department ID</label>
                                        <InputText
                                            value={formData.tentativeDepartment}
                                            onChange={(e) =>
                                                handleInputChange(
                                                    'tentativeDepartment',
                                                    e.target.value,
                                                )
                                            }
                                            placeholder="Enter department UUID"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Designation ID
                                        </label>
                                        <InputText
                                            value={formData.tentativeDesignation}
                                            onChange={(e) =>
                                                handleInputChange(
                                                    'tentativeDesignation',
                                                    e.target.value,
                                                )
                                            }
                                            placeholder="Enter designation UUID"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Employment Type ID
                                        </label>
                                        <InputText
                                            value={formData.tentativeEmploymentType}
                                            onChange={(e) =>
                                                handleInputChange(
                                                    'tentativeEmploymentType',
                                                    e.target.value,
                                                )
                                            }
                                            placeholder="Enter employment type UUID"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">
                                            Reporting To ID
                                        </label>
                                        <InputText
                                            value={formData.tentativeReportingTo}
                                            onChange={(e) =>
                                                handleInputChange(
                                                    'tentativeReportingTo',
                                                    e.target.value,
                                                )
                                            }
                                            placeholder="Enter reporting manager UUID"
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label className="block text-600 mb-1">Tenant Role</label>
                                        <InputText
                                            value={formData.tenantRole}
                                            onChange={(e) =>
                                                handleInputChange('tenantRole', e.target.value)
                                            }
                                            placeholder="Enter tenant role"
                                            className="w-full"
                                        />
                                    </div>
                                    <div>
                                        <label className="block text-600 mb-1">
                                            Tenant ID <span className="text-red-500">*</span>
                                        </label>
                                        <Dropdown
                                            value={formData.tenantId}
                                            options={tenantOptions}
                                            onChange={(e) => handleInputChange('tenantId', e.value)}
                                            placeholder={
                                                isTenantsLoading
                                                    ? 'Loading tenants...'
                                                    : 'Select Tenant'
                                            }
                                            loading={isTenantsLoading}
                                            filter // Adds a search bar inside the dropdown
                                            className={`w-full ${errors.tenantId ? 'p-invalid' : ''}`}
                                        />
                                        {errors.tenantId && (
                                            <small className="p-error">{errors.tenantId}</small>
                                        )}
                                    </div>
                                </div>
                            </SectionCardWithHeader>
                        </div>
                    )}
                </TabbedSectionCard>

                {/* Bottom Action Bar */}
                {/* <Divider />
                <div className="flex justify-content-end gap-2 px-3 pb-3">
                    <Button
                        label="Cancel"
                        icon="pi pi-times"
                        outlined
                        severity="secondary"
                        onClick={handleBack}
                        disabled={isPending}
                    />
                    <Button
                        label="Reset Form"
                        icon="pi pi-refresh"
                        outlined
                        onClick={handleReset}
                        disabled={isPending}
                    />
                    <Button
                        label="Create Candidate"
                        icon="pi pi-check"
                        severity="success"
                        onClick={handleSubmit}
                        loading={isPending}
                    />
                </div> */}
            </PageContentCard>
        </div>
    );
};

export default OnboardingCandidateCreateView;
