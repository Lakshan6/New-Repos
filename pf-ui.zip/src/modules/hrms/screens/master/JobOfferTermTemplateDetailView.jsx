// src/pages/hrms/job-offer-term-template/JobOfferTermTemplateDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useJobOfferTermTemplateDetail from '../../hooks/master/useJobOfferTermTemplateDetail';
import useUpdateJobOfferTermTemplate from '../../hooks/master/useUpdateJobOfferTermTemplate';

const JobOfferTermTemplateDetailView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);

    const templateId = location.state?.templateId;

    const { data, isLoading, isError, error, refetch } = useJobOfferTermTemplateDetail(templateId);
    const { mutate: updateTemplate, isLoading: isSaving } = useUpdateJobOfferTermTemplate();

    const [formData, setFormData] = useState({
        templateName: '',
        tenantId: '',
        tenantRole: '',
        module: '',
        validFrom: null,
        validUpto: null,
    });

    const [originalFormData, setOriginalFormData] = useState({});
    const [isEditing, setIsEditing] = useState(false);
    const [hasInitialized, setHasInitialized] = useState(false);

    useEffect(() => {
        if (!templateId) {
            toast.current?.show({
                severity: 'warn',
                summary: 'No Template Selected',
                detail: 'Please select a job offer term template from the list',
                life: 4000,
            });
            navigate('/web/landing/hrms/job-offer-term-template', { replace: true });
        }
    }, [templateId, navigate]);

    useEffect(() => {
        if (data && !hasInitialized) {
            const initialData = {
                templateName: data.templateName ?? '',
                tenantId: data.tenantId ?? '',
                tenantRole: data.tenantRole ?? '',
                module: data.module ?? '',
                validFrom: data.validFrom,
                validUpto: data.validUpto,
            };
            setFormData(initialData);
            setOriginalFormData(initialData);
            setHasInitialized(true);
        }
    }, [data, hasInitialized]);

    const handleBack = () => navigate(-1);

    const handleInputChange = (field, value) => {
        setFormData((prev) => ({ ...prev, [field]: value }));
    };

    const handleEdit = () => setIsEditing(true);

    const handleCancel = () => {
        setFormData({ ...originalFormData });
        setIsEditing(false);
        toast.current?.show({
            severity: 'info',
            summary: 'Cancelled',
            detail: 'Changes reverted',
            life: 3000,
        });
    };

    const handleSave = () => {
        if (!templateId) return;

        const payload = {
            templateName: formData.templateName.trim(),
            module: formData.module?.trim() || '',
            validFrom: formData.validFrom ? formData.validFrom.toISOString() : null,
            validUpto: formData.validUpto ? formData.validUpto.toISOString() : null,
        };

        updateTemplate(
            { id: templateId, payload },
            {
                onSuccess: () => {
                    toast.current?.show({
                        severity: 'success',
                        summary: 'Updated',
                        detail: 'Job offer term template updated successfully',
                        life: 3000,
                    });
                    setIsEditing(false);
                    refetch();
                },
                onError: (err) => {
                    toast.current?.show({
                        severity: 'error',
                        summary: 'Update Failed',
                        detail: err?.message || 'Unable to update template',
                        life: 4000,
                    });
                },
            }
        );
    };

    if (isLoading) {
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <ProgressSpinner />
                        <p className="mt-3 text-500">Loading template details...</p>
                    </div>
                </PageContentCard>
            </div>
        );
    }

    if (isError || !data) {
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                        <h2>Unable to load job offer term template</h2>
                        <p className="text-600 mb-4">
                            {error?.message || 'Template not found or invalid access'}
                        </p>
                        <div className="flex gap-3">
                            <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={handleBack} />
                            <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                        </div>
                    </div>
                </PageContentCard>
            </div>
        );
    }

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Job Offer Term Templates', command: () => navigate('/web/landing/hrms/job-offer-term-template') },
        { label: 'Details' },
    ];

    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />

            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <PageContentCard padding="md" rounded="lg" shadow="sm">
                <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
                    <div className="flex align-items-center gap-4">
                        <Button icon="pi pi-arrow-left" text rounded onClick={handleBack} />
                        <h4 className="m-0 text-2xl font-semibold">Job Offer Term Template Details</h4>
                        {templateId && (
                            <Button
                                size="small"
                                label={templateId}
                                severity="secondary"
                                rounded
                                onClick={() => navigator.clipboard.writeText(templateId)}
                                tooltip="Copy ID"
                            />
                        )}
                    </div>

                    <div className="flex align-items-center gap-2">
                        {isEditing ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="danger"
                                    onClick={handleCancel}
                                    disabled={isSaving}
                                    size="small"
                                />
                                <Button
                                    label="Save"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isSaving}
                                    disabled={isSaving}
                                    size="small"
                                />
                            </>
                        ) : (
                            <Button
                                label="Edit"
                                icon="pi pi-pencil"
                                outlined
                                onClick={handleEdit}
                                size="small"
                            />
                        )}
                    </div>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <TabbedSectionCard transparentBorder>
                    <SectionCardWithHeader
                        title="Template Information"
                        subtitle={formData.templateName || '—'}
                    >
                        <div className="sc-grid-2 gap-4">
                            <div>
                                <label className="block text-600 mb-1">Template Name</label>
                                <InputText
                                    value={formData.templateName}
                                    onChange={(e) => handleInputChange('templateName', e.target.value)}
                                    disabled={!isEditing}
                                    className="w-full"
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Module</label>
                                <InputText
                                    value={formData.module}
                                    onChange={(e) => handleInputChange('module', e.target.value)}
                                    disabled={!isEditing}
                                    className="w-full"
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid From</label>
                                <Calendar
                                    value={formData.validFrom}
                                    onChange={(e) => handleInputChange('validFrom', e.value)}
                                    disabled={!isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid Upto</label>
                                <Calendar
                                    value={formData.validUpto}
                                    onChange={(e) => handleInputChange('validUpto', e.value)}
                                    disabled={!isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Tenant ID</label>
                                <InputText
                                    value={formData.tenantId}
                                    disabled
                                    className="w-full bg-gray-100"
                                />
                            </div>


                        </div>
                    </SectionCardWithHeader>
                </TabbedSectionCard>
            </PageContentCard>
        </div>
    );
};

export default JobOfferTermTemplateDetailView;