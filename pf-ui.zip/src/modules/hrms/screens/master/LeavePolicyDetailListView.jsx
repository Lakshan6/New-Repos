import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeavePolicyDetailList from '../../hooks/master/useLeavePolicyDetailList';

const LeavePolicyDetailListView = () => {
  const navigate = useNavigate();

  const {
    data: policyDetails = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeavePolicyDetailList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredDetails = searchTerm.trim()
    ? policyDetails.filter(item =>
        item.leaveTypeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : policyDetails;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Policy Details' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Leave Type',
      name: 'leaveTypeName',
      placeholder: 'e.g. Casual Leave, Sick Leave, Earned Leave',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.leaveTypeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(
      2,
      '0'
    )}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Policy Details</h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/leave-policy-detail/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredDetails}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load data'}`
              : 'No policy details found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-policy-detail/detail', {
              state: { detailId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="leaveTypeName" header="Leave Type" sortable />
          <Column field="leavePolicyName" header="Policy Name" sortable />
          <Column field="annualAllocation" header="Annual Allocation" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeavePolicyDetailListView;