// src/pages/hrms/interview-type/InterviewTypeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useInterviewTypeList from '../../hooks/master/useInterviewTypeList';

const InterviewTypeListView = () => {
  const navigate = useNavigate();

  const {
    data: interviewTypes = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useInterviewTypeList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredTypes = searchTerm.trim()
    ? interviewTypes.filter(item =>
        item.interviewTypeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : interviewTypes;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Interview Types' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Interview Type',
      name: 'interviewTypeName',
      placeholder: 'e.g. Technical, HR Round, Managerial',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.interviewTypeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Interview Types</h4>
          <Button
            label="Add New Interview Type"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/interview-type/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredTypes}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load interview types'}` : 'No interview types found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/interview-type/detail', {
              state: { interviewTypeId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="interviewTypeName" header="Interview Type" sortable />
          <Column field="description" header="Description" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default InterviewTypeListView;