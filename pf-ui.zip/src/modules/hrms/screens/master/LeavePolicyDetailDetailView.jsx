
// src/pages/hrms/leave-policy-detail/LeavePolicyDetailDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useLeavePolicyDetail from '../../hooks/master/useLeavePolicyDetailDetails';
import { useLeavePolicyList } from '../../hooks/master/useLeavePolicyList';
import { useLeaveTypeList } from '../../hooks/master/useLeaveTypeList';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const LeavePolicyDetailDetailView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);

    const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
    const detailId = location.state?.detailId;
    const isCreateMode = location.pathname.endsWith('/create');

    const {
        leavePolicyDetail: data,
        isLoading,
        isError,
        error,
        refetch,
        createLeavePolicyDetail,
        updateLeavePolicyDetail,
        deleteLeavePolicyDetail,
        isCreating,
        isUpdating,
        isDeleting,
        mutationError,
    } = useLeavePolicyDetail({ id: isCreateMode ? null : detailId, userInfo });

    const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });
    const { data: leavePolicies = [], isLoading: isPoliciesLoading } = useLeavePolicyList();
    const { data: leaveTypes = [], isLoading: isTypesLoading } = useLeaveTypeList();

    const [formData, setFormData] = useState({
        annualAllocation: 0,
        leavePolicyId: '',
        leaveTypeId: '',
        tenantId: '',
        tenantRole: '',
        module: '',
        validFrom: null,
        validUpto: null,
    });
    const [originalFormData, setOriginalFormData] = useState({});
    const [isEditing, setIsEditing] = useState(isCreateMode);
    const [hasInitialized, setHasInitialized] = useState(false);

    const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
    const showToast = (severity, summary, detail, life = 3000) =>
        toast.current?.show({ severity, summary, detail, life });

    const tenantOptions = (tenants || []).map(t => ({
        label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
        value: t.tenantId || t.id || t.code || '',
    }));

    const leavePolicyOptions = leavePolicies.map(p => ({
        label: p.policyName || p.id,
        value: p.id,
    }));

    const leaveTypeOptions = leaveTypes.map(t => ({
        label: t.leaveTypeName || t.id,
        value: t.id,
    }));

    // Redirect if no detail selected in detail mode
    useEffect(() => {
        if (!isCreateMode && !detailId) {
            showToast('warn', 'No Policy Detail Selected', 'Please select from the list', 4000);
            navigate('/web/landing/hrms/leave-policy-detail', { replace: true });
        }
    }, [isCreateMode, detailId, navigate]);

    // Initialize form data from API
    useEffect(() => {
        if (!isCreateMode && data && !hasInitialized) {
            const initialData = {
                annualAllocation: data.annualAllocation ?? 0,
                leavePolicyId: data.leavePolicy?.id ?? '',
                leaveTypeId: data.leaveType?.id ?? '',
                tenantId: data.tenantId ?? '',
                tenantRole: data.tenantRole ?? '',
                module: data.module ?? '',
                validFrom: data.validFrom ? new Date(data.validFrom) : null,
                validUpto: data.validUpto ? new Date(data.validUpto) : null,
            };
            setFormData(initialData);
            setOriginalFormData(initialData);
            setHasInitialized(true);
        }
    }, [data, isCreateMode, hasInitialized]);

    const handleCancel = () => {
        if (isCreateMode) return navigate('/web/landing/hrms/leave-policy-detail');
        setFormData({ ...originalFormData });
        setIsEditing(false);
        showToast('info', 'Cancelled', 'Changes reverted');
    };

    const validateForm = () => {
        if (formData.annualAllocation == null || formData.annualAllocation <= 0)
            return 'Annual Allocation must be greater than 0';
        if (!formData.leavePolicyId) return 'Leave Policy is required';
        if (!formData.leaveTypeId) return 'Leave Type is required';
        if (isCreateMode && !formData.tenantId) return 'Tenant is required';
        if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
            return 'Valid Upto cannot be before Valid From';
        return null;
    };

    // ── KEY FIX: send leavePolicy and leaveType as { id } objects ─────────
    const buildPayload = () => ({
        ...(isCreateMode ? {} : { id: detailId }),
        annualAllocation: formData.annualAllocation,
        leavePolicy: { id: formData.leavePolicyId },
        leaveType: { id: formData.leaveTypeId },
        tenantId: formData.tenantId || originalFormData.tenantId,
        tenantRole: formData.tenantRole || originalFormData.tenantRole,
        module: formData.module?.trim() || '',
        validFrom: formData.validFrom?.toISOString() || null,
        validUpto: formData.validUpto?.toISOString() || null,
    });

    const handleSave = async () => {
        const validationError = validateForm();
        if (validationError) return showToast('warn', 'Validation', validationError);

        const payload = buildPayload();

        try {
            if (isCreateMode) {
                await createLeavePolicyDetail(payload);
                showToast('success', 'Created', 'Leave policy detail created successfully');
                setTimeout(() => navigate('/web/landing/hrms/leave-policy-detail'), 900);
            } else {
                await updateLeavePolicyDetail(payload);
                showToast('success', 'Updated', 'Leave policy detail updated successfully');
                setIsEditing(false);
                refetch();
            }
        } catch (err) {
            const msg = err?.message || mutationError?.message || 'Something went wrong';
            showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
        }
    };

    const handleDelete = () =>
        confirmDialog({
            message: 'Are you sure you want to delete this policy detail?\nThis action cannot be undone.',
            header: 'Confirm Delete',
            icon: 'pi pi-exclamation-triangle',
            acceptClassName: 'p-button-danger',
            acceptLabel: 'Yes, Delete',
            rejectLabel: 'No',
            accept: async () => {
                try {
                    await deleteLeavePolicyDetail(detailId);
                    showToast('success', 'Deleted', 'Leave policy detail deleted successfully');
                    setTimeout(() => navigate('/web/landing/hrms/leave-policy-detail'), 800);
                } catch (err) {
                    const msg = err?.message || 'Could not delete policy detail';
                    showToast('error', 'Delete Failed', msg, 5000);
                }
            },
        });

    const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

    if (!isCreateMode && isLoading)
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <ProgressSpinner />
                        <p className="mt-3 text-500">Loading policy detail...</p>
                    </div>
                </PageContentCard>
            </div>
        );

    if (!isCreateMode && (isError || !data))
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                        <h2>Unable to load leave policy detail</h2>
                        <p className="text-600 mb-4">
                            {error?.message || 'Record not found or invalid access'}
                        </p>
                        <div className="flex gap-3">
                            <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
                            <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                        </div>
                    </div>
                </PageContentCard>
            </div>
        );

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Leave Policy Details', command: () => navigate('/web/landing/hrms/leave-policy-detail') },
        { label: isCreateMode ? 'Create Policy Detail' : 'Details' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const title = isCreateMode ? 'Create New Policy Detail' : 'Leave Policy Detail';
    const subtitle = isCreateMode ? 'New Policy Detail' : `${formData.annualAllocation ?? 0} leaves`;

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />
            <ConfirmDialog />

            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <PageContentCard padding="md" rounded="lg" shadow="sm">
                <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
                    <div className="flex align-items-center gap-4">
                        <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
                        <h4 className="m-0 text-2xl font-semibold">{title}</h4>
                        {!isCreateMode && detailId && (
                            <Button
                                size="small"
                                label={detailId}
                                severity="secondary"
                                rounded
                                onClick={() => navigator.clipboard.writeText(detailId)}
                                tooltip="Copy ID"
                            />
                        )}
                    </div>

                    <div className="flex align-items-center gap-2 flex-wrap">
                        {isCreateMode ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    disabled={isAnyMutationRunning}
                                    size="small"
                                />
                                <Button
                                    label="Create"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isCreating}
                                    size="small"
                                />
                            </>
                        ) : isEditing ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    size="small"
                                />
                                <Button
                                    label="Delete"
                                    icon="pi pi-trash"
                                    severity="danger"
                                    outlined
                                    onClick={handleDelete}
                                    loading={isDeleting}
                                    size="small"
                                />
                                <Button
                                    label="Save"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isUpdating}
                                    size="small"
                                />
                            </>
                        ) : (
                            <Button
                                label="Edit"
                                icon="pi pi-pencil"
                                outlined
                                onClick={() => setIsEditing(true)}
                                size="small"
                            />
                        )}
                    </div>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <TabbedSectionCard transparentBorder>
                    <SectionCardWithHeader title="Policy Allocation Detail" subtitle={subtitle}>
                        <div className="sc-grid-2 gap-4">

                            {isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant *</label>
                                    <Dropdown
                                        value={formData.tenantId}
                                        options={tenantOptions}
                                        onChange={(e) => handleInputChange('tenantId', e.value)}
                                        placeholder="Select tenant"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isTenantsLoading}
                                    />
                                </div>
                            )}

                            {/* Leave Policy — required by backend as { id } object */}
                            <div>
                                <label className="block text-600 mb-1">Leave Policy *</label>
                                {(isCreateMode || isEditing) ? (
                                    <Dropdown
                                        value={formData.leavePolicyId}
                                        options={leavePolicyOptions}
                                        onChange={(e) => handleInputChange('leavePolicyId', e.value)}
                                        placeholder="Select leave policy"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isPoliciesLoading}
                                    />
                                ) : (
                                    <InputText
                                        value={
                                            leavePolicyOptions.find(o => o.value === formData.leavePolicyId)?.label ||
                                            data?.leavePolicy?.policyName ||
                                            '—'
                                        }
                                        disabled
                                        className="w-full bg-gray-100"
                                    />
                                )}
                            </div>

                            {/* Leave Type — required by backend as { id } object */}
                            <div>
                                <label className="block text-600 mb-1">Leave Type *</label>
                                {(isCreateMode || isEditing) ? (
                                    <Dropdown
                                        value={formData.leaveTypeId}
                                        options={leaveTypeOptions}
                                        onChange={(e) => handleInputChange('leaveTypeId', e.value)}
                                        placeholder="Select leave type"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isTypesLoading}
                                    />
                                ) : (
                                    <InputText
                                        value={
                                            leaveTypeOptions.find(o => o.value === formData.leaveTypeId)?.label ||
                                            data?.leaveType?.leaveTypeName ||
                                            '—'
                                        }
                                        disabled
                                        className="w-full bg-gray-100"
                                    />
                                )}
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Annual Allocation (Days) *</label>
                                <InputNumber
                                    value={formData.annualAllocation}
                                    onValueChange={(e) => handleInputChange('annualAllocation', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    min={0}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter number of days' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Module</label>
                                <InputText
                                    value={formData.module}
                                    onChange={(e) => handleInputChange('module', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter module name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid From</label>
                                <Calendar
                                    value={formData.validFrom}
                                    onChange={(e) => handleInputChange('validFrom', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid from' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid Upto</label>
                                <Calendar
                                    value={formData.validUpto}
                                    onChange={(e) => handleInputChange('validUpto', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid upto' : ''}
                                />
                            </div>

                            {!isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant ID</label>
                                    <InputText
                                        value={formData.tenantId}
                                        disabled
                                        className="w-full bg-gray-100"
                                    />
                                </div>
                            )}

                        </div>
                    </SectionCardWithHeader>
                </TabbedSectionCard>
            </PageContentCard>
        </div>
    );
};

export default LeavePolicyDetailDetailView;