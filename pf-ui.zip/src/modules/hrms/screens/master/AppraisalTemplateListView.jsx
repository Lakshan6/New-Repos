// src/pages/hrms/appraisal-template/AppraisalTemplateListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useAppraisalTemplateList from '../../hooks/master/useAppraisalTemplateList';

const AppraisalTemplateListView = () => {
  const navigate = useNavigate();

  const {
    data: templates = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useAppraisalTemplateList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredTemplates = searchTerm.trim()
    ? templates.filter(item =>
        item.templateName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : templates;



  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Appraisal Templates' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Template Name',
      name: 'templateName',
      placeholder: 'e.g. Annual Sabha, Quarterly Review, 360 Degree',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.templateName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(
      2,
      '0'
    )}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Appraisal Templates</h4>
          <Button
            label="Add New Template"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/appraisal-template/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredTemplates}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load templates'}` : 'No appraisal templates found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/appraisal-template/detail', {
              state: { templateId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="templateName" header="Template Name" sortable />
          <Column field="ratingCriteria" header="Rating Criteria" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default AppraisalTemplateListView;