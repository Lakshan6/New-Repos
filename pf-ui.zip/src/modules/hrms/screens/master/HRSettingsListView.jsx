// src/pages/hrms/settings/HRSettingsListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useHRSettingsList from '../../hooks/master/useHRSettingsList';

const HRSettingsListView = () => {
  const navigate = useNavigate();

  const {
    data: settings = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useHRSettingsList();

  const [searchTerms, setSearchTerms] = useState({});

  const filteredSettings = settings.filter(item =>
    Object.entries(searchTerms).every(([key, val]) =>
      !val?.trim() || item[key]?.toLowerCase().includes(val.toLowerCase())
    )
  );

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'HR Settings' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Sender Email',
      name: 'sender',
      placeholder: 'e.g. hr@company.com, payroll@company.com',
    },
    {
      type: 'InputText',
      label: 'Hiring Sender',
      name: 'hiringSender',
      placeholder: 'e.g. careers@company.com',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerms(values);
  };

  const handleClear = () => {
    setSearchTerms({});
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  const yesNo = (value) => (value ? 'Yes' : 'No');

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">HR Settings</h4>

          <Button
            label="Add New Settings"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/hr-settings/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredSettings}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load HR settings'}`
              : 'No HR settings found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/hr-settings/detail', {
              state: { settingId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="sender"           header="Sender Email"           sortable />
          <Column field="hiringSender"     header="Hiring Sender Email"    sortable />

          <Column
            field="autoLeaveEncashment"
            header="Auto Leave Encash"
            body={(row) => yesNo(row.autoLeaveEncashment)}
            sortable
          />
          <Column
            field="emailSalarySlipToEmployee"
            header="Email Salary Slip"
            body={(row) => yesNo(row.emailSalarySlipToEmployee)}
            sortable
          />
          <Column
            field="encryptSalarySlipsInEmails"
            header="Encrypt Slips"
            body={(row) => yesNo(row.encryptSalarySlipsInEmails)}
            sortable
          />
          <Column
            field="sendHolidayReminders"
            header="Send Holiday Reminders"
            body={(row) => yesNo(row.sendHolidayReminders)}
            sortable
          />

          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default HRSettingsListView;