// src/pages/hrms/expense-claim-type/ExpenseClaimTypeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useExpenseClaimTypeList from '../../hooks/master/useExpenseClaimTypeList';

const ExpenseClaimTypeListView = () => {
  const navigate = useNavigate();

  const {
    data: claimTypes = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useExpenseClaimTypeList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredTypes = searchTerm.trim()
    ? claimTypes.filter(item =>
        item.expenseTypeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : claimTypes;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Expense Claim Types' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Expense Type',
      name: 'expenseTypeName',
      placeholder: 'e.g. Travel Expense, Medical, Food Allowance',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.expenseTypeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Expense Claim Types</h4>
          <Button
            label="Add Expense Claim Type"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/expense-claim-type/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredTypes}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load claim types'}` : 'No expense claim types found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/expense-claim-type/detail', {
              state: { typeId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="expenseTypeName" header="Expense Type" sortable />
          <Column field="deferredExpenseAccount" header="Deferred Account" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default ExpenseClaimTypeListView;