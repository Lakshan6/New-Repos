// src/pages/hrms/designation-skill/DesignationSkillListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';

import SearchCard from '@shared/components/SearchCard';
import useDesignationSkillList from '../../hooks/master/useDesignationSkillList';

const DesignationSkillListView = () => {
  const navigate = useNavigate();

  const {
    data: designationSkills = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useDesignationSkillList();

  const [searchTerms, setSearchTerms] = useState({});

  const filteredSkills = designationSkills.filter(item =>
    Object.entries(searchTerms).every(([key, val]) =>
      !val?.trim() || item[key]?.toLowerCase().includes(val.toLowerCase())
    )
  );



  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Designation Skills' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Skill Name',
      name: 'skillName',
      placeholder: 'e.g. Java, React, Leadership, Communication',
    },
    {
      type: 'InputText',
      label: 'Core Skill',
      name: 'coreSkillName',
      placeholder: 'e.g. Programming, Soft Skills, Database',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerms(values);
  };

  const handleClear = () => {
    setSearchTerms({});
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  const proficiencyTemplate = (row) => {
    const severityMap = {
      Expert: 'success',
      Advanced: 'info',
      Intermediate: 'warning',
      Beginner: 'danger',
      // you can add more levels if needed
    };

    const severity = severityMap[row.proficiency] || 'secondary';

    return (
      <Tag
        value={row.proficiency || '—'}
        severity={severity}
        rounded
      />
    );
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Designation Skills</h4>
          <Button
            label="Add New Designation Skill"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/designation-skill/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredSkills}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load designation skills'}`
              : 'No designation skills found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/designation-skill/detail', {
              state: { skillId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="skillName" header="Designation Skill Name" sortable />
          <Column field="coreSkillName" header="Core Skill" sortable />

          <Column
            field="proficiency"
            header="Proficiency Level"
            body={proficiencyTemplate}
            sortable
          />

          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default DesignationSkillListView;