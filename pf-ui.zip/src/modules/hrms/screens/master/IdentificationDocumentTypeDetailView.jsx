// src/pages/hrms/identification-document-type/IdentificationDocumentTypeDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useIdentificationDocumentType from '../../hooks/master/useIdentificationDocumentType';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const IdentificationDocumentTypeDetailView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);

    const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
    const documentTypeId = location.state?.documentTypeId;
    const isCreateMode = location.pathname.endsWith('/create');

    const {
        identificationDocumentType: data,
        isLoading,
        isError,
        error,
        refetch,
        createIdentificationDocumentType,
        updateIdentificationDocumentType,
        deleteIdentificationDocumentType,
        isCreating,
        isUpdating,
        isDeleting,
        mutationError,
    } = useIdentificationDocumentType({ id: isCreateMode ? null : documentTypeId, userInfo });

    const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

    const [formData, setFormData] = useState({
        documentTypeName: '',
        tenantId: '',
        tenantRole: '',
        module: '',
        validFrom: null,
        validUpto: null,
    });
    const [originalFormData, setOriginalFormData] = useState({});
    const [isEditing, setIsEditing] = useState(isCreateMode);
    const [hasInitialized, setHasInitialized] = useState(false);

    const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
    const showToast = (severity, summary, detail, life = 3000) =>
        toast.current?.show({ severity, summary, detail, life });

    const tenantOptions = (tenants || []).map(t => ({
        label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
        value: t.tenantId || t.id || t.code || '',
    }));

    // Redirect if no document type selected in detail mode
    useEffect(() => {
        if (!isCreateMode && !documentTypeId) {
            showToast('warn', 'No Document Type Selected', 'Please select from the list', 4000);
            navigate('/web/landing/hrms/identification-document-type', { replace: true });
        }
    }, [isCreateMode, documentTypeId, navigate]);

    // Initialize form data from API
    useEffect(() => {
        if (!isCreateMode && data && !hasInitialized) {
            const initialData = {
                documentTypeName: data.documentTypeName ?? '',
                tenantId: data.tenantId ?? '',
                tenantRole: data.tenantRole ?? '',
                module: data.module ?? '',
                validFrom: data.validFrom ? new Date(data.validFrom) : null,
                validUpto: data.validUpto ? new Date(data.validUpto) : null,
            };
            setFormData(initialData);
            setOriginalFormData(initialData);
            setHasInitialized(true);
        }
    }, [data, isCreateMode, hasInitialized]);

    const handleCancel = () => {
        if (isCreateMode) return navigate('/web/landing/hrms/identification-document-type');
        setFormData({ ...originalFormData });
        setIsEditing(false);
        showToast('info', 'Cancelled', 'Changes reverted');
    };

    const validateForm = () => {
        if (!formData.documentTypeName?.trim()) return 'Document Type Name is required';
        if (isCreateMode && !formData.tenantId) return 'Tenant is required';
        if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
            return 'Valid Upto cannot be before Valid From';
        return null;
    };

    const buildPayload = () => ({
        ...(isCreateMode ? {} : { id: documentTypeId }),
        documentTypeName: formData.documentTypeName.trim(),
        tenantId: formData.tenantId || originalFormData.tenantId,
        tenantRole: formData.tenantRole || originalFormData.tenantRole,
        module: formData.module?.trim() || '',
        validFrom: formData.validFrom?.toISOString() || null,
        validUpto: formData.validUpto?.toISOString() || null,
    });

    const handleSave = async () => {
        const validationError = validateForm();
        if (validationError) return showToast('warn', 'Validation', validationError);

        const payload = buildPayload();

        try {
            if (isCreateMode) {
                await createIdentificationDocumentType(payload);
                showToast('success', 'Created', 'Document type created successfully');
                setTimeout(() => navigate('/web/landing/hrms/identification-document-type'), 900);
            } else {
                await updateIdentificationDocumentType(payload);
                showToast('success', 'Updated', 'Document type updated successfully');
                setIsEditing(false);
                refetch();
            }
        } catch (err) {
            const msg = err?.message || mutationError?.message || 'Something went wrong';
            showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
        }
    };

    const handleDelete = () =>
        confirmDialog({
            message: 'Are you sure you want to delete this document type?\nThis action cannot be undone.',
            header: 'Confirm Delete',
            icon: 'pi pi-exclamation-triangle',
            acceptClassName: 'p-button-danger',
            acceptLabel: 'Yes, Delete',
            rejectLabel: 'No',
            accept: async () => {
                try {
                    await deleteIdentificationDocumentType(documentTypeId);
                    showToast('success', 'Deleted', 'Document type deleted successfully');
                    setTimeout(() => navigate('/web/landing/hrms/identification-document-type'), 800);
                } catch (err) {
                    const msg = err?.message || 'Could not delete document type';
                    showToast('error', 'Delete Failed', msg, 5000);
                }
            },
        });

    const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

    if (!isCreateMode && isLoading)
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <ProgressSpinner />
                        <p className="mt-3 text-500">Loading document type details...</p>
                    </div>
                </PageContentCard>
            </div>
        );

    if (!isCreateMode && (isError || !data))
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                        <h2>Unable to load document type</h2>
                        <p className="text-600 mb-4">
                            {error?.message || 'Not found or invalid access'}
                        </p>
                        <div className="flex gap-3">
                            <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
                            <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                        </div>
                    </div>
                </PageContentCard>
            </div>
        );

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Identification Document Types', command: () => navigate('/web/landing/hrms/identification-document-type') },
        { label: isCreateMode ? 'Create Document Type' : 'Details' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const title = isCreateMode ? 'Create New Document Type' : 'Identification Document Type Details';
    const subtitle = formData.documentTypeName?.trim() || (isCreateMode ? 'New Document Type' : '—');

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />
            <ConfirmDialog />

            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <PageContentCard padding="md" rounded="lg" shadow="sm">
                <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
                    <div className="flex align-items-center gap-4">
                        <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
                        <h4 className="m-0 text-2xl font-semibold">{title}</h4>
                        {!isCreateMode && documentTypeId && (
                            <Button
                                size="small"
                                label={documentTypeId}
                                severity="secondary"
                                rounded
                                onClick={() => navigator.clipboard.writeText(documentTypeId)}
                                tooltip="Copy ID"
                            />
                        )}
                    </div>

                    <div className="flex align-items-center gap-2 flex-wrap">
                        {isCreateMode ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    disabled={isAnyMutationRunning}
                                    size="small"
                                />
                                <Button
                                    label="Create"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isCreating}
                                    size="small"
                                />
                            </>
                        ) : isEditing ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    size="small"
                                />
                                <Button
                                    label="Delete"
                                    icon="pi pi-trash"
                                    severity="danger"
                                    outlined
                                    onClick={handleDelete}
                                    loading={isDeleting}
                                    size="small"
                                />
                                <Button
                                    label="Save"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isUpdating}
                                    size="small"
                                />
                            </>
                        ) : (
                            <Button
                                label="Edit"
                                icon="pi pi-pencil"
                                outlined
                                onClick={() => setIsEditing(true)}
                                size="small"
                            />
                        )}
                    </div>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <TabbedSectionCard transparentBorder>
                    <SectionCardWithHeader title="Document Type Information" subtitle={subtitle}>
                        <div className="sc-grid-2 gap-4">

                            {isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant *</label>
                                    <Dropdown
                                        value={formData.tenantId}
                                        options={tenantOptions}
                                        onChange={(e) => handleInputChange('tenantId', e.value)}
                                        placeholder="Select tenant"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isTenantsLoading}
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block text-600 mb-1">Document Type Name *</label>
                                <InputText
                                    value={formData.documentTypeName}
                                    onChange={(e) => handleInputChange('documentTypeName', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter document type name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Module</label>
                                <InputText
                                    value={formData.module}
                                    onChange={(e) => handleInputChange('module', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter module name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid From</label>
                                <Calendar
                                    value={formData.validFrom}
                                    onChange={(e) => handleInputChange('validFrom', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid from' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid Upto</label>
                                <Calendar
                                    value={formData.validUpto}
                                    onChange={(e) => handleInputChange('validUpto', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid upto' : ''}
                                />
                            </div>

                            {!isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant ID</label>
                                    <InputText
                                        value={formData.tenantId}
                                        disabled
                                        className="w-full bg-gray-100"
                                    />
                                </div>
                            )}

                        </div>
                    </SectionCardWithHeader>
                </TabbedSectionCard>
            </PageContentCard>
        </div>
    );
};

export default IdentificationDocumentTypeDetailView;