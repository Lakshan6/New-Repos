// src/pages/hrms/shift-location/ShiftLocationListView.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import SearchCard from '@shared/components/SearchCard';

import useShiftLocationList from '../../hooks/master/useShiftLocationList';

const ShiftLocationListView = () => {
    const navigate = useNavigate();

    const {
        data: locations = [],
        isLoading,
        isError,
        error,
        refetch,
    } = useShiftLocationList();

    const [filteredLocations, setFilteredLocations] = useState([]);

    useEffect(() => {
        setFilteredLocations(locations);
    }, [locations]);

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Shift Locations' },
    ];

    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const searchFilters = [
        {
            type: 'InputText',
            label: 'Location Name',
            name: 'locationName',
            placeholder: 'e.g. Head Office, Bangalore Branch, Mumbai Hub',
        },
    ];

    const handleSearch = (values) => {
        const { locationName } = values;

        if (!locationName?.trim()) {
            setFilteredLocations(locations);
            return;
        }

        const filtered = locations.filter((item) =>
            item.locationName?.toLowerCase().includes(locationName.toLowerCase())
        );

        setFilteredLocations(filtered);
    };

    const handleClear = () => {
        setFilteredLocations(locations);
        refetch();
    };

    const formatDate = (dateString) => {
        if (!dateString) return '—';
        const d = new Date(dateString);
        return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
    };

    return (
        <div className="surface-ground min-h-screen p-3">
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <SearchCard
                filters={searchFilters}
                onSubmit={handleSearch}
                onClear={handleClear}
            />

            <Card className="mt-4">
                <div className="ml-2 mb-3">
                    <h4 className="m-0 text-2xl font-semibold">Shift Locations</h4>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <DataTable
                    value={filteredLocations}
                    stripedRows
                    paginator
                    rows={10}
                    rowsPerPageOptions={[10, 25, 50]}
                    rowHover
                    loading={isLoading}
                    emptyMessage={isError ? `Error: ${error?.message}` : 'No shift locations found'}
                    onRowClick={(e) =>
                        navigate('/web/landing/hrms/shift-location/detail', {
                            state: { locationId: e.data.id },
                        })
                    }
                    selectionMode="single"
                    className="cursor-pointer"
                >
                    <Column field="locationName" header="Location Name" sortable />
                    <Column field="address" header="Address" sortable />

                    <Column
                        field="validFrom"
                        header="Valid From"
                        body={(row) => formatDate(row.validFrom)}
                        sortable
                    />
                    <Column
                        field="validUpto"
                        header="Valid Upto"
                        body={(row) => formatDate(row.validUpto)}
                        sortable
                    />
                </DataTable>
            </Card>
        </div>
    );
};

export default ShiftLocationListView;