import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeaveBlockList from '../../hooks/master/useLeaveBlockList';

const LeaveBlockListView = () => {
  const navigate = useNavigate();

  const {
    data: blocks = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeaveBlockList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredBlocks = searchTerm.trim()
    ? blocks.filter(item =>
        item.leaveBlockListName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : blocks;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Block Lists' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Block List Name',
      name: 'leaveBlockListName',
      placeholder: 'e.g. Annual Leave Block, Festival Block, Probation Block',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.leaveBlockListName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Block Lists</h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/leave-block-list/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredBlocks}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load data'}` : 'No leave block lists found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-block-list/detail', {
              state: { blockId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="leaveBlockListName" header="Block List Name" sortable />
          <Column field="appliesToCompany" header="Applies To Company" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeaveBlockListView;