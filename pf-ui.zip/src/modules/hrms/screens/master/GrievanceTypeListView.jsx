// src/pages/hrms/grievance-type/GrievanceTypeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useGrievanceTypeList from '../../hooks/master/useGrievanceTypeList';

const GrievanceTypeListView = () => {
  const navigate = useNavigate();

  const {
    data: grievanceTypes = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useGrievanceTypeList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredTypes = searchTerm.trim()
    ? grievanceTypes.filter(item =>
        item.grievanceTypeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : grievanceTypes;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Grievance Types' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Grievance Type',
      name: 'grievanceTypeName',
      placeholder: 'e.g. Holiday Issues, Salary Delay',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.grievanceTypeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(
      2,
      '0'
    )}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Grievance Types</h4>
          <Button
            label="Add New Grievance Type"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/grievance-type/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredTypes}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load grievance types'}` : 'No grievance types found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/grievance-type/detail', {
              state: { grievanceTypeId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="grievanceTypeName" header="Grievance Type" sortable />
          <Column field="description" header="Description" sortable />
          <Column field="module" header="Module" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default GrievanceTypeListView;