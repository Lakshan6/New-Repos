import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeavePeriodList from '../../hooks/master/useLeavePeriodList';

const LeavePeriodListView = () => {
  const navigate = useNavigate();

  const {
    data: periods = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeavePeriodList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredPeriods = searchTerm.trim()
    ? periods.filter(item =>
        item.periodName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : periods;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Periods' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Period Name',
      name: 'periodName',
      placeholder: 'e.g. Q1 2026 Leave, Annual Leave Period',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.periodName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(
      d.getMonth() + 1
    ).padStart(2, '0')}-${d.getFullYear()}`;
  };

  const activeTemplate = (row) => (
    <Tag
      value={row.isActive ? 'Active' : 'Inactive'}
      severity={row.isActive ? 'success' : 'danger'}
      rounded
    />
  );

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Periods</h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/leave-period/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredPeriods}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError ? `Error: ${error?.message || 'Failed to load data'}` : 'No leave periods found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-period/detail', {
              state: { periodId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="periodName" header="Period Name" sortable />
          <Column field="fromDate" header="From Date" body={(row) => formatDate(row.fromDate)} sortable />
          <Column field="toDate" header="To Date" body={(row) => formatDate(row.toDate)} sortable />
          <Column field="isActive" header="Status" body={activeTemplate} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeavePeriodListView;