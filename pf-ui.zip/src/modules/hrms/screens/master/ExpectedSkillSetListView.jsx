// src/pages/hrms/expected-skill-set/ExpectedSkillSetListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useExpectedSkillSetList from '../../hooks/master/useExpectedSkillSetList';

const ExpectedSkillSetListView = () => {
  const navigate = useNavigate();

  const {
    data: skillSets = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useExpectedSkillSetList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredSkillSets = searchTerm.trim()
    ? skillSets.filter(item =>
        item.skillName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : skillSets;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Expected Skill Sets' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Skill Name',
      name: 'skillName',
      placeholder: 'e.g. Java, React, Leadership, Communication',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.skillName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Expected Skill Sets</h4>
          <Button
            label="Add Expected Skill Set"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/expected-skill-set/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredSkillSets}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load expected skill sets'}` : 'No expected skill sets found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/expected-skill-set/detail', {
              state: { skillSetId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="skillName" header="Skill Name" sortable />
          <Column field="coreSkillName" header="Core Skill" sortable />
          <Column field="interviewRoundName" header="Interview Round" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default ExpectedSkillSetListView;