// src/pages/hrms/job-offer-term-template/JobOfferTermTemplateListView.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import SearchCard from '@shared/components/SearchCard';

import useJobOfferTermTemplateList from '../../hooks/master/useJobOfferTermTemplateList';

const JobOfferTermTemplateListView = () => {
    const navigate = useNavigate();

    const {
        data: templates = [],
        isLoading,
        isError,
        error,
        refetch,
    } = useJobOfferTermTemplateList();

    const [filteredTemplates, setFilteredTemplates] = useState([]);

    useEffect(() => {
        setFilteredTemplates(templates);
    }, [templates]);

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Job Offer Term Templates' },
    ];

    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const searchFilters = [
        {
            type: 'InputText',
            label: 'Template Name',
            name: 'templateName',
            placeholder: 'e.g. Normal Template, Senior Position Terms, Fresher Offer',
        },
    ];

    const handleSearch = (values) => {
        const { templateName } = values;

        if (!templateName?.trim()) {
            setFilteredTemplates(templates);
            return;
        }

        const filtered = templates.filter((item) =>
            item.templateName?.toLowerCase().includes(templateName.toLowerCase())
        );

        setFilteredTemplates(filtered);
    };

    const handleClear = () => {
        setFilteredTemplates(templates);
        refetch();
    };

    const formatDate = (dateString) => {
        if (!dateString) return '—';
        const d = new Date(dateString);
        return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
    };

    return (
        <div className="surface-ground min-h-screen p-3">
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <SearchCard
                filters={searchFilters}
                onSubmit={handleSearch}
                onClear={handleClear}
            />

            <Card className="mt-4">
                <div className="ml-2 mb-3">
                    <h4 className="m-0 text-2xl font-semibold">Job Offer Term Templates</h4>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <DataTable
                    value={filteredTemplates}
                    stripedRows
                    paginator
                    rows={10}
                    rowsPerPageOptions={[10, 25, 50]}
                    rowHover
                    loading={isLoading}
                    emptyMessage={isError ? `Error: ${error?.message}` : 'No term templates found'}
                    onRowClick={(e) =>
                        navigate('/web/landing/hrms/job-offer-term-template/detail', {
                            state: { templateId: e.data.id },
                        })
                    }
                    selectionMode="single"
                    className="cursor-pointer"
                >
                    <Column field="templateName" header="Template Name" sortable />

                    <Column
                        field="validFrom"
                        header="Valid From"
                        body={(row) => formatDate(row.validFrom)}
                        sortable
                    />
                    <Column
                        field="validUpto"
                        header="Valid Upto"
                        body={(row) => formatDate(row.validUpto)}
                        sortable
                    />
                </DataTable>
            </Card>
        </div>
    );
};

export default JobOfferTermTemplateListView;