import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeaveBlockListDateList from '../../hooks/master/useLeaveBlockListDateList';

const LeaveBlockListDateListView = () => {
  const navigate = useNavigate();

  const {
    data: blockDates = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeaveBlockListDateList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredDates = searchTerm.trim()
    ? blockDates.filter(item =>
        item.reason?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : blockDates;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Block List Dates' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Reason',
      name: 'reason',
      placeholder: 'e.g. Company Holiday, Festival, Training Day',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.reason || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard
        filters={searchFilters}
        onSubmit={handleSearch}
        onClear={handleClear}
      />

      <Card className="mt-4">
        {/* Header aligned like SkillList */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">
            Leave Block List Dates
          </h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() =>
              navigate('/web/landing/hrms/leave-block-list-date/create')
            }
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredDates}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load data'}`
              : 'No block dates found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-block-list-date/detail', {
              state: { dateId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column
            field="blockDate"
            header="Block Date"
            body={(row) => formatDate(row.blockDate)}
            sortable
          />
          <Column field="reason" header="Reason" sortable />
          <Column
            field="leaveBlockListName"
            header="Block List"
            sortable
          />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeaveBlockListDateListView;