// src/pages/hrms/kra/KRAListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useKRAList from '../../hooks/master/useKRAList';

const KRAListView = () => {
  const navigate = useNavigate();

  const {
    data: kras = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useKRAList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredKRAs = searchTerm.trim()
    ? kras.filter(item =>
        item.kraName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : kras;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'KRAs' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'KRA Name',
      name: 'kraName',
      placeholder: 'e.g. Technical Excellence, Leadership, Innovation',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.kraName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Key Result Areas (KRAs)</h4>
          <Button
            label="Add New KRA"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/kra/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredKRAs}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load KRAs'}` : 'No KRAs found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/kra/detail', {
              state: { kraId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="kraName" header="KRA Name" sortable />
          <Column field="description" header="Description" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default KRAListView;