// src/pages/hrms/employment-type/EmploymentTypeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useEmploymentTypeList from '../../hooks/master/useEmploymentTypeList';

const EmploymentTypeListView = () => {
  const navigate = useNavigate();

  const {
    data: employmentTypes = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useEmploymentTypeList();

  // ── KEY FIX: no useEffect — derive filtered list from search term only ──
  // useEffect(() => setFilteredTypes(employmentTypes), [employmentTypes])
  // was causing infinite loop because employmentTypes = [] is a new reference every render
  const [searchTerm, setSearchTerm] = useState('');

  const filteredTypes = searchTerm.trim()
    ? employmentTypes.filter(item =>
        item.employeeTypeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : employmentTypes;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Employment Types' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Employment Type',
      name: 'employeeTypeName',
      placeholder: 'e.g. Full Time, Contract',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.employeeTypeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Employment Types</h4>
          <Button
            label="Add New Employment Type"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/employment-type/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredTypes}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load employment types'}`
              : 'No employment types found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/employment-type/detail', {
              state: { employmentTypeId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="employeeTypeName" header="Employment Type" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default EmploymentTypeListView;