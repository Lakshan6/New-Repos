// src/pages/hrms/shift-type/ShiftTypeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useShiftTypeList from '../../hooks/master/useShiftTypeList';

const ShiftTypeListView = () => {
  const navigate = useNavigate();

  const {
    data: shifts = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useShiftTypeList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredShifts = searchTerm.trim()
    ? shifts.filter(item =>
        item.shiftName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : shifts;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Shift Types' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Shift Name',
      name: 'shiftName',
      placeholder: 'e.g. Morning Shift, Night Shift, General Shift',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.shiftName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(
      d.getMonth() + 1
    ).padStart(2, '0')}-${d.getFullYear()}`;
  };

  const formatTime = (timeString) => {
    if (!timeString) return '—';
    const d = new Date(timeString);
    return d.toLocaleTimeString([], {
      hour: '2-digit',
      minute: '2-digit',
      hour12: true,
    });
  };

  const yesNoTemplate = (value) => (
    <Tag value={value ? 'Yes' : 'No'} severity={value ? 'success' : 'danger'} rounded />
  );

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard
        filters={searchFilters}
        onSubmit={handleSearch}
        onClear={handleClear}
      />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Shift Types</h4>

          <Button
            label="Add New Shift Type"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/shift-type/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredShifts}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load shift types'}`
              : 'No shift types found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/shift-type/detail', {
              state: { shiftId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="shiftName" header="Shift Name" sortable />

          <Column
            field="startTime"
            header="Start Time"
            body={(row) => formatTime(row.startTime)}
            sortable
          />

          <Column
            field="endTime"
            header="End Time"
            body={(row) => formatTime(row.endTime)}
            sortable
          />

          <Column
            field="enableAutoAttendance"
            header="Auto Attendance"
            body={(row) => yesNoTemplate(row.enableAutoAttendance)}
            sortable
          />

          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />

          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default ShiftTypeListView;