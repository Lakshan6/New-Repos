// src/pages/hrms/employee-feedback-criteria/EmployeeFeedbackCriteriaListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useEmployeeFeedbackCriteriaList from '../../hooks/master/useEmployeeFeedbackCriteriaList';

const EmployeeFeedbackCriteriaListView = () => {
  const navigate = useNavigate();

  const {
    data: criterias = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useEmployeeFeedbackCriteriaList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredCriterias = searchTerm.trim()
    ? criterias.filter(item =>
        item.criteriaName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : criterias;



  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Feedback Criteria' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Criteria Name',
      name: 'criteriaName',
      placeholder: 'Enter criteria name',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.criteriaName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const date = new Date(dateString);
    const day = String(date.getDate()).padStart(2, '0');
    const month = String(date.getMonth() + 1).padStart(2, '0');
    const year = date.getFullYear();
    return `${day}-${month}-${year}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      {/* Breadcrumb */}
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      {/* Search */}
      <SearchCard
        filters={searchFilters}
        onSubmit={handleSearch}
        onClear={handleClear}
      />

      {/* List Card */}
      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Employee Feedback Criteria</h4>
          <Button
            label="Add New Criteria"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() =>
              navigate('/web/landing/hrms/employee-feedback-criteria/create')
            }
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredCriterias}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError ? `Error: ${error?.message}` : 'No criteria found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/employee-feedback-criteria/detail', {
              state: { criteriaId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="criteriaName" header="Criteria Name" sortable />
          <Column field="description" header="Description" />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default EmployeeFeedbackCriteriaListView;