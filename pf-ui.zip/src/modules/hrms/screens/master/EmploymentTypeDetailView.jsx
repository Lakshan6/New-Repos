// src/pages/hrms/employment-type/EmploymentTypeDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useEmploymentType from '../../hooks/master/useEmploymentType';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const EmploymentTypeDetailView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);

    const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
    const employmentTypeId = location.state?.employmentTypeId;
    const isCreateMode = location.pathname.endsWith('/create');

    const {
        employmentType: data,
        isLoading,
        isError,
        error,
        refetch,
        createEmploymentType,
        updateEmploymentType,
        deleteEmploymentType,
        isCreating,
        isUpdating,
        isDeleting,
        mutationError,
    } = useEmploymentType({ id: isCreateMode ? null : employmentTypeId, userInfo });

    const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

    const [formData, setFormData] = useState({
        employeeTypeName: '',
        tenantId: '',
        tenantRole: '',
        module: '',
        validFrom: null,
        validUpto: null,
    });
    const [originalFormData, setOriginalFormData] = useState({});
    const [isEditing, setIsEditing] = useState(isCreateMode);
    const [hasInitialized, setHasInitialized] = useState(false);

    const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));

    // ── KEY FIX: showToast uses toast.current directly — stable ref, no deps issue
    const showToast = (severity, summary, detail, life = 3000) =>
        toast.current?.show({ severity, summary, detail, life });

    const tenantOptions = (tenants || []).map(t => ({
        label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
        value: t.tenantId || t.id || t.code || '',
    }));

    // ── KEY FIX: use toast.current directly inside useEffect, not showToast ──
    // showToast is recreated every render → putting it in deps causes infinite loop
    useEffect(() => {
        if (!isCreateMode && !employmentTypeId) {
            toast.current?.show({
                severity: 'warn',
                summary: 'No Employment Type Selected',
                detail: 'Please select a type from the list',
                life: 4000,
            });
            navigate('/web/landing/hrms/employment-type', { replace: true });
        }
    }, [isCreateMode, employmentTypeId, navigate]);

    // Initialize form data from API
    useEffect(() => {
        if (!isCreateMode && data && !hasInitialized) {
            const initialData = {
                employeeTypeName: data.employeeTypeName ?? '',
                tenantId: data.tenantId ?? '',
                tenantRole: data.tenantRole ?? '',
                module: data.module ?? '',
                validFrom: data.validFrom ? new Date(data.validFrom) : null,
                validUpto: data.validUpto ? new Date(data.validUpto) : null,
            };
            setFormData(initialData);
            setOriginalFormData(initialData);
            setHasInitialized(true);
        }
    }, [data, isCreateMode, hasInitialized]);

    const handleCancel = () => {
        if (isCreateMode) return navigate('/web/landing/hrms/employment-type');
        setFormData({ ...originalFormData });
        setIsEditing(false);
        showToast('info', 'Cancelled', 'Changes reverted');
    };

    const validateForm = () => {
        if (!formData.employeeTypeName?.trim()) return 'Employment Type Name is required';
        if (isCreateMode && !formData.tenantId) return 'Tenant is required';
        if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
            return 'Valid Upto cannot be before Valid From';
        return null;
    };

    const buildPayload = () => ({
        ...(isCreateMode ? {} : { id: employmentTypeId }),
        employeeTypeName: formData.employeeTypeName.trim(),
        tenantId: formData.tenantId || originalFormData.tenantId,
        tenantRole: formData.tenantRole || originalFormData.tenantRole,
        module: formData.module?.trim() || '',
        validFrom: formData.validFrom?.toISOString() || null,
        validUpto: formData.validUpto?.toISOString() || null,
    });

    const handleSave = async () => {
        const validationError = validateForm();
        if (validationError) return showToast('warn', 'Validation', validationError);

        const payload = buildPayload();

        try {
            if (isCreateMode) {
                await createEmploymentType(payload);
                showToast('success', 'Created', 'Employment type created successfully');
                setTimeout(() => navigate('/web/landing/hrms/employment-type'), 900);
            } else {
                await updateEmploymentType(payload);
                showToast('success', 'Updated', 'Employment type updated successfully');
                setIsEditing(false);
                refetch();
            }
        } catch (err) {
            const msg = err?.message || mutationError?.message || 'Something went wrong';
            showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
        }
    };

    const handleDelete = () =>
        confirmDialog({
            message: 'Are you sure you want to delete this employment type?\nThis action cannot be undone.',
            header: 'Confirm Delete',
            icon: 'pi pi-exclamation-triangle',
            acceptClassName: 'p-button-danger',
            acceptLabel: 'Yes, Delete',
            rejectLabel: 'No',
            accept: async () => {
                try {
                    await deleteEmploymentType(employmentTypeId);
                    showToast('success', 'Deleted', 'Employment type deleted successfully');
                    setTimeout(() => navigate('/web/landing/hrms/employment-type'), 800);
                } catch (err) {
                    const msg = err?.message || 'Could not delete employment type';
                    showToast('error', 'Delete Failed', msg, 5000);
                }
            },
        });

    const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

    if (!isCreateMode && isLoading)
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <ProgressSpinner />
                        <p className="mt-3 text-500">Loading employment type details...</p>
                    </div>
                </PageContentCard>
            </div>
        );

    if (!isCreateMode && (isError || !data))
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                        <h2>Unable to load employment type</h2>
                        <p className="text-600 mb-4">
                            {error?.message || 'Type not found or invalid access'}
                        </p>
                        <div className="flex gap-3">
                            <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
                            <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                        </div>
                    </div>
                </PageContentCard>
            </div>
        );

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Employment Types', command: () => navigate('/web/landing/hrms/employment-type') },
        { label: isCreateMode ? 'Create Employment Type' : 'Details' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const title = isCreateMode ? 'Create New Employment Type' : 'Employment Type Details';
    const subtitle = formData.employeeTypeName?.trim() || (isCreateMode ? 'New Employment Type' : '—');

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />
            <ConfirmDialog />

            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <PageContentCard padding="md" rounded="lg" shadow="sm">
                <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
                    <div className="flex align-items-center gap-4">
                        <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
                        <h4 className="m-0 text-2xl font-semibold">{title}</h4>
                        {!isCreateMode && employmentTypeId && (
                            <Button
                                size="small"
                                label={employmentTypeId}
                                severity="secondary"
                                rounded
                                onClick={() => navigator.clipboard.writeText(employmentTypeId)}
                                tooltip="Copy ID"
                            />
                        )}
                    </div>

                    <div className="flex align-items-center gap-2 flex-wrap">
                        {isCreateMode ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    disabled={isAnyMutationRunning}
                                    size="small"
                                />
                                <Button
                                    label="Create"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isCreating}
                                    size="small"
                                />
                            </>
                        ) : isEditing ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    size="small"
                                />
                                <Button
                                    label="Delete"
                                    icon="pi pi-trash"
                                    severity="danger"
                                    outlined
                                    onClick={handleDelete}
                                    loading={isDeleting}
                                    size="small"
                                />
                                <Button
                                    label="Save"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isUpdating}
                                    size="small"
                                />
                            </>
                        ) : (
                            <Button
                                label="Edit"
                                icon="pi pi-pencil"
                                outlined
                                onClick={() => setIsEditing(true)}
                                size="small"
                            />
                        )}
                    </div>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <TabbedSectionCard transparentBorder>
                    <SectionCardWithHeader title="Employment Type Information" subtitle={subtitle}>
                        <div className="sc-grid-2 gap-4">

                            {isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant *</label>
                                    <Dropdown
                                        value={formData.tenantId}
                                        options={tenantOptions}
                                        onChange={(e) => handleInputChange('tenantId', e.value)}
                                        placeholder="Select tenant"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isTenantsLoading}
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block text-600 mb-1">Employment Type Name *</label>
                                <InputText
                                    value={formData.employeeTypeName}
                                    onChange={(e) => handleInputChange('employeeTypeName', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter employment type name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Module</label>
                                <InputText
                                    value={formData.module}
                                    onChange={(e) => handleInputChange('module', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter module name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid From</label>
                                <Calendar
                                    value={formData.validFrom}
                                    onChange={(e) => handleInputChange('validFrom', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid from' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid Upto</label>
                                <Calendar
                                    value={formData.validUpto}
                                    onChange={(e) => handleInputChange('validUpto', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid upto' : ''}
                                />
                            </div>

                            {!isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant ID</label>
                                    <InputText
                                        value={formData.tenantId}
                                        disabled
                                        className="w-full bg-gray-100"
                                    />
                                </div>
                            )}

                        </div>
                    </SectionCardWithHeader>
                </TabbedSectionCard>
            </PageContentCard>
        </div>
    );
};

export default EmploymentTypeDetailView;