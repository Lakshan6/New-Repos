// src/pages/hrms/job-applicant-source/JobApplicantSourceListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useJobApplicantSourceList from '../../hooks/master/useJobApplicantSourceList';

const JobApplicantSourceListView = () => {
  const navigate = useNavigate();

  const {
    data: sources = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useJobApplicantSourceList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredSources = searchTerm.trim()
    ? sources.filter(item =>
        item.sourceName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : sources;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Job Applicant Sources' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Source Name',
      name: 'sourceName',
      placeholder: 'e.g. Naukri, LinkedIn, Referral, Company Website',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.sourceName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Job Applicant Sources</h4>
          <Button
            label="Add New Source"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/job-applicant-source/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredSources}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load sources'}` : 'No applicant sources found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/job-applicant-source/detail', {
              state: { sourceId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="sourceName" header="Source Name" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default JobApplicantSourceListView;