// src/pages/hrms/appointment-letter-template/AppointmentLetterTemplateDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { useAppointmentLetterTemplates } from '../../hooks/master/useAppointmentLetterTemplates';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const AppointmentLetterTemplateDetailView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);

    const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
    const templateId = location.state?.templateId;
    const isCreateMode = location.pathname.endsWith('/create');

    const {
        template: data,
        isLoading,
        isError,
        error,
        refetch,
        createTemplate,
        updateTemplate,
        deleteTemplate,
        isCreating,
        isUpdating,
        isDeleting,
        mutationError
    } = useAppointmentLetterTemplates({ id: isCreateMode ? null : templateId, userInfo });

    const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

    const [formData, setFormData] = useState({
        templateName: '',
        intro: '',
        closingNotes: '',
        tenantId: '',
        tenantRole: '',
        module: '',
        validFrom: null,
        validUpto: null,
    });

    const [originalFormData, setOriginalFormData] = useState({});
    const [isEditing, setIsEditing] = useState(isCreateMode);
    const [hasInitialized, setHasInitialized] = useState(false);

    const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
    const showToast = (severity, summary, detail, life = 3000) =>
        toast.current?.show({ severity, summary, detail, life });

    const tenantOptions = (tenants || []).map(t => ({
        label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
        value: t.tenantId || t.id || t.code || ''
    })).filter(t => t.value);

    useEffect(() => {
        if (!isCreateMode && !templateId) {
            showToast('warn', 'No Template Selected', 'Please select a template from the list', 4000);
            navigate('/web/landing/hrms/appointment-letter-template', { replace: true });
        }
    }, [isCreateMode, templateId, navigate]);

    useEffect(() => {
        if (!isCreateMode && data && !hasInitialized) {
            const initialData = {
                templateName: data.templateName ?? '',
                intro: data.intro ?? '',
                closingNotes: data.closingNotes ?? '',
                tenantId: data.tenantId ?? '',
                tenantRole: data.tenantRole ?? '',
                module: data.module ?? '',
                validFrom: data.validFrom ? new Date(data.validFrom) : null,
                validUpto: data.validUpto ? new Date(data.validUpto) : null,
            };
            setFormData(initialData);
            setOriginalFormData(initialData);
            setHasInitialized(true);
        }
    }, [data, isCreateMode, hasInitialized]);

    const handleCancel = () => {
        if (isCreateMode) return navigate('/web/landing/hrms/appointment-letter-template');
        setFormData({ ...originalFormData });
        setIsEditing(false);
        showToast('info', 'Cancelled', 'Changes reverted');
    };

    const validateForm = () => {
        if (!formData.templateName?.trim()) return 'Template Name is required';
        if (isCreateMode && !formData.tenantId) return 'Tenant is required';
        if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
            return 'Valid Upto cannot be before Valid From';
        return null;
    };

    const buildPayload = () => ({
        ...(isCreateMode ? {} : { id: templateId }),
        templateName: formData.templateName.trim(),
        intro: formData.intro?.trim() || '',
        closingNotes: formData.closingNotes?.trim() || '',
        tenantId: formData.tenantId || originalFormData.tenantId,
        tenantRole: formData.tenantRole || originalFormData.tenantRole,
        module: formData.module?.trim() || '',
        validFrom: formData.validFrom?.toISOString() || null,
        validUpto: formData.validUpto?.toISOString() || null,
    });

    const handleSave = async () => {
        const validationError = validateForm();
        if (validationError) return showToast('warn', 'Validation', validationError);

        const payload = buildPayload();

        try {
            if (isCreateMode) {
                await createTemplate(payload);
                showToast('success', 'Created', 'Template created successfully');
                setTimeout(() => navigate('/web/landing/hrms/appointment-letter-template'), 900);
            } else {
                await updateTemplate(payload);
                showToast('success', 'Updated', 'Template updated successfully');
                setIsEditing(false);
                refetch();
            }
        } catch (err) {
            const msg = err?.message || mutationError?.message || 'Something went wrong';
            showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
        }
    };

    const handleDelete = () =>
        confirmDialog({
            message: 'Are you sure you want to delete this template?\nThis action cannot be undone.',
            header: 'Confirm Delete',
            icon: 'pi pi-exclamation-triangle',
            acceptClassName: 'p-button-danger',
            acceptLabel: 'Yes, Delete',
            rejectLabel: 'No',
            accept: async () => {
                try {
                    await deleteTemplate(templateId);
                    showToast('success', 'Deleted', 'Template deleted successfully');
                    setTimeout(() => navigate('/web/landing/hrms/appointment-letter-template'), 800);
                } catch (err) {
                    const msg = err?.message || 'Could not delete template';
                    showToast('error', 'Delete Failed', msg, 5000);
                }
            },
        });

    const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

    if (!isCreateMode && isLoading)
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <ProgressSpinner />
                        <p className="mt-3 text-500">Loading template details...</p>
                    </div>
                </PageContentCard>
            </div>
        );

    if (!isCreateMode && (isError || !data))
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                        <h2>Unable to load template</h2>
                        <p className="text-600 mb-4">{error?.message || 'Template not found or invalid access'}</p>
                        <div className="flex gap-3">
                            <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
                            <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                        </div>
                    </div>
                </PageContentCard>
            </div>
        );

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Appointment Letter Templates', command: () => navigate('/web/landing/hrms/appointment-letter-template') },
        { label: isCreateMode ? 'Create Template' : 'Details' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const title = isCreateMode ? 'Create New Template' : 'Template Details';
    const subtitle = formData.templateName.trim() || (isCreateMode ? 'New Template' : '—');

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />
            <ConfirmDialog />
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <PageContentCard padding="md" rounded="lg" shadow="sm">
                <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
                    <div className="flex align-items-center gap-4">
                        <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
                        <h4 className="m-0 text-2xl font-semibold">{title}</h4>
                    </div>
                    <div className="flex align-items-center gap-2 flex-wrap">
                        {isCreateMode ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    disabled={isAnyMutationRunning}
                                    size="small"
                                />
                                <Button
                                    label="Create"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isCreating}
                                    size="small"
                                />
                            </>
                        ) : isEditing ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    size="small"
                                />
                                <Button
                                    label="Delete"
                                    icon="pi pi-trash"
                                    severity="danger"
                                    outlined
                                    onClick={handleDelete}
                                    loading={isDeleting}
                                    size="small"
                                />
                                <Button
                                    label="Save"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isUpdating}
                                    size="small"
                                />
                            </>
                        ) : (
                            <Button label="Edit" icon="pi pi-pencil" outlined onClick={() => setIsEditing(true)} size="small" />
                        )}
                    </div>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <TabbedSectionCard transparentBorder>
                    <SectionCardWithHeader title="Template Information" subtitle={subtitle}>
                        <div className="sc-grid-2 gap-4">
                            {isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant *</label>
                                    <Dropdown
                                        value={formData.tenantId}
                                        options={tenantOptions}
                                        onChange={(e) => handleInputChange('tenantId', e.value)}
                                        placeholder="Select tenant"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isTenantsLoading}
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block text-600 mb-1">Template Name *</label>
                                <InputText
                                    value={formData.templateName}
                                    onChange={(e) => handleInputChange('templateName', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter template name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Module</label>
                                <InputText
                                    value={formData.module}
                                    onChange={(e) => handleInputChange('module', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter module name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Introduction Text</label>
                                <InputTextarea
                                    value={formData.intro}
                                    onChange={(e) => handleInputChange('intro', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    rows={4}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter introduction text' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Closing Notes</label>
                                <InputTextarea
                                    value={formData.closingNotes}
                                    onChange={(e) => handleInputChange('closingNotes', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    rows={4}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter closing notes' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid From</label>
                                <Calendar
                                    value={formData.validFrom}
                                    onChange={(e) => handleInputChange('validFrom', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select start date' : ''}
                                    dateFormat="yy-mm-dd"
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid Upto</label>
                                <Calendar
                                    value={formData.validUpto}
                                    onChange={(e) => handleInputChange('validUpto', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select end date' : ''}
                                    dateFormat="yy-mm-dd"
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>
                </TabbedSectionCard>
            </PageContentCard>
        </div>
    );
};

export default AppointmentLetterTemplateDetailView;