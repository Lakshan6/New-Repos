// src/pages/hrms/shift-schedule/ShiftScheduleListView.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useShiftScheduleList from '../../hooks/master/useShiftScheduleList';

const ShiftScheduleListView = () => {
    const navigate = useNavigate();

    const {
        data: schedules = [],
        isLoading,
        isError,
        error,
        refetch,
    } = useShiftScheduleList();

    const [filteredSchedules, setFilteredSchedules] = useState([]);

    useEffect(() => {
        setFilteredSchedules(schedules);
    }, [schedules]);

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Shift Schedules' },
    ];

    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const searchFilters = [
        {
            type: 'InputText',
            label: 'Schedule Name',
            name: 'scheduleName',
            placeholder: 'e.g. Weekly Morning, Rotating Shift, Night Schedule',
        },
    ];

    const handleSearch = (values) => {
        const { scheduleName } = values;

        if (!scheduleName?.trim()) {
            setFilteredSchedules(schedules);
            return;
        }

        const filtered = schedules.filter((item) =>
            item.scheduleName?.toLowerCase().includes(scheduleName.toLowerCase())
        );

        setFilteredSchedules(filtered);
    };

    const handleClear = () => {
        setFilteredSchedules(schedules);
        refetch();
    };

    const formatDate = (dateString) => {
        if (!dateString) return '—';
        const d = new Date(dateString);
        return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
    };

    return (
        <div className="surface-ground min-h-screen p-3">
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <SearchCard
                filters={searchFilters}
                onSubmit={handleSearch}
                onClear={handleClear}
            />

            <Card className="mt-4">

                {/* HEADER SECTION (same style as ShiftType) */}
                <div className="flex justify-content-between align-items-center mb-3 px-2">
                    <h4 className="m-0 text-2xl font-semibold">Shift Schedules</h4>

                    <Button
                        label="Add New Shift Schedule"
                        icon="pi pi-plus"
                        severity="success"
                        size="small"
                        onClick={() =>
                            navigate('/web/landing/hrms/shift-schedule/create')
                        }
                    />
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <DataTable
                    value={filteredSchedules}
                    stripedRows
                    paginator
                    rows={10}
                    rowsPerPageOptions={[10, 25, 50]}
                    rowHover
                    loading={isLoading}
                    emptyMessage={
                        isError
                            ? `Error: ${error?.message || 'Failed to load schedules'}`
                            : 'No shift schedules found'
                    }
                    onRowClick={(e) =>
                        navigate('/web/landing/hrms/shift-schedule/detail', {
                            state: { scheduleId: e.data.id },
                        })
                    }
                    selectionMode="single"
                    className="cursor-pointer"
                >
                    <Column field="scheduleName" header="Schedule Name" sortable />
                    <Column field="shiftTypeName" header="Shift Type" sortable />

                    <Column
                        field="startDate"
                        header="Start Date"
                        body={(row) => formatDate(row.startDate)}
                        sortable
                    />

                    <Column
                        field="endDate"
                        header="End Date"
                        body={(row) => formatDate(row.endDate)}
                        sortable
                    />

                    <Column
                        field="validFrom"
                        header="Valid From"
                        body={(row) => formatDate(row.validFrom)}
                        sortable
                    />

                    <Column
                        field="validUpto"
                        header="Valid Upto"
                        body={(row) => formatDate(row.validUpto)}
                        sortable
                    />
                </DataTable>
            </Card>
        </div>
    );
};

export default ShiftScheduleListView;