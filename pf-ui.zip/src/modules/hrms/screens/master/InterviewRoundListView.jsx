// src/pages/hrms/interview-round/InterviewRoundListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useInterviewRoundList from '../../hooks/master/useInterviewRoundList';

const InterviewRoundListView = () => {
  const navigate = useNavigate();

  const {
    data: rounds = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useInterviewRoundList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredRounds = searchTerm.trim()
    ? rounds.filter(item =>
        item.roundName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : rounds;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Interview Rounds' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Round Name',
      name: 'roundName',
      placeholder: 'e.g. Technical Round 1, HR Round, Final Interview',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.roundName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Interview Rounds</h4>
          <Button
            label="Add New Interview Round"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/interview-round/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredRounds}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load interview rounds'}` : 'No interview rounds found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/interview-round/detail', {
              state: { roundId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="roundName" header="Round Name" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default InterviewRoundListView;