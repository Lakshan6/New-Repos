// src/pages/hrms/shift-schedule/ShiftScheduleDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { useShiftSchedules } from '../../hooks/master/useShiftSchedules';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';
import { useShiftTypeList } from '../../hooks/master/useShiftTypeList';

const ShiftScheduleDetailView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
  const scheduleId = location.state?.scheduleId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    shiftSchedule: data,
    isLoading,
    isError,
    error,
    refetch,
    createShiftSchedule,
    updateShiftSchedule,
    deleteShiftSchedule,
    isCreating,
    isUpdating,
    isDeleting,
    mutationError,
  } = useShiftSchedules({ id: isCreateMode ? null : scheduleId, userInfo });

  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });
  const { data: shiftTypes = [], isLoading: isShiftTypesLoading } = useShiftTypeList();

  const shiftTypeOptions = shiftTypes.map(st => ({
    label: st.shiftName || `Shift ${st.id}`,
    value: st.id,
  }));

  const [formData, setFormData] = useState({
    scheduleName: '',
    startDate: null,
    endDate: null,
    tenantId: '',
    tenantRole: '',
    module: '',
    validFrom: null,
    validUpto: null,
    shiftTypeId: '',
  });
  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || [])
    .map(t => ({
      label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
      value: t.tenantId || t.id || t.code || '',
    }))
    .filter(t => t.value);

  // Redirect if no schedule selected in detail mode
  useEffect(() => {
    if (!isCreateMode && !scheduleId) {
      showToast('warn', 'No Schedule Selected', 'Please select a shift schedule from the list', 4000);
      navigate('/web/landing/hrms/shift-schedule', { replace: true });
    }
  }, [isCreateMode, scheduleId, navigate]);

  // Initialize form data from API
  useEffect(() => {
    if (!isCreateMode && data && !hasInitialized) {
      const initialData = {
        scheduleName: data.scheduleName ?? '',
        startDate: data.startDate ? new Date(data.startDate) : null,
        endDate: data.endDate ? new Date(data.endDate) : null,
        tenantId: data.tenantId ?? '',
        tenantRole: data.tenantRole ?? '',
        module: data.module ?? '',
        validFrom: data.validFrom ? new Date(data.validFrom) : null,
        validUpto: data.validUpto ? new Date(data.validUpto) : null,
        shiftTypeId: data.shiftType?.id ?? '',
      };
      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }
  }, [data, isCreateMode, hasInitialized]);

  const handleCancel = () => {
    if (isCreateMode) return navigate('/web/landing/hrms/shift-schedule');
    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {
    if (!formData.scheduleName?.trim()) return 'Schedule Name is required';
    if (!formData.shiftTypeId) return 'Shift Type is required';
    if (!formData.startDate) return 'Start Date is required';
    if (!formData.endDate) return 'End Date is required';
    if (formData.startDate && formData.endDate && formData.startDate > formData.endDate)
      return 'End Date must be after Start Date';
    if (isCreateMode && !formData.tenantId) return 'Tenant is required';
    if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
      return 'Valid Upto cannot be before Valid From';
    return null;
  };

  // ── KEY FIX: send shiftType as { id } object, not flat shiftTypeId ────────
  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: scheduleId }),
    scheduleName: formData.scheduleName.trim(),
    shiftType: { id: formData.shiftTypeId },
    startDate: formData.startDate instanceof Date
      ? formData.startDate.toISOString().split('T')[0]
      : formData.startDate,
    endDate: formData.endDate instanceof Date
      ? formData.endDate.toISOString().split('T')[0]
      : formData.endDate,
    tenantId: formData.tenantId || originalFormData.tenantId,
    tenantRole: formData.tenantRole || originalFormData.tenantRole,
    module: formData.module?.trim() || '',
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
  });

  const handleSave = async () => {
    const validationError = validateForm();
    if (validationError) return showToast('warn', 'Validation', validationError);

    const payload = buildPayload();

    try {
      if (isCreateMode) {
        await createShiftSchedule(payload);
        showToast('success', 'Created', 'Shift schedule created successfully');
        setTimeout(() => navigate('/web/landing/hrms/shift-schedule'), 900);
      } else {
        await updateShiftSchedule(payload);
        showToast('success', 'Updated', 'Shift schedule updated successfully');
        setIsEditing(false);
        refetch();
      }
    } catch (err) {
      const msg = err?.message || mutationError?.message || 'Something went wrong';
      showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
    }
  };

  const handleDelete = () =>
    confirmDialog({
      message: 'Are you sure you want to delete this shift schedule?\nThis action cannot be undone.',
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: async () => {
        try {
          await deleteShiftSchedule(scheduleId);
          showToast('success', 'Deleted', 'Shift schedule deleted successfully');
          setTimeout(() => navigate('/web/landing/hrms/shift-schedule'), 800);
        } catch (err) {
          const msg = err?.message || 'Could not delete shift schedule';
          showToast('error', 'Delete Failed', msg, 5000);
        }
      },
    });

  const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

  if (!isCreateMode && isLoading)
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading shift schedule details...</p>
          </div>
        </PageContentCard>
      </div>
    );

  if (!isCreateMode && (isError || !data))
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load shift schedule</h2>
            <p className="text-600 mb-4">{error?.message || 'Schedule not found or invalid access'}</p>
            <div className="flex gap-3">
              <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Shift Schedules', command: () => navigate('/web/landing/hrms/shift-schedule') },
    { label: isCreateMode ? 'Create Schedule' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const title = isCreateMode ? 'Create New Shift Schedule' : 'Shift Schedule Details';
  const subtitle = formData.scheduleName?.trim() || (isCreateMode ? 'New Shift Schedule' : '—');

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />

      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">{title}</h4>
            {!isCreateMode && scheduleId && (
              <Button
                size="small"
                label={scheduleId}
                severity="secondary"
                rounded
                onClick={() => navigator.clipboard.writeText(scheduleId)}
                tooltip="Copy ID"
              />
            )}
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">
            {isCreateMode ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Create"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isCreating}
                  size="small"
                />
              </>
            ) : isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  size="small"
                />
                <Button
                  label="Delete"
                  icon="pi pi-trash"
                  severity="danger"
                  outlined
                  onClick={handleDelete}
                  loading={isDeleting}
                  size="small"
                />
                <Button
                  label="Save"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isUpdating}
                  size="small"
                />
              </>
            ) : (
              <Button
                label="Edit"
                icon="pi pi-pencil"
                outlined
                onClick={() => setIsEditing(true)}
                size="small"
              />
            )}
          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder>
          <SectionCardWithHeader title="Schedule Information" subtitle={subtitle}>
            <div className="sc-grid-2 gap-4">

              {isCreateMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading}
                  />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Schedule Name *</label>
                <InputText
                  value={formData.scheduleName}
                  onChange={(e) => handleInputChange('scheduleName', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter schedule name' : ''}
                />
              </div>

              {/* Shift Type — required by backend as shiftType: { id } */}
              <div>
                <label className="block text-600 mb-1">Shift Type *</label>
                {(isCreateMode || isEditing) ? (
                  <Dropdown
                    value={formData.shiftTypeId}
                    options={shiftTypeOptions}
                    onChange={(e) => handleInputChange('shiftTypeId', e.value)}
                    placeholder="Select shift type"
                    className="w-full"
                    filter
                    showClear
                    disabled={isShiftTypesLoading}
                  />
                ) : (
                  <InputText
                    value={
                      shiftTypeOptions.find(o => o.value === formData.shiftTypeId)?.label ||
                      data?.shiftType?.shiftName ||
                      '—'
                    }
                    disabled
                    className="w-full bg-gray-100"
                  />
                )}
              </div>

              <div>
                <label className="block text-600 mb-1">Start Date *</label>
                <Calendar
                  value={formData.startDate}
                  onChange={(e) => handleInputChange('startDate', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select start date' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">End Date *</label>
                <Calendar
                  value={formData.endDate}
                  onChange={(e) => handleInputChange('endDate', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select end date' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Module</label>
                <InputText
                  value={formData.module}
                  onChange={(e) => handleInputChange('module', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter module name' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar
                  value={formData.validFrom}
                  onChange={(e) => handleInputChange('validFrom', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select valid from' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar
                  value={formData.validUpto}
                  onChange={(e) => handleInputChange('validUpto', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select valid upto' : ''}
                />
              </div>

              {!isCreateMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant ID</label>
                  <InputText
                    value={formData.tenantId}
                    disabled
                    className="w-full bg-gray-100"
                  />
                </div>
              )}

            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default ShiftScheduleDetailView;