// src/pages/master/SkillDetailView.jsx  (or wherever you keep it)
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputTextarea } from 'primereact/inputtextarea';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { useSkills } from '../../hooks/master/useSkills';           // ← new single hook
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const SkillDetailView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
  const skillId = location.state?.skillId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    skill: data,
    isLoading,
    isError,
    error,
    refetch,
    createSkill,
    updateSkill,
    deleteSkill,
    isCreating,
    isUpdating,
    isDeleting,
    mutationError,
  } = useSkills({ id: isCreateMode ? null : skillId, userInfo });

  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

  const [formData, setFormData] = useState({
    skillName: '',
    description: '',
    tenantId: '',
    tenantRole: '',
    module: '',
    validFrom: null,
    validUpto: null,
  });
  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || [])
    .map(t => ({
      label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
      value: t.tenantId || t.id || t.code || '',
    }))
    .filter(t => t.value);

  useEffect(() => {
    if (!isCreateMode && !skillId) {
      showToast('warn', 'No Skill Selected', 'Please select a skill from the list', 4000);
      navigate('/web/landing/hrms/skill', { replace: true });
    }
  }, [isCreateMode, skillId, navigate]);

  useEffect(() => {
    if (!isCreateMode && data && !hasInitialized) {
      const initialData = {
        skillName: data.skillName ?? '',
        description: data.description ?? '',
        tenantId: data.tenantId ?? '',
        tenantRole: data.tenantRole ?? '',
        module: data.module ?? '',
        validFrom: data.validFrom ? new Date(data.validFrom) : null,
        validUpto: data.validUpto ? new Date(data.validUpto) : null,
      };
      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }
  }, [data, isCreateMode, hasInitialized]);

  const handleCancel = () => {
    if (isCreateMode) return navigate('/web/landing/hrms/skill');
    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {
    if (!formData.skillName?.trim()) return 'Skill Name is required';
    if (isCreateMode && !formData.tenantId) return 'Tenant is required';
    if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
      return 'Valid Upto cannot be before Valid From';
    return null;
  };

  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: skillId }),
    skillName: formData.skillName.trim(),
    description: formData.description?.trim() || '',
    tenantId: formData.tenantId || originalFormData.tenantId,
    tenantRole: formData.tenantRole || originalFormData.tenantRole,
    module: formData.module?.trim() || '',
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
  });

  const handleSave = async () => {
    const validationError = validateForm();
    if (validationError) return showToast('warn', 'Validation', validationError);

    const payload = buildPayload();

    try {
      if (isCreateMode) {
        await createSkill(payload);
        showToast('success', 'Created', 'Skill created successfully');
        setTimeout(() => navigate('/web/landing/hrms/skill'), 900);
      } else {
        await updateSkill(payload);
        showToast('success', 'Updated', 'Skill updated successfully');
        setIsEditing(false);
        refetch();
      }
    } catch (err) {
      const msg = err?.message || mutationError?.message || 'Something went wrong';
      showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
    }
  };

  const handleDelete = () =>
    confirmDialog({
      message: 'Are you sure you want to delete this skill?\nThis action cannot be undone.',
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: async () => {
        try {
          await deleteSkill(skillId);
          showToast('success', 'Deleted', 'Skill deleted successfully');
          setTimeout(() => navigate('/web/landing/hrms/skill'), 800);
        } catch (err) {
          const msg = err?.message || 'Could not delete skill';
          showToast('error', 'Delete Failed', msg, 5000);
        }
      },
    });

  const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

  if (!isCreateMode && isLoading)
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading skill details...</p>
          </div>
        </PageContentCard>
      </div>
    );

  if (!isCreateMode && (isError || !data))
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load skill</h2>
            <p className="text-600 mb-4">{error?.message || 'Skill not found or invalid access'}</p>
            <div className="flex gap-3">
              <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Skills', command: () => navigate('/web/landing/hrms/skill') },
    { label: isCreateMode ? 'Create Skill' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const title = isCreateMode ? 'Create New Skill' : 'Skill Details';
  const subtitle = formData.skillName.trim() || (isCreateMode ? 'New Skill' : '—');

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">{title}</h4>
          </div>
          <div className="flex align-items-center gap-2 flex-wrap">
            {isCreateMode ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Create"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isCreating}
                  size="small"
                />
              </>
            ) : isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  size="small"
                />
                <Button
                  label="Delete"
                  icon="pi pi-trash"
                  severity="danger"
                  outlined
                  onClick={handleDelete}
                  loading={isDeleting}
                  size="small"
                />
                <Button
                  label="Save"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isUpdating}
                  size="small"
                />
              </>
            ) : (
              <Button label="Edit" icon="pi pi-pencil" outlined onClick={() => setIsEditing(true)} size="small" />
            )}
          </div>
        </div>

       <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder >
          <SectionCardWithHeader title="Skill Information" subtitle={subtitle}>
            <div className="sc-grid-2 gap-4">
              {isCreateMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading}
                  />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Skill Name *</label>
                <InputText
                  value={formData.skillName}
                  onChange={(e) => handleInputChange('skillName', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter skill name' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Description</label>
                <InputTextarea
                  rows={4}
                  value={formData.description}
                  onChange={(e) => handleInputChange('description', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter a short description' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Module</label>
                <InputText
                  value={formData.module}
                  onChange={(e) => handleInputChange('module', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter module name' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar
                  value={formData.validFrom}
                  onChange={(e) => handleInputChange('validFrom', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  className="w-full"
                  placeholder={isCreateMode ? 'Select start date' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar
                  value={formData.validUpto}
                  onChange={(e) => handleInputChange('validUpto', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  className="w-full"
                  placeholder={isCreateMode ? 'Select end date' : ''}
                />
              </div>
            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default SkillDetailView;