// src/pages/hrms/employee-grade/EmployeeGradeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useEmployeeGradeList from '../../hooks/master/useEmployeeGradeList';

const EmployeeGradeListView = () => {
  const navigate = useNavigate();

  const {
    data: grades = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useEmployeeGradeList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredGrades = searchTerm.trim()
    ? grades.filter(item =>
        item.gradeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : grades;



  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Employee Grades' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Grade Name',
      name: 'gradeName',
      placeholder: 'Enter grade name',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.gradeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(
      d.getMonth() + 1
    ).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      {/* Breadcrumb */}
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      {/* Search */}
      <SearchCard
        filters={searchFilters}
        onSubmit={handleSearch}
        onClear={handleClear}
      />

      {/* List Card */}
      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Employee Grades</h4>
          <Button
            label="Add New Grade"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/employee-grade/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredGrades}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError ? `Error: ${error?.message}` : 'No grades found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/employee-grade/detail', {
              state: { gradeId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="gradeName" header="Grade Name" sortable />
          <Column field="defaultSalaryStructure" header="Salary Structure" sortable />
          <Column field="defaultBasePay" header="Base Pay" sortable />
          <Column field="defaultCurrency" header="Currency" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default EmployeeGradeListView;