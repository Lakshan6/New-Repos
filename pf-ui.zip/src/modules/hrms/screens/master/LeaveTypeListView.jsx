import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeaveTypeList from '../../hooks/master/useLeaveTypeList';

const LeaveTypeListView = () => {
  const navigate = useNavigate();

  const {
    data: leaveTypes = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeaveTypeList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredTypes = searchTerm.trim()
    ? leaveTypes.filter(item =>
        item.leaveTypeName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : leaveTypes;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Types' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Leave Type',
      name: 'leaveTypeName',
      placeholder: 'e.g. Casual Leave, Sick Leave, Earned Leave',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.leaveTypeName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(
      2,
      '0'
    )}-${d.getFullYear()}`;
  };

  const yesNoTemplate = (value) => (
    <Tag value={value ? 'Yes' : 'No'} severity={value ? 'success' : 'danger'} rounded />
  );

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Types</h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/leave-type/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredTypes}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load data'}`
              : 'No leave types found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-type/detail', {
              state: { typeId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="leaveTypeName" header="Leave Type" sortable />
          <Column field="maxLeavesAllowed" header="Max Leaves" sortable />
          <Column
            field="carryForwardEncashedLeaves"
            header="Carry Forward"
            body={(row) => yesNoTemplate(row.carryForwardEncashedLeaves)}
            sortable
          />
          <Column
            field="isEarnedLeave"
            header="Earned Leave"
            body={(row) => yesNoTemplate(row.isEarnedLeave)}
            sortable
          />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeaveTypeListView;