// src/pages/hrms/purpose-of-travel/PurposeOfTravelListView.jsx
import React, { useEffect, useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import usePurposeOfTravelList from '../../hooks/master/usePurposeOfTravelList';

const PurposeOfTravelListView = () => {
    const navigate = useNavigate();

    const {
        data: purposes = [],
        isLoading,
        isError,
        error,
        refetch,
    } = usePurposeOfTravelList();

    const [filteredPurposes, setFilteredPurposes] = useState([]);

    useEffect(() => {
        setFilteredPurposes(purposes);
    }, [purposes]);

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Purpose of Travels' },
    ];

    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const searchFilters = [
        {
            type: 'InputText',
            label: 'Purpose Name',
            name: 'purposeName',
            placeholder: 'e.g. Client Meeting, Project Kickoff, Training, Site Visit',
        },
    ];

    const handleSearch = (values) => {
        const { purposeName } = values;

        if (!purposeName?.trim()) {
            setFilteredPurposes(purposes);
            return;
        }

        const filtered = purposes.filter((item) =>
            item.purposeName?.toLowerCase().includes(purposeName.toLowerCase())
        );

        setFilteredPurposes(filtered);
    };

    const handleClear = () => {
        setFilteredPurposes(purposes);
        refetch();
    };

    const formatDate = (dateString) => {
        if (!dateString) return '—';
        const d = new Date(dateString);
        return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
    };

    return (
        <div className="surface-ground min-h-screen p-3">
            {/* Breadcrumb */}
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {/* Search Card */}
            <SearchCard
                filters={searchFilters}
                onSubmit={handleSearch}
                onClear={handleClear}
            />

            <Card className="mt-4">
                {/* Header with Add button */}
                <div className="flex justify-content-between align-items-center mb-3 px-2">
                    <h4 className="m-0 text-2xl font-semibold">Purpose of Travels</h4>

                    <Button
                        label="Add New Purpose"
                        icon="pi pi-plus"
                        severity="success"
                        size="small"
                        onClick={() =>
                            navigate('/web/landing/hrms/purpose-of-travel/create')
                        }
                    />
                </div>

                <div className="border-top-1 surface-border mb-3" />

                {/* DataTable */}
                <DataTable
                    value={filteredPurposes}
                    stripedRows
                    paginator
                    rows={10}
                    rowsPerPageOptions={[10, 25, 50]}
                    rowHover
                    loading={isLoading}
                    emptyMessage={
                        isError
                            ? `Error: ${error?.message || 'Failed to load purposes'}`
                            : 'No purpose of travels found'
                    }
                    onRowClick={(e) => {
                        // Make sure to use the correct field from API
                        const id = e.data.purposeId ?? e.data.id;
                        if (!id) {
                            alert('Purpose not found or invalid access');
                            return;
                        }

                        navigate('/web/landing/hrms/purpose-of-travel/detail', {
                            state: { purposeId: id },
                        });
                    }}
                    selectionMode="single"
                    className="cursor-pointer"
                >
                    <Column field="purposeName" header="Purpose Name" sortable />
                    <Column field="description" header="Description" sortable />
                    <Column field="module" header="Module" sortable />
                    <Column
                        field="validFrom"
                        header="Valid From"
                        body={(row) => formatDate(row.validFrom)}
                        sortable
                    />
                    <Column
                        field="validUpto"
                        header="Valid Upto"
                        body={(row) => formatDate(row.validUpto)}
                        sortable
                    />
                </DataTable>
            </Card>
        </div>
    );
};

export default PurposeOfTravelListView;