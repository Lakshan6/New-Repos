// src/pages/hrms/appraisal-template-goal/AppraisalTemplateGoalListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useAppraisalTemplateGoalList from '../../hooks/master/useAppraisalTemplateGoalList';

const AppraisalTemplateGoalListView = () => {
  const navigate = useNavigate();

  const {
    data: goals = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useAppraisalTemplateGoalList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredGoals = searchTerm.trim()
    ? goals.filter(item =>
        item.kraName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : goals;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Appraisal Template Goals' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'KRA Name',
      name: 'kraName',
      placeholder: 'e.g. Technical Excellence, Leadership, Teamwork',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.kraName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  const weightageTemplate = (row) => `${row.perWeightage}%`;

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Appraisal Template Goals (KRAs)</h4>
          <Button
            label="Add New Goal"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/appraisal-template-goal/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredGoals}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load goals'}`
              : 'No appraisal goals found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/appraisal-template-goal/detail', {
              state: { goalId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="kraName" header="KRA / Goal Name" sortable />
          <Column field="appraisalTemplateName" header="Appraisal Template" sortable />
          <Column field="perWeightage" header="Weightage" body={weightageTemplate} sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default AppraisalTemplateGoalListView;