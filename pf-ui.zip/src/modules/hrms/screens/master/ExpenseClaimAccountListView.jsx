// src/pages/hrms/expense-claim-account/ExpenseClaimAccountListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useExpenseClaimAccountList from '../../hooks/master/useExpenseClaimAccountList';

const ExpenseClaimAccountListView = () => {
  const navigate = useNavigate();

  const {
    data: accounts = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useExpenseClaimAccountList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredAccounts = searchTerm.trim()
    ? accounts.filter(item =>
        item.defaultAccount?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : accounts;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Expense Claim Accounts' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Account Name',
      name: 'defaultAccount',
      placeholder: 'e.g. Main Travel Account, Medical Reimbursement Account',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.defaultAccount || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Expense Claim Accounts</h4>
          <Button
            label="Add Expense Claim Account"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/expense-claim-account/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredAccounts}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load accounts'}` : 'No expense claim accounts found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/expense-claim-account/detail', {
              state: { accountId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="defaultAccount" header="Account Name" sortable />
          <Column field="expenseClaimTypeName" header="Expense Type" sortable />
          <Column field="module" header="Module" sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default ExpenseClaimAccountListView;