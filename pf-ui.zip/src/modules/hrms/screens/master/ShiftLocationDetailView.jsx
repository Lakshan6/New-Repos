// src/pages/hrms/shift-location/ShiftLocationDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { useShiftLocations } from '../../hooks/master/useShiftLocations';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const ShiftLocationDetailView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
  const locationId = location.state?.locationId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    location: data,
    isLoading,
    isError,
    error,
    refetch,
    createLocation,
    updateLocation,
    deleteLocation,
    isCreating,
    isUpdating,
    isDeleting,
    mutationError,
  } = useShiftLocations({ id: isCreateMode ? null : locationId, userInfo });

  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

  const [formData, setFormData] = useState({
    locationName: '',
    address: '',
    latitude: null,
    longitude: null,
    tenantId: '',
    tenantRole: '',
    module: '',
    validFrom: null,
    validUpto: null,
  });

  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (field, value) =>
    setFormData((prev) => ({ ...prev, [field]: value }));

  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || [])
    .map((t) => ({
      label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
      value: t.tenantId || t.id || t.code || '',
    }))
    .filter((t) => t.value);

  useEffect(() => {
    if (!isCreateMode && !locationId) {
      showToast('warn', 'No Location Selected', 'Please select a shift location from the list', 4000);
      navigate('/web/landing/hrms/shift-location', { replace: true });
    }
  }, [isCreateMode, locationId, navigate]);

  useEffect(() => {
    if ((data || isCreateMode) && !hasInitialized) {
      const initialData = {
        locationName: data?.locationName ?? '',
        address: data?.address ?? '',
        latitude: data?.latitude ?? null,
        longitude: data?.longitude ?? null,
        tenantId: data?.tenantId ?? '',
        tenantRole: data?.tenantRole ?? '',
        module: data?.module ?? '',
        validFrom: data?.validFrom ? new Date(data.validFrom) : null,
        validUpto: data?.validUpto ? new Date(data.validUpto) : null,
      };
      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }
  }, [data, isCreateMode, hasInitialized]);

  const handleCancel = () => {
    if (isCreateMode) return navigate('/web/landing/hrms/shift-location');
    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {
    if (!formData.locationName?.trim()) return 'Location Name is required';
    if (isCreateMode && !formData.tenantId) return 'Tenant is required';
    if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
      return 'Valid Upto cannot be before Valid From';
    return null;
  };

  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: locationId }),
    locationName: formData.locationName.trim(),
    address: formData.address?.trim() || '',
    latitude: formData.latitude ?? null,
    longitude: formData.longitude ?? null,
    tenantId: formData.tenantId || originalFormData.tenantId,
    tenantRole: formData.tenantRole || originalFormData.tenantRole,
    module: formData.module?.trim() || '',
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
  });

  const handleSave = async () => {
    const validationError = validateForm();
    if (validationError) return showToast('warn', 'Validation', validationError);

    const payload = buildPayload();

    try {
      if (isCreateMode) {
        await createLocation(payload);
        showToast('success', 'Created', 'Shift location created successfully');
        navigate('/web/landing/hrms/shift-location');
      } else {
        await updateLocation(payload);
        showToast('success', 'Updated', 'Shift location updated successfully');
        setIsEditing(false);
        refetch();
      }
    } catch (err) {
      const msg = err?.message || mutationError?.message || 'Something went wrong';
      showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
    }
  };

  const handleDelete = () =>
    confirmDialog({
      message: 'Are you sure you want to delete this shift location?\nThis action cannot be undone.',
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: async () => {
        try {
          await deleteLocation(locationId);
          showToast('success', 'Deleted', 'Shift location deleted successfully');
          navigate('/web/landing/hrms/shift-location');
        } catch (err) {
          const msg = err?.message || 'Could not delete shift location';
          showToast('error', 'Delete Failed', msg, 5000);
        }
      },
    });

  const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

  if (!isCreateMode && isLoading)
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading shift location details...</p>
          </div>
        </PageContentCard>
      </div>
    );

  if (!isCreateMode && (isError || !data))
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load shift location</h2>
            <p className="text-600 mb-4">{error?.message || 'Shift location not found or invalid access'}</p>
            <div className="flex gap-3">
              <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Shift Locations', command: () => navigate('/web/landing/hrms/shift-location') },
    { label: isCreateMode ? 'Create Shift Location' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">{isCreateMode ? 'Create New Shift Location' : 'Shift Location Details'}</h4>
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">
            {isCreateMode ? (
              <>
                <Button label="Cancel" icon="pi pi-times" outlined severity="secondary" onClick={handleCancel} disabled={isAnyMutationRunning} size="small" />
                <Button label="Create" icon="pi pi-save" severity="success" onClick={handleSave} loading={isCreating} size="small" />
              </>
            ) : isEditing ? (
              <>
                <Button label="Cancel" icon="pi pi-times" outlined severity="secondary" onClick={handleCancel} size="small" />
                <Button label="Delete" icon="pi pi-trash" severity="danger" outlined onClick={handleDelete} loading={isDeleting} size="small" />
                <Button label="Save" icon="pi pi-save" severity="success" onClick={handleSave} loading={isUpdating} size="small" />
              </>
            ) : (
              <Button label="Edit" icon="pi pi-pencil" outlined onClick={() => setIsEditing(true)} size="small" />
            )}
          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder>
          <SectionCardWithHeader title="Shift Location Information" subtitle={formData.locationName || '—'}>
            <div className="sc-grid-2 gap-4">
              {(isCreateMode || isEditing) && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown value={formData.tenantId} options={tenantOptions} onChange={(e) => handleInputChange('tenantId', e.value)} placeholder="Select tenant" className="w-full" filter showClear disabled={isTenantsLoading} />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Location Name *</label>
                <InputText value={formData.locationName} onChange={(e) => handleInputChange('locationName', e.target.value)} disabled={!isCreateMode && !isEditing} className="w-full" />
              </div>

              <div>
                <label className="block text-600 mb-1">Address</label>
                <InputText value={formData.address} onChange={(e) => handleInputChange('address', e.target.value)} disabled={!isCreateMode && !isEditing} className="w-full" />
              </div>

              <div>
                <label className="block text-600 mb-1">Latitude</label>
                <InputNumber value={formData.latitude} onChange={(e) => handleInputChange('latitude', e.value)} disabled={!isCreateMode && !isEditing} min={-90} max={90} decimalScale={6} className="w-full" />
              </div>

              <div>
                <label className="block text-600 mb-1">Longitude</label>
                <InputNumber value={formData.longitude} onChange={(e) => handleInputChange('longitude', e.value)} disabled={!isCreateMode && !isEditing} min={-180} max={180} decimalScale={6} className="w-full" />
              </div>

              <div>
                <label className="block text-600 mb-1">Module</label>
                <InputText value={formData.module} onChange={(e) => handleInputChange('module', e.target.value)} disabled={!isCreateMode && !isEditing} className="w-full" />
              </div>

              {!isCreateMode && !isEditing && (
                <div>
                  <label className="block text-600 mb-1">Tenant</label>
                  <InputText value={formData.tenantId} disabled className="w-full bg-gray-100" />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar value={formData.validFrom} onChange={(e) => handleInputChange('validFrom', e.value)} disabled={!isCreateMode && !isEditing} showIcon className="w-full" />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar value={formData.validUpto} onChange={(e) => handleInputChange('validUpto', e.value)} disabled={!isCreateMode && !isEditing} showIcon className="w-full" />
              </div>
            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default ShiftLocationDetailView;