// src/pages/hrms/onboarding-template/OnboardingTemplateDetailView.jsx

import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { Dropdown } from 'primereact/dropdown';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useOnboardingTemplate from '../../hooks/master/useOnboardingTemplate';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const OnboardingTemplateDetailView = () => {

  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const templateId = location.state?.templateId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    template,
    isLoading,
    isError,
    error,
    refetch,
    updateTemplate,
    createTemplate,
    isUpdating,
    isCreating
  } = useOnboardingTemplate({ id: isCreateMode ? null : templateId });

  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

  const [formData, setFormData] = useState({
    templateName: '',
    tenantId: '',
    tenantRole: '',
    module: '',
    validFrom: null,
    validUpto: null,
    revId: 1,
  });

  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (field, value) =>
    setFormData((prev) => ({ ...prev, [field]: value }));

  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || [])
    .map((t) => ({
      label: t.name || t.tenantName || t.displayName || t.code || 'Unnamed Tenant',
      value: t.tenantId || t.id || t.code || '',
    }))
    .filter((t) => t.value);

  useEffect(() => {

    if ((template || isCreateMode) && !hasInitialized) {

      const initialData = {
        templateName: template?.templateName ?? '',
        tenantId: template?.tenantId ?? '',
        tenantRole: template?.tenantRole ?? '',
        module: template?.module ?? '',
        validFrom: template?.validFrom ? new Date(template.validFrom) : null,
        validUpto: template?.validUpto ? new Date(template.validUpto) : null,
        revId: template?.revId ?? 1,
      };

      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }

  }, [template, isCreateMode, hasInitialized]);

  const handleCancel = () => {

    if (isCreateMode) {
      return navigate('/web/landing/hrms/employee-onboarding-template');
    }

    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {

    if (!formData.templateName?.trim())
      return 'Template Name is required';

    if (isCreateMode && !formData.tenantId)
      return 'Tenant is required';

    if (
      formData.validFrom &&
      formData.validUpto &&
      formData.validFrom > formData.validUpto
    ) {
      return 'Valid Upto cannot be before Valid From';
    }

    return null;
  };

  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: templateId }),
    templateName: formData.templateName.trim(),
    tenantId: formData.tenantId || originalFormData.tenantId,
    tenantRole: formData.tenantRole || originalFormData.tenantRole,
    module: formData.module?.trim() || '',
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
    revId: formData.revId,
  });

  const handleSave = async () => {

    const validationError = validateForm();

    if (validationError)
      return showToast('warn', 'Validation Error', validationError);

    const payload = buildPayload();

    try {

      if (isCreateMode) {

        await createTemplate(payload);
        showToast('success', 'Created', 'Onboarding template created successfully');

      } else {

        await updateTemplate(payload);
        showToast('success', 'Updated', 'Onboarding template updated successfully');

      }

      setIsEditing(false);
      refetch();

    } catch (err) {

      const msg = err?.message || 'Something went wrong';
      showToast('error', 'Operation Failed', msg, 6000);

    }
  };

  const isAnyMutationRunning = isUpdating || isCreating;

  if (!isCreateMode && isLoading) {
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading template details...</p>
          </div>
        </PageContentCard>
      </div>
    );
  }

  if (!isCreateMode && (isError || !template)) {
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load template</h2>
            <p className="text-600 mb-4">
              {error?.message || 'Template not found or invalid access'}
            </p>
            <div className="flex gap-3">
              <Button
                label="Go Back"
                icon="pi pi-arrow-left"
                outlined
                onClick={() => navigate(-1)}
              />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );
  }

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    {
      label: 'Onboarding Templates',
      command: () => navigate('/web/landing/hrms/employee-onboarding-template'),
    },
    { label: isCreateMode ? 'Create Template' : 'Details' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  return (
    <div className="surface-ground min-h-screen p-1">

      <Toast ref={toast} />
      <ConfirmDialog />

      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">

        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">

          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">
              {isCreateMode
                ? 'Create New Onboarding Template'
                : 'Onboarding Template Details'}
            </h4>
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">

            {isCreateMode ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Create"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isAnyMutationRunning}
                  size="small"
                />
              </>
            ) : isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  size="small"
                />
                <Button
                  label="Save"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isUpdating}
                  size="small"
                />
              </>
            ) : (
              <Button
                label="Edit"
                icon="pi pi-pencil"
                outlined
                onClick={() => setIsEditing(true)}
                size="small"
              />
            )}

          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder>

          <SectionCardWithHeader
            title="Template Information"
            subtitle={formData.templateName || '—'}
          >

            <div className="sc-grid-2 gap-4">

              {(isCreateMode || isEditing) && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading}
                  />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Template Name *</label>
                <InputText
                  value={formData.templateName}
                  onChange={(e) =>
                    handleInputChange('templateName', e.target.value)
                  }
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Module</label>
                <InputText
                  value={formData.module}
                  onChange={(e) => handleInputChange('module', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              {!isCreateMode && !isEditing && (
                <div>
                  <label className="block text-600 mb-1">Tenant</label>
                  <InputText
                    value={formData.tenantId}
                    disabled
                    className="w-full bg-gray-100"
                  />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar
                  value={formData.validFrom}
                  onChange={(e) => handleInputChange('validFrom', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar
                  value={formData.validUpto}
                  onChange={(e) => handleInputChange('validUpto', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                />
              </div>

              {!isCreateMode && !isEditing && (
                <div>
                  <label className="block text-600 mb-1">Revision ID</label>
                  <InputText
                    value={formData.revId}
                    disabled
                    className="w-full bg-gray-100"
                  />
                </div>
              )}

            </div>

          </SectionCardWithHeader>

        </TabbedSectionCard>

      </PageContentCard>
    </div>
  );
};

export default OnboardingTemplateDetailView;