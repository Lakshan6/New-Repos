// src/pages/hrms/designation-skill/DesignationSkillDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { Calendar } from 'primereact/calendar';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useDesignationSkills from '../../hooks/master/useDesignationSkills';
import { useSkillList } from '../../hooks/master/useSkillList';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

// ── Static options ──────────────────────────────────────────────────────────
const PROFICIENCY_OPTIONS = [
  { label: 'Expert', value: 'Expert' },
  { label: 'Advanced', value: 'Advanced' },
  { label: 'Intermediate', value: 'Intermediate' },
  { label: 'Beginner', value: 'Beginner' },
];

const DesignationSkillDetailView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
  const skillId = location.state?.skillId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    designationSkill: data,
    isLoading,
    isError,
    error,
    refetch,
    createDesignationSkill,
    updateDesignationSkill,
    deleteDesignationSkill,
    isCreating,
    isUpdating,
    isDeleting,
    mutationError,
  } = useDesignationSkills({ id: isCreateMode ? null : skillId, userInfo });

  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });
  const { data: coreSkills = [], isLoading: isSkillsLoading } = useSkillList();

  const [formData, setFormData] = useState({
    skillName: '',
    proficiency: '',
    coreSkillId: '',   // stores the selected core skill id
    module: '',
    tenantId: '',
    tenantRole: '',
    validFrom: null,
    validUpto: null,
  });
  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || []).map(t => ({
    label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
    value: t.tenantId || t.id || t.code || '',
  }));

  const coreSkillOptions = coreSkills.map(s => ({
    label: s.skillName || s.id,
    value: s.id,
  }));

  // Redirect if no skill selected in detail mode
  useEffect(() => {
    if (!isCreateMode && !skillId) {
      showToast('warn', 'No Skill Selected', 'Please select a designation skill', 4000);
      navigate('/web/landing/hrms/designation-skill', { replace: true });
    }
  }, [isCreateMode, skillId, navigate]);

  // Initialize form data from API
  // ── KEY FIX: read coreSkillId from data.skill?.id (not data.coreSkillId) ─
  useEffect(() => {
    if (!isCreateMode && data && !hasInitialized) {
      const initialData = {
        skillName: data.skillName || '',
        proficiency: data.proficiency || '',
        coreSkillId: data.skill?.id || '',
        module: data.module || '',
        tenantId: data.tenantId || '',
        tenantRole: data.tenantRole || '',
        validFrom: data.validFrom ? new Date(data.validFrom) : null,
        validUpto: data.validUpto ? new Date(data.validUpto) : null,
      };
      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }
  }, [data, isCreateMode, hasInitialized]);

  const handleCancel = () => {
    if (isCreateMode) return navigate('/web/landing/hrms/designation-skill');
    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {
    if (!formData.skillName?.trim()) return 'Skill Name is required';
    if (!formData.coreSkillId) return 'Core Skill is required';
    if (isCreateMode && !formData.tenantId) return 'Tenant is required';
    if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
      return 'Valid Upto cannot be before Valid From';
    return null;
  };

  // ── KEY FIX: send skill as { id } object, not flat coreSkillId ───────────
  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: skillId }),
    skillName: formData.skillName.trim(),
    proficiency: formData.proficiency?.trim() || '',
    skill: { id: formData.coreSkillId },
    module: formData.module?.trim() || '',
    tenantId: formData.tenantId || originalFormData.tenantId,
    tenantRole: formData.tenantRole || originalFormData.tenantRole,
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
  });

  const handleSave = async () => {
    const validationError = validateForm();
    if (validationError) return showToast('warn', 'Validation', validationError);

    const payload = buildPayload();

    try {
      if (isCreateMode) {
        await createDesignationSkill(payload);
        showToast('success', 'Created', 'Designation skill created successfully');
        setTimeout(() => navigate('/web/landing/hrms/designation-skill'), 900);
      } else {
        await updateDesignationSkill(payload);
        showToast('success', 'Updated', 'Designation skill updated successfully');
        setIsEditing(false);
        refetch();
      }
    } catch (err) {
      const msg = err?.message || mutationError?.message || 'Something went wrong';
      showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
    }
  };

  const handleDelete = () =>
    confirmDialog({
      message: 'Are you sure you want to delete this skill?\nThis action cannot be undone.',
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: async () => {
        try {
          await deleteDesignationSkill(skillId);
          showToast('success', 'Deleted', 'Designation skill deleted successfully');
          setTimeout(() => navigate('/web/landing/hrms/designation-skill'), 800);
        } catch (err) {
          const msg = err?.message || 'Could not delete skill';
          showToast('error', 'Delete Failed', msg, 5000);
        }
      },
    });

  const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

  if (!isCreateMode && isLoading)
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading designation skill details...</p>
          </div>
        </PageContentCard>
      </div>
    );

  if (!isCreateMode && (isError || !data))
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load designation skill</h2>
            <p className="text-600 mb-4">{error?.message || 'Skill not found or invalid access'}</p>
            <div className="flex gap-3">
              <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Designation Skills', command: () => navigate('/web/landing/hrms/designation-skill') },
    { label: isCreateMode ? 'Create Skill' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const title = isCreateMode ? 'Create New Designation Skill' : 'Designation Skill Details';
  const subtitle = formData.skillName?.trim() || (isCreateMode ? 'New Designation Skill' : '—');

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />

      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">{title}</h4>
            {!isCreateMode && skillId && (
              <Button
                size="small"
                label={skillId}
                severity="secondary"
                rounded
                onClick={() => navigator.clipboard.writeText(skillId)}
                tooltip="Copy ID"
              />
            )}
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">
            {isCreateMode ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Create"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isCreating}
                  size="small"
                />
              </>
            ) : isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  size="small"
                />
                <Button
                  label="Delete"
                  icon="pi pi-trash"
                  severity="danger"
                  outlined
                  onClick={handleDelete}
                  loading={isDeleting}
                  size="small"
                />
                <Button
                  label="Save"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isUpdating}
                  size="small"
                />
              </>
            ) : (
              <Button
                label="Edit"
                icon="pi pi-pencil"
                outlined
                onClick={() => setIsEditing(true)}
                size="small"
              />
            )}
          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder>
          <SectionCardWithHeader title="Skill Information" subtitle={subtitle}>
            <div className="sc-grid-2 gap-4">

              {isCreateMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading}
                  />
                </div>
              )}

              {/* Core Skill — required by backend as skill: { id } */}
              <div>
                <label className="block text-600 mb-1">Core Skill *</label>
                {(isCreateMode || isEditing) ? (
                  <Dropdown
                    value={formData.coreSkillId}
                    options={coreSkillOptions}
                    onChange={(e) => handleInputChange('coreSkillId', e.value)}
                    placeholder="Select core skill"
                    className="w-full"
                    filter
                    showClear
                    disabled={isSkillsLoading}
                  />
                ) : (
                  <InputText
                    value={
                      coreSkillOptions.find(o => o.value === formData.coreSkillId)?.label ||
                      data?.skill?.skillName ||
                      '—'
                    }
                    disabled
                    className="w-full bg-gray-100"
                  />
                )}
              </div>

              <div>
                <label className="block text-600 mb-1">Skill Name *</label>
                <InputText
                  value={formData.skillName}
                  onChange={(e) => handleInputChange('skillName', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter designation skill name' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Proficiency</label>
                {(isCreateMode || isEditing) ? (
                  <Dropdown
                    value={formData.proficiency}
                    options={PROFICIENCY_OPTIONS}
                    onChange={(e) => handleInputChange('proficiency', e.value)}
                    placeholder="Select proficiency"
                    className="w-full"
                    showClear
                  />
                ) : (
                  <InputText
                    value={formData.proficiency || '—'}
                    disabled
                    className="w-full bg-gray-100"
                  />
                )}
              </div>

              <div>
                <label className="block text-600 mb-1">Module</label>
                <InputText
                  value={formData.module}
                  onChange={(e) => handleInputChange('module', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter module name' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar
                  value={formData.validFrom}
                  onChange={(e) => handleInputChange('validFrom', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select valid from' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar
                  value={formData.validUpto}
                  onChange={(e) => handleInputChange('validUpto', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select valid upto' : ''}
                />
              </div>

              {!isCreateMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant ID</label>
                  <InputText
                    value={formData.tenantId}
                    disabled
                    className="w-full bg-gray-100"
                  />
                </div>
              )}

            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default DesignationSkillDetailView;