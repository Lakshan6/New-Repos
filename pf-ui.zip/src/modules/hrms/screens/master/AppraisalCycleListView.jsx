// src/pages/hrms/appraisal-cycle/AppraisalCycleListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';
import SearchCard from '@shared/components/SearchCard';

import useAppraisalCycleList from '../../hooks/master/useAppraisalCycleList';

const AppraisalCycleListView = () => {
  const navigate = useNavigate();

  const {
    data: cycles = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useAppraisalCycleList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredCycles = searchTerm.trim()
    ? cycles.filter(item =>
        item.cycleName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : cycles;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Appraisal Cycles' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Cycle Name',
      name: 'cycleName',
      placeholder: 'e.g. FY 2026 Appraisal Cycle, Annual Review 2025',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.cycleName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Appraisal Cycles</h4>
          <Button
            label="Add New Cycle"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/appraisal-cycle/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredCycles}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load cycles'}`
              : 'No appraisal cycles found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/appraisal-cycle/detail', {
              state: { cycleId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="cycleName" header="Cycle Name" sortable />
          <Column field="startDate" header="Start Date" body={(row) => formatDate(row.startDate)} sortable />
          <Column field="endDate" header="End Date" body={(row) => formatDate(row.endDate)} sortable />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default AppraisalCycleListView;