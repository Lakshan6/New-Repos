// src/pages/hrms/appointment-letter-content/AppointmentLetterContentListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useAppointmentLetterContentList from '../../hooks/master/useAppointmentLetterContentList';

const AppointmentLetterContentListView = () => {
  const navigate = useNavigate();

  const {
    data: contents = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useAppointmentLetterContentList();

  const [searchTerm, setSearchTerm] = useState('');

  // ── KEY FIX: derive filtered list inline instead of useEffect + setState ──
  const filteredContents = searchTerm.trim()
    ? contents.filter(item =>
        item.title?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : contents;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Appointment Letter Contents' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Title',
      name: 'title',
      placeholder: 'e.g. Job Title & Role, Salary & Benefits, Terms & Conditions',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.title || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Appointment Letter Contents</h4>
          <Button
            label="Add New Content"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/appointment-letter-content/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredContents}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load contents'}`
              : 'No appointment letter contents found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/appointment-letter-content/detail', {
              state: { contentId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="title" header="Title" sortable />
          <Column field="appointmentLetterTemplateName" header="Letter Template" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default AppointmentLetterContentListView;