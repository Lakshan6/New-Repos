// src/pages/hrms/hr-settings/HRSettingsDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputSwitch } from 'primereact/inputswitch';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { useHRSettings } from '../../hooks/master/useHRSettings';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const HRSettingsDetailView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
  const settingsId = location.state?.settingId || location.state?.settingsId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    settings: data,
    isLoading,
    isError,
    error,
    refetch,
    createHRSettings,
    updateHRSettings,
    deleteHRSettings,
    isCreating,
    isUpdating,
    isDeleting,
    mutationError,
  } = useHRSettings({ id: isCreateMode ? null : settingsId, userInfo });

  const [formData, setFormData] = useState({
    sender: '',
    hiringSender: '',
    leaveApprovalNotificationTemplate: '',
    leaveStatusNotificationTemplate: '',
    feedbackReminderNotificationTemplate: '',
    interviewReminderTemplate: '',
    exitQuestionnaireNotificationTemplate: '',
    roleAllowedToCreateBackdatedLeaveApplication: '',
    exitQuestionnaireWebForm: '',
    autoLeaveEncashment: false,
    restrictBackdatedLeaveApplication: false,
    emailSalarySlipToEmployee: false,
    encryptSalarySlipsInEmails: false,
    passwordPolicy: '',
    stopBirthdayReminders: false,
    sendHolidayReminders: false,
    tenantId: '',
    validFrom: null,
    validUpto: null,
  });

  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  // Moved here — now isEditing is already defined → no more initialization error
  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({
    enabled: isCreateMode || isEditing,
  });

  const handleInputChange = (field, value) =>
    setFormData((prev) => ({ ...prev, [field]: value }));

  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || [])
    .map((t) => ({
      label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
      value: t.tenantId || t.id || t.code || '',
    }))
    .filter((t) => t.value);

  // Redirect if no ID in view mode
  useEffect(() => {
    if (!isCreateMode && !settingsId) {
      showToast('warn', 'No HR Settings Selected', 'Please select HR Settings from the list', 4000);
      navigate('/web/landing/hrms/hr-settings', { replace: true });
    }
  }, [isCreateMode, settingsId, navigate]);

  // Initialize form
  useEffect(() => {
    if ((data || isCreateMode) && !hasInitialized) {
      const initialData = isCreateMode
        ? { ...formData }
        : {
            sender: data?.sender ?? '',
            hiringSender: data?.hiringSender ?? '',
            leaveApprovalNotificationTemplate: data?.leaveApprovalNotificationTemplate ?? '',
            leaveStatusNotificationTemplate: data?.leaveStatusNotificationTemplate ?? '',
            feedbackReminderNotificationTemplate: data?.feedbackReminderNotificationTemplate ?? '',
            interviewReminderTemplate: data?.interviewReminderTemplate ?? '',
            exitQuestionnaireNotificationTemplate: data?.exitQuestionnaireNotificationTemplate ?? '',
            roleAllowedToCreateBackdatedLeaveApplication:
              data?.roleAllowedToCreateBackdatedLeaveApplication ?? '',
            exitQuestionnaireWebForm: data?.exitQuestionnaireWebForm ?? '',
            autoLeaveEncashment: data?.autoLeaveEncashment ?? false,
            restrictBackdatedLeaveApplication: data?.restrictBackdatedLeaveApplication ?? false,
            emailSalarySlipToEmployee: data?.emailSalarySlipToEmployee ?? false,
            encryptSalarySlipsInEmails: data?.encryptSalarySlipsInEmails ?? false,
            passwordPolicy: data?.passwordPolicy ?? '',
            stopBirthdayReminders: data?.stopBirthdayReminders ?? false,
            sendHolidayReminders: data?.sendHolidayReminders ?? false,
            tenantId: data?.tenantId ?? '',
            validFrom: data?.validFrom ? new Date(data.validFrom) : null,
            validUpto: data?.validUpto ? new Date(data.validUpto) : null,
          };

      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }
  }, [data, isCreateMode, hasInitialized]);

  const handleCancel = () => {
    if (isCreateMode) return navigate('/web/landing/hrms/hr-settings');
    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {
    if (!formData.sender?.trim()) return 'Default Sender Email is required';
    if (isCreateMode && !formData.tenantId) return 'Tenant is required';
    if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto) {
      return 'Valid Upto cannot be before Valid From';
    }
    return null;
  };

  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: settingsId }),
    sender: formData.sender.trim(),
    hiringSender: formData.hiringSender.trim(),
    leaveApprovalNotificationTemplate: formData.leaveApprovalNotificationTemplate.trim(),
    leaveStatusNotificationTemplate: formData.leaveStatusNotificationTemplate.trim(),
    feedbackReminderNotificationTemplate: formData.feedbackReminderNotificationTemplate.trim(),
    interviewReminderTemplate: formData.interviewReminderTemplate.trim(),
    exitQuestionnaireNotificationTemplate: formData.exitQuestionnaireNotificationTemplate.trim(),
    roleAllowedToCreateBackdatedLeaveApplication: formData.roleAllowedToCreateBackdatedLeaveApplication.trim(),
    exitQuestionnaireWebForm: formData.exitQuestionnaireWebForm.trim(),
    autoLeaveEncashment: formData.autoLeaveEncashment,
    restrictBackdatedLeaveApplication: formData.restrictBackdatedLeaveApplication,
    emailSalarySlipToEmployee: formData.emailSalarySlipToEmployee,
    encryptSalarySlipsInEmails: formData.encryptSalarySlipsInEmails,
    passwordPolicy: formData.passwordPolicy.trim(),
    stopBirthdayReminders: formData.stopBirthdayReminders,
    sendHolidayReminders: formData.sendHolidayReminders,
    tenantId: formData.tenantId || originalFormData.tenantId,
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
  });

  const handleSave = async () => {
    const validationError = validateForm();
    if (validationError) return showToast('warn', 'Validation Error', validationError);

    const payload = buildPayload();

    try {
      if (isCreateMode) {
        await createHRSettings(payload);
        showToast('success', 'Created', 'HR Settings created successfully');
        setTimeout(() => navigate('/web/landing/hrms/hr-settings'), 900);
      } else {
        await updateHRSettings(payload);
        showToast('success', 'Updated', 'HR Settings updated successfully');
        setIsEditing(false);
        refetch();
      }
    } catch (err) {
      const msg = err?.message || mutationError?.message || 'Something went wrong';
      showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
    }
  };

  const handleDelete = () =>
    confirmDialog({
      message: 'Are you sure you want to delete this HR Settings?\nThis action cannot be undone.',
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: async () => {
        try {
          await deleteHRSettings(settingsId);
          showToast('success', 'Deleted', 'HR Settings deleted successfully');
          setTimeout(() => navigate('/web/landing/hrms/hr-settings'), 800);
        } catch (err) {
          const msg = err?.message || 'Could not delete HR Settings';
          showToast('error', 'Delete Failed', msg, 5000);
        }
      },
    });

  const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

  if (!isCreateMode && isLoading) {
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading HR Settings details...</p>
          </div>
        </PageContentCard>
      </div>
    );
  }

  if (!isCreateMode && (isError || !data)) {
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load HR Settings</h2>
            <p className="text-600 mb-4">{error?.message || 'HR Settings not found or invalid access'}</p>
            <div className="flex gap-3">
              <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );
  }

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'HR Settings', command: () => navigate('/web/landing/hrms/hr-settings') },
    { label: isCreateMode ? 'Create HR Settings' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />

      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">
              {isCreateMode ? 'Create New HR Settings' : 'HR Settings Details'}
            </h4>
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">
            {isCreateMode || isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                {isCreateMode ? (
                  <Button
                    label="Create"
                    icon="pi pi-save"
                    severity="success"
                    onClick={handleSave}
                    loading={isCreating}
                    size="small"
                  />
                ) : (
                  <>
                    <Button
                      label="Delete"
                      icon="pi pi-trash"
                      severity="danger"
                      outlined
                      onClick={handleDelete}
                      loading={isDeleting}
                      size="small"
                    />
                    <Button
                      label="Save"
                      icon="pi pi-save"
                      severity="success"
                      onClick={handleSave}
                      loading={isUpdating}
                      size="small"
                    />
                  </>
                )}
              </>
            ) : (
              <Button
                label="Edit"
                icon="pi pi-pencil"
                outlined
                onClick={() => setIsEditing(true)}
                size="small"
              />
            )}
          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder>
          <SectionCardWithHeader title="HR Configuration" subtitle={formData.sender || '—'}>
            <div className="sc-grid-2 gap-4">
              {(isCreateMode || isEditing) && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading}
                  />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Default Sender Email *</label>
                <InputText
                  value={formData.sender}
                  onChange={(e) => handleInputChange('sender', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Hiring Sender Email</label>
                <InputText
                  value={formData.hiringSender}
                  onChange={(e) => handleInputChange('hiringSender', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Leave Approval Notification Template</label>
                <InputText
                  value={formData.leaveApprovalNotificationTemplate}
                  onChange={(e) => handleInputChange('leaveApprovalNotificationTemplate', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Leave Status Notification Template</label>
                <InputText
                  value={formData.leaveStatusNotificationTemplate}
                  onChange={(e) => handleInputChange('leaveStatusNotificationTemplate', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Feedback Reminder Template</label>
                <InputText
                  value={formData.feedbackReminderNotificationTemplate}
                  onChange={(e) => handleInputChange('feedbackReminderNotificationTemplate', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Interview Reminder Template</label>
                <InputText
                  value={formData.interviewReminderTemplate}
                  onChange={(e) => handleInputChange('interviewReminderTemplate', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Exit Questionnaire Notification Template</label>
                <InputText
                  value={formData.exitQuestionnaireNotificationTemplate}
                  onChange={(e) => handleInputChange('exitQuestionnaireNotificationTemplate', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Role Allowed for Backdated Leave</label>
                <InputText
                  value={formData.roleAllowedToCreateBackdatedLeaveApplication}
                  onChange={(e) => handleInputChange('roleAllowedToCreateBackdatedLeaveApplication', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Exit Questionnaire Web Form</label>
                <InputText
                  value={formData.exitQuestionnaireWebForm}
                  onChange={(e) => handleInputChange('exitQuestionnaireWebForm', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Auto Leave Encashment</label>
                <InputSwitch
                  checked={formData.autoLeaveEncashment}
                  onChange={(e) => handleInputChange('autoLeaveEncashment', e.value)}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Restrict Backdated Leave Application</label>
                <InputSwitch
                  checked={formData.restrictBackdatedLeaveApplication}
                  onChange={(e) => handleInputChange('restrictBackdatedLeaveApplication', e.value)}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Email Salary Slip to Employee</label>
                <InputSwitch
                  checked={formData.emailSalarySlipToEmployee}
                  onChange={(e) => handleInputChange('emailSalarySlipToEmployee', e.value)}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Encrypt Salary Slips in Emails</label>
                <InputSwitch
                  checked={formData.encryptSalarySlipsInEmails}
                  onChange={(e) => handleInputChange('encryptSalarySlipsInEmails', e.value)}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Stop Birthday Reminders</label>
                <InputSwitch
                  checked={formData.stopBirthdayReminders}
                  onChange={(e) => handleInputChange('stopBirthdayReminders', e.value)}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Send Holiday Reminders</label>
                <InputSwitch
                  checked={formData.sendHolidayReminders}
                  onChange={(e) => handleInputChange('sendHolidayReminders', e.value)}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Password Policy</label>
                <InputText
                  value={formData.passwordPolicy}
                  onChange={(e) => handleInputChange('passwordPolicy', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              {!isCreateMode && !isEditing && (
                <div>
                  <label className="block text-600 mb-1">Tenant</label>
                  <InputText value={formData.tenantId} disabled className="w-full bg-gray-100" />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar
                  value={formData.validFrom}
                  onChange={(e) => handleInputChange('validFrom', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar
                  value={formData.validUpto}
                  onChange={(e) => handleInputChange('validUpto', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  className="w-full"
                />
              </div>
            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default HRSettingsDetailView;