import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeavePolicyList from '../../hooks/master/useLeavePolicyList';

const LeavePolicyListView = () => {
  const navigate = useNavigate();

  const {
    data: policies = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeavePolicyList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredPolicies = searchTerm.trim()
    ? policies.filter(item =>
        item.policyName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : policies;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Policies' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Policy Name',
      name: 'policyName',
      placeholder: 'e.g. Standard Annual Leave, Casual Leave Policy',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.policyName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(
      d.getMonth() + 1
    ).padStart(2, '0')}-${d.getFullYear()}`;
  };

  const carryForwardTemplate = (row) => (
    <Tag
      value={row.carryForwardEncashedLeaves ? 'Yes' : 'No'}
      severity={row.carryForwardEncashedLeaves ? 'success' : 'warning'}
      rounded
    />
  );

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Policies</h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/leave-policy/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredPolicies}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError ? `Error: ${error?.message || 'Failed to load data'}` : 'No leave policies found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-policy/detail', {
              state: { policyId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="policyName" header="Policy Name" sortable />
          <Column
            field="carryForwardEncashedLeaves"
            header="Carry Forward Encashed Leaves"
            body={carryForwardTemplate}
            sortable
          />
          <Column field="validFrom" header="Valid From" body={(row) => formatDate(row.validFrom)} sortable />
          <Column field="validUpto" header="Valid Upto" body={(row) => formatDate(row.validUpto)} sortable />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeavePolicyListView;