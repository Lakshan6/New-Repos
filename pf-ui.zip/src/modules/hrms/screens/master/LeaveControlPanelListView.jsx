// src/pages/hrms/leave-control-panel/LeaveControlPanelListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeaveControlPanelList from '../../hooks/master/useLeaveControlPanelList';

const LeaveControlPanelListView = () => {
  const navigate = useNavigate();

  const {
    data: panels = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeaveControlPanelList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredPanels = searchTerm.trim()
    ? panels.filter(item =>
        item.panelName?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : panels;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Control Panels' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Panel Name',
      name: 'panelName',
      placeholder: 'e.g. Annual Leave Panel, Quarterly Leave Panel',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.panelName || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(d.getMonth() + 1).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Control Panels</h4>
          <Button
            label="Add New Panel"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() => navigate('/web/landing/hrms/leave-control-panel/create')}
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredPanels}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={isError ? `Error: ${error?.message || 'Failed to load panels'}` : 'No leave control panels found'}
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-control-panel/detail', {
              state: { panelId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="name" header="Panel Name" sortable />
          <Column
            field="fromDate"
            header="From Date"
            body={(row) => formatDate(row.fromDate)}
            sortable
          />
          <Column
            field="toDate"
            header="To Date"
            body={(row) => formatDate(row.toDate)}
            sortable
          />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeaveControlPanelListView;