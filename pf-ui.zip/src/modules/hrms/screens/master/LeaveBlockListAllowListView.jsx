import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Card } from 'primereact/card';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import { Button } from 'primereact/button';

import SearchCard from '@shared/components/SearchCard';
import useLeaveBlockListAllowList from '../../hooks/master/useLeaveBlockListAllowList';

const LeaveBlockListAllowListView = () => {
  const navigate = useNavigate();

  const {
    data: allows = [],
    isLoading,
    isError,
    error,
    refetch,
  } = useLeaveBlockListAllowList();

  const [searchTerm, setSearchTerm] = useState('');

  const filteredAllows = searchTerm.trim()
    ? allows.filter(item =>
        item.allowUser?.toLowerCase().includes(searchTerm.toLowerCase())
      )
    : allows;

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Leave Block List Allows' },
  ];

  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const searchFilters = [
    {
      type: 'InputText',
      label: 'Allowed User',
      name: 'allowUser',
      placeholder: 'e.g. user_1001, user_2002, hr_admin',
    },
  ];

  const handleSearch = (values) => {
    setSearchTerm(values.allowUser || '');
  };

  const handleClear = () => {
    setSearchTerm('');
    refetch();
  };

  const formatDate = (dateString) => {
    if (!dateString) return '—';
    const d = new Date(dateString);
    return `${String(d.getDate()).padStart(2, '0')}-${String(
      d.getMonth() + 1
    ).padStart(2, '0')}-${d.getFullYear()}`;
  };

  return (
    <div className="surface-ground min-h-screen p-3">
      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

      <Card className="mt-4">
        {/* Header with Add New button */}
        <div className="flex justify-content-between align-items-center mb-3 px-2">
          <h4 className="m-0 text-2xl font-semibold">Leave Block List Allowed Users</h4>
          <Button
            label="Add New"
            icon="pi pi-plus"
            severity="success"
            size="small"
            onClick={() =>
              navigate('/web/landing/hrms/leave-block-list-allow/create')
            }
          />
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <DataTable
          value={filteredAllows}
          stripedRows
          paginator
          rows={10}
          rowsPerPageOptions={[10, 25, 50]}
          rowHover
          loading={isLoading}
          emptyMessage={
            isError
              ? `Error: ${error?.message || 'Failed to load data'}`
              : 'No allowed users found'
          }
          onRowClick={(e) =>
            navigate('/web/landing/hrms/leave-block-list-allow/detail', {
              state: { allowId: e.data.id },
            })
          }
          selectionMode="single"
          className="cursor-pointer"
        >
          <Column field="allowUser" header="Allowed User" sortable />
          <Column field="leaveBlockListName" header="Leave Block List" sortable />
          <Column
            field="validFrom"
            header="Valid From"
            body={(row) => formatDate(row.validFrom)}
            sortable
          />
          <Column
            field="validUpto"
            header="Valid Upto"
            body={(row) => formatDate(row.validUpto)}
            sortable
          />
        </DataTable>
      </Card>
    </div>
  );
};

export default LeaveBlockListAllowListView;