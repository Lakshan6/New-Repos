// src/pages/hrms/shift-type/ShiftTypeDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import { InputSwitch } from 'primereact/inputswitch';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import { useShiftTypes } from '../../hooks/master/useShiftTypes';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const ShiftTypeDetailView = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const toast = useRef(null);

  const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
  const shiftId = location.state?.shiftId;
  const isCreateMode = location.pathname.endsWith('/create');

  const {
    shiftType: data,
    isLoading,
    isError,
    error,
    refetch,
    createShiftType,
    updateShiftType,
    deleteShiftType,
    isCreating,
    isUpdating,
    isDeleting,
    mutationError,
  } = useShiftTypes({ id: isCreateMode ? null : shiftId, userInfo });

  const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

  const [formData, setFormData] = useState({
    shiftName: '',
    startTime: null,
    endTime: null,
    enableAutoAttendance: false,
    determineCheckInAndCheckOut: '',
    beginCheckInBeforeShiftStartTime: 0,
    allowCheckOutAfterShiftEndTime: 0,
    workingHoursThresholdForAbsent: 0,
    workingHoursThresholdForHalfDay: 0,
    enableEntryGracePeriod: false,
    lateEntryGracePeriod: 0,
    enableExitGracePeriod: false,
    earlyExitGracePeriod: 0,
    tenantId: '',
    tenantRole: '',
    module: '',
    validFrom: null,
    validUpto: null,
  });

  const [originalFormData, setOriginalFormData] = useState({});
  const [isEditing, setIsEditing] = useState(isCreateMode);
  const [hasInitialized, setHasInitialized] = useState(false);

  const handleInputChange = (field, value) => {
    setFormData((prev) => ({ ...prev, [field]: value }));
  };

  const showToast = (severity, summary, detail, life = 3000) =>
    toast.current?.show({ severity, summary, detail, life });

  const tenantOptions = (tenants || [])
    .map((t) => ({
      label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
      value: t.tenantId || t.id || t.code || '',
    }))
    .filter((t) => t.value);

  const checkInOutOptions = [
    { label: 'Auto', value: 'AUTO' },
    { label: 'Manual', value: 'MANUAL' },
    { label: 'Hybrid', value: 'HYBRID' },
  ];

  useEffect(() => {
    if (!isCreateMode && !shiftId) {
      showToast('warn', 'No Shift Selected', 'Please select a shift type from the list', 4000);
      navigate('/web/landing/hrms/shift-type', { replace: true });
    }
  }, [isCreateMode, shiftId, navigate]);

  useEffect(() => {
    if (!isCreateMode && data && !hasInitialized) {
      const initialData = {
        shiftName: data.shiftName ?? '',
        startTime: data.startTime ? new Date(data.startTime) : null,
        endTime: data.endTime ? new Date(data.endTime) : null,
        enableAutoAttendance: data.enableAutoAttendance ?? false,
        determineCheckInAndCheckOut: data.determineCheckInAndCheckOut ?? '',
        beginCheckInBeforeShiftStartTime: Number(data.beginCheckInBeforeShiftStartTime) ?? 0,
        allowCheckOutAfterShiftEndTime: Number(data.allowCheckOutAfterShiftEndTime) ?? 0,
        workingHoursThresholdForAbsent: Number(data.workingHoursThresholdForAbsent) ?? 0,
        workingHoursThresholdForHalfDay: Number(data.workingHoursThresholdForHalfDay) ?? 0,
        enableEntryGracePeriod: data.enableEntryGracePeriod ?? false,
        lateEntryGracePeriod: Number(data.lateEntryGracePeriod) ?? 0,
        enableExitGracePeriod: data.enableExitGracePeriod ?? false,
        earlyExitGracePeriod: Number(data.earlyExitGracePeriod) ?? 0,
        tenantId: data.tenantId ?? '',
        tenantRole: data.tenantRole ?? '',
        module: data.module ?? '',
        validFrom: data.validFrom ? new Date(data.validFrom) : null,
        validUpto: data.validUpto ? new Date(data.validUpto) : null,
      };
      setFormData(initialData);
      setOriginalFormData(initialData);
      setHasInitialized(true);
    }
  }, [data, isCreateMode, hasInitialized]);

  const handleCancel = () => {
    if (isCreateMode) return navigate('/web/landing/hrms/shift-type');
    setFormData({ ...originalFormData });
    setIsEditing(false);
    showToast('info', 'Cancelled', 'Changes reverted');
  };

  const validateForm = () => {
    if (!formData.shiftName?.trim()) return 'Shift Name is required';
    if (isCreateMode && !formData.tenantId) return 'Tenant is required';
    if (formData.startTime && formData.endTime && formData.startTime > formData.endTime)
      return 'End Time must be after Start Time';
    if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
      return 'Valid Upto cannot be before Valid From';
    return null;
  };

  const buildPayload = () => ({
    ...(isCreateMode ? {} : { id: shiftId }),
    shiftName: formData.shiftName.trim(),
    startTime: formData.startTime?.toISOString() || null,
    endTime: formData.endTime?.toISOString() || null,
    enableAutoAttendance: formData.enableAutoAttendance,
    determineCheckInAndCheckOut: formData.determineCheckInAndCheckOut?.trim() || '',
    beginCheckInBeforeShiftStartTime: formData.beginCheckInBeforeShiftStartTime ?? 0,
    allowCheckOutAfterShiftEndTime: formData.allowCheckOutAfterShiftEndTime ?? 0,
    workingHoursThresholdForAbsent: formData.workingHoursThresholdForAbsent ?? 0,
    workingHoursThresholdForHalfDay: formData.workingHoursThresholdForHalfDay ?? 0,
    enableEntryGracePeriod: formData.enableEntryGracePeriod,
    lateEntryGracePeriod: formData.lateEntryGracePeriod ?? 0,
    enableExitGracePeriod: formData.enableExitGracePeriod,
    earlyExitGracePeriod: formData.earlyExitGracePeriod ?? 0,
    tenantId: formData.tenantId || originalFormData.tenantId,
    tenantRole: formData.tenantRole || originalFormData.tenantRole,
    module: formData.module?.trim() || '',
    validFrom: formData.validFrom?.toISOString() || null,
    validUpto: formData.validUpto?.toISOString() || null,
  });

  const handleSave = async () => {
    const validationError = validateForm();
    if (validationError) return showToast('warn', 'Validation Error', validationError);

    const payload = buildPayload();

    try {
      if (isCreateMode) {
        await createShiftType(payload);
        showToast('success', 'Created', 'Shift type created successfully');
        setTimeout(() => navigate('/web/landing/hrms/shift-type'), 900);
      } else {
        await updateShiftType(payload);
        showToast('success', 'Updated', 'Shift type updated successfully');
        setIsEditing(false);
        refetch();
      }
    } catch (err) {
      const msg = err?.message || mutationError?.message || 'Operation failed';
      showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
    }
  };

  const handleDelete = () =>
    confirmDialog({
      message: 'Are you sure you want to delete this shift type?\nThis action cannot be undone.',
      header: 'Confirm Delete',
      icon: 'pi pi-exclamation-triangle',
      acceptClassName: 'p-button-danger',
      acceptLabel: 'Yes, Delete',
      rejectLabel: 'No',
      accept: async () => {
        try {
          await deleteShiftType(shiftId);
          showToast('success', 'Deleted', 'Shift type deleted successfully');
          setTimeout(() => navigate('/web/landing/hrms/shift-type'), 800);
        } catch (err) {
          const msg = err?.message || 'Could not delete shift type';
          showToast('error', 'Delete Failed', msg, 5000);
        }
      },
    });

  const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

  // ────────────────────────────────────────────────
  // Debug: Remove or comment this block after testing
  console.log('Render →', {
    isCreateMode,
    isEditing,
    isAnyMutationRunning,
    disabledSwitches: !isCreateMode && !isEditing,
    currentAutoAttendance: formData.enableAutoAttendance,
  });
  // ────────────────────────────────────────────────

  if (!isCreateMode && isLoading) {
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <ProgressSpinner />
            <p className="mt-3 text-500">Loading shift type details...</p>
          </div>
        </PageContentCard>
      </div>
    );
  }

  if (!isCreateMode && (isError || !data)) {
    return (
      <div className="surface-ground min-h-screen p-3">
        <PageContentCard padding="lg" rounded="lg">
          <div className="flex align-items-center justify-content-center flex-column py-8">
            <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
            <h2>Unable to load shift type</h2>
            <p className="text-600 mb-4">{error?.message || 'Shift type not found or invalid access'}</p>
            <div className="flex gap-3">
              <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
              <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
            </div>
          </div>
        </PageContentCard>
      </div>
    );
  }

  const breadcrumbItems = [
    { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
    { label: 'Shift Types', command: () => navigate('/web/landing/hrms/shift-type') },
    { label: isCreateMode ? 'Create Shift Type' : 'Details' },
  ];
  const home = { icon: 'pi pi-home', command: () => navigate('/') };

  const title = isCreateMode ? 'Create New Shift Type' : 'Shift Type Details';
  const subtitle = formData.shiftName.trim() || (isCreateMode ? 'New Shift Type' : '—');

  return (
    <div className="surface-ground min-h-screen p-1">
      <Toast ref={toast} />
      <ConfirmDialog />

      <div className="mb-3">
        <BreadCrumb model={breadcrumbItems} home={home} />
      </div>

      <PageContentCard padding="md" rounded="lg" shadow="sm">
        <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
          <div className="flex align-items-center gap-4">
            <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
            <h4 className="m-0 text-2xl font-semibold">{title}</h4>
          </div>

          <div className="flex align-items-center gap-2 flex-wrap">
            {isCreateMode ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Create"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isCreating}
                  size="small"
                />
              </>
            ) : isEditing ? (
              <>
                <Button
                  label="Cancel"
                  icon="pi pi-times"
                  outlined
                  severity="secondary"
                  onClick={handleCancel}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Delete"
                  icon="pi pi-trash"
                  severity="danger"
                  outlined
                  onClick={handleDelete}
                  loading={isDeleting}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
                <Button
                  label="Save"
                  icon="pi pi-save"
                  severity="success"
                  onClick={handleSave}
                  loading={isUpdating}
                  disabled={isAnyMutationRunning}
                  size="small"
                />
              </>
            ) : (
              <Button
                label="Edit"
                icon="pi pi-pencil"
                outlined
                onClick={() => {
                  console.log('→ Edit button clicked – setting isEditing = true');
                  setIsEditing(true);
                }}
                disabled={isAnyMutationRunning}
                size="small"
              />
            )}
          </div>
        </div>

        <div className="border-top-1 surface-border mb-3" />

        <TabbedSectionCard transparentBorder>
          <SectionCardWithHeader title="Shift Information" subtitle={subtitle}>
            <div className="sc-grid-2 gap-4">
              {isCreateMode && (
                <div>
                  <label className="block text-600 mb-1">Tenant *</label>
                  <Dropdown
                    value={formData.tenantId}
                    options={tenantOptions}
                    onChange={(e) => handleInputChange('tenantId', e.value)}
                    placeholder="Select tenant"
                    className="w-full"
                    filter
                    showClear
                    disabled={isTenantsLoading || isAnyMutationRunning}
                  />
                </div>
              )}

              <div>
                <label className="block text-600 mb-1">Shift Name *</label>
                <InputText
                  value={formData.shiftName}
                  onChange={(e) => handleInputChange('shiftName', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter shift name' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Start Time</label>
                <Calendar
                  value={formData.startTime}
                  onChange={(e) => handleInputChange('startTime', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showTime
                  hourFormat="12"
                  timeOnly
                  className="w-full"
                  placeholder={isCreateMode ? 'Select start time' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">End Time</label>
                <Calendar
                  value={formData.endTime}
                  onChange={(e) => handleInputChange('endTime', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showTime
                  hourFormat="12"
                  timeOnly
                  className="w-full"
                  placeholder={isCreateMode ? 'Select end time' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Enable Auto Attendance</label>
                <InputSwitch
                  checked={formData.enableAutoAttendance}
                  onChange={(e) => {
                    console.log('Toggle clicked → new value:', e.checked);
                    handleInputChange('enableAutoAttendance', e.checked);
                  }}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Determine Check-In/Check-Out</label>
                <Dropdown
                  value={formData.determineCheckInAndCheckOut}
                  options={checkInOutOptions}
                  onChange={(e) => handleInputChange('determineCheckInAndCheckOut', e.value)}
                  placeholder="Select method"
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Begin Check-In Before Shift Start (minutes)</label>
                <InputNumber
                  value={formData.beginCheckInBeforeShiftStartTime}
                  onChange={(e) => handleInputChange('beginCheckInBeforeShiftStartTime', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  min={0}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Allow Check-Out After Shift End (minutes)</label>
                <InputNumber
                  value={formData.allowCheckOutAfterShiftEndTime}
                  onChange={(e) => handleInputChange('allowCheckOutAfterShiftEndTime', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  min={0}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Working Hours Threshold for Absent (hours)</label>
                <InputNumber
                  value={formData.workingHoursThresholdForAbsent}
                  onChange={(e) => handleInputChange('workingHoursThresholdForAbsent', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  min={0}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Working Hours Threshold for Half Day (hours)</label>
                <InputNumber
                  value={formData.workingHoursThresholdForHalfDay}
                  onChange={(e) => handleInputChange('workingHoursThresholdForHalfDay', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  min={0}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Enable Entry Grace Period</label>
                <InputSwitch
                  checked={formData.enableEntryGracePeriod}
                  onChange={(e) => {
                    console.log('Entry Grace toggle → new value:', e.checked);
                    handleInputChange('enableEntryGracePeriod', e.checked);
                  }}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Late Entry Grace Period (minutes)</label>
                <InputNumber
                  value={formData.lateEntryGracePeriod}
                  onChange={(e) => handleInputChange('lateEntryGracePeriod', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  min={0}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Enable Exit Grace Period</label>
                <InputSwitch
                  checked={formData.enableExitGracePeriod}
                  onChange={(e) => {
                    console.log('Exit Grace toggle → new value:', e.checked);
                    handleInputChange('enableExitGracePeriod', e.checked);
                  }}
                  disabled={!isCreateMode && !isEditing}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Early Exit Grace Period (minutes)</label>
                <InputNumber
                  value={formData.earlyExitGracePeriod}
                  onChange={(e) => handleInputChange('earlyExitGracePeriod', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  min={0}
                  className="w-full"
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Module</label>
                <InputText
                  value={formData.module}
                  onChange={(e) => handleInputChange('module', e.target.value)}
                  disabled={!isCreateMode && !isEditing}
                  className="w-full"
                  placeholder={isCreateMode ? 'Enter module name (optional)' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid From</label>
                <Calendar
                  value={formData.validFrom}
                  onChange={(e) => handleInputChange('validFrom', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select validity start' : ''}
                />
              </div>

              <div>
                <label className="block text-600 mb-1">Valid Upto</label>
                <Calendar
                  value={formData.validUpto}
                  onChange={(e) => handleInputChange('validUpto', e.value)}
                  disabled={!isCreateMode && !isEditing}
                  showIcon
                  dateFormat="yy-mm-dd"
                  className="w-full"
                  placeholder={isCreateMode ? 'Select validity end' : ''}
                />
              </div>
            </div>
          </SectionCardWithHeader>
        </TabbedSectionCard>
      </PageContentCard>
    </div>
  );
};

export default ShiftTypeDetailView;