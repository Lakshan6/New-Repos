// src/pages/hrms/leave-type/LeaveTypeDetailView.jsx
import React, { useEffect, useRef, useState } from 'react';
import { useNavigate, useLocation } from 'react-router-dom';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import { InputSwitch } from 'primereact/inputswitch';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { BreadCrumb } from 'primereact/breadcrumb';
import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';

import PageContentCard from '@shared/components/PageContentCard';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';

import useLeaveType from '../../hooks/master/useLeaveType';
import { useGetTenantIds } from '../../hooks/useGetTenantIds';

const LeaveTypeDetailView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);

    const userInfo = JSON.parse(localStorage.getItem('userInfo')) || {};
    const typeId = location.state?.typeId;
    const isCreateMode = location.pathname.endsWith('/create');

    const {
        leaveType: data,
        isLoading,
        isError,
        error,
        refetch,
        createLeaveType,
        updateLeaveType,
        deleteLeaveType,
        isCreating,
        isUpdating,
        isDeleting,
        mutationError,
    } = useLeaveType({ id: isCreateMode ? null : typeId, userInfo });

    const { tenants, isLoading: isTenantsLoading } = useGetTenantIds({ enabled: isCreateMode });

    const [formData, setFormData] = useState({
        leaveTypeName: '',
        maxLeavesAllowed: 0,
        applicableAfter: 0,
        maxContinuousDaysAllowed: 0,
        isCarryForward: false,
        isEarnedLeave: false,
        isLwp: false,
        isOptionalLeave: false,
        allowNegative: false,
        includeHoliday: false,
        isCompensatory: false,
        earningComponent: '',
        fractionOfDailySalaryPerLeave: 0,
        encashmentThresholdDays: 0,
        earnedLeaveFrequency: '',
        rounding: '',
        tenantId: '',
        tenantRole: '',
        module: '',
        validFrom: null,
        validUpto: null,
    });
    const [originalFormData, setOriginalFormData] = useState({});
    const [isEditing, setIsEditing] = useState(isCreateMode);
    const [hasInitialized, setHasInitialized] = useState(false);

    const handleInputChange = (field, value) => setFormData(prev => ({ ...prev, [field]: value }));
    const showToast = (severity, summary, detail, life = 3000) =>
        toast.current?.show({ severity, summary, detail, life });

    const tenantOptions = (tenants || []).map(t => ({
        label: t.name || t.tenantName || t.displayName || t.companyName || t.code || 'Unnamed Tenant',
        value: t.tenantId || t.id || t.code || '',
    }));

    // Redirect if no type selected in detail mode
    useEffect(() => {
        if (!isCreateMode && !typeId) {
            showToast('warn', 'No Leave Type Selected', 'Please select a leave type from the list', 4000);
            navigate('/web/landing/hrms/leave-type', { replace: true });
        }
    }, [isCreateMode, typeId, navigate]);

    // Initialize form data from API
    useEffect(() => {
        if (!isCreateMode && data && !hasInitialized) {
            const initialData = {
                leaveTypeName: data.leaveTypeName ?? '',
                maxLeavesAllowed: data.maxLeavesAllowed ?? 0,
                applicableAfter: data.applicableAfter ?? 0,
                maxContinuousDaysAllowed: data.maxContinuousDaysAllowed ?? 0,
                isCarryForward: data.isCarryForward ?? false,
                isEarnedLeave: data.isEarnedLeave ?? false,
                isLwp: data.isLwp ?? false,
                isOptionalLeave: data.isOptionalLeave ?? false,
                allowNegative: data.allowNegative ?? false,
                includeHoliday: data.includeHoliday ?? false,
                isCompensatory: data.isCompensatory ?? false,
                earningComponent: data.earningComponent ?? '',
                fractionOfDailySalaryPerLeave: data.fractionOfDailySalaryPerLeave ?? 0,
                encashmentThresholdDays: data.encashmentThresholdDays ?? 0,
                earnedLeaveFrequency: data.earnedLeaveFrequency ?? '',
                rounding: data.rounding ?? '',
                tenantId: data.tenantId ?? '',
                tenantRole: data.tenantRole ?? '',
                module: data.module ?? '',
                validFrom: data.validFrom ? new Date(data.validFrom) : null,
                validUpto: data.validUpto ? new Date(data.validUpto) : null,
            };
            setFormData(initialData);
            setOriginalFormData(initialData);
            setHasInitialized(true);
        }
    }, [data, isCreateMode, hasInitialized]);

    const handleCancel = () => {
        if (isCreateMode) return navigate('/web/landing/hrms/leave-type');
        setFormData({ ...originalFormData });
        setIsEditing(false);
        showToast('info', 'Cancelled', 'Changes reverted');
    };

    const validateForm = () => {
        if (!formData.leaveTypeName?.trim()) return 'Leave Type Name is required';
        if (isCreateMode && !formData.tenantId) return 'Tenant is required';
        if (formData.validFrom && formData.validUpto && formData.validFrom > formData.validUpto)
            return 'Valid Upto cannot be before Valid From';
        return null;
    };

    const buildPayload = () => ({
        ...(isCreateMode ? {} : { id: typeId }),
        leaveTypeName: formData.leaveTypeName.trim(),
        maxLeavesAllowed: formData.maxLeavesAllowed ?? 0,
        applicableAfter: formData.applicableAfter ?? 0,
        maxContinuousDaysAllowed: formData.maxContinuousDaysAllowed ?? 0,
        isCarryForward: formData.isCarryForward ?? false,
        isEarnedLeave: formData.isEarnedLeave ?? false,
        isLwp: formData.isLwp ?? false,
        isOptionalLeave: formData.isOptionalLeave ?? false,
        allowNegative: formData.allowNegative ?? false,
        includeHoliday: formData.includeHoliday ?? false,
        isCompensatory: formData.isCompensatory ?? false,
        earningComponent: formData.earningComponent?.trim() || null,
        fractionOfDailySalaryPerLeave: formData.fractionOfDailySalaryPerLeave ?? 0,
        encashmentThresholdDays: formData.encashmentThresholdDays ?? 0,
        earnedLeaveFrequency: formData.earnedLeaveFrequency?.trim() || null,
        rounding: formData.rounding?.trim() || null,
        tenantId: formData.tenantId || originalFormData.tenantId,
        tenantRole: formData.tenantRole || originalFormData.tenantRole,
        module: formData.module?.trim() || '',
        validFrom: formData.validFrom?.toISOString() || null,
        validUpto: formData.validUpto?.toISOString() || null,
    });

    const handleSave = async () => {
        const validationError = validateForm();
        if (validationError) return showToast('warn', 'Validation', validationError);

        const payload = buildPayload();

        try {
            if (isCreateMode) {
                await createLeaveType(payload);
                showToast('success', 'Created', 'Leave type created successfully');
                setTimeout(() => navigate('/web/landing/hrms/leave-type'), 900);
            } else {
                await updateLeaveType(payload);
                showToast('success', 'Updated', 'Leave type updated successfully');
                setIsEditing(false);
                refetch();
            }
        } catch (err) {
            const msg = err?.message || mutationError?.message || 'Something went wrong';
            showToast('error', isCreateMode ? 'Creation Failed' : 'Update Failed', msg, 6000);
        }
    };

    const handleDelete = () =>
        confirmDialog({
            message: 'Are you sure you want to delete this leave type?\nThis action cannot be undone.',
            header: 'Confirm Delete',
            icon: 'pi pi-exclamation-triangle',
            acceptClassName: 'p-button-danger',
            acceptLabel: 'Yes, Delete',
            rejectLabel: 'No',
            accept: async () => {
                try {
                    await deleteLeaveType(typeId);
                    showToast('success', 'Deleted', 'Leave type deleted successfully');
                    setTimeout(() => navigate('/web/landing/hrms/leave-type'), 800);
                } catch (err) {
                    const msg = err?.message || 'Could not delete leave type';
                    showToast('error', 'Delete Failed', msg, 5000);
                }
            },
        });

    const isAnyMutationRunning = isCreating || isUpdating || isDeleting;

    if (!isCreateMode && isLoading)
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <ProgressSpinner />
                        <p className="mt-3 text-500">Loading leave type details...</p>
                    </div>
                </PageContentCard>
            </div>
        );

    if (!isCreateMode && (isError || !data))
        return (
            <div className="surface-ground min-h-screen p-3">
                <PageContentCard padding="lg" rounded="lg">
                    <div className="flex align-items-center justify-content-center flex-column py-8">
                        <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                        <h2>Unable to load leave type</h2>
                        <p className="text-600 mb-4">
                            {error?.message || 'Leave type not found or invalid access'}
                        </p>
                        <div className="flex gap-3">
                            <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={() => navigate(-1)} />
                            <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                        </div>
                    </div>
                </PageContentCard>
            </div>
        );

    const breadcrumbItems = [
        { label: 'HRMS', command: () => navigate('/web/landing/hrms') },
        { label: 'Leave Types', command: () => navigate('/web/landing/hrms/leave-type') },
        { label: isCreateMode ? 'Create Leave Type' : 'Details' },
    ];
    const home = { icon: 'pi pi-home', command: () => navigate('/') };

    const title = isCreateMode ? 'Create New Leave Type' : 'Leave Type Details';
    const subtitle = formData.leaveTypeName?.trim() || (isCreateMode ? 'New Leave Type' : '—');

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />
            <ConfirmDialog />

            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            <PageContentCard padding="md" rounded="lg" shadow="sm">
                <div className="flex align-items-center justify-content-between mt-1 mb-2 px-3 py-1">
                    <div className="flex align-items-center gap-4">
                        <Button icon="pi pi-arrow-left" text rounded onClick={() => navigate(-1)} />
                        <h4 className="m-0 text-2xl font-semibold">{title}</h4>
                        {!isCreateMode && typeId && (
                            <Button
                                size="small"
                                label={typeId}
                                severity="secondary"
                                rounded
                                onClick={() => navigator.clipboard.writeText(typeId)}
                                tooltip="Copy ID"
                            />
                        )}
                    </div>

                    <div className="flex align-items-center gap-2 flex-wrap">
                        {isCreateMode ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    disabled={isAnyMutationRunning}
                                    size="small"
                                />
                                <Button
                                    label="Create"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isCreating}
                                    size="small"
                                />
                            </>
                        ) : isEditing ? (
                            <>
                                <Button
                                    label="Cancel"
                                    icon="pi pi-times"
                                    outlined
                                    severity="secondary"
                                    onClick={handleCancel}
                                    size="small"
                                />
                                <Button
                                    label="Delete"
                                    icon="pi pi-trash"
                                    severity="danger"
                                    outlined
                                    onClick={handleDelete}
                                    loading={isDeleting}
                                    size="small"
                                />
                                <Button
                                    label="Save"
                                    icon="pi pi-save"
                                    severity="success"
                                    onClick={handleSave}
                                    loading={isUpdating}
                                    size="small"
                                />
                            </>
                        ) : (
                            <Button
                                label="Edit"
                                icon="pi pi-pencil"
                                outlined
                                onClick={() => setIsEditing(true)}
                                size="small"
                            />
                        )}
                    </div>
                </div>

                <div className="border-top-1 surface-border mb-3" />

                <TabbedSectionCard transparentBorder>
                    <SectionCardWithHeader title="Leave Type Information" subtitle={subtitle}>
                        <div className="sc-grid-2 gap-4">

                            {isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant *</label>
                                    <Dropdown
                                        value={formData.tenantId}
                                        options={tenantOptions}
                                        onChange={(e) => handleInputChange('tenantId', e.value)}
                                        placeholder="Select tenant"
                                        className="w-full"
                                        filter
                                        showClear
                                        disabled={isTenantsLoading}
                                    />
                                </div>
                            )}

                            <div>
                                <label className="block text-600 mb-1">Leave Type Name *</label>
                                <InputText
                                    value={formData.leaveTypeName}
                                    onChange={(e) => handleInputChange('leaveTypeName', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter leave type name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Max Leaves Allowed</label>
                                <InputNumber
                                    value={formData.maxLeavesAllowed}
                                    onValueChange={(e) => handleInputChange('maxLeavesAllowed', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    min={0}
                                    className="w-full"
                                    placeholder={isCreateMode ? '0' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Applicable After (Months)</label>
                                <InputNumber
                                    value={formData.applicableAfter}
                                    onValueChange={(e) => handleInputChange('applicableAfter', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    min={0}
                                    className="w-full"
                                    placeholder={isCreateMode ? '0' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Max Continuous Days Allowed</label>
                                <InputNumber
                                    value={formData.maxContinuousDaysAllowed}
                                    onValueChange={(e) => handleInputChange('maxContinuousDaysAllowed', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    min={0}
                                    className="w-full"
                                    placeholder={isCreateMode ? '0' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Fraction of Daily Salary Per Leave</label>
                                <InputNumber
                                    value={formData.fractionOfDailySalaryPerLeave}
                                    onValueChange={(e) => handleInputChange('fractionOfDailySalaryPerLeave', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    min={0}
                                    className="w-full"
                                    placeholder={isCreateMode ? '0' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Encashment Threshold Days</label>
                                <InputNumber
                                    value={formData.encashmentThresholdDays}
                                    onValueChange={(e) => handleInputChange('encashmentThresholdDays', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    min={0}
                                    className="w-full"
                                    placeholder={isCreateMode ? '0' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Earning Component</label>
                                <InputText
                                    value={formData.earningComponent}
                                    onChange={(e) => handleInputChange('earningComponent', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter earning component' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Earned Leave Frequency</label>
                                <InputText
                                    value={formData.earnedLeaveFrequency}
                                    onChange={(e) => handleInputChange('earnedLeaveFrequency', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter frequency' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Rounding</label>
                                <InputText
                                    value={formData.rounding}
                                    onChange={(e) => handleInputChange('rounding', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter rounding method' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Module</label>
                                <InputText
                                    value={formData.module}
                                    onChange={(e) => handleInputChange('module', e.target.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Enter module name' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Carry Forward</label>
                                <InputSwitch
                                    checked={formData.isCarryForward}
                                    onChange={(e) => handleInputChange('isCarryForward', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Is Earned Leave</label>
                                <InputSwitch
                                    checked={formData.isEarnedLeave}
                                    onChange={(e) => handleInputChange('isEarnedLeave', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Is LWP (Leave Without Pay)</label>
                                <InputSwitch
                                    checked={formData.isLwp}
                                    onChange={(e) => handleInputChange('isLwp', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Is Optional Leave</label>
                                <InputSwitch
                                    checked={formData.isOptionalLeave}
                                    onChange={(e) => handleInputChange('isOptionalLeave', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Allow Negative Balance</label>
                                <InputSwitch
                                    checked={formData.allowNegative}
                                    onChange={(e) => handleInputChange('allowNegative', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Include Holiday in Count</label>
                                <InputSwitch
                                    checked={formData.includeHoliday}
                                    onChange={(e) => handleInputChange('includeHoliday', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Is Compensatory Leave</label>
                                <InputSwitch
                                    checked={formData.isCompensatory}
                                    onChange={(e) => handleInputChange('isCompensatory', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid From</label>
                                <Calendar
                                    value={formData.validFrom}
                                    onChange={(e) => handleInputChange('validFrom', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid from' : ''}
                                />
                            </div>

                            <div>
                                <label className="block text-600 mb-1">Valid Upto</label>
                                <Calendar
                                    value={formData.validUpto}
                                    onChange={(e) => handleInputChange('validUpto', e.value)}
                                    disabled={!isCreateMode && !isEditing}
                                    showIcon
                                    dateFormat="yy-mm-dd"
                                    className="w-full"
                                    placeholder={isCreateMode ? 'Select valid upto' : ''}
                                />
                            </div>

                            {!isCreateMode && (
                                <div>
                                    <label className="block text-600 mb-1">Tenant ID</label>
                                    <InputText
                                        value={formData.tenantId}
                                        disabled
                                        className="w-full bg-gray-100"
                                    />
                                </div>
                            )}

                        </div>
                    </SectionCardWithHeader>
                </TabbedSectionCard>
            </PageContentCard>
        </div>
    );
};

export default LeaveTypeDetailView;