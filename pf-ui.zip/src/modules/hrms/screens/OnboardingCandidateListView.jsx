// OnboardingCandidateListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import SearchCard from '@shared/components/SearchCard';
import { useCandidateList } from '../hooks/candidates/useCandidateList';
import { Tag } from 'primereact/tag';

import { PASTEL_COLORS } from '../utils/colours';
import { STATUS_COLOURS, EXTENDED_STATUS_COLOURS, getStatusColor } from '../utils/statusColours';

// Helper to generate initials from name
const getInitials = (name) => {
    if (!name) return '??';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
};

// Avatar component (circular with initials)
const EmployeeAvatar = ({ name }) => {
    const initials = getInitials(name);
    const colorIndex =
        name?.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) % PASTEL_COLORS.length;
    const bgColor = PASTEL_COLORS[colorIndex];

    return (
        <div className="flex align-items-center gap-3">
            <div
                className="w-2rem h-2rem border-circle flex align-items-center justify-content-center text-black-alpha-50  font-bold text-sm"
                style={{ backgroundColor: bgColor }}
            >
                {initials}
            </div>
            <span>{name || 'N/A'}</span>
        </div>
    );
};

const OnboardingCandidateListView = () => {
    const navigate = useNavigate();

    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [sortField, setSortField] = useState('applicationDate');
    const [sortOrder, setSortOrder] = useState('desc');

    const {
        data: candidateData,
        isLoading,
        isError,
        error,
        refetch,
    } = useCandidateList({
        page,
        size: rowsPerPage,
        sortField,
        sortOrder,
    });

    const candidates = candidateData?.content || [];
    const totalRecords = candidateData?.totalElements || 0;

    //Pagination Handlers:
    const onPage = (event) => {
        setPage(event.page);
        setRowsPerPage(event.rows);
    };

    const onSort = (event) => {
        setSortField(event.sortField);
        setSortOrder(event.sortOrder === 1 ? 'asc' : 'desc');
    };

    const handleRowClick = (rowData) => {
        navigate('/web/landing/hrms/onboarding-candidate', {
            state: { candidateId: rowData.id },
        });
    };

    // Breadcrumb items
    const breadcrumbItems = [
        {
            label: 'HRMS',
            command: () => navigate('/web/landing/hrms'),
        },
        {
            label: 'Onboarding',
        },
    ];

    const home = {
        icon: 'pi pi-home',
        command: () => navigate('/'),
    };

    const searchFilters = [
        { type: 'InputText', label: 'Name', name: 'name', placeholder: 'Enter name' },
        {
            type: 'InputText',
            label: 'Department',
            name: 'department',
            placeholder: 'Enter department',
        },
        {
            type: 'InputText',
            label: 'Status',
            name: 'status',
            placeholder: 'Pending / In Progress',
        },
    ];

    const handleSearch = (values) => {
        console.log('Search values:', values);
        // Later: refetch with params or update queryKey
    };

    const handleClear = () => {
        console.log('Clear search');
        refetch();
    };

    const handleDownload = () => {
        console.log('Download candidates:', candidates);
        // Implement CSV export later
    };

    return (
        <div className="surface-ground min-h-screen mt-1 mb-1 p-2">
            {/* Breadcrumb */}
            <div className="mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {/* Search Card */}
            <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

            {/* Data Table Card */}
            <Card className="mt-4">
                {/* Header inside card */}
                <div className="flex align-items-center justify-content-between mb-3">
                    <h4 className="m-0 text-2xl font-semibold">Candidate Onboarding</h4>

                    <Button
                        label="Create Candidate"
                        icon="pi pi-plus"
                        className="p-button-sm"
                        onClick={() => navigate('/web/landing/hrms/onboarding-create')}
                    />
                </div>

                {/* Horizontal Line */}
                <div className="border-top-1 surface-border mb-3" />

                <DataTable
                    value={candidates}
                    stripedRows
                    lazy
                    paginator
                    first={page * rowsPerPage}
                    rows={rowsPerPage}
                    totalRecords={totalRecords}
                    onPage={onPage}
                    onSort={onSort}
                    sortField={sortField}
                    sortOrder={sortOrder === 'asc' ? 1 : -1}
                    rowsPerPageOptions={[10, 25, 50, 100]}
                    paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords} candidates"
                    rowHover
                    loading={isLoading}
                    emptyMessage={isError ? `Error: ${error?.message}` : 'No candidates found'}
                    onRowClick={(e) => handleRowClick(e.data)}
                >
                    <Column
                        field="name"
                        header="Name"
                        sortable
                        body={(rowData) => <EmployeeAvatar name={rowData.name} />}
                    />
                    <Column field="cellNumber" header="Contact" sortable />
                    <Column field="personalEmail" header="Email" sortable />
                    <Column field="applicationDate" header="Applied On" sortable />
                    <Column field="expectedJoinDate" header="Expected Join" sortable />
                    <Column field="source" header="Source" sortable />
                    <Column
                        field="status"
                        header="Status"
                        sortable
                        body={(rowData) => {
                            const rawStatus = rowData.status;
                            if (!rawStatus) {
                                return (
                                    <Tag
                                        value="Unknown"
                                        rounded
                                        style={{ backgroundColor: '#E2E8F0', color: '#475569' }}
                                        className="text-sm font-bold px-2 py-1"
                                    />
                                );
                            }

                            const { bg, text } = getStatusColor(rawStatus);

                            // Optional: nice display labels (you can expand this)
                            const labelMap = {
                                DOCUMENT_VERIFICATION: 'Document Verification',
                                PENDING_EMPLOYEE_CREATED: 'Pending Employee Creation',
                                EMPLOYEE_CREATED: 'Employee Created',
                                REJECTED: 'Rejected',
                                COMPLETED: 'Completed',
                                CONVERTED: 'Converted',
                                // Add more friendly names as needed
                            };

                            const displayLabel =
                                labelMap[rawStatus.toUpperCase()] ||
                                rawStatus
                                    .split('_')
                                    .map(
                                        (word) =>
                                            word.charAt(0).toUpperCase() +
                                            word.slice(1).toLowerCase(),
                                    )
                                    .join(' ');

                            return (
                                <Tag
                                    value={displayLabel}
                                    rounded
                                    className="text-sm font-bold px-2 py-1"
                                    style={{
                                        backgroundColor: bg,
                                        color: text,
                                        border: 'none',
                                    }}
                                />
                            );
                        }}
                    />
                </DataTable>
            </Card>
        </div>
    );
};

export default OnboardingCandidateListView;
