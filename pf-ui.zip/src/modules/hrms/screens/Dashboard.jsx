import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { InputText } from 'primereact/inputtext';
import { IconField } from 'primereact/iconfield';
import { InputIcon } from 'primereact/inputicon';
import { Panel } from 'primereact/panel';
import { Divider } from 'primereact/divider';
import {
    Card,
    PageLayout,
    FormGroup,
    ReadOnlyField,
    ControlledInputText,
    ControlledInputTextarea,
    ControlledPassword,
    ControlledInputOtp,
    ControlledDropdown,
    ControlledMultiSelect,
    ControlledInputNumber,
    ControlledCalendar,
    ControlledAutoComplete,
    ControlledListbox,
    ControlledCascadeSelect,
    ControlledTreeSelect,
    ControlledSelectButton,
    ControlledTripleInput,
    ControlledInputSwitch,
    ControlledCheckbox,
    ControlledTriStateCheckbox,
    ControlledToggleButton,
    ControlledRadioGroup,
    ControlledSlider,
    ControlledKnob,
    ControlledRating,
    ControlledChips,
    ControlledColorPicker,
} from '@shared/components';

/* ─── Static data ──────────────────────────────────────────────────────────── */

const INITIAL_EMPLOYEES = [
    {
        id: 1,
        name: 'Ravi Kumar',
        dept: 'Engineering',
        role: 'Senior Developer',
        status: 'Active',
        joined: '2021-03-15',
        salary: 85000,
    },
    {
        id: 2,
        name: 'Priya Sharma',
        dept: 'HR',
        role: 'HR Manager',
        status: 'Active',
        joined: '2019-07-22',
        salary: 72000,
    },
    {
        id: 3,
        name: 'Anil Mehta',
        dept: 'Finance',
        role: 'Financial Analyst',
        status: 'On Leave',
        joined: '2020-11-10',
        salary: 68000,
    },
    {
        id: 4,
        name: 'Deepa Nair',
        dept: 'Engineering',
        role: 'QA Engineer',
        status: 'Active',
        joined: '2022-01-05',
        salary: 62000,
    },
    {
        id: 5,
        name: 'Suresh Babu',
        dept: 'Sales',
        role: 'Sales Executive',
        status: 'Active',
        joined: '2018-09-30',
        salary: 55000,
    },
    {
        id: 6,
        name: 'Kavitha Rao',
        dept: 'Marketing',
        role: 'Marketing Lead',
        status: 'Inactive',
        joined: '2017-04-15',
        salary: 78000,
    },
    {
        id: 7,
        name: 'Rajesh Iyer',
        dept: 'Engineering',
        role: 'DevOps Engineer',
        status: 'Active',
        joined: '2023-02-20',
        salary: 90000,
    },
    {
        id: 8,
        name: 'Meena Pillai',
        dept: 'HR',
        role: 'Recruiter',
        status: 'Active',
        joined: '2021-08-14',
        salary: 58000,
    },
    {
        id: 9,
        name: 'Vinod Gupta',
        dept: 'Finance',
        role: 'CFO',
        status: 'Active',
        joined: '2015-06-01',
        salary: 150000,
    },
    {
        id: 10,
        name: 'Swathi Reddy',
        dept: 'Engineering',
        role: 'Product Manager',
        status: 'On Leave',
        joined: '2020-05-18',
        salary: 95000,
    },
    {
        id: 11,
        name: 'Arjun Singh',
        dept: 'Sales',
        role: 'Sales Manager',
        status: 'Active',
        joined: '2019-12-03',
        salary: 82000,
    },
    {
        id: 12,
        name: 'Lakshmi Devi',
        dept: 'Marketing',
        role: 'Content Writer',
        status: 'Active',
        joined: '2022-09-07',
        salary: 48000,
    },
];

const STATUS_SEVERITY = {
    Active: 'success',
    'On Leave': 'warning',
    Inactive: 'danger',
};

const DEPARTMENT_OPTIONS = [
    { label: 'Engineering', value: 'Engineering' },
    { label: 'HR', value: 'HR' },
    { label: 'Finance', value: 'Finance' },
    { label: 'Sales', value: 'Sales' },
    { label: 'Marketing', value: 'Marketing' },
];

const EMPLOYEE_TYPE_OPTIONS = [
    { label: 'Full-time', value: 'full-time' },
    { label: 'Part-time', value: 'part-time' },
    { label: 'Contract', value: 'contract' },
    { label: 'Intern', value: 'intern' },
];

/* ─── Showcase data ────────────────────────────────────────────────────────── */

const SKILL_OPTIONS = [
    { label: 'React', value: 'react' },
    { label: 'Node.js', value: 'nodejs' },
    { label: 'Python', value: 'python' },
    { label: 'Java', value: 'java' },
    { label: 'SQL', value: 'sql' },
    { label: 'DevOps', value: 'devops' },
];

const GENDER_OPTIONS = [
    { label: 'Male', value: 'M' },
    { label: 'Female', value: 'F' },
    { label: 'Other', value: 'O' },
];

const VIEW_MODE_OPTIONS = [
    { label: 'Grid', value: 'grid' },
    { label: 'List', value: 'list' },
    { label: 'Timeline', value: 'timeline' },
];

const CATEGORY_OPTIONS = [
    { label: 'Engineering', value: 'eng' },
    { label: 'HR', value: 'hr' },
    { label: 'Finance', value: 'fin' },
    { label: 'Operations', value: 'ops' },
];

const REGION_OPTIONS = [
    {
        name: 'India',
        states: [
            { name: 'Karnataka', cities: [{ name: 'Bengaluru' }, { name: 'Mysuru' }] },
            { name: 'Maharashtra', cities: [{ name: 'Mumbai' }, { name: 'Pune' }] },
        ],
    },
    {
        name: 'USA',
        states: [
            { name: 'California', cities: [{ name: 'San Francisco' }, { name: 'Los Angeles' }] },
            { name: 'New York', cities: [{ name: 'New York City' }, { name: 'Buffalo' }] },
        ],
    },
];

const ORG_TREE = [
    {
        key: 'eng',
        label: 'Engineering',
        children: [
            { key: 'eng-fe', label: 'Frontend' },
            { key: 'eng-be', label: 'Backend' },
            { key: 'eng-qa', label: 'QA' },
            { key: 'eng-ops', label: 'DevOps' },
        ],
    },
    {
        key: 'hr',
        label: 'Human Resources',
        children: [
            { key: 'hr-rec', label: 'Recruitment' },
            { key: 'hr-pay', label: 'Payroll' },
        ],
    },
    { key: 'fin', label: 'Finance' },
    { key: 'ops', label: 'Operations' },
];

const EMPLOYEE_NAMES = [
    'Ravi Kumar',
    'Priya Sharma',
    'Anil Mehta',
    'Deepa Nair',
    'Suresh Babu',
    'Kavitha Rao',
    'Rajesh Iyer',
    'Meena Pillai',
    'Vinod Gupta',
    'Swathi Reddy',
];

/* ─── Extracted prop constants (avoids inline object/function lint warnings) ── */

const RULES_NAME = { required: 'Full name is required.' };
const RULES_ROLE = { required: 'Job role is required.' };
const RULES_DEPT = { required: 'Department is required.' };
const RULES_SALARY = { min: { value: 0, message: 'Salary must be a positive value.' } };

const COL_STYLE_NAME = { minWidth: '160px' };
const COL_STYLE_DEPT = { minWidth: '140px' };
const COL_STYLE_ROLE = { minWidth: '160px' };
const COL_STYLE_STATUS = { width: '120px' };
const COL_STYLE_JOINED = { width: '130px' };
const COL_STYLE_SALARY = { width: '130px' };

/* ─── QuickAddEmployeeForm ─────────────────────────────────────────────────── */

function QuickAddEmployeeForm({ onAdd }) {
    const { control, handleSubmit, reset } = useForm({
        defaultValues: {
            name: '',
            department: null,
            role: '',
            employeeType: null,
            salary: null,
        },
    });

    const onSubmit = (data) => {
        onAdd(data);
        reset();
    };

    return (
        <Panel header="Quick Add Employee">
            <form onSubmit={handleSubmit(onSubmit)} noValidate>
                <div className="grid">
                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="name" label="Full Name" required>
                            <ControlledInputText
                                name="name"
                                control={control}
                                inputId="name"
                                placeholder="e.g. Ravi Kumar"
                                rules={RULES_NAME}
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="role" label="Job Role" required>
                            <ControlledInputText
                                name="role"
                                control={control}
                                inputId="role"
                                placeholder="e.g. Senior Developer"
                                rules={RULES_ROLE}
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="department" label="Department" required>
                            <ControlledDropdown
                                name="department"
                                control={control}
                                inputId="department"
                                options={DEPARTMENT_OPTIONS}
                                placeholder="Select department"
                                rules={RULES_DEPT}
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="employeeType" label="Employment Type">
                            <ControlledDropdown
                                name="employeeType"
                                control={control}
                                inputId="employeeType"
                                options={EMPLOYEE_TYPE_OPTIONS}
                                placeholder="Select type"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="salary"
                            label="Monthly Salary (₹)"
                            info="Gross monthly salary before deductions."
                        >
                            <ControlledInputNumber
                                name="salary"
                                control={control}
                                inputId="salary"
                                placeholder="e.g. 75000"
                                min={0}
                                rules={RULES_SALARY}
                            />
                        </FormGroup>
                    </div>
                </div>

                <div className="flex justify-content-end gap-2 mt-3">
                    <Button
                        type="button"
                        label="Discard"
                        icon="pi pi-times"
                        text
                        severity="secondary"
                        onClick={reset}
                    />
                    <Button type="submit" label="Add Employee" icon="pi pi-user-plus" />
                </div>
            </form>
        </Panel>
    );
}

QuickAddEmployeeForm.propTypes = {
    onAdd: PropTypes.func.isRequired,
};

/* ─── SectionHeader ────────────────────────────────────────────────────────── */

function SectionHeader({ title, icon }) {
    return (
        <div className="col-12 mt-2">
            <Divider align="left" className="mt-1 mb-0">
                <span className="flex align-items-center gap-2 text-sm font-semibold text-500 uppercase">
                    {icon && <i className={icon} />}
                    {title}
                </span>
            </Divider>
        </div>
    );
}

SectionHeader.propTypes = {
    title: PropTypes.string.isRequired,
    icon: PropTypes.string,
};

/* ─── FormComponentsShowcase ───────────────────────────────────────────────── */

function FormComponentsShowcase() {
    const { control, handleSubmit } = useForm({
        defaultValues: {
            /* text */
            notes: '',
            phone: '',
            password: '',
            otp: null,
            /* date */
            joiningDate: null,
            leaveRange: null,
            /* selection */
            manager: '',
            skills: [],
            viewMode: 'list',
            listCategory: null,
            region: null,
            orgNode: null,
            salesArea: '1200-10-10',
            /* boolean */
            isActive: true,
            acceptTerms: false,
            approvalStatus: null,
            isPublished: false,
            gender: 'M',
            /* numeric / visual */
            salaryBand: 60,
            completion: 75,
            rating: 4,
            /* misc */
            tags: ['ERP', 'React'],
            brandColor: 'ff5733',
        },
    });

    const [suggestions, setSuggestions] = useState([]);

    const handleComplete = useCallback((e) => {
        setSuggestions(
            EMPLOYEE_NAMES.filter((n) => n.toLowerCase().includes(e.query.toLowerCase())),
        );
    }, []);

    const onSubmit = useCallback((data) => {
        console.log('Showcase values:', data);
    }, []);

    return (
        <>
            <p className="text-600 text-sm mt-0 mb-1">
                Live demo of every controlled form component in{' '}
                <code>@shared/components/FormComponents</code>. All fields are bound to React Hook
                Form via <code>useController</code>. Open the browser console and click{' '}
                <strong>Log values</strong> to inspect the collected form state.
            </p>

            <form onSubmit={handleSubmit(onSubmit)} noValidate>
                <div className="grid">
                    {/* ── Text Inputs ───────────────────────────────────────── */}
                    <SectionHeader title="Text Inputs" icon="pi pi-pencil" />

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-text" label="InputText">
                            <ControlledInputText
                                name="notes"
                                control={control}
                                inputId="sc-text"
                                placeholder="Free-form text…"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-textarea"
                            label="InputTextarea"
                            info="Grows with content (autoResize)"
                        >
                            <ControlledInputTextarea
                                name="notes"
                                control={control}
                                inputId="sc-textarea"
                                rows={3}
                                autoResize
                                placeholder="Enter notes…"
                            />
                        </FormGroup>
                    </div>

                    {/* <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-mask" label="InputMask" info="Mask: +91 (999) 999-9999">
                            <ControlledInputMask
                                name="phone"
                                control={control}
                                inputId="sc-mask"
                                mask="+91 (999) 999-9999"
                                placeholder="+91 (___) ___-____"
                            />
                        </FormGroup> 
                    </div> */}

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-password"
                            label="Password"
                            info="Strength meter + show/hide toggle"
                        >
                            <ControlledPassword
                                name="password"
                                control={control}
                                inputId="sc-password"
                                toggleMask
                                placeholder="Enter password"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-otp"
                            label="InputOtp"
                            info="6-digit integer-only OTP"
                        >
                            <ControlledInputOtp
                                name="otp"
                                control={control}
                                inputId="sc-otp"
                                // length={6}
                                integerOnly
                            />
                        </FormGroup>
                    </div>

                    {/* ── Date / Range ──────────────────────────────────────── */}
                    <SectionHeader title="Date / Range" icon="pi pi-calendar" />

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-date" label="Calendar — single date">
                            <ControlledCalendar
                                name="joiningDate"
                                control={control}
                                inputId="sc-date"
                                showIcon
                                placeholder="DD-MM-YYYY"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-range" label="Calendar — date range">
                            <ControlledCalendar
                                name="leaveRange"
                                control={control}
                                inputId="sc-range"
                                showIcon
                                selectionMode="range"
                                placeholder="From – To"
                            />
                        </FormGroup>
                    </div>

                    {/* ── Read-only ─────────────────────────────────────────── */}
                    <SectionHeader title="Read-only Display" icon="pi pi-eye" />

                    <div className="col-12 md:col-6">
                        <ReadOnlyField label="Employee ID" value="EMP-10042" />
                    </div>

                    <div className="col-12 md:col-6">
                        <ReadOnlyField label="Created By" value="System" />
                    </div>

                    {/* ── Selection ─────────────────────────────────────────── */}
                    <SectionHeader title="Selection" icon="pi pi-list" />

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-dropdown" label="Dropdown">
                            <ControlledDropdown
                                name="listCategory"
                                control={control}
                                inputId="sc-dropdown"
                                options={CATEGORY_OPTIONS}
                                placeholder="Select category"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-multiselect"
                            label="MultiSelect"
                            info="Displayed as chips"
                        >
                            <ControlledMultiSelect
                                name="skills"
                                control={control}
                                inputId="sc-multiselect"
                                options={SKILL_OPTIONS}
                                placeholder="Select skills"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-autocomplete"
                            label="AutoComplete"
                            info="Type a name to search"
                        >
                            <ControlledAutoComplete
                                name="manager"
                                control={control}
                                inputId="sc-autocomplete"
                                suggestions={suggestions}
                                completeMethod={handleComplete}
                                dropdown
                                placeholder="Reporting manager…"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-selectbutton" label="SelectButton">
                            <ControlledSelectButton
                                name="viewMode"
                                control={control}
                                inputId="sc-selectbutton"
                                options={VIEW_MODE_OPTIONS}
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-listbox"
                            label="Listbox"
                            info="Scrollable list with filter"
                        >
                            <ControlledListbox
                                name="listCategory"
                                control={control}
                                inputId="sc-listbox"
                                options={CATEGORY_OPTIONS}
                                filter
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-cascade"
                            label="CascadeSelect"
                            info="Country → State → City"
                        >
                            <ControlledCascadeSelect
                                name="region"
                                control={control}
                                inputId="sc-cascade"
                                options={REGION_OPTIONS}
                                optionLabel="name"
                                optionGroupLabel="name"
                                optionGroupChildren={['states', 'cities']}
                                placeholder="Select region…"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-treeselect"
                            label="TreeSelect"
                            info="Hierarchical department tree"
                        >
                            <ControlledTreeSelect
                                name="orgNode"
                                control={control}
                                inputId="sc-treeselect"
                                options={ORG_TREE}
                                filter
                                placeholder="Select department…"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-triple"
                            label="TripleInput"
                            info="3-segment composite code e.g. Org–Channel–Division"
                        >
                            <ControlledTripleInput
                                name="salesArea"
                                control={control}
                                inputId="sc-triple"
                                segmentLengths={[4, 2, 2]}
                                segmentPlaceholders={['1200', '10', '10']}
                            />
                        </FormGroup>
                    </div>

                    {/* ── Boolean / Toggle ──────────────────────────────────── */}
                    <SectionHeader title="Boolean / Toggle" icon="pi pi-toggle-on" />

                    <div className="col-12 md:col-6 lg:col-4">
                        <FormGroup
                            htmlFor="sc-switch"
                            label="InputSwitch"
                            info="Stores boolean true/false"
                        >
                            <ControlledInputSwitch
                                name="isActive"
                                control={control}
                                inputId="sc-switch"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6 lg:col-4">
                        <FormGroup
                            htmlFor="sc-toggle"
                            label="ToggleButton"
                            info="On/Off with custom labels"
                        >
                            <ControlledToggleButton
                                name="isPublished"
                                control={control}
                                inputId="sc-toggle"
                                onLabel="Published"
                                offLabel="Draft"
                                onIcon="pi pi-check"
                                offIcon="pi pi-pencil"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6 lg:col-4">
                        <FormGroup
                            htmlFor="sc-tristate"
                            label="TriStateCheckbox"
                            info="true = Approved · false = Rejected · null = Pending"
                        >
                            <ControlledTriStateCheckbox
                                name="approvalStatus"
                                control={control}
                                inputId="sc-tristate"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-checkbox"
                            label="Checkbox"
                            info="Inline label support"
                        >
                            <ControlledCheckbox
                                name="acceptTerms"
                                control={control}
                                inputId="sc-checkbox"
                                label="I accept the terms and conditions"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-radio"
                            label="RadioGroup"
                            info="Single RHF field — multiple radio buttons"
                        >
                            <ControlledRadioGroup
                                name="gender"
                                control={control}
                                inputId="sc-radio"
                                options={GENDER_OPTIONS}
                            />
                        </FormGroup>
                    </div>

                    {/* ── Numeric / Visual ──────────────────────────────────── */}
                    <SectionHeader title="Numeric / Visual" icon="pi pi-chart-bar" />

                    <div className="col-12 md:col-4">
                        <FormGroup
                            htmlFor="sc-number"
                            label="InputNumber"
                            info="Currency mode (INR)"
                        >
                            <ControlledInputNumber
                                name="salaryBand"
                                control={control}
                                inputId="sc-number"
                                mode="currency"
                                currency="INR"
                                placeholder="0"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-4">
                        <FormGroup
                            htmlFor="sc-slider"
                            label="Slider"
                            info="Range: 30 – 200 · step 5"
                        >
                            <ControlledSlider
                                name="salaryBand"
                                control={control}
                                inputId="sc-slider"
                                min={30}
                                max={200}
                                step={5}
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-4">
                        <FormGroup
                            htmlFor="sc-rating"
                            label="Rating"
                            info="5-star performance rating"
                        >
                            <ControlledRating
                                name="rating"
                                control={control}
                                inputId="sc-rating"
                                stars={5}
                                cancel={false}
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 flex justify-content-center">
                        <FormGroup
                            htmlFor="sc-knob"
                            label="Knob"
                            info="Circular numeric input — completion %"
                        >
                            <ControlledKnob
                                name="completion"
                                control={control}
                                inputId="sc-knob"
                                min={0}
                                max={100}
                            />
                        </FormGroup>
                    </div>

                    {/* ── Miscellaneous ─────────────────────────────────────── */}
                    <SectionHeader title="Miscellaneous" icon="pi pi-ellipsis-h" />

                    <div className="col-12 md:col-6">
                        <FormGroup
                            htmlFor="sc-chips"
                            label="Chips"
                            info="Tag-style array input — press Enter to add"
                        >
                            <ControlledChips
                                name="tags"
                                control={control}
                                inputId="sc-chips"
                                placeholder="Add tag and press Enter…"
                            />
                        </FormGroup>
                    </div>

                    <div className="col-12 md:col-6">
                        <FormGroup htmlFor="sc-color" label="ColorPicker" info="Stores hex value">
                            <ControlledColorPicker
                                name="brandColor"
                                control={control}
                                inputId="sc-color"
                                format="hex"
                            />
                        </FormGroup>
                    </div>

                    {/* ── Actions ───────────────────────────────────────────── */}
                    <div className="col-12 flex justify-content-end gap-2 mt-3">
                        <Button type="submit" label="Log values" icon="pi pi-code" outlined />
                    </div>
                </div>
            </form>
        </>
    );
}

/* ─── Dashboard ────────────────────────────────────────────────────────────── */

const Dashboard = () => {
    const [employees, setEmployees] = useState(INITIAL_EMPLOYEES);
    const [globalFilter, setGlobalFilter] = useState('');

    const handleAdd = useCallback((data) => {
        setEmployees((prev) => [
            ...prev,
            {
                // id:     prev.length + 1,
                name: data.name,
                dept: data.department ?? '—',
                role: data.role,
                status: 'Active',
                joined: new Date().toISOString().slice(0, 10),
                salary: data.salary ?? 0,
            },
        ]);
    }, []);

    const statusBody = useCallback(
        (row) => <Tag value={row.status} severity={STATUS_SEVERITY[row.status]} />,
        [],
    );

    const salaryBody = useCallback((row) => <span>₹{row.salary.toLocaleString('en-IN')}</span>, []);

    const joinedBody = useCallback(
        (row) => (
            <span>
                {new Date(row.joined).toLocaleDateString('en-IN', {
                    day: '2-digit',
                    month: 'short',
                    year: 'numeric',
                })}
            </span>
        ),
        [],
    );

    const handleFilterChange = useCallback((e) => setGlobalFilter(e.target.value), []);

    const header = (
        <div className="flex align-items-center gap-2">
            <IconField iconPosition="left">
                <InputIcon className="pi pi-search" />
                <InputText
                    value={globalFilter}
                    onChange={handleFilterChange}
                    placeholder="Search employees…"
                />
            </IconField>
            <Button label="Add Employee" icon="pi pi-plus" size="small" />
        </div>
    );

    return (
        <PageLayout>
            <PageLayout.Header
                title="HRMS Dashboard"
                subtitle="Workforce overview and employee directory"
                status={<Tag value="Live" severity="success" />}
                actions={
                    <>
                        <Button label="Export Report" icon="pi pi-download" outlined />
                        <Button label="Add Employee" icon="pi pi-plus" />
                    </>
                }
            />

            <PageLayout.Content>
                {/* <div className="grid">
                    {STATS.map((stat) => (
                        <div key={stat.label} className="col-12 md:col-4">
                            <MetricCard
                                value={stat.value}
                                label={stat.label}
                                status={stat.status}
                                severity={stat.severity}
                            />
                        </div>
                    ))}
                </div> */}

                <QuickAddEmployeeForm onAdd={handleAdd} />

                <Card
                    title="Form Components Showcase"
                    footer={
                        <span className="text-sm text-color-secondary">
                            Shared card wrapper with title, content, and footer regions.
                        </span>
                    }
                >
                    <FormComponentsShowcase />
                </Card>

                <Card
                    title="Employee Directory"
                    header={header}
                    footer={
                        <div className="flex align-items-center justify-content-between gap-2">
                            <span className="text-sm text-color-secondary">
                                Showing {employees.length} employees
                            </span>
                            <Button
                                label="Manage Employees"
                                icon="pi pi-arrow-right"
                                text
                                severity="secondary"
                            />
                        </div>
                    }
                >
                    <DataTable
                        value={employees}
                        dataKey="id"
                        globalFilter={globalFilter}
                        globalFilterFields={['name', 'dept', 'role', 'status']}
                        paginator
                        rows={10}
                        rowsPerPageOptions={[5, 10, 25]}
                        sortMode="multiple"
                        removableSort
                        rowHover
                        emptyMessage="No employees found."
                        size="small"
                    >
                        <Column field="name" header="Employee" sortable style={COL_STYLE_NAME} />
                        <Column field="dept" header="Department" sortable style={COL_STYLE_DEPT} />
                        <Column field="role" header="Role" sortable style={COL_STYLE_ROLE} />
                        <Column
                            field="status"
                            header="Status"
                            body={statusBody}
                            sortable
                            style={COL_STYLE_STATUS}
                        />
                        <Column
                            field="joined"
                            header="Joined"
                            body={joinedBody}
                            sortable
                            style={COL_STYLE_JOINED}
                        />
                        <Column
                            field="salary"
                            header="Salary (₹)"
                            body={salaryBody}
                            sortable
                            style={COL_STYLE_SALARY}
                        />
                    </DataTable>
                </Card>
            </PageLayout.Content>

            <PageLayout.Footer align="between">
                <span className="text-sm text-color-secondary">
                    <i className="pi pi-clock mr-2" />
                    Last updated: {new Date().toLocaleDateString()}
                </span>
                <div className="flex gap-2">
                    <Button label="Refresh" icon="pi pi-refresh" text severity="secondary" />
                    <Button label="View All Employees" icon="pi pi-users" />
                </div>
            </PageLayout.Footer>
        </PageLayout>
    );
};

export default Dashboard;
