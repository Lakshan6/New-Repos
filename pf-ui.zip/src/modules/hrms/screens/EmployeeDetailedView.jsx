// EmployeeDetailedView.jsx
import React, { useRef, useEffect, useState, useCallback, useMemo } from 'react';
import { useNavigate, useLocation } from 'react-router';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Toast } from 'primereact/toast';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Dialog } from 'primereact/dialog';
import { TieredMenu } from 'primereact/tieredmenu';
import SectionCardWithHeader from '@shared/components/SectionCardWithHeader';
import TabbedSectionCard from '@shared/components/TabbedSectionCard';
import { AttachmentTable } from '@shared/components/AttachmentTable';
import { CustomTimeline } from '@shared/components/CustomTimeline';
import { useEmployeeDetail } from '../hooks/employees/useEmployeeDetail';
import { useGetInstance } from '../hooks/useGetInstance';
import { mapWorkflowToTimelineEvents } from '../utils/mapWorkflowToTimelineEvents';
import { useWorkflowAvailableActions } from '../hooks/useWorkflowAvailableActions';
import { useTakeActionOnEmployee } from '../hooks/employees/useTakeActionOnEmployee';
import PageContentCard from '@shared/components/PageContentCard';
import { Tag } from 'primereact/tag';
import { BreadCrumb } from 'primereact/breadcrumb';
import { useUpdateEmployee } from '../hooks/employees/useUpdateEmployee';
import { useFetchEmployeeDocuments } from '../hooks/employees/useFetchEmployeeDocuments.js';
import ActionConfirmationDialog from '../components/ActionConfirmationDialog';
import { useFetchDocumentMetadata } from '../hooks/useFetchDocumentMetadata';
import { useUploadEmployeeDocuments } from '../hooks/employees/useUploadEmployeeDocuments';
import { useSearchUsersByRoleAndOrg } from '../hooks/useSearchUsersByRoleAndOrg';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';

import { ConfirmDialog, confirmDialog } from 'primereact/confirmdialog';
import { useCreateEmployeeQualification } from '../hooks/employees/useCreateEmployeeQualification';
import { useUpdateEmployeeQualification } from '../hooks/employees/useUpdateEmployeeQualification';
import { useDeleteEmployeeQualification } from '../hooks/employees/useDeleteEmployeeQualification';
import { useCreateEmployeePastExperience } from '../hooks/employees/useCreateEmployeePastExperience';
import { useUpdateEmployeePastExperience } from '../hooks/employees/useUpdateEmployeePastExperience';
import { useDeleteEmployeePastExperience } from '../hooks/employees/useDeleteEmployeePastExperience';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { InputNumber } from 'primereact/inputnumber';
import { Checkbox } from 'primereact/checkbox';
import { InputTextarea } from 'primereact/inputtextarea';

import { PASTEL_COLORS } from '../utils/colours';

// AUDIT HISTORY IMPORTS
import { useAuditEntityHistory } from '../hooks/audit/useAuditEntityHistory';
import { mapAuditEntityToTimeline } from '../utils/mapAuditEntityToTimeline';

const INITIAL_ATTACHMENTS = [
    {
        srNo: 1,
        documentName: 'Address Proof',
        documentDescriptionType: 'dropdown',
        documents: [
            { label: 'Aadhar Card', value: 'aadhar' },
            { label: 'Passport', value: 'passport' },
            { label: 'Driving License', value: 'license' },
        ],
        selectedDoc: 'aadhar',
        files: [],
        multiple: true,
    },
    {
        srNo: 2,
        documentName: 'Educational Certificates',
        documentDescriptionType: 'input',
        enteredDesc: '',
        files: [],
        multiple: true,
    },
    {
        srNo: 3,
        documentName: 'Previous Employment',
        documentDescriptionType: 'dropdown',
        documents: [
            { label: 'Experience Letter', value: 'experience' },
            { label: 'Relieving Letter', value: 'relieving' },
            { label: 'Pay Slip', value: 'payslip' },
        ],
        selectedDoc: null,
        files: [],
        multiple: true,
    },
];

// Helper to generate initials from name
const getInitials = (name) => {
    if (!name) return '??';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
};

// Profile Avatar Component (larger version for detail view)
const ProfileAvatar = ({ name, size = '15rem' }) => {
    const initials = getInitials(name);
    const colorIndex =
        name?.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) % PASTEL_COLORS.length;
    const bgColor = PASTEL_COLORS[colorIndex];

    return (
        <div
            className="border-square border-round-xl border-1 border-black flex align-items-center justify-content-center text-black-alpha-50 font-bold"
            style={{
                width: size,
                height: size,
                backgroundColor: bgColor,
                fontSize: '4rem',
            }}
        >
            {initials}
        </div>
    );
};

const EmployeeDetailedView = () => {
    const navigate = useNavigate();
    const location = useLocation();
    const toast = useRef(null);
    const actionsMenuRef = useRef(null);

    const employeeId = location.state?.employeeId;

    // Fetch employee details
    const { data, isLoading, isError, error, refetch } = useEmployeeDetail(employeeId);

    const employee = data?.employee;
    const onboardingProcess = data?.onboardingProcess;
    const qualifications = data?.qualifications || [];
    const pastExperiences = data?.pastExperiences || [];

    // Form state
    const [formData, setFormData] = useState({});
    const [originalFormData, setOriginalFormData] = useState({});
    const [attachments, setAttachments] = useState(INITIAL_ATTACHMENTS);

    // UI state
    const [activeTab, setActiveTab] = useState('employee');
    const [isEditing, setIsEditing] = useState(false);
    const [showTimeline, setShowTimeline] = useState(false);
    const [timelineEvents, setTimelineEvents] = useState([]);
    const [documentsLoaded, setDocumentsLoaded] = useState(false);
    const [showActionDialog, setShowActionDialog] = useState(false);
    const [currentAction, setCurrentAction] = useState(null);
    const [currentStateOfEmployee, setCurrentStateOfEmployee] = useState(null);

    //Qualifications Dialog State Variables
    const [showQualificationDialog, setShowQualificationDialog] = useState(false);
    const [editingQualification, setEditingQualification] = useState(null);
    const [qualificationForm, setQualificationForm] = useState({});

    //Experience Dialog State Variables
    const [showExperienceDialog, setShowExperienceDialog] = useState(false);
    const [editingExperience, setEditingExperience] = useState(null);
    const [experienceForm, setExperienceForm] = useState({});

    // Timeline workflow/history display
    const [timelineView, setTimelineView] = useState('workflow');
    const [auditEvents, setAuditEvents] = useState([]);

    // Breadcrumb items
    const breadcrumbItems = useMemo(
        () => [
            {
                label: 'HRMS',
                command: () => navigate('/web/landing/hrms'),
            },
            {
                label: 'Employees',
                command: () => navigate('/web/landing/hrms/employee'),
            },
            {
                label: 'Employee Detail',
            },
        ],
        [navigate],
    );

    const home = useMemo(
        () => ({
            icon: 'pi pi-home',
            command: () => navigate('/'),
        }),
        [navigate],
    );

    // Workflow hooks
    const { fetchInstance, fetchCurrentState, isPending: isTimelineLoading } = useGetInstance();
    const {
        loadActions,
        clearActions,
        actions: workflowActions,
        isLoading: isActionsLoading,
        error: actionsError,
    } = useWorkflowAvailableActions();
    const { execute, isPending: isActionPending } = useTakeActionOnEmployee();

    //DATA UPDATE HOOK:
    const { updateEmployee, isPending: isUpdating } = useUpdateEmployee(employee?.id);

    // Documents hook
    const { fetchEmployeeDocuments, isPending: isLoadingDocuments } =
        useFetchEmployeeDocuments(employeeId);
    const { fetchDocumentMetadata } = useFetchDocumentMetadata();
    const { uploadDocuments, isPending: isUploadingDocs } = useUploadEmployeeDocuments(employeeId);

    //assignee hook - API/hook
    const { searchUsers, isPending: isLoadingAssignees } = useSearchUsersByRoleAndOrg();
    const [availableAssignees, setAvailableAssignees] = useState([]);

    // Qualification hooks
    const { createQualification, isPending: isCreatingQualification } =
        useCreateEmployeeQualification(employee?.id);
    const { updateQualification, isPending: isUpdatingQualification } =
        useUpdateEmployeeQualification(employee?.id);
    const { deleteQualification, isPending: isDeletingQualification } =
        useDeleteEmployeeQualification(employee?.id);

    // Past Experience hooks
    const { createPastExperience, isPending: isCreatingExperience } =
        useCreateEmployeePastExperience(employee?.id);
    const { updatePastExperience, isPending: isUpdatingExperience } =
        useUpdateEmployeePastExperience(employee?.id);
    const { deletePastExperience, isPending: isDeletingExperience } =
        useDeleteEmployeePastExperience(employee?.id);

    // Audit history hook
    const { fetchAuditHistory, isPending: isAuditLoading } = useAuditEntityHistory(
        'employee-audit',
        employee?.id,
    );

    // Toast helper - Define early as it's used by other callbacks
    const showToast = useCallback((severity, summary, detail) => {
        toast.current?.show({ severity, summary, detail, life: 3000 });
    }, []);

    // Derive current state safely
    useEffect(() => {
        const workflowInstanceId = onboardingProcess?.workflowInstanceId;

        if (!workflowInstanceId) {
            setCurrentStateOfEmployee(null);
            return;
        }

        const loadCurrentState = async () => {
            try {
                const state = await fetchCurrentState(workflowInstanceId);
                setCurrentStateOfEmployee(state ? state.trim().toUpperCase() : null);
            } catch (err) {
                console.error('Failed to fetch workflow state', err);
                setCurrentStateOfEmployee(null);
            }
        };

        loadCurrentState();
    }, [onboardingProcess?.workflowInstanceId, fetchCurrentState]);

    // Helper function to get icon based on action type
    const getActionIcon = useCallback((actionCode) => {
        const iconMap = {
            APPROVE: 'pi pi-check',
            VERIFY: 'pi pi-verified',
            REJECT: 'pi pi-times',
            SUBMIT: 'pi pi-send',
            RETURN: 'pi pi-arrow-left',
            FORWARD: 'pi pi-arrow-right',
            CANCEL: 'pi pi-ban',
        };
        return iconMap[actionCode?.toUpperCase()] || 'pi pi-cog';
    }, []);

    // Check if we're in document verification (read-only) state
    const isReadOnlyDocuments = useMemo(() => {
        return false;
    });

    // Load documents into attachments state
    const loadDocumentsFromEmployeeData = useCallback((documents) => {
        if (!documents || !Array.isArray(documents) || documents.length === 0) {
            console.log('No documents to load');
            setDocumentsLoaded(true);
            return;
        }

        console.log('Loading documents into attachments:', documents);

        const documentsByType = {};

        documents.forEach((doc) => {
            const docType = doc.documentType || doc.documentName || 'Unknown';
            if (!documentsByType[docType]) {
                documentsByType[docType] = [];
            }

            const fileWrapper = {
                name: doc.fileName || doc.name || 'document',
                size: doc.fileSize || doc.size || 0,
                type: doc.mimeType || doc.type || 'application/octet-stream',
                fileStoreId: doc.fileStoreId || doc.id,
                uploadStatus: 'success',
                previewUrl: doc.previewUrl || doc.url,
            };

            documentsByType[docType].push(fileWrapper);
        });

        setAttachments((prev) =>
            prev.map((attachment) => {
                const matchingDocs = documentsByType[attachment.documentName] || [];
                return {
                    ...attachment,
                    files: matchingDocs.length > 0 ? matchingDocs : attachment.files,
                };
            }),
        );

        setDocumentsLoaded(true);
    }, []);

    // Helper to get all uploaded fileStoreIds
    const getUploadedFileStoreIds = useCallback(() => {
        const fileStoreIds = [];
        attachments.forEach((attachment) => {
            attachment.files.forEach((fileWrapper) => {
                if (fileWrapper.fileStoreId && fileWrapper.uploadStatus === 'success') {
                    fileStoreIds.push(fileWrapper.fileStoreId);
                }
            });
        });
        return fileStoreIds;
    }, [attachments]);

    // Backend persistence helper
    const buildSubmittedDocumentPayload = useCallback(
        ({ employeeId, onboardingProcessId, candidateId = null }) => {
            const documents = [];

            attachments.forEach((attachment) => {
                attachment.files.forEach((fileWrapper) => {
                    if (fileWrapper.fileStoreId && fileWrapper.uploadStatus === 'success') {
                        documents.push({
                            onboardingProcessId,
                            candidateId,
                            employeeId,
                            filestoreId: fileWrapper.fileStoreId,
                            documentType: attachment.documentName,
                            documentDescription:
                                attachment.selectedDoc || attachment.enteredDesc || null,
                            fileName: fileWrapper.name,
                            fileSize: fileWrapper.size ?? null,
                            mimeType: fileWrapper.type ?? null,
                        });
                    }
                });
            });

            return documents;
        },
        [attachments],
    );

    // Check if any files are still uploading
    const hasUploadingFiles = useMemo(() => {
        return attachments.some((attachment) =>
            attachment.files.some((fileWrapper) => fileWrapper.uploadStatus === 'pending'),
        );
    }, [attachments]);

    // Check if any uploads have failed
    const hasFailedUploads = useMemo(() => {
        return attachments.some((attachment) =>
            attachment.files.some((fileWrapper) => fileWrapper.uploadStatus === 'failed'),
        );
    }, [attachments]);

    // Dynamic menu items with loading state
    const getActionMenuItems = useCallback(() => {
        // Loading state
        if (isActionsLoading) {
            return [
                {
                    template: () => (
                        <div className="flex align-items-center justify-content-center gap-2 px-3 py-2">
                            <i className="pi pi-spinner pi-spin text-primary" />
                            <span className="text-600">Loading actions...</span>
                        </div>
                    ),
                },
            ];
        }

        // Error state
        if (actionsError) {
            return [
                {
                    template: () => (
                        <div className="flex align-items-center justify-content-center gap-2 px-3 py-2 text-red-500">
                            <i className="pi pi-exclamation-circle" />
                            <span>Failed to load actions</span>
                        </div>
                    ),
                },
            ];
        }

        // Empty state
        if (workflowActions.length === 0) {
            return [
                {
                    template: () => (
                        <div className="flex align-items-center justify-content-center gap-2 px-3 py-2 text-500">
                            <i className="pi pi-info-circle" />
                            <span>No actions available</span>
                        </div>
                    ),
                },
            ];
        }

        // Actual action items
        return workflowActions.map((wfAction) => ({
            label: wfAction.label,
            icon: getActionIcon(wfAction.action),
            command: () =>
                handleAction({
                    actionCode: wfAction.action,
                    nextState: wfAction.nextState,
                    nextStateName: wfAction.nextStateName,
                    requiresDocuments: wfAction.documentRequired ?? false,
                    requiresAssignee: wfAction.assigneeMandatory ?? false,
                    roleIds: wfAction.roleIds,
                }),
        }));
    }, [isActionsLoading, actionsError, workflowActions, getActionIcon]);

    // Tabs configuration
    const tabs = useMemo(
        () => [
            {
                label: 'Employee Info',
                icon: 'pi pi-user',
                active: activeTab === 'employee',
                onClick: () => setActiveTab('employee'),
            },
            {
                label: 'Qualifications',
                icon: 'pi pi-book',
                active: activeTab === 'qualifications',
                onClick: () => setActiveTab('qualifications'),
                badge: qualifications.length > 0 ? qualifications.length : null,
            },
            {
                label: 'Past Experience',
                icon: 'pi pi-briefcase',
                active: activeTab === 'experience',
                onClick: () => setActiveTab('experience'),
                badge: pastExperiences.length > 0 ? pastExperiences.length : null,
            },
            {
                label: 'Documents',
                icon: 'pi pi-paperclip',
                active: activeTab === 'documents',
                onClick: () => setActiveTab('documents'),
                badge: attachments.reduce((sum, att) => sum + att.files.length, 0),
            },
            {
                label: 'Bank Details',
                icon: 'pi pi-money-bill',
                active: activeTab === 'bank',
                onClick: () => setActiveTab('bank'),
            },
        ],
        [activeTab, attachments, qualifications.length, pastExperiences.length],
    );

    // Fetch documents on component mount
    useEffect(() => {
        if (!employeeId) return;
        if (documentsLoaded) return;

        const loadDocuments = async () => {
            try {
                const docs = await fetchEmployeeDocuments();
                console.log('Fetched employee documents:', docs);
                loadDocumentsFromEmployeeData(docs);
            } catch (err) {
                console.error('Failed to fetch employee documents:', err);
                setDocumentsLoaded(true);
            }
        };

        loadDocuments();
    }, [employeeId, documentsLoaded, fetchEmployeeDocuments, loadDocumentsFromEmployeeData]);

    // Reset documents when employee changes
    useEffect(() => {
        setDocumentsLoaded(false);
        setAttachments(INITIAL_ATTACHMENTS);
    }, [employeeId]);

    // Redirect if no ID
    useEffect(() => {
        if (!employeeId) {
            navigate('/web/landing/hrms/employees', { replace: true });
        }
    }, [employeeId, navigate]);

    // Populate form when data arrives
    useEffect(() => {
        if (employee) {
            const data = {
                // Basic Info
                employeeId: employee.employeeId || employee.employee || '',
                firstName: employee.firstName || '',
                lastName: employee.lastName || '',
                fullName: employee.fullName || employee.employeeName || '',
                gender: employee.gender || '',
                dateOfBirth: employee.dateOfBirth || '',
                contactNumber: employee.contactNumber || employee.cellNumber || '',
                email: employee.email || employee.personalEmail || '',
                companyEmail: employee.companyEmail || '',
                currentAddress: employee.currentAddress || '',
                joiningDate: employee.joiningDate || employee.dateOfJoining || '',

                // Organizational (include both IDs and names)
                departmentId: employee.departmentId || null,
                department: employee.department || employee.departmentName || '',
                designationId: employee.designationId || null,
                designation: employee.designation || employee.designationName || '',
                reportingOfficerId: employee.reportingManager || employee.reportingToId || '',
                reportingOfficerName:
                    employee.reportingOfficerName || employee.reportingToName || '',
                employmentTypeId: employee.employmentTypeId || null,
                employeeType: employee.employeeType || employee.employmentTypeName || '',
                workLocation: employee.workLocation || '',

                // Bank Details
                bankName: employee.bankName || '',
                accountNumber: employee.accountNumber || '',
                ifsc: employee.ifsc || '',
                branch: employee.branch || '',
                micr: employee.micr || '',
                accountType: employee.accountType || '',

                // Status & Audit
                tenantId: employee.tenantId || null,
                revId: employee.revId || null,
            };
            setFormData(data);
            setOriginalFormData(data);
        }
    }, [employee]);

    // Safe dialog close handler
    const handleCloseActionDialog = useCallback(() => {
        setShowActionDialog(false);
        setCurrentAction(null);
    }, []);

    // Navigation
    const handleBack = useCallback(() => navigate(-1), [navigate]);

    // Form field change handler
    const handleInputChange = useCallback((field, value) => {
        setFormData((prev) => ({
            ...prev,
            [field]: value,
        }));
    }, []);

    // Edit mode handlers
    const handleEdit = useCallback(() => {
        setOriginalFormData({ ...formData });
        setIsEditing(true);
    }, [formData]);

    const handleCancel = useCallback(() => {
        setFormData({ ...originalFormData });
        setIsEditing(false);
    }, [originalFormData]);

    const handleSave = useCallback(async () => {
        try {
            // Call the API to update employee
            const updatedEmployee = await updateEmployee(formData);

            // Update local state with response
            setOriginalFormData({ ...formData });
            setIsEditing(false);

            // Optionally refetch to ensure data is synced
            await refetch();

            showToast('success', 'Saved', 'Employee details updated successfully');
        } catch (err) {
            console.error('Update failed:', err);
            showToast('error', 'Save Failed', err?.message || 'Unable to save changes');
        }
    }, [formData, updateEmployee, refetch, showToast]);

    // Action handler with document support
    const handleAction = useCallback(
        async (actionObj) => {
            setCurrentAction(actionObj);
            setShowActionDialog(true);

            try {
                const roleIds = actionObj.roleIds;

                if (!roleIds || roleIds.length === 0) {
                    setAvailableAssignees([]);
                    return;
                }

                const users = await searchUsers({
                    roleIds,
                    // 🚨 tenant comes from requestInfo automatically
                    // orgIds intentionally NOT passed
                });

                const assignees = (users || []).map((u) => ({
                    label: `${u.firstName ?? ''} ${u.lastName ?? ''}`.trim(),
                    value: u.uuid, // ← ASSIGNEE UUID
                    email: u.emailId,
                    role: u.roleIds?.join(', '), // optional display
                }));

                setAvailableAssignees(assignees);
            } catch (err) {
                console.error('Failed to load assignees', err);
                setAvailableAssignees([]);
                showToast('error', 'Assignee Load Failed', 'Unable to fetch eligible assignees');
            }
        },
        [searchUsers, showToast],
    );

    // Used to execute the selected action
    const executeAction = useCallback(
        async ({ action, assignee, supportingDocuments = [] }) => {
            //   Guard against null action
            if (!action?.actionCode) {
                showToast('error', 'Action Error', 'Invalid workflow action');
                return;
            }

            const { actionCode, nextState, nextStateName, requiresDocuments } = action;

            // Close dialog immediately
            setShowActionDialog(false);
            setCurrentAction(null);

            try {
                // ---------- Guard Checks ----------
                if (!onboardingProcess?.workflowInstanceId) {
                    showToast('error', 'Workflow Error', 'Workflow instance not found');
                    return;
                }

                if (hasUploadingFiles) {
                    showToast(
                        'warning',
                        'Upload In Progress',
                        'Please wait for all files to finish uploading',
                    );
                    return;
                }

                if (hasFailedUploads) {
                    showToast(
                        'error',
                        'Upload Failed',
                        'Some files failed to upload. Please remove and re-upload them.',
                    );
                    return;
                }

                //   NEW: Validate supporting documents when required
                if (requiresDocuments && supportingDocuments.length === 0) {
                    showToast(
                        'warning',
                        'Documents Required',
                        'This action requires supporting documents to be uploaded.',
                    );
                    return;
                }

                // ---------- Step 1: Save Main Employee Documents (Always save if any exist) ----------
                const uploadedFileStoreIds = getUploadedFileStoreIds();

                if (uploadedFileStoreIds.length > 0) {
                    showToast('info', 'Saving Documents', 'Uploading employee documents...');

                    const documentPayload = buildSubmittedDocumentPayload({
                        employeeId: employee.id,
                        onboardingProcessId: onboardingProcess.id,
                        candidateId: null,
                    });

                    await uploadDocuments(documentPayload);
                    showToast(
                        'success',
                        'Documents Saved',
                        'Employee documents uploaded successfully',
                    );
                }

                // ---------- Step 2: Save Supporting Documents ----------
                if (supportingDocuments.length > 0) {
                    showToast('info', 'Saving Supporting Documents', 'Uploading...');

                    const supportingPayload = supportingDocuments.map((doc) => ({
                        onboardingProcessId: onboardingProcess.id,
                        candidateId: null,
                        employeeId: employee.id,
                        filestoreId: doc.fileStoreId,
                        documentType: 'Supporting Documents',
                        documentDescription:
                            doc.documentDescription || 'Supporting documents for workflow action',
                        fileName: `Supporting Document - ${doc.fileName}`,
                        fileSize: doc.fileSize ?? null,
                        mimeType: doc.mimeType ?? null,
                    }));

                    await uploadDocuments(supportingPayload);
                    showToast(
                        'success',
                        'Supporting Documents Saved',
                        'Supporting documents uploaded successfully',
                    );
                }

                // ---------- Step 3: Execute Workflow ----------
                showToast('info', 'Processing', `Executing action: ${actionCode}`);

                const payload = {
                    wfInstanceId: onboardingProcess.workflowInstanceId,
                    employeeId: employee.id,
                    action: action.actionCode,
                    shouldSync: true,
                };

                //   ADD ASSIGNEE IF PRESENT
                if (assignee) {
                    payload.assignee = assignee;
                }

                //   IMPORTANT: Only send supporting document IDs to workflow
                const supportIds = supportingDocuments.map((d) => d.fileStoreId);

                if (supportIds.length > 0) {
                    payload.documents = supportIds;
                }

                await execute(payload);

                showToast('success', 'Action Completed', `Moved to state: ${nextState}`);

                // ---------- Step 4: Refresh ----------
                clearActions();

                const updatedState = await fetchCurrentState(onboardingProcess.workflowInstanceId);
                setCurrentStateOfEmployee(updatedState?.trim().toUpperCase() || null);

                await refetch();
            } catch (err) {
                showToast(
                    'error',
                    'Action Failed',
                    err?.message || 'Unable to perform workflow action',
                );
            }
        },
        [
            onboardingProcess?.workflowInstanceId,
            onboardingProcess?.id,
            employee?.id,
            hasUploadingFiles,
            hasFailedUploads,
            getUploadedFileStoreIds,
            buildSubmittedDocumentPayload,
            uploadDocuments,
            execute,
            clearActions,
            fetchCurrentState,
            refetch,
            showToast,
        ],
    );

    // Actions button click handler - opens menu and loads actions
    const handleActionsButtonClick = useCallback(
        async (event) => {
            // Toggle menu first (will show loading state)
            actionsMenuRef.current?.toggle(event);

            // Load actions if not already loaded or loading
            if (workflowActions.length === 0 && !isActionsLoading) {
                const workflowInstanceId = onboardingProcess?.workflowInstanceId;

                try {
                    await loadActions(workflowInstanceId);
                } catch (err) {
                    console.error('Failed to load actions:', err);
                }
            }
        },
        [
            workflowActions.length,
            isActionsLoading,
            onboardingProcess?.workflowInstanceId,
            loadActions,
        ],
    );

    const handleReset = useCallback(() => {
        refetch();
        setAttachments(INITIAL_ATTACHMENTS);
        setIsEditing(false);
        showToast('info', 'Reset', 'Form has been reset');
    }, [refetch, showToast]);

    // Timeline handler with document metadata
    const handleViewTimeline = useCallback(async () => {
        try {
            const workflowInstanceId = onboardingProcess?.workflowInstanceId;
            if (!workflowInstanceId) {
                showToast('warn', 'No Workflow', 'No workflow instance found');
                return;
            }

            const response = await fetchInstance(workflowInstanceId);
            const wfInstance = response?.[0];

            if (!wfInstance) {
                showToast('error', 'Data Error', 'Workflow instance not found');
                return;
            }

            // Pass the fetch function for document metadata
            const events = await mapWorkflowToTimelineEvents(wfInstance, fetchDocumentMetadata);

            setTimelineEvents(events);
            setShowTimeline(true);
        } catch (err) {
            showToast(
                'error',
                'Unable to load timeline',
                err?.message || 'Workflow timeline could not be loaded',
            );
        }
    }, [onboardingProcess?.workflowInstanceId, fetchInstance, fetchDocumentMetadata, showToast]);

    const handleTimelineViewChange = useCallback(
        async (view) => {
            setTimelineView(view);

            if (view === 'history' && auditEvents.length === 0) {
                try {
                    const auditData = await fetchAuditHistory();
                    const events = mapAuditEntityToTimeline(auditData);
                    setAuditEvents(events);
                } catch (err) {
                    showToast(
                        'error',
                        'History Load Failed',
                        err?.message || 'Unable to load audit history',
                    );
                }
            }
        },
        [auditEvents.length, fetchAuditHistory, showToast],
    );

    // Copy to clipboard handler
    const copyToClipboard = useCallback(async (text) => {
        try {
            await navigator.clipboard.writeText(text);
            toast.current?.show({
                severity: 'success',
                summary: 'Copied!',
                detail: 'Copied to clipboard',
                life: 2000,
            });
        } catch (err) {
            console.error('Copy failed:', err);
            toast.current?.show({
                severity: 'error',
                summary: 'Failed',
                detail: 'Could not copy',
                life: 3000,
            });
        }
    }, []);

    // Qualifications Dialog Handlers
    const openCreateQualification = () => {
        setEditingQualification(null);

        setQualificationForm({
            qualificationType: '',
            educationLevel: '',
            courseName: '',
            specialization: '',
            majorField: '',
            minorField: '',
            institution: '',
            boardOrUniversity: '',
            issuingAuthority: '',
            accreditationBody: '',
            country: '',
            modeOfStudy: '',
            yearOfCompletion: '',
            issueDate: '',
            expiryDate: '',
            completionStatus: '',
            durationInMonths: '',
            gradeOrPercentage: '',
            percentageNumeric: '',
            cgpa: '',
            resultClassification: '',
            honors: '',
            certificateNumber: '',
            registrationNumber: '',
            verificationSource: '',
            verificationReference: '',
            isDeclaredByCandidate: true,
            isSelfAttested: false,
        });

        setShowQualificationDialog(true);
    };

    const openEditQualification = (row) => {
        setEditingQualification(row);
        setQualificationForm({ ...row });
        setShowQualificationDialog(true);
    };
    const handleDeleteQualification = (row) => {
        confirmDialog({
            message: 'Are you sure you want to delete this qualification?',
            header: 'Delete Confirmation',
            icon: 'pi pi-exclamation-triangle',
            accept: async () => {
                try {
                    await deleteQualification(row.id);
                    showToast('success', 'Deleted', 'Qualification removed');
                    refetch();
                } catch (err) {
                    showToast(
                        'error',
                        'Delete Failed',
                        err?.message || 'Unable to delete qualification',
                    );
                }
            },
        });
    };

    const handleSaveQualification = async () => {
        if (!qualificationForm.courseName?.trim() || !qualificationForm.qualificationType?.trim()) {
            showToast('error', 'Validation', 'Course Name and Qualification Type are required');
            return;
        }

        const qualificationData = {
            ...qualificationForm,
            tenantId: employee.tenantId,
            employeeId: employee.id,
        };

        try {
            if (editingQualification) {
                await updateQualification(qualificationData);
                showToast('success', 'Updated', 'Qualification updated successfully');
            } else {
                await createQualification(qualificationData);
                showToast('success', 'Created', 'Qualification added successfully');
            }

            setShowQualificationDialog(false);
            refetch();
        } catch (err) {
            showToast('error', 'Failed', err?.message || 'Operation failed');
        }
    };

    // Past Experience Dialog Handlers
    const openCreateExperience = () => {
        setEditingExperience(null);

        setExperienceForm({
            companyName: '',
            designation: '',
            employmentType: '',
            employeeCode: '',
            startDate: null,
            endDate: null,
            isCurrent: false,
            durationInMonths: null,
            responsibilities: '',
            reasonForLeaving: '',
            companyLocation: '',
            companyCountry: '',
            companyRegistrationNumber: '',
            reportingManagerName: '',
            reportingManagerEmail: '',
            hrContactEmail: '',
            hrContactPhone: '',
            experienceCertificateNumber: '',
            offerLetterNumber: '',
            relievingLetterNumber: '',
            verificationSource: '',
            verificationReference: '',
            isVerified: false,
            lastDrawnSalary: null,
            currency: 'INR',
        });

        setShowExperienceDialog(true);
    };

    const openEditExperience = (row) => {
        setEditingExperience(row);
        setExperienceForm({ ...row });
        setShowExperienceDialog(true);
    };

    const handleDeleteExperience = (row) => {
        confirmDialog({
            message: 'Are you sure you want to delete this experience record?',
            header: 'Delete Confirmation',
            icon: 'pi pi-exclamation-triangle',
            accept: async () => {
                try {
                    await deletePastExperience(row.id);
                    showToast('success', 'Deleted', 'Experience record removed');
                    refetch();
                } catch (err) {
                    showToast(
                        'error',
                        'Delete Failed',
                        err?.message || 'Unable to delete experience record',
                    );
                }
            },
        });
    };

    const handleSaveExperience = async () => {
        if (!experienceForm.companyName?.trim() || !experienceForm.designation?.trim()) {
            showToast('error', 'Validation', 'Company Name and Designation are required');
            return;
        }

        const experienceData = {
            ...experienceForm,
            tenantId: employee.tenantId,
            employeeId: employee.id,
        };

        try {
            if (editingExperience) {
                await updatePastExperience(experienceData);
                showToast('success', 'Updated', 'Experience updated successfully');
            } else {
                await createPastExperience(experienceData);
                showToast('success', 'Created', 'Experience added successfully');
            }

            setShowExperienceDialog(false);
            refetch();
        } catch (err) {
            showToast('error', 'Failed', err?.message || 'Operation failed');
        }
    };

    // Loading state
    if (isLoading) {
        return (
            <div className="surface-ground min-h-screen flex align-items-center justify-content-center flex-column">
                <ProgressSpinner />
                <p className="mt-3 text-500">Loading employee details...</p>
            </div>
        );
    }

    // Error state
    if (isError || !employee) {
        return (
            <div className="surface-ground min-h-screen p-4 flex align-items-center justify-content-center flex-column">
                <i className="pi pi-exclamation-triangle text-6xl text-orange-500 mb-4" />
                <h2>Unable to load employee</h2>
                <p className="text-600 mb-4">{error?.message || 'Employee not found'}</p>
                <div className="flex gap-3">
                    <Button label="Go Back" icon="pi pi-arrow-left" outlined onClick={handleBack} />
                    <Button label="Retry" icon="pi pi-refresh" onClick={refetch} />
                </div>
            </div>
        );
    }

    return (
        <div className="surface-ground min-h-screen p-1">
            <Toast ref={toast} />

            {/* Action Confirmation Dialog */}
            {showActionDialog && currentAction && (
                <ActionConfirmationDialog
                    visible={showActionDialog}
                    onHide={handleCloseActionDialog}
                    onConfirm={executeAction}
                    action={currentAction}
                    availableAssignees={availableAssignees}
                    candidate={employee} // Pass employee as candidate
                    uploadedDocCount={getUploadedFileStoreIds().length}
                />
            )}

            {/* TieredMenu with Dynamic Items */}
            <TieredMenu
                model={getActionMenuItems()}
                popup
                ref={actionsMenuRef}
                breakpoint="600px"
                pt={{
                    root: { className: 'min-w-12rem' },
                }}
            />

            {/* Breadcrumb */}
            <div className="ml-0 mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {/* Main Content Card */}
            <PageContentCard padding="md" rounded="lg" shadow="sm">
                {/* Header – Left: Back + Title + Tag | Right: Actions/Edit */}
                <div className="flex align-items-center justify-content-between mt-1 mb-1 px-3 py-1">
                    {/* LEFT SIDE */}
                    <div className="flex align-items-center gap-3">
                        <Button icon="pi pi-arrow-left" text rounded onClick={handleBack} />

                        <div className="flex align-items-center gap-5">
                            <h4 className="m-0 text-2xl font-semibold">Employee Details</h4>
                            <Button
                                size="small"
                                label={employee?.id || 'N/A'}
                                severity="secondary"
                                rounded
                                onClick={() => copyToClipboard(employee.id || '')}
                            />
                        </div>

                        <Tag
                            className="p-2"
                            value={onboardingProcess?.currentState}
                            rounded
                            severity={
                                onboardingProcess?.currentState !== 'REJECTED'
                                    ? 'success'
                                    : 'danger'
                            }
                        />
                        {hasUploadingFiles && (
                            <Tag
                                icon="pi pi-spinner pi-spin"
                                severity="info"
                                value="Uploading..."
                            />
                        )}
                        {hasFailedUploads && (
                            <Tag
                                icon="pi pi-exclamation-circle"
                                severity="danger"
                                value="Upload Failed"
                            />
                        )}
                    </div>

                    {/* RIGHT SIDE – Edit/Save or Actions */}
                    {isEditing ? (
                        <div className="flex align-items-center gap-2">
                            <Button
                                label="Cancel"
                                icon="pi pi-times"
                                outlined
                                severity="danger"
                                onClick={handleCancel}
                                disabled={isUpdating}
                                size="small"
                            />
                            <Button
                                label="Save"
                                icon="pi pi-save"
                                severity="success"
                                onClick={handleSave}
                                loading={isUpdating}
                                size="small"
                            />
                        </div>
                    ) : (
                        <div className="flex align-items-center gap-2">
                            <Button
                                label="Edit"
                                icon="pi pi-pencil"
                                outlined
                                onClick={handleEdit}
                                size="small"
                            />
                            <Button
                                label="Actions"
                                icon="pi pi-chevron-down"
                                iconPos="right"
                                onClick={handleActionsButtonClick}
                                loading={isActionsLoading}
                                disabled={hasUploadingFiles}
                                size="small"
                            />
                            <Button
                                label="View Timeline"
                                icon="pi pi-history"
                                outlined
                                onClick={handleViewTimeline}
                                loading={isTimelineLoading}
                                size="small"
                            />
                        </div>
                    )}
                </div>

                {/* Divider Line */}
                <div className="border-top-1 surface-border  mb-1" />

                {/* TABBED SECTION CARD */}
                <TabbedSectionCard tabs={tabs} transparentBorder={true}>
                    {/* TAB: Employee Info */}
                    {activeTab === 'employee' && (
                        <div className="flex flex-column gap-4">
                            <SectionCardWithHeader title="Profile Information">
                                <div className="flex gap-4">
                                    {/* Left: Profile Photo */}
                                    <div className="flex flex-column align-items-center justify-content-center gap-3 px-3">
                                        <ProfileAvatar name={formData.fullName} />
                                        {isEditing && (
                                            <Button
                                                label="Change Photo"
                                                icon="pi pi-camera"
                                                size="small"
                                                outlined
                                            />
                                        )}
                                    </div>

                                    {/* Right: Form Fields */}
                                    <div className="flex-1">
                                        <div className="grid">
                                            <div className="col-12 md:col-6">
                                                <label
                                                    htmlFor="employeeId"
                                                    className="block text-600 mb-2"
                                                >
                                                    Employee ID
                                                </label>
                                                <InputText
                                                    value={formData.employeeId}
                                                    disabled
                                                    className="w-full"
                                                />
                                            </div>

                                            <div className="col-12 md:col-6">
                                                <label
                                                    htmlFor="fullName"
                                                    className="block text-600 mb-2"
                                                >
                                                    Full Name
                                                </label>
                                                <InputText
                                                    value={formData.fullName}
                                                    onChange={(e) =>
                                                        handleInputChange(
                                                            'fullName',
                                                            e.target.value,
                                                        )
                                                    }
                                                    disabled={!isEditing}
                                                    className="w-full"
                                                />
                                            </div>

                                            <div className="col-12 md:col-6">
                                                <label
                                                    htmlFor="email"
                                                    className="block text-600 mb-2"
                                                >
                                                    Email
                                                </label>
                                                <InputText
                                                    value={formData.email}
                                                    onChange={(e) =>
                                                        handleInputChange('email', e.target.value)
                                                    }
                                                    disabled={!isEditing}
                                                    className="w-full"
                                                />
                                            </div>

                                            <div className="col-12 md:col-6">
                                                <label
                                                    htmlFor="contactNumber"
                                                    className="block text-600 mb-2"
                                                >
                                                    Mobile
                                                </label>
                                                <InputText
                                                    value={formData.contactNumber}
                                                    onChange={(e) =>
                                                        handleInputChange(
                                                            'contactNumber',
                                                            e.target.value,
                                                        )
                                                    }
                                                    disabled={!isEditing}
                                                    className="w-full"
                                                />
                                            </div>

                                            <div className="col-12 md:col-6">
                                                <label
                                                    htmlFor="dateOfBirth"
                                                    className="block text-600 mb-2"
                                                >
                                                    Date of Birth
                                                </label>
                                                <InputText
                                                    value={formData.dateOfBirth}
                                                    onChange={(e) =>
                                                        handleInputChange(
                                                            'dateOfBirth',
                                                            e.target.value,
                                                        )
                                                    }
                                                    disabled={!isEditing}
                                                    className="w-full"
                                                />
                                            </div>

                                            <div className="col-12 md:col-6">
                                                <label
                                                    htmlFor="gender"
                                                    className="block text-600 mb-2"
                                                >
                                                    Gender
                                                </label>
                                                <InputText
                                                    value={formData.gender}
                                                    onChange={(e) =>
                                                        handleInputChange('gender', e.target.value)
                                                    }
                                                    disabled={!isEditing}
                                                    className="w-full"
                                                />
                                            </div>

                                            <div className="col-12">
                                                <label
                                                    htmlFor="currentAddress"
                                                    className="block text-600 mb-2"
                                                >
                                                    Current Address
                                                </label>
                                                <InputText
                                                    value={formData.currentAddress}
                                                    onChange={(e) =>
                                                        handleInputChange(
                                                            'currentAddress',
                                                            e.target.value,
                                                        )
                                                    }
                                                    disabled={!isEditing}
                                                    className="w-full"
                                                />
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </SectionCardWithHeader>

                            <SectionCardWithHeader
                                title="Employee Information"
                                subtitle={employee.fullName}
                                status={currentStateOfEmployee}
                            >
                                <div className="sc-grid-2">
                                    <div>
                                        <label
                                            htmlFor="joiningDate"
                                            className="block text-600 mb-2"
                                        >
                                            Joining Date
                                        </label>
                                        <InputText
                                            value={formData.joiningDate}
                                            disabled
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label htmlFor="department" className="block text-600 mb-2">
                                            Department
                                        </label>
                                        <InputText
                                            value={formData.department}
                                            onChange={(e) =>
                                                handleInputChange('department', e.target.value)
                                            }
                                            disabled={!isEditing}
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="designation"
                                            className="block text-600 mb-2"
                                        >
                                            Designation
                                        </label>
                                        <InputText
                                            value={formData.designation}
                                            onChange={(e) =>
                                                handleInputChange('designation', e.target.value)
                                            }
                                            disabled={!isEditing}
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="reportingOfficerName"
                                            className="block text-600 mb-2"
                                        >
                                            Reporting Officer
                                        </label>
                                        <InputText
                                            value={formData.reportingOfficerName}
                                            onChange={(e) =>
                                                handleInputChange(
                                                    'reportingOfficerName',
                                                    e.target.value,
                                                )
                                            }
                                            disabled={!isEditing}
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="employeeType"
                                            className="block text-600 mb-2"
                                        >
                                            Employee Type
                                        </label>
                                        <InputText
                                            value={formData.employeeType}
                                            onChange={(e) =>
                                                handleInputChange('employeeType', e.target.value)
                                            }
                                            disabled={!isEditing}
                                            className="w-full"
                                        />
                                    </div>

                                    <div>
                                        <label
                                            htmlFor="workLocation"
                                            className="block text-600 mb-2"
                                        >
                                            Work Location
                                        </label>
                                        <InputText
                                            value={formData.workLocation}
                                            onChange={(e) =>
                                                handleInputChange('workLocation', e.target.value)
                                            }
                                            disabled={!isEditing}
                                            className="w-full"
                                        />
                                    </div>
                                </div>
                            </SectionCardWithHeader>
                        </div>
                    )}

                    {/* ── NEW ── Qualifications Tab */}
                    {activeTab === 'qualifications' && (
                        <SectionCardWithHeader
                            title="Educational Qualifications"
                            subtitle={`${qualifications.length} qualification${qualifications.length !== 1 ? 's' : ''}`}
                            actions={[
                                {
                                    label: 'Add Qualification',
                                    icon: 'pi pi-plus',
                                    onClick: openCreateQualification,
                                    // optional:
                                    className: 'p-button-outlined p-button-s',
                                    tooltip: 'Add new educational qualification',
                                },
                            ]}
                        >
                            {qualifications.length === 0 ? (
                                <div className="text-center py-6 text-500">
                                    No qualifications added yet
                                </div>
                            ) : (
                                <div>
                                    <DataTable
                                        value={qualifications}
                                        size="medium"
                                        showGridlines
                                        className="table-outline-clean"
                                        scrollable
                                        scrollHeight="600px"
                                    >
                                        {/* Core */}
                                        <Column field="qualificationType" header="Type" />
                                        <Column field="educationLevel" header="Level" />
                                        <Column field="courseName" header="Course" />
                                        <Column field="specialization" header="Specialization" />

                                        {/* Institution */}
                                        <Column
                                            header="Institution / University"
                                            body={(row) =>
                                                row.institution ||
                                                row.boardOrUniversity ||
                                                row.issuingAuthority ||
                                                '-'
                                            }
                                        />
                                        <Column field="modeOfStudy" header="Mode" />

                                        {/* Completion */}
                                        <Column field="yearOfCompletion" header="Year" />
                                        <Column field="completionStatus" header="Status" />

                                        {/* Result */}
                                        <Column
                                            header="Score"
                                            body={(row) =>
                                                row.gradeOrPercentage ||
                                                row.percentageNumeric ||
                                                row.cgpa ||
                                                '-'
                                            }
                                        />

                                        <Column
                                            header="Actions"
                                            body={(row) => (
                                                <div className="flex gap-2 justify-content-center">
                                                    <Button
                                                        icon="pi pi-pencil"
                                                        text
                                                        onClick={() => openEditQualification(row)}
                                                    />
                                                    <Button
                                                        icon="pi pi-trash"
                                                        text
                                                        severity="danger"
                                                        onClick={() =>
                                                            handleDeleteQualification(row)
                                                        }
                                                    />
                                                </div>
                                            )}
                                        />
                                    </DataTable>
                                </div>
                            )}
                        </SectionCardWithHeader>
                    )}

                    {/* ── NEW ── Experience Tab */}
                    {activeTab === 'experience' && (
                        <SectionCardWithHeader
                            title="Past Experience"
                            subtitle={`${pastExperiences.length} experience${pastExperiences.length !== 1 ? 's' : ''}`}
                            actions={[
                                {
                                    label: 'Add Experience',
                                    icon: 'pi pi-plus',
                                    onClick: openCreateExperience,
                                    className: 'p-button-outlined p-button-s',
                                    tooltip: 'Add past experience details',
                                },
                            ]}
                        >
                            {pastExperiences.length === 0 ? (
                                <div className="text-center py-6 text-500">
                                    No past experience records found.
                                </div>
                            ) : (
                                <div>
                                    <DataTable
                                        value={pastExperiences}
                                        size="medium"
                                        responsiveLayout="scroll"
                                        className="table-outline-clean"
                                        showGridlines
                                        scrollable
                                        scrollHeight="600px"
                                    >
                                        {/* Company */}
                                        <Column field="companyName" header="Company" />

                                        <Column field="designation" header="Designation" />

                                        <Column field="employmentType" header="Type" />

                                        {/* Period */}
                                        <Column
                                            header="Period"
                                            body={(row) => {
                                                const start = row.startDate
                                                    ? new Date(row.startDate).toLocaleDateString()
                                                    : '-';

                                                const end = row.isCurrent
                                                    ? 'Present'
                                                    : row.endDate
                                                      ? new Date(row.endDate).toLocaleDateString()
                                                      : '-';

                                                return `${start} → ${end}`;
                                            }}
                                        />

                                        <Column
                                            field="durationInMonths"
                                            header="Duration (Months)"
                                        />

                                        {/* Location */}
                                        <Column
                                            header="Location"
                                            body={(row) =>
                                                row.companyLocation || row.companyCountry || '-'
                                            }
                                        />

                                        {/* Salary */}
                                        <Column
                                            header="Last Salary"
                                            body={(row) =>
                                                row.lastDrawnSalary
                                                    ? `${row.currency || ''} ${row.lastDrawnSalary}`
                                                    : '-'
                                            }
                                        />

                                        {/* Current */}
                                        <Column
                                            header="Status"
                                            body={(row) =>
                                                row.isCurrent ? (
                                                    <Tag
                                                        value="Current"
                                                        severity="success"
                                                        rounded
                                                    />
                                                ) : (
                                                    <Tag
                                                        value="Past"
                                                        severity="secondary"
                                                        rounded
                                                    />
                                                )
                                            }
                                        />

                                        {/* Verified */}
                                        <Column
                                            header="Verified"
                                            body={(row) =>
                                                row.isVerified ? (
                                                    <Tag value="Verified" severity="info" rounded />
                                                ) : (
                                                    <Tag
                                                        value="Pending"
                                                        severity="warning"
                                                        rounded
                                                    />
                                                )
                                            }
                                        />

                                        <Column
                                            header="Actions"
                                            body={(row) => (
                                                <div className="flex gap-2 justify-content-center">
                                                    <Button
                                                        icon="pi pi-pencil"
                                                        text
                                                        onClick={() => openEditExperience(row)}
                                                    />
                                                    <Button
                                                        icon="pi pi-trash"
                                                        text
                                                        severity="danger"
                                                        onClick={() => handleDeleteExperience(row)}
                                                    />
                                                </div>
                                            )}
                                        />
                                    </DataTable>
                                </div>
                            )}
                        </SectionCardWithHeader>
                    )}

                    {/* TAB: Documents */}
                    {activeTab === 'documents' && (
                        <SectionCardWithHeader
                            title="Attachments"
                            subtitle={
                                isLoadingDocuments
                                    ? 'Loading documents...'
                                    : `${attachments.reduce((sum, att) => sum + att.files.length, 0)} files`
                            }
                        >
                            {isReadOnlyDocuments && (
                                <div className="mb-3 p-3 bg-blue-50 border-round">
                                    <i className="pi pi-info-circle text-blue-500 mr-2" />
                                    <span className="text-blue-700">
                                        Documents are under verification. You cannot upload or
                                        remove files at this stage.
                                    </span>
                                </div>
                            )}

                            {isLoadingDocuments ? (
                                <div className="flex align-items-center justify-content-center py-5">
                                    <ProgressSpinner style={{ width: '50px', height: '50px' }} />
                                    <span className="ml-3 text-500">Loading documents...</span>
                                </div>
                            ) : (
                                <AttachmentTable
                                    attachments={attachments}
                                    setAttachments={setAttachments}
                                    readOnly={isReadOnlyDocuments}
                                />
                            )}
                        </SectionCardWithHeader>
                    )}

                    {activeTab === 'bank' && (
                        <SectionCardWithHeader title="Bank Details">
                            <div className="sc-grid-2">
                                <div>
                                    <label htmlFor="bankName" className="block text-600 mb-1">
                                        Bank Name
                                    </label>
                                    <InputText
                                        value={formData.bankName}
                                        onChange={(e) =>
                                            handleInputChange('bankName', e.target.value)
                                        }
                                        disabled={!isEditing}
                                        className="w-full"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="accountNumber" className="block text-600 mb-1">
                                        Account Number
                                    </label>
                                    <InputText
                                        value={formData.accountNumber}
                                        onChange={(e) =>
                                            handleInputChange('accountNumber', e.target.value)
                                        }
                                        disabled={!isEditing}
                                        className="w-full"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="ifsc" className="block text-600 mb-1">
                                        IFSC Code
                                    </label>
                                    <InputText
                                        value={formData.ifsc}
                                        onChange={(e) => handleInputChange('ifsc', e.target.value)}
                                        disabled={!isEditing}
                                        className="w-full"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="branch" className="block text-600 mb-1">
                                        Branch
                                    </label>
                                    <InputText
                                        value={formData.branch}
                                        onChange={(e) =>
                                            handleInputChange('branch', e.target.value)
                                        }
                                        disabled={!isEditing}
                                        className="w-full"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="micr" className="block text-600 mb-1">
                                        MICR Code
                                    </label>
                                    <InputText
                                        value={formData.micr}
                                        onChange={(e) => handleInputChange('micr', e.target.value)}
                                        disabled={!isEditing}
                                        className="w-full"
                                    />
                                </div>

                                <div>
                                    <label htmlFor="accountType" className="block text-600 mb-1">
                                        Account Type
                                    </label>
                                    <InputText
                                        value={formData.accountType}
                                        onChange={(e) =>
                                            handleInputChange('accountType', e.target.value)
                                        }
                                        disabled={!isEditing}
                                        className="w-full"
                                    />
                                </div>
                            </div>
                        </SectionCardWithHeader>
                    )}
                </TabbedSectionCard>
            </PageContentCard>

            {/* Timeline Dialog */}
            <Dialog
                header={
                    <div className="flex align-items-center justify-content-between">
                        <h2 className="m-0 text-xl font-semibold">Timeline</h2>
                        <div className="flex gap-2 pr-4">
                            <Button
                                label="Workflow"
                                icon="pi pi-sitemap"
                                size="small"
                                severity={timelineView === 'workflow' ? 'primary' : 'secondary'}
                                outlined={timelineView !== 'workflow'}
                                onClick={() => handleTimelineViewChange('workflow')}
                            />
                            <Button
                                label="History"
                                icon="pi pi-clock"
                                size="small"
                                severity={timelineView === 'history' ? 'primary' : 'secondary'}
                                outlined={timelineView !== 'history'}
                                onClick={() => handleTimelineViewChange('history')}
                            />
                        </div>
                    </div>
                }
                headerClassName="border-bottom-2 surface-border pb-3"
                visible={showTimeline}
                style={{ width: '70vw', maxHeight: '80vh' }}
                modal
                draggable={false}
                onHide={() => {
                    setShowTimeline(false);
                    setTimelineView('workflow'); // Reset to default view when closing
                    setAuditEvents([]);
                }}
            >
                <div className="pt-5 pb-2 pl-1 pr-1">
                    {timelineView === 'workflow' ? (
                        <CustomTimeline events={timelineEvents} />
                    ) : isAuditLoading ? (
                        <div className="flex align-items-center justify-content-center py-6">
                            <ProgressSpinner />
                        </div>
                    ) : auditEvents.length === 0 ? (
                        <div className="text-center text-500 py-8">
                            <i className="pi pi-clock text-6xl mb-3" />
                            <p>No history found</p>
                        </div>
                    ) : (
                        <CustomTimeline events={auditEvents} isAudit />
                    )}
                </div>
            </Dialog>

            {/* Qualifications Dialog */}
            <Dialog
                headerClassName="border-bottom-2 surface-border pb-3"
                header={editingQualification ? 'Edit Qualification' : 'Add Qualification'}
                visible={showQualificationDialog}
                style={{ width: '70vw', maxHeight: '90vh' }}
                modal
                onHide={() => setShowQualificationDialog(false)}
                draggable={false}
            >
                <div className="mt-3 p-fluid">
                    {/* ==================== CORE QUALIFICATION DETAILS ==================== */}
                    <SectionCardWithHeader title="Core Details" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="qualificationType" className="font-semibold">
                                    Qualification Type <span className="text-red-500">*</span>
                                </label>
                                <InputText
                                    placeholder="e.g., ACADEMIC, CERTIFICATION"
                                    id="qualificationType"
                                    value={qualificationForm.qualificationType}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            qualificationType: e.target.value,
                                        }))
                                    }
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="educationLevel" className="font-semibold">
                                    Education Level
                                </label>
                                <Dropdown
                                    id="educationLevel"
                                    value={qualificationForm.educationLevel}
                                    options={[
                                        { label: '10th', value: '10th' },
                                        { label: '12th', value: '12th' },
                                        { label: 'Diploma', value: 'Diploma' },
                                        { label: 'Bachelor', value: 'Bachelor' },
                                        { label: 'Master', value: 'Master' },
                                        { label: 'PhD', value: 'PhD' },
                                    ]}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            educationLevel: e.value,
                                        }))
                                    }
                                    placeholder="Select Level"
                                />
                            </div>

                            <div className="field md:col-6">
                                <label htmlFor="courseName" className="font-semibold">
                                    Course Name <span className="text-red-500">*</span>
                                </label>
                                <InputText
                                    id="courseName"
                                    value={qualificationForm.courseName}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            courseName: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Bachelor of Technology"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="specialization" className="font-semibold">
                                    Specialization
                                </label>
                                <InputText
                                    id="specialization"
                                    value={qualificationForm.specialization}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            specialization: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Computer Science"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="majorField" className="font-semibold">
                                    Major Field
                                </label>
                                <InputText
                                    id="majorField"
                                    value={qualificationForm.majorField}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            majorField: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Software Engineering"
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== INSTITUTION CONTEXT ==================== */}
                    <SectionCardWithHeader title="Institution Details" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="institution" className="font-semibold">
                                    Institution
                                </label>
                                <InputText
                                    id="institution"
                                    value={qualificationForm.institution}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            institution: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., IIT Delhi"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="boardOrUniversity" className="font-semibold">
                                    Board / University
                                </label>
                                <InputText
                                    id="boardOrUniversity"
                                    value={qualificationForm.boardOrUniversity}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            boardOrUniversity: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Delhi University"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="issuingAuthority" className="font-semibold">
                                    Issuing Authority
                                </label>
                                <InputText
                                    id="issuingAuthority"
                                    value={qualificationForm.issuingAuthority}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            issuingAuthority: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., CBSE"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="country" className="font-semibold">
                                    Country
                                </label>
                                <InputText
                                    id="country"
                                    value={qualificationForm.country}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            country: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., India"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="modeOfStudy" className="font-semibold">
                                    Mode of Study
                                </label>
                                <Dropdown
                                    id="modeOfStudy"
                                    value={qualificationForm.modeOfStudy}
                                    options={[
                                        { label: 'Full-time', value: 'Full-time' },
                                        { label: 'Part-time', value: 'Part-time' },
                                        { label: 'Distance', value: 'Distance' },
                                        { label: 'Online', value: 'Online' },
                                    ]}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            modeOfStudy: e.value,
                                        }))
                                    }
                                    placeholder="Select Mode"
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== COMPLETION DETAILS ==================== */}
                    <SectionCardWithHeader title="Completion & Dates" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="yearOfCompletion" className="font-semibold">
                                    Year of Completion
                                </label>
                                <InputNumber
                                    id="yearOfCompletion"
                                    value={qualificationForm.yearOfCompletion}
                                    onValueChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            yearOfCompletion: e.value,
                                        }))
                                    }
                                    placeholder="e.g., 2024"
                                    useGrouping={false}
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="issueDate" className="font-semibold">
                                    Issue Date
                                </label>
                                <Calendar
                                    id="issueDate"
                                    value={
                                        qualificationForm.issueDate
                                            ? new Date(qualificationForm.issueDate)
                                            : null
                                    }
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            issueDate: e.value,
                                        }))
                                    }
                                    dateFormat="dd/mm/yy"
                                    showIcon
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="expiryDate" className="font-semibold">
                                    Expiry Date
                                </label>
                                <Calendar
                                    id="expiryDate"
                                    value={
                                        qualificationForm.expiryDate
                                            ? new Date(qualificationForm.expiryDate)
                                            : null
                                    }
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            expiryDate: e.value,
                                        }))
                                    }
                                    dateFormat="dd/mm/yy"
                                    showIcon
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="completionStatus" className="font-semibold">
                                    Completion Status
                                </label>
                                <Dropdown
                                    id="completionStatus"
                                    value={qualificationForm.completionStatus}
                                    options={[
                                        { label: 'Completed', value: 'Completed' },
                                        { label: 'Pursuing', value: 'Pursuing' },
                                        { label: 'Discontinued', value: 'Discontinued' },
                                    ]}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            completionStatus: e.value,
                                        }))
                                    }
                                    placeholder="Select Status"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="durationInMonths" className="font-semibold">
                                    Duration (Months)
                                </label>
                                <InputNumber
                                    id="durationInMonths"
                                    value={qualificationForm.durationInMonths}
                                    onValueChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            durationInMonths: e.value,
                                        }))
                                    }
                                    placeholder="e.g., 48"
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== RESULTS ==================== */}
                    <SectionCardWithHeader title="Results & Performance" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="gradeOrPercentage" className="font-semibold">
                                    Grade / Percentage
                                </label>
                                <InputText
                                    id="gradeOrPercentage"
                                    value={qualificationForm.gradeOrPercentage}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            gradeOrPercentage: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Distinction, 85%"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="resultClassification" className="font-semibold">
                                    Result Classification
                                </label>
                                <Dropdown
                                    id="resultClassification"
                                    value={qualificationForm.resultClassification}
                                    options={[
                                        { label: 'First Class', value: 'First Class' },
                                        { label: 'Distinction', value: 'Distinction' },
                                        { label: 'Pass', value: 'Pass' },
                                    ]}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            resultClassification: e.value,
                                        }))
                                    }
                                    placeholder="Select Classification"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="percentageNumeric" className="font-semibold">
                                    Percentage (Numeric)
                                </label>
                                <InputNumber
                                    id="percentageNumeric"
                                    value={qualificationForm.percentageNumeric}
                                    onValueChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            percentageNumeric: e.value,
                                        }))
                                    }
                                    minFractionDigits={2}
                                    suffix="%"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="cgpa" className="font-semibold">
                                    CGPA
                                </label>
                                <InputNumber
                                    id="cgpa"
                                    value={qualificationForm.cgpa}
                                    onValueChange={(e) =>
                                        setQualificationForm((prev) => ({ ...prev, cgpa: e.value }))
                                    }
                                    max={10}
                                    minFractionDigits={2}
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== CREDENTIAL IDENTITY ==================== */}
                    <SectionCardWithHeader title="Credential Information" className="mb-4 ">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="certificateNumber" className="font-semibold">
                                    Certificate Number
                                </label>
                                <InputText
                                    id="certificateNumber"
                                    value={qualificationForm.certificateNumber}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            certificateNumber: e.target.value,
                                        }))
                                    }
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="registrationNumber" className="font-semibold">
                                    Registration Number
                                </label>
                                <InputText
                                    id="registrationNumber"
                                    value={qualificationForm.registrationNumber}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            registrationNumber: e.target.value,
                                        }))
                                    }
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== DECLARATION FLAGS ==================== */}
                    <SectionCardWithHeader title="Declaration" className="mb-0">
                        <div className="grid p-fluid">
                            <div className="field-checkbox col-12 md:col-6">
                                <Checkbox
                                    inputId="isDeclaredByCandidate"
                                    checked={qualificationForm.isDeclaredByCandidate}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            isDeclaredByCandidate: e.checked,
                                        }))
                                    }
                                />
                                <label htmlFor="isDeclaredByCandidate">Declared by Candidate</label>
                            </div>

                            <div className="field-checkbox  col-12 md:col-6">
                                <Checkbox
                                    inputId="isSelfAttested"
                                    checked={qualificationForm.isSelfAttested}
                                    onChange={(e) =>
                                        setQualificationForm((prev) => ({
                                            ...prev,
                                            isSelfAttested: e.checked,
                                        }))
                                    }
                                />
                                <label htmlFor="isSelfAttested">Self Attested</label>
                            </div>
                        </div>
                    </SectionCardWithHeader>
                </div>

                {/* Footer Actions */}
                <div className="flex justify-content-end mt-4 gap-2">
                    <Button
                        label="Cancel"
                        outlined
                        onClick={() => setShowQualificationDialog(false)}
                        disabled={isCreatingQualification || isUpdatingQualification}
                    />
                    <Button
                        label="Save"
                        icon="pi pi-save"
                        onClick={handleSaveQualification}
                        loading={isCreatingQualification || isUpdatingQualification}
                        disabled={isCreatingQualification || isUpdatingQualification}
                    />
                </div>
            </Dialog>

            {/* ── NEW ── Past Experience Dialog */}
            <Dialog
                headerClassName="border-bottom-2 surface-border pb-3"
                header={editingExperience ? 'Edit Past Experience' : 'Add Past Experience'}
                visible={showExperienceDialog}
                style={{ width: '70vw', maxHeight: '90vh' }}
                modal
                onHide={() => setShowExperienceDialog(false)}
                draggable={false}
            >
                <div className="mt-3 p-fluid">
                    {/* ==================== CORE EXPERIENCE DETAILS ==================== */}
                    <SectionCardWithHeader title="Core Experience Details" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="companyName" className="font-semibold">
                                    Company Name <span className="text-red-500">*</span>
                                </label>
                                <InputText
                                    id="companyName"
                                    value={experienceForm.companyName}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            companyName: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Tech Corp Ltd"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="designation" className="font-semibold">
                                    Designation <span className="text-red-500">*</span>
                                </label>
                                <InputText
                                    id="designation"
                                    value={experienceForm.designation}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            designation: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Software Engineer"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="employmentType" className="font-semibold">
                                    Employment Type
                                </label>
                                <Dropdown
                                    id="employmentType"
                                    value={experienceForm.employmentType}
                                    options={[
                                        { label: 'Full-time', value: 'Full-time' },
                                        { label: 'Part-time', value: 'Part-time' },
                                        { label: 'Contract', value: 'Contract' },
                                        { label: 'Internship', value: 'Internship' },
                                    ]}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            employmentType: e.value,
                                        }))
                                    }
                                    placeholder="Select Employment Type"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="employeeCode" className="font-semibold">
                                    Employee Code
                                </label>
                                <InputText
                                    id="employeeCode"
                                    value={experienceForm.employeeCode}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            employeeCode: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., EMP-12345"
                                />
                            </div>

                            <div className="field col-12">
                                <label htmlFor="responsibilities" className="font-semibold">
                                    Responsibilities
                                </label>
                                <InputTextarea
                                    id="responsibilities"
                                    value={experienceForm.responsibilities}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            responsibilities: e.target.value,
                                        }))
                                    }
                                    rows={3}
                                    placeholder="Briefly describe your key roles, projects, and achievements..."
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== TENURE & DATES ==================== */}
                    <SectionCardWithHeader title="Tenure & Dates" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="startDate" className="font-semibold">
                                    Start Date
                                </label>
                                <Calendar
                                    id="startDate"
                                    value={
                                        experienceForm.startDate
                                            ? new Date(experienceForm.startDate)
                                            : null
                                    }
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            startDate: e.value,
                                        }))
                                    }
                                    dateFormat="dd/mm/yy"
                                    showIcon
                                    placeholder="Select start date"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="endDate" className="font-semibold">
                                    End Date
                                </label>
                                <Calendar
                                    id="endDate"
                                    value={
                                        experienceForm.endDate
                                            ? new Date(experienceForm.endDate)
                                            : null
                                    }
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({ ...prev, endDate: e.value }))
                                    }
                                    dateFormat="dd/mm/yy"
                                    showIcon
                                    disabled={experienceForm.isCurrent}
                                    placeholder="Select end date"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="durationInMonths" className="font-semibold">
                                    Duration (Months)
                                </label>
                                <InputNumber
                                    id="durationInMonths"
                                    value={experienceForm.durationInMonths}
                                    onValueChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            durationInMonths: e.value,
                                        }))
                                    }
                                    placeholder="e.g., 24"
                                />
                            </div>

                            <div className="field col-12 md:col-6 flex align-items-center">
                                <Checkbox
                                    inputId="isCurrent"
                                    checked={experienceForm.isCurrent}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            isCurrent: e.checked,
                                            endDate: e.checked ? null : prev.endDate,
                                        }))
                                    }
                                />
                                <label htmlFor="isCurrent" className="ml-2 font-semibold">
                                    Currently Working Here
                                </label>
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== CONTACT & REPORTING ==================== */}
                    <SectionCardWithHeader title="Reporting & Contact Information" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="reportingManagerName" className="font-semibold">
                                    Reporting Manager Name
                                </label>
                                <InputText
                                    id="reportingManagerName"
                                    value={experienceForm.reportingManagerName}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            reportingManagerName: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., John Doe"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="reportingManagerEmail" className="font-semibold">
                                    Reporting Manager Email
                                </label>
                                <InputText
                                    id="reportingManagerEmail"
                                    value={experienceForm.reportingManagerEmail}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            reportingManagerEmail: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., manager@company.com"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="hrContactEmail" className="font-semibold">
                                    HR Contact Email
                                </label>
                                <InputText
                                    id="hrContactEmail"
                                    value={experienceForm.hrContactEmail}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            hrContactEmail: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., hr-verify@company.com"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="hrContactPhone" className="font-semibold">
                                    HR Contact Phone
                                </label>
                                <InputText
                                    id="hrContactPhone"
                                    value={experienceForm.hrContactPhone}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            hrContactPhone: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., +1 234 567 890"
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== PROOF & VERIFICATION ==================== */}
                    <SectionCardWithHeader title="Proof & Verification" className="mb-4">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label
                                    htmlFor="experienceCertificateNumber"
                                    className="font-semibold"
                                >
                                    Exp. Certificate No.
                                </label>
                                <InputText
                                    id="experienceCertificateNumber"
                                    value={experienceForm.experienceCertificateNumber}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            experienceCertificateNumber: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., CERT-778899"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="offerLetterNumber" className="font-semibold">
                                    Offer Letter Number
                                </label>
                                <InputText
                                    id="offerLetterNumber"
                                    value={experienceForm.offerLetterNumber}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            offerLetterNumber: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., OFF-4455"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="verificationSource" className="font-semibold">
                                    Verification Source
                                </label>
                                <InputText
                                    id="verificationSource"
                                    value={experienceForm.verificationSource}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            verificationSource: e.target.value,
                                        }))
                                    }
                                    placeholder="e.g., Third-party agency, HR Portal"
                                />
                            </div>

                            <div className="field col-12 md:col-6 flex align-items-center">
                                <Checkbox
                                    inputId="isVerified"
                                    checked={experienceForm.isVerified}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            isVerified: e.checked,
                                        }))
                                    }
                                />
                                <label htmlFor="isVerified" className="ml-2 font-semibold">
                                    Verified Record
                                </label>
                            </div>
                        </div>
                    </SectionCardWithHeader>

                    {/* ==================== COMPENSATION ==================== */}
                    <SectionCardWithHeader title="Compensation" className="mb-0">
                        <div className="grid formgrid p-fluid">
                            <div className="field col-12 md:col-6">
                                <label htmlFor="lastDrawnSalary" className="font-semibold">
                                    Last Drawn Salary
                                </label>
                                <InputNumber
                                    id="lastDrawnSalary"
                                    value={experienceForm.lastDrawnSalary}
                                    onValueChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            lastDrawnSalary: e.value,
                                        }))
                                    }
                                    mode="decimal"
                                    minFractionDigits={2}
                                    placeholder="e.g., 85000.00"
                                />
                            </div>

                            <div className="field col-12 md:col-6">
                                <label htmlFor="currency" className="font-semibold">
                                    Currency
                                </label>
                                <Dropdown
                                    id="currency"
                                    value={experienceForm.currency}
                                    options={[
                                        { label: 'INR (₹)', value: 'INR' },
                                        { label: 'USD ($)', value: 'USD' },
                                    ]}
                                    onChange={(e) =>
                                        setExperienceForm((prev) => ({
                                            ...prev,
                                            currency: e.value,
                                        }))
                                    }
                                    placeholder="Select Currency"
                                />
                            </div>
                        </div>
                    </SectionCardWithHeader>
                </div>

                {/* Footer Actions */}
                <div className="flex justify-content-end mt-4 gap-2">
                    <Button
                        label="Cancel"
                        outlined
                        onClick={() => setShowExperienceDialog(false)}
                        disabled={isCreatingExperience || isUpdatingExperience}
                    />
                    <Button
                        label="Save"
                        icon="pi pi-save"
                        onClick={handleSaveExperience}
                        loading={isCreatingExperience || isUpdatingExperience}
                        disabled={isCreatingExperience || isUpdatingExperience}
                    />
                </div>
            </Dialog>
        </div>
    );
};

export default EmployeeDetailedView;
