// EmployeeListView.jsx
import React, { useState } from 'react';
import { useNavigate } from 'react-router';
import { Card } from 'primereact/card';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { BreadCrumb } from 'primereact/breadcrumb';
import SearchCard from '@shared/components/SearchCard';
import { useEmployeeList } from '../hooks/employees/useEmployeeList';
import { Tag } from 'primereact/tag';

import { PASTEL_COLORS } from '../utils/colours';
import { getStatusColor } from '../utils/statusColours';

// Helper to generate initials from name
const getInitials = (name) => {
    if (!name) return '??';
    const parts = name.trim().split(' ');
    if (parts.length >= 2) {
        return (parts[0][0] + parts[1][0]).toUpperCase();
    }
    return name.substring(0, 2).toUpperCase();
};

// Avatar component (circular with initials)
const EmployeeAvatar = ({ name }) => {
    const initials = getInitials(name);
    const colorIndex =
        name?.split('').reduce((acc, c) => acc + c.charCodeAt(0), 0) % PASTEL_COLORS.length;
    const bgColor = PASTEL_COLORS[colorIndex];

    return (
        <div className="flex align-items-center gap-3">
            <div
                className="w-2rem h-2rem border-circle flex align-items-center justify-content-center text-black-alpha-50 font-bold text-sm"
                style={{ backgroundColor: bgColor }}
            >
                {initials}
            </div>
            <span>{name || 'N/A'}</span>
        </div>
    );
};

const EmployeeListView = () => {
    const navigate = useNavigate();

    // Pagination state
    const [page, setPage] = useState(0);
    const [rowsPerPage, setRowsPerPage] = useState(10);
    const [sortField, setSortField] = useState('employee'); // ✅ Changed from 'createdAt'
    const [sortOrder, setSortOrder] = useState('asc'); // ✅ Changed to 'asc'

    // Fetch employees with pagination
    const {
        data: employeeData,
        isLoading,
        isError,
        error,
        refetch,
    } = useEmployeeList({
        page,
        size: rowsPerPage,
        sortField,
        sortOrder,
    });

    // Extract employees and pagination info
    const employees = employeeData?.content || [];
    const totalRecords = employeeData?.totalElements || 0;

    const handleRowClick = (rowData) => {
        navigate('/web/landing/hrms/employee-details', {
            state: { employeeId: rowData.id },
        });
    };

    // Handle pagination changes
    const onPage = (event) => {
        setPage(event.page);
        setRowsPerPage(event.rows);
    };

    // Handle sorting changes
    const onSort = (event) => {
        // PrimeReact DataTable sends sortField and sortOrder (1 for asc, -1 for desc)
        let backendField;

        switch (event.sortField) {
            case 'name':
                backendField = 'firstName';
                break;
            case 'employeeId':
                backendField = 'employee';
                break;
            case 'email':
                backendField = 'companyEmail';
                break;
            default:
                backendField = event.sortField;
        }

        setSortField(backendField);
        setSortOrder(event.sortOrder === 1 ? 'asc' : 'desc');
    };

    // Breadcrumb items
    const breadcrumbItems = [
        {
            label: 'HRMS',
            command: () => navigate('/web/landing/hrms'),
        },
        {
            label: 'Employees',
        },
    ];

    const home = {
        icon: 'pi pi-home',
        command: () => navigate('/'),
    };

    const searchFilters = [
        { type: 'InputText', label: 'Name', name: 'name', placeholder: 'Enter name' },
        {
            type: 'InputText',
            label: 'Employee ID',
            name: 'employee',
            placeholder: 'Enter employee ID',
        },
        {
            type: 'InputText',
            label: 'Department',
            name: 'department',
            placeholder: 'Enter department',
        },
        {
            type: 'InputText',
            label: 'Designation',
            name: 'designation',
            placeholder: 'Enter designation',
        },
        {
            type: 'Dropdown',
            label: 'Status',
            name: 'status',
            placeholder: 'Select status',
            options: [
                { label: 'All', value: '' },
                { label: 'Active', value: 'Active' },
                { label: 'Inactive', value: 'Inactive' },
                { label: 'On Leave', value: 'On Leave' },
                { label: 'Terminated', value: 'Terminated' },
            ],
        },
    ];

    const handleSearch = (values) => {
        console.log('Search values:', values);
        // Reset to first page when searching
        setPage(0);
        // Later: implement search with backend filters
        // You'll need to pass search params to useEmployeeList
    };

    const handleClear = () => {
        console.log('Clear search');
        setPage(0);
        refetch();
    };

    const handleDownload = () => {
        console.log('Download employees:', employees);
        // Implement CSV export later
    };

    const handleAddEmployee = () => {
        navigate('/web/landing/hrms/employee-create');
    };

    // Status badge styling
    const statusBodyTemplate = (row) => {
        const rawStatus = row.status;
        if (!rawStatus) {
            return (
                <Tag
                    value="Unknown"
                    rounded
                    style={{ backgroundColor: '#E2E8F0', color: '#475569' }}
                    className="text-sm font-bold px-2 py-1"
                />
            );
        }

        const { bg, text } = getStatusColor(rawStatus);

        // Nice display name
        const labelMap = {
            ACTIVE: 'Active',
            Active: 'Active',
            INACTIVE: 'Inactive',
            Inactive: 'Inactive',
            ON_LEAVE: 'On Leave',
            'On Leave': 'On Leave',
            TERMINATED: 'Terminated',
            Terminated: 'Terminated',
            DOCUMENT_VERIFICATION: 'Document Verification',
            PENDING_EMPLOYEE_CREATED: 'Pending Employee Creation',
            EMPLOYEE_CREATED: 'Employee Created',
            REJECTED: 'Rejected',
            COMPLETED: 'Completed',
            CONVERTED: 'Converted',
        };

        const displayLabel =
            labelMap[rawStatus] ||
            rawStatus
                .split('_')
                .map((w) => w.charAt(0).toUpperCase() + w.slice(1).toLowerCase())
                .join(' ');

        return (
            <Tag
                value={displayLabel}
                rounded
                className="text-sm font-bold px-2 py-1"
                style={{
                    backgroundColor: bg,
                    color: text,
                    border: 'none',
                }}
            />
        );
    };

    return (
        <div className="surface-ground min-h-screen p-0">
            {/* Breadcrumb */}
            <div className="ml-0 mb-3">
                <BreadCrumb model={breadcrumbItems} home={home} />
            </div>

            {/* Search Card */}
            <SearchCard filters={searchFilters} onSubmit={handleSearch} onClear={handleClear} />

            {/* Data Table Card */}
            <Card className="mt-4">
                {/* Header */}
                <div className="ml-2 mb-3">
                    <h4 className="m-0 text-2xl font-semibold">Employees</h4>
                </div>

                {/* Horizontal Line */}
                <div className="border-top-1 surface-border mb-3" />

                <DataTable
                    value={employees}
                    stripedRows
                    lazy
                    paginator
                    first={page * rowsPerPage}
                    rows={rowsPerPage}
                    totalRecords={totalRecords}
                    onPage={onPage}
                    onSort={onSort}
                    sortField={sortField}
                    sortOrder={sortOrder === 'asc' ? 1 : -1}
                    rowsPerPageOptions={[10, 25, 50, 100]}
                    paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink CurrentPageReport RowsPerPageDropdown"
                    currentPageReportTemplate="Showing {first} to {last} of {totalRecords} employees"
                    rowHover
                    onRowClick={(e) => {
                        console.log('Row clicked:', e.data);
                        handleRowClick(e.data);
                    }}
                    loading={isLoading}
                    emptyMessage={isError ? `Error: ${error?.message}` : 'No employees found'}
                >
                    <Column field="employeeId" header="Employee ID" sortable />
                    <Column
                        field="name"
                        header="Name"
                        sortable
                        body={(rowData) => <EmployeeAvatar name={rowData.name} />}
                    />
                    <Column field="department" header="Department" sortable />
                    <Column field="designation" header="Designation" sortable />
                    <Column field="email" header="Email" sortable />
                    <Column field="contactNumber" header="Contact" sortable />
                    <Column field="joiningDate" header="Joining Date" sortable />
                    <Column field="status" header="Status" sortable body={statusBodyTemplate} />
                </DataTable>
            </Card>
        </div>
    );
};

export default EmployeeListView;
