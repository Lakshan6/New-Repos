// src/hrms/hooks/useGetTenantIds.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';
import { useEffect, useState } from 'react';

/**
 * Hook to fetch all available Tenant IDs from the MDMS service
 */
export const useGetTenantIds = () => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const [tenants, setTenants] = useState([]);

    const { mutateAsync, isPending, isError, error } = useMutationApi({
        service: 'mdms',
        endpoint: '/tenant/_fetchAll',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    const fetchTenants = async () => {
        const requestInfo = getReqInfoObj();
        try {
            const response = await mutateAsync({ ...requestInfo });
            console.log('raw response:', response); // confirm the shape

            // The API returns a plain array, not wrapped in an object
            const list = Array.isArray(response)
                ? response
                : response?.tenants || response?.data || [];

            setTenants(list);
        } catch (err) {
            console.error('Failed to fetch tenants:', err);
        }
    };

    // Auto-fetch on mount
    useEffect(() => {
        fetchTenants();
    }, []);

    return {
        tenants,
        isLoading: isPending,
        isError,
        error,
        refresh: fetchTenants,
    };
};
