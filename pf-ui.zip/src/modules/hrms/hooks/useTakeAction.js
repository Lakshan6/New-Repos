// src/hooks/workflow/useTakeAction.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to perform an action on a workflow instance (approve, verify, reject, etc.)
 */
export const useTakeAction = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'workflow',
        endpoint: '/wf/process/_take_action',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Perform an action on workflow instance
     *
     * @param {Object} params
     * @param {string} params.wfInstanceId
     * @param {string} params.action
     * @param {string} [params.assignee] - User UUID
     * @param {string} [params.assigneeTenantId]
     * @param {string} [params.documentAccessStrategy]
     * @param {string[]} [params.documents]
     */
    const takeAction = async ({
        wfInstanceId,
        action,
        assignee,
        assigneeTenantId,
        documentAccessStrategy = 'ALL_ROLES_IN_PROCESS',
        documents = [],
    }) => {
        if (!wfInstanceId) {
            throw new Error('Workflow instance ID is required');
        }
        if (!action) {
            throw new Error('Action is required');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            wfInstanceDto: {
                wfInstanceId,
                action,
                documentAccessStrategy,

                ...(assignee && { assignee }),
                ...(assigneeTenantId && { assigneeTenantId }),
                ...(documents?.length > 0 && { documents }),
            },
        };

        return await mutateAsync(requestBody);
    };

    return {
        takeAction,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};
