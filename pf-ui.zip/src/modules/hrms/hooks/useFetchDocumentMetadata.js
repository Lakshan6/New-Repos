// src/hooks/useFetchDocumentMetadata.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to fetch document metadata by one or more fileStoreIds
 * Uses the bulk metadata endpoint that accepts filestoreIds array
 */
export const useFetchDocumentMetadata = () => {
    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms', // ← replace with actual service name (e.g. 'document', 'file', 'candidate')
        endpoint: '/api/documents/get-documents', // ← your real endpoint path
        useGateway: true, // ← keep same as your other hooks
        method: 'POST', // explicit, though useMutationApi might default to POST
        headers: {
            // Authorization is likely handled inside useMutationApi or via interceptor
            // If you need to force it:
            // Authorization: `Bearer ${localStorage.getItem('authToken') ?? ''}`,
        },
    });

    /**
     * Fetch document metadata for one or more fileStoreIds
     *
     * @param {Object} params
     * @param {string} [params.filestoreId] - single file store ID (fallback)
     * @param {string[]} [params.filestoreIds] - preferred: array of file store IDs
     * @returns {Promise<DocumentMetadata[]>} Array of document metadata objects
     * @throws {Error} If no IDs provided or request fails
     */
    const fetchDocumentMetadata = async ({ filestoreId, filestoreIds = [] }) => {
        // Determine final list of IDs (array always wins)
        let targetIds = filestoreIds;

        if (!targetIds?.length && filestoreId) {
            targetIds = [filestoreId];
        }

        if (!targetIds?.length) {
            throw new Error('At least one filestoreId or non-empty filestoreIds must be provided');
        }

        // Build payload matching your Postman example
        const requestInfo = getReqInfoObj(); // ← reuses your shared utility

        const requestBody = {
            ...requestInfo,
            filestoreIds: targetIds, // always send as array
            // filestoreId: filestoreId, // ← optional, only if backend strictly needs it
        };

        try {
            const response = await mutateAsync(requestBody);
            // Assuming the API returns the array directly
            return response?.data || response || [];
        } catch (err) {
            console.error('Failed to fetch document metadata:', err);
            throw err; // let caller handle (e.g. show toast)
        }
    };

    return {
        fetchDocumentMetadata, // main async function to call
        isPending,
        isError,
        error,
        data, // last successful response (if you need it)
        reset,
    };
};
