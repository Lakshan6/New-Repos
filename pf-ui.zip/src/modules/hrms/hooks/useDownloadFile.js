// src/hooks/useDownloadFile.js
import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

export const useDownloadFile = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending } = useMutationApi({
        service: 'filestore', // gateway-mapped service
        endpoint: '/files/download', // backend endpoint
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        responseType: 'blob', // IMPORTANT
    });

    const downloadFile = useCallback(
        async (fileStoreId, fileName) => {
            if (!fileStoreId) {
                throw new Error('fileStoreId is required');
            }

            const payload = {
                requestInfo: getReqInfoObj(),
                fileStoreId,
            };

            const blob = await mutateAsync(payload);

            // Create browser download
            const url = window.URL.createObjectURL(blob);
            const a = document.createElement('a');
            a.href = url;
            a.download = fileName || 'document';
            document.body.appendChild(a);
            a.click();

            a.remove();
            window.URL.revokeObjectURL(url);
        },
        [mutateAsync],
    );

    return {
        downloadFile,
        isPending,
    };
};
