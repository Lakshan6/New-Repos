import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Generic Audit Fetch Hook
 * @param {string} entityType - e.g. 'candidate-audit' | 'employee-audit'
 * @param {string} entityId - UUID
 */
export const useAuditEntityHistory = (entityType, entityId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/v1/audit-entities/fetch`,
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
            'X-Audit-Entity-Type': entityType,
        },
    });

    const fetchAuditHistory = async () => {
        if (!entityId) {
            throw new Error('Entity ID is required');
        }

        const payload = {
            ...requestInfo,
            id: entityId,
        };

        const response = await mutateAsync(payload);

        return response?.content || [];
    };

    return {
        fetchAuditHistory,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};
