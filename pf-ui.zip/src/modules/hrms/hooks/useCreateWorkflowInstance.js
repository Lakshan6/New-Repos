import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to create (open) a new workflow instance
 */
export const useCreateWorkflowInstance = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'workflow',
        endpoint: '/wf/process/_create',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Create a workflow instance
     *
     * @param {Object} params
     * @param {string} params.workFlowDef - Workflow definition ID
     * @param {string} [params.action="OPEN"] - Initial action (usually OPEN)
     * @param {string} [params.assignee] - Explicit assignee UUID (optional)
     * @param {string} [params.assigneeTenantId] - Tenant ID of assignee (optional)
     * @param {Object} [params.tenantRoleAndTenantMap] - Role → Tenant mapping (optional)
     *
     * @returns {Promise<Object>} Workflow instance response
     */
    const createWorkflowInstance = async ({
        workFlowDef = 'ONBOARDING_WF', //By default create an instance for onboarding
        action = 'OPEN',
        assignee,
        assigneeTenantId,
        tenantRoleAndTenantMap,
    }) => {
        if (!workFlowDef) {
            throw new Error('Workflow definition (workFlowDef) is required');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            wfInstanceDto: {
                workFlowDef,
                action,

                // Optional fields – included only if provided
                ...(assignee && { assignee }),
                ...(assigneeTenantId && { assigneeTenantId }),
                ...(tenantRoleAndTenantMap && {
                    tenantRoleAndTenantMap,
                }),
            },
        };

        const response = await mutateAsync(requestBody);
        return response;
    };

    return {
        createWorkflowInstance,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};
