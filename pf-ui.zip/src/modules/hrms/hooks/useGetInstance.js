// src/hooks/workflow/useGetInstance.js
import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to fetch workflow instance data
 */
export const useGetInstance = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'workflow',
        endpoint: '/wf/process/_search',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch workflow instance by UUID
     * @param {string} instanceUuid
     * @returns {Promise<any[]>} Workflow instance response
     */
    const fetchInstance = useCallback(
        async (instanceUuid) => {
            if (!instanceUuid) {
                throw new Error('Workflow instance UUID is required');
            }

            const requestInfo = getReqInfoObj();

            const requestBody = {
                ...requestInfo,
                wfSearchDto: {
                    instanceUuid,
                },
            };

            return await mutateAsync(requestBody);
        },
        [mutateAsync],
    );

    /**
     * Fetch current workflow state as string
     * @param {string} instanceUuid
     * @returns {Promise<string>} current state (e.g. "COMPLETED_ONBOARDING")
     */
    const fetchCurrentState = useCallback(
        async (instanceUuid) => {
            const response = await fetchInstance(instanceUuid);

            if (!Array.isArray(response) || response.length === 0) {
                throw new Error('Workflow instance not found');
            }

            return response[0]?.currentState?.state ?? '';
        },
        [fetchInstance],
    );

    return {
        fetchInstance,
        fetchCurrentState,
        isPending,
        isError,
        error,
        data,
    };
};
