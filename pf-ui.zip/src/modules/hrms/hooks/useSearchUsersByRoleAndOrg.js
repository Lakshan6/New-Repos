import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to search users by roleIds and orgIds (tenant/org)
 */
export const useSearchUsersByRoleAndOrg = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'user',
        endpoint: '/user/_search',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Search users
     *
     * @param {Object} params
     * @param {string[]} params.roleIds - Required role IDs
     * @param {string[]} [params.orgIds] - Optional org/tenant IDs
     *
     * @param {Object} [params.filters] - Optional user search filters
     * @param {string} [params.filters.uuid]
     * @param {string} [params.filters.firstName]
     * @param {string} [params.filters.middleName]
     * @param {string} [params.filters.lastName]
     * @param {string} [params.filters.phoneNo]
     * @param {string} [params.filters.altPhoneNo]
     * @param {string} [params.filters.emailId]
     * @param {string} [params.filters.username]
     *
     * @returns {Promise<UserSearchResponseDto[]>}
     */
    const searchUsers = async ({ roleIds, orgIds, filters = {} }) => {
        if (!roleIds || roleIds.length === 0) {
            throw new Error('roleIds are required to search users');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            requestInfo,

            // Optional filters (included only if present)
            ...(filters.uuid && { uuid: filters.uuid }),
            ...(filters.firstName && { firstName: filters.firstName }),
            ...(filters.middleName && { middleName: filters.middleName }),
            ...(filters.lastName && { lastName: filters.lastName }),
            ...(filters.phoneNo && { phoneNo: filters.phoneNo }),
            ...(filters.altPhoneNo && { altPhoneNo: filters.altPhoneNo }),
            ...(filters.emailId && { emailId: filters.emailId }),
            ...(filters.username && { username: filters.username }),

            // Core search constraints
            roleIds,
            ...(orgIds?.length > 0 && { orgIds }),
        };

        return await mutateAsync(requestBody);
    };

    return {
        searchUsers,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useSearchUsersByRoleAndOrg;
