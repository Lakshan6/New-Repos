// src/hooks/master/useLeavePolicyDetailList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeavePolicyDetailList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['leave-policy-details', 'list'],
    queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-policy-detail',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((detail) => ({
        id: detail.id,
        annualAllocation: detail.annualAllocation ?? 0,
        tenantId: detail.tenantId,
        tenantRole: detail.tenantRole,
        module: detail.module,
        validFrom: detail.validFrom,
        validUpto: detail.validUpto,
        leavePolicyId: detail.leavePolicy?.id || null,
        leavePolicyName: detail.leavePolicy?.policyName || '—',
        leaveTypeId: detail.leaveType?.id || null,
        leaveTypeName: detail.leaveType?.leaveTypeName || '—',
      }));
    },

  });
};

export default useLeavePolicyDetailList;