// src/hooks/hrms/useEmployeeFeedbackCriteria.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useEmployeeFeedbackCriteria = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['employee-feedback-criteria', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'employee-feedback-criteria',
        },
      }),

    select: (item) =>
      item
        ? {
            id: item.id,
            criteriaName: item.criteriaName || '',
            description: item.description || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!payload?.criteriaName?.trim()) {
        throw new Error('Criteria Name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            criteriaName: payload.criteriaName.trim(),
            description: payload.description?.trim() || null,
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'employee-feedback-criteria',
          'Content-Type': 'application/json',
        },
        body,
      });
    },

    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['employee-feedback-criteria', 'list'] });

      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['employee-feedback-criteria', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'employee-feedback-criteria',
        },
      });
    },

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['employee-feedback-criteria', 'list'] });
    },
  });

  // ── RETURN ─────────────────────────────────────────────────────────────
  return {
    employeeFeedbackCriteria: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createEmployeeFeedbackCriteria: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),

    updateEmployeeFeedbackCriteria: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),

    deleteEmployeeFeedbackCriteria: (delId) =>
      deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,

    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useEmployeeFeedbackCriteria;