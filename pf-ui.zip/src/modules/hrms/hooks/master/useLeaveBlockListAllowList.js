// src/hooks/master/useLeaveBlockListAllowList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeaveBlockListAllowList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['leave-block-list-allows', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-block-list-allow',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((allow) => ({
        id: allow.id,
        allowUser: allow.allowUser,
        tenantId: allow.tenantId,
        tenantRole: allow.tenantRole,
        module: allow.module,
        validFrom: allow.validFrom,
        validUpto: allow.validUpto,
        leaveBlockListId: allow.leaveBlockList?.id || null,
        leaveBlockListName: allow.leaveBlockList?.leaveBlockListName || '—',
      }));
    },

  });
};

export default useLeaveBlockListAllowList;