// src/hooks/master/useAppraisalTemplateList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useAppraisalTemplateList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['appraisal-templates', 'list'],
          queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'appraisal-template',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((template) => ({
        id: template.id,
        templateName: template.templateName,
        description: template.description || '',
        kraEvaluationMethod: template.kraEvaluationMethod || '',
        ratingCriteria: template.ratingCriteria || '',
        tenantId: template.tenantId,
        tenantRole: template.tenantRole,
        module: template.module,
        validFrom: template.validFrom,
        validUpto: template.validUpto,
      }));
    },

  });
};

export default useAppraisalTemplateList;