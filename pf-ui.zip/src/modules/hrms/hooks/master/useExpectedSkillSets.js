// src/hooks/master/useExpectedSkillSets.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

const useExpectedSkillSets = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') || '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['expected-skill-sets', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expected-skill-set',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            skillName: item.skillName || '',
            // ── KEY FIX: map skill relation object (not flat coreSkillId) ──
            skill: item.skill || null,
            module: item.module || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.skillName?.trim())
        throw new Error('Skill Name is required');
      if (!isUpdate && !payload?.skill?.id)
        throw new Error('Core Skill is required');
      if (!payload?.tenantId)
        throw new Error('Tenant is required');
      if (isUpdate && !payload?.id)
        throw new Error('ID is required for update');

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            skillName: payload.skillName.trim(),
            skill: { id: payload.skill.id },
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expected-skill-set',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['expected-skill-sets', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['expected-skill-sets', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expected-skill-set',
        },
      });
    },
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['expected-skill-sets', 'list'] }),
  });

  return {
    expectedSkillSet: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createExpectedSkillSet: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateExpectedSkillSet: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteExpectedSkillSet: (id) =>
      deleteMutation.mutateAsync(id),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useExpectedSkillSets;