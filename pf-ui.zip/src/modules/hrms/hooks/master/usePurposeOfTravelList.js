// src/hooks/master/usePurposeOfTravelList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const usePurposeOfTravelList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['purpose-of-travels', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'purpose-of-travel',
        },
      });
    },

    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((purpose) => ({
        id: purpose.id,             // original ID
        purposeId: purpose.id,       // also map as purposeId for detail page
        purposeName: purpose.purposeName,
        description: purpose.description ?? '',
        tenantId: purpose.tenantId,
        tenantRole: purpose.tenantRole,
        module: purpose.module,
        validFrom: purpose.validFrom,
        validUpto: purpose.validUpto,
      }));
    },
  });
};

export default usePurposeOfTravelList;