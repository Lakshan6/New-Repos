// src/hooks/master/useOfferTermList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useOfferTermList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['offer-terms', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'offer-term',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((term) => ({
        id: term.id,
        offerTermName: term.offerTermName,
        label: term.label || '—',
        fieldtype: term.fieldtype || '—',
        fieldname: term.fieldname || '—',
        tenantId: term.tenantId,
        tenantRole: term.tenantRole,
        module: term.module,
        validFrom: term.validFrom,
        validUpto: term.validUpto,
        jobOfferTermTemplateId: term.jobOfferTermTemplate?.id || null,
        jobOfferTermTemplateName: term.jobOfferTermTemplate?.templateName || '—',
      }));
    },
  
  });
};

export default useOfferTermList;