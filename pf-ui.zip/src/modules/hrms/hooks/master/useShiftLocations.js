// src/hooks/master/useShiftLocations.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useShiftLocations = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL only ────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['shiftLocations', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-location',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            locationName: item.locationName || '',
            address: item.address || '',
            latitude: item.latitude ?? null,
            longitude: item.longitude ?? null,
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ───────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.locationName?.trim()) {
        throw new Error('Location name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('Location ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            locationName: payload.locationName.trim(),
            address: payload.address?.trim() || null,
            latitude: payload.latitude ?? null,
            longitude: payload.longitude ?? null,
            module: payload.module?.trim() || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
            tenantId: payload.tenantId || null,       // ← included
            tenantRole: payload.tenantRole || null,   // ← optional
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-location',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['shiftLocations', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['shiftLocations', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ──────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-location',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shiftLocations', 'list'] });
    },
  });

  return {
    location: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createLocation: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateLocation: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteLocation: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useShiftLocations;