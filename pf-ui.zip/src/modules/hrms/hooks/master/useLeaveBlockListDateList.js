// src/hooks/master/useLeaveBlockListDateList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeaveBlockListDateList = () => {
    const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['leave-block-list-dates', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-block-list-date',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((date) => ({
        id: date.id,
        blockDate: date.blockDate,
        reason: date.reason || '—',
        tenantId: date.tenantId,
        tenantRole: date.tenantRole,
        module: date.module,
        validFrom: date.validFrom,
        validUpto: date.validUpto,
        leaveBlockListId: date.leaveBlockList?.id || null,
        leaveBlockListName: date.leaveBlockList?.leaveBlockListName || '—',
      }));
    },
  });
};

export default useLeaveBlockListDateList;