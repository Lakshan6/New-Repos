
// src/hooks/master/useShiftTypeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useShiftTypeList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['shift-types', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-type',
        },
      });
    },

    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((shift) => ({
        id: shift.id,
        shiftName: shift.shiftName,
        startTime: shift.startTime,
        endTime: shift.endTime,
        enableAutoAttendance: shift.enableAutoAttendance ?? false,
        determineCheckInAndCheckOut:
          shift.determineCheckInAndCheckOut || '',
        tenantId: shift.tenantId,
        tenantRole: shift.tenantRole,
        module: shift.module,
        validFrom: shift.validFrom,
        validUpto: shift.validUpto,
      }));
    },
  });
};

export default useShiftTypeList;