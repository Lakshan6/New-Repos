
// src/hooks/master/useAppointmentLetterTemplateList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useAppointmentLetterTemplateList = () => {


  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['appointment-letter-templates', 'list'],
        queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'appointment-letter-template',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((template) => ({
        id: template.id,
        templateName: template.templateName,
        intro: template.intro || '',
        closingNotes: template.closingNotes || '',
        tenantId: template.tenantId,
        tenantRole: template.tenantRole,
        module: template.module,
        validFrom: template.validFrom,
        validUpto: template.validUpto,
      }));
    },

  });
};

export default useAppointmentLetterTemplateList;