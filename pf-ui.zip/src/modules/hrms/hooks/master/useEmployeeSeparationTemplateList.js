// src/hooks/master/useEmployeeSeparationTemplateList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useEmployeeSeparationTemplateList = () => {
       const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['employee-separation-templates', 'list'],
         queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'employee-separation-template',
                },
            });
        },

        select: (response) => {
            const rawList =
                response?.data ||
                response?.content ||
                (Array.isArray(response) ? response : []);

            if (!Array.isArray(rawList)) return [];

            return rawList.map((template) => ({
                id: template.id,
                templateName: template.templateName,
                tenantId: template.tenantId,
                tenantRole: template.tenantRole,
                module: template.module,
                validFrom: template.validFrom,
                validUpto: template.validUpto,
                revId: template.revId || null,
            }));
        },

    });
};

export default useEmployeeSeparationTemplateList;