// src/hooks/master/useHRSettings.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useHRSettings = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL QUERY ───────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['hr-settings', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'hr-settings',   // ← adjust if backend uses different entity name
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            sender: item.sender || '',
            hiringSender: item.hiringSender || '',
            leaveApprovalNotificationTemplate: item.leaveApprovalNotificationTemplate || '',
            leaveStatusNotificationTemplate: item.leaveStatusNotificationTemplate || '',
            feedbackReminderNotificationTemplate: item.feedbackReminderNotificationTemplate || '',
            interviewReminderTemplate: item.interviewReminderTemplate || '',
            exitQuestionnaireNotificationTemplate: item.exitQuestionnaireNotificationTemplate || '',
            roleAllowedToCreateBackdatedLeaveApplication:
              item.roleAllowedToCreateBackdatedLeaveApplication || '',
            exitQuestionnaireWebForm: item.exitQuestionnaireWebForm || '',
            autoLeaveEncashment: item.autoLeaveEncashment ?? false,
            restrictBackdatedLeaveApplication: item.restrictBackdatedLeaveApplication ?? false,
            emailSalarySlipToEmployee: item.emailSalarySlipToEmployee ?? false,
            encryptSalarySlipsInEmails: item.encryptSalarySlipsInEmails ?? false,
            passwordPolicy: item.passwordPolicy || '',
            stopBirthdayReminders: item.stopBirthdayReminders ?? false,
            sendHolidayReminders: item.sendHolidayReminders ?? false,
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE MUTATION ───────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      // Basic client-side validation
      if (!isUpdate && !payload?.sender?.trim()) {
        throw new Error('Default sender email is required for creation');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('HR Settings ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            sender: payload.sender?.trim() || '',
            hiringSender: payload.hiringSender?.trim() || '',
            leaveApprovalNotificationTemplate: payload.leaveApprovalNotificationTemplate?.trim() || '',
            leaveStatusNotificationTemplate: payload.leaveStatusNotificationTemplate?.trim() || '',
            feedbackReminderNotificationTemplate: payload.feedbackReminderNotificationTemplate?.trim() || '',
            interviewReminderTemplate: payload.interviewReminderTemplate?.trim() || '',
            exitQuestionnaireNotificationTemplate: payload.exitQuestionnaireNotificationTemplate?.trim() || '',
            roleAllowedToCreateBackdatedLeaveApplication:
              payload.roleAllowedToCreateBackdatedLeaveApplication?.trim() || '',
            exitQuestionnaireWebForm: payload.exitQuestionnaireWebForm?.trim() || '',
            autoLeaveEncashment: payload.autoLeaveEncashment ?? false,
            restrictBackdatedLeaveApplication: payload.restrictBackdatedLeaveApplication ?? false,
            emailSalarySlipToEmployee: payload.emailSalarySlipToEmployee ?? false,
            encryptSalarySlipsInEmails: payload.encryptSalarySlipsInEmails ?? false,
            passwordPolicy: payload.passwordPolicy?.trim() || '',
            stopBirthdayReminders: payload.stopBirthdayReminders ?? false,
            sendHolidayReminders: payload.sendHolidayReminders ?? false,
            tenantId: payload.tenantId || 'PRO_OR', // fallback like in skills
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'hr-settings',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['hr-settings', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['hr-settings', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE MUTATION ────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'hr-settings',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['hr-settings', 'list'] });
    },
  });

  return {
    settings: detailQuery.data,   // renamed from "skill" → "settings"
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createHRSettings: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateHRSettings: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteHRSettings: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useHRSettings;