// src/hooks/master/useExpenseClaimType.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useExpenseClaimType = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL only ───────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['expenseClaimTypes', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expense-claim-type',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            expenseTypeName: item.expenseTypeName || '',
            deferredExpenseAccount: item.deferredExpenseAccount || '',
            tenantId: item.tenantId || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.expenseTypeName?.trim()) {
        throw new Error('Expense Type Name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            expenseTypeName: payload.expenseTypeName.trim(),
            tenantId: payload.tenantId || 'PRO_OR',
            deferredExpenseAccount: payload.deferredExpenseAccount?.trim() || null,
            module: payload.module?.trim() || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expense-claim-type',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['expenseClaimTypes', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['expenseClaimTypes', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expense-claim-type',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expenseClaimTypes', 'list'] });
    },
  });

  return {
    claimType: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createClaimType: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateClaimType: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteClaimType: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useExpenseClaimType;