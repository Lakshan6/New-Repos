// src/hooks/master/useInterviewRounds.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useInterviewRounds = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ✅ DETAIL
  const detailQuery = useQuery({
    queryKey: ['interviewRounds', 'detail', id],
    enabled: !!id,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',   // ✅ FIXED
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo,
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'interview-round', // ✅ VERY IMPORTANT
        },
      }),

    select: (item) =>
      item
        ? {
            id: item.id,
            roundName: item.roundName || '',
            tenantId: item.tenantId || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ✅ CREATE / UPDATE
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!payload?.roundName?.trim()) {
        throw new Error('Round name is required');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            roundName: payload.roundName.trim(),
            tenantId: payload.tenantId || 'PRO_OR',
            module: payload.module || '',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',   // ✅ FIXED
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'interview-round', // ✅ MUST
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['interviewRounds', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['interviewRounds', 'detail', payload.id],
        });
      }
    },
  });

  // ✅ DELETE
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete', // ✅ FIXED
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo,
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'interview-round', // ✅ MUST
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['interviewRounds', 'list'] });
    },
  });

  return {
    interviewRound: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createInterviewRound: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),

    updateInterviewRound: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),

    deleteInterviewRound: (id) => deleteMutation.mutateAsync(id),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};