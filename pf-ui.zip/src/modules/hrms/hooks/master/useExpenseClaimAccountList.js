// src/hooks/master/useExpenseClaimAccountList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useExpenseClaimAccountList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['expense-claim-accounts', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'expense-claim-account',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((account) => ({
        id: account.id,
        defaultAccount: account.defaultAccount,
        tenantId: account.tenantId,
        tenantRole: account.tenantRole,
        module: account.module,
        validFrom: account.validFrom,
        validUpto: account.validUpto,
        expenseClaimTypeId: account.expenseClaimType?.id || null,
        expenseClaimTypeName: account.expenseClaimType?.expenseTypeName || '—',
      }));
    },

  });
};

export default useExpenseClaimAccountList;