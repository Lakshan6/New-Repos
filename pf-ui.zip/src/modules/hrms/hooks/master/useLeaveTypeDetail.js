// src/hooks/master/useLeaveTypeDetail.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeaveTypeDetail = (typeId, customHeaders = {}) => {
    const authToken = localStorage.getItem('authToken') ?? '';

    return useQuery({
        queryKey: ['leave-type', 'detail', typeId],
        enabled: !!typeId,

        queryFn: async () => {
            if (!typeId) return null;

            const response = await apiRequest({
                service: 'erp_hrms',
                endpoint: `/api/v1/entities/${typeId}`,
                method: 'GET',
                headers: {
                    'X-Entity-Type': 'leave-type',
                    Authorization: `Bearer ${authToken}`,
                    ...customHeaders,
                },
            });

            return response?.data ?? response;
        },

        select: (item) => {
            if (!item || String(item.id) !== String(typeId)) return null;

            return {
                id: item.id,
                leaveTypeName: item.leaveTypeName || '',
                maxLeavesAllowed: item.maxLeavesAllowed ?? 0,
                applicableAfter: item.applicableAfter ?? 0,
                maxContinuousDaysAllowed: item.maxContinuousDaysAllowed ?? 0,
                isCarryForward: item.isCarryForward ?? false,
                isEarnedLeave: item.isEarnedLeave ?? false,
                isLwp: item.isLwp ?? false,
                isOptionalLeave: item.isOptionalLeave ?? false,
                allowNegative: item.allowNegative ?? false,
                includeHoliday: item.includeHoliday ?? false,
                isCompensatory: item.isCompensatory ?? false,
                earningComponent: item.earningComponent || '',
                fractionOfDailySalaryPerLeave: item.fractionOfDailySalaryPerLeave ?? 0,
                encashmentThresholdDays: item.encashmentThresholdDays ?? 0,
                earnedLeaveFrequency: item.earnedLeaveFrequency || '',
                rounding: item.rounding || '',
                tenantId: item.tenantId || '',
                tenantRole: item.tenantRole || '',
                module: item.module || '',
                validFrom: item.validFrom ? new Date(item.validFrom) : null,
                validUpto: item.validUpto ? new Date(item.validUpto) : null,
            };
        },
    });
};

export default useLeaveTypeDetail;
