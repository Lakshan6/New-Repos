// src/hooks/master/useInterviewTypeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useInterviewTypeList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['interview-types', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'interview-type',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((type) => ({
        id: type.id,
        interviewTypeName: type.interviewTypeName,
        description: type.description || '',
        tenantId: type.tenantId,
        tenantRole: type.tenantRole,
        module: type.module,
        validFrom: type.validFrom,
        validUpto: type.validUpto,
      }));
    },

  });
};

export default useInterviewTypeList;