// src/hooks/master/useEmployeeGradeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useEmployeeGradeList = () => {
       const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['employee-grades', 'list'],
        queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'employee-grade',
                },
            });
        },

        select: (response) => {
            const rawList =
                response?.data ||
                response?.content ||
                (Array.isArray(response) ? response : []);

            if (!Array.isArray(rawList)) return [];

            return rawList.map((grade) => ({
                id: grade.id,
                gradeName: grade.gradeName,
                defaultSalaryStructure: grade.defaultSalaryStructure,
                defaultBasePay: grade.defaultBasePay,
                defaultCurrency: grade.defaultCurrency,
                tenantId: grade.tenantId,
                tenantRole: grade.tenantRole,
                module: grade.module,
                validFrom: grade.validFrom,
                validUpto: grade.validUpto,
            }));
        },

    });
};

export default useEmployeeGradeList;
