// src/hooks/master/useIdentificationDocumentTypeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useIdentificationDocumentTypeList = () => {
       const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['identification-document-types', 'list'],
  queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'identification-document-type',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((doc) => ({
        id: doc.id,
        documentTypeName: doc.documentTypeName,
        tenantId: doc.tenantId,
        tenantRole: doc.tenantRole,
        module: doc.module,
        validFrom: doc.validFrom,
        validUpto: doc.validUpto,
      }));
    },

  });
};

export default useIdentificationDocumentTypeList;