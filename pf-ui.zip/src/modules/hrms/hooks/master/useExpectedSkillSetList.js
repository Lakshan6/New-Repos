// src/hooks/master/useExpectedSkillSetList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useExpectedSkillSetList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['expected-skill-sets', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expected-skill-set',
        },
      });
    },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((skillSet) => ({
        id: skillSet.id,
        skillName: skillSet.skillName,
        tenantId: skillSet.tenantId,
        tenantRole: skillSet.tenantRole,
        module: skillSet.module,
        validFrom: skillSet.validFrom,
        validUpto: skillSet.validUpto,
        interviewRoundId: skillSet.interviewRound?.id || null,
        interviewRoundName: skillSet.interviewRound?.roundName || '—',
        skillId: skillSet.skill?.id || null,
        coreSkillName: skillSet.skill?.skillName || '—',
      }));
    },
  });
};

export default useExpectedSkillSetList;