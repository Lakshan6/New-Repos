// src/hooks/master/useShiftSchedules.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useShiftSchedules = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL only ───────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['shiftSchedules', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-schedule',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            scheduleName: item.scheduleName || '',
            startDate: item.startDate ? new Date(item.startDate) : null,
            endDate: item.endDate ? new Date(item.endDate) : null,
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
            shiftType: item.shiftType
              ? {
                  id: item.shiftType.id,
                  shiftName: item.shiftType.shiftName || '',
                }
              : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      // ── Basic validations ──
      if (!payload?.scheduleName?.trim()) {
        throw new Error('Schedule name is required');
      }
      if (!payload?.shiftType?.id) {
        throw new Error('Shift Type is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('Shift Schedule ID is required for update');
      }

      // ── Build request body ──
      const body = isUpdate
        ? payload
        : {
            requestInfo,
            scheduleName: payload.scheduleName.trim(),
            tenantId: payload.tenantId || 'PRO_OR',
            shiftType: { id: payload.shiftType.id }, // ← required
            startDate: payload.startDate || null,
            endDate: payload.endDate || null,
            module: payload.module?.trim() || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-schedule',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['shiftSchedules', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['shiftSchedules', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-schedule',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shiftSchedules', 'list'] });
    },
  });

  return {
    shiftSchedule: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createShiftSchedule: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateShiftSchedule: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteShiftSchedule: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useShiftSchedules;