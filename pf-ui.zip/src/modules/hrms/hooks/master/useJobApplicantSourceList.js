// src/hooks/master/useJobApplicantSourceList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useJobApplicantSourceList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['job-applicant-sources', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'job-applicant-source',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((source) => ({
        id: source.id,
        sourceName: source.sourceName,
        tenantId: source.tenantId,
        tenantRole: source.tenantRole,
        module: source.module,
        validFrom: source.validFrom,
        validUpto: source.validUpto,
      }));
    },

  });
};

export default useJobApplicantSourceList;