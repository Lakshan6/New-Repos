// src/hooks/master/useShiftTypes.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useShiftTypes = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL only ───────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['shiftTypes', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-type',   // ← changed entity type
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            shiftName: item.shiftName || '',
            startTime: item.startTime ? new Date(item.startTime) : null,
            endTime: item.endTime ? new Date(item.endTime) : null,
            enableAutoAttendance: item.enableAutoAttendance ?? false,
            determineCheckInAndCheckOut: item.determineCheckInAndCheckOut || '',
            beginCheckInBeforeShiftStartTime: Number(item.beginCheckInBeforeShiftStartTime) || 0,
            allowCheckOutAfterShiftEndTime: Number(item.allowCheckOutAfterShiftEndTime) || 0,
            workingHoursThresholdForAbsent: Number(item.workingHoursThresholdForAbsent) || 0,
            workingHoursThresholdForHalfDay: Number(item.workingHoursThresholdForHalfDay) || 0,
            enableEntryGracePeriod: item.enableEntryGracePeriod ?? false,
            lateEntryGracePeriod: Number(item.lateEntryGracePeriod) || 0,
            enableExitGracePeriod: item.enableExitGracePeriod ?? false,
            earlyExitGracePeriod: Number(item.earlyExitGracePeriod) || 0,
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.shiftName?.trim()) {
        throw new Error('Shift name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('Shift Type ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            shiftName: payload.shiftName.trim(),
            tenantId: payload.tenantId || 'PRO_OR',           // default tenant if needed
            startTime: payload.startTime || null,
            endTime: payload.endTime || null,
            enableAutoAttendance: payload.enableAutoAttendance ?? false,
            determineCheckInAndCheckOut: payload.determineCheckInAndCheckOut?.trim() || null,
            beginCheckInBeforeShiftStartTime: Number(payload.beginCheckInBeforeShiftStartTime) || 0,
            allowCheckOutAfterShiftEndTime: Number(payload.allowCheckOutAfterShiftEndTime) || 0,
            workingHoursThresholdForAbsent: Number(payload.workingHoursThresholdForAbsent) || 0,
            workingHoursThresholdForHalfDay: Number(payload.workingHoursThresholdForHalfDay) || 0,
            enableEntryGracePeriod: payload.enableEntryGracePeriod ?? false,
            lateEntryGracePeriod: Number(payload.lateEntryGracePeriod) || 0,
            enableExitGracePeriod: payload.enableExitGracePeriod ?? false,
            earlyExitGracePeriod: Number(payload.earlyExitGracePeriod) || 0,
            module: payload.module?.trim() || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-type',     // ← important: entity type
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['shiftTypes', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['shiftTypes', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-type',     // ← entity type
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['shiftTypes', 'list'] });
    },
  });

  return {
    shiftType: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createShiftType: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateShiftType: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteShiftType: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useShiftTypes;