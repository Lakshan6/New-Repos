// src/hooks/master/useOnboardingTemplate.js

import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useOnboardingTemplate = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ───────────────── FETCH DETAIL ─────────────────
  const detailQuery = useQuery({
    queryKey: ['onboardingTemplate', 'detail', id],
    enabled: !!id,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo,
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'employee-onboarding-template',
        },
      }),

    select: (item) =>
      item
        ? {
            id: item.id,
            templateName: item.templateName || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom || null,
            validUpto: item.validUpto || null,
            revId: item.revId || 1,
          }
        : null,
  });

  // ───────────────── CREATE / UPDATE ─────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {

      if (!payload?.templateName?.trim()) {
        throw new Error('Template Name is required');
      }

      if (isUpdate && !payload?.id) {
        throw new Error('ID required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            templateName: payload.templateName.trim(),
            tenantId: payload.tenantId || null,
            tenantRole: payload.tenantRole || null,
            module: payload.module?.trim() || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
            revId: payload.revId || 1,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'employee-onboarding-template',
          'Content-Type': 'application/json',
        },
        body,
      });
    },

    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['onboardingTemplate', 'list'] });

      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['onboardingTemplate', 'detail', payload.id],
        });
      }
    },
  });

  // ───────────────── DELETE ─────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {

      if (!delId) throw new Error('ID required for delete');

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'employee-onboarding-template',
        },
      });
    },

    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['onboardingTemplate', 'list'] }),
  });

  return {
    template: detailQuery.data,

    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createTemplate: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),

    updateTemplate: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),

    deleteTemplate: (id) =>
      deleteMutation.mutateAsync(id),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
  };
};

export default useOnboardingTemplate;