// src/hooks/master/useLeavePeriodList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeavePeriodList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['leave-periods', 'list'],
  queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-period',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((period) => ({
        id: period.id,
        periodName: period.periodName,
        fromDate: period.fromDate,
        toDate: period.toDate,
        isActive: period.isActive ?? false,
        tenantId: period.tenantId,
        tenantRole: period.tenantRole,
        module: period.module,
        validFrom: period.validFrom,
        validUpto: period.validUpto,
      }));
    },
  
  });
};

export default useLeavePeriodList;