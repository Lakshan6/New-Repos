// src/hooks/master/useAppointmentLetterTemplates.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useAppointmentLetterTemplates = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL only ───────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['appointmentLetterTemplates', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appointment-letter-template',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            templateName: item.templateName || '',
            intro: item.intro || '',
            closingNotes: item.closingNotes || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.templateName?.trim()) {
        throw new Error('Template name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('Template ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            templateName: payload.templateName.trim(),
            tenantId: payload.tenantId || 'PRO_OR', // default tenant if needed
            intro: payload.intro?.trim() || '',
            closingNotes: payload.closingNotes?.trim() || '',
            module: payload.module?.trim() || '',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appointment-letter-template',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['appointmentLetterTemplates', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['appointmentLetterTemplates', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appointment-letter-template',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appointmentLetterTemplates', 'list'] });
    },
  });

  return {
    template: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createTemplate: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateTemplate: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteTemplate: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useAppointmentLetterTemplates;