// src/hooks/hrms/useLeaveType.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useLeaveType = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['leave-type', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-type',
        },
      }),

    select: (item) =>
      item
        ? {
            id: item.id,
            leaveTypeName: item.leaveTypeName || '',
            maxLeavesAllowed: item.maxLeavesAllowed ?? 0,
            applicableAfter: item.applicableAfter ?? 0,
            maxContinuousDaysAllowed: item.maxContinuousDaysAllowed ?? 0,
            isCarryForward: item.isCarryForward ?? false,
            isEarnedLeave: item.isEarnedLeave ?? false,
            isLwp: item.isLwp ?? false,
            isOptionalLeave: item.isOptionalLeave ?? false,
            allowNegative: item.allowNegative ?? false,
            includeHoliday: item.includeHoliday ?? false,
            isCompensatory: item.isCompensatory ?? false,
            earningComponent: item.earningComponent || '',
            fractionOfDailySalaryPerLeave: item.fractionOfDailySalaryPerLeave ?? 0,
            encashmentThresholdDays: item.encashmentThresholdDays ?? 0,
            earnedLeaveFrequency: item.earnedLeaveFrequency || '',
            rounding: item.rounding || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!payload?.leaveTypeName?.trim()) {
        throw new Error('Leave Type Name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            leaveTypeName: payload.leaveTypeName.trim(),
            maxLeavesAllowed: payload.maxLeavesAllowed ?? 0,
            applicableAfter: payload.applicableAfter ?? 0,
            maxContinuousDaysAllowed: payload.maxContinuousDaysAllowed ?? 0,
            isCarryForward: payload.isCarryForward ?? false,
            isEarnedLeave: payload.isEarnedLeave ?? false,
            isLwp: payload.isLwp ?? false,
            isOptionalLeave: payload.isOptionalLeave ?? false,
            allowNegative: payload.allowNegative ?? false,
            includeHoliday: payload.includeHoliday ?? false,
            isCompensatory: payload.isCompensatory ?? false,
            earningComponent: payload.earningComponent?.trim() || null,
            fractionOfDailySalaryPerLeave: payload.fractionOfDailySalaryPerLeave ?? 0,
            encashmentThresholdDays: payload.encashmentThresholdDays ?? 0,
            earnedLeaveFrequency: payload.earnedLeaveFrequency?.trim() || null,
            rounding: payload.rounding?.trim() || null,
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-type',
          'Content-Type': 'application/json',
        },
        body,
      });
    },

    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['leave-type', 'list'] });

      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['leave-type', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-type',
        },
      });
    },

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leave-type', 'list'] });
    },
  });

  // ── RETURN ─────────────────────────────────────────────────────────────
  return {
    leaveType: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createLeaveType: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),

    updateLeaveType: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),

    deleteLeaveType: (delId) =>
      deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,

    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useLeaveType;