// src/hooks/master/useInterviewRoundList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useInterviewRoundList = () => {
       const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['interview-rounds', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'interview-round',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((round) => ({
        id: round.id,
        roundName: round.roundName,
        tenantId: round.tenantId,
        tenantRole: round.tenantRole,
        module: round.module,
        validFrom: round.validFrom,
        validUpto: round.validUpto,
      }));
    },

  });
};

export default useInterviewRoundList;