// src/hooks/master/useSkillList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useSkillList = () => {
    const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['skills', 'list'],
        queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'skill',
                },
            });
        },


    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((skill) => ({
        id: skill.id,
        skillName: skill.skillName,
        description: skill.description || '',
        tenantId: skill.tenantId,
        tenantRole: skill.tenantRole,
        module: skill.module,
        validFrom: skill.validFrom,
        validUpto: skill.validUpto,
      }));
    },
 
  });
};

export default useSkillList;