// src/hooks/useEmployeeFeedbackCriteriaList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

/**
 * Fetches the list of all employee feedback criteria
 */
export const useEmployeeFeedbackCriteriaList = () => {
     const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['employee-feedback-criteria', 'list'],

   queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'employee-feedback-criteria',
                },
            });
        },

        // Using the select transformation to format data and calculate status
        select: (response) => {
            /**
             * API Normalization:
             * Checks if data is in response.data, response.content (Spring Boot), 
             * or if the response itself is the array.
             */
            const rawList = response?.data || response?.content || (Array.isArray(response) ? response : []);

            if (!Array.isArray(rawList)) {
                console.warn('Feedback Criteria API did not return an array:', rawList);
                return [];
            }



                    

            return rawList.map((criteria) => {
                // Business Logic: Check if the criteria is expired based on current date
                const isExpired = criteria.validUpto && new Date(criteria.validUpto) < new Date();
                
                return {
                    id: criteria.id, // UUID string
                    criteriaName: criteria.criteriaName ,
                    description: criteria.description ,
           

                    
                    // Metadata and Validity
                    validFrom: criteria.validFrom,
                    validUpto: criteria.validUpto,

                };
            });
        },

    });
};

export default useEmployeeFeedbackCriteriaList;