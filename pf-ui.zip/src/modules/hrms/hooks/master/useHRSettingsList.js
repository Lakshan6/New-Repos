// src/hooks/master/useHRSettingsList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useHRSettingsList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['hr-settings', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'hr-settings',
        },
      });
    },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((setting) => ({
        id: setting.id,
        sender: setting.sender,
        hiringSender: setting.hiringSender,
        autoLeaveEncashment: setting.autoLeaveEncashment,
        emailSalarySlipToEmployee: setting.emailSalarySlipToEmployee,
        encryptSalarySlipsInEmails: setting.encryptSalarySlipsInEmails,
        passwordPolicy: setting.passwordPolicy,
        sendHolidayReminders: setting.sendHolidayReminders,
        tenantId: setting.tenantId,
        validFrom: setting.validFrom,
        validUpto: setting.validUpto,
      }));
    },
  });
};

export default useHRSettingsList;