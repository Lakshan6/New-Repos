// src/hooks/master/useEmploymentTypeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useEmploymentTypeList = () => {
    const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['employment-types', 'list'],
          queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'employment-type',
                },
            });
        },
        select: (response) => {
            const rawList =
                response?.data ||
                response?.content ||
                (Array.isArray(response) ? response : []);

            if (!Array.isArray(rawList)) return [];

            return rawList.map((type) => ({
                id: type.id,
                employeeTypeName: type.employeeTypeName,  // matches your JSON
                tenantId: type.tenantId,
                tenantRole: type.tenantRole,
                module: type.module,
                validFrom: type.validFrom,
                validUpto: type.validUpto,
                revId: type.revId || null,
            }));
        },

    });
};

export default useEmploymentTypeList;