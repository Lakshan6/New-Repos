// src/hooks/master/useShiftLocationList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useShiftLocationList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['shift-locations', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-location',
        },
      });
    },

    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((loc) => ({
        id: loc.id,
        locationName: loc.locationName,
        address: loc.address ?? '—',
        latitude: loc.latitude ?? null,
        longitude: loc.longitude ?? null,
        tenantId: loc.tenantId,
        tenantRole: loc.tenantRole,
        module: loc.module,
        validFrom: loc.validFrom,
        validUpto: loc.validUpto,
      }));
    },
  });
};

export default useShiftLocationList;