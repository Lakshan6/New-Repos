// src/hooks/master/useDesignationSkillList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useDesignationSkillList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['designation-skills', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'designation-skill',
        },
      });
    },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((item) => ({
        id: item.id,
        skillName: item.skillName,
        proficiency: item.proficiency || '—',
        tenantId: item.tenantId,
        tenantRole: item.tenantRole,
        module: item.module,
        validFrom: item.validFrom,
        validUpto: item.validUpto,
        skillId: item.skill?.id || null,
        coreSkillName: item.skill?.skillName || '—',
      }));
    },
  });
};

export default useDesignationSkillList;