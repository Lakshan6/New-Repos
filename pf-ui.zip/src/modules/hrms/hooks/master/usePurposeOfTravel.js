// src/hooks/master/usePurposeOfTravel.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const usePurposeOfTravel = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── FETCH DETAIL ───────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['purposeOfTravel', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo,
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'purpose-of-travel',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            purposeName: item.purposeName || '',
            description: item.description || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE / UPDATE ──────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.purposeName?.trim()) {
        throw new Error('Purpose Name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('ID required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            purposeName: payload.purposeName.trim(),
            description: payload.description?.trim() || null,
            tenantId: payload.tenantId || null,
            module: payload.module?.trim() || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'purpose-of-travel',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['purposeOfTravel', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['purposeOfTravel', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ─────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'purpose-of-travel',
        },
      });
    },
    onSuccess: () => queryClient.invalidateQueries({ queryKey: ['purposeOfTravel', 'list'] }),
  });

  return {
    purpose: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createPurpose: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updatePurpose: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deletePurpose: (id) => deleteMutation.mutateAsync(id),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default usePurposeOfTravel;