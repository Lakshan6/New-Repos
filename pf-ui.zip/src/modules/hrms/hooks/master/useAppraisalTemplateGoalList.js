// src/hooks/master/useAppraisalTemplateGoalList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useAppraisalTemplateGoalList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['appraisal-template-goals', 'list'],
      queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'appraisal-template-goal',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((goal) => ({
        id: goal.id,
        perWeightage: goal.perWeightage || 0,
        tenantId: goal.tenantId,
        tenantRole: goal.tenantRole,
        module: goal.module,
        validFrom: goal.validFrom,
        validUpto: goal.validUpto,
        appraisalTemplateId: goal.appraisalTemplate?.id || null,
        appraisalTemplateName: goal.appraisalTemplate?.templateName || '—',
        kraId: goal.kra?.id || null,
        kraName: goal.kra?.kraName || '—',
      }));
    },

  });
};

export default useAppraisalTemplateGoalList;