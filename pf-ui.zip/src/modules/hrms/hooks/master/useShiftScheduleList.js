// src/hooks/master/useShiftScheduleList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useShiftScheduleList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['shift-schedules', 'list'],
    queryFn: async () => {
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'shift-schedule',
        },
      });
    },

    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((schedule) => ({
        id: schedule.id,
        scheduleName: schedule.scheduleName,
        startDate: schedule.startDate,
        endDate: schedule.endDate,
        shiftTypeId: schedule.shiftType?.id ?? null,
        shiftTypeName: schedule.shiftType?.shiftName ?? '',
        tenantId: schedule.tenantId,
        tenantRole: schedule.tenantRole,
        module: schedule.module,
        validFrom: schedule.validFrom,
        validUpto: schedule.validUpto,
      }));
    },
  });
};

export default useShiftScheduleList;