// src/hooks/master/useAppraisalCycleList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useAppraisalCycleList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['appraisal-cycles', 'list'],
       queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'appraisal-cycle',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((cycle) => ({
        id: cycle.id,
        cycleName: cycle.cycleName,
        startDate: cycle.startDate,
        endDate: cycle.endDate,
        kraEvaluationMethod: cycle.kraEvaluationMethod,
        tenantId: cycle.tenantId,
        tenantRole: cycle.tenantRole,
        module: cycle.module,
        validFrom: cycle.validFrom,
        validUpto: cycle.validUpto,
      }));
    },

  });
};

export default useAppraisalCycleList;