// src/hooks/master/useAppointmentLetterContent.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useAppointmentLetterContent = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') || '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ───────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['appointmentLetterContent', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appointment-letter-content',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            title: item.title || '',
            description: item.description || '',
            module: item.module || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
            appointmentLetterTemplate: item.appointmentLetterTemplate || null,
          }
        : null,
  });

  // ── CREATE / UPDATE ──────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.title?.trim())
        throw new Error('Title is required');
      if (!isUpdate && !payload?.appointmentLetterTemplate?.id)
        throw new Error('Appointment Letter Template is required');
      if (isUpdate && !payload?.id)
        throw new Error('ID is required for update');

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            title: payload.title.trim(),
            description: payload.description?.trim() || null,
            appointmentLetterTemplate: { id: payload.appointmentLetterTemplate.id },
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            tenantRole: payload.tenantRole || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appointment-letter-content',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['appointmentLetterContent', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['appointmentLetterContent', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ───────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appointment-letter-content',
        },
      });
    },
    onSuccess: () =>
      queryClient.invalidateQueries({ queryKey: ['appointmentLetterContent', 'list'] }),
  });

  return {
    content: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createContent: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateContent: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteContent: (id) => deleteMutation.mutateAsync(id),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useAppointmentLetterContent;