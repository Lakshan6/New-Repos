// src/hooks/master/useLeaveControlPanel.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useLeaveControlPanel = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL only ───────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['leaveControlPanels', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-control-panel',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            name: item.name || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            fromDate: item.fromDate ? new Date(item.fromDate) : null,
            toDate: item.toDate ? new Date(item.toDate) : null,
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.name?.trim()) {
        throw new Error('Panel name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('Panel ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            name: payload.name.trim(),
            tenantId: payload.tenantId || '', // must be provided in create mode
            tenantRole: payload.tenantRole || null,
            module: payload.module?.trim() || null,
            fromDate: payload.fromDate || null,
            toDate: payload.toDate || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-control-panel',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['leaveControlPanels', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({ queryKey: ['leaveControlPanels', 'detail', payload.id] });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-control-panel',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leaveControlPanels', 'list'] });
    },
  });

  return {
    panel: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createPanel: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updatePanel: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deletePanel: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useLeaveControlPanel;