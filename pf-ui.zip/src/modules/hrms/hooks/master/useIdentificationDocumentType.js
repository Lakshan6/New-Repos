// src/hooks/hrms/useIdentificationDocumentType.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useIdentificationDocumentType = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['identification-document-type', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'identification-document-type',
        },
      }),

    select: (item) =>
      item
        ? {
            id: item.id,
            documentTypeName: item.documentTypeName || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!payload?.documentTypeName?.trim()) {
        throw new Error('Document Type Name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            documentTypeName: payload.documentTypeName.trim(),
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'identification-document-type',
          'Content-Type': 'application/json',
        },
        body,
      });
    },

    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['identification-document-type', 'list'] });

      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['identification-document-type', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'identification-document-type',
        },
      });
    },

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['identification-document-type', 'list'] });
    },
  });

  // ── RETURN ─────────────────────────────────────────────────────────────
  return {
    identificationDocumentType: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createIdentificationDocumentType: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),

    updateIdentificationDocumentType: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),

    deleteIdentificationDocumentType: (delId) =>
      deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,

    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useIdentificationDocumentType;