// src/hooks/master/useLeaveBlockList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeaveBlockList = () => {
   const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['leave-block-lists', 'list'],
 queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-block-list',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((block) => ({
        id: block.id,
        leaveBlockListName: block.leaveBlockListName,
        appliesToCompany: block.appliesToCompany || '—',
        tenantId: block.tenantId,
        tenantRole: block.tenantRole,
        module: block.module,
        validFrom: block.validFrom,
        validUpto: block.validUpto,
      }));
    },

  });
};

export default useLeaveBlockList;