// src/modules/hrms/hooks/master/useExpenseClaimAccounts.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useExpenseClaimAccounts = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL QUERY ─────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['expense-claim-account', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expense-claim-account',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            defaultAccount: item.defaultAccount || '',
            module: item.module || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
            expenseClaimType: item.expenseClaimType || null,
          }
        : null,
  });

  // ── CREATE / UPDATE MUTATION ───────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!isUpdate && !payload?.defaultAccount?.trim()) {
        throw new Error('Expense claim account name is required');
      }
      if (!isUpdate && !payload?.expenseClaimType?.id) {
        throw new Error('Expense Claim Type is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('Account ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            defaultAccount: payload.defaultAccount?.trim(),
            expenseClaimType: { id: payload.expenseClaimType.id },
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            tenantRole: payload.tenantRole || null,
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expense-claim-account',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['expense-claim-account', 'list'] });

      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['expense-claim-account', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE MUTATION ─────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'expense-claim-account',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['expense-claim-account', 'list'] });
    },
  });

  return {
    account: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createAccount: (data) => crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateAccount: (data) => crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteAccount: (delId) => deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useExpenseClaimAccounts;