// src/hooks/hrms/useLeavePolicyDetail.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useLeavePolicyDetail = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['leave-policy-detail', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-policy-detail',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            annualAllocation: item.annualAllocation ?? 0,
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
            leaveType: item.leaveType || null,
            leavePolicy: item.leavePolicy || null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (payload?.annualAllocation == null || payload.annualAllocation <= 0)
        throw new Error('Annual Allocation must be greater than 0');
      if (!isUpdate && !payload?.leavePolicy?.id)
        throw new Error('Leave Policy is required');
      if (!isUpdate && !payload?.leaveType?.id)
        throw new Error('Leave Type is required');
      if (isUpdate && !payload?.id)
        throw new Error('ID is required for update');

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            annualAllocation: payload.annualAllocation,
            leavePolicy: { id: payload.leavePolicy.id },
            leaveType: { id: payload.leaveType.id },
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-policy-detail',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['leave-policy-detail', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['leave-policy-detail', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-policy-detail',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['leave-policy-detail', 'list'] });
    },
  });

  return {
    leavePolicyDetail: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createLeavePolicyDetail: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateLeavePolicyDetail: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteLeavePolicyDetail: (delId) =>
      deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useLeavePolicyDetail;