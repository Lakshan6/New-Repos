// src/hooks/master/useLeaveControlPanelList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeaveControlPanelList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';

  return useQuery({
    queryKey: ['leave-control-panels', 'list'],
    queryFn: async () => {
      const response = await apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: 'GET',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'leave-control-panel',
        },
      });

      // Debug: log API response
      console.log('Leave Control Panels API Response:', response);

      return response;
    },
    select: (response) => {
      // Normalize API response
      const rawList =
        Array.isArray(response?.data) ? response.data :
        Array.isArray(response?.content) ? response.content :
        Array.isArray(response) ? response :
        [];

      if (!Array.isArray(rawList)) return [];

      // Filter only valid panels with id
      return rawList
        .filter((panel) => panel && panel.id)
        .map((panel) => ({
          id: panel.id,
          name: panel.name || '—',
          fromDate: panel.fromDate || null,
          toDate: panel.toDate || null,
          tenantId: panel.tenantId || null,
          tenantRole: panel.tenantRole || null,
          module: panel.module || null,
          validFrom: panel.validFrom || null,
          validUpto: panel.validUpto || null,
        }));
    },
    onError: (err) => {
      console.error('Failed to fetch leave control panels:', err);
    },
  });
};

export default useLeaveControlPanelList;