// src/hooks/master/useLeaveTypeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeaveTypeList = () => {
    const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['leave-type', 'list'],
        queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-type',
                },
            });
        },
        select: (response) => {
            const rawList =
                response?.data || response?.content || (Array.isArray(response) ? response : []);

            if (!Array.isArray(rawList)) return [];

            return rawList.map((type) => ({
                id: type.id,
                leaveTypeName: type.leaveTypeName,
                maxLeavesAllowed: type.maxLeavesAllowed ?? 0,
                applicableAfter: type.applicableAfter ?? 0,
                maxContinuousDaysAllowed: type.maxContinuousDaysAllowed ?? 0,
                isCarryForward: type.isCarryForward ?? false,
                isEarnedLeave: type.isEarnedLeave ?? false,
                isLwp: type.isLwp ?? false,
                isOptionalLeave: type.isOptionalLeave ?? false,
                allowNegative: type.allowNegative ?? false,
                includeHoliday: type.includeHoliday ?? false,
                isCompensatory: type.isCompensatory ?? false,
                tenantId: type.tenantId,
                tenantRole: type.tenantRole,
                module: type.module,
                validFrom: type.validFrom,
                validUpto: type.validUpto,
            }));
        },
    });
};

export default useLeaveTypeList;
