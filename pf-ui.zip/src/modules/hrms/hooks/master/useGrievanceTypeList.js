// src/hooks/master/useGrievanceTypeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useGrievanceTypeList = () => {
       const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['grievance-types', 'list'],
    queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'grievance-type',
                },
            });
        },
        select: (response) => {
            const rawList =
                response?.data ||
                response?.content ||
                (Array.isArray(response) ? response : []);

            if (!Array.isArray(rawList)) return [];

            return rawList.map((type) => ({
                id: type.id,
                grievanceTypeName: type.grievanceTypeName,
                description: type.description || '',
                tenantId: type.tenantId,
                tenantRole: type.tenantRole,
                module: type.module,
                validFrom: type.validFrom,
                validUpto: type.validUpto,
                revId: type.revId || null,
            }));
        },

    });
};

export default useGrievanceTypeList;