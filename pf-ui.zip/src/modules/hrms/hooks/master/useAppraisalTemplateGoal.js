// src/hooks/hrms/useAppraisalTemplateGoal.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useAppraisalTemplateGoal = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['appraisal-template-goal', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appraisal-template-goal',
        },
      }),
    select: (item) =>
      item
        ? {
            id: item.id,
            perWeightage: item.perWeightage ?? 0,
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            module: item.module || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
            kra: item.kra || null,
            appraisalTemplate: item.appraisalTemplate || null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (payload?.perWeightage == null || payload.perWeightage <= 0 || payload.perWeightage > 100)
        throw new Error('Weightage must be between 1 and 100');
      if (!isUpdate && !payload?.kra?.id)
        throw new Error('KRA is required');
      if (!isUpdate && !payload?.appraisalTemplate?.id)
        throw new Error('Appraisal Template is required');
      if (isUpdate && !payload?.id)
        throw new Error('ID is required for update');

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            perWeightage: payload.perWeightage,
            kra: { id: payload.kra.id },
            appraisalTemplate: { id: payload.appraisalTemplate.id },
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appraisal-template-goal',
          'Content-Type': 'application/json',
        },
        body,
      });
    },
    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['appraisal-template-goal', 'list'] });
      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['appraisal-template-goal', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');
      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: { requestInfo: { userInfo }, id: delId },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'appraisal-template-goal',
        },
      });
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['appraisal-template-goal', 'list'] });
    },
  });

  return {
    appraisalTemplateGoal: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createAppraisalTemplateGoal: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),
    updateAppraisalTemplateGoal: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),
    deleteAppraisalTemplateGoal: (delId) =>
      deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,
    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useAppraisalTemplateGoal;