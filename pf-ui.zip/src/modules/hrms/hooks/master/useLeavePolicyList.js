// src/hooks/master/useLeavePolicyList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useLeavePolicyList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['leave-policies', 'list'],
   queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'leave-policy',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((policy) => ({
        id: policy.id,
        policyName: policy.policyName,
        carryForwardEncashedLeaves: policy.carryForwardEncashedLeaves ?? false,
        tenantId: policy.tenantId,
        tenantRole: policy.tenantRole,
        module: policy.module,
        validFrom: policy.validFrom,
        validUpto: policy.validUpto,
      }));
    },

  });
};

export default useLeavePolicyList;