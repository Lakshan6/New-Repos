// src/hooks/master/useAppointmentLetterContentList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useAppointmentLetterContentList = () => {

  const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['appointment-letter-contents', 'list'],
        queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'appointment-letter-content',
                },
            });
        },

    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((content) => ({
        id: content.id,
        title: content.title,
        description: content.description || '',
        tenantId: content.tenantId,
        tenantRole: content.tenantRole,
        module: content.module,
        validFrom: content.validFrom,
        validUpto: content.validUpto,
        appointmentLetterTemplateId: content.appointmentLetterTemplate?.id || null,
        appointmentLetterTemplateName: content.appointmentLetterTemplate?.templateName || '—',
      }));
    },
  });
};

export default useAppointmentLetterContentList;