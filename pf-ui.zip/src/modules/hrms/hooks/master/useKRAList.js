// src/hooks/master/useKRAList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

export const useKRAList = () => {
  const authToken = localStorage.getItem('authToken') ?? '';
  return useQuery({
    queryKey: ['kras', 'list'],
   queryFn: async () => {
            return apiRequest({
                service: 'erp_hrms',
                endpoint: '/api/v1/entities',
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                    'X-Entity-Type': 'kra',
                },
            });
        },
    select: (response) => {
      const rawList =
        response?.data ||
        response?.content ||
        (Array.isArray(response) ? response : []);

      if (!Array.isArray(rawList)) return [];

      return rawList.map((kra) => ({
        id: kra.id,
        kraName: kra.kraName,
        description: kra.description || '',
        tenantId: kra.tenantId,
        tenantRole: kra.tenantRole,
        module: kra.module,
        validFrom: kra.validFrom,
        validUpto: kra.validUpto,
      }));
    },

  });
};

export default useKRAList;