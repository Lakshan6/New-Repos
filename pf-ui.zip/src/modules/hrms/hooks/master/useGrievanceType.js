// src/hooks/hrms/useGrievanceType.js
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';
import { getReqInfoObj } from '@shared/utils/common';

export const useGrievanceType = ({ id = null, userInfo = null } = {}) => {
  const authToken = localStorage.getItem('authToken') ?? '';
  const queryClient = useQueryClient();
  const requestInfo = getReqInfoObj?.() || { userInfo: userInfo || {} };

  // ── DETAIL ─────────────────────────────────────────────────────────────
  const detailQuery = useQuery({
    queryKey: ['grievance-type', 'detail', id],
    enabled: !!id && !!userInfo,
    queryFn: async () =>
      apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/fetch',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'grievance-type',
        },
      }),

    select: (item) =>
      item
        ? {
            id: item.id,
            grievanceTypeName: item.grievanceTypeName || '',
            description: item.description || '',
            module: item.module || '',
            tenantId: item.tenantId || '',
            tenantRole: item.tenantRole || '',
            validFrom: item.validFrom ? new Date(item.validFrom) : null,
            validUpto: item.validUpto ? new Date(item.validUpto) : null,
            revId: item.revId ?? null,
          }
        : null,
  });

  // ── CREATE + UPDATE ────────────────────────────────────────────────────
  const crudMutation = useMutation({
    mutationFn: async ({ isUpdate = false, payload }) => {
      if (!payload?.grievanceTypeName?.trim()) {
        throw new Error('Grievance Type Name is required');
      }
      if (isUpdate && !payload?.id) {
        throw new Error('ID is required for update');
      }

      const body = isUpdate
        ? payload
        : {
            requestInfo,
            grievanceTypeName: payload.grievanceTypeName.trim(),
            description: payload.description?.trim() || null,
            module: payload.module?.trim() || null,
            tenantId: payload.tenantId || 'PRO_OR',
            validFrom: payload.validFrom || null,
            validUpto: payload.validUpto || null,
          };

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities',
        method: isUpdate ? 'PATCH' : 'POST',
        useGateway: true,
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'grievance-type',
          'Content-Type': 'application/json',
        },
        body,
      });
    },

    onSuccess: (_, { isUpdate, payload }) => {
      queryClient.invalidateQueries({ queryKey: ['grievance-type', 'list'] });

      if (isUpdate && payload?.id) {
        queryClient.invalidateQueries({
          queryKey: ['grievance-type', 'detail', payload.id],
        });
      }
    },
  });

  // ── DELETE ─────────────────────────────────────────────────────────────
  const deleteMutation = useMutation({
    mutationFn: async (delId) => {
      if (!delId) throw new Error('ID required for delete');

      return apiRequest({
        service: 'erp_hrms',
        endpoint: '/api/v1/entities/delete',
        method: 'POST',
        useGateway: true,
        body: {
          requestInfo: { userInfo },
          id: delId,
        },
        headers: {
          Authorization: `Bearer ${authToken}`,
          'X-Entity-Type': 'grievance-type',
        },
      });
    },

    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['grievance-type', 'list'] });
    },
  });

  // ── RETURN ─────────────────────────────────────────────────────────────
  return {
    grievanceType: detailQuery.data,
    isLoading: detailQuery.isLoading,
    isError: detailQuery.isError,
    error: detailQuery.error,
    refetch: detailQuery.refetch,

    createGrievanceType: (data) =>
      crudMutation.mutateAsync({ isUpdate: false, payload: data }),

    updateGrievanceType: (data) =>
      crudMutation.mutateAsync({ isUpdate: true, payload: data }),

    deleteGrievanceType: (delId) =>
      deleteMutation.mutateAsync(delId),

    isCreating: crudMutation.isPending && !crudMutation.variables?.isUpdate,
    isUpdating: crudMutation.isPending && crudMutation.variables?.isUpdate,
    isDeleting: deleteMutation.isPending,

    mutationError: crudMutation.error || deleteMutation.error,
  };
};

export default useGrievanceType;