// src/hooks/leaves/useGetLeaveRequestHistoryForEmployee.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to search/fetch leave request history for a specific employee.
 * Uses POST + search body pattern (consistent with other search endpoints).
 */
export const useGetLeaveRequestHistoryForEmployee = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/leaves/requests/employee/search',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch leave request history for an employee.
     *
     * @param {Object} params
     * @param {string} params.employeeId - UUID of the employee whose history to fetch
     */
    const fetchLeaveHistory = async () => {
        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            //EMPLOYEE ID CAN BE SENT
        };

        return await mutateAsync(requestBody);
    };

    return {
        fetchLeaveHistory,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useGetLeaveRequestHistoryForEmployee;
