// src/hooks/leaves/useGetLeaveRequestHistoryForApprover.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to search/fetch leave requests pending under or actioned by a manager/approver.
 * Uses POST + search body pattern (consistent with other search endpoints).
 */
export const useGetLeaveRequestHistoryForApprover = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/leaves/requests/manager/search',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch leave requests visible to a manager/approver.
     *
     * @param {Object} params
     * @param {string} params.approverId - UUID of the approver/manager
     */
    const fetchApproverLeaveHistory = async () => {
        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            //APPROVER ID CAN BE SENT
        };

        return await mutateAsync(requestBody);
    };

    return {
        fetchApproverLeaveHistory,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useGetLeaveRequestHistoryForApprover;
