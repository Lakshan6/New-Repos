// src/hooks/Leaves/useLeaveDecision.js
import { useState } from 'react';
import { useTakeAction } from '../useTakeAction';
import { useSyncLeaveRequest } from './useSyncLeaveRequest';

/**
 * Orchestrator hook: takes a workflow action on a leave request,
 * then syncs the leave request projection.
 *
 * Usage:
 *   const { decideLeave, isPending, error } = useLeaveDecision();
 *   await decideLeave({ wfInstanceId, action: 'Approved', comment });
 */
export const useLeaveDecision = () => {
    const { takeAction, isPending: isActioning } = useTakeAction();
    const { syncLeaveRequest, isPending: isSyncing } = useSyncLeaveRequest();

    const [error, setError] = useState(null);

    /**
     * @param {Object}  params
     * @param {string}  params.wfInstanceId   - workflowInstanceId from the leave request
     * @param {string}  params.action         - e.g. 'Approved' | 'Rejected'
     * @param {string}  [params.comment]      - optional approver note (not sent to wf API but
     *                                          available for your own audit logging)
     * @param {string}  [params.assignee]     - optional reassign target UUID
     * @param {string}  [params.assigneeTenantId]
     */
    const decideLeave = async ({ wfInstanceId, action, comment, assignee, assigneeTenantId }) => {
        setError(null);

        try {
            // Step 1 — push the decision into the workflow engine
            await takeAction({
                wfInstanceId,
                action,
                ...(assignee && { assignee }),
                ...(assigneeTenantId && { assigneeTenantId }),
            });

            // Step 2 — sync the leave request projection so the HRMS DB reflects the new status
            await syncLeaveRequest(wfInstanceId);
        } catch (err) {
            setError(err);
            throw err; // re-throw so callers can show toast / handle locally
        }
    };

    return {
        decideLeave,
        isPending: isActioning || isSyncing,
        error,
    };
};

export default useLeaveDecision;
