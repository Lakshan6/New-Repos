// src/hooks/Leaves/useSyncLeaveRequest.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to sync a leave request status/projection from workflow
 * Endpoint: POST /api/leaves/requests/sync
 */
export const useSyncLeaveRequest = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/leaves/requests/sync',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Sync leave request data based on workflow instance ID
     * @param {string} wfInstanceId - UUID of the workflow instance
     * @returns {Promise<any>} Sync response from the server
     */
    const syncLeaveRequest = async (wfInstanceId) => {
        if (!wfInstanceId) {
            throw new Error('Workflow instance ID is required');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            workflowInstanceId: wfInstanceId,
        };

        try {
            const response = await mutateAsync(requestBody);
            return response;
        } catch (err) {
            console.error('Sync leave request failed:', err);
            throw err;
        }
    };

    return {
        syncLeaveRequest,
        isPending,
        isError,
        error,
        data,
    };
};

export default useSyncLeaveRequest;
