// src/hooks/leaves/useGetLeaveBalance.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Fetches the leave balance for a specific employee.
 * Endpoint is POST — employeeId is sent in the request body alongside requestInfo.
 * Data is returned as-is from the API (no transformation).
 */
export const useGetLeaveBalance = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/leaves/ledger/balance/search',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch leave balance for an employee.
     *
     * @param {string} employeeId - UUID of the employee
     */
    const fetchLeaveBalance = async () => {
        const requestInfo = getReqInfoObj();

        return await mutateAsync({
            ...requestInfo,
            //CAN SEND EMPLOYEE ID
        });
    };

    return {
        fetchLeaveBalance,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useGetLeaveBalance;
