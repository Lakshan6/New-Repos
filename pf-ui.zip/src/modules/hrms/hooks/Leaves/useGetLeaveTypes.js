// src/hooks/leaves/useGetLeaveTypes.js
import { useReadApi } from '@shared/hooks/useReadApi';

/**
 * Fetches all available leave types via the generic entity endpoint.
 * Data is returned as-is from the API (no transformation).
 */
export const useGetLeaveTypes = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const query = useReadApi({
        service: 'erp_hrms',
        endpoint: `/api/v1/entities`,
        method: 'GET',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'X-Entity-Type': 'leave-type',
        },
    });

    return {
        ...query,
    };
};

export default useGetLeaveTypes;
