// src/hooks/leaves/useCreateLeaveRequest.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to submit a new leave request for an employee.
 */
export const useCreateLeaveRequest = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/leaves/requests/submit',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Submit a leave request.
     *
     * @param {Object} params
     * @param {string}  params.workflowId          - UUID of the workflow definition to trigger
     * @param {string}  params.employeeId          - UUID of the employee applying for leave
     * @param {string}  params.leaveTypeId         - UUID of the leave type
     * @param {string}  params.dateFrom            - Start date in YYYY-MM-DD format
     * @param {string}  params.dateTo              - End date in YYYY-MM-DD format
     * @param {number}  params.days                - Total number of leave days
     * @param {string}  [params.startSession]      - 'FULL' | 'FIRST_HALF' | 'SECOND_HALF'
     * @param {string}  [params.endSession]        - 'FULL' | 'FIRST_HALF' | 'SECOND_HALF'
     * @param {string}  [params.reason]            - Reason for the leave
     * @param {string}  params.tenantId            - Tenant identifier
     */
    const createLeaveRequest = async ({
        workflowId,
        //employeeId,
        leaveTypeId,
        dateFrom,
        dateTo,
        days,
        startSession = 'FULL',
        endSession = 'FULL',
        reason = '',
        tenantId,
    }) => {
        if (!workflowId) throw new Error('workflowId is required');
        //if (!employeeId) throw new Error('employeeId is required');
        if (!leaveTypeId) throw new Error('leaveTypeId is required');
        if (!dateFrom) throw new Error('dateFrom is required');
        if (!dateTo) throw new Error('dateTo is required');
        if (days == null) throw new Error('days is required');
        if (!tenantId) throw new Error('tenantId is required');

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            workflowId,
            leaveRequest: {
                //employee: { id: employeeId },
                leaveType: { id: leaveTypeId },
                dateFrom,
                dateTo,
                days,
                startSession,
                endSession,
                reason,
                tenantId,
            },
        };

        return await mutateAsync(requestBody);
    };

    return {
        createLeaveRequest,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useCreateLeaveRequest;
