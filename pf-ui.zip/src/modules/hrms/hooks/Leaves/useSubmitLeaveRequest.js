// src/hooks/Leaves/useSubmitLeaveRequest.js
import { useState, useCallback } from 'react';
import { useCreateWorkflowInstance } from '../../hooks/useCreateWorkflowInstance';
import { useCreateLeaveRequest } from '../Leaves/useCreateLeaveRequest';
import { useTakeAction } from '../../hooks/useTakeAction';
import { useFetchUserForEmployee } from '../employees/useFetchUserForEmployee';

/**
 * Orchestrator hook that submits a leave request in three sequential steps:
 *
 *  1. Create a workflow instance  → LEAVE_APPROVAL_WF / INITIATE → gets wfInstanceId
 *  2. Submit the leave request    → attaches wfInstanceId, returns approverId (reporting_to)
 *  3. Use the approver_id to get userId → get the userId, from approverId
 *  4. Take action on the instance → SUBMIT, assignee = userId from step 3
 */
export const useSubmitLeaveRequest = () => {
    const [isPending, setIsPending] = useState(false);
    const [error, setError] = useState(null);
    const [data, setData] = useState(null);

    const { createWorkflowInstance } = useCreateWorkflowInstance();
    const { createLeaveRequest } = useCreateLeaveRequest();
    const { fetchUser } = useFetchUserForEmployee();
    const { takeAction } = useTakeAction();

    /**
     * @param {Object} params
     * @param {string}  params.leaveTypeId
     * @param {string}  params.dateFrom          - 'YYYY-MM-DD'
     * @param {string}  params.dateTo            - 'YYYY-MM-DD'
     * @param {number}  params.days
     * @param {string}  [params.startSession]    - 'FULL' | 'FIRST_HALF' | 'SECOND_HALF'
     * @param {string}  [params.endSession]      - 'FULL' | 'FIRST_HALF' | 'SECOND_HALF'
     * @param {string}  [params.reason]
     * @param {string}  params.tenantId
     */
    const submitLeaveRequest = useCallback(
        async ({
            leaveTypeId,
            dateFrom,
            dateTo,
            days,
            startSession = 'FULL',
            endSession = 'FULL',
            reason = '',
            tenantId,
        }) => {
            setIsPending(true);
            setError(null);
            setData(null);

            try {
                // ── Step 1: Initiate the workflow instance ────────────────────────
                const wfResponse = await createWorkflowInstance({
                    workFlowDef: 'LEAVE_APPROVAL_WF',
                    action: 'INITIATE',
                    tenantRoleAndTenantMap: {
                        PF_ORG: 'PF_ORG',
                        'COMPANY.UNIT': 'BG_CX',
                    },
                });

                const wfInstanceId = wfResponse?.uuid ?? wfResponse?.id;
                if (!wfInstanceId) {
                    throw new Error(
                        'Workflow instance creation did not return a valid wfInstanceId.',
                    );
                }

                // ── Step 2: Submit the leave request ─────────────────────────────
                const leaveResponse = await createLeaveRequest({
                    workflowId: wfInstanceId,
                    leaveTypeId,
                    dateFrom,
                    dateTo,
                    days,
                    startSession,
                    endSession,
                    reason,
                    tenantId,
                });

                // The leave response is expected to contain the approverId / reporting_to officer
                const approverId =
                    leaveResponse?.approverId ??
                    leaveResponse?.leaveRequest?.approverId ??
                    leaveResponse?.reportingTo ??
                    leaveResponse?.leaveRequest?.reportingTo;

                const approverTenantId =
                    leaveResponse?.approverTenantId ??
                    leaveResponse?.leaveRequest?.approverTenantId ??
                    tenantId; // fallback to same tenant

                if (!approverId) {
                    throw new Error(
                        'Leave request response did not return an approverId / reportingTo. ' +
                            'Cannot assign the SUBMIT action.',
                    );
                }

                // ── Step 4: Take the SUBMIT action on the workflow instance ───────
                const approverUserId = await fetchUser(approverId);

                // ── Step 4: Take the SUBMIT action on the workflow instance ───────
                const actionResponse = await takeAction({
                    wfInstanceId,
                    action: 'SUBMIT',
                    assignee: approverUserId,
                    assigneeTenantId: approverTenantId,
                });

                const result = { wfResponse, leaveResponse, actionResponse };
                setData(result);
                return result;
            } catch (err) {
                setError(err);
                throw err; // re-throw so the caller's try/catch (toast, etc.) still fires
            } finally {
                setIsPending(false);
            }
        },
        [createWorkflowInstance, createLeaveRequest, fetchUser, takeAction],
    );

    return {
        submitLeaveRequest,
        isPending,
        error,
        data,
    };
};

export default useSubmitLeaveRequest;
