// src/hooks/workflow/useWorkflowAvailableActions.js
import { useState, useCallback } from 'react';
import { useGetInstance } from './useGetInstance';
import { useGetWorkflowDefinition } from './useGetWorkflowDefinition';

/**
 * Returns possible actions for the current workflow state
 */
export const useWorkflowAvailableActions = () => {
    const { fetchInstance } = useGetInstance();
    const { fetchDefinition } = useGetWorkflowDefinition();

    const [actions, setActions] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const [error, setError] = useState(null);

    const loadActions = useCallback(
        async (workflowInstanceId) => {
            try {
                setIsLoading(true);
                setError(null);

                /* 1️⃣ Fetch workflow instance */
                const instanceResponse = await fetchInstance(workflowInstanceId);
                const wfInstance = instanceResponse?.[0];

                if (!wfInstance) {
                    throw new Error('Workflow instance not found');
                }

                const currentStateId = wfInstance.currentState?.id;
                const workflowDefId = wfInstance.wfDef?.id;

                if (!currentStateId || !workflowDefId) {
                    throw new Error('Invalid workflow instance data');
                }

                /* 2️⃣ Fetch workflow definition */
                const defResponse = await fetchDefinition(workflowDefId);
                const wfDef = defResponse?.[0];

                if (!wfDef) {
                    throw new Error('Workflow definition not found');
                }

                /* 3️⃣ Resolve actions for current state */
                const stateDef = wfDef.stateDtos.find((s) => s.id === currentStateId);

                const availableActions = stateDef?.actionDtos ?? [];

                /* 4️⃣ Normalize for UI */
                const normalizedActions = availableActions.map((action) => ({
                    id: action.id,
                    label: action.action.replace(/_/g, ' '),
                    action: action.action,
                    nextState: action.nextState,
                    nextStateName: action.nextStateName,
                    assigneeMandatory: action.assigneeMandatory,
                    documentRequired: action.documentRequired,
                    roleIds: action.roleIds,
                }));

                setActions(normalizedActions);
            } catch (err) {
                setError(err);
                setActions([]);
            } finally {
                setIsLoading(false);
            }
        },
        [fetchInstance, fetchDefinition],
    );

    // Add this function to clear cached actions
    const clearActions = useCallback(() => {
        setActions([]);
        setError(null);
    }, []);

    return {
        loadActions,
        clearActions,
        actions,
        isLoading,
        error,
    };
};
