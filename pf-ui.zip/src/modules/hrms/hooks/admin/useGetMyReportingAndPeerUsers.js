import { useMutationApi } from '@shared/hooks';

export const useGetMyReportingAndPeerUsers = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    return useMutationApi({
        service: 'user',
        endpoint: '/user/_getMyReportingAndPeerUsers',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        options: {
            // Optional: add onSuccess, onError, etc. here
        },
    });
};
