// hooks/useResourceSearch.js
import { useMutationApi } from '@shared/hooks';

export const useResourceSearch = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'mdms',
        endpoint: '/resource/_searchV1',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    // Expose a custom function that takes the search parameters
    const searchResources = async (requestBody) => {
        const response = await mutateAsync(requestBody);

        console.log('Raw API Response:', response);

        // Adjust based on your actual response structure
        const resources = response?.Resource || response?.resource || response || [];
        const totalRecords =
            response?.totalCount ||
            response?.totalRecords ||
            response?.Resource?.length ||
            resources.length;

        console.log('Parsed resources:', resources);
        console.log('Total records:', totalRecords);

        return {
            data: Array.isArray(resources) ? resources : [],
            totalRecords: Number(totalRecords),
        };
    };

    return {
        searchResources,
        isPending,
        isError,
        error,
        data,
    };
};
