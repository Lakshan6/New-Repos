// hooks/useGetMyReportingOrPeerUser.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

export const useGetMyReportingOrPeerUser = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'user',
        endpoint: '/user/_getMyReportingOrPeerUser',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    // Expose a custom function that takes the UUID
    const fetchUserById = async (uuid) => {
        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            uuid, // ✅ the employee's UUID (dynamic)
        };

        // Fire the API call with the body
        const response = await mutateAsync(requestBody);
        return response;
    };

    return { fetchUserById, isPending, isError, error, data };
};
