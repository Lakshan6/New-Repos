import { useMutationApi } from '@shared/hooks';

export const useUpdateUserByAdmin = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    return useMutationApi({
        service: 'user',
        endpoint: '/user/_updateUserByAdmin',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        options: {
            // Optional: add onSuccess, onError, etc. here
        },
    });
};
