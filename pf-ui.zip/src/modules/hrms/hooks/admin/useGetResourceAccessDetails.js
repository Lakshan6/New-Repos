import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

export const useGetResourceAccessDetails = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'mdms',
        endpoint: '/resource/access/_searchV1',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    // Expose a custom function that takes the resourceId
    const fetchResourceAccessById = async (resourceId) => {
        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            accessSearchDto: {
                resourceId, // ✅ the resource's ID (dynamic)
            },
        };

        // Fire the API call with the body
        const response = await mutateAsync(requestBody);
        return response;
    };

    return { fetchResourceAccessById, isPending, isError, error, data };
};
