// src/hooks/employees/useEmployeeDetail.js
import { useMemo } from 'react';
import { useReadApi } from '@shared/hooks/useReadApi';

/**
 * Fetches details of a single employee by ID
 * @param {string} employeeId - UUID of the employee
 */
export const useEmployeeDetail = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const query = useReadApi({
        service: 'erp_hrms',
        endpoint: `/api/employees/${employeeId}`,
        method: 'GET',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    // Transform data using useMemo
    const transformedData = useMemo(() => {
        if (!query.data) return null;

        const employeeDto = query.data.employeeDto;
        const onboardingDto = query.data.onboardingProcessDto;

        return {
            employee: {
                id: employeeDto.id,

                // Canonical employee identifiers
                employeeId: employeeDto.employee,
                employeeCode: employeeDto.employee,

                fullName: employeeDto.employeeName,
                firstName: employeeDto.firstName,
                lastName: employeeDto.lastName,

                gender: employeeDto.gender,
                dateOfBirth: employeeDto.dateOfBirth,
                joiningDate: employeeDto.dateOfJoining,

                status: employeeDto.status,

                contactNumber: employeeDto.cellNumber,
                personalEmail: employeeDto.personalEmail,
                officialEmail: employeeDto.companyEmail,

                currentAddress: employeeDto.currentAddress,

                companyId: employeeDto.companyId,
                companyName: employeeDto.companyName,

                departmentId: employeeDto.departmentId,
                department: employeeDto.departmentName,

                designationId: employeeDto.designationId,
                designation: employeeDto.designationName,

                employmentTypeId: employeeDto.employmentTypeId,
                employmentType: employeeDto.employmentTypeName,

                reportingOfficerId: employeeDto.reportingToId,
                reportingOfficerName: employeeDto.reportingToName,

                reviewingOfficerId: employeeDto.reviewingOfficerId,
                reviewingOfficerName: employeeDto.reviewingOfficerName,

                tenantId: employeeDto.tenantId,
                tenantRole: employeeDto.tenantRole,
                module: employeeDto.module,
            },

            onboardingProcess: onboardingDto
                ? {
                      id: onboardingDto.id,
                      workflowInstanceId: onboardingDto.workflowInstanceId,
                      candidateId: onboardingDto.candidateId,
                      employeeId: onboardingDto.employeeId,
                      currentState: onboardingDto.currentState,
                      status: onboardingDto.status,
                      progressPercentage: onboardingDto.progressPercentage,
                      startedAt: onboardingDto.startedAt,
                      expectedCompletionAt: onboardingDto.expectedCompletionAt,
                      completedAt: onboardingDto.completedAt,
                      rejectionReason: onboardingDto.rejectionReason,
                  }
                : null,

            qualifications: query.data?.qualificationList || [],
            pastExperiences: query.data?.pastExperienceList || [],
        };
    }, [query.data]);

    return {
        ...query,
        data: transformedData,
    };
};

export default useEmployeeDetail;
