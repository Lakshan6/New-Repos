// src/hrms/hooks/employees/useDeleteEmployeePastExperience.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// DELETING PAST EXPERIENCE FOR EMPLOYEES

export const useDeleteEmployeePastExperience = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/employees/${employeeId}/experience`,
        method: 'DELETE',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    const deletePastExperience = async (experienceId) => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        if (!experienceId) {
            throw new Error('Past Experience ID is required');
        }

        const payload = {
            ...requestInfo,
            pastExperience: {
                id: experienceId,
                candidateId: null,
                employeeId,
            },
        };

        return await mutateAsync(payload);
    };

    return { deletePastExperience, isPending, isError, error, data, reset };
};

export default useDeleteEmployeePastExperience;
