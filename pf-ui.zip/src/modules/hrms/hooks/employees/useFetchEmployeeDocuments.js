// src/hooks/employees/useFetchEmployeeDocuments.js
import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';

/**
 * Hook to fetch submitted documents for an employee
 * Uses GET /employees/{employeeId}/documents
 */
export const useFetchEmployeeDocuments = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms',
        endpoint: employeeId ? `/api/employees/${employeeId}/documents` : null,
        method: 'GET',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: !!employeeId, // important: do not fire if employeeId is missing
    });

    /**
     * Fetch documents for the initialized employee
     */
    const fetchEmployeeDocuments = useCallback(async () => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        const response = await mutateAsync();

        return (response || []).map((doc) => ({
            id: doc.id,
            documentType: doc.documentType,
            documentDescription: doc.documentDescription,
            fileName: doc.fileName,
            fileSize: doc.fileSize,
            mimeType: doc.mimeType,
            fileStoreId: doc.filestoreId,
            candidateId: doc.candidateId,
            onboardingProcessId: doc.onboardingProcessId,
            employeeId: doc.employeeId,
            uploadedAt: doc.uploadedAt,
            uploadedBy: doc.uploadedBy,
        }));
    }, [employeeId, mutateAsync]);

    return {
        fetchEmployeeDocuments,
        isPending,
        isError,
        error,
        data,
    };
};
