// src/hooks/employees/useTakeActionOnEmployee.js
import { useQueryClient } from '@tanstack/react-query';
import { useTakeAction } from '../useTakeAction';
import { useSyncEmployee } from './useSyncEmployee';

export const useTakeActionOnEmployee = () => {
    const queryClient = useQueryClient();

    const { takeAction, isPending: isActionPending } = useTakeAction();
    const { syncEmployee, isPending: isSyncPending } = useSyncEmployee();

    const isPending = isActionPending || isSyncPending;

    const execute = async ({
        wfInstanceId,
        employeeId,
        action,
        assignee, // ✅ ADD THIS PARAMETER
        assigneeTenantId, // ✅ ADD THIS TOO (optional)
        documentAccessStrategy,
        documents,
        shouldSync = true,
    }) => {
        // Step 1: Take action
        const actionResponse = await takeAction({
            wfInstanceId,
            action,
            assignee, // ✅ Pass assignee
            assigneeTenantId, // ✅ Pass assigneeTenantId
            documentAccessStrategy,
            documents,
        });

        // Step 2: Sync (conditionally)
        let syncResponse = null;
        if (shouldSync) {
            syncResponse = await syncEmployee(wfInstanceId);
        }

        // Step 3: Invalidate queries
        queryClient.invalidateQueries({ queryKey: ['employee', 'list'] });
        if (employeeId) {
            queryClient.invalidateQueries({ queryKey: ['employee', 'detail', employeeId] });
        }

        return { actionResponse, syncResponse };
    };

    return {
        execute,
        isPending,
    };
};

export default useTakeActionOnEmployee;
