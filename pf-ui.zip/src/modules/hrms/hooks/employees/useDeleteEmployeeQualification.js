// src/hrms/hooks/employees/useDeleteEmployeeQualification.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// DELETING QUALIFICATIONS FOR EMPLOYEES

/**
 * Hook to delete a qualification for an employee
 * Uses DELETE /api/employees/{employeeId}/qualifications
 *
 * @param {string} employeeId - The employee UUID
 */
export const useDeleteEmployeeQualification = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/employees/${employeeId}/qualifications`,
        method: 'DELETE',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Delete a qualification
     * @param {string} qualificationId - UUID of the qualification to delete
     */
    const deleteQualification = async (qualificationId) => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        if (!qualificationId) {
            throw new Error('Qualification ID is required');
        }

        const payload = {
            ...requestInfo,
            qualification: {
                id: qualificationId,
                candidateId: null,
                employeeId,
            },
        };

        return await mutateAsync(payload);
    };

    return {
        deleteQualification,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useDeleteEmployeeQualification;
