// src/hooks/employees/useUploadEmployeeDocuments.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to upload documents for a Employee
 * Uses POST /api/employees/{employeeId}/documents
 *
 * @param {string} employeeId - The Employee UUID (passed during initialization)
 */
export const useUploadEmployeeDocuments = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const userId = employeeId; // Adjust based on where you store userId THIS USERID is used for AUDITING

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms', // Adjust to your service name
        endpoint: `/api/employees/${employeeId}/documents`,
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'X-User-Id': userId,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Upload documents for the Employee
     * @param {Array} documents - Array of SubmittedDocumentCreateRequest objects
     * @returns {Promise<Array>} Array of SubmittedDocumentResponse
     *
     * @example
     * const documents = [
     *   {
     *     onboardingProcessId: "uuid",
     *     candidateId: "uuid"/null,
     *     employeeId: "uuid", <-- Needed & Available
     *     filestoreId: "fs-uuid",
     *     documentType: "Address Proof",
     *     documentDescription: "aadhar",
     *     fileName: "aadhar.pdf",
     *     fileSize: 123456,
     *     mimeType: "application/pdf"
     *   }
     * ]
     * await uploadDocuments(documents);
     */
    const uploadDocuments = async (documents) => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        if (!documents || documents.length === 0) {
            throw new Error('At least one document is required');
        }

        // Validate that all documents have the correct EmployeeId
        const invalidDocs = documents.filter((doc) => doc.employeeId !== employeeId);
        if (invalidDocs.length > 0) {
            throw new Error('All documents must belong to the same Employee');
        }

        const response = await mutateAsync(documents);

        return response;
    };

    return {
        uploadDocuments,
        isPending,
        isError,
        error,
        data,
    };
};
