// src/hooks/employees/useSyncEmployee.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to sync candidate status/projection from workflow
 * Endpoint: POST /api/employees/sync
 */
export const useSyncEmployee = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/employees/sync',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Sync Employee data based on workflow instance ID
     * @param {string} wfInstanceId - UUID of the workflow instance
     * @returns {Promise<any>} Sync response from the server
     */
    const syncEmployee = async (wfInstanceId) => {
        if (!wfInstanceId) {
            throw new Error('Workflow instance ID is required');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            workflowInstanceId: wfInstanceId, // ← FIXED: was using undefined variable
        };

        try {
            const response = await mutateAsync(requestBody);
            return response;
        } catch (err) {
            console.error('Sync employee failed:', err);
            throw err;
        }
    };

    return {
        syncEmployee,
        isPending,
        isError,
        error,
        data,
    };
};

export default useSyncEmployee;
