// src/hrms/hooks/employees/useUpdateEmployee.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to update employee details
 * @param {string} employeeId - Employee UUID
 */
export const useUpdateEmployee = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/employees/${employeeId}`, // ✅ ID included here
        method: 'PUT',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Update an employee
     * @param {Object} employeeData - Form data from the component
     * @returns {Promise<EmployeeDto>} Updated employee data
     */
    const updateEmployee = async (employeeData) => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        const employeeDto = mapFormDataToDto(employeeId, employeeData);
        const response = await mutateAsync(employeeDto);
        return response;
    };

    // ... mapFormDataToDto stays the same ...
    /**
     * Maps component form data to EmployeeDto structure
     * @param {string} id - Employee UUID
     * @param {Object} formData - Form data from component state
     * @returns {Object} EmployeeDto
     */
    const mapFormDataToDto = (id, formData) => {
        return {
            id,
            ...requestInfo,

            // Basic Information
            employee: formData.employeeId || null, // employee code
            employeeName: formData.fullName || null,
            firstName: formData.firstName || null,
            lastName: formData.lastName || null,
            gender: formData.gender || null,
            dateOfBirth: formData.dateOfBirth || null, // Should be LocalDate format: "YYYY-MM-DD"
            dateOfJoining: formData.joiningDate || null, // Should be LocalDate format: "YYYY-MM-DD"

            // Contact Information
            cellNumber: formData.contactNumber || null,
            personalEmail: formData.email || null,
            companyEmail: formData.companyEmail || null,
            currentAddress: formData.currentAddress || null,

            // Organizational - Names (for display, IDs should also be passed if available)
            departmentId: formData.departmentId || null,
            departmentName: formData.department || null,
            designationId: formData.designationId || null,
            designationName: formData.designation || null,
            employmentTypeId: formData.employmentTypeId || null,
            employmentTypeName: formData.employeeType || null,

            // Reporting Structure
            reportingToId: formData.reportingManager || null,
            reportingToName: formData.reportingManagerName || null,
            reviewingOfficerId: formData.reviewingOfficerId || null,
            reviewingOfficerName: formData.reviewingOfficerName || null,

            // Employment Status
            status: formData.status || null,

            // Multi-tenancy & Audit (preserve existing values if needed)
            tenantId: formData.tenantId || null,
            tenantRole: formData.tenantRole || null,
            module: formData.module || null,
            validFrom: formData.validFrom || null,
            validUpto: formData.validUpto || null,
            revId: formData.revId || null,
        };
    };

    return {
        updateEmployee,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useUpdateEmployee;
