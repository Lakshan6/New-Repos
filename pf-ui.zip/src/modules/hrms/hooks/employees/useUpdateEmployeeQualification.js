// src/hrms/hooks/employees/useUpdateEmployeeQualification.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// UPDATING QUALIFICATIONS FOR EMPLOYEES

/**
 * Hook to update an existing qualification for an employee
 * Uses PUT /api/employees/{employeeId}/qualifications
 *
 * @param {string} employeeId - The employee UUID
 */
export const useUpdateEmployeeQualification = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/employees/${employeeId}/qualifications`,
        method: 'PUT',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Update an existing qualification
     * @param {Object} qualificationData - Qualification form data (must include id)
     */
    const updateQualification = async (qualificationData) => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        if (!qualificationData?.id) {
            throw new Error('Qualification ID is required for update');
        }

        const payload = {
            ...requestInfo,
            qualification: mapFormDataToQualificationDto(employeeId, qualificationData),
        };

        return await mutateAsync(payload);
    };

    /**
     * Maps UI form data → QualificationDTO
     */
    const mapFormDataToQualificationDto = (employeeId, formData) => ({
        // Required for update
        id: formData.id,

        // Ownership (IMPORTANT: exactly one must be present)
        candidateId: null,
        employeeId,
        tenantId: formData.tenantId || null,

        // Core Qualification Details
        qualificationType: formData.qualificationType || null,
        educationLevel: formData.educationLevel || null,
        courseName: formData.courseName || null,
        specialization: formData.specialization || null,
        majorField: formData.majorField || null,
        minorField: formData.minorField || null,

        // Institution Context
        institution: formData.institution || null,
        boardOrUniversity: formData.boardOrUniversity || null,
        issuingAuthority: formData.issuingAuthority || null,
        accreditationBody: formData.accreditationBody || null,
        country: formData.country || null,
        modeOfStudy: formData.modeOfStudy || null,

        // Completion Details
        yearOfCompletion: formData.yearOfCompletion || null,
        issueDate: formData.issueDate || null,
        expiryDate: formData.expiryDate || null,
        completionStatus: formData.completionStatus || null,
        durationInMonths: formData.durationInMonths || null,

        // Results
        gradeOrPercentage: formData.gradeOrPercentage || null,
        percentageNumeric: formData.percentageNumeric || null,
        cgpa: formData.cgpa || null,
        resultClassification: formData.resultClassification || null,
        honors: formData.honors || null,

        // Credential Identity
        certificateNumber: formData.certificateNumber || null,
        registrationNumber: formData.registrationNumber || null,
        verificationSource: formData.verificationSource || null,
        verificationReference: formData.verificationReference || null,

        // Declaration Flags
        isDeclaredByCandidate: formData.isDeclaredByCandidate ?? true,
        isSelfAttested: formData.isSelfAttested ?? false,
    });

    return {
        updateQualification,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useUpdateEmployeeQualification;
