// ../hooks/Employees/useFetchUserForEmployee.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to find the User ID associated with a specific Employee ID.
 * Required for workflow assignments where the assignee must be a User UUID.
 */
export const useFetchUserForEmployee = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/employees/fetchUser',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * @param {string} employeeId - UUID of the employee
     */
    const fetchUser = async (employeeId) => {
        const requestInfo = getReqInfoObj();

        const requestBody = {
            requestInfo,
            id: employeeId,
        };

        const response = await mutateAsync(requestBody);

        // Return the uuid (userId) specifically
        const userId = response?.uuid;

        if (!userId) {
            throw new Error('User mapping not found for the selected approver.');
        }

        return userId;
    };

    return {
        fetchUser,
        isPending,
        isError,
        error,
        data,
    };
};

export default useFetchUserForEmployee;
