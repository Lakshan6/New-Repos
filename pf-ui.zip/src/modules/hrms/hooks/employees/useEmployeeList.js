// src/hooks/employees/useEmployeeList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

/**
 * Fetches the list of all employees with pagination
 *
 * @param {Object} options - Pagination options
 * @param {number} options.page - Page number (0-indexed)
 * @param {number} options.size - Number of items per page
 * @param {string} options.sortField - Field to sort by (e.g., 'employee', 'dateOfJoining')
 * @param {string} options.sortOrder - Sort direction ('asc' or 'desc')
 */
export const useEmployeeList = ({
    page = 0,
    size = 10,
    sortField = 'employee', // ✅ Changed from 'createdAt' to 'employee'
    sortOrder = 'asc', // ✅ Changed to 'asc' for employee ID
} = {}) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['employees', 'list', page, size, sortField, sortOrder],

        queryFn: async () => {
            // Build query parameters
            const params = new URLSearchParams({
                page: page.toString(),
                size: size.toString(),
                sort: `${sortField},${sortOrder}`,
            });

            return apiRequest({
                service: 'erp_hrms',
                endpoint: `/api/employees?${params.toString()}`,
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                },
            });
        },

        // Transform the Spring Page response
        select: (response) => {
            // 1. Handle the metadata shift: look for response.page, fallback to root response
            const pageMetadata = response?.page || response || {};

            if (!response || !response.content) {
                console.warn('Employees API did not return expected Page structure:', response);
                return {
                    content: [],
                    totalElements: 0,
                    totalPages: 0,
                    size: size,
                    number: page,
                };
            }

            return {
                content: response.content.map((employee) => ({
                    id: employee.id,
                    employeeId: employee.employee || employee.employeeCode || 'N/A',
                    name:
                        employee.fullName ||
                        employee.employeeName ||
                        `${employee.firstName || ''} ${employee.lastName || ''}`.trim() ||
                        'N/A',
                    department: employee.department || employee.departmentName || 'N/A',
                    designation: employee.designation || employee.designationName || 'N/A',
                    email:
                        employee.email ||
                        employee.officialEmail ||
                        employee.companyEmail ||
                        employee.personalEmail ||
                        'N/A',
                    contactNumber:
                        employee.contactNumber ||
                        employee.cellNumber ||
                        employee.phoneNumber ||
                        'N/A',
                    joiningDate: employee.joiningDate || employee.dateOfJoining || null,
                    status: employee.status || 'Active',
                    firstName: employee.firstName,
                    lastName: employee.lastName,
                    gender: employee.gender,
                    dateOfBirth: employee.dateOfBirth,
                    reportingManager: employee.reportingManager || employee.reportingToId || null,
                    reportingManagerName: employee.reportingManagerName || null,
                    employeeType: employee.employeeType || 'PERMANENT',
                    workLocation: employee.workLocation || employee.branch || null,
                    currentAddress: employee.currentAddress || null,
                    permanentAddress: employee.permanentAddress || null,
                    tenantId: employee.tenantId,
                    createdAt: employee.createdAt || employee.createdtime,
                    updatedAt: employee.updatedAt || employee.updatedtime,
                    candidateId: employee.candidateId || null,
                })),

                // 2. Map metadata from pageMetadata (response.page)
                totalElements: pageMetadata.totalElements ?? 0,
                totalPages: pageMetadata.totalPages ?? 0,
                size: pageMetadata.size ?? size,
                number: pageMetadata.number ?? page,

                // 3. Flags usually remain at the root or can be inferred
                first: response.first ?? pageMetadata.number === 0,
                last: response.last ?? pageMetadata.number + 1 >= pageMetadata.totalPages,
                numberOfElements: response.numberOfElements ?? response.content.length,
                empty: response.empty ?? response.content.length === 0,
            };
        },
    });
};

export default useEmployeeList;
