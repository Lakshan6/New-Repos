// src/hrms/hooks/employees/useUpdateEmployeePastExperience.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// UPDATING PAST EXPERIENCE FOR EMPLOYEES

export const useUpdateEmployeePastExperience = (employeeId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/employees/${employeeId}/experience`,
        method: 'PUT',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    const updatePastExperience = async (experienceData) => {
        if (!employeeId) {
            throw new Error('Employee ID is required');
        }

        if (!experienceData?.id) {
            throw new Error('Past Experience ID is required for update');
        }

        const payload = {
            ...requestInfo,
            pastExperience: mapFormDataToPastExperienceDto(employeeId, experienceData),
        };

        return await mutateAsync(payload);
    };

    const mapFormDataToPastExperienceDto = (employeeId, formData) => ({
        id: formData.id,

        candidateId: null,
        employeeId,
        tenantId: formData.tenantId || null,

        companyName: formData.companyName || null,
        designation: formData.designation || null,
        employmentType: formData.employmentType || null,
        employeeCode: formData.employeeCode || null,
        startDate: formData.startDate || null,
        endDate: formData.endDate || null,
        isCurrent: formData.isCurrent ?? false,
        durationInMonths: formData.durationInMonths || null,
        responsibilities: formData.responsibilities || null,
        reasonForLeaving: formData.reasonForLeaving || null,

        companyLocation: formData.companyLocation || null,
        companyCountry: formData.companyCountry || null,
        companyRegistrationNumber: formData.companyRegistrationNumber || null,

        reportingManagerName: formData.reportingManagerName || null,
        reportingManagerEmail: formData.reportingManagerEmail || null,
        hrContactEmail: formData.hrContactEmail || null,
        hrContactPhone: formData.hrContactPhone || null,

        experienceCertificateNumber: formData.experienceCertificateNumber || null,
        offerLetterNumber: formData.offerLetterNumber || null,
        relievingLetterNumber: formData.relievingLetterNumber || null,
        verificationSource: formData.verificationSource || null,
        verificationReference: formData.verificationReference || null,
        isVerified: formData.isVerified ?? false,

        lastDrawnSalary: formData.lastDrawnSalary || null,
        currency: formData.currency || null,
    });

    return { updatePastExperience, isPending, isError, error, data, reset };
};

export default useUpdateEmployeePastExperience;
