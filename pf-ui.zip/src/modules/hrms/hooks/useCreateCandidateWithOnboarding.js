// src/hrms/hooks/useCreateCandidateWithOnboarding.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';
import { useQueryClient } from '@tanstack/react-query';

/**
 * Hook to create a candidate with onboarding process
 */
export const useCreateCandidateWithOnboarding = () => {
    const queryClient = useQueryClient();
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/candidates/create-with-onboarding',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        onSuccess: () => {
            // Invalidate candidates list to refetch fresh data
            queryClient.invalidateQueries({ queryKey: ['candidates'] });
            queryClient.invalidateQueries({ queryKey: ['onboarding-candidates'] });
        },
    });

    /**
     * Create candidate with onboarding
     * @param {Object} params
     * @param {Object} params.candidate - The candidate data object
     * @param {string} params.workflowInstanceId - The ID of the workflow to trigger
     */
    const createCandidate = async ({ candidate, workflowInstanceId }) => {
        if (!workflowInstanceId) {
            throw new Error('Workflow Instance ID is required');
        }

        const requestBody = {
            ...requestInfo,
            candidate,
            workflowInstanceId,
        };

        return await mutateAsync(requestBody);
    };

    return {
        createCandidate,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useCreateCandidateWithOnboarding;
