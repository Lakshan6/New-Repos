// src/hooks/candidates/useSyncCandidate.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to sync candidate status/projection from workflow
 * Endpoint: POST /api/candidates/sync
 */
export const useSyncCandidate = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms',
        endpoint: '/api/candidates/sync',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Sync candidate data based on workflow instance ID
     * @param {string} wfInstanceId - UUID of the workflow instance
     * @returns {Promise<any>} Sync response from the server
     */
    const syncCandidate = async (wfInstanceId) => {
        if (!wfInstanceId) {
            throw new Error('Workflow instance ID is required');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            workflowInstanceId: wfInstanceId, // ← FIXED: was using undefined variable
        };

        try {
            const response = await mutateAsync(requestBody);
            return response;
        } catch (err) {
            console.error('Sync candidate failed:', err);
            throw err;
        }
    };

    return {
        syncCandidate,
        isPending,
        isError,
        error,
        data,
    };
};

export default useSyncCandidate;
