// src/hooks/candidates/useCandidateList.js
import { useQuery } from '@tanstack/react-query';
import { apiRequest } from '@shared/utils';

/**
 * Fetches paginated candidates for onboarding
 */
export const useCandidateList = ({
    page = 0,
    size = 10,
    sortField = 'applicationDate',
    sortOrder = 'desc',
} = {}) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    return useQuery({
        queryKey: ['candidates', 'list', page, size, sortField, sortOrder],

        queryFn: async () => {
            const params = new URLSearchParams({
                page: page.toString(),
                size: size.toString(),
                sort: `${sortField},${sortOrder}`,
            });

            return apiRequest({
                service: 'erp_hrms',
                endpoint: `/api/candidates?${params.toString()}`,
                method: 'GET',
                useGateway: true,
                headers: {
                    Authorization: `Bearer ${authToken}`,
                },
            });
        },

        select: (response) => {
            if (!response || !response.content) {
                console.warn('Candidates API did not return Page structure:', response);
                return {
                    content: [],
                    totalElements: 0,
                    totalPages: 0,
                    size,
                    number: page,
                };
            }

            // Pull metadata from the nested 'page' object
            const {
                totalElements = 0,
                totalPages = 0,
                size: responseSize = size,
                number = page,
            } = response.page || {};

            return {
                content: response.content.map((candidate) => ({
                    id: candidate.id,
                    name:
                        candidate.fullName ||
                        `${candidate.firstName || ''} ${candidate.lastName || ''}`.trim() ||
                        'N/A',

                    department: candidate.department || 'N/A',
                    designation: candidate.designation || 'N/A',
                    status: candidate.status || 'APPLIED',

                    applicationDate: candidate.applicationDate,
                    expectedJoinDate: candidate.expectedJoinDate,
                    source: candidate.source,

                    cellNumber: candidate.cellNumber,
                    personalEmail: candidate.personalEmail,
                    currentAddress: candidate.currentAddress,

                    workflowInstanceId: candidate.workflowInstanceId || null,
                    candidateCode: candidate.candidateCode,
                    gender: candidate.gender,
                    dateOfBirth: candidate.dateOfBirth,
                    tenantId: candidate.tenantId,
                })),

                // Map the extracted metadata back to the flat structure your UI expects
                totalElements,
                totalPages,
                size: responseSize,
                number,

                // These boolean flags are usually still at the root or can be inferred
                first: number === 0,
                last: number + 1 >= totalPages,
                empty: response.content.length === 0,
            };
        },
    });
};

export default useCandidateList;
