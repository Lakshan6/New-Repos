// src/hrms/hooks/candidates/useCreateQualification.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// CREATING QUALIFICATIONS FOR CANDIDATES

/**
 * Hook to create a new qualification for a candidate
 * Uses POST /api/candidates/{candidateId}/qualifications
 *
 * @param {string} candidateId - The candidate UUID
 */
export const useCreateQualification = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/candidates/${candidateId}/qualifications`,
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Create a new qualification
     * @param {Object} qualificationData - Qualification form data
     * @returns {Promise<QualificationDTO>}
     */
    const createQualification = async (qualificationData) => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        const payload = {
            ...requestInfo,
            qualification: mapFormDataToQualificationDto(candidateId, qualificationData),
        };

        return await mutateAsync(payload);
    };

    /**
     * Maps UI form data → QualificationDTO
     */
    const mapFormDataToQualificationDto = (candidateId, formData) => ({
        // Ownership
        candidateId,
        employeeId: formData.employeeId || null,
        tenantId: formData.tenantId || null,

        // Core Qualification Details
        qualificationType: formData.qualificationType || null,
        educationLevel: formData.educationLevel || null,
        courseName: formData.courseName || null,
        specialization: formData.specialization || null,
        majorField: formData.majorField || null,
        minorField: formData.minorField || null,

        // Institution Context
        institution: formData.institution || null,
        boardOrUniversity: formData.boardOrUniversity || null,
        issuingAuthority: formData.issuingAuthority || null,
        accreditationBody: formData.accreditationBody || null,
        country: formData.country || null,
        modeOfStudy: formData.modeOfStudy || null,

        // Completion Details
        yearOfCompletion: formData.yearOfCompletion || null,
        issueDate: formData.issueDate || null,
        expiryDate: formData.expiryDate || null,
        completionStatus: formData.completionStatus || null,
        durationInMonths: formData.durationInMonths || null,

        // Results
        gradeOrPercentage: formData.gradeOrPercentage || null,
        percentageNumeric: formData.percentageNumeric || null,
        cgpa: formData.cgpa || null,
        resultClassification: formData.resultClassification || null,
        honors: formData.honors || null,

        // Credential Identity
        certificateNumber: formData.certificateNumber || null,
        registrationNumber: formData.registrationNumber || null,
        verificationSource: formData.verificationSource || null,
        verificationReference: formData.verificationReference || null,

        // Declaration Flags
        isDeclaredByCandidate: formData.isDeclaredByCandidate ?? true,
        isSelfAttested: formData.isSelfAttested ?? false,
    });

    return {
        createQualification,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useCreateQualification;
