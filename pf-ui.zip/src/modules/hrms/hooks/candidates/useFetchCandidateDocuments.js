// src/hooks/candidates/useFetchCandidateDocuments.js
import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';

/**
 * Hook to fetch submitted documents for a candidate
 * Uses GET /candidates/{candidateId}/documents
 */
export const useFetchCandidateDocuments = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms',
        endpoint: candidateId ? `/api/candidates/${candidateId}/documents` : null,
        method: 'GET',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: !!candidateId, // important: do not fire if candidateId missing
    });

    /**
     * Fetch documents for the initialized candidate
     */
    const fetchCandidateDocuments = useCallback(async () => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        const response = await mutateAsync();

        return (response || []).map((doc) => ({
            id: doc.id,
            documentType: doc.documentType,
            documentDescription: doc.documentDescription,
            fileName: doc.fileName,
            fileSize: doc.fileSize,
            mimeType: doc.mimeType,
            fileStoreId: doc.filestoreId,
            candidateId: doc.candidateId,
            onboardingProcessId: doc.onboardingProcessId,
            employeeId: doc.employeeId,
            uploadedAt: doc.uploadedAt,
            uploadedBy: doc.uploadedBy,
        }));
    }, [candidateId, mutateAsync]);

    return {
        fetchCandidateDocuments,
        isPending,
        isError,
        error,
        data,
    };
};
