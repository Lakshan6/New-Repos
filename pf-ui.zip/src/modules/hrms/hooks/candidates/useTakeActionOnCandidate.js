// src/hooks/candidates/useTakeActionOnCandidate.js
import { useQueryClient } from '@tanstack/react-query';
import { useTakeAction } from '../useTakeAction';
import { useSyncCandidate } from './useSyncCandidate';

export const useTakeActionOnCandidate = () => {
    const queryClient = useQueryClient();

    const { takeAction, isPending: isActionPending } = useTakeAction();
    const { syncCandidate, isPending: isSyncPending } = useSyncCandidate();

    const isPending = isActionPending || isSyncPending;

    const execute = async ({
        wfInstanceId,
        candidateId,
        action,
        assignee, //  ADD THIS PARAMETER
        assigneeTenantId, //  ADD THIS TOO (optional)
        documentAccessStrategy,
        documents,
        shouldSync = true,
    }) => {
        // Step 1: Take action
        const actionResponse = await takeAction({
            wfInstanceId,
            action,
            documentAccessStrategy,
            assignee,
            assigneeTenantId,
            documents,
        });

        // Step 2: Sync (conditionally)
        let syncResponse = null;
        if (shouldSync) {
            syncResponse = await syncCandidate(wfInstanceId);
        }

        // Step 3: Invalidate queries
        queryClient.invalidateQueries({ queryKey: ['candidates', 'list'] });
        if (candidateId) {
            queryClient.invalidateQueries({ queryKey: ['candidate', 'detail', candidateId] });
        }

        return { actionResponse, syncResponse };
    };

    return {
        execute,
        isPending,
    };
};

export default useTakeActionOnCandidate;
