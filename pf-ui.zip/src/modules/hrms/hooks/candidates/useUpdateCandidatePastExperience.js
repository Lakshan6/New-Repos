// src/hrms/hooks/candidates/useUpdateCandidatePastExperience.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// UPDATING PAST EXPERIENCE FOR CANDIDATES

/**
 * Hook to update an existing past experience record for a candidate
 * Uses PUT /api/candidates/{candidateId}/experience
 *
 * @param {string} candidateId - The candidate UUID
 */
export const useUpdateCandidatePastExperience = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/candidates/${candidateId}/experience`,
        method: 'PUT',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Update an existing past experience record
     * @param {Object} experienceData - Past experience form data (must include id)
     * @returns {Promise<PastExperienceDTO>}
     */
    const updatePastExperience = async (experienceData) => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        if (!experienceData.id) {
            throw new Error('Past Experience ID is required for update');
        }

        const payload = {
            ...requestInfo,
            pastExperience: mapFormDataToPastExperienceDto(candidateId, experienceData),
        };

        return await mutateAsync(payload);
    };

    /**
     * Maps UI form data → PastExperienceDTO
     */
    const mapFormDataToPastExperienceDto = (candidateId, formData) => ({
        // ID is required for update
        id: formData.id,

        // Ownership
        candidateId,
        employeeId: formData.employeeId || null,
        tenantId: formData.tenantId || null,

        // Core Experience Details
        companyName: formData.companyName || null,
        designation: formData.designation || null,
        employmentType: formData.employmentType || null,
        employeeCode: formData.employeeCode || null,
        startDate: formData.startDate || null,
        endDate: formData.endDate || null,
        isCurrent: formData.isCurrent ?? false,
        durationInMonths: formData.durationInMonths || null,
        responsibilities: formData.responsibilities || null,
        reasonForLeaving: formData.reasonForLeaving || null,

        // Company Context
        companyLocation: formData.companyLocation || null,
        companyCountry: formData.companyCountry || null,
        companyRegistrationNumber: formData.companyRegistrationNumber || null,

        // Reporting & HR Contact
        reportingManagerName: formData.reportingManagerName || null,
        reportingManagerEmail: formData.reportingManagerEmail || null,
        hrContactEmail: formData.hrContactEmail || null,
        hrContactPhone: formData.hrContactPhone || null,

        // Proof & Verification Metadata
        experienceCertificateNumber: formData.experienceCertificateNumber || null,
        offerLetterNumber: formData.offerLetterNumber || null,
        relievingLetterNumber: formData.relievingLetterNumber || null,
        verificationSource: formData.verificationSource || null,
        verificationReference: formData.verificationReference || null,
        isVerified: formData.isVerified ?? false,

        // Compensation Context
        lastDrawnSalary: formData.lastDrawnSalary || null,
        currency: formData.currency || null,
    });

    return {
        updatePastExperience,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useUpdateCandidatePastExperience;
