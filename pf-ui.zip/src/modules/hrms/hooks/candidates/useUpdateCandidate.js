// src/hrms/hooks/candidates/useUpdateCandidate.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to update candidate details
 * @param {string} candidateId - Candidate UUID
 */
export const useUpdateCandidate = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/candidates/${candidateId}`,
        method: 'PUT',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Update candidate
     * @param {Object} formData - Candidate form state
     * @returns {Promise<CandidateDto>}
     */
    const updateCandidate = async (formData) => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        const candidateDto = mapFormDataToCandidateDto(candidateId, formData);
        return await mutateAsync(candidateDto);
    };

    /**
     * Maps UI form data → CandidateDto (partial update safe)
     */
    const mapFormDataToCandidateDto = (id, formData) => ({
        id,
        ...requestInfo,

        // Basic Information
        candidateCode: formData.candidateCode || null,
        fullName: formData.fullName || null,
        firstName: formData.firstName || null,
        lastName: formData.lastName || null,
        gender: formData.gender || null,
        dateOfBirth: formData.dateOfBirth || null,

        // Recruitment
        applicationDate: formData.applicationDate || null,
        expectedJoinDate: formData.expectedJoinDate || null,
        source: formData.source || null,
        applicationData: formData.applicationData || null,
        status: formData.status || null,

        // Contact
        cellNumber: formData.cellNumber || null,
        personalEmail: formData.personalEmail || null,
        currentAddress: formData.currentAddress || null,

        // Org (IDs only)
        company: formData.company || null,
        tentativeDepartment: formData.tentativeDepartment || null,
        tentativeDesignation: formData.tentativeDesignation || null,
        tentativeEmploymentTypeId: formData.tentativeEmploymentTypeId || null,
        tentativeReportingToId: formData.tentativeReportingToId || null,

        // Multi-tenancy & audit
        tenantId: formData.tenantId || null,
        tenantRole: formData.tenantRole || null,
        module: formData.module || 'HRMS',
        validFrom: formData.validFrom || null,
        validUpto: formData.validUpto || null,
        revId: formData.revId || null,
    });

    return {
        updateCandidate,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useUpdateCandidate;
