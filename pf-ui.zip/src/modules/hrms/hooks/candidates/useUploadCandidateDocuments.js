// src/hooks/candidates/useUploadCandidateDocuments.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to upload documents for a candidate
 * Uses POST /api/candidates/{candidateId}/documents
 *
 * @param {string} candidateId - The candidate UUID (passed during initialization)
 */
export const useUploadCandidateDocuments = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const userId = candidateId; // Adjust based on where you store userId THIS USERID is used for AUDITING

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'erp_hrms', // Adjust to your service name
        endpoint: `/api/candidates/${candidateId}/documents`,
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'X-User-Id': userId,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Upload documents for the candidate
     * @param {Array} documents - Array of SubmittedDocumentCreateRequest objects
     * @returns {Promise<Array>} Array of SubmittedDocumentResponse
     *
     * @example
     * const documents = [
     *   {
     *     onboardingProcessId: "uuid",
     *     candidateId: "uuid",
     *     employeeId: null,
     *     filestoreId: "fs-uuid",
     *     documentType: "Address Proof",
     *     documentDescription: "aadhar",
     *     fileName: "aadhar.pdf",
     *     fileSize: 123456,
     *     mimeType: "application/pdf"
     *   }
     * ]
     * await uploadDocuments(documents);
     */
    const uploadDocuments = async (documents) => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        if (!documents || documents.length === 0) {
            throw new Error('At least one document is required');
        }

        // Validate that all documents have the correct candidateId
        const invalidDocs = documents.filter((doc) => doc.candidateId !== candidateId);
        if (invalidDocs.length > 0) {
            throw new Error('All documents must belong to the same candidate');
        }

        const response = await mutateAsync(documents);

        return response;
    };

    return {
        uploadDocuments,
        isPending,
        isError,
        error,
        data,
    };
};
