// src/hrms/hooks/candidates/useDeleteQualification.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// DELETING QUALIFICATIONS FOR CANDIDATES

/**
 * Hook to delete a qualification for a candidate
 * Uses DELETE /api/candidates/{candidateId}/qualifications
 *
 * @param {string} candidateId - The candidate UUID
 */
export const useDeleteQualification = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/candidates/${candidateId}/qualifications`,
        method: 'DELETE',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Delete a qualification
     * @param {string} qualificationId - UUID of the qualification to delete
     * @returns {Promise<void>}
     */
    const deleteQualification = async (qualificationId) => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        if (!qualificationId) {
            throw new Error('Qualification ID is required');
        }

        const payload = {
            ...requestInfo,
            qualification: {
                id: qualificationId,
                candidateId,
            },
        };

        return await mutateAsync(payload);
    };

    return {
        deleteQualification,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useDeleteQualification;
