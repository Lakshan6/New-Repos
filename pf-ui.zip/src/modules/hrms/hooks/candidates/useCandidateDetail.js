// src/hooks/candidates/useCandidateDetail.js
import { useMemo } from 'react';
import { useReadApi } from '@shared/hooks/useReadApi';

/**
 * Fetches details of a single candidate by ID
 * @param {string} candidateId - UUID of the candidate
 */
export const useCandidateDetail = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const query = useReadApi({
        service: 'erp_hrms',
        endpoint: `/api/candidates/${candidateId}`,
        method: 'GET',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    // Transform data using useMemo
    const transformedData = useMemo(() => {
        if (!query.data) return null;

        const candidate = query.data?.candidateDto || {};
        const onboarding = query.data?.onboardingProcessDto || {};

        return {
            candidate: {
                id: candidate.id,
                candidateCode: candidate.candidateCode,
                fullName: candidate.fullName,
                firstName: candidate.firstName,
                lastName: candidate.lastName,
                gender: candidate.gender,
                dateOfBirth: candidate.dateOfBirth,
                applicationDate: candidate.applicationDate,
                expectedJoinDate: candidate.expectedJoinDate,
                source: candidate.source,
                applicationData: candidate.applicationData,
                status: candidate.status,
                cellNumber: candidate.cellNumber,
                personalEmail: candidate.personalEmail,
                currentAddress: candidate.currentAddress,
                company: candidate.company,
                tenantId: candidate.tenantId,
            },

            onboardingProcess: {
                id: onboarding.id,
                workflowInstanceId: onboarding.workflowInstanceId,
                currentState: onboarding.currentState,
                status: onboarding.status,
                progressPercentage: onboarding.progressPercentage,
                startedAt: onboarding.startedAt,
                completedAt: onboarding.completedAt,
                rejectionReason: onboarding.rejectionReason,
            },

            qualifications: query.data?.qualificationList || [],
            pastExperiences: query.data?.pastExperienceList || [],
        };
    }, [query.data]);

    return {
        ...query,
        data: transformedData,
    };
};

export default useCandidateDetail;
