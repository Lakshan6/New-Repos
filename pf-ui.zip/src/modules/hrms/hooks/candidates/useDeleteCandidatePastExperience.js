// src/hrms/hooks/candidates/useDeleteCandidatePastExperience.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

// DELETING PAST EXPERIENCE FOR CANDIDATES

/**
 * Hook to delete a past experience record for a candidate
 * Uses DELETE /api/candidates/{candidateId}/experience
 *
 * @param {string} candidateId - The candidate UUID
 */
export const useDeleteCandidatePastExperience = (candidateId) => {
    const authToken = localStorage.getItem('authToken') ?? '';
    const requestInfo = getReqInfoObj();

    const { mutateAsync, isPending, isError, error, data, reset } = useMutationApi({
        service: 'erp_hrms',
        endpoint: `/api/candidates/${candidateId}/experience`,
        method: 'DELETE',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    /**
     * Delete a past experience record
     * @param {string} experienceId - UUID of the past experience to delete
     * @returns {Promise<void>}
     */
    const deletePastExperience = async (experienceId) => {
        if (!candidateId) {
            throw new Error('Candidate ID is required');
        }

        if (!experienceId) {
            throw new Error('Past Experience ID is required');
        }

        const payload = {
            ...requestInfo,
            pastExperience: {
                id: experienceId,
                candidateId,
            },
        };

        return await mutateAsync(payload);
    };

    return {
        deletePastExperience,
        isPending,
        isError,
        error,
        data,
        reset,
    };
};

export default useDeleteCandidatePastExperience;
