// src/hooks/workflow/useGetInstance.js
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

/**
 * Hook to fetch a specific workflow instance by UUID
 */
export const useGetWorkflowDefinition = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'workflow',
        endpoint: '/wf/_search',
        method: 'POST',
        useGateway: true,
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
    });

    /**
     * Fetch workflow definition
     * @param {string} workflowId
     * @returns {Promise<any>} Workflow instance data
     */
    const fetchDefinition = async (workflowId) => {
        if (!workflowId) {
            throw new Error('Workflow ID is required');
        }

        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            wfSearchDto: {
                id: workflowId,
            },
        };

        const response = await mutateAsync(requestBody);
        return response;
    };

    return {
        fetchDefinition,
        isPending,
        isError,
        error,
        data,
    };
};
