export const STATUS_COLOURS = [
    { label: 'DOCUMENT_VERIFICATION', bg: '#E8D1FF', text: '#63439C' },
    { label: 'PENDING_EMPLOYEE_CREATED', bg: '#FFE2C2', text: '#855B32' },
    { label: 'Pending employee created', bg: '#FFE2C2', text: '#855B32' },
    { label: 'COMPLETED_ONBOARDING', bg: '#C6E7CE', text: '#3E6B48' },
    { label: 'New', bg: '#B9E5FF', text: '#3D6D8C' },
    { label: 'Renewal', bg: '#E8D1FF', text: '#63439C' },
    { label: 'EMPLOYEE_CREATED', bg: '#C2F0F0', text: '#2D6666' },
    { label: 'Special', bg: '#FFD6F5', text: '#8C4079' },
    { label: 'INITIATED', bg: '#FFF4C2', text: '#857021' },
    { label: 'COMPLETED', bg: '#E2E8F0', text: '#475569' },
    { label: 'REJECTED', bg: '#FEF3C7', text: '#92400E' },
];

export const EXTENDED_STATUS_COLOURS = [
    // Originals + your expanded ones
    { id: 'unqualified', label: 'Unqualified', bg: '#FFD5D5', text: '#B33A3A' },
    { id: 'proposal', label: 'Proposal', bg: '#FFE2C2', text: '#855B32' },
    { id: 'qualified', label: 'Qualified', bg: '#C6E7CE', text: '#3E6B48' },
    { id: 'new', label: 'New', bg: '#B9E5FF', text: '#3D6D8C' },
    { id: 'renewal', label: 'Renewal', bg: '#E8D1FF', text: '#63439C' },
    { id: 'active', label: 'Active', bg: '#D1FAE5', text: '#065F46' },
    { id: 'warning', label: 'Warning', bg: '#FEF3C7', text: '#92400E' },
    { id: 'urgent', label: 'Urgent', bg: '#FEE2E2', text: '#991B1B' },
    { id: 'growth', label: 'Growth', bg: '#ECFCCB', text: '#3F6212' },
    { id: 'discovery', label: 'Discovery', bg: '#CFFAFE', text: '#155E75' },
    { id: 'callback', label: 'Callback', bg: '#E0E7FF', text: '#3730A3' },
    { id: 'review', label: 'Review', bg: '#FAE8FF', text: '#86198F' },
    { id: 'archived', label: 'Archived', bg: '#F3F4F6', text: '#374151' },
    { id: 'on_hold', label: 'On Hold', bg: '#F1F5F9', text: '#475569' },
    { id: 'negotiation', label: 'Negotiation', bg: '#FFE4E6', text: '#9F1239' },
    { id: 'processing', label: 'Processing', bg: '#CCFBF1', text: '#115E59' },
];

// Helper function to find color by label (case insensitive)
export const getStatusColor = (status) => {
    if (!status) {
        return { bg: '#E2E8F0', text: '#475569' }; // neutral fallback
    }

    const normalized = status.trim().toUpperCase();

    const allColors = [...STATUS_COLOURS, ...EXTENDED_STATUS_COLOURS];

    const match = allColors.find((item) => item.label.toUpperCase() === normalized);

    return match ? { bg: match.bg, text: match.text } : { bg: '#E2E8F0', text: '#475569' }; // fallback
};
