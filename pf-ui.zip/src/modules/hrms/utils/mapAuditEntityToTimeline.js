const AUDIT_META_FIELDS = new Set([
    'revId',
    'validFrom',
    'validUpto',
    'actionType',
    'lastModifiedBy',
    'lastModifiedTime',
    'module',
    'tenantId',
    'tenantRole',
]);

const formatValue = (val) => {
    if (val === null || val === undefined) return '—';
    if (typeof val === 'boolean') return val ? 'Yes' : 'No';
    return String(val);
};

const formatFieldLabel = (key) =>
    key
        .replace(/([A-Z])/g, ' $1')
        .replace(/^./, (c) => c.toUpperCase())
        .trim();

const diffObjects = (prev = {}, curr = {}) => {
    const changes = [];
    Object.keys(curr).forEach((key) => {
        if (AUDIT_META_FIELDS.has(key)) return;
        if (prev[key] !== curr[key]) {
            changes.push({
                field: key,
                oldValue: formatValue(prev[key]),
                newValue: formatValue(curr[key]),
            });
        }
    });
    return changes;
};

const ACTION_TYPE_LABEL = {
    UPDATE: 'Record Updated',
    CREATE: 'Record Created',
    DELETE: 'Record Deleted',
};

export const mapAuditEntityToTimeline = (auditList = []) => {
    if (!auditList.length) return [];

    const sorted = [...auditList].sort((a, b) => a.revId - b.revId);
    const events = [];

    for (let i = 0; i < sorted.length; i++) {
        const current = sorted[i];
        const previous = sorted[i - 1];

        const changes = previous
            ? diffObjects(previous, current)
            : Object.keys(current)
                  .filter((key) => !AUDIT_META_FIELDS.has(key))
                  .map((key) => ({
                      field: key,
                      oldValue: '—',
                      newValue: formatValue(current[key]),
                  }));

        if (!changes.length) continue;

        // Parse the ISO timestamp into separate date and time strings
        const parsedDate = current.validFrom ? new Date(current.validFrom) : null;

        const dateStr = parsedDate
            ? parsedDate.toLocaleDateString('en-IN', {
                  day: '2-digit',
                  month: 'short',
                  year: 'numeric',
              })
            : '—';

        const timeStr = parsedDate
            ? parsedDate.toLocaleTimeString('en-IN', {
                  hour: '2-digit',
                  minute: '2-digit',
              })
            : '';

        // Build a human-readable description from the changes array
        const description = changes
            .map(
                ({ field, oldValue, newValue }) =>
                    `[${formatFieldLabel(field)}]: ${oldValue} → ${newValue}`,
            )
            .join('\n');

        events.push({
            id: current.revId,
            // LEFT column
            title: ACTION_TYPE_LABEL[current.actionType] ?? current.actionType,
            date: dateStr,
            time: timeStr,
            // RIGHT column
            heading: `Revision ${current.revId}  ·  ${current.status ?? ''}`,
            description,
            subDescription: current.lastModifiedBy
                ? `Modified by: ${current.lastModifiedBy}`
                : null,
            attachments: [],
            // Keep raw changes if you ever want to use them later
            _changes: changes,
        });
    }

    return events;
};
