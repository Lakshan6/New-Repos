const ROOT_TENANT_ID = 'BEL';

export { ROOT_TENANT_ID };
