/**
 * Converts Workflow Instance API response into
 * CustomTimeline-compatible event objects
 *
 * Input  : wfInstance (single workflow instance object)
 * Output : Array<CustomTimelineEvent>
 */

/* ---------- Date & Time Helpers ---------- */

const formatDateTime = (timestamp) => {
    if (!timestamp) return { date: '-', time: '-' };

    const dateObj = new Date(timestamp);

    return {
        date: dateObj.toLocaleDateString(undefined, {
            year: 'numeric',
            month: 'short',
            day: '2-digit',
        }),
        time: dateObj.toLocaleTimeString(undefined, {
            hour: '2-digit',
            minute: '2-digit',
        }),
    };
};

const formatDuration = (ms) => {
    if (!ms || ms <= 0) return 'Instant';

    const totalSeconds = Math.floor(ms / 1000);
    const minutes = Math.floor(totalSeconds / 60);
    const seconds = totalSeconds % 60;

    if (minutes > 0) {
        return `${minutes} min ${seconds} sec`;
    }

    return `${seconds} sec`;
};

/* ---------- Core Mapper ---------- */

export const mapWorkflowToTimelineEvents = (wfInstance) => {
    if (!wfInstance || !Array.isArray(wfInstance.stateInstances)) {
        return [];
    }

    const currentStateId = wfInstance.currentState?.id;

    return wfInstance.stateInstances
        .slice()
        .sort((a, b) => a.createdTime - b.createdTime)
        .map((state) => {
            const { date, time } = formatDateTime(state.createdTime);

            const isCurrentState = state.stateId === currentStateId;

            return {
                title: isCurrentState
                    ? `${state.stateName.replace(/_/g, ' ')} (Current)`
                    : state.stateName.replace(/_/g, ' '),

                date,
                time,

                heading: state.stateName.replace(/_/g, ' '),

                description: `Action performed by ${state.assignerName}`,

                subDescription: `Time spent in this state: ${formatDuration(state.duration)}`,

                attachments: [], // future: map documents uploaded in this state
            };
        });
};
