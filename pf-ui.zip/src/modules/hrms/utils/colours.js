// src/constants/colors.js (or src/utils/colors.js)
export const PASTEL_COLORS = [
    '#A7C7E7', // Soft Blue
    '#BEE3DB', // Mint Green
    '#FFD3B6', // Peach
    '#FFAAA5', // Soft Coral
    '#FFC6FF', // Light Lavender
    '#D4E4FF', // Baby Blue
    '#E0BBE4', // Pale Purple
    '#FFE5D9', // Soft Apricot
    '#C7CEEA', // Lilac
    '#B5EAD7', // Pale Mint
];

// Optional: Export more palettes if needed
export const ULTRA_PASTEL_COLORS = [
    '#DCEBFF',
    '#E8F5E9',
    '#FFF3E0',
    '#FFEBEE',
    '#F3E5F5',
    '#E3F2FD',
    '#F3E8FF',
    '#FFF8E1',
    '#E8EAF6',
    '#E0F7FA',
];
