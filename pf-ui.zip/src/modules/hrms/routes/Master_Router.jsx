// src/routes/master.routes.tsx
import EmployeeFeedbackCriteriaListView from '../screens/master/EmployeeFeedbackCriteriaListView';
import EmployeeFeedbackCriteriaDetailedView from '../screens/master/EmployeeFeedbackCriteriaDetailedView';
import EmployeeGradeListView from '../screens/master/EmployeeGradeListView';
import EmployeeGradeDetailView from '../screens/master/EmployeeGradeDetailView';
import OnboardingTemplateListView from '../screens/master/OnboardingTemplateListView';
import OnboardingTemplateDetailView from '../screens/master/OnboardingTemplateDetailView';
import EmployeeSeparationTemplateListView from '../screens/master/EmployeeSeparationTemplateListView';
import EmployeeSeparationTemplateDetailView from '../screens/master/EmployeeSeparationTemplateDetailView';
import EmploymentTypeListView from '../screens/master/EmploymentTypeListView';
import EmploymentTypeDetailView from '../screens/master/EmploymentTypeDetailView';
import GrievanceTypeListView from '../screens/master/GrievanceTypeListView';
import GrievanceTypeDetailView from '../screens/master/GrievanceTypeDetailView';
import IdentificationDocumentTypeListView from '../screens/master/IdentificationDocumentTypeListView';
import IdentificationDocumentTypeDetailView from '../screens/master/IdentificationDocumentTypeDetailView';
import AppraisalCycleListView from '../screens/master/AppraisalCycleListView';
import AppraisalCycleDetailView from '../screens/master/AppraisalCycleDetailView';
import AppraisalTemplateListView from '../screens/master/AppraisalTemplateListView';
import AppraisalTemplateDetailView from '../screens/master/AppraisalTemplateDetailView';
import AppraisalTemplateGoalListView from '../screens/master/AppraisalTemplateGoalListView';
import AppraisalTemplateGoalDetailView from '../screens/master/AppraisalTemplateGoalDetailView';
import LeavePolicyListView from '../screens/master/LeavePolicyListView';
import LeavePolicyDetailView from '../screens/master/LeavePolicyDetailView';
import LeaveTypeListView from '../screens/master/LeaveTypeListView';
import LeaveTypeDetailView from '../screens/master/LeaveTypeDetailView';
import LeavePolicyDetailListView from '../screens/master/LeavePolicyDetailListView';
import LeavePolicyDetailDetailView from '../screens/master/LeavePolicyDetailDetailView';
import LeavePeriodListView from '../screens/master/LeavePeriodListView';
import LeavePeriodDetailView from '../screens/master/LeavePeriodDetailView';
import LeaveBlockListView from '../screens/master/LeaveBlockListView';
import LeaveBlockDetailView from '../screens/master/LeaveBlockDetailView';
import LeaveBlockListAllowListView from '../screens/master/LeaveBlockListAllowListView';
import LeaveBlockListAllowDetailView from '../screens/master/LeaveBlockListAllowDetailView';
import LeaveBlockListDateListView from '../screens/master/LeaveBlockListDateListView';
import LeaveBlockListDateDetailView from '../screens/master/LeaveBlockListDateDetailView';
import LeaveControlPanelListView from '../screens/master/LeaveControlPanelListView';
import LeaveControlPanelDetailView from '../screens/master/LeaveControlPanelDetailView';
import KRAListView from '../screens/master/KRAListView';
import KRADetailView from '../screens/master/KRADetailView';
import JobApplicantSourceListView from '../screens/master/JobApplicantSourceListView';
import JobApplicantSourceDetailView from '../screens/master/JobApplicantSourceDetailView';
import OfferTermListView from '../screens/master/OfferTermListView';
import OfferTermDetailView from '../screens/master/OfferTermDetailView';
import InterviewRoundListView from '../screens/master/InterviewRoundListView';
import InterviewRoundDetailView from '../screens/master/InterviewRoundDetailView';
import InterviewTypeListView from '../screens/master/InterviewTypeListView';
import InterviewTypeDetailView from '../screens/master/InterviewTypeDetailView';
import AppointmentLetterTemplateListView from '../screens/master/AppointmentLetterTemplateListView';
import AppointmentLetterTemplateDetailView from '../screens/master/AppointmentLetterTemplateDetailView';
import AppointmentLetterContentListView from '../screens/master/AppointmentLetterContentListView';
import AppointmentLetterContentDetailView from '../screens/master/AppointmentLetterContentDetailView';
import ExpenseClaimTypeListView from '../screens/master/ExpenseClaimTypeListView';
import ExpenseClaimTypeDetailView from '../screens/master/ExpenseClaimTypeDetailView';

import ExpenseClaimAccountListView from '../screens/master/ExpenseClaimAccountListView';
import ExpenseClaimAccountDetailView from '../screens/master/ExpenseClaimAccountDetailView';

import SkillListView from '../screens/master/SkillListView';
import SkillDetailView from '../screens/master/SkillDetailView';

import ExpectedSkillSetListView from '../screens/master/ExpectedSkillSetListView';
import ExpectedSkillSetDetailView from '../screens/master/ExpectedSkillSetDetailView';

import ShiftTypeListView from '../screens/master/ShiftTypeListView';
import ShiftTypeDetailView from '../screens/master/ShiftTypeDetailView';


import DesignationSkillListView from '../screens/master/DesignationSkillListView';
import DesignationSkillDetailView from '../screens/master/DesignationSkillDetailView';

import HRSettingsListView from '../screens/master/HRSettingsListView';
import HRSettingsDetailView from '../screens/master/HRSettingsDetailView';

import PurposeOfTravelListView from '../screens/master/PurposeOfTravelListView';
import PurposeOfTravelDetailView from '../screens/master/PurposeOfTravelDetailView';

import ShiftLocationListView from '../screens/master/ShiftLocationListView';
import ShiftLocationDetailView from '../screens/master/ShiftLocationDetailView';

import ShiftScheduleListView from '../screens/master/ShiftScheduleListView';
import ShiftScheduleDetailView from '../screens/master/ShiftScheduleDetailView';


export const masterRoutes = [


    { path: '/employee-feedback-criteria', element: <EmployeeFeedbackCriteriaListView /> },
    { path: '/employee-feedback-criteria/detail', element: <EmployeeFeedbackCriteriaDetailedView /> },
    { path: '/employee-feedback-criteria/create', element: <EmployeeFeedbackCriteriaDetailedView /> },
  
    { path: '/employee-grade', element: <EmployeeGradeListView /> },
    { path: '/employee-grade/detail', element: <EmployeeGradeDetailView /> },
    { path: '/employee-grade/create', element: <EmployeeGradeDetailView /> },

    { path: '/employee-separation-template', element: <EmployeeSeparationTemplateListView /> },
    { path: '/employee-separation-template/detail', element: <EmployeeSeparationTemplateDetailView /> },
    { path: '/employee-separation-template/create', element: <EmployeeSeparationTemplateDetailView /> },
  
    { path: '/employment-type', element: <EmploymentTypeListView /> },
    { path: '/employment-type/detail', element: <EmploymentTypeDetailView /> },
    { path: '/employment-type/create', element: <EmploymentTypeDetailView /> },

    { path: '/grievance-type', element: <GrievanceTypeListView /> },
    { path: '/grievance-type/detail', element: <GrievanceTypeDetailView /> },
    { path: '/grievance-type/create', element: <GrievanceTypeDetailView /> },

    { path: '/identification-document-type', element: <IdentificationDocumentTypeListView /> },
    { path: '/identification-document-type/detail', element: <IdentificationDocumentTypeDetailView /> },
    { path: '/identification-document-type/create', element: <IdentificationDocumentTypeDetailView /> },
 
    { path: '/appraisal-cycle', element: <AppraisalCycleListView /> },
    { path: '/appraisal-cycle/detail', element: <AppraisalCycleDetailView /> },
    { path: '/appraisal-cycle/create', element: <AppraisalCycleDetailView /> },


    { path: '/appraisal-template', element: <AppraisalTemplateListView /> },
    { path: '/appraisal-template/detail', element: <AppraisalTemplateDetailView /> },
    { path: '/appraisal-template/create', element: <AppraisalTemplateDetailView /> },


    { path: '/appraisal-template-goal', element: <AppraisalTemplateGoalListView /> },
    { path: '/appraisal-template-goal/detail', element: <AppraisalTemplateGoalDetailView /> },   //missing appraisalTemplateId    kraId → ID of the selected KRA (goal)
    { path: '/appraisal-template-goal/create', element: <AppraisalTemplateGoalDetailView /> },
 

    { path: '/leave-type', element: <LeaveTypeListView /> },
    { path: '/leave-type/detail', element: <LeaveTypeDetailView /> },
    { path: '/leave-type/create', element: <LeaveTypeDetailView /> },

    { path: '/leave-policy-detail', element: <LeavePolicyDetailListView /> },
    { path: '/leave-policy-detail/detail', element: <LeavePolicyDetailDetailView /> },  // both are required leaveType: formData.leaveTypeId,      // <-- required leavePolicy: formData.leavePolicyId,
    { path: '/leave-policy-detail/create', element: <LeavePolicyDetailDetailView /> },


    { path: '/leave-policy', element: <LeavePolicyListView /> },
    { path: '/leave-policy/detail', element: <LeavePolicyDetailView /> },
    { path: '/leave-policy/create', element: <LeavePolicyDetailView /> },


    { path: '/leave-period', element: <LeavePeriodListView /> },
    { path: '/leave-period/detail', element: <LeavePeriodDetailView /> },
    { path: '/leave-period/create', element: <LeavePeriodDetailView /> },


    { path: '/leave-block-list', element: <LeaveBlockListView /> },
    { path: '/leave-block-list/detail', element: <LeaveBlockDetailView /> },
    { path: '/leave-block-list/create', element: <LeaveBlockDetailView /> },


    { path: '/leave-block-list-allow', element: <LeaveBlockListAllowListView /> },
    { path: '/leave-block-list-allow/detail', element: <LeaveBlockListAllowDetailView /> },  //validation required leaveBlockList
    { path: '/leave-block-list-allow/create', element: <LeaveBlockListAllowDetailView /> },


    { path: '/leave-block-list-date', element: <LeaveBlockListDateListView /> },
    { path: '/leave-block-list-date/detail', element: <LeaveBlockListDateDetailView /> },  //validation required leaveBlockListId
    { path: '/leave-block-list-date/create', element: <LeaveBlockListDateDetailView /> },


    { path: '/leave-control-panel', element: <LeaveControlPanelListView /> },
    { path: '/leave-control-panel/detail', element: <LeaveControlPanelDetailView /> },   //here some need to be fix
    { path: '/leave-control-panel/create', element: <LeaveControlPanelDetailView /> },


    { path: '/kra', element: <KRAListView /> },
    { path: '/kra/detail', element: <KRADetailView /> },
    { path: '/kra/create', element: <KRADetailView /> },

    { path: '/job-applicant-source', element: <JobApplicantSourceListView /> },
    { path: '/job-applicant-source/detail', element: <JobApplicantSourceDetailView /> },
    { path: '/job-applicant-source/create', element: <JobApplicantSourceDetailView /> },


    { path: '/offer-term', element: <OfferTermListView /> },
    { path: '/offer-term/detail', element: <OfferTermDetailView /> },   //some need to fix it
    { path: '/offer-term/create', element: <OfferTermDetailView /> },


    { path: '/interview-round', element: <InterviewRoundListView /> },
    { path: '/interview-round/detail', element: <InterviewRoundDetailView /> },  //interview type id is required
    { path: '/interview-round/create', element: <InterviewRoundDetailView /> },     


    { path: '/interview-type', element: <InterviewTypeListView /> },
    { path: '/interview-type/detail', element: <InterviewTypeDetailView /> },
    { path: '/interview-type/create', element: <InterviewTypeDetailView /> },

    { path: '/appointment-letter-template', element: <AppointmentLetterTemplateListView /> },
    { path: '/appointment-letter-template/detail', element: <AppointmentLetterTemplateDetailView /> },
    { path: '/appointment-letter-template/create', element: <AppointmentLetterTemplateDetailView /> },

    { path: '/appointment-letter-content', element: <AppointmentLetterContentListView /> },
    { path: '/appointment-letter-content/detail', element: <AppointmentLetterContentDetailView /> },   //validation is requred appointmentLetterTemplateId
    { path: '/appointment-letter-content/create', element: <AppointmentLetterContentDetailView /> },

    { path: '/expense-claim-type', element: <ExpenseClaimTypeListView /> },
    { path: '/expense-claim-type/detail', element: <ExpenseClaimTypeDetailView /> },
    { path: '/expense-claim-type/create', element: <ExpenseClaimTypeDetailView /> },

    { path: '/expense-claim-account', element: <ExpenseClaimAccountListView /> },
    { path: '/expense-claim-account/detail', element: <ExpenseClaimAccountDetailView /> },
    { path: '/expense-claim-account/create', element: <ExpenseClaimAccountDetailView /> },     //validation implementaion is remaning  

    { path: '/expected-skill-set', element: <ExpectedSkillSetListView /> },
    { path: '/expected-skill-set/detail', element: <ExpectedSkillSetDetailView /> },
    { path: '/expected-skill-set/create', element: <ExpectedSkillSetDetailView /> },

    { path: '/designation-skill', element: <DesignationSkillListView /> },
    { path: '/designation-skill/detail', element: <DesignationSkillDetailView /> },
    { path: '/designation-skill/create', element: <DesignationSkillDetailView /> },


    { path: '/hr-settings', element: <HRSettingsListView /> },
    { path: '/hr-settings/detail', element: <HRSettingsDetailView /> },
    { path: '/hr-settings/create', element: <HRSettingsDetailView /> },

    { path: '/skill', element: <SkillListView /> },
    { path: '/skill/detail', element: <SkillDetailView /> },
    { path: '/skill/create', element: <SkillDetailView /> },

    { path: '/shift-schedule', element: <ShiftScheduleListView /> },
    { path: '/shift-schedule/detail', element: <ShiftScheduleDetailView /> },
    { path: '/shift-schedule/create', element: <ShiftScheduleDetailView /> },

     { path: '/shift-type', element: <ShiftTypeListView /> },
    { path: '/shift-type/detail', element: <ShiftTypeDetailView /> },
    { path: '/shift-type/create', element: <ShiftTypeDetailView /> },

    { path: '/shift-location', element: <ShiftLocationListView /> },
    { path: '/shift-location/detail', element: <ShiftLocationDetailView /> },
    { path: '/shift-location/create', element: <ShiftLocationDetailView /> },
 
    { path: '/purpose-of-travel', element: <PurposeOfTravelListView /> },
    { path: '/purpose-of-travel/detail', element: <PurposeOfTravelDetailView /> },
    { path: '/purpose-of-travel/create', element: <PurposeOfTravelDetailView /> },

    { path: '/employee-onboarding-template', element: <OnboardingTemplateListView /> },
    { path: '/employee-onboarding-template/detail', element: <OnboardingTemplateDetailView /> },
    { path: '/employee-onboarding-template/create', element: <OnboardingTemplateDetailView /> },

];



