import { Route, Routes } from 'react-router';
import { TranslationProvider, RequireAccess } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';
import {
    AdminLanding,
    UserList,
    UserDetails,
    ResourceList,
    ResourceAccessDetails,
    AdminLayout,
} from '../screens/admin';

import { OrgChart } from '../components/admin';
import { ROOT_TENANT_ID } from '../utils/constants';
import OnboardingCandidateListView from '../screens/OnboardingCandidateListView';
import OnboardingCandidateDetailedView from '../screens/OnboardingCandidateDetailedView';
import EmployeeListView from '../screens/EmployeeListView';
import EmployeeDetailedView from '../screens/EmployeeDetailedView';
import Dashboard from '../screens/Dashboard';
import OnboardingCandidateCreateView from '../screens/OnboardingCandidateCreateView';

import { masterRoutes } from './Master_Router';

const Router = () => {
    return (
        <TranslationProvider module={LOCALISATION_MODULES.HRMS} translationsAtom={translationsAtom}>
            <Routes>
                {/* VMENU routes — guarded by resource.path from _searchMyAccess */}
                <Route
                    index
                    element={
                        <RequireAccess resourcePath="HUMAN_RESOURCE.HOME">
                            <AdminLanding />
                        </RequireAccess>
                    }
                />
                <Route
                    path="/sample"
                    element={
                        <RequireAccess resourcePath="HUMAN_RESOURCE.HOME">
                            <Dashboard />
                        </RequireAccess>
                    }
                />
                <Route
                    path="/onboarding"
                    element={
                        <RequireAccess resourcePath="HUMAN_RESOURCE.ONNOARDING">
                            <OnboardingCandidateListView />
                        </RequireAccess>
                    }
                />
                <Route
                    path="/employee"
                    element={
                        <RequireAccess resourcePath="HUMAN_RESOURCE.EMPLOYEES">
                            <EmployeeListView />
                        </RequireAccess>
                    }
                />

                {/* Sub-routes — no guard; only reachable via UI from guarded list views */}
                <Route
                    path="/onboarding-create"
                    element={<OnboardingCandidateCreateView />}
                ></Route>
                <Route path="/onboarding-candidate" element={<OnboardingCandidateDetailedView />} />
                <Route path="/employee-details" element={<EmployeeDetailedView />}></Route>

                {masterRoutes.map(({ path, element }) => (
                    <Route key={path} path={path} element={element} />
                ))}

                {/* Leaves and Leave approval */}
                {/* <Route path="/time-n-attendance/leaves" element={<LeavesPage />}></Route>
                <Route
                    path="/time-n-attendance/leave-approvals"
                    element={<LeaveApprovals />}
                ></Route>

                <Route
                    path="/employee-feedback-criteria"
                    element={<EmployeeFeedbackCriteriaListView />}
                ></Route>
                <Route
                    path="/employee-feedback-criteria/detail"
                    element={<EmployeeFeedbackCriteriaDetailedView />}
                ></Route> */}

                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
