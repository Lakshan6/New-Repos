import { useCallback } from 'react';
import { useParams, useNavigate } from 'react-router';
import MRPOutputDetails from '../components/MRPOutputDetails';

const MRPOutputDetailsPage = () => {
    const { runId } = useParams();
    const navigate = useNavigate();

    const handleBack = useCallback(() => {
        navigate('/web/landing/mrp/mrp-report');
    }, [navigate]);

    return <MRPOutputDetails runId={runId} onBack={handleBack} />;
};

export default MRPOutputDetailsPage;
