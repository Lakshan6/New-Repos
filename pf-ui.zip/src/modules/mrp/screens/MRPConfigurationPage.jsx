import React, { useState, useMemo, useCallback } from 'react';
import { useForm, useWatch } from 'react-hook-form';
import { useMutation } from '@tanstack/react-query';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { Tag } from 'primereact/tag';

import { useSafeContext, useT } from '@shared/hooks';
import { AuthContext, apiRequest } from '@shared/utils';
import { PageLayout, Card, useAppToast } from '@shared/components';
import {
    FormGroup,
    ControlledInputText,
    ControlledInputSwitch,
    ControlledInputNumber,
    ControlledDropdown,
} from '@shared/components/FormComponents';

const MRP_TYPE_OPTIONS = [
    { label: 'VB', value: 'VB' },
    { label: 'VM', value: 'VM' },
    { label: 'PD', value: 'PD' },
];

const SCHEDULE_TYPE_OPTIONS = [
    { label: 'Monthly', value: 'MONTHLY' },
    { label: 'Weekly', value: 'WEEKLY' },
];

const WEEKDAY_OPTIONS = [
    { label: 'Sunday', value: 'SUN' },
    { label: 'Monday', value: 'MON' },
    { label: 'Tuesday', value: 'TUE' },
    { label: 'Wednesday', value: 'WED' },
    { label: 'Thursday', value: 'THU' },
    { label: 'Friday', value: 'FRI' },
    { label: 'Saturday', value: 'SAT' },
];

const WEEKDAY_CRON_MAP = { SUN: 1, MON: 2, TUE: 3, WED: 4, THU: 5, FRI: 6, SAT: 7 };

const ENDPOINT_MAP = {
    VB: '/api/mrp/vb-scheduler',
    VM: '/api/mrp/vm-scheduler',
    PD: '/api/mrp/mrp-scheduler',
};

const DEFAULT_VALUES = {
    mrpType: 'VB',
    runName: '',
    scheduleType: 'MONTHLY',
    dayOfMonth: 1,
    dayOfWeek: 'MON',
    warehouseIds: '',
    regenerative: false,
    createdBy: '',
};

const FIELDS = {
    mrpType: { required: 'MRP Type is required' },
    runName: { required: 'Run Name is required' },
    scheduleType: { required: 'Schedule type is required' },
    dayOfMonth: {
        required: 'Day of month is required',
        min: { value: 1, message: 'Min 1' },
        max: { value: 28, message: 'Max 28' },
    },
    dayOfWeek: { required: 'Day of week is required' },
    createdBy: { required: 'Created By is required' },
};

function buildCronExpr(scheduleType, dayOfMonth, dayOfWeek) {
    if (scheduleType === 'WEEKLY') {
        return `0 32 11 ? * ${WEEKDAY_CRON_MAP[dayOfWeek] || 2} *`;
    }
    return `59 59 23 ${dayOfMonth} * ? *`;
}

const MRPConfigurationPage = () => {
    const { t } = useT();
    const { authToken, tenantIds } = useSafeContext(AuthContext);
    const selectedTenantId = tenantIds?.[0];
    const { success, apiError } = useAppToast();

    const [responseData, setResponseData] = useState(null);
    const [dialogVisible, setDialogVisible] = useState(false);

    const { control, handleSubmit, reset } = useForm({
        defaultValues: DEFAULT_VALUES,
    });

    const scheduleType = useWatch({ control, name: 'scheduleType' });

    const headers = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);

    const { mutate, isPending } = useMutation({
        mutationFn: ({ endpoint, payload }) =>
            apiRequest({
                service: 'mrp',
                headers,
                endpoint,
                method: 'POST',
                body: payload,
            }),
    });

    const onSubmit = useCallback(
        (data) => {
            const cronExpr = buildCronExpr(data.scheduleType, data.dayOfMonth, data.dayOfWeek);
            const endpoint = ENDPOINT_MAP[data.mrpType];
            const mrpTypeLabel = data.mrpType;

            const payload = {
                requestInfo: { authToken },
                plantId: selectedTenantId,
                runName: data.runName,
                cronExpr,
                scheduleType: data.scheduleType,
                ...(data.scheduleType === 'MONTHLY'
                    ? { dayOfMonth: data.dayOfMonth }
                    : { dayOfWeek: data.dayOfWeek }),
                warehouseIds: data.warehouseIds || null,
                regenerative: data.regenerative,
                createdBy: data.createdBy,
            };

            mutate(
                { endpoint, payload },
                {
                    onSuccess: (resp) => {
                        success(t('Success'), t(`${mrpTypeLabel} Schedule created successfully.`));
                        setResponseData({
                            ...resp,
                            mrpType: mrpTypeLabel,
                            scheduleType: data.scheduleType,
                            dayOfMonth: data.dayOfMonth,
                            dayOfWeek: data.dayOfWeek,
                        });
                        setDialogVisible(true);
                        reset(DEFAULT_VALUES);
                    },
                    onError: (err) => {
                        apiError(err, t(`Failed to create ${mrpTypeLabel} schedule.`));
                    },
                },
            );
        },
        [mutate, selectedTenantId, authToken, t, success, apiError, reset],
    );

    const hideDialog = useCallback(() => {
        setDialogVisible(false);
        setResponseData(null);
    }, []);

    const dialogFooter = useCallback(
        () => (
            <div className="flex justify-content-end gap-2">
                <Button label={t('Close')} icon="pi pi-check" onClick={hideDialog} />
            </div>
        ),
        [hideDialog, t],
    );

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('Scheduler Configuration')}
                subtitle={t('Create and manage MRP scheduler runs (VB / VM / PD).')}
            />

            <PageLayout.Content>
                <Card title={t('Schedule Details')}>
                    <div className="grid">
                        <div className="col-12 md:col-6">
                            <FormGroup htmlFor="mrpType" label={t('MRP Type')} required>
                                <ControlledDropdown
                                    name="mrpType"
                                    control={control}
                                    inputId="mrpType"
                                    options={MRP_TYPE_OPTIONS}
                                    placeholder={t('Select MRP type')}
                                    rules={FIELDS.mrpType}
                                />
                            </FormGroup>
                        </div>

                        <div className="col-12 md:col-6">
                            <FormGroup htmlFor="runName" label={t('Run Name')} required>
                                <ControlledInputText
                                    name="runName"
                                    control={control}
                                    inputId="runName"
                                    placeholder={t('e.g. Monday VB Run')}
                                    rules={FIELDS.runName}
                                />
                            </FormGroup>
                        </div>

                        <div className="col-12 md:col-6">
                            <FormGroup htmlFor="scheduleType" label={t('Schedule Type')} required>
                                <ControlledDropdown
                                    name="scheduleType"
                                    control={control}
                                    inputId="scheduleType"
                                    options={SCHEDULE_TYPE_OPTIONS}
                                    placeholder={t('Select schedule type')}
                                    rules={FIELDS.scheduleType}
                                />
                            </FormGroup>
                        </div>

                        <div className="col-12 md:col-6">
                            {scheduleType === 'MONTHLY' ? (
                                <FormGroup htmlFor="dayOfMonth" label={t('Day of Month')} required>
                                    <ControlledInputNumber
                                        name="dayOfMonth"
                                        control={control}
                                        inputId="dayOfMonth"
                                        min={1}
                                        max={28}
                                        rules={FIELDS.dayOfMonth}
                                    />
                                </FormGroup>
                            ) : (
                                <FormGroup htmlFor="dayOfWeek" label={t('Day of Week')} required>
                                    <ControlledDropdown
                                        name="dayOfWeek"
                                        control={control}
                                        inputId="dayOfWeek"
                                        options={WEEKDAY_OPTIONS}
                                        placeholder={t('Select day')}
                                        rules={FIELDS.dayOfWeek}
                                    />
                                </FormGroup>
                            )}
                        </div>

                        <div className="col-12 md:col-6">
                            <FormGroup htmlFor="warehouseIds" label={t('Warehouse IDs')}>
                                <ControlledInputText
                                    name="warehouseIds"
                                    control={control}
                                    inputId="warehouseIds"
                                    placeholder={t('Optional - comma separated')}
                                />
                            </FormGroup>
                        </div>

                        <div className="col-12 md:col-6">
                            <FormGroup htmlFor="createdBy" label={t('Created By')} required>
                                <ControlledInputText
                                    name="createdBy"
                                    control={control}
                                    inputId="createdBy"
                                    placeholder={t('Enter creator name')}
                                    rules={FIELDS.createdBy}
                                />
                            </FormGroup>
                        </div>

                        <div className="col-12 md:col-6">
                            <FormGroup htmlFor="regenerative" label={t('Regenerative')}>
                                <ControlledInputSwitch
                                    name="regenerative"
                                    control={control}
                                    inputId="regenerative"
                                />
                            </FormGroup>
                        </div>
                    </div>
                </Card>
            </PageLayout.Content>

            <PageLayout.Footer align="right">
                <Button
                    label={t('Save Schedule')}
                    icon="pi pi-save"
                    onClick={handleSubmit(onSubmit)}
                    loading={isPending}
                />
            </PageLayout.Footer>

            <Dialog
                header={t('Schedule Created Successfully')}
                visible={dialogVisible}
                modal
                onHide={hideDialog}
                footer={dialogFooter}
            >
                {responseData && (
                    <div className="flex flex-column gap-3">
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('MRP Type')}:
                            </span>
                            <Tag value={responseData.mrpType} severity="info" />
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Schedule ID')}:
                            </span>
                            <span className="text-900 font-medium">{responseData.scheduleId}</span>
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Run Name')}:
                            </span>
                            <span className="text-900">{responseData.runName}</span>
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Plant ID')}:
                            </span>
                            <span className="text-900">{responseData.plantId}</span>
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Schedule Type')}:
                            </span>
                            <Tag
                                value={
                                    responseData.scheduleType === 'WEEKLY'
                                        ? t('Weekly')
                                        : t('Monthly')
                                }
                                severity="info"
                            />
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {responseData.scheduleType === 'WEEKLY'
                                    ? t('Day of Week')
                                    : t('Day of Month')}
                                :
                            </span>
                            <span className="text-900">
                                {responseData.scheduleType === 'WEEKLY'
                                    ? WEEKDAY_OPTIONS.find(
                                          (o) => o.value === responseData.dayOfWeek,
                                      )?.label || responseData.dayOfWeek
                                    : responseData.dayOfMonth}
                            </span>
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Cron Expression')}:
                            </span>
                            <span className="text-900">{responseData.cronExpr}</span>
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Created At')}:
                            </span>
                            <span className="text-900">
                                {new Date(responseData.createdAt).toLocaleString()}
                            </span>
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Regenerative')}:
                            </span>
                            <Tag
                                value={responseData.regenerative ? t('Yes') : t('No')}
                                severity={responseData.regenerative ? 'info' : 'contrast'}
                            />
                        </div>
                        <div className="flex align-items-center gap-2">
                            <span className="font-semibold text-color-secondary w-8rem">
                                {t('Active')}:
                            </span>
                            <Tag
                                value={responseData.isActive ? t('Active') : t('Inactive')}
                                severity={responseData.isActive ? 'success' : 'danger'}
                            />
                        </div>
                        {responseData.warehouseIds && (
                            <div className="flex align-items-center gap-2">
                                <span className="font-semibold text-color-secondary w-8rem">
                                    {t('Warehouse IDs')}:
                                </span>
                                <span className="text-900">{responseData.warehouseIds}</span>
                            </div>
                        )}
                    </div>
                )}
            </Dialog>
        </PageLayout>
    );
};

export default MRPConfigurationPage;
