import React, { useState, useMemo, useCallback } from 'react';
import PropTypes from 'prop-types';

import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { TabView, TabPanel } from 'primereact/tabview';
import { classNames } from 'primereact/utils';

import { useT, useSafeContext, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { PageLayout, DynamicHeightWrapper, Card, useAppToast } from '@shared/components';

import MRPOutputDetails from '../components/MRPOutputDetails';

/* ===========================
    Constants
=========================== */
const PLANT_ID = 'TEST_SBU';

const STATUS_STYLE = {
    PENDING: {
        backgroundColor: 'var(--yellow-100)',
        color: 'var(--yellow-700)',
        borderRadius: '6px',
        padding: '4px 8px',
    },
    COMPLETED: {
        backgroundColor: 'var(--green-100)',
        color: 'var(--green-700)',
        borderRadius: '6px',
        padding: '4px 8px',
    },
    FAILED: {
        backgroundColor: 'var(--red-100)',
        color: 'var(--red-700)',
        borderRadius: '6px',
        padding: '4px 8px',
    },
    IN_PROGRESS: {
        backgroundColor: 'var(--blue-100)',
        color: 'var(--blue-700)',
        borderRadius: '6px',
        padding: '4px 8px',
    },
};

/* ===========================
    Sub Components
=========================== */
function StatusTag({ status }) {
    const style = STATUS_STYLE[status] ?? {};
    return <Tag value={status} style={style} className="text-xs" />;
}
StatusTag.propTypes = { status: PropTypes.string.isRequired };

function FlagChip({ active, label }) {
    return (
        <span
            className={classNames(
                'border-round-sm px-2 py-1 text-xs font-medium',
                active ? 'bg-primary text-white' : 'bg-surface-200 text-color-secondary',
            )}
        >
            {label}
        </span>
    );
}
FlagChip.propTypes = {
    active: PropTypes.bool.isRequired,
    label: PropTypes.string.isRequired,
};

/* ===========================
    Main Page
=========================== */
const MRPPlanningRunPage = () => {
    const { t } = useT();
    const { authToken } = useSafeContext(AuthContext);
    const { success, error: toastError } = useAppToast();

    const [vbVmSelectedRows, setVbVmSelectedRows] = useState([]);
    const [pdSelectedRows, setPdSelectedRows] = useState([]);
    const [isRunning, setIsRunning] = useState(false);

    // Success data after MRP run
    const [runSuccessData, setRunSuccessData] = useState(null);
    const [showOutputDetails, setShowOutputDetails] = useState(false);

    const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);

    /* ===========================
        API Hooks
    =========================== */
    const {
        data: planningFilesResponse,
        isFetching: isLoading,
        error,
        refetch,
    } = useReadApi({
        service: 'mrp',
        endpoint: '/api/mrp/planning-file/get-planningFile',
        method: 'POST',
        body: useMemo(() => ({ requestInfo: { authToken } }), [authToken]),
        headers: authHeaders,
        enabled: !!authToken,
    });

    const { mutateAsync: executeMrpRun } = useMutationApi({
        service: 'mrp',
        endpoint: '/api/mrp/mrp_run',
        method: 'POST',
        headers: authHeaders,
    });

    const planningFiles = useMemo(() => {
        const response = planningFilesResponse;
        return Array.isArray(response)
            ? response
            : Array.isArray(response?.data)
              ? response.data
              : [];
    }, [planningFilesResponse]);

    const vbVmFiles = useMemo(
        () => planningFiles.filter((f) => f.mrpType === 'VB' || f.mrpType === 'VM'),
        [planningFiles],
    );

    const pdFiles = useMemo(() => planningFiles.filter((f) => f.mrpType === 'PD'), [planningFiles]);

    const allSelectedRows = useMemo(
        () => [...vbVmSelectedRows, ...pdSelectedRows],
        [vbVmSelectedRows, pdSelectedRows],
    );

    /* ===========================
        Handlers
    =========================== */
    const handleVbVmSelectionChange = useCallback((e) => {
        setVbVmSelectedRows(e.value);
    }, []);

    const handlePdSelectionChange = useCallback((e) => {
        setPdSelectedRows(e.value);
    }, []);

    const handleRun = useCallback(async () => {
        if (!allSelectedRows.length) return;

        try {
            setIsRunning(true);

            const payload = {
                requestInfo: { authToken },
                planningFiles: allSelectedRows.map((row) => ({
                    inventoryChangedFlag: row.inventoryChangedFlag ?? false,
                    itemId: row.itemId,
                    mrpType: row.mrpType,
                    pfId: row.pfId,
                    plantId: row.plantId || PLANT_ID,
                    saleOrderId: row.saleOrderId,
                    priority: row.priority ?? 1,
                    safetyStockChangedFlag: row.safetyStockChangedFlag ?? false,
                    status: row.status,
                    ...(row.mrpType === 'PD' && {
                        quantity: Number(row.quantity) || 0,
                    }),
                })),
            };

            const result = await executeMrpRun(payload);

            setRunSuccessData(result);
            setVbVmSelectedRows([]);
            setPdSelectedRows([]);

            success(t('Success'), t('MRP Run completed successfully.'));
        } catch (err) {
            console.error('MRP Run Error:', err);
            toastError(t('Error'), err.message || t('Failed to execute MRP run'));
        } finally {
            setIsRunning(false);
        }
    }, [allSelectedRows, authToken, executeMrpRun, t, success, toastError]);

    const handleBackToList = useCallback(() => {
        setRunSuccessData(null);
        setShowOutputDetails(false);
        refetch();
    }, [refetch]);

    const handleViewRunDetails = useCallback(() => {
        if (runSuccessData?.runID) {
            setShowOutputDetails(true);
        }
    }, [runSuccessData]);

    /* ===========================
        Body Templates
    =========================== */
    const statusBodyTemplate = useCallback((row) => <StatusTag status={row.status} />, []);

    // const changeFlagsBodyTemplate = useCallback(
    //     (row) => (
    //         <div className="flex gap-2">
    //             <FlagChip active={!!row.inventoryChangedFlag} label={t('Inv')} />
    //             <FlagChip active={!!row.safetyStockChangedFlag} label={t('SS')} />
    //         </div>
    //     ),
    //     [t],
    // );

    /* ===========================
        Sub-Views
    =========================== */
    if (showOutputDetails && runSuccessData?.runID) {
        return <MRPOutputDetails runId={runSuccessData.runID} onBack={handleBackToList} />;
    }

    if (runSuccessData) {
        return (
            <PageLayout>
                <PageLayout.Header
                    title={runSuccessData.message || t('MRP Run Completed Successfully!')}
                    subtitle={t('Run details are shown below.')}
                    status={<Tag value={runSuccessData.status || 'SUCCESS'} severity="success" />}
                    actions={
                        <Button
                            label={t('Back to Planning Files')}
                            icon="pi pi-arrow-left"
                            onClick={handleBackToList}
                            outlined
                        />
                    }
                />
                <PageLayout.Content>
                    <Card title={t('MRP Run Summary')}>
                        <div className="grid">
                            <div className="col-12 md:col-6">
                                <p className="mb-2">
                                    <span className="font-semibold text-color-secondary mr-2">
                                        {t('MRP Run ID')}:
                                    </span>
                                    <span className="text-900">{runSuccessData.runID}</span>
                                </p>
                            </div>
                            <div className="col-12 md:col-6">
                                <p className="mb-2">
                                    <span className="font-semibold text-color-secondary mr-2">
                                        {t('Timestamp')}:
                                    </span>
                                    <span className="text-900">
                                        {runSuccessData.timestamp
                                            ? new Date(runSuccessData.timestamp).toLocaleString()
                                            : new Date().toLocaleString()}
                                    </span>
                                </p>
                            </div>
                        </div>
                    </Card>

                    <div className="mt-2">
                        <Button
                            label={t('View MRP Run Details')}
                            icon="pi pi-list"
                            onClick={handleViewRunDetails}
                            severity="info"
                        />
                    </div>
                </PageLayout.Content>
            </PageLayout>
        );
    }

    if (error) {
        return (
            <PageLayout>
                <PageLayout.Header title={t('MRP Planning Run')} />
                <PageLayout.Content>
                    <div className="flex flex-column align-items-center justify-content-center gap-3 py-8">
                        <i className="pi pi-exclamation-triangle text-4xl text-red-500" />
                        <p className="text-center font-medium text-lg m-0">
                            {error?.message || t('Failed to load planning files.')}
                        </p>
                        <Button
                            label={t('Retry')}
                            icon="pi pi-refresh"
                            onClick={refetch}
                            outlined
                        />
                    </div>
                </PageLayout.Content>
            </PageLayout>
        );
    }

    /* ===========================
        Main List View
    =========================== */
    return (
        <PageLayout>
            <PageLayout.Header
                title={t('MRP Planning Run')}
                subtitle={t('Select planning files and execute the MRP run.')}
                actions={
                    <div className="flex gap-2">
                        <Button
                            icon="pi pi-refresh"
                            outlined
                            severity="secondary"
                            onClick={refetch}
                            loading={isLoading}
                            aria-label={t('Refresh')}
                        />
                        <Button
                            label={t('Run MRP')}
                            icon="pi pi-play"
                            onClick={handleRun}
                            loading={isRunning}
                            disabled={!allSelectedRows.length || isRunning}
                        />
                    </div>
                }
            />

            <PageLayout.Content>
                <DynamicHeightWrapper>
                    {(h) => (
                        <TabView>
                            <TabPanel header="Manual/Automatic Reorder MRP[VB/VM]">
                                <DataTable
                                    value={vbVmFiles}
                                    selection={vbVmSelectedRows}
                                    onSelectionChange={handleVbVmSelectionChange}
                                    selectionMode="multiple"
                                    dataKey="pfId"
                                    loading={isLoading}
                                    showGridlines
                                    stripedRows
                                    scrollable
                                    scrollHeight={h}
                                    emptyMessage={t('No VB/VM planning files found.')}
                                >
                                    <Column selectionMode="multiple" />
                                    <Column
                                        field="saleOrderId"
                                        header={t('Sale Oder ID')}
                                        sortable
                                    />
                                    <Column field="itemId" header={t('Item ID')} sortable />
                                    <Column field="mrpType" header={t('MRP Type')} sortable />
                                    <Column field="quantity" header={t('Quantity')} sortable />
                                    <Column
                                        field="status"
                                        header={t('Status')}
                                        body={statusBodyTemplate}
                                        sortable
                                    />
                                    <Column field="plantId" header={t('Plant ID')} sortable />
                                    <Column field="createdBy" header={t('Created By')} sortable />
                                </DataTable>
                            </TabPanel>
                            <TabPanel header="Planned MRP[PD]">
                                <DataTable
                                    value={pdFiles}
                                    selection={pdSelectedRows}
                                    onSelectionChange={handlePdSelectionChange}
                                    selectionMode="multiple"
                                    dataKey="pfId"
                                    loading={isLoading}
                                    showGridlines
                                    stripedRows
                                    scrollable
                                    scrollHeight={h}
                                    emptyMessage={t('No PD planning files found.')}
                                >
                                    <Column selectionMode="multiple" />
                                    <Column
                                        field="saleOrderId"
                                        header={t('Sale Oder ID')}
                                        sortable
                                    />
                                    <Column field="itemId" header={t('Item ID')} sortable />
                                    <Column field="mrpType" header={t('MRP Type')} sortable />
                                    <Column field="quantity" header={t('Quantity')} sortable />
                                    <Column
                                        field="status"
                                        header={t('Status')}
                                        body={statusBodyTemplate}
                                        sortable
                                    />
                                    <Column field="plantId" header={t('Plant ID')} sortable />
                                    <Column field="createdBy" header={t('Created By')} sortable />
                                </DataTable>
                            </TabPanel>
                        </TabView>
                    )}
                </DynamicHeightWrapper>
            </PageLayout.Content>
        </PageLayout>
    );
};

export default MRPPlanningRunPage;
