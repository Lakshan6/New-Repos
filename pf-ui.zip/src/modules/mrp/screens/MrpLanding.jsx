import React from 'react';
import { PageLayout, Card } from '@shared/components';
import { useT } from '@shared/hooks';

const MrpLanding = () => {
    const { t } = useT();

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('MRP Landing Page')}
                subtitle={t('Welcome to the Material Requirements Planning module.')}
            />
            <PageLayout.Content>
                <Card>
                    <p className="m-0">
                        {t(
                            'Use the sidebar to navigate through MRP runs, planning files, and demand forecasting.',
                        )}
                    </p>
                </Card>
            </PageLayout.Content>
        </PageLayout>
    );
};

export default MrpLanding;
