import { useState, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { useNavigate } from 'react-router-dom';

import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';

import { useT, useSafeContext, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { PageLayout, Card, useAppToast } from '@shared/components';

const MaterialForecastOutputPage = ({ forecastRunResult, onBack }) => {
    const { t } = useT();
    const navigate = useNavigate(); // Hook initialized to manage page redirection
    const { success, error: toastError } = useAppToast();
    const [isMrpRunning, setIsMrpRunning] = useState(false);

    const { authToken, tenantIds } = useSafeContext(AuthContext);
    const selectedTenantId = tenantIds?.[0] || 'TEST_SBU';

    /* =========================== API Hooks =========================== */
    const { mutateAsync: executeMrpRun } = useMutationApi({
        service: 'mrp',
        endpoint: '/api/mrp/mrp_run',
        method: 'POST',
        headers: useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]),
    });

    /* =========================== Execute MRP Run =========================== */
    const handleExecuteMrpRun = useCallback(async () => {
        if (!forecastRunResult?.forecastResults?.length) return;

        try {
            setIsMrpRunning(true);

            const payload = {
                requestInfo: { authToken },
                planningFiles: forecastRunResult.forecastResults.map((row) => {
                    const currentMrpType = row.mrpType || 'PD';
                    const targetQuantity = row.forecastQty ?? row.quantity ?? 0;

                    return {
                        inventoryChangedFlag: row.inventoryChangedFlag ?? false,
                        itemId: row.itemId,
                        mrpType: currentMrpType,
                        pfId: row.forecastId || row.pfId,
                        plantId: row.plantId || selectedTenantId,
                        saleOrderId: row.saleOrderId ?? null,
                        priority: row.priority ?? 1,
                        safetyStockChangedFlag: row.safetyStockChangedFlag ?? false,
                        status: row.status || 'PENDING',
                        ...(currentMrpType === 'PD' && {
                            quantity: Number(targetQuantity) || 0,
                        }),
                    };
                }),
            };

            await executeMrpRun(payload);
            success(t('Success'), t('MRP Run completed successfully. Redirecting...'));

            navigate('/web/landing/mrp/mrp-report', {
                state: { triggerRefetch: true },
            });
        } catch (err) {
            console.error('MRP Run Error:', err);
            toastError(t('Error'), err.message || t('Failed to execute MRP run'));
        } finally {
            setIsMrpRunning(false);
        }
    }, [
        forecastRunResult,
        authToken,
        selectedTenantId,
        executeMrpRun,
        success,
        t,
        navigate,
        toastError,
    ]);

    /* =========================== Column Templates =========================== */
    const periodStartBody = useCallback(
        (row) => (row.periodStart ? new Date(row.periodStart).toLocaleDateString() : '-'),
        [],
    );

    const periodEndBody = useCallback(
        (row) => (row.periodEnd ? new Date(row.periodEnd).toLocaleDateString() : '-'),
        [],
    );

    const forecastQtyBody = useCallback(
        (row) => <span className="text-primary font-bold">{row.forecastQty?.toFixed(3)}</span>,
        [],
    );

    const confidencePctBody = useCallback((row) => `${row.confidencePct || 0}%`, []);

    if (!forecastRunResult) return null;

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('Forecast Run Execution Details')}
                subtitle={`${t('Review forecast breakdowns for plant')} ${forecastRunResult.plantId || selectedTenantId}`}
                status={<Tag value={forecastRunResult.status || 'COMPLETED'} severity="success" />}
                actions={
                    <div className="flex gap-2">
                        <Button
                            label={t('Back')}
                            icon="pi pi-arrow-left"
                            onClick={onBack}
                            outlined
                            severity="secondary"
                        />
                        <Button
                            label={t('Run MRP')}
                            icon="pi pi-play"
                            onClick={handleExecuteMrpRun}
                            loading={isMrpRunning}
                        />
                    </div>
                }
            />

            <PageLayout.Content>
                {/* Execution Summary Metadata */}
                <Card title={t('Execution Summary')}>
                    <div className="grid row-gap-3 text-sm">
                        <div className="col-12 sm:col-6 md:col-3">
                            <div className="font-semibold text-color-secondary mb-1">
                                {t('Run Reference ID')}
                            </div>
                            <div className="text-900 font-mono text-xs">
                                {forecastRunResult.forecastRunId}
                            </div>
                        </div>
                        <div className="col-12 sm:col-6 md:col-3">
                            <div className="font-semibold text-color-secondary mb-1">
                                {t('Model Engine')}
                            </div>
                            <div className="text-900">
                                <Tag value={forecastRunResult.modelType} severity="info" />
                            </div>
                        </div>
                        <div className="col-12 sm:col-6 md:col-3">
                            <div className="font-semibold text-color-secondary mb-1">
                                {t('Horizon Interval')}
                            </div>
                            <div className="text-900">
                                {forecastRunResult.horizonDays} {t('Days')}
                            </div>
                        </div>
                        <div className="col-12 sm:col-6 md:col-3">
                            <div className="font-semibold text-color-secondary mb-1">
                                {t('Buckets Formed')}
                            </div>
                            <div className="text-900">{forecastRunResult.recordsGenerated}</div>
                        </div>
                    </div>
                </Card>

                {/* Output Data Table Breakdown */}
                <Card title={t('Generated Forecast Data Items')}>
                    <DataTable
                        value={forecastRunResult.forecastResults || []}
                        showGridlines
                        stripedRows
                        responsiveLayout="scroll"
                        emptyMessage={t('No forecast breakdown configurations available.')}
                    >
                        <Column field="itemId" header={t('Item Code')} className="font-semibold" />
                        <Column
                            field="periodStart"
                            header={t('Start Date')}
                            body={periodStartBody}
                        />
                        <Column field="periodEnd" header={t('End Date')} body={periodEndBody} />
                        <Column field="bucketType" header={t('Bucket Size')} />
                        <Column
                            field="forecastQty"
                            header={t('Forecast Quantity')}
                            body={forecastQtyBody}
                        />
                        <Column
                            field="confidencePct"
                            header={t('Confidence %')}
                            body={confidencePctBody}
                        />
                    </DataTable>
                </Card>
            </PageLayout.Content>
        </PageLayout>
    );
};

MaterialForecastOutputPage.propTypes = {
    forecastRunResult: PropTypes.object,
    onBack: PropTypes.func.isRequired,
};

export default MaterialForecastOutputPage;
