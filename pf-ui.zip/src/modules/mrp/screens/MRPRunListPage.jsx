import { useState, useRef, useMemo, useCallback } from 'react';
import { useNavigate } from 'react-router';
import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { Dropdown } from 'primereact/dropdown';
import { OverlayPanel } from 'primereact/overlaypanel';
import { Calendar } from 'primereact/calendar';
import { Paginator } from 'primereact/paginator';
import { useT, useSafeContext, useReadApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { PageLayout } from '@shared/components';
import MRPOutputDetails from '../components/MRPOutputDetails';

const STATUS_OPTIONS = [
    { label: 'Completed', value: 'COMPLETED' },
    { label: 'In Progress', value: 'IN_PROGRESS' },
    { label: 'Failed', value: 'FAILED' },
    { label: 'Pending', value: 'PENDING' },
];

const INITIAL_FORM = {
    status: '',
    runId: '',
    runDate: null,
};

const ITEMS_PER_PAGE = 9;

const getStatusBadgeClass = (status) => {
    switch (status) {
        case 'FAILED':
            return 'bg-red-100 text-red-700';
        case 'IN_PROGRESS':
            return 'bg-blue-100 text-blue-700';
        case 'PENDING':
            return 'bg-orange-100 text-orange-700';
        case 'COMPLETED':
        default:
            return 'bg-green-100 text-green-700';
    }
};
const getStatusIcon = (status) => {
    switch (status) {
        case 'FAILED':
            return 'pi pi-exclamation-triangle text-red-500';
        case 'PENDING':
            return 'pi pi-clock text-orange-500';
        case 'IN_PROGRESS':
            return 'pi pi-cog text-blue-500';
        case 'COMPLETED':
        default:
            return 'pi pi-check-circle text-green-500';
    }
};

const MRPRunListPage = () => {
    const navigate = useNavigate();
    const { t } = useT();
    const op = useRef(null);
    const { authToken } = useSafeContext(AuthContext);

    const [searchForm, setSearchForm] = useState(INITIAL_FORM);
    const [first, setFirst] = useState(0);
    const [rows, setRows] = useState(ITEMS_PER_PAGE);
    const [selectedRunId, setSelectedRunId] = useState(null);

    const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);

    const { data: runsResponse, isFetching: isLoading } = useReadApi({
        service: 'mrp',
        endpoint: '/api/mrp/runs/read',
        method: 'POST',
        body: useMemo(() => ({ requestInfo: { authToken } }), [authToken]),
        headers: authHeaders,
        enabled: !!authToken,
    });

    const allRuns = useMemo(() => {
        const response = runsResponse;
        return Array.isArray(response)
            ? response
            : Array.isArray(response?.data)
              ? response.data
              : [];
    }, [runsResponse]);

    const filteredRuns = useMemo(() => {
        let result = allRuns;

        if (searchForm.runId) {
            const query = searchForm.runId.toLowerCase();
            result = result.filter(
                (r) =>
                    String(r.mrpRunId ?? '')
                        .toLowerCase()
                        .includes(query) ||
                    String(r.runName ?? '')
                        .toLowerCase()
                        .includes(query),
            );
        }
        if (searchForm.status) {
            result = result.filter((r) => r.status === searchForm.status);
        }
        if (searchForm.runDate) {
            const filterDate =
                searchForm.runDate instanceof Date
                    ? searchForm.runDate.toISOString().split('T')[0]
                    : searchForm.runDate;
            result = result.filter((r) => {
                if (!r.runDate) return false;
                const runDateStr = new Date(r.runDate).toISOString().split('T')[0];
                return runDateStr === filterDate;
            });
        }

        return [...result].sort((a, b) => {
            const statusOrder = { IN_PROGRESS: 0, COMPLETED: 1, FAILED: 2, PENDING: 3 };
            const orderDiff = (statusOrder[a.status] ?? 3) - (statusOrder[b.status] ?? 3);
            if (orderDiff !== 0) return orderDiff;
            const dateA = a.runDate ? new Date(a.runDate).getTime() : 0;
            const dateB = b.runDate ? new Date(b.runDate).getTime() : 0;
            return dateB - dateA;
        });
    }, [allRuns, searchForm]);

    const paginatedRuns = useMemo(() => {
        return filteredRuns.slice(first, first + rows);
    }, [filteredRuns, first, rows]);

    const updateForm = useCallback((field, value) => {
        setFirst(0);
        setSearchForm((prev) => ({ ...prev, [field]: value }));
    }, []);

    const handleCloseDetails = useCallback(() => setSelectedRunId(null), []);
    const handleViewRun = useCallback((e) => setSelectedRunId(e.currentTarget.dataset.runId), []);

    const handleClear = useCallback(() => {
        setFirst(0);
        setSearchForm(INITIAL_FORM);
    }, []);

    const onPageChange = useCallback((event) => {
        setFirst(event.first);
        setRows(event.rows);
    }, []);

    const handleToggleFilters = useCallback((e) => op.current.toggle(e), []);
    const handleCreateRun = useCallback(
        () => navigate('/web/landing/mrp/planning-files'),
        [navigate],
    );
    const handleStatusChange = useCallback((e) => updateForm('status', e.value), [updateForm]);
    const handleRunDateChange = useCallback((e) => updateForm('runDate', e.value), [updateForm]);

    const pageActions = useMemo(
        () => (
            <div className="flex gap-2 align-items-center">
                <Button
                    type="button"
                    icon="pi pi-filter"
                    label={t('Filter')}
                    outlined
                    onClick={handleToggleFilters}
                    className="p-button-sm text-secondary"
                />
                <Button
                    label={t('Run Now MRP')}
                    icon="pi pi-play"
                    onClick={handleCreateRun}
                    className="p-button-sm bg-blue-800 border-blue-800 ml-2"
                />

                <OverlayPanel ref={op} showCloseIcon dismissable className="w-25rem">
                    <div className="grid p-fluid">
                        <div className="col-12 mb-2">
                            <label className="block text-sm font-medium mb-1">{t('Status')}</label>
                            <Dropdown
                                value={searchForm.status}
                                options={STATUS_OPTIONS}
                                onChange={handleStatusChange}
                                placeholder={t('Select Status')}
                                className="p-inputtext-sm"
                                showClear
                            />
                        </div>
                        <div className="col-12 mb-2">
                            <label className="block text-sm font-medium mb-1">
                                {t('Run Date')}
                            </label>
                            <Calendar
                                value={searchForm.runDate}
                                onChange={handleRunDateChange}
                                className="p-inputtext-sm"
                                showIcon
                                placeholder="dd/mm/yyyy"
                                dateFormat="dd/mm/yy"
                            />
                        </div>
                        <div className="col-12 mt-2 flex justify-content-end gap-2">
                            <Button
                                type="button"
                                label={t('Reset')}
                                outlined
                                onClick={handleClear}
                                className="p-button-sm text-secondary"
                            />
                        </div>
                    </div>
                </OverlayPanel>
            </div>
        ),
        [
            t,
            handleToggleFilters,
            handleCreateRun,
            searchForm,
            handleStatusChange,
            handleRunDateChange,
            handleClear,
        ],
    );

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('MRP Run Results')}
                subtitle={t('View all Material Requirements Planning (MRP) run results.')}
                actions={pageActions}
            />

            <PageLayout.Content>
                {isLoading ? (
                    <div className="text-center p-5">
                        <i className="pi pi-spinner pi-spin text-2xl" />
                    </div>
                ) : filteredRuns.length === 0 ? (
                    <div className="text-center p-5 text-muted">{t('No MRP runs found.')}</div>
                ) : (
                    <div className="grid flex-1 overflow-hidden">
                        <div className={`col-12 ${selectedRunId ? 'lg:col-6 overflow-auto' : ''}`}>
                            <div className="grid">
                                {paginatedRuns.map((run, index) => (
                                    <div
                                        key={run.mrpRunId}
                                        className={`col-12 ${selectedRunId ? 'md:col-12 lg:col-6' : 'sm:col-6 lg:col-4'} p-2`}
                                    >
                                        <div
                                            className={`surface-card p-3 border-round shadow-1 h-full flex flex-column justify-content-between ${selectedRunId === run.mrpRunId ? 'border-1 border-primary' : ''}`}
                                        >
                                            <div>
                                                <div className="flex justify-content-between align-items-center mb-2">
                                                    <div className="flex align-items-center gap-2">
                                                        <i
                                                            className={`${getStatusIcon(run.status)} text-xl`}
                                                        />
                                                        <span className="font-bold text-lg text-900">
                                                            {run.mrpRunId}
                                                        </span>
                                                    </div>
                                                    {index === 0 && (
                                                        <Tag
                                                            value={t('Latest')}
                                                            severity="info"
                                                            className="mr-1"
                                                        />
                                                    )}
                                                    <span
                                                        className={`text-xs font-semibold px-2 py-1 border-round ${getStatusBadgeClass(run.status)}`}
                                                    >
                                                        {run.status || 'Unknown'}
                                                    </span>
                                                </div>

                                                <div className="text-sm font-medium text-700 mb-3">
                                                    {run.runName || t('Monthly Plan')}
                                                </div>

                                                <div className="text-xs text-600  flex align-items-center gap-2">
                                                    <i className="pi pi-calendar text-400" />
                                                    <span>
                                                        <strong>{t('Run Date:')}</strong>{' '}
                                                        {run.runDate
                                                            ? new Date(run.runDate).toLocaleString()
                                                            : '—'}
                                                    </span>
                                                </div>

                                                {run.status === 'FAILED' && (
                                                    <div className="bg-red-50 text-red-700 text-xs p-2 border-round border-1 border-red-200 mt-2 mb-1">
                                                        <strong>{t('Error:')}</strong>{' '}
                                                        {run.errorMessage ||
                                                            t(
                                                                'Missing BOM items. Please fix issues and rerun.',
                                                            )}
                                                    </div>
                                                )}

                                                {(run.status === 'PENDING' ||
                                                    run.status === 'IN_PROGRESS') && (
                                                    <div className="mt-2 mb-1">
                                                        {/* <div className="flex justify-content-between text-xs font-semibold mb-1">
                                                            <span>{t('Progress')}</span>
                                                            <span>{run.progress || 0}%</span>
                                                        </div>
                                                        <ProgressBar
                                                            value={run.progress || 0}
                                                            showValue={false}
                                                            style={PROGRESS_BAR_STYLE}
                                                        />
                                                        <div className="text-xs text-600 mt-2">
                                                            {t('Materials Processed:')}{' '}
                                                            {run.materialsProcessed || 0} /{' '}
                                                            {run.materialsEvaluated || 0}
                                                        </div> */}
                                                    </div>
                                                )}
                                            </div>

                                            <div className="mt-3">
                                                <hr className="border-top-1 border-200 mb-2" />
                                                <div className="text-xs text-600 mb-2 flex justify-content-between">
                                                    <span>
                                                        <i className="pi pi-user mr-1 text-400" />
                                                        {run.executedBy || 'System'}
                                                    </span>
                                                </div>
                                                {run.status !== 'PENDING' && (
                                                    <div className="flex justify-content-end mt-2">
                                                        <Button
                                                            label={t('View Result')}
                                                            className="p-button-sm p-button-outlined text-xs p-1"
                                                            onClick={handleViewRun}
                                                            data-run-id={run.mrpRunId}
                                                        />
                                                    </div>
                                                )}
                                            </div>
                                        </div>
                                    </div>
                                ))}
                            </div>

                            <div className="flex align-items-center justify-content-center mt-4 pt-3 border-top-1 border-200">
                                <Paginator
                                    first={first}
                                    rows={rows}
                                    totalRecords={filteredRuns.length}
                                    onPageChange={onPageChange}
                                    className="bg-transparent border-none p-0"
                                />
                            </div>
                        </div>
                        {selectedRunId && (
                            <div className="col-12 lg:col-6 overflow-auto">
                                <MRPOutputDetails
                                    runId={selectedRunId}
                                    embedded
                                    onClose={handleCloseDetails}
                                />
                            </div>
                        )}
                    </div>
                )}
            </PageLayout.Content>
        </PageLayout>
    );
};

export default MRPRunListPage;
