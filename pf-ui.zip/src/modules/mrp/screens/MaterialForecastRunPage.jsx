import React, { useMemo, useEffect, useState, useCallback } from 'react';
import { useForm } from 'react-hook-form';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Checkbox } from 'primereact/checkbox';
import { Calendar } from 'primereact/calendar';
import { TabView, TabPanel } from 'primereact/tabview';
import PropTypes from 'prop-types';

import { useSafeContext, useT, useReadApi, useMutationApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { PageLayout, Card, useAppToast } from '@shared/components';
import {
    FormGroup,
    ControlledDropdown,
    ControlledCalendar,
    ControlledInputNumber,
} from '@shared/components/FormComponents';

// Importing the newly isolated output subcomponent screen
import MaterialForecastOutputPage from './MaterialForecastOutputPage';

/* ==========================================================================
   Forecast Control Fields Component
   ========================================================================== */
const ForecastControlFields = ({
    control,
    t,
    materialOptions,
    isMaterialsLoading,
    typeOptions,
    rules,
    forecastType,
    fromDate,
}) => (
    <Card title={t('Forecast Control Parameters')}>
        <div className="grid">
            <div className="col-12 md:col-6">
                <FormGroup htmlFor="material" label={t('Select Material')} required>
                    <ControlledDropdown
                        name="material"
                        control={control}
                        options={materialOptions}
                        optionLabel="label"
                        optionValue="value"
                        placeholder={t('Choose material...')}
                        loading={isMaterialsLoading}
                        filter
                        rules={rules.material}
                    />
                </FormGroup>
            </div>

            <div className="col-12 md:col-6">
                <FormGroup htmlFor="forecastType" label={t('Forecast Type')} required>
                    <ControlledDropdown
                        name="forecastType"
                        control={control}
                        options={typeOptions}
                        optionLabel="label"
                        optionValue="value"
                        placeholder={t('Select Type...')}
                        rules={rules.forecastType}
                    />
                </FormGroup>
            </div>

            <div className="col-12 md:col-6">
                <FormGroup htmlFor="fromDate" label={t('From Period')} required>
                    <ControlledCalendar
                        name="fromDate"
                        control={control}
                        disabled={!forecastType}
                        view={forecastType === 'YEARLY' ? 'year' : 'month'}
                        dateFormat={forecastType === 'YEARLY' ? 'yy' : 'mm/yy'}
                        placeholder={forecastType === 'YEARLY' ? 'YYYY' : 'MM/YYYY'}
                        rules={rules.fromDate}
                        showIcon
                    />
                </FormGroup>
            </div>

            <div className="col-12 md:col-6">
                <FormGroup htmlFor="toDate" label={t('To Period')} required>
                    <ControlledCalendar
                        name="toDate"
                        control={control}
                        disabled={!forecastType}
                        view={forecastType === 'YEARLY' ? 'year' : 'month'}
                        dateFormat={forecastType === 'YEARLY' ? 'yy' : 'mm/yy'}
                        placeholder={forecastType === 'YEARLY' ? 'YYYY' : 'MM/YYYY'}
                        minDate={fromDate || undefined}
                        rules={rules.toDate}
                        showIcon
                    />
                </FormGroup>
            </div>
        </div>
    </Card>
);

ForecastControlFields.propTypes = {
    control: PropTypes.object.isRequired,
    t: PropTypes.func.isRequired,
    materialOptions: PropTypes.array.isRequired,
    isMaterialsLoading: PropTypes.bool,
    typeOptions: PropTypes.array.isRequired,
    rules: PropTypes.object.isRequired,
    forecastType: PropTypes.string,
    fromDate: PropTypes.instanceOf(Date),
};

const AI_DIALOG_BREAKPOINTS = { '960px': '75vw', '641px': '90vw' };

/* ==========================================================================
   Main Page Workspace Component
   ========================================================================== */
const MaterialForecastRunPage = () => {
    const { t } = useT();
    const { success, warn, apiError } = useAppToast();
    const [activeIndex, setActiveIndex] = useState(0);
    const [forecastRunResult, setForecastRunResult] = useState(null);

    const [aiPlantId, setAiPlantId] = useState('');
    const [aiItemId, setAiItemId] = useState('');
    const [aiStartDate, setAiStartDate] = useState(null);
    const [aiEndDate, setAiEndDate] = useState(null);
    const [aiSafetyStock, setAiSafetyStock] = useState(false);
    const [aiForecastResult, setAiForecastResult] = useState(null);
    const [aiForecastDialogVisible, setAiForecastDialogVisible] = useState(false);
    const [isAiRunning, setIsAiRunning] = useState(false);

    const { control, handleSubmit, setValue, watch } = useForm({
        defaultValues: {
            material: null,
            forecastType: null,
            fromDate: null,
            toDate: null,
            bucketType: null,
            horizon: null,
            modelType: null,
            tableRecords: [],
        },
    });

    const selectedMaterial = watch('material');
    const forecastType = watch('forecastType');
    const fromDate = watch('fromDate');
    const toDate = watch('toDate');
    const tableRecords = watch('tableRecords');

    const { authToken, tenantIds } = useSafeContext(AuthContext);
    const selectedTenantId = tenantIds?.[0] || 'TEST_SBU';

    const rules = useMemo(
        () => ({
            material: { required: t('Material is required.') },
            forecastType: { required: t('Forecast Type is required.') },
            fromDate: { required: t('From period is required.') },
            toDate: { required: t('To period is required.') },
            bucketType: { required: t('Bucket Type is required.') },
            horizon: { required: t('Horizon is required.'), min: 1 },
            modelType: { required: t('Model Type is required.') },
        }),
        [t],
    );

    const headers = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);

    /* =========================== API Hooks =========================== */
    const { data: rawMaterials, isFetching: isMaterialsLoading } = useReadApi({
        service: 'material',
        endpoint: '/material/forecast-enabled',
        method: 'GET',
        headers,
    });

    const { mutateAsync: saveConsumptionHistory, isPending: isSaving } = useMutationApi({
        service: 'mrp',
        endpoint: '/api/mrp/forecast/consumption-history',
        method: 'POST',
        headers,
    });

    const { mutateAsync: fetchConsumptionHistory, isPending: isLoadingHistory } = useMutationApi({
        service: 'mrp',
        endpoint: '/api/mrp/forecast/consumption-history/read',
        method: 'POST',
        headers,
    });

    const { mutateAsync: executeForecastRun, isPending: isRunning } = useMutationApi({
        service: 'mrp',
        endpoint: '/api/mrp/forecast/run',
        method: 'POST',
        headers,
    });

    const { mutateAsync: runAverageDemandForecast } = useMutationApi({
        service: 'inv_ml',
        endpoint: '/api/v1/forecast/average-demand',
        method: 'POST',
        headers,
    });

    const { mutateAsync: runCombinedForecast } = useMutationApi({
        service: 'inv_ml',
        endpoint: '/api/v1/forecast/combined',
        method: 'POST',
        headers,
    });

    const materialOptions = useMemo(() => {
        if (!Array.isArray(rawMaterials)) return [];
        return rawMaterials.map((mat) => ({ label: mat, value: mat }));
    }, [rawMaterials]);

    const typeOptions = useMemo(
        () => [
            { label: t('Monthly'), value: 'MONTHLY' },
            { label: t('Yearly'), value: 'YEARLY' },
        ],
        [t],
    );

    const bucketOptions = useMemo(() => {
        if (!forecastType) return [];
        if (forecastType === 'MONTHLY') {
            return [
                { label: t('Monthly'), value: 'MONTH' },
                { label: t('Weekly'), value: 'WEEK' },
            ];
        }
        return [
            { label: t('Yearly'), value: 'YEAR' },
            { label: t('Monthly'), value: 'MONTH' },
            { label: t('Weekly'), value: 'WEEK' },
        ];
    }, [forecastType, t]);

    const modelOptions = useMemo(
        () => [
            { label: 'SMA (Simple Moving Average)', value: 'SMA' },
            { label: 'EMA (Exponential Moving Average)', value: 'EMA' },
            { label: 'WMA (Weighted Moving Average)', value: 'WMA' },
        ],
        [],
    );

    /* =========================== Dynamic Periods =========================== */
    const dynamicPeriods = useMemo(() => {
        if (!forecastType || !fromDate || !toDate) return [];

        const start = new Date(fromDate);
        const end = new Date(toDate);
        if (start > end) return [];

        const periods = [];
        let current = new Date(start);

        if (forecastType === 'MONTHLY') {
            while (current <= end) {
                const label = current.toLocaleString('default', {
                    month: 'short',
                    year: 'numeric',
                });
                const key = `${current.getFullYear()}-${String(current.getMonth() + 1).padStart(2, '0')}`;
                periods.push({ label, key });
                current.setMonth(current.getMonth() + 1);
            }
        } else {
            while (current.getFullYear() <= end.getFullYear()) {
                const yearStr = String(current.getFullYear());
                periods.push({ label: yearStr, key: yearStr });
                current.setFullYear(current.getFullYear() + 1);
            }
        }
        return periods;
    }, [forecastType, fromDate, toDate]);

    /* =========================== History Processing =========================== */
    const processConsumptionHistory = useCallback(
        (historyRecords) => {
            if (!dynamicPeriods.length) return;

            const historyMap = new Map();
            historyRecords.forEach((record) => {
                if (record.periodStart && record.consumedQty !== undefined) {
                    const key = record.periodStart.substring(0, 7);
                    historyMap.set(key, record.consumedQty);
                }
            });

            const updatedValues = {};
            dynamicPeriods.forEach((period) => {
                updatedValues[period.key] = historyMap.get(period.key) ?? 0;
            });

            setValue('tableRecords', [{ materialId: selectedMaterial, values: updatedValues }]);
        },
        [dynamicPeriods, selectedMaterial, setValue],
    );

    const resetTableToZeros = useCallback(() => {
        if (!dynamicPeriods.length) return;
        const periodValues = {};
        dynamicPeriods.forEach((period) => {
            periodValues[period.key] = 0;
        });

        setValue('tableRecords', [{ materialId: selectedMaterial, values: periodValues }]);
    }, [dynamicPeriods, selectedMaterial, setValue]);

    /* =========================== Auto Load Consumption History =========================== */
    useEffect(() => {
        const loadHistory = async () => {
            if (!selectedMaterial || !fromDate || !toDate || !selectedTenantId || !authToken)
                return;

            try {
                const payload = {
                    requestInfo: { authToken, tenantId: selectedTenantId },
                    itemId: selectedMaterial,
                    plantId: selectedTenantId,
                };

                const response = await fetchConsumptionHistory(payload);
                if (Array.isArray(response) && response.length > 0) {
                    processConsumptionHistory(response);
                } else {
                    resetTableToZeros();
                }
            } catch (err) {
                console.error('Failed to load consumption history', err);
                resetTableToZeros();
            }
        };

        loadHistory();
    }, [
        selectedMaterial,
        fromDate,
        toDate,
        selectedTenantId,
        authToken,
        fetchConsumptionHistory,
        processConsumptionHistory,
        resetTableToZeros,
    ]);

    /* =========================== Save Consumption =========================== */
    const onSaveConsumption = async (data) => {
        if (!data.tableRecords?.length) {
            warn(t('Warning'), t('Please enter consumption values.'));
            return;
        }

        try {
            const payload = {
                requestInfo: { tenantId: selectedTenantId },
                itemId: data.material,
                plantId: selectedTenantId,
                type: data.forecastType,
                fromDate: data.fromDate ? data.fromDate.toISOString() : null,
                toDate: data.toDate ? data.toDate.toISOString() : null,
                consumedQuantities: data.tableRecords[0]?.values || {},
            };

            await saveConsumptionHistory(payload);
            success(t('Success'), t('Consumption history saved successfully.'));
            setActiveIndex(1);
        } catch (err) {
            apiError(err, t('Failed to save consumption history.'));
        }
    };

    /* =========================== Run Forecast =========================== */
    const onRunForecast = async (data) => {
        try {
            const payload = {
                plantId: selectedTenantId,
                itemIds: [data.material],
                historyFrom: data.fromDate,
                historyTo: data.toDate,
                bucketType: data.bucketType,
                horizonDays: data.horizon,
                modelType: data.modelType,
            };

            const response = await executeForecastRun(payload);
            success(t('Success'), t('Forecast run executed successfully.'));
            setForecastRunResult(response);
        } catch (err) {
            apiError(err, t('Failed to run forecast.'));
        }
    };

    const onRunAIForecast = useCallback(async () => {
        if (!authToken) {
            warn(t('Warning'), t('Auth token is required. Please login again.'));
            return;
        }

        if (!aiPlantId || !aiItemId || !aiStartDate || !aiEndDate) {
            warn(t('Warning'), t('Please fill in all fields.'));
            return;
        }

        setIsAiRunning(true);

        const toDateStr = (date) => {
            if (!(date instanceof Date)) return date;

            const year = date.getFullYear();
            const month = String(date.getMonth() + 1).padStart(2, '0');
            const day = String(date.getDate()).padStart(2, '0');

            return `${year}-${month}-${day}`;
        };

        const payload = {
            requestInfo: { authToken },
            plantId: aiPlantId,
            itemId: aiItemId,
            startDate: toDateStr(aiStartDate),
            endDate: toDateStr(aiEndDate),
        };

        try {
            const result = aiSafetyStock
                ? await runCombinedForecast(payload)
                : await runAverageDemandForecast(payload);

            setAiForecastResult(result);
            setAiForecastDialogVisible(true);
            success(t('Success'), t('AI Forecast completed successfully.'));
        } catch (err) {
            apiError(err, t('Failed to run AI forecast.'));
        } finally {
            setIsAiRunning(false);
        }
    }, [
        authToken,
        aiPlantId,
        aiItemId,
        aiStartDate,
        aiEndDate,
        aiSafetyStock,
        runAverageDemandForecast,
        runCombinedForecast,
        t,
        warn,
        success,
        apiError,
    ]);

    const handleAiPlantIdChange = useCallback((e) => setAiPlantId(e.target.value), []);
    const handleAiItemIdChange = useCallback((e) => setAiItemId(e.target.value), []);
    const handleAiStartDateChange = useCallback((e) => setAiStartDate(e.value), []);
    const handleAiEndDateChange = useCallback((e) => setAiEndDate(e.value), []);
    const handleAiSafetyStockChange = useCallback((e) => setAiSafetyStock(e.checked), []);
    const handleHideAiForecastDialog = useCallback(() => setAiForecastDialogVisible(false), []);

    const aiForecastExpectedDemandBody = useCallback(
        (rowData) => rowData.expected_demand?.toFixed(2),
        [],
    );
    const aiForecastSafetyStockBody = useCallback(
        (rowData) => rowData.dynamic_safety_stock?.toFixed(2),
        [],
    );
    const aiForecastTotalInventoryBody = useCallback(
        (rowData) => rowData.total_recommended_inventory?.toFixed(2),
        [],
    );

    const renderCell = useCallback(
        (rowData, options) => {
            const { rowIndex, field } = options;
            return (
                <ControlledInputNumber
                    name={`tableRecords.${rowIndex}.values.${field}`}
                    control={control}
                    min={0}
                    placeholder="0"
                    className="w-full"
                />
            );
        },
        [control],
    );

    const handleTabChange = useCallback((e) => setActiveIndex(e.index), []);

    const handleBackToForm = useCallback(() => setForecastRunResult(null), []);

    /* ==========================================================================
       SUBVIEW SWITCH TRIGGER: Load Result Subscreen View
       ========================================================================== */
    if (forecastRunResult) {
        return (
            <MaterialForecastOutputPage
                forecastRunResult={forecastRunResult}
                onBack={handleBackToForm}
            />
        );
    }

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('Material Demand Forecasting')}
                subtitle={t('Manage consumption history and execute forecast runs.')}
               
            />

            <PageLayout.Content>
                <TabView activeIndex={activeIndex} onTabChange={handleTabChange}>
                    <TabPanel
                        header={t('Save Consumption History')}
                        className="flex flex-column gap-3"
                    >
                        <ForecastControlFields
                            control={control}
                            t={t}
                            materialOptions={materialOptions}
                            isMaterialsLoading={isMaterialsLoading}
                            typeOptions={typeOptions}
                            rules={rules}
                            forecastType={forecastType}
                            fromDate={fromDate}
                        />

                        {tableRecords.length > 0 && dynamicPeriods.length > 0 && (
                            <Card
                                title={`${t('Consumption Matrix Estimates Data Entry')} ${isLoadingHistory ? '(Loading...)' : ''}`}
                            >
                                <DataTable
                                    value={tableRecords}
                                    showGridlines
                                    stripedRows
                                    responsiveLayout="scroll"
                                >
                                    <Column
                                        field="materialId"
                                        header={t('Material Code')}
                                        frozen
                                        className="border-right-1 surface-border font-semibold"
                                    />
                                    {dynamicPeriods.map((period) => (
                                        <Column
                                            key={period.key}
                                            field={period.key}
                                            header={period.label}
                                            body={renderCell}
                                        />
                                    ))}
                                </DataTable>
                            </Card>
                        )}
                    </TabPanel>

                    <TabPanel header={t('Run Forecast')} className="flex flex-column gap-3">
                        <ForecastControlFields
                            control={control}
                            t={t}
                            materialOptions={materialOptions}
                            isMaterialsLoading={isMaterialsLoading}
                            typeOptions={typeOptions}
                            rules={rules}
                            forecastType={forecastType}
                            fromDate={fromDate}
                        />

                        {forecastType && (
                            <Card title={t('Horizon Days Information')}>
                                <div className="grid">
                                    <div className="col-12 md:col-6">
                                        <FormGroup
                                            htmlFor="bucketType"
                                            label={t('Bucket Type')}
                                            required
                                        >
                                            <ControlledDropdown
                                                name="bucketType"
                                                control={control}
                                                options={bucketOptions}
                                                optionLabel="label"
                                                optionValue="value"
                                                placeholder={t('Select Bucket Type...')}
                                                rules={rules.bucketType}
                                            />
                                        </FormGroup>
                                    </div>

                                    <div className="col-12 md:col-6">
                                        <FormGroup htmlFor="horizon" label={t('Horizon')} required>
                                            <ControlledInputNumber
                                                name="horizon"
                                                control={control}
                                                min={1}
                                                placeholder={t('Enter horizon count')}
                                                rules={rules.horizon}
                                            />
                                        </FormGroup>
                                    </div>

                                    <div className="col-12 md:col-6">
                                        <FormGroup
                                            htmlFor="modelType"
                                            label={t('Model Type')}
                                            required
                                        >
                                            <ControlledDropdown
                                                name="modelType"
                                                control={control}
                                                options={modelOptions}
                                                optionLabel="label"
                                                optionValue="value"
                                                placeholder={t('Select Model...')}
                                                rules={rules.modelType}
                                            />
                                        </FormGroup>
                                    </div>
                                </div>
                            </Card>
                        )}
                    </TabPanel>

                    <TabPanel header={t('AI Forecast')} className="flex flex-column gap-3">
                        <Card title={t('AI Forecast Parameters')}>
                            <div className="grid">
                                <div className="col-12 md:col-6">
                                    <div className="field">
                                        <label
                                            htmlFor="aiPlantId"
                                            className="font-medium text-700 mb-2 block"
                                        >
                                            {t('Plant ID')} <span className="text-red-500">*</span>
                                        </label>
                                        <InputText
                                            id="aiPlantId"
                                            value={aiPlantId}
                                            onChange={handleAiPlantIdChange}
                                            placeholder={t('Enter Plant ID')}
                                            className="w-full"
                                        />
                                    </div>
                                </div>

                                <div className="col-12 md:col-6">
                                    <div className="field">
                                        <label
                                            htmlFor="aiItemId"
                                            className="font-medium text-700 mb-2 block"
                                        >
                                            {t('Item ID')} <span className="text-red-500">*</span>
                                        </label>
                                        <InputText
                                            id="aiItemId"
                                            value={aiItemId}
                                            onChange={handleAiItemIdChange}
                                            placeholder={t('Enter Item ID')}
                                            className="w-full"
                                        />
                                    </div>
                                </div>

                                <div className="col-12 md:col-6">
                                    <div className="field">
                                        <label
                                            htmlFor="aiStartDate"
                                            className="font-medium text-700 mb-2 block"
                                        >
                                            {t('Start Date')}{' '}
                                            <span className="text-red-500">*</span>
                                        </label>
                                        <Calendar
                                            id="aiStartDate"
                                            value={aiStartDate}
                                            onChange={handleAiStartDateChange}
                                            showIcon
                                            dateFormat="dd/mm/yy"
                                            placeholder="dd/mm/yyyy"
                                            className="w-full"
                                        />
                                    </div>
                                </div>

                                <div className="col-12 md:col-6">
                                    <div className="field">
                                        <label
                                            htmlFor="aiEndDate"
                                            className="font-medium text-700 mb-2 block"
                                        >
                                            {t('End Date')} <span className="text-red-500">*</span>
                                        </label>
                                        <Calendar
                                            id="aiEndDate"
                                            value={aiEndDate}
                                            onChange={handleAiEndDateChange}
                                            showIcon
                                            dateFormat="dd/mm/yy"
                                            placeholder="dd/mm/yyyy"
                                            minDate={aiStartDate}
                                            className="w-full"
                                        />
                                    </div>
                                </div>

                                <div className="col-12">
                                    <div className="field flex align-items-center gap-2">
                                        <Checkbox
                                            inputId="aiSafetyStock"
                                            checked={aiSafetyStock}
                                            onChange={handleAiSafetyStockChange}
                                        />
                                        <label
                                            htmlFor="aiSafetyStock"
                                            className="font-medium text-700"
                                        >
                                            {t('Include Dynamic Safety Stock')}
                                        </label>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    </TabPanel>
                </TabView>

                <Dialog
                    header={t('AI Forecast Results')}
                    visible={aiForecastDialogVisible}
                    onHide={handleHideAiForecastDialog}
                    breakpoints={AI_DIALOG_BREAKPOINTS}
                    className="w-6"
                    modal
                >
                    {aiForecastResult && (
                        <div className="flex flex-column gap-3">
                            <div className="grid">
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary">
                                        {t('Plant ID')}
                                    </span>
                                    <div className="font-medium">{aiForecastResult.plant_id}</div>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary">
                                        {t('Item ID')}
                                    </span>
                                    <div className="font-medium">{aiForecastResult.item_id}</div>
                                </div>
                            </div>

                            <DataTable
                                value={aiForecastResult.forecast}
                                showGridlines
                                stripedRows
                                responsiveLayout="scroll"
                                size="small"
                            >
                                <Column field="month" header={t('Month')} />
                                <Column
                                    field="expected_demand"
                                    header={t('Expected Demand')}
                                    body={aiForecastExpectedDemandBody}
                                />
                                {aiSafetyStock && (
                                    <Column
                                        field="dynamic_safety_stock"
                                        header={t('Dynamic Safety Stock')}
                                        body={aiForecastSafetyStockBody}
                                    />
                                )}
                                {aiSafetyStock && (
                                    <Column
                                        field="total_recommended_inventory"
                                        header={t('Total Recommended Inventory')}
                                        body={aiForecastTotalInventoryBody}
                                    />
                                )}
                            </DataTable>
                        </div>
                    )}
                </Dialog>
            </PageLayout.Content>

            <PageLayout.Footer align={'right'}>
                {activeIndex === 0 && tableRecords.length > 0 && dynamicPeriods.length > 0 && (
                    <Button
                        label={t('Save Consumption History')}
                        icon="pi pi-save"
                        onClick={handleSubmit(onSaveConsumption)}
                        loading={isSaving}
                        className="px-5"
                    />
                )}
                {activeIndex === 1 && (
                    <Button
                        label={t('Execute Forecast Run')}
                        icon="pi pi-chart-line"
                        onClick={handleSubmit(onRunForecast)}
                        loading={isRunning}
                        className="px-5"
                    />
                )}
                {activeIndex === 2 && (
                    <Button
                        label={t('Run AI Forecast')}
                        icon="pi pi-cloud"
                        onClick={onRunAIForecast}
                        loading={isAiRunning}
                        className="px-5"
                    />
                )}
            </PageLayout.Footer>
        </PageLayout>
    );
};

export default MaterialForecastRunPage;
