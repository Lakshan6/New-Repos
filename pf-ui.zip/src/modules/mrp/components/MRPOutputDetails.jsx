import { memo, useMemo, useCallback, useState } from 'react';
import PropTypes from 'prop-types';

import { Button } from 'primereact/button';
import { Tag } from 'primereact/tag';
import { Dialog } from 'primereact/dialog';
import { ProgressSpinner } from 'primereact/progressspinner';

import { useT, useSafeContext, useReadApi } from '@shared/hooks';
import { AuthContext } from '@shared/utils';
import { PageLayout } from '@shared/components';

const STATUS_LABEL = {
    PLANNED: 'Planned',
};

const SBU_BREAKPOINTS = { '960px': '75vw', '641px': '90vw' };

const ItemCard = memo(function ItemCard({ data, onViewSbu }) {
    const { t } = useT();
    const status = data.status || '';
    const suggestedQty = Number(data.suggestedQty ?? 0);
    const availableQty = Number(data.availableQty ?? 0);
    const isShortage = availableQty < 0;

    const handleClick = useCallback(() => onViewSbu(data), [onViewSbu, data]);
    const formattedCreatedDate = useMemo(
        () => (data.createdDate ? new Date(data.createdDate).toLocaleDateString() : '\u2014'),
        [data.createdDate],
    );

    return (
        <div className="surface-card px-3 py-2 border-bottom-1 surface-border">
            <div className="flex align-items-start justify-content-between mb-2">
                <div className="flex align-items-center gap-2">
                    <span className="font-semibold text-base text-900">{data.itemId}</span>
                    <Tag
                        className="bg-blue-50 text-blue-700 border-1 border-blue-200"
                        value={STATUS_LABEL[status] || status || t('N/A')}
                    />
                </div>
            </div>
            <div className="grid text-sm">
                <div className="col-3">
                    <span className="block text-color-secondary text-xs">{t('MRP Type')}</span>
                    <span className="text-900">{data.mrpType || '\u2014'}</span>
                </div>
                <div className="col-3">
                    <span className="block text-color-secondary text-xs">{t('Plant')}</span>
                    <span className="text-900">{data.plantId || '\u2014'}</span>
                </div>
                <div className="col-3">
                    <span className="block text-color-secondary text-xs">
                        {t('Procurement Type')}
                    </span>
                    <span className="text-900">{data.procurementType || '\u2014'}</span>
                </div>
                <div className="col-3">
                    <span className="block text-color-secondary text-xs">{t('Created Date')}</span>
                    <span className="text-900">{formattedCreatedDate}</span>
                </div>
                <div className="col-3">
                    <span className="block text-color-secondary text-xs">{t('Suggested Qty')}</span>
                    <span className="font-semibold text-900">{suggestedQty.toFixed(3)}</span>
                </div>
                <div className="col-3">
                    <span className="block text-color-secondary text-xs">{t('Available Qty')}</span>
                    <span className={`font-semibold ${isShortage ? 'text-red-500' : 'text-900'}`}>
                        {availableQty.toFixed(3)}
                        {isShortage && (
                            <i
                                className="pi pi-exclamation-circle text-red-500 ml-1 text-xs"
                                aria-hidden="true"
                            />
                        )}
                    </span>
                </div>
                <div className="col-12 flex justify-content-end gap-2">
                    <Button
                        label={t('SBU Breakdown')}
                        icon="pi pi-eye"
                        className="p-button-sm p-button-outlined text-xs p-1"
                        onClick={handleClick}
                    />
                </div>
            </div>
        </div>
    );
});

ItemCard.propTypes = {
    data: PropTypes.object.isRequired,
    onViewSbu: PropTypes.func.isRequired,
};

export default function MRPOutputDetails({ runId, onBack, embedded = false, onClose }) {
    const { t } = useT();
    const { authToken } = useSafeContext(AuthContext);

    const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);

    const {
        data: outputDetailsResponse,
        isFetching: loading,
        error,
    } = useReadApi({
        service: 'mrp',
        endpoint: '/api/mrp/run/output',
        method: 'POST',
        body: useMemo(
            () => ({
                requestInfo: { authToken },
                runId: runId,
            }),
            [authToken, runId],
        ),
        headers: authHeaders,
        enabled: !!authToken && !!runId,
    });

    const outputData = useMemo(() => {
        const response = outputDetailsResponse;
        return Array.isArray(response)
            ? response
            : Array.isArray(response?.data)
              ? response.data
              : [];
    }, [outputDetailsResponse]);

    const [sbuBreakdownDialogVisible, setSbuBreakdownDialogVisible] = useState(false);
    const [selectedSbuBreakdown, setSelectedSbuBreakdown] = useState([]);
    const [selectedBreakdownItemId, setSelectedBreakdownItemId] = useState('');

    const handleOpenSbuBreakdown = useCallback((rowData) => {
        setSelectedSbuBreakdown(rowData.sbuBreakdowns || []);
        setSelectedBreakdownItemId(rowData.itemId || '');
        setSbuBreakdownDialogVisible(true);
    }, []);

    const handleCloseSbuBreakdown = useCallback(() => {
        setSbuBreakdownDialogVisible(false);
        setSelectedSbuBreakdown([]);
        setSelectedBreakdownItemId('');
    }, []);

    if (loading) {
        if (embedded) {
            return (
                <div className="flex align-items-center justify-content-center py-8">
                    <ProgressSpinner />
                </div>
            );
        }
        return (
            <PageLayout>
                <PageLayout.Content>
                    <div className="flex align-items-center justify-content-center h-25rem">
                        <ProgressSpinner />
                    </div>
                </PageLayout.Content>
            </PageLayout>
        );
    }

    if (error) {
        if (embedded) {
            return (
                <div className="flex flex-column align-items-center justify-content-center gap-3 py-8">
                    <i
                        className="pi pi-exclamation-triangle text-4xl text-red-500"
                        aria-hidden="true"
                    />
                    <p className="text-center font-medium text-lg text-red-500">
                        {error?.message || t('Failed to load MRP run outputs.')}
                    </p>
                    <Button
                        label={t('Close')}
                        icon="pi pi-times"
                        onClick={onClose}
                        outlined
                        size="small"
                    />
                </div>
            );
        }
        return (
            <PageLayout>
                <PageLayout.Content>
                    <div className="flex flex-column align-items-center justify-content-center gap-3 py-8">
                        <i
                            className="pi pi-exclamation-triangle text-4xl text-red-500"
                            aria-hidden="true"
                        />
                        <p className="text-center font-medium text-lg text-red-500">
                            {error?.message || t('Failed to load MRP run outputs.')}
                        </p>
                        <Button
                            label={t('Back')}
                            icon="pi pi-arrow-left"
                            onClick={onBack}
                            outlined
                            size="small"
                        />
                    </div>
                </PageLayout.Content>
            </PageLayout>
        );
    }

    if (embedded) {
        return (
            <div className="surface-card border-round h-full flex flex-column">
                <div className="flex align-items-center justify-content-between p-3 border-bottom-1 surface-border">
                    <div className="flex flex-column gap-1">
                        <span className="font-semibold text-lg text-900">
                            {t('MRP Run Output')}
                        </span>
                        <span className="text-sm text-color-secondary">
                            {t('Run ID')}: {runId}
                        </span>
                    </div>
                    <Button icon="pi pi-times" text aria-label={t('Close')} onClick={onClose} />
                </div>
                <div className="flex-1 overflow-auto p-3">
                    {outputData.length === 0 ? (
                        <div className="flex align-items-center justify-content-center py-8">
                            <span className="text-color-secondary">
                                {t('No configuration output records found for this run.')}
                            </span>
                        </div>
                    ) : (
                        <div className="flex flex-column">
                            {outputData.map((item) => (
                                <ItemCard
                                    key={item.itemId || item.id}
                                    data={item}
                                    onViewSbu={handleOpenSbuBreakdown}
                                />
                            ))}
                        </div>
                    )}
                </div>
                <Dialog
                    header={`${t('SBU Breakdown')} \u2014 ${selectedBreakdownItemId}`}
                    visible={sbuBreakdownDialogVisible}
                    onHide={handleCloseSbuBreakdown}
                    breakpoints={SBU_BREAKPOINTS}
                    className="w-6"
                >
                    {selectedSbuBreakdown.length === 0 ? (
                        <p className="text-500 p-3">{t('No breakdown data available.')}</p>
                    ) : (
                        selectedSbuBreakdown.map((sb, idx) => (
                            <div
                                key={sb.id || idx}
                                className="grid p-fluid mb-2 p-2 surface-ground border-round"
                            >
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Plant ID')}
                                    </span>
                                    <span className="font-semibold">{sb.plantId || '\u2014'}</span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Primary SBU')}
                                    </span>
                                    <span className="font-semibold">
                                        {sb.isPrimarySbu ? 'Yes' : 'No'}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('On Hand Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.onHandStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Available Qty')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.availableQty ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Reserved Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.reservedStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Blocked Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.blockedStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Safety Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.safetyStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Scheduled Receipts')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.scheduledReceiptsQty ?? 0).toFixed(4)}
                                    </span>
                                </div>
                            </div>
                        ))
                    )}
                </Dialog>
            </div>
        );
    }

    return (
        <PageLayout>
            <PageLayout.Header
                title={t('MRP Run Output Details')}
                subtitle={
                    <span className="flex align-items-center gap-1">
                        {t('Run ID')}: <span className="font-semibold">{runId}</span>
                    </span>
                }
                backButton
                onBack={onBack}
            />

            <PageLayout.Content>
                {outputData.length === 0 ? (
                    <div className="flex align-items-center justify-content-center py-8">
                        <span className="text-color-secondary">
                            {t('No configuration output records found for this run.')}
                        </span>
                    </div>
                ) : (
                    <div className="flex flex-column">
                        {outputData.map((item) => (
                            <ItemCard
                                key={item.itemId || item.id}
                                data={item}
                                onViewSbu={handleOpenSbuBreakdown}
                            />
                        ))}
                    </div>
                )}

                <Dialog
                    header={`${t('SBU Breakdown')} \u2014 ${selectedBreakdownItemId}`}
                    visible={sbuBreakdownDialogVisible}
                    onHide={handleCloseSbuBreakdown}
                    breakpoints={SBU_BREAKPOINTS}
                    className="w-6"
                >
                    {selectedSbuBreakdown.length === 0 ? (
                        <p className="text-500 p-3">{t('No breakdown data available.')}</p>
                    ) : (
                        selectedSbuBreakdown.map((sb, idx) => (
                            <div
                                key={sb.id || idx}
                                className="grid p-fluid mb-2 p-2 surface-ground border-round"
                            >
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Plant ID')}
                                    </span>
                                    <span className="font-semibold">{sb.plantId || '\u2014'}</span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Primary SBU')}
                                    </span>
                                    <span className="font-semibold">
                                        {sb.isPrimarySbu ? 'Yes' : 'No'}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('On Hand Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.onHandStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Available Qty')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.availableQty ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Reserved Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.reservedStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Blocked Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.blockedStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Safety Stock')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.safetyStock ?? 0).toFixed(3)}
                                    </span>
                                </div>
                                <div className="col-6">
                                    <span className="text-sm text-color-secondary block">
                                        {t('Scheduled Receipts')}
                                    </span>
                                    <span className="font-semibold">
                                        {Number(sb.scheduledReceiptsQty ?? 0).toFixed(4)}
                                    </span>
                                </div>
                            </div>
                        ))
                    )}
                </Dialog>
            </PageLayout.Content>
        </PageLayout>
    );
}

MRPOutputDetails.propTypes = {
    runId: PropTypes.string.isRequired,
    onBack: PropTypes.func,
    embedded: PropTypes.bool,
    onClose: PropTypes.func,
};
