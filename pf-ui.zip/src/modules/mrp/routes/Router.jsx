import { Suspense, lazy } from 'react';
import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { LOCALISATION_MODULES } from '@shared/utils';
import MRPPlanningRunPage from '../screens/MRPPlanningRunPage';
import MaterialForecastRunPage from '../screens/MaterialForecastRunPage';
import MRPRunListPage from '../screens/MRPRunListPage';
import MRPOutputDetailsPage from '../screens/MRPOutputDetailsPage';
import MRPConfigurationPage from '../screens/MRPConfigurationPage';

const MrpLanding = lazy(() => import('../screens/MrpLanding'));

const RouteFallback = () => <div className="p-4 text-center">Loading...</div>;

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.COMMON}
            translationsAtom={translationsAtom}
        >
            <Suspense fallback={<RouteFallback />}>
                <Routes>
                    <Route index element={<MrpLanding />} />
                    <Route path="/planning-files" element={<MRPPlanningRunPage />} />
                    <Route path="/forecast" element={<MaterialForecastRunPage />} />
                    <Route path="/mrp-report" element={<MRPRunListPage />} />
                    <Route path="/mrp-report/view/:runId" element={<MRPOutputDetailsPage />} />
                    <Route path="/mrp-configuration" element={<MRPConfigurationPage />} />
                </Routes>
            </Suspense>
        </TranslationProvider>
    );
};

export default Router;
