import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.BOILERPLATE}
            translationsAtom={translationsAtom}
        >
            <Routes>
                <Route index element={<>Boilerplate Home Screen</>} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
