// src/modules/ai-assistant/index.js

export { default as AiAssistantPage } from './screens/AiAssistantPage';

export { default as ConversationSidebar } from './components/ConversationSidebar';
export { default as ChatPanel } from './components/ChatPanel';
export { default as SelfDocumentPanel } from './components/SelfDocumentPanel';
export { default as MessageBubble } from './components/MessageBubble';
export { default as SourceChunks } from './components/SourceChunks';

export { default as useDialogs } from './hooks/useDialogs';
export {
    useConversations,
    useCreateConversation,
    useRenameConversation,
    useDeleteConversation,
    useSelectConversation,
} from './hooks/useConversations';
export { default as useCompletion } from './hooks/useCompletion';
export { useChatUpload, useSelfDocUpload } from './hooks/useUpload';
export {
    useSelfDocKb,
    useKbDocuments,
    useToggleDocStatus,
    useDeleteDocument,
    useRerunDocument,
} from './hooks/useKnowledgeBase';

export * from './store/atoms';
export {
    ragAxios,
    getRagAuth,
    RAG_APIS,
    EXCLUDED_DIALOG_NAMES,
    SELF_DOCUMENT_KB_NAME,
    LS_KEYS,
} from './utils/ragApi';
