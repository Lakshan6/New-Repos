import { Route, Routes } from 'react-router';
import { Navigate } from 'react-router-dom';
import { TranslationProvider } from '@shared/components';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';
import { translationsAtom } from '../store/atoms';

import DashboardPage from '../screens/dashboard';
import DatasetDetailPage from '../screens/datasetdetails';
import AiAssistantPage from '../screens/AiAssistantPage';

const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.DOCUMENT_LIBRARY}
            translationsAtom={translationsAtom}
        >
            <Routes>
                <Route index element={<Navigate to="admin-repository" replace />} />
                <Route
                    path="admin"
                    element={<Navigate to="admin-repository/dashboard" replace />}
                />
                <Route path="admin-repository" element={<DashboardPage />} />
                <Route path="admin-repository/dashboard" element={<DashboardPage />} />
                <Route path="admin-repository/dataset/:id" element={<DatasetDetailPage />} />
                <Route path="ai-assistant" element={<AiAssistantPage />} />
                <Route path="*" element={<NotFoundPage />} />
                <Route path="ai-assistant" element={<AiAssistantPage />} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
