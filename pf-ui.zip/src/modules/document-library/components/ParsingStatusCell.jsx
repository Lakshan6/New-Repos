import { useCallback, useMemo, useRef } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { ProgressBar } from 'primereact/progressbar';
import { OverlayPanel } from 'primereact/overlaypanel';
import { RunningStatus } from '../hooks/useParsingWithPolling';
import { ParsingPopoverContent } from './ParsingPopoverContent.jsx';

const TOOLTIP_OPTIONS = {
    position: 'top',
};

const OVERLAY_WIDTH_STYLE = {
    width: '24rem',
};

const SPINNER_STYLE = {
    display: 'inline-block',
    width: '1rem',
    height: '1rem',
    border: '2px solid #d1d5db',
    borderTopColor: '#34568C',
    borderRadius: '50%',
    animation: 'spin 0.75s linear infinite',
    flexShrink: 0,
};

export function ParsingStatusCell({ file, parsingState, onStartParsing, onCancelParsing }) {
    const op = useRef(null);

    const run = String(parsingState?.run ?? file.run ?? '');
    const progress = parsingState?.progress !== undefined ? parsingState.progress : file.progress;

    const progressMsg = parsingState?.progress_msg || file.progress_msg;

    const processBeginAt = parsingState?.process_begin_at || file.process_begin_at;

    const processDuration = parsingState?.process_duration || file.process_duration;

    const progressPercent = Math.round((progress || 0) * 100);

    const isRunning = run === RunningStatus.RUNNING;
    const isDone = run === RunningStatus.DONE;
    const isFailed = run === RunningStatus.FAIL;
    const isCancelled = run === RunningStatus.CANCEL;
    const isUnstarted = run === RunningStatus.UNSTART;

    const handleStartClick = useCallback(() => {
        onStartParsing(file.id, file.name);
    }, [file.id, file.name, onStartParsing]);

    const handleCancelClick = useCallback(() => {
        onCancelParsing(file.id, file.name);
    }, [file.id, file.name, onCancelParsing]);

    const handleRefreshClick = useCallback(() => {
        onStartParsing(file.id, file.name);
    }, [file.id, file.name, onStartParsing]);

    const handleOverlayShow = useCallback((event) => {
        op.current?.show(event);
    }, []);

    const handleOverlayHide = useCallback((event) => {
        op.current?.hide(event);
    }, []);

    const overlayContent = useMemo(
        () => (
            <div style={OVERLAY_WIDTH_STYLE}>
                <ParsingPopoverContent
                    run={run}
                    progressMsg={progressMsg}
                    processBeginAt={processBeginAt}
                    processDuration={processDuration}
                    progressPercent={progressPercent}
                />
            </div>
        ),
        [processBeginAt, processDuration, progressMsg, progressPercent, run],
    );

    // UNSTART (0) – Play button
    if (isUnstarted) {
        return (
            <Button
                icon="pi pi-play"
                rounded
                severity="info"
                onClick={handleStartClick}
                tooltip="Start parsing"
                tooltipOptions={TOOLTIP_OPTIONS}
                aria-label="Start parsing"
            />
        );
    }

    // RUNNING (1) – Spinner + ProgressBar + Cancel
    if (isRunning) {
        return (
            <>
                <OverlayPanel ref={op}>{overlayContent}</OverlayPanel>

                <div
                    className="flex align-items-center gap-2 cursor-pointer"
                    onMouseEnter={handleOverlayShow}
                    onMouseLeave={handleOverlayHide}
                >
                    <span style={SPINNER_STYLE} aria-hidden="true" />

                    <style>
                        {`
                            @keyframes spin {
                                to {
                                    transform: rotate(360deg);
                                }
                            }
                        `}
                    </style>

                    <ProgressBar value={progressPercent} className="w-5rem" showValue={false} />

                    <span className="text-sm font-semibold text-color-secondary">
                        {progressPercent}%
                    </span>

                    <Button
                        icon="pi pi-times"
                        rounded
                        severity="danger"
                        text
                        onClick={handleCancelClick}
                        tooltip="Cancel parsing"
                        tooltipOptions={TOOLTIP_OPTIONS}
                        aria-label="Cancel parsing"
                    />
                </div>
            </>
        );
    }

    // CANCEL (2) – Secondary refresh
    if (isCancelled) {
        return (
            <>
                <OverlayPanel ref={op}>{overlayContent}</OverlayPanel>

                <Button
                    icon="pi pi-refresh"
                    rounded
                    severity="secondary"
                    onClick={handleRefreshClick}
                    tooltip="Retry parsing"
                    tooltipOptions={TOOLTIP_OPTIONS}
                    onMouseEnter={handleOverlayShow}
                    onMouseLeave={handleOverlayHide}
                    aria-label="Retry parsing"
                />
            </>
        );
    }

    // DONE (3) – Success refresh
    if (isDone) {
        return (
            <>
                <OverlayPanel ref={op}>{overlayContent}</OverlayPanel>

                <Button
                    icon="pi pi-refresh"
                    rounded
                    severity="success"
                    onClick={handleRefreshClick}
                    tooltip="Re-run parsing"
                    tooltipOptions={TOOLTIP_OPTIONS}
                    onMouseEnter={handleOverlayShow}
                    onMouseLeave={handleOverlayHide}
                    aria-label="Re-run parsing"
                />
            </>
        );
    }

    // FAIL (4) – Danger refresh
    if (isFailed) {
        return (
            <>
                <OverlayPanel ref={op}>{overlayContent}</OverlayPanel>

                <Button
                    icon="pi pi-refresh"
                    rounded
                    severity="danger"
                    onClick={handleRefreshClick}
                    tooltip="Re-run parsing"
                    tooltipOptions={TOOLTIP_OPTIONS}
                    onMouseEnter={handleOverlayShow}
                    onMouseLeave={handleOverlayHide}
                    aria-label="Re-run parsing"
                />
            </>
        );
    }

    return null;
}

ParsingStatusCell.propTypes = {
    file: PropTypes.shape({
        id: PropTypes.string,
        name: PropTypes.string,
        run: PropTypes.string,
        progress: PropTypes.number,
        progress_msg: PropTypes.string,
        process_begin_at: PropTypes.string,
        process_duration: PropTypes.number,
    }).isRequired,

    parsingState: PropTypes.shape({
        run: PropTypes.string,
        progress: PropTypes.number,
        progress_msg: PropTypes.string,
        process_begin_at: PropTypes.string,
        process_duration: PropTypes.number,
    }),

    onStartParsing: PropTypes.func.isRequired,
    onCancelParsing: PropTypes.func.isRequired,
};

ParsingStatusCell.defaultProps = {
    parsingState: null,
};
