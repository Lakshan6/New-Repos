import PropTypes from 'prop-types';
import { useRef, useState, useCallback, useMemo } from 'react';
import { useAtomValue } from 'jotai';
import { Button } from 'primereact/button';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import { ProgressBar } from 'primereact/progressbar';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Dialog } from 'primereact/dialog';
import { Toast } from 'primereact/toast';
import { InputSwitch } from 'primereact/inputswitch';

import {
    useSelfDocKb,
    useKbDocuments,
    useToggleDocStatus,
    useDeleteDocument,
    useRerunDocument,
} from '../hooks/useKnowledgeBase';

import { useSelfDocUpload } from '../hooks/useUpload';
import { selfDocKbAtom } from '../store/atoms';
import { RAG_APIS } from '../utils/ragApi';

const IMAGE_BASE = RAG_APIS.DOCUMENT_IMAGE_BASE_URL ?? '';

const getThumbnailUrl = (doc) => (doc?.thumbnail ? `${IMAGE_BASE}${doc.thumbnail}` : null);

const THUMBNAIL_ICON_STYLE = {
    fontSize: '1.2rem',
};

const THUMBNAIL_IMAGE_STYLE = {
    width: '36px',
    height: '46px',
    objectFit: 'cover',
    borderRadius: '3px',
    border: '1px solid var(--surface-border)',
};

const NAME_TEXT_STYLE = {
    maxWidth: '200px',
};

const PROGRESS_CONTAINER_STYLE = {
    width: '80px',
};

const PROGRESS_BAR_STYLE = {
    height: '6px',
    fontSize: '10px',
};

const LOADER_STYLE = {
    width: '40px',
    height: '40px',
};

const DOCS_LOADER_STYLE = {
    width: '36px',
    height: '36px',
};

const FOLDER_ICON_STYLE = {
    color: 'var(--primary-color)',
};

const UPLOAD_ICON_STYLE = {
    fontSize: '2rem',
    color: 'var(--primary-color)',
};

const DROPZONE_STYLE = {
    minHeight: '110px',
    borderStyle: 'dashed',
};

const DIALOG_STYLE = {
    width: '400px',
};

const THUMBNAIL_COLUMN_STYLE = {
    width: '54px',
};

const DOCUMENT_COLUMN_STYLE = {
    minWidth: '180px',
};

const STATUS_COLUMN_STYLE = {
    width: '100px',
};

const PROGRESS_COLUMN_STYLE = {
    width: '110px',
};

const ACTIONS_COLUMN_STYLE = {
    width: '120px',
};

const DOC_COUNT_TAG_STYLE = {
    fontSize: '11px',
};

const HIDDEN_INPUT_STYLE = {
    display: 'none',
};

// ── Column body sub-components ────────────────────────────────────────────────

const ThumbnailBody = ({ rowData }) => {
    const url = getThumbnailUrl(rowData);

    const handleImageError = useCallback((e) => {
        e.currentTarget.style.display = 'none';
    }, []);

    if (!url) {
        return (
            <i
                className="pi pi-file text-color-secondary"
                style={THUMBNAIL_ICON_STYLE}
                aria-hidden="true"
            />
        );
    }

    return (
        <img
            src={url}
            alt={`Thumbnail of ${rowData.name}`}
            style={THUMBNAIL_IMAGE_STYLE}
            onError={handleImageError}
        />
    );
};

ThumbnailBody.propTypes = {
    rowData: PropTypes.object.isRequired,
};

const NameBody = ({ rowData }) => (
    <div>
        <p
            className="text-sm font-medium text-900 m-0 white-space-nowrap overflow-hidden text-overflow-ellipsis"
            style={NAME_TEXT_STYLE}
            title={rowData.name}
        >
            {rowData.name}
        </p>

        <span className="text-xs text-color-secondary">{rowData.suffix?.toUpperCase()}</span>
    </div>
);

NameBody.propTypes = {
    rowData: PropTypes.object.isRequired,
};

const StatusBody = ({ rowData }) => {
    const isEnabled = String(rowData.status) === '1';
    const label = isEnabled ? 'Enabled' : 'Disabled';
    const severity = isEnabled ? 'success' : 'danger';

    return <Tag value={label} severity={severity} />;
};

StatusBody.propTypes = {
    rowData: PropTypes.object.isRequired,
};

const ProgressBody = ({ rowData }) => {
    const progress = rowData.progress ?? 0;

    if (progress < 0) {
        return <Tag value="Failed" severity="danger" />;
    }

    if (progress === 0 && String(rowData.run) !== 'RUNNING') {
        return <span className="text-xs text-color-secondary font-medium">Not Parsed</span>;
    }

    const pct = Math.round(progress * 100);

    return (
        <div style={PROGRESS_CONTAINER_STYLE}>
            <ProgressBar
                value={pct}
                showValue
                style={PROGRESS_BAR_STYLE}
                aria-label={`Parse progress ${pct}%`}
            />
        </div>
    );
};

ProgressBody.propTypes = {
    rowData: PropTypes.object.isRequired,
};

const ActionsBody = ({ rowData, onToggle, onRerun, onDelete }) => {
    const isEnabled = rowData.status === '1';

    const toggleLabel = isEnabled ? 'Disable' : 'Enable';
    const progress = rowData.progress ?? 0;
    const isNotParsed = progress === 0 && String(rowData.run) !== 'RUNNING';

    const runIcon = isNotParsed ? 'pi pi-play' : 'pi pi-refresh';
    const runTitle = isNotParsed ? 'Run' : 'Rerun';

    const handleToggle = useCallback(() => {
        onToggle(rowData);
    }, [rowData, onToggle]);

    const handleRerun = useCallback(() => {
        onRerun(rowData.id);
    }, [rowData.id, onRerun]);

    const handleDelete = useCallback(() => {
        onDelete(rowData.id);
    }, [rowData.id, onDelete]);

    return (
        <div className="flex gap-2 align-items-center">
            <InputSwitch checked={isEnabled} onChange={handleToggle} tooltip={toggleLabel} />

            <Button
                icon={runIcon}
                text
                severity="info"
                size="small"
                onClick={handleRerun}
                aria-label={`${runTitle} parsing for ${rowData.name}`}
                title={runTitle}
            />

            <Button
                icon="pi pi-trash"
                text
                severity="danger"
                size="small"
                onClick={handleDelete}
                aria-label={`Delete ${rowData.name}`}
                title="Delete"
            />
        </div>
    );
};

ActionsBody.propTypes = {
    rowData: PropTypes.object.isRequired,
    onToggle: PropTypes.func.isRequired,
    onRerun: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
};

// ── SelfDocumentPanel ─────────────────────────────────────────────────────────

const SelfDocumentPanel = () => {
    const toastRef = useRef(null);
    const fileInputRef = useRef(null);

    const [uploadDialogVisible, setUploadDialogVisible] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);
    const [selectedDocs, setSelectedDocs] = useState([]);

    const selfDocKb = useAtomValue(selfDocKbAtom);

    const { isLoading: kbLoading } = useSelfDocKb();

    const { data: docData, isLoading: docsLoading } = useKbDocuments(selfDocKb?.id ?? null);

    const { mutate: toggleStatus } = useToggleDocStatus(selfDocKb?.id);

    const { mutate: deleteDoc } = useDeleteDocument(selfDocKb?.id);

    const { mutate: rerunDoc } = useRerunDocument(selfDocKb?.id);

    const { uploadAndRun, isUploading } = useSelfDocUpload(selfDocKb?.id);

    const docs = docData?.docs ?? [];

    const uploadButtonLabel = isUploading ? 'Uploading…' : 'Upload & Parse';

    const uploadButtonIcon = isUploading ? 'pi pi-spin pi-spinner' : 'pi pi-upload';

    const docCountValue = useMemo(
        () => `${selfDocKb?.doc_num ?? docs.length} docs`,
        [selfDocKb?.doc_num, docs.length],
    );

    const handleOpenUploadDialog = useCallback(() => {
        setSelectedFile(null);
        setUploadDialogVisible(true);
    }, []);

    const handleCloseUploadDialog = useCallback(() => {
        setUploadDialogVisible(false);
        setSelectedFile(null);
    }, []);

    const handleFileSelect = useCallback((e) => {
        setSelectedFile(e.target.files?.[0] ?? null);
        e.target.value = '';
    }, []);

    const handleBrowseClick = useCallback(() => {
        fileInputRef.current?.click();
    }, []);

    const handleBrowseKeyDown = useCallback((e) => {
        if (e.key === 'Enter') {
            fileInputRef.current?.click();
        }
    }, []);

    const showToast = useCallback((config) => {
        toastRef.current?.show(config);
    }, []);

    const handleUploadConfirm = useCallback(async () => {
        if (!selectedFile || !selfDocKb?.id) {
            return;
        }

        const result = await uploadAndRun(selectedFile);

        if (result.length) {
            showToast({
                severity: 'success',
                summary: 'Uploaded & parsing started',
                detail: selectedFile.name,
                life: 4000,
            });

            handleCloseUploadDialog();
        } else {
            showToast({
                severity: 'error',
                summary: 'Upload failed',
                detail: selectedFile.name,
                life: 4000,
            });
        }
    }, [selectedFile, selfDocKb, uploadAndRun, handleCloseUploadDialog, showToast]);

    const handleToggle = useCallback(
        (doc) => {
            const newStatus = doc.status === '1' ? 0 : 1;

            toggleStatus(
                {
                    docId: doc.id,
                    status: newStatus,
                },
                {
                    onSuccess: () => {
                        showToast({
                            severity: 'success',
                            summary: 'Status updated',
                            life: 2000,
                        });
                        setSelectedDocs([]);
                    },
                    onError: (err) => {
                        showToast({
                            severity: 'error',
                            summary: 'Error',
                            detail: err.message,
                            life: 3000,
                        });
                    },
                },
            );
        },
        [toggleStatus, showToast],
    );

    const handleRerun = useCallback(
        (docId) => {
            rerunDoc(docId, {
                onSuccess: () => {
                    showToast({
                        severity: 'info',
                        summary: 'Rerun started',
                        life: 2000,
                    });
                },
                onError: (err) => {
                    showToast({
                        severity: 'error',
                        summary: 'Error',
                        detail: err.message,
                        life: 3000,
                    });
                },
            });
        },
        [rerunDoc, showToast],
    );

    const handleDelete = useCallback(
        (docId) => {
            deleteDoc(docId, {
                onSuccess: () => {
                    showToast({
                        severity: 'success',
                        summary: 'Deleted',
                        life: 2000,
                    });
                },
                onError: (err) => {
                    showToast({
                        severity: 'error',
                        summary: 'Error',
                        detail: err.message,
                        life: 3000,
                    });
                },
            });
        },
        [deleteDoc, showToast],
    );

    const handleBatchToggle = useCallback(
        (statusVal) => {
            if (!selectedDocs || !selectedDocs.length) return;
            const docIds = selectedDocs.map((d) => d.id);

            toggleStatus(
                {
                    docIds,
                    status: statusVal,
                },
                {
                    onSuccess: () => {
                        showToast({
                            severity: 'success',
                            summary: `Batch ${statusVal === 1 ? 'Enabled' : 'Disabled'}`,
                            life: 2000,
                        });
                        setSelectedDocs([]); // Clear selection after successful action
                    },
                    onError: (err) => {
                        showToast({
                            severity: 'error',
                            summary: 'Error',
                            detail: err.message,
                            life: 3000,
                        });
                    },
                },
            );
        },
        [selectedDocs, toggleStatus, showToast],
    );

    // Stable body renderers

    const thumbnailBody = useCallback((rowData) => <ThumbnailBody rowData={rowData} />, []);

    const nameBody = useCallback((rowData) => <NameBody rowData={rowData} />, []);

    const statusBody = useCallback((rowData) => <StatusBody rowData={rowData} />, []);

    const progressBody = useCallback((rowData) => <ProgressBody rowData={rowData} />, []);

    const actionsBody = useCallback(
        (rowData) => (
            <ActionsBody
                rowData={rowData}
                onToggle={handleToggle}
                onRerun={handleRerun}
                onDelete={handleDelete}
            />
        ),
        [handleToggle, handleRerun, handleDelete],
    );

    if (kbLoading) {
        return (
            <div className="flex justify-content-center align-items-center flex-1 p-4">
                <ProgressSpinner
                    style={LOADER_STYLE}
                    strokeWidth="4"
                    aria-label="Loading knowledge base"
                />
            </div>
        );
    }

    if (!selfDocKb) {
        return (
            <div className="flex flex-column align-items-center justify-content-center flex-1 p-4 gap-2">
                <i
                    className="pi pi-exclamation-circle"
                    style={UPLOAD_ICON_STYLE}
                    aria-hidden="true"
                />

                <p className="text-color-secondary text-center">
                    Self-document knowledge base not found.
                </p>
            </div>
        );
    }

    return (
        <div className="flex flex-column h-full p-3 gap-3">
            <Toast ref={toastRef} position="bottom-right" />

            {/* Toolbar */}

            <div className="flex align-items-center justify-content-between flex-wrap gap-2">
                <div className="flex align-items-center gap-2">
                    <i className="pi pi-folder" style={FOLDER_ICON_STYLE} aria-hidden="true" />

                    <span className="text-sm font-semibold text-900">{selfDocKb.name}</span>

                    <Tag value={docCountValue} severity="info" style={DOC_COUNT_TAG_STYLE} />
                </div>

                <div className="flex gap-2">
                    {selectedDocs && selectedDocs.length > 0 && (
                        <>
                            <Button
                                label="Enable Selected"
                                severity="success"
                                outlined
                                onClick={() => handleBatchToggle(1)}
                            />
                            <Button
                                label="Disable Selected"
                                severity="danger"
                                outlined
                                onClick={() => handleBatchToggle(0)}
                            />
                        </>
                    )}
                    <Button
                        label="Upload & Parse"
                        icon="pi pi-upload"
                        onClick={handleOpenUploadDialog}
                        disabled={isUploading}
                        aria-label="Upload document to knowledge base"
                    />
                </div>
            </div>

            {/* Document table */}

            {docsLoading ? (
                <div className="flex justify-content-center align-items-center flex-1">
                    <ProgressSpinner
                        style={DOCS_LOADER_STYLE}
                        strokeWidth="4"
                        aria-label="Loading documents"
                    />
                </div>
            ) : (
                <DataTable
                    value={docs}
                    selection={selectedDocs}
                    onSelectionChange={(e) => setSelectedDocs(e.value)}
                    dataKey="id"
                    emptyMessage="No documents yet. Click 'Upload & Parse' to add one."
                    scrollable
                    scrollHeight="flex"
                    size="small"
                    aria-label="Knowledge base documents"
                >
                    <Column selectionMode="multiple" headerStyle={{ width: '3rem' }}></Column>
                    <Column header="" body={thumbnailBody} style={THUMBNAIL_COLUMN_STYLE} />

                    <Column header="Document" body={nameBody} style={DOCUMENT_COLUMN_STYLE} />

                    <Column header="Status" body={statusBody} style={STATUS_COLUMN_STYLE} />

                    <Column header="Progress" body={progressBody} style={PROGRESS_COLUMN_STYLE} />

                    <Column header="Actions" body={actionsBody} style={ACTIONS_COLUMN_STYLE} />
                </DataTable>
            )}

            {/* Upload Dialog */}

            <Dialog
                header="Upload Document"
                visible={uploadDialogVisible}
                onHide={handleCloseUploadDialog}
                style={DIALOG_STYLE}
                modal
            >
                <div className="flex flex-column gap-3">
                    <input
                        ref={fileInputRef}
                        type="file"
                        accept=".pdf,.docx,.xlsx,.csv,.txt,.md"
                        style={HIDDEN_INPUT_STYLE}
                        onChange={handleFileSelect}
                        aria-label="Select file to upload"
                    />

                    <div
                        role="button"
                        tabIndex={0}
                        className="flex flex-column align-items-center justify-content-center border-round-md border-1 surface-border p-4 gap-2 cursor-pointer"
                        style={DROPZONE_STYLE}
                        onClick={handleBrowseClick}
                        onKeyDown={handleBrowseKeyDown}
                        aria-label="Click to browse and select a file"
                    >
                        <i
                            className="pi pi-cloud-upload"
                            style={UPLOAD_ICON_STYLE}
                            aria-hidden="true"
                        />

                        {selectedFile ? (
                            <p className="text-sm font-medium text-900 text-center m-0">
                                {selectedFile.name}
                            </p>
                        ) : (
                            <p className="text-sm text-color-secondary text-center m-0">
                                Click to browse or drop a file here
                            </p>
                        )}

                        <p className="text-xs text-color-secondary m-0">
                            PDF, DOCX, XLSX, CSV, TXT, MD
                        </p>
                    </div>

                    <div className="flex justify-content-end gap-2">
                        <Button
                            label="Cancel"
                            text
                            severity="secondary"
                            onClick={handleCloseUploadDialog}
                            aria-label="Cancel"
                        />

                        <Button
                            label={uploadButtonLabel}
                            icon={uploadButtonIcon}
                            disabled={!selectedFile || isUploading}
                            onClick={handleUploadConfirm}
                            aria-label="Confirm upload and start parsing"
                        />
                    </div>
                </div>
            </Dialog>
        </div>
    );
};

export default SelfDocumentPanel;
