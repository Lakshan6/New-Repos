import PropTypes from 'prop-types';
import { useRef, useEffect, useState, useCallback, useMemo } from 'react';

import { useAtomValue, useSetAtom } from 'jotai';

import { InputTextarea } from 'primereact/inputtextarea';
import { Button } from 'primereact/button';
import { ProgressBar } from 'primereact/progressbar';

import MessageBubble from './MessageBubble';

import {
    messagesAtom,
    isStreamingAtom,
    activeConversationAtom,
    selectedDialogAtom,
} from '../store/atoms';

import useCompletion from '../hooks/useCompletion';

import { useCreateConversation, useRenameConversation } from '../hooks/useConversations';

import { useChatUpload } from '../hooks/useUpload';

const FILE_ICON_STYLE = {
    fontSize: '11px',
};

const FILE_NAME_STYLE = {
    maxWidth: '110px',
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
};

const REMOVE_BUTTON_STYLE = {
    width: '16px',
    height: '16px',
    padding: 0,
};

const FileChip = ({ name, index, onRemove }) => {
    const handleRemove = useCallback(() => {
        onRemove(index);
    }, [index, onRemove]);

    return (
        <div className="flex align-items-center gap-1 p-1 border-round border-1 surface-border surface-card">
            <i className="pi pi-file text-primary" style={FILE_ICON_STYLE} aria-hidden="true" />

            <span className="text-xs text-color-secondary" style={FILE_NAME_STYLE} title={name}>
                {name}
            </span>

            <Button
                icon="pi pi-times"
                text
                size="small"
                onClick={handleRemove}
                aria-label={`Remove ${name}`}
                style={REMOVE_BUTTON_STYLE}
            />
        </div>
    );
};

FileChip.propTypes = {
    name: PropTypes.string.isRequired,
    index: PropTypes.number.isRequired,
    onRemove: PropTypes.func.isRequired,
};

const ChatPanel = () => {
    const messages = useAtomValue(messagesAtom);
    const isStreaming = useAtomValue(isStreamingAtom);
    const activeConversation = useAtomValue(activeConversationAtom);
    const selectedDialog = useAtomValue(selectedDialogAtom);

    const setMessages = useSetAtom(messagesAtom);

    const { sendMessage } = useCompletion();

    const { mutateAsync: createConversation, isPending: creating } = useCreateConversation();

    const { mutate: renameConversation } = useRenameConversation();

    const { uploadForChat, isUploading } = useChatUpload();

    const [inputText, setInputText] = useState('');
    const [pendingFiles, setPendingFiles] = useState([]);
    const [pendingFileNames, setPendingFileNames] = useState([]);

    const messagesEndRef = useRef(null);
    const textareaRef = useRef(null);
    const fileInputRef = useRef(null);

    const activeConvRef = useRef(activeConversation);
    const renamedRef = useRef(false);

    useEffect(() => {
        activeConvRef.current = activeConversation;
        renamedRef.current = false;
    }, [activeConversation]);

    const hasUserMsg = useMemo(() => messages.some((m) => m.role === 'user'), [messages]);

    useEffect(() => {
        messagesEndRef.current?.scrollIntoView({
            behavior: 'smooth',
        });
    }, [messages]);

    const isChatDisabled = !activeConversation?.id;

    const canSend = useMemo(
        () =>
            (inputText.trim().length > 0 || pendingFiles.length > 0) &&
            !isStreaming &&
            !isUploading &&
            !creating &&
            !isChatDisabled,
        [creating, inputText, pendingFiles.length, isStreaming, isUploading, isChatDisabled],
    );

    const ensureConversation = useCallback(async () => {
        return activeConvRef.current;
    }, []);

    const handleSend = useCallback(async () => {
        if (!canSend) {
            return;
        }

        const text = inputText.trim() || 'Uploaded document';
        const currentPendingFiles = pendingFiles;

        setInputText('');
        setPendingFiles([]);
        setPendingFileNames([]);

        if (textareaRef.current) {
            textareaRef.current.style.height = 'auto';
        }

        const conv = await ensureConversation();

        if (!conv?.id) {
            return;
        }

        const snapshot = [...messages];

        const isFirstMsg = !hasUserMsg && !renamedRef.current;

        const result = await sendMessage({
            userText: text,
            files: currentPendingFiles,
            currentMessages: snapshot,
        });

        if (result && isFirstMsg) {
            renamedRef.current = true;

            const name = text.length > 60 ? `${text.slice(0, 60)}…` : text;

            renameConversation({
                sessionId: conv.id,
                name,
            });
        }
    }, [
        canSend,
        ensureConversation,
        hasUserMsg,
        inputText,
        messages,
        pendingFiles,
        renameConversation,
        sendMessage,
    ]);

    const handleKeyDown = useCallback(
        (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
            }
        },
        [handleSend],
    );

    const handleInputChange = useCallback((e) => {
        setInputText(e.target.value);
    }, []);

    const handleAttachClick = useCallback(() => {
        fileInputRef.current?.click();
    }, []);

    const handleFileChange = useCallback(
        async (e) => {
            const files = Array.from(e.target.files ?? []);

            if (!files.length) {
                return;
            }

            e.target.value = '';

            const conv = await ensureConversation();

            if (!conv?.id) {
                return;
            }

            for (const file of files) {
                const docs = await uploadForChat(file, conv.id);

                if (docs.length) {
                    setPendingFiles((prev) => [...prev, ...docs]);

                    setPendingFileNames((prev) => [...prev, file.name]);
                }
            }
        },
        [ensureConversation, uploadForChat],
    );

    const handleRemoveFile = useCallback((idx) => {
        setPendingFiles((prev) => prev.filter((_, i) => i !== idx));

        setPendingFileNames((prev) => prev.filter((_, i) => i !== idx));
    }, []);

    const handleEditUserMessage = useCallback(
        (content) => {
            setInputText(content);

            setMessages((prev) => {
                const reversed = [...prev].reverse();

                const lastUserIdx = reversed.findIndex((m) => m.role === 'user');

                if (lastUserIdx === -1) {
                    return prev;
                }

                return prev.slice(0, prev.length - 1 - lastUserIdx);
            });

            textareaRef.current?.focus();
        },
        [setMessages],
    );

    const rootStyle = useMemo(
        () => ({
            height: '100%',
            minHeight: 0,
        }),
        [],
    );

    const messagesContainerStyle = useMemo(
        () => ({
            minHeight: 0,
        }),
        [],
    );

    const emptyStateStyle = useMemo(
        () => ({
            opacity: 0.6,
        }),
        [],
    );

    const emptyIconStyle = useMemo(
        () => ({
            fontSize: '3rem',
            color: 'var(--primary-color)',
        }),
        [],
    );

    const uploadProgressStyle = useMemo(
        () => ({
            height: '3px',
        }),
        [],
    );

    const footerStyle = useMemo(
        () => ({
            background: 'var(--surface-card)',
        }),
        [],
    );

    const inputTextareaStyle = useMemo(
        () => ({
            maxHeight: '140px',
            resize: 'none',
        }),
        [],
    );

    const hiddenFileInputStyle = useMemo(
        () => ({
            display: 'none',
        }),
        [],
    );

    const sendButtonIcon = useMemo(
        () => (isStreaming ? 'pi pi-spin pi-spinner' : 'pi pi-send'),
        [isStreaming],
    );

    const renderFileChip = useCallback(
        (name, i) => (
            <FileChip key={`${name}-${i}`} name={name} index={i} onRemove={handleRemoveFile} />
        ),
        [handleRemoveFile],
    );
    const messageEditHandlers = useMemo(() => {
        const handlers = new Map();

        messages.forEach((msg, idx) => {
            const key = msg.id ? `${msg.id}-${idx}` : `${msg.role}-${idx}`;

            handlers.set(key, () => handleEditUserMessage(msg.content ?? ''));
        });

        return handlers;
    }, [handleEditUserMessage, messages]);

    const messageItems = useMemo(() => {
        return messages.map((msg, idx) => {
            const key = msg.id ? `${msg.id}-${idx}` : `${msg.role}-${idx}`;

            return (
                <MessageBubble
                    key={key}
                    message={msg}
                    onEditUserMessage={messageEditHandlers.get(key)}
                />
            );
        });
    }, [messageEditHandlers, messages]);
    const prologue = useMemo(
        () =>
            selectedDialog?.prompt_config?.prologue ??
            "Hi! I'm your assistant, what can I do for you?",
        [selectedDialog],
    );

    return (
        <div className="flex flex-column flex-1 overflow-hidden" style={rootStyle}>
            <div
                className="flex-1 overflow-y-auto p-3"
                style={messagesContainerStyle}
                aria-live="polite"
                aria-label="Chat messages"
            >
                {messages.length === 0 ? (
                    <div
                        className="flex flex-column align-items-center justify-content-center h-full gap-3"
                        style={emptyStateStyle}
                    >
                        <i className="pi pi-comments" style={emptyIconStyle} aria-hidden="true" />

                        <p className="text-lg font-medium text-color-secondary text-center">
                            {prologue}
                        </p>
                    </div>
                ) : (
                    messageItems
                )}

                <div ref={messagesEndRef} />
            </div>

            {isUploading && (
                <div className="px-3 pb-1 flex-shrink-0">
                    <ProgressBar
                        mode="indeterminate"
                        style={uploadProgressStyle}
                        aria-label="Uploading file"
                    />
                </div>
            )}

            {pendingFileNames.length > 0 && (
                <div className="flex flex-wrap gap-1 px-3 pb-2 flex-shrink-0">
                    {pendingFileNames.map(renderFileChip)}
                </div>
            )}

            <div
                className="flex align-items-end gap-2 p-3 border-top-1 surface-border flex-shrink-0"
                style={footerStyle}
            >
                {selectedDialog?.name !== 'self-document' && (
                    <>
                        <input
                            ref={fileInputRef}
                            type="file"
                            multiple
                            accept=".pdf,.docx,.xlsx,.csv,.txt,.md"
                            style={hiddenFileInputStyle}
                            onChange={handleFileChange}
                            aria-label="Attach files"
                            disabled={isChatDisabled}
                        />

                        <Button
                            icon="pi pi-paperclip"
                            text
                            severity="secondary"
                            disabled={isStreaming || isUploading || isChatDisabled}
                            onClick={handleAttachClick}
                            aria-label="Attach a file"
                            title="Attach file"
                        />
                    </>
                )}

                <InputTextarea
                    ref={textareaRef}
                    value={inputText}
                    onChange={handleInputChange}
                    onKeyDown={handleKeyDown}
                    placeholder="Type your message… (Enter to send, Shift+Enter for new line)"
                    autoResize
                    rows={1}
                    className="flex-1"
                    style={inputTextareaStyle}
                    disabled={isStreaming || !selectedDialog || isChatDisabled}
                    aria-label="Chat message input"
                    id="chat-message-input"
                />

                <Button
                    icon={sendButtonIcon}
                    disabled={!canSend}
                    onClick={handleSend}
                    aria-label="Send message"
                    title="Send"
                />
            </div>
        </div>
    );
};

export default ChatPanel;
