import PropTypes from 'prop-types';
import { useState, useCallback, useMemo } from 'react';
import { Button } from 'primereact/button';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Dialog } from 'primereact/dialog';

const RAG_BASE = import.meta.env.VITE_RAG_BASE_URL || '';

// ── Shared Styles ─────────────────────────────────────────────────────────────
const FILE_ATTACHMENT_STYLE = {
    background: 'rgba(255,255,255,0.15)',
    maxWidth: '200px',
};

const FILE_ICON_STYLE = {
    fontSize: '16px',
    color: '#fff',
    opacity: 0.9,
};

const FILE_NAME_STYLE = {
    color: '#fff',
    opacity: 0.9,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
};

const USER_MESSAGE_STYLE = {
    background: 'var(--primary-color)',
    color: '#fff',
    wordBreak: 'break-word',
    lineHeight: 1.6,
    fontSize: '0.9rem',
};

const USER_AVATAR_STYLE = {
    width: '32px',
    height: '32px',
    background: 'var(--surface-300)',
    alignSelf: 'flex-end',
};

const ASSISTANT_AVATAR_STYLE = {
    width: '32px',
    height: '32px',
    background: 'var(--primary-color)',
    color: 'var(--surface-0)',
    fontSize: '12px',
    fontWeight: 600,
    alignSelf: 'flex-end',
};

const ASSISTANT_MESSAGE_STYLE = {
    wordBreak: 'break-word',
    lineHeight: 1.6,
    fontSize: '0.9rem',
    boxShadow: 'var(--card-shadow)',
};

const THINKING_SPINNER_STYLE = {
    width: '18px',
    height: '18px',
};

const DOCUMENT_ICON_STYLE = {
    fontSize: '14px',
    flexShrink: 0,
    marginTop: '2px',
};

const HTML_CONTENT_STYLE = {
    overflowX: 'auto',
};

const DOC_CARD_STYLE = {
    maxWidth: '220px',
};

const DOC_NAME_STYLE = {
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
};

const DIALOG_STYLE = {
    width: '700px',
    maxWidth: '95vw',
};

const CHUNK_IMAGE_STYLE = {
    width: '100%',
    borderRadius: '6px',
    marginBottom: '12px',
    border: '1px solid var(--surface-border)',
};

const CHUNK_CONTENT_STYLE = {
    whiteSpace: 'pre-wrap',
    fontSize: '0.85rem',
    lineHeight: 1.6,
    margin: 0,
};

const MESSAGE_WRAPPER_STYLE = {
    maxWidth: '75%',
};

const ASSISTANT_WRAPPER_STYLE = {
    maxWidth: '80%',
};

const DOC_CONTENT_WRAPPER_STYLE = {
    overflow: 'hidden',
};

const DOC_ICON_PDF_STYLE = {
    fontSize: '18px',
};

const MATCH_PERCENT_STYLE = {
    overflow: 'hidden',
};

const SOURCE_REFERENCE_CONTAINER_STYLE = {
    maxHeight: '70vh',
    overflowY: 'auto',
};

// ── Helpers ───────────────────────────────────────────────────────────────────
const isHtmlContent = (text) =>
    typeof text === 'string' && (text.includes('<table') || text.includes('<tr'));

const renderMarkdown = (text) => {
    if (!text) {
        return '';
    }

    let html = text
        .replace(/&/g, '&amp;')
        .replace(/</g, '&lt;')
        .replace(/>/g, '&gt;')
        .replace(/\*\*(.+?)\*\*/g, '<strong>$1</strong>')
        .replace(/\*(.+?)\*/g, '<em>$1</em>')
        .replace(
            /`([^`]+)`/g,
            '<code style="background:var(--surface-hover);padding:1px 4px;border-radius:4px;">$1</code>',
        )
        .replace(
            /\[ID:(\d+)\]/g,
            (_, n) =>
                `<span class="citation-marker" data-chunk-index="${n}" style="color:var(--primary-color);font-size:0.75rem;cursor:pointer;vertical-align:super;font-weight:600;background:var(--highlight-bg);padding:1px 4px;border-radius:3px;">[${n}]</span>`,
        )
        .replace(
            /\[(\d+)\]/g,
            (_, n) =>
                `<span class="citation-marker" data-chunk-index="${n}" style="color:var(--primary-color);font-size:0.75rem;cursor:pointer;vertical-align:super;font-weight:600;background:var(--highlight-bg);padding:1px 4px;border-radius:3px;">[${n}]</span>`,
        );

    html = html
        .split(/\n\n+/)
        .map((paragraph) => {
            const paragraphHtml = paragraph.replace(/\n/g, '<br />');

            return `<p style="margin:0 0 0.5rem">${paragraphHtml}</p>`;
        })
        .join('');

    return html;
};

const copyText = (text) => {
    if (navigator.clipboard) {
        navigator.clipboard.writeText(text).catch(() => {});
    }
};

const getChunkImageUrl = (imageId) =>
    imageId ? `${RAG_BASE}/api/v1/documents/images/${imageId}` : null;

const getChunkByCitationIndex = (chunks, idx) => {
    if (Number.isNaN(idx)) {
        return null;
    }

    if (chunks[idx]) {
        return chunks[idx];
    }

    if (chunks[idx - 1]) {
        return chunks[idx - 1];
    }

    return null;
};

// ── FileAttachment ────────────────────────────────────────────────────────────
const FileAttachment = ({ file }) => (
    <div className="flex align-items-center gap-2 p-2 border-round" style={FILE_ATTACHMENT_STYLE}>
        <i className="pi pi-file-pdf" style={FILE_ICON_STYLE} aria-hidden="true" />

        <span className="text-xs" style={FILE_NAME_STYLE} title={file.name}>
            {file.name}
        </span>
    </div>
);

FileAttachment.propTypes = {
    file: PropTypes.shape({
        name: PropTypes.string.isRequired,
        id: PropTypes.string,
        size: PropTypes.number,
    }).isRequired,
};

// ── UserMessage ───────────────────────────────────────────────────────────────
const UserMessage = ({ content, files, onEdit }) => {
    const [copied, setCopied] = useState(false);

    const handleCopy = useCallback(() => {
        copyText(content);

        setCopied(true);

        setTimeout(() => {
            setCopied(false);
        }, 1500);
    }, [content]);

    return (
        <div className="flex justify-content-end mb-3">
            <div style={MESSAGE_WRAPPER_STYLE}>
                <div className="p-3 border-round-lg" style={USER_MESSAGE_STYLE}>
                    {content}

                    {files?.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-2">
                            {files.map((file) => (
                                <FileAttachment key={file.id || file.name} file={file} />
                            ))}
                        </div>
                    )}
                </div>

                <div className="flex justify-content-end gap-1 mt-1">
                    <Button
                        icon={copied ? 'pi pi-check' : 'pi pi-copy'}
                        text
                        severity="secondary"
                        size="small"
                        onClick={handleCopy}
                        aria-label="Copy message"
                        title="Copy"
                    />

                    <Button
                        icon="pi pi-pencil"
                        text
                        severity="secondary"
                        size="small"
                        onClick={onEdit}
                        aria-label="Edit message"
                        title="Edit"
                    />
                </div>
            </div>

            <div
                className="flex align-items-center justify-content-center border-circle ml-2 flex-shrink-0"
                style={USER_AVATAR_STYLE}
                aria-hidden="true"
            >
                <i className="pi pi-user" />
            </div>
        </div>
    );
};

UserMessage.propTypes = {
    content: PropTypes.string.isRequired,
    files: PropTypes.array,
    onEdit: PropTypes.func.isRequired,
};

UserMessage.defaultProps = {
    files: [],
};

// ── AssistantMessage ──────────────────────────────────────────────────────────
const AssistantMessage = ({ content, reference, streaming, thinking }) => {
    const [copied, setCopied] = useState(false);
    const [selectedChunk, setSelectedChunk] = useState(null);

    const chunks = useMemo(() => reference?.chunks ?? [], [reference?.chunks]);

    const docAggs = useMemo(() => reference?.doc_aggs ?? [], [reference?.doc_aggs]);

    const hasChunks = chunks.length > 0;

    const htmlContentMarkup = useMemo(
        () => ({
            __html: content,
        }),
        [content],
    );

    const markdownContentMarkup = useMemo(
        () => ({
            __html: renderMarkdown(content),
        }),
        [content],
    );

    const handleCopy = useCallback(() => {
        copyText(content.replace(/<[^>]+>/g, ''));

        setCopied(true);

        setTimeout(() => {
            setCopied(false);
        }, 1500);
    }, [content]);

    const handleContentClick = useCallback(
        (event) => {
            const marker = event.target.closest('.citation-marker');

            if (!marker) {
                return;
            }

            const idx = parseInt(marker.dataset.chunkIndex, 10);

            const chunk = getChunkByCitationIndex(chunks, idx);

            if (chunk) {
                setSelectedChunk(chunk);
            }
        },
        [chunks],
    );

    const handleContentKeyDown = useCallback(
        (event) => {
            if (event.key !== 'Enter' && event.key !== ' ') {
                return;
            }

            handleContentClick(event);
        },
        [handleContentClick],
    );

    const handleDialogHide = useCallback(() => {
        setSelectedChunk(null);
    }, []);

    const handleImageError = useCallback((event) => {
        event.target.style.display = 'none';
    }, []);

    const createDocClickHandler = useCallback(
        (docId) => () => {
            window.open(`${RAG_BASE}/api/v1/documents/${docId}/preview`, '_blank');
        },
        [],
    );

    const createDocKeyDownHandler = useCallback(
        (docId) => (event) => {
            if (event.key !== 'Enter' && event.key !== ' ') {
                return;
            }

            event.preventDefault();

            window.open(`${RAG_BASE}/api/v1/documents/${docId}/preview`, '_blank');
        },
        [],
    );

    return (
        <div className="flex justify-content-start mb-3">
            <div
                className="flex align-items-center justify-content-center border-round-md mr-2 flex-shrink-0"
                style={ASSISTANT_AVATAR_STYLE}
                aria-hidden="true"
            >
                AI
            </div>

            <div style={ASSISTANT_WRAPPER_STYLE}>
                <div
                    className="p-3 border-round-lg surface-card border-1 surface-border"
                    style={ASSISTANT_MESSAGE_STYLE}
                >
                    {thinking && (
                        <div className="flex align-items-center gap-2">
                            <ProgressSpinner
                                style={THINKING_SPINNER_STYLE}
                                strokeWidth="4"
                                aria-label="AI thinking"
                            />

                            <span className="text-sm text-color-secondary">Thinking…</span>
                        </div>
                    )}

                    {content && (
                        <div className="flex align-items-start gap-1">
                            {hasChunks && (
                                <span
                                    style={DOCUMENT_ICON_STYLE}
                                    aria-label="Has document references"
                                >
                                    📄
                                </span>
                            )}

                            <div
                                className="flex-1"
                                onClick={handleContentClick}
                                onKeyDown={handleContentKeyDown}
                                role="button"
                                tabIndex={0}
                            >
                                {isHtmlContent(content) ? (
                                    <div
                                        className="ai-html-content"
                                        dangerouslySetInnerHTML={htmlContentMarkup}
                                        style={HTML_CONTENT_STYLE}
                                    />
                                ) : (
                                    <div dangerouslySetInnerHTML={markdownContentMarkup} />
                                )}
                            </div>
                        </div>
                    )}

                    {streaming && !thinking && content && (
                        <span className="ai-stream-cursor" aria-hidden="true" />
                    )}
                </div>

                {!streaming && docAggs.length > 0 && (
                    <div className="flex flex-wrap gap-2 mt-2">
                        {docAggs.map((doc) => (
                            <div
                                key={doc.doc_id}
                                className="flex align-items-center gap-2 p-2 border-1 surface-border border-round surface-card cursor-pointer hover:surface-hover"
                                style={DOC_CARD_STYLE}
                                title={`View ${doc.doc_name}`}
                                onClick={createDocClickHandler(doc.doc_id)}
                                onKeyDown={createDocKeyDownHandler(doc.doc_id)}
                                role="button"
                                tabIndex={0}
                            >
                                <i
                                    className="pi pi-file-pdf text-red-500"
                                    style={DOC_ICON_PDF_STYLE}
                                />

                                <div className="flex-1" style={DOC_CONTENT_WRAPPER_STYLE}>
                                    <div className="text-xs font-medium" style={DOC_NAME_STYLE}>
                                        {doc.doc_name}
                                    </div>

                                    <div
                                        className="text-xs text-color-secondary"
                                        style={MATCH_PERCENT_STYLE}
                                    >
                                        {doc.count} references
                                    </div>
                                </div>
                            </div>
                        ))}
                    </div>
                )}

                {!streaming && content && (
                    <div className="flex gap-1 mt-1">
                        <Button
                            icon={copied ? 'pi pi-check' : 'pi pi-copy'}
                            text
                            severity="secondary"
                            size="small"
                            onClick={handleCopy}
                            aria-label="Copy response"
                            title="Copy"
                        />
                    </div>
                )}
            </div>

            <Dialog
                header={selectedChunk?.document_name ?? 'Source Reference'}
                visible={!!selectedChunk}
                onHide={handleDialogHide}
                style={DIALOG_STYLE}
                maximizable
            >
                {selectedChunk && (
                    <div style={SOURCE_REFERENCE_CONTAINER_STYLE}>
                        {selectedChunk.image_id && (
                            <img
                                src={getChunkImageUrl(selectedChunk.image_id)}
                                alt={`Page from ${selectedChunk.document_name}`}
                                style={CHUNK_IMAGE_STYLE}
                                onError={handleImageError}
                            />
                        )}

                        <div className="p-3 surface-ground border-round">
                            <div className="flex align-items-center gap-2 mb-2">
                                <i className="pi pi-file-pdf text-red-500" />

                                <span className="text-sm font-semibold">
                                    {selectedChunk.document_name}
                                </span>

                                <span
                                    className="text-xs text-color-secondary ml-auto"
                                    style={MATCH_PERCENT_STYLE}
                                >
                                    {Math.round((selectedChunk.similarity ?? 0) * 100)}% match
                                </span>
                            </div>

                            <p style={CHUNK_CONTENT_STYLE}>{selectedChunk.content}</p>
                        </div>
                    </div>
                )}
            </Dialog>
        </div>
    );
};

AssistantMessage.propTypes = {
    content: PropTypes.string,
    reference: PropTypes.shape({
        chunks: PropTypes.array,
        doc_aggs: PropTypes.array,
    }),
    streaming: PropTypes.bool,
    thinking: PropTypes.bool,
};

AssistantMessage.defaultProps = {
    content: '',
    reference: {
        chunks: [],
        doc_aggs: [],
    },
    streaming: false,
    thinking: false,
};

// ── MessageBubble ─────────────────────────────────────────────────────────────
const MessageBubble = ({ message, onEditUserMessage }) => {
    const { role, content, files, reference, _streaming, _thinking } = message;

    if (role === 'user') {
        return <UserMessage content={content ?? ''} files={files} onEdit={onEditUserMessage} />;
    }

    return (
        <AssistantMessage
            content={content ?? ''}
            reference={reference}
            streaming={_streaming ?? false}
            thinking={_thinking ?? false}
        />
    );
};

MessageBubble.propTypes = {
    message: PropTypes.shape({
        role: PropTypes.string.isRequired,
        content: PropTypes.string,
        id: PropTypes.string,
        files: PropTypes.array,
        reference: PropTypes.shape({
            chunks: PropTypes.array,
            doc_aggs: PropTypes.array,
        }),
        _streaming: PropTypes.bool,
        _thinking: PropTypes.bool,
        _error: PropTypes.bool,
    }).isRequired,
    onEditUserMessage: PropTypes.func,
};

MessageBubble.defaultProps = {
    onEditUserMessage: () => {},
};

export default MessageBubble;
