import PropTypes from 'prop-types';
import { useMemo } from 'react';
import { RunningStatusLabels, RunningStatusColors } from '../hooks/useParsingWithPolling';

const DEFAULT_STATUS_COLOR = '#9CA3AF';

export function ParsingPopoverContent({
    run,
    progressMsg = '',
    processBeginAt = '',
    processDuration = 0,
    progressPercent = 0,
}) {
    const statusColor = RunningStatusColors[run] || DEFAULT_STATUS_COLOR;

    const statusDotStyle = useMemo(
        () => ({
            backgroundColor: statusColor,
        }),
        [statusColor],
    );

    const statusLabel = RunningStatusLabels[run] || 'Unknown';

    const cleanProgressMsg = useMemo(
        () => (progressMsg ? progressMsg.replace(/(\n)\1+/g, '$1') : ''),
        [progressMsg],
    );

    const formattedProgressMsg = useMemo(() => {
        if (!cleanProgressMsg) {
            return '';
        }

        const parts = cleanProgressMsg.split(/(\[ERROR\][^\n]*)/g);

        return parts.map((part, idx) => {
            if (part.startsWith('[ERROR]')) {
                return (
                    <span key={`error-${idx}`} className="text-red-600">
                        {part}
                    </span>
                );
            }

            return part;
        });
    }, [cleanProgressMsg]);

    return (
        <div className="space-y-3">
            <div className="flex items-center gap-2 pb-2 border-b border-gray-200">
                <span className="w-2 h-2 rounded-full inline-block" style={statusDotStyle} />

                <span className="text-sm font-semibold text-gray-700">{statusLabel}</span>

                {progressPercent > 0 && run === '1' && (
                    <span className="text-xs font-medium text-blue-600 ml-auto">
                        {progressPercent}%
                    </span>
                )}
            </div>

            <div className="space-y-2 text-sm">
                {processBeginAt && (
                    <div className="flex gap-2">
                        <span className="font-semibold text-gray-600 min-w-fit">Start Time:</span>

                        <span className="text-gray-700">{processBeginAt}</span>
                    </div>
                )}

                {processDuration > 0 && (
                    <div className="flex gap-2">
                        <span className="font-semibold text-gray-600 min-w-fit">Duration:</span>

                        <span className="text-gray-700">{processDuration.toFixed(2)} seconds</span>
                    </div>
                )}

                {cleanProgressMsg && (
                    <div className="flex flex-col gap-1">
                        <span className="font-semibold text-gray-600">Log:</span>

                        <div className="bg-gray-50 border border-gray-200 rounded p-2 max-h-48 overflow-y-auto">
                            <pre className="text-xs text-gray-700 whitespace-pre-wrap break-words font-mono">
                                {formattedProgressMsg}
                            </pre>
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
}

ParsingPopoverContent.propTypes = {
    run: PropTypes.string,
    progressMsg: PropTypes.string,
    processBeginAt: PropTypes.string,
    processDuration: PropTypes.number,
    progressPercent: PropTypes.number,
};
