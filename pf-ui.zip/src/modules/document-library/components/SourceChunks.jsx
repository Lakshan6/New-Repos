import PropTypes from 'prop-types';
import { useState, useCallback, useMemo } from 'react';
import { Accordion, AccordionTab } from 'primereact/accordion';
import { Tag } from 'primereact/tag';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { RAG_APIS } from '../utils/ragApi';

const IMAGE_BASE = RAG_APIS.DOCUMENT_IMAGE_BASE_URL ?? '';
const SIMILARITY_THRESHOLD = 0.55;

const THUMB_IMAGE_STYLE = {
    width: '44px',
    height: '58px',
    objectFit: 'cover',
    borderRadius: '3px',
    border: '1px solid var(--surface-border)',
    flexShrink: 0,
};

const DOCUMENT_NAME_STYLE = {
    maxWidth: '170px',
};

const TAG_STYLE = {
    fontSize: '10px',
    padding: '1px 5px',
};

const CONTENT_TEXT_STYLE = {
    lineHeight: 1.5,
};

const VIEW_FULL_BUTTON_STYLE = {
    width: 'fit-content',
    padding: 0,
    height: 'auto',
    fontSize: '11px',
};

const DIALOG_STYLE = {
    width: '680px',
    maxWidth: '95vw',
};

const DIALOG_CONTENT_STYLE = {
    maxHeight: '60vh',
    overflowY: 'auto',
};

const FULL_IMAGE_STYLE = {
    width: '100%',
    borderRadius: '6px',
    marginBottom: '12px',
    border: '1px solid var(--surface-border)',
};

const HTML_CONTENT_STYLE = {
    overflowX: 'auto',
    fontSize: '0.85rem',
};

const PLAIN_CONTENT_STYLE = {
    whiteSpace: 'pre-wrap',
    fontSize: '0.875rem',
    lineHeight: 1.6,
};

const buildChunkImageUrl = (imageId) =>
    imageId ? `${IMAGE_BASE}/v1/document/image/${imageId}` : null;

const isHtmlContent = (text) =>
    typeof text === 'string' && (text.includes('<table') || text.includes('<tr'));

const truncatePlain = (text, max) => {
    if (!text) return '';

    const plain = text
        .replace(/<[^>]+>/g, ' ')
        .replace(/\s+/g, ' ')
        .trim();

    return plain.length > max ? `${plain.slice(0, max)}…` : plain;
};

// ── ChunkItem ─────────────────────────────────────────────────────────────────
const ChunkItem = ({ chunk, onViewFull }) => {
    const sim = Math.round((chunk.similarity ?? 0) * 100);
    const thumbUrl = buildChunkImageUrl(chunk.image_id);

    const handleViewFull = useCallback(() => {
        onViewFull(chunk);
    }, [chunk, onViewFull]);

    const handleThumbError = useCallback((e) => {
        e.currentTarget.style.display = 'none';
    }, []);

    return (
        <div className="flex gap-2 p-2 border-round-md border-1 surface-border surface-card mb-2">
            {thumbUrl && (
                <img
                    src={thumbUrl}
                    alt={`Page from ${chunk.document_name}`}
                    style={THUMB_IMAGE_STYLE}
                    onError={handleThumbError}
                />
            )}

            <div className="flex flex-column gap-1 flex-1 min-w-0">
                <div className="flex align-items-center justify-content-between gap-1 flex-wrap">
                    <span
                        className="text-xs font-semibold text-primary overflow-hidden text-overflow-ellipsis white-space-nowrap"
                        style={DOCUMENT_NAME_STYLE}
                        title={chunk.document_name}
                    >
                        <i className="pi pi-file-pdf mr-1" aria-hidden="true" />
                        {chunk.document_name}
                    </span>

                    <Tag
                        value={`${sim}% match`}
                        severity={sim >= 70 ? 'success' : 'warning'}
                        style={TAG_STYLE}
                    />
                </div>

                <p className="text-xs text-color-secondary m-0" style={CONTENT_TEXT_STYLE}>
                    {truncatePlain(chunk.content, 160)}
                </p>

                <Button
                    label="View full"
                    text
                    size="small"
                    icon="pi pi-eye"
                    onClick={handleViewFull}
                    aria-label={`View full content from ${chunk.document_name}`}
                    style={VIEW_FULL_BUTTON_STYLE}
                />
            </div>
        </div>
    );
};

ChunkItem.propTypes = {
    chunk: PropTypes.shape({
        content: PropTypes.string,
        document_name: PropTypes.string,
        image_id: PropTypes.string,
        similarity: PropTypes.number,
    }).isRequired,
    onViewFull: PropTypes.func.isRequired,
};

// ── SourceChunks ──────────────────────────────────────────────────────────────
const SourceChunks = ({ chunks }) => {
    const [expandedChunk, setExpandedChunk] = useState(null);

    const filtered = useMemo(
        () => (chunks ?? []).filter((chunk) => (chunk.similarity ?? 0) >= SIMILARITY_THRESHOLD),
        [chunks],
    );

    const handleHide = useCallback(() => {
        setExpandedChunk(null);
    }, []);

    const handleExpandChunk = useCallback((chunk) => {
        setExpandedChunk(chunk);
    }, []);

    const handleFullImageError = useCallback((e) => {
        e.currentTarget.style.display = 'none';
    }, []);

    const dialogImageUrl = useMemo(
        () => buildChunkImageUrl(expandedChunk?.image_id),
        [expandedChunk],
    );

    const htmlContent = useMemo(
        () => ({
            __html: expandedChunk?.content ?? '',
        }),
        [expandedChunk],
    );

    const accordionHeader = useMemo(
        () => (
            <span className="flex align-items-center gap-2">
                <i className="pi pi-book text-sm" aria-hidden="true" />
            </span>
        ),
        [],
    );

    if (!filtered.length) {
        return null;
    }

    return (
        <>
            <div className="mt-2">
                <Accordion>
                    <AccordionTab header={accordionHeader}>
                        <div className="pt-1">
                            {filtered.map((chunk) => (
                                <ChunkItem
                                    key={chunk.id ?? chunk.document_id}
                                    chunk={chunk}
                                    onViewFull={handleExpandChunk}
                                />
                            ))}
                        </div>
                    </AccordionTab>
                </Accordion>
            </div>

            <Dialog
                header={expandedChunk?.document_name ?? 'Source'}
                visible={!!expandedChunk}
                onHide={handleHide}
                style={DIALOG_STYLE}
                maximizable
            >
                {expandedChunk && (
                    <div style={DIALOG_CONTENT_STYLE}>
                        {expandedChunk.image_id && (
                            <img
                                src={dialogImageUrl}
                                alt={`Page from ${expandedChunk.document_name}`}
                                style={FULL_IMAGE_STYLE}
                                onError={handleFullImageError}
                            />
                        )}

                        {isHtmlContent(expandedChunk.content) ? (
                            <div
                                className="ai-html-content"
                                dangerouslySetInnerHTML={htmlContent}
                                style={HTML_CONTENT_STYLE}
                            />
                        ) : (
                            <p style={PLAIN_CONTENT_STYLE}>{expandedChunk.content}</p>
                        )}
                    </div>
                )}
            </Dialog>
        </>
    );
};

SourceChunks.propTypes = {
    chunks: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.string,
            content: PropTypes.string,
            document_id: PropTypes.string,
            document_name: PropTypes.string,
            image_id: PropTypes.string,
            similarity: PropTypes.number,
        }),
    ),
};

SourceChunks.defaultProps = {
    chunks: [],
};

export default SourceChunks;
