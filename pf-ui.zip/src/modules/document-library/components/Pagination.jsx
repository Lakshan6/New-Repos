import PropTypes from 'prop-types';
import { Paginator } from 'primereact/paginator';
import { useCallback } from 'react';

export default function Pagination({ currentPage, totalItems, pageSize, onPageChange }) {
    const handlePageChange = useCallback(
        (e) => {
            onPageChange(e.page + 1);
        },
        [onPageChange],
    );

    if (!totalItems) return null;

    return (
        <Paginator
            first={(currentPage - 1) * pageSize}
            rows={pageSize}
            totalRecords={totalItems}
            onPageChange={handlePageChange}
        />
    );
}

Pagination.propTypes = {
    currentPage: PropTypes.number.isRequired,
    totalItems: PropTypes.number.isRequired,
    pageSize: PropTypes.number.isRequired,
    onPageChange: PropTypes.func.isRequired,
};
