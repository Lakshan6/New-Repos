import { useState, useEffect, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { ProgressSpinner } from 'primereact/progressspinner';
import API_CONFIG from '../utils/apiConfig';
import { getRagAuthHeaders } from '../utils/ragAuth';

const PRIMARY = '#34568C';

const IMAGE_EXTS = ['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg', 'bmp'];
const OFFICE_EXTS = ['docx', 'doc', 'pptx', 'ppt', 'xlsx', 'xls'];
const TEXT_EXTS = ['txt', 'md', 'csv', 'json', 'xml', 'html', 'htm', 'js', 'ts', 'css', 'log'];

const DIALOG_STYLE = {
    width: '90vw',
    maxWidth: '64rem',
    height: '90vh',
};

const DIALOG_CONTENT_STYLE = {
    padding: 0,
    display: 'flex',
    flexDirection: 'column',
    overflow: 'hidden',
};

const DIALOG_PT = {
    root: { className: 'rounded-xl overflow-hidden' },
    header: { className: 'px-6 py-4 border-b bg-white flex-shrink-0' },
    content: { className: 'flex-1 overflow-hidden bg-slate-50 relative' },
};

const HEADER_STYLE = {
    color: '#1f2937',
};

const HEADER_ICON_STYLE = {
    fontSize: '1.2rem',
    color: PRIMARY,
};

const SPINNER_STYLE = {
    width: '48px',
    height: '48px',
};

const OFFICE_ICON_WRAPPER_STYLE = {
    background: 'rgba(52,86,140,0.08)',
};

const OFFICE_ICON_STYLE = {
    fontSize: '3rem',
    color: PRIMARY,
};

const FILE_ICON_STYLE = {
    fontSize: '4rem',
};

const BUTTON_STYLE = {
    backgroundColor: PRIMARY,
    border: 'none',
};

function getExt(filename) {
    return (filename?.split('.').pop() || '').toLowerCase();
}

export default function FilePreviewDialog({ file, onClose }) {
    const [objectUrl, setObjectUrl] = useState(null);
    const [textContent, setTextContent] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState(null);

    const ext = getExt(file?.name);

    const isImage = useMemo(() => IMAGE_EXTS.includes(ext), [ext]);
    const isPdf = useMemo(() => ext === 'pdf', [ext]);
    const isText = useMemo(() => TEXT_EXTS.includes(ext), [ext]);
    const isOffice = useMemo(() => OFFICE_EXTS.includes(ext), [ext]);

    useEffect(() => {
        if (!file?.id) return undefined;

        let blobUrl = null;

        const loadDocument = async () => {
            setLoading(true);
            setError(null);
            setObjectUrl(null);
            setTextContent(null);

            try {
                const DOCUMENT_GET_API = API_CONFIG.DOCUMENT_GET;

                if (!DOCUMENT_GET_API) {
                    throw new Error('VITE_DOCUMENT_GET is not configured in .env');
                }

                const url = `${DOCUMENT_GET_API}/${file.id}`;

                const res = await fetch(url, {
                    method: 'GET',
                    headers: getRagAuthHeaders(false),
                    credentials: 'include',
                });

                if (!res.ok) {
                    const errText = await res.text().catch(() => '');

                    throw new Error(`Server returned ${res.status} – ${errText || 'No details'}`);
                }

                const blob = await res.blob();

                if (isText) {
                    const text = await blob.text();
                    setTextContent(text);
                } else {
                    blobUrl = URL.createObjectURL(blob);
                    setObjectUrl(blobUrl);
                }
            } catch (err) {
                console.error('Document fetch failed:', err);

                if (isPdf || isImage || isOffice) {
                    const DOCUMENT_GET_API = API_CONFIG.DOCUMENT_GET;

                    const directUrl = DOCUMENT_GET_API ? `${DOCUMENT_GET_API}/${file.id}` : null;

                    if (directUrl) {
                        setObjectUrl(directUrl);
                        setError(null);
                        return;
                    }
                }

                setError(err.message || 'Failed to load document');
            } finally {
                setLoading(false);
            }
        };

        loadDocument();

        return () => {
            if (blobUrl) {
                URL.revokeObjectURL(blobUrl);
            }
        };
    }, [file?.id, isImage, isOffice, isPdf, isText]);

    const handleDownload = useCallback(() => {
        if (!objectUrl) return;

        const a = document.createElement('a');

        a.href = objectUrl;
        a.download = file.name;

        a.click();
    }, [file?.name, objectUrl]);

    const dialogHeader = useMemo(
        () => (
            <div
                className="flex items-center gap-3 text-lg font-semibold truncate"
                style={HEADER_STYLE}
            >
                <i className="pi pi-file" style={HEADER_ICON_STYLE} />
                <span className="truncate">{file?.name}</span>
            </div>
        ),
        [file?.name],
    );

    return (
        <Dialog
            visible={!!file}
            onHide={onClose}
            header={dialogHeader}
            style={DIALOG_STYLE}
            contentStyle={DIALOG_CONTENT_STYLE}
            pt={DIALOG_PT}
        >
            <div className="flex-1 overflow-hidden bg-slate-50 relative h-full">
                {loading && (
                    <div className="absolute inset-0 flex flex-col items-center justify-center gap-4 bg-slate-50/95 z-10">
                        <ProgressSpinner style={SPINNER_STYLE} />
                        <p className="text-slate-600 text-base font-medium">Loading document…</p>
                    </div>
                )}

                {!loading && error && (
                    <div className="flex flex-col items-center justify-center h-full gap-5 px-12 text-center">
                        <i className="pi pi-file text-slate-300" style={FILE_ICON_STYLE} />

                        <p className="text-slate-700 font-semibold text-xl">
                            Failed to load document
                        </p>

                        <p className="text-slate-500 text-base max-w-xl break-words">{error}</p>
                    </div>
                )}

                {!loading && !error && (
                    <>
                        {isPdf && objectUrl && (
                            <iframe
                                src={objectUrl}
                                title={file.name}
                                className="w-full h-full border-0"
                            />
                        )}

                        {isImage && objectUrl && (
                            <div className="flex items-center justify-center h-full p-8 overflow-auto bg-slate-50">
                                <img
                                    src={objectUrl}
                                    alt={file.name}
                                    className="max-w-full max-h-full object-contain rounded-xl shadow-lg"
                                />
                            </div>
                        )}

                        {isText && textContent !== null && (
                            <div className="h-full overflow-auto p-8">
                                <pre className="text-base leading-relaxed text-slate-800 font-mono whitespace-pre-wrap break-words bg-white border border-slate-200 rounded-xl p-6 h-full shadow-inner">
                                    {textContent}
                                </pre>
                            </div>
                        )}

                        {isOffice && (
                            <div className="flex flex-col items-center justify-center h-full gap-6 px-12 text-center">
                                <div
                                    className="h-24 w-24 rounded-3xl flex items-center justify-center shadow-md"
                                    style={OFFICE_ICON_WRAPPER_STYLE}
                                >
                                    <i className="pi pi-file" style={OFFICE_ICON_STYLE} />
                                </div>

                                <div className="max-w-lg">
                                    <p className="text-slate-800 font-semibold text-xl break-words mb-3">
                                        {file.name}
                                    </p>

                                    <p className="text-slate-600 text-lg">
                                        Preview not available for{' '}
                                        <span className="font-semibold uppercase">.{ext}</span>{' '}
                                        files in browser.
                                    </p>
                                </div>

                                {objectUrl && (
                                    <Button
                                        label="Download File"
                                        icon="pi pi-download"
                                        onClick={handleDownload}
                                        style={BUTTON_STYLE}
                                    />
                                )}
                            </div>
                        )}

                        {!isPdf && !isImage && !isText && !isOffice && (
                            <div className="flex flex-col items-center justify-center h-full gap-6 px-12 text-center">
                                <i className="pi pi-file text-slate-300" style={FILE_ICON_STYLE} />

                                <p className="text-slate-600 font-medium text-xl">
                                    No preview available for this file type
                                </p>

                                {objectUrl && (
                                    <Button
                                        label="Download"
                                        icon="pi pi-download"
                                        onClick={handleDownload}
                                        style={BUTTON_STYLE}
                                    />
                                )}
                            </div>
                        )}
                    </>
                )}
            </div>
        </Dialog>
    );
}

FilePreviewDialog.propTypes = {
    file: PropTypes.shape({
        id: PropTypes.string,
        name: PropTypes.string,
        size: PropTypes.number,
    }),
    onClose: PropTypes.func.isRequired,
};

FilePreviewDialog.defaultProps = {
    file: null,
};
