import { useEffect, useState, useMemo, useCallback } from 'react';
import { useNavigate, useParams } from 'react-router-dom';
import { toast } from '../utils/toast';
import { STORAGE_KEYS } from '@shared/utils';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Checkbox } from 'primereact/checkbox';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Card, PageLayout } from '@shared/components';

import { useDatasetAPI } from '../hooks/useDatasetAPI';
import { useUserManagement } from '../hooks/useUserManagement';
import { useFileUpload } from '../hooks/useFileUpload';
import { useParsingWithPolling } from '../hooks/useParsingWithPolling';
import { ParsingStatusCell } from '../components/ParsingStatusCell';
import { getFileStatusBadge, filterFiles, filterUsers } from '../utils/fileHelpers';
import FilePreviewDialog from '../components/FilePreviewDialog';
import { getRagTenantId } from '../utils/tenant';
import { getRagAuthHeaders } from '../utils/ragAuth';
import API_CONFIG from '../utils/apiConfig';
import { useMutationApi } from '@shared/hooks';
const PRIMARY = '#34568C';
const PRIMARY_BG = 'rgba(52,86,140,0.08)';

// ── Sort helpers ──────────────────────────────────────────────────────────────
function cycleSort(prev, key) {
    if (prev.key !== key) return { key, direction: 'asc' };
    if (prev.direction === 'asc') return { key, direction: 'desc' };
    if (prev.direction === 'desc') return { key: null, direction: null };
    return { key, direction: 'asc' };
}

function sortList(list, sortConfig, dateKeys = []) {
    if (!sortConfig.key || !sortConfig.direction) return list;
    return [...list].sort((a, b) => {
        let valA = a[sortConfig.key] ?? '';
        let valB = b[sortConfig.key] ?? '';
        if (dateKeys.includes(sortConfig.key)) {
            valA = valA ? new Date(valA) : new Date(0);
            valB = valB ? new Date(valB) : new Date(0);
            return sortConfig.direction === 'asc' ? valA - valB : valB - valA;
        }
        if (typeof valA === 'number' && typeof valB === 'number') {
            return sortConfig.direction === 'asc' ? valA - valB : valB - valA;
        }
        valA = valA.toString().toLowerCase();
        valB = valB.toString().toLowerCase();
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
    });
}

export default function DatasetDetailPage() {
    const navigate = useNavigate();
    const { id } = useParams();

    const [activeTab, setActiveTab] = useState('files');
    const [files, setFiles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [detailsLoading, setDetailsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [userSearchQuery, setUserSearchQuery] = useState('');
    const [selectedFiles, setSelectedFiles] = useState(new Set());
    const [showUploadDialog, setShowUploadDialog] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);
    const [datasetInfo, setDatasetInfo] = useState(null);
    const [hoverFileId, setHoverFileId] = useState(null);
    const [showUserDropdown, setShowUserDropdown] = useState(false);
    const [previewFile, setPreviewFile] = useState(null);
    const [fileSortConfig, setFileSortConfig] = useState({ key: null, direction: null });
    const [userSortConfig, setUserSortConfig] = useState({ key: null, direction: null });

    const handleFileSort = useCallback(
        (key) => setFileSortConfig((prev) => cycleSort(prev, key)),
        [],
    );
    const handleUserSort = useCallback(
        (key) => setUserSortConfig((prev) => cycleSort(prev, key)),
        [],
    );

    const { fetchDatasetDetails, fetchFiles: fetchFilesAPI } = useDatasetAPI();
    const tenantId = getRagTenantId();

    const {
        users,
        allUsers,
        userLoading,
        fetchAccessedUsers,
        fetchAllTeamUsers,
        addUser,
        deleteUser,
    } = useUserManagement(id, tenantId);

    const { uploading, uploadFile } = useFileUpload(id, tenantId);

    const formatUploadDate = (dateStr) => {
        if (!dateStr) return '-';
        const [datePart, timePart] = dateStr.split('T');
        if (!datePart) return '-';
        const [yyyy, mm, dd] = datePart.split('-');
        return `${dd}-${mm}-${yyyy} ${timePart || ''}`.trim();
    };

    const formatDate = (dateStr) => {
        if (!dateStr) return '-';
        const [datePart, timePart] = dateStr.split('T');
        const [yyyy, mm, dd] = datePart.split('-');
        return `${dd}-${mm}-${yyyy} ${timePart}`;
    };

    const { startParsing, cancelParsing, getParsingState, parsingStates } = useParsingWithPolling(
        id,
        tenantId,
        fetchFilesAPI,
    );

    useEffect(() => {
        const loadDatasetDetails = async () => {
            if (!id) return;
            setDetailsLoading(true);
            try {
                const details = await fetchDatasetDetails(id);
                setDatasetInfo(details);
            } catch {
                toast.error('❌ Failed to load dataset details');
            } finally {
                setDetailsLoading(false);
            }
        };
        loadDatasetDetails();
    }, [id, fetchDatasetDetails]);

    useEffect(() => {
        const loadData = async () => {
            if (!datasetInfo || !tenantId) return;
            try {
                const filesData = await fetchFilesAPI(datasetInfo.id);
                setFiles(filesData);
                await fetchAccessedUsers();
                await fetchAllTeamUsers();
            } catch {
                toast.error('❌ Failed to load files and users');
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [datasetInfo, tenantId, fetchFilesAPI, fetchAccessedUsers, fetchAllTeamUsers]);

    const availableUsers = useMemo(() => {
        const accessedEmails = new Set(users.map((u) => (typeof u === 'string' ? u : u.email)));
        return allUsers.filter((user) => {
            const userEmail = typeof user === 'string' ? user : user.email;
            return !accessedEmails.has(userEmail);
        });
    }, [allUsers, users]);

    const filteredFiles = useMemo(() => filterFiles(files, searchQuery), [files, searchQuery]);
    const filteredUsers = useMemo(
        () => filterUsers(availableUsers, userSearchQuery),
        [availableUsers, userSearchQuery],
    );

    const sortedFiles = useMemo(() => {
        const base = fileSortConfig.key
            ? sortList(filteredFiles, fileSortConfig, ['create_time'])
            : [...filteredFiles].sort((a, b) => new Date(b.create_time) - new Date(a.create_time));

        // Map over the files to inject parsing state and selection so DataTable detects changes
        const parsingStatesMap = getParsingState ? parsingStates || new Map() : new Map();

        return base.map((file) => ({
            ...file,
            _parsingUpdate: parsingStatesMap.get(String(file.id))?.progress || 0,
            _selected: selectedFiles.has(file.id),
        }));
    }, [filteredFiles, fileSortConfig, selectedFiles, parsingStates, getParsingState]);

    const sortedUsers = useMemo(() => {
        const base = userSortConfig.key
            ? sortList(users, userSortConfig, ['updateDate'])
            : [...users].sort((a, b) => {
                  const dateA = a.updateDate ? new Date(a.updateDate) : new Date(0);
                  const dateB = b.updateDate ? new Date(b.updateDate) : new Date(0);
                  return dateB - dateA;
              });
        return base;
    }, [users, userSortConfig]);

    const handleFileSelect = useCallback((e) => {
        const file = e.target.files?.[0];
        if (file) {
            setSelectedFile(file);
            toast.success(`📁 File selected: ${file.name}`);
        }
    }, []);

    const handleFileUpload = useCallback(async () => {
        if (!selectedFile) {
            toast.warning('Please select a file to upload');
            return;
        }
        if (!datasetInfo?.name) {
            toast.error('Dataset name not loaded');
            return;
        }
        const fileName = selectedFile.name;
        const toastId = toast.loading(`Uploading "${fileName}"...`);
        try {
            await uploadFile(selectedFile, datasetInfo.name, async () => {
                setShowUploadDialog(false);
                setSelectedFile(null);
                const filesData = await fetchFilesAPI(id);
                setFiles(filesData);
                toast.dismiss(toastId);
            });
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Failed to upload "${fileName}": ${err.message}`);
        }
    }, [selectedFile, datasetInfo, uploadFile, fetchFilesAPI, id]);

    const handleParseFile = useCallback(
        async (documentId, fileName) => {
            toast.loading(`⏳ Starting to parse "${fileName}"...`);
            await startParsing(documentId, fileName);
        },
        [startParsing],
    );

    const handleCancelParsing = useCallback(
        async (documentId, fileName) => {
            toast.loading(`⛔ Cancelling parsing for "${fileName}"...`);
            await cancelParsing(documentId, fileName);
        },
        [cancelParsing],
    );

    const handleBulkParseFiles = useCallback(async () => {
        if (selectedFiles.size === 0) return;
        const docIds = Array.from(selectedFiles);
        const fileNames = docIds
            .map((fid) => filteredFiles.find((f) => f.id === fid)?.name)
            .filter(Boolean);
        const toastId = toast.loading(`Parsing ${docIds.length} file(s)...`);
        try {
            await startParsing(docIds, fileNames);
            toast.dismiss(toastId);
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Failed to parse files: ${err.message}`);
        }
    }, [selectedFiles, filteredFiles, startParsing]);

    const handleBulkCancelParsing = useCallback(async () => {
        if (selectedFiles.size === 0) return;
        const docIds = Array.from(selectedFiles);
        const fileNames = docIds
            .map((fid) => filteredFiles.find((f) => f.id === fid)?.name)
            .filter(Boolean);
        const toastId = toast.loading(`Cancelling parsing for ${docIds.length} file(s)...`);
        try {
            await cancelParsing(docIds, fileNames);
            toast.dismiss(toastId);
            toast.success(`✅ Parsing cancelled for ${docIds.length} file(s)`);
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Failed to cancel parsing: ${err.message}`);
        }
    }, [selectedFiles, filteredFiles, cancelParsing]);

    const handleDeleteSingleFile = useCallback(
        async (fileId, fileName) => {
            if (
                !window.confirm(
                    `Are you sure you want to delete "${fileName}"? This action cannot be undone.`,
                )
            ) {
                toast.info('Delete operation cancelled');
                return;
            }
            const toastId = toast.loading(`Deleting "${fileName}"...`);
            try {
                const response = await fetch(API_CONFIG.DOCUMENT_DELETE, {
                    method: 'POST',
                    headers: getRagAuthHeaders(),
                    body: JSON.stringify({ doc_id: [fileId] }),
                });
                const data = await response.json();
                if (response.ok && data.code === 0) {
                    toast.dismiss(toastId);
                    const updatedFiles = await fetchFilesAPI(id);
                    setFiles(updatedFiles);
                    setSelectedFiles((prev) => {
                        const s = new Set(prev);
                        s.delete(fileId);
                        return s;
                    });
                    toast.success(`✅ File "${fileName}" deleted successfully!`);
                } else {
                    toast.dismiss(toastId);
                    toast.error(
                        `❌ Failed to delete "${fileName}": ${data.message || 'Unknown error'}`,
                    );
                }
            } catch (err) {
                toast.dismiss(toastId);
                toast.error(`❌ Error deleting "${fileName}": ${err.message}`);
            }
        },
        [fetchFilesAPI, id],
    );

    const handleBulkDeleteFiles = useCallback(async () => {
        if (selectedFiles.size === 0) return;
        if (
            !window.confirm(
                `Are you sure you want to delete ${selectedFiles.size} file(s)? This action cannot be undone.`,
            )
        ) {
            toast.info('Delete operation cancelled');
            return;
        }
        const docIds = Array.from(selectedFiles);
        const toastId = toast.loading(`Deleting ${docIds.length} file(s)...`);
        try {
            const response = await fetch(API_CONFIG.DOCUMENT_DELETE, {
                method: 'POST',
                headers: getRagAuthHeaders(),
                body: JSON.stringify({ doc_id: docIds }),
            });
            const data = await response.json();
            if (response.ok && data.code === 0) {
                toast.dismiss(toastId);
                const updatedFiles = await fetchFilesAPI(id);
                setFiles(updatedFiles);
                setSelectedFiles(new Set());
                toast.success(`✅ ${docIds.length} file(s) deleted successfully!`);
            } else {
                toast.dismiss(toastId);
                toast.error(`❌ Failed to delete files: ${data.message || 'Unknown error'}`);
            }
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Error deleting files: ${err.message}`);
        }
    }, [selectedFiles, fetchFilesAPI, id]);

    const handleAddUser = useCallback(
        async (emailOrUser) => {
            const email = typeof emailOrUser === 'string' ? emailOrUser : emailOrUser.email;
            if (!email.trim()) {
                toast.warning('⚠️ Please enter a valid email address');
                return;
            }
            const toastId = toast.loading(`Adding user ${email}...`);
            try {
                await addUser(email, datasetInfo?.name);
                setUserSearchQuery('');
                setShowUserDropdown(false);
                toast.dismiss(toastId);
            } catch (err) {
                toast.dismiss(toastId);
                toast.error(`❌ Failed to add user: ${err.message || 'Unknown error'}`);
            }
        },
        [addUser, datasetInfo?.name],
    );

    const handleDeleteUser = useCallback(
        async (emailOrUser) => {
            const email = typeof emailOrUser === 'string' ? emailOrUser : emailOrUser.email;
            if (!window.confirm(`Remove access for ${email}?`)) {
                toast.info('Delete operation cancelled');
                return;
            }
            const toastId = toast.loading(`Removing access for ${email}...`);
            try {
                await deleteUser(email);
                toast.dismiss(toastId);
                toast.success(`✅ User ${email} access removed successfully!`);
            } catch (err) {
                toast.dismiss(toastId);
                toast.error(`❌ Failed to remove user: ${err.message || 'Unknown error'}`);
            }
        },
        [deleteUser],
    );

    const toggleFileSelection = useCallback((fileId) => {
        setSelectedFiles((prev) => {
            const s = new Set(prev);
            s.has(fileId) ? s.delete(fileId) : s.add(fileId);
            return s;
        });
    }, []);

    const toggleAllFiles = useCallback(() => {
        setSelectedFiles((prev) =>
            prev.size === filteredFiles.length
                ? new Set()
                : new Set(filteredFiles.map((f) => f.id)),
        );
    }, [filteredFiles]);

    // Stable tab + nav handlers
    const handleTabFiles = useCallback(() => setActiveTab('files'), []);
    const handleTabUsers = useCallback(() => setActiveTab('users'), []);
    const handleBack = useCallback(() => navigate(-1), [navigate]);
    const handleOpenUpload = useCallback(() => setShowUploadDialog(true), []);
    const handleCloseUpload = useCallback(() => {
        setShowUploadDialog(false);
        setSelectedFile(null);
    }, []);
    const handleOpenUserDrop = useCallback(() => setShowUserDropdown(true), []);
    const handleCloseUserDrop = useCallback(() => setShowUserDropdown(false), []);
    const handleClearUserSearch = useCallback(() => setUserSearchQuery(''), []);
    const handleUserSearchChange = useCallback((e) => setUserSearchQuery(e.target.value), []);
    const handleFileSearchChange = useCallback((e) => setSearchQuery(e.target.value), []);
    const handleClosePreview = useCallback(() => setPreviewFile(null), []);
    const handleAddUserFromQuery = useCallback(
        () => handleAddUser(userSearchQuery),
        [handleAddUser, userSearchQuery],
    );

    // ── Loading / error states ────────────────────────────────────────────────
    if (detailsLoading) {
        return (
            <div className="w-full min-h-screen bg-white flex items-center justify-center">
                <div className="text-center">
                    <ProgressSpinner
                        style={{ width: '48px', height: '48px' }}
                        className="mx-auto mb-4"
                    />
                    <p className="text-slate-600">Loading dataset details...</p>
                </div>
            </div>
        );
    }

    if (!datasetInfo) {
        return (
            <div className="w-full min-h-screen bg-white flex flex-col items-center justify-center">
                <p className="text-red-600 text-lg font-semibold mb-4">Failed to load dataset</p>
                <Button label="Back to Dashboard" onClick={handleBack} />
            </div>
        );
    }

    // ── Column body templates ─────────────────────────────────────────────────

    const fileCheckboxTemplate = (file) => (
        <Checkbox
            checked={selectedFiles.has(file.id)}
            onChange={() => toggleFileSelection(file.id)}
        />
    );

    const fileNameTemplate = (file) => (
        <button
            onClick={() => setPreviewFile(file)}
            className="flex items-center gap-2 group text-left transition-colors"
            title={`Preview ${file.name}`}
            style={{ color: 'inherit' }}
        >
            <i className="pi pi-file flex-shrink-0" style={{ color: '#ef4444' }} />
            <span
                className="group-hover:underline underline-offset-2 overflow-hidden text-overflow-ellipsis white-space-nowrap"
                style={{ color: PRIMARY, maxWidth: '250px', display: 'inline-block' }}
            >
                {file.name}
            </span>
            <i
                className="pi pi-eye flex-shrink-0 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ color: PRIMARY }}
            />
        </button>
    );

    const fileDateTemplate = (file) => (
        <span className="text-slate-600 text-sm">{formatUploadDate(file.create_date)}</span>
    );

    const fileStatusTemplate = (file) => {
        const statusBadge = getFileStatusBadge(file.status);
        return (
            <span
                className={`inline-flex items-center px-2 py-1 rounded text-xs font-semibold ${statusBadge.className}`}
            >
                {statusBadge.label}
            </span>
        );
    };

    const fileParseTemplate = (file) => {
        const parsingState = getParsingState(file.id);
        return (
            <ParsingStatusCell
                file={file}
                parsingState={parsingState}
                onStartParsing={handleParseFile}
                onCancelParsing={handleCancelParsing}
            />
        );
    };

    const fileActionTemplate = (file) => (
        <button
            onClick={() => handleDeleteSingleFile(file.id, file.name)}
            onMouseEnter={() => setHoverFileId(file.id)}
            onMouseLeave={() => setHoverFileId(null)}
            className={`p-2 rounded-lg transition-all duration-200 ${
                hoverFileId === file.id
                    ? 'bg-red-50 text-red-600 shadow-md scale-110'
                    : 'text-slate-400 hover:text-red-600 hover:bg-red-50'
            }`}
            title="Delete file"
        >
            <i className="pi pi-trash" style={{ fontSize: '1.1rem' }} />
        </button>
    );

    const userEmailTemplate = (user) => (
        <span
            className="font-medium text-slate-900 overflow-hidden text-overflow-ellipsis white-space-nowrap block"
            style={{ maxWidth: '250px' }}
            title={typeof user === 'string' ? user : user.email}
        >
            {typeof user === 'string' ? user : user.email}
        </span>
    );

    const userNicknameTemplate = (user) => (
        <span
            className="text-slate-600 overflow-hidden text-overflow-ellipsis white-space-nowrap block"
            style={{ maxWidth: '200px' }}
            title={typeof user === 'string' ? 'N/A' : user.nickname || 'N/A'}
        >
            {typeof user === 'string' ? 'N/A' : user.nickname || 'N/A'}
        </span>
    );

    const userDateTemplate = (user) => (
        <span className="text-slate-600">{formatDate(user.updateDate)}</span>
    );

    const userActionTemplate = (user) => (
        <Button
            icon="pi pi-trash"
            rounded
            text
            severity="danger"
            className="h-8"
            onClick={() => handleDeleteUser(user)}
        />
    );

    // ── Dialog footers ────────────────────────────────────────────────────────

    const uploadFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined disabled={uploading} onClick={handleCloseUpload} />
            <Button
                label={uploading ? 'Uploading...' : 'Upload'}
                icon={uploading ? 'pi pi-spin pi-spinner' : undefined}
                disabled={!selectedFile || uploading}
                style={{ backgroundColor: PRIMARY, border: 'none' }}
                onClick={handleFileUpload}
            />
        </div>
    );

    const addUserFooter = (
        <div className="flex gap-2 justify-end">
            <Button
                label="Discard"
                outlined
                onClick={() => {
                    handleClearUserSearch();
                    handleCloseUserDrop();
                }}
                className="border-slate-300 text-slate-700"
            />
            <Button
                label="Add User"
                icon="pi pi-user-plus"
                disabled={
                    !userSearchQuery.trim() ||
                    !availableUsers.some((u) => {
                        const userEmail = typeof u === 'string' ? u : u.email;
                        return userEmail === userSearchQuery.trim();
                    })
                }
                style={{ backgroundColor: '#22c55e', border: 'none' }}
                onClick={handleAddUserFromQuery}
            />
        </div>
    );

    return (
        <PageLayout className="w-full">
            <PageLayout.Header
                title={datasetInfo?.name || 'Dataset Details'}
                actions={
                    <div
                        className="flex bg-white shadow-md rounded-full px-4 py-2 gap-2 border"
                        style={{ borderColor: PRIMARY }}
                    >
                        <button
                            onClick={handleBack}
                            className="inline-flex items-center gap-2 px-4 py-2 rounded-full border transition-all duration-200"
                            style={{
                                borderColor: '#fca5a5',
                                background: 'rgba(239,68,68,0.05)',
                                color: '#dc2626',
                            }}
                        >
                            <i className="pi pi-chevron-left text-sm" />
                            <span className="font-medium">Back</span>
                        </button>
                        <div className="flex rounded-full gap-2">
                            <button
                                onClick={handleTabFiles}
                                className="px-6 py-2 rounded-full text-base font-medium transition flex items-center gap-1.5"
                                style={
                                    activeTab === 'files'
                                        ? {
                                              background: PRIMARY,
                                              color: '#fff',
                                              boxShadow: '0 2px 8px rgba(52,86,140,0.3)',
                                          }
                                        : { color: PRIMARY }
                                }
                            >
                                <i className="pi pi-file" />
                                Files ({files.length})
                            </button>
                            {datasetInfo?.name?.toLowerCase() !== 'self-document' && (
                                <button
                                    onClick={handleTabUsers}
                                    className="px-6 py-2 rounded-full text-base font-medium transition flex items-center gap-1.5"
                                    style={
                                        activeTab === 'users'
                                            ? {
                                                  background: PRIMARY,
                                                  color: '#fff',
                                                  boxShadow: '0 2px 8px rgba(52,86,140,0.3)',
                                              }
                                            : { color: PRIMARY }
                                    }
                                >
                                    <i className="pi pi-users" />
                                    Users with Access ({users.length})
                                </button>
                            )}
                        </div>
                    </div>
                }
            />

            <PageLayout.Content>
                <Card>
                    {/* FILES TAB */}
                    {activeTab === 'files' && (
                        <div className="space-y-6">
                            {/* Toolbar */}
                            <div
                                className="bg-white rounded-lg shadow-md p-3 border-l-4"
                                style={{ borderLeftColor: PRIMARY }}
                            >
                                <div className="flex items-center justify-between gap-3 mb-3">
                                    <span className="text-xs font-semibold text-slate-700">
                                        Selected: {selectedFiles.size} Files
                                    </span>
                                    {selectedFiles.size > 0 && (
                                        <div className="flex items-center gap-2">
                                            <Button
                                                label={`Parse All (${selectedFiles.size})`}
                                                style={{
                                                    backgroundColor: '#22c55e',
                                                    border: 'none',
                                                    height: '2rem',
                                                    fontSize: '0.75rem',
                                                    padding: '0 0.75rem',
                                                }}
                                                onClick={handleBulkParseFiles}
                                            />
                                            <Button
                                                label={`Cancel Parse (${selectedFiles.size})`}
                                                style={{
                                                    backgroundColor: '#f97316',
                                                    border: 'none',
                                                    height: '2rem',
                                                    fontSize: '0.75rem',
                                                    padding: '0 0.75rem',
                                                }}
                                                onClick={handleBulkCancelParsing}
                                            />
                                            <Button
                                                label={`Delete (${selectedFiles.size})`}
                                                severity="danger"
                                                style={{
                                                    height: '2rem',
                                                    fontSize: '0.75rem',
                                                    padding: '0 0.75rem',
                                                }}
                                                onClick={handleBulkDeleteFiles}
                                            />
                                        </div>
                                    )}
                                </div>
                                <div className="flex items-center gap-2">
                                    <span className="p-input-icon-left relative flex-1">
                                        <i className="pi pi-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                                        <InputText
                                            placeholder="Search files..."
                                            value={searchQuery}
                                            onChange={handleFileSearchChange}
                                            className="pl-9 py-1 text-sm w-full border-slate-300"
                                        />
                                    </span>
                                    <Button
                                        label="Add File"
                                        icon="pi pi-upload"
                                        style={{
                                            backgroundColor: PRIMARY,
                                            border: 'none',
                                            height: '2rem',
                                            fontSize: '0.75rem',
                                            padding: '0 0.75rem',
                                        }}
                                        onClick={handleOpenUpload}
                                    />
                                </div>
                            </div>

                            {/* Files Table */}
                            <div
                                className="bg-white rounded-lg shadow-md overflow-x-auto border border-slate-200 max-w-full"
                                style={{ minHeight: '300px' }}
                            >
                                {loading ? (
                                    <div className="flex justify-center items-center py-12">
                                        <ProgressSpinner
                                            style={{ width: '48px', height: '48px' }}
                                        />
                                    </div>
                                ) : sortedFiles.length === 0 ? (
                                    <div className="flex flex-col items-center justify-center py-12">
                                        <i
                                            className="pi pi-file text-slate-300 mb-4"
                                            style={{ fontSize: '4rem' }}
                                        />
                                        <p className="text-slate-500 text-lg font-semibold">
                                            No files found
                                        </p>
                                    </div>
                                ) : (
                                    <DataTable
                                        value={sortedFiles}
                                        tableStyle={{ minWidth: '40rem' }}
                                        pt={{ headerRow: { style: { background: PRIMARY_BG } } }}
                                    >
                                        <Column
                                            header={
                                                <Checkbox
                                                    checked={
                                                        selectedFiles.size ===
                                                            filteredFiles.length &&
                                                        filteredFiles.length > 0
                                                    }
                                                    onChange={toggleAllFiles}
                                                />
                                            }
                                            body={fileCheckboxTemplate}
                                            style={{ width: '3rem' }}
                                            headerClassName="py-4"
                                        />
                                        <Column
                                            field="name"
                                            header="Name"
                                            sortable
                                            body={fileNameTemplate}
                                            headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                            onHeaderClick={() => handleFileSort('name')}
                                        />
                                        <Column
                                            field="create_date"
                                            header="Upload Date"
                                            sortable
                                            body={fileDateTemplate}
                                            headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                            onHeaderClick={() => handleFileSort('create_time')}
                                        />
                                        <Column
                                            field="status"
                                            header="Enabled"
                                            body={fileStatusTemplate}
                                            headerStyle={{
                                                color: PRIMARY,
                                                fontWeight: 700,
                                                textAlign: 'center',
                                            }}
                                            bodyClassName="text-center"
                                        />
                                        <Column
                                            header="Parse"
                                            body={fileParseTemplate}
                                            headerStyle={{
                                                color: PRIMARY,
                                                fontWeight: 700,
                                                textAlign: 'center',
                                            }}
                                            bodyClassName="text-center"
                                        />
                                        <Column
                                            header="Action"
                                            body={fileActionTemplate}
                                            headerStyle={{
                                                color: PRIMARY,
                                                fontWeight: 700,
                                                textAlign: 'center',
                                            }}
                                            bodyClassName="text-center"
                                        />
                                    </DataTable>
                                )}
                            </div>
                        </div>
                    )}

                    {/* USERS TAB */}
                    {activeTab === 'users' && (
                        <div className="space-y-6">
                            <div className="flex justify-end">
                                <Button
                                    label="Add Team Member to Get Access"
                                    icon="pi pi-user-plus"
                                    style={{ backgroundColor: '#22c55e', border: 'none' }}
                                    onClick={handleOpenUserDrop}
                                />
                            </div>

                            <div
                                className="bg-white rounded-lg shadow-md p-6 border-l-4"
                                style={{ borderLeftColor: PRIMARY }}
                            >
                                <h3 className="text-lg font-bold text-slate-900 mb-4 flex items-center gap-2">
                                    <i
                                        className="pi pi-lock"
                                        style={{ fontSize: '1.3rem', color: PRIMARY }}
                                    />
                                    Current Members with Access ({users.length})
                                </h3>

                                <div className="max-h-[calc(100vh-300px)] overflow-y-auto overflow-x-auto max-w-full">
                                    {userLoading ? (
                                        <div className="flex justify-center py-8">
                                            <ProgressSpinner
                                                style={{ width: '32px', height: '32px' }}
                                            />
                                        </div>
                                    ) : users.length === 0 ? (
                                        <div className="text-center py-8 text-slate-500">
                                            <p className="text-sm">No users have access yet</p>
                                        </div>
                                    ) : (
                                        <DataTable
                                            value={sortedUsers}
                                            tableStyle={{ minWidth: '30rem' }}
                                            pt={{
                                                headerRow: { style: { background: PRIMARY_BG } },
                                            }}
                                        >
                                            <Column
                                                field="email"
                                                header="Email"
                                                sortable
                                                body={userEmailTemplate}
                                                headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                                onHeaderClick={() => handleUserSort('email')}
                                            />
                                            <Column
                                                field="nickname"
                                                header="Nickname"
                                                sortable
                                                body={userNicknameTemplate}
                                                headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                                onHeaderClick={() => handleUserSort('nickname')}
                                            />
                                            <Column
                                                field="updateDate"
                                                header="Last Accessed Date"
                                                sortable
                                                body={userDateTemplate}
                                                headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                                onHeaderClick={() => handleUserSort('updateDate')}
                                            />
                                            <Column
                                                header="Action"
                                                body={userActionTemplate}
                                                headerStyle={{
                                                    color: PRIMARY,
                                                    fontWeight: 700,
                                                    textAlign: 'center',
                                                }}
                                                bodyClassName="text-center"
                                            />
                                        </DataTable>
                                    )}
                                </div>
                            </div>
                        </div>
                    )}
                </Card>
            </PageLayout.Content>

            {/* FILE PREVIEW DIALOG */}
            {previewFile && <FilePreviewDialog file={previewFile} onClose={handleClosePreview} />}

            {/* UPLOAD DIALOG */}
            <Dialog
                visible={showUploadDialog}
                onHide={handleCloseUpload}
                header="Upload File to Dataset"
                footer={uploadFooter}
                style={{ width: '28rem' }}
            >
                <div className="space-y-4">
                    <button
                        type="button"
                        className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition w-full"
                        style={{ borderColor: PRIMARY }}
                        onClick={() => document.getElementById('fileInput')?.click()}
                    >
                        <i
                            className="pi pi-upload mb-2"
                            style={{ fontSize: '2rem', color: PRIMARY }}
                        />
                        <p className="text-sm font-medium text-slate-900 mt-2">
                            {selectedFile ? selectedFile.name : 'Click to select a file'}
                        </p>
                        <p className="text-xs text-slate-500 mt-1">
                            {selectedFile
                                ? `Size: ${(selectedFile.size / 1024 / 1024).toFixed(2)} MB`
                                : 'PDF, DOC, DOCX, TXT, Images, etc.'}
                        </p>
                        <input
                            id="fileInput"
                            type="file"
                            onChange={handleFileSelect}
                            className="hidden"
                            accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.pptx,.ppt,.xlsx,.xls"
                        />
                    </button>
                    {selectedFile && (
                        <div
                            className="rounded-lg p-3"
                            style={{
                                background: 'rgba(52,86,140,0.08)',
                                border: `1px solid ${PRIMARY}`,
                            }}
                        >
                            <p className="text-sm text-slate-700">
                                <span className="font-semibold">Selected:</span> {selectedFile.name}
                            </p>
                        </div>
                    )}
                </div>
            </Dialog>

            {/* ADD USER DIALOG */}
            <Dialog
                visible={showUserDropdown}
                onHide={handleCloseUserDrop}
                header="Add Team Member to Dataset"
                footer={addUserFooter}
                style={{ width: '28rem' }}
            >
                <div className="space-y-4">
                    <span className="p-input-icon-left p-input-icon-right relative block">
                        <i className="pi pi-search absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" />
                        <InputText
                            placeholder="Search or select team member..."
                            value={userSearchQuery}
                            onChange={handleUserSearchChange}
                            className="pl-9 pr-10 w-full border-slate-300"
                        />
                        {userSearchQuery.trim() && (
                            <button
                                onClick={handleClearUserSearch}
                                className="absolute right-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600 transition"
                            >
                                <i className="pi pi-times text-sm" />
                            </button>
                        )}
                    </span>

                    <div className="border border-slate-200 rounded-lg max-h-64 overflow-y-auto bg-slate-50">
                        {availableUsers.length === 0 ? (
                            <div className="p-4 text-center text-slate-500 text-sm">
                                All team members already have access to this dataset
                            </div>
                        ) : filteredUsers.length === 0 && userSearchQuery.trim() ? (
                            <div className="p-4 text-center text-slate-500 text-sm">
                                No matching team members found
                            </div>
                        ) : (
                            <ul className="divide-y divide-slate-200">
                                {filteredUsers.length > 0 ? (
                                    filteredUsers.map((user) => {
                                        const email = typeof user === 'string' ? user : user.email;
                                        const nickname =
                                            typeof user === 'string' ? '' : user.nickname;
                                        return (
                                            <li key={email}>
                                                <button
                                                    type="button"
                                                    className="p-3 cursor-pointer transition hover:bg-green-100 text-left w-full border-none bg-transparent"
                                                    onClick={() => setUserSearchQuery(email)}
                                                >
                                                    <div className="text-sm font-medium text-slate-900">
                                                        {email}
                                                    </div>
                                                    {nickname && (
                                                        <div className="text-xs text-slate-500">
                                                            {nickname}
                                                        </div>
                                                    )}
                                                </button>
                                            </li>
                                        );
                                    })
                                ) : (
                                    <div className="p-4 text-center text-slate-500 text-sm">
                                        Start typing to search for team members...
                                    </div>
                                )}
                            </ul>
                        )}
                    </div>

                    {userSearchQuery.trim() &&
                        availableUsers.some((u) => {
                            const userEmail = typeof u === 'string' ? u : u.email;
                            return userEmail === userSearchQuery.trim();
                        }) && (
                            <div
                                className="rounded-lg p-3"
                                style={{ background: '#f0fdf4', border: '1px solid #86efac' }}
                            >
                                <p className="text-sm text-green-800">
                                    <span className="font-semibold">Selected:</span>{' '}
                                    {userSearchQuery.trim()}
                                </p>
                            </div>
                        )}
                </div>
            </Dialog>
        </PageLayout>
    );
}
