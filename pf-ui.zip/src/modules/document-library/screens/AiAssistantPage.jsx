import { useCallback } from 'react';
import { useAtom } from 'jotai';
import { TabView, TabPanel } from 'primereact/tabview';
import { PageLayout } from '@shared/components';
import ConversationSidebar from '../components/ConversationSidebar';
import ChatPanel from '../components/ChatPanel';
import SelfDocumentPanel from '../components/SelfDocumentPanel';
import { activeTabIndexAtom } from '../store/atoms';
import useDialogs from '../hooks/useDialogs';
import { useConversations } from '../hooks/useConversations';
import '../styles/ai-assistant.scss';

const AiAssistantPage = () => {
    const [activeTabIndex, setActiveTabIndex] = useAtom(activeTabIndexAtom);

    useDialogs();
    useConversations();

    const handleTabChange = useCallback((e) => setActiveTabIndex(e.index), [setActiveTabIndex]);

    return (
        <PageLayout>
            <PageLayout.Header
                title="AI Assistant"
                subtitle="Chat with the internal knowledge base or manage documents"
            />
            <PageLayout.Content>
                <div className="ai-assistant-root">
                    {activeTabIndex === 0 && <ConversationSidebar />}
                    <div className="ai-assistant-main">
                        <TabView
                            className="ai-assistant-tabview"
                            activeIndex={activeTabIndex}
                            onTabChange={handleTabChange}
                        >
                            <TabPanel header="Chat" leftIcon="pi pi-comments mr-2">
                                <ChatPanel />
                            </TabPanel>
                            <TabPanel header="Self-Document" leftIcon="pi pi-folder mr-2">
                                <SelfDocumentPanel />
                            </TabPanel>
                        </TabView>
                    </div>
                </div>
            </PageLayout.Content>
        </PageLayout>
    );
};

export default AiAssistantPage;
