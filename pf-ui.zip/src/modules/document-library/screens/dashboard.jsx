import { useEffect, useMemo, useState, useRef, useCallback } from 'react';
import { useNavigate } from 'react-router-dom';
import { toast } from '../utils/toast';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { Card, PageLayout } from '@shared/components';
import TeamManagement from './TeamManagement';
import DatasetTable from '../components/DatasetTable';
import { STORAGE_KEYS } from '@shared/utils';
import { getRagAuthHeaders } from '../utils/ragAuth';
import { getRagTenantId } from '../utils/tenant';
import { useMutationApi } from '@shared/hooks';
export default function DashboardPage() {
    const [user, setUser] = useState(null);
    const [activeTab, setActiveTab] = useState('datasets');
    const [logoutOpen, setLogoutOpen] = useState(false);
    const [datasets, setDatasets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [appliedSearchQuery, setAppliedSearchQuery] = useState('');
    const [searchTrigger, setSearchTrigger] = useState(0);
    const [isSearching, setIsSearching] = useState(false);
    const [error, setError] = useState('');
    const [renameDialogOpen, setRenameDialogOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [selectedDataset, setSelectedDataset] = useState(null);
    const [newName, setNewName] = useState('');
    const [createDialogOpen, setCreateDialogOpen] = useState(false);
    const [newDatasetName, setNewDatasetName] = useState('');
    const [pagination, setPagination] = useState({ current: 1, pageSize: 10, total: 0 });
    const currentPage = pagination.current;
    const pageSize = pagination.pageSize;

    const navigate = useNavigate();
    const searchTimeoutRef = useRef(null);
    const headers = {
        Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) || localStorage.getItem('Token') || localStorage.getItem('Authorization') || ''}`,
        'X-Tenant-Id': getRagTenantId(),
    };
    useEffect(() => {
        const savedUser = localStorage.getItem('userInfo');
        if (savedUser) setUser(JSON.parse(savedUser));
        console.log('=== DASHBOARD LOADED ===');
        console.log('Tenant ID:', getRagTenantId());
    }, []);

    useEffect(() => {
        if (getRagTenantId() && activeTab === 'datasets') {
            console.log('Tenant ID ready, triggering initial fetch...');
            setSearchTrigger((prev) => prev + 1);
        }
    }, [activeTab]);

    useEffect(() => {
        return () => {
            if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        };
    }, []);

    // const fetchDatasets = useCallback(
    //     async (searchTerm = '') => {
    //         setLoading(true);
    //         setError('');
    //         try {
    //             const tenantId = getRagTenantId();
    //             console.log('=== FETCHING DATASETS ===');
    //             console.log('Search Term:', searchTerm);
    //             console.log('Page:', currentPage);

    //             const response = await fetch(API_CONFIG.FETCHDATA, {
    //                 method: 'POST',
    //                 headers: getRagAuthHeaders(),
    //                 body: JSON.stringify({
    //                     tenant_id: tenantId,
    //                     page: currentPage,
    //                     page_size: pageSize,
    //                     keywords: searchTerm,
    //                 }),
    //             });

    //             const data = await response.json();
    //             console.log('Dataset response:', data);

    //             if (data.code === 0 && data.data?.kbs) {
    //                 const kbs = data.data.kbs;
    //                 setDatasets(kbs);
    //                 setPagination((prev) => ({ ...prev, total: data.data.total || 0 }));
    //                 console.log('Datasets loaded:', kbs.length);
    //             } else {
    //                 setError(data.message || 'Failed to fetch datasets');
    //                 toast.error(`${data.message || 'Failed to fetch datasets'}`);
    //             }
    //         } catch (err) {
    //             console.error('Error fetching datasets:', err);
    //             setError('Error fetching datasets. Please check your connection.');
    //             toast.error('Failed to load datasets');
    //         } finally {
    //             setLoading(false);
    //             setIsSearching(false);
    //         }
    //     },
    //     [currentPage, pageSize],
    // );
    // First, declare the mutation at the top of your component (with other mutations)
    const fetchDatasetsMutation = useMutationApi({
        service: 'dl', // or 'dl'
        endpoint: '/api/fetchdata', // ← Confirm this endpoint with your backend
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: fetchDatasetsApi } = fetchDatasetsMutation;
    const fetchDatasets = useCallback(
        async (searchTerm = '') => {
            setLoading(true);
            setError('');

            try {
                const tenantId = getRagTenantId();

                const data = await fetchDatasetsApi({
                    body: {
                        tenant_id: tenantId,
                        page: currentPage,
                        page_size: pageSize,
                        keywords: searchTerm,
                    },
                });

                if (data.code === 0 && data.data?.kbs) {
                    const kbs = data.data.kbs;

                    setDatasets(kbs);

                    setPagination((prev) => ({
                        ...prev,
                        total: data.data.total || 0,
                    }));
                } else {
                    setError(data.message || 'Failed to fetch datasets');
                    toast.error(data.message || 'Failed to fetch datasets');
                }
            } catch (err) {
                console.error(err);
                setError('Error fetching datasets');
                toast.error('Failed to load datasets');
            } finally {
                setLoading(false);
                setIsSearching(false);
            }
        },
        [currentPage, pageSize, fetchDatasetsApi],
    );
    useEffect(() => {
        if (getRagTenantId() && activeTab === 'datasets') {
            fetchDatasets(appliedSearchQuery);
        }
    }, [activeTab, appliedSearchQuery, fetchDatasets, searchTrigger]);

    const debouncedSearch = useCallback((query) => {
        setSearchQuery(query);
        if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        setIsSearching(true);
        searchTimeoutRef.current = setTimeout(() => {
            setPagination((prev) => ({ ...prev, current: 1 }));
            setAppliedSearchQuery(query);
            setSearchTrigger((prev) => prev + 1);
        }, 300);
    }, []);

    const handleSearch = useCallback(() => {
        if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        setIsSearching(true);
        setPagination((prev) => ({ ...prev, current: 1 }));
        setAppliedSearchQuery(searchQuery);
        setSearchTrigger((prev) => prev + 1);
    }, [searchQuery]);

    const handleLogout = useCallback(() => {
        localStorage.clear();
        toast.success('Logged out successfully');
        setTimeout(() => {
            window.location.href = '/';
        }, 1000);
    }, []);

    const handleKeyPress = useCallback((e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
            setPagination((prev) => ({ ...prev, current: 1 }));
        }
    }, []);

    const handleClearSearch = useCallback(() => {
        setSearchQuery('');
        if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        setPagination((prev) => ({ ...prev, current: 1 }));
        setAppliedSearchQuery('');
        setSearchTrigger((prev) => prev + 1);
    }, []);

    const handlePageChange = useCallback((page) => {
        setPagination((prev) => ({ ...prev, current: page }));
    }, []);

    const handleRename = useCallback((dataset) => {
        setSelectedDataset(dataset);
        setNewName(dataset.name);
        setRenameDialogOpen(true);
    }, []);

    const handleDelete = useCallback((dataset) => {
        setSelectedDataset(dataset);
        setDeleteDialogOpen(true);
    }, []);

    const handleTabDatasets = useCallback(() => setActiveTab('datasets'), []);
    const handleTabUsers = useCallback(() => setActiveTab('users'), []);
    const handleCloseLogout = useCallback(() => setLogoutOpen(false), []);
    const handleCloseRename = useCallback(() => setRenameDialogOpen(false), []);
    const handleCloseDelete = useCallback(() => setDeleteDialogOpen(false), []);
    const handleOpenCreate = useCallback(() => setCreateDialogOpen(true), []);
    const handleCloseCreate = useCallback(() => setCreateDialogOpen(false), []);

    const handleSearchChange = useCallback(
        (e) => debouncedSearch(e.target.value),
        [debouncedSearch],
    );
    const handleNewNameChange = useCallback((e) => setNewName(e.target.value), []);
    const handleNewDatasetNameChange = useCallback((e) => setNewDatasetName(e.target.value), []);

    // const confirmRename = useCallback(async () => {
    //     if (!newName.trim()) {
    //         toast.warning('Please enter a dataset name');
    //         return;
    //     }
    //     if (newName === selectedDataset.name) {
    //         toast.info('Name is the same as current');
    //         return;
    //     }
    //     try {
    //         const toastId = toast.loading('Renaming dataset...');
    //         const response = await fetch(API_CONFIG.RENAMEKB, {
    //             method: 'POST',
    //             headers: getRagAuthHeaders(),
    //             body: JSON.stringify({
    //                 kb_id: selectedDataset.id,
    //                 tenant_id: getRagTenantId(),
    //                 new_name: newName,
    //             }),
    //         });
    //         const data = await response.json();
    //         if (response.ok && data.code === 0) {
    //             setRenameDialogOpen(false);
    //             setNewName('');
    //             setSelectedDataset(null);
    //             toast.dismiss(toastId);
    //             toast.success(`Dataset renamed to "${newName}"`);
    //             setSearchTrigger((prev) => prev + 1);
    //         } else {
    //             toast.dismiss(toastId);
    //             toast.error(`${data.message || 'Only owner can rename'}`);
    //         }
    //     } catch (err) {
    //         toast.error(`Failed to rename: ${err.message}`);
    //     }
    // }, [newName, selectedDataset]);
    const renameDatasetMutation = useMutationApi({
        service: 'dl', // or 'pl' if mapped there
        endpoint: '/api/renamekb',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: renameDatasetApi } = renameDatasetMutation;
    const confirmRename = useCallback(async () => {
        if (!newName.trim()) {
            toast.warning('Please enter a dataset name');
            return;
        }

        if (newName === selectedDataset?.name) {
            toast.info('Name is the same as current');
            return;
        }

        try {
            const toastId = toast.loading('Renaming dataset...');

            const data = await renameDatasetApi({
                body: {
                    kb_id: selectedDataset.id,
                    tenant_id: getRagTenantId(),
                    new_name: newName,
                },
            });

            console.log('Rename response:', data);

            if (data.code === 0) {
                setRenameDialogOpen(false);
                setNewName('');
                setSelectedDataset(null);

                toast.dismiss(toastId);
                toast.success(`Dataset renamed to "${newName}"`);

                setSearchTrigger((prev) => prev + 1);
            } else {
                toast.dismiss(toastId);
                toast.error(data.message || 'Only owner can rename');
            }
        } catch (err) {
            console.error('Rename failed:', err);
            toast.error(`Failed to rename: ${err.message}`);
        }
    }, [newName, selectedDataset, renameDatasetApi]);
    // const confirmDelete = useCallback(async () => {
    //     try {
    //         const toastId = toast.loading('Deleting dataset...');
    //         const response = await fetch(API_CONFIG.DELETEDATASET, {
    //             method: 'POST',
    //             headers: getRagAuthHeaders(),
    //             body: JSON.stringify({
    //                 kb_id: selectedDataset.id,
    //                 tenant_id: getRagTenantId(),
    //             }),
    //         });
    //         const data = await response.json();
    //         if (data.code === 1) {
    //             toast.dismiss(toastId);
    //             toast.error(`${data.message || 'Dataset name already exists'}`);
    //             return;
    //         }
    //         if (response.ok && data.code === 0) {
    //             setDeleteDialogOpen(false);
    //             setSelectedDataset(null);
    //             toast.dismiss(toastId);
    //             toast.success('Dataset deleted successfully');
    //             setPagination((prev) => ({ ...prev, current: 1 }));
    //             setSearchTrigger((prev) => prev + 1);
    //         } else {
    //             toast.dismiss(toastId);
    //             toast.error(`${data.message || 'Failed to delete dataset'}`);
    //         }
    //     } catch (err) {
    //         toast.error(`Failed to delete: ${err.message}`);
    //     }
    // }, [selectedDataset]);
    const deleteDatasetMutation = useMutationApi({
        service: 'dl', // or 'pl'
        endpoint: '/api/deletedataset',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: deleteDatasetApi } = deleteDatasetMutation;
    const confirmDelete = useCallback(async () => {
        if (!selectedDataset?.id) {
            toast.error('No dataset selected');
            return;
        }

        try {
            const toastId = toast.loading('Deleting dataset...');

            const data = await deleteDatasetApi({
                body: {
                    kb_id: selectedDataset.id,
                    tenant_id: getRagTenantId(),
                },
            });

            console.log('Delete response:', data);

            if (data.code === 1) {
                toast.dismiss(toastId);
                toast.error(data.message || 'Failed to delete dataset');
                return;
            }

            if (data.code === 0) {
                setDeleteDialogOpen(false);
                setSelectedDataset(null);

                toast.dismiss(toastId);
                toast.success('Dataset deleted successfully');

                setPagination((prev) => ({
                    ...prev,
                    current: 1,
                }));

                setSearchTrigger((prev) => prev + 1);
            } else {
                toast.dismiss(toastId);
                toast.error(data.message || 'Failed to delete dataset');
            }
        } catch (err) {
            console.error('Delete failed:', err);
            toast.error(`Failed to delete: ${err.message}`);
        }
    }, [selectedDataset, deleteDatasetApi]);
    // const confirmCreateDataset = useCallback(async () => {
    //     if (!newDatasetName.trim()) {
    //         toast.warning('Please enter a dataset name');
    //         return;
    //     }
    //     try {
    //         const toastId = toast.loading('Creating dataset...');
    //         const response = await fetch(API_CONFIG.CREATEDATASET, {
    //             method: 'POST',
    //             headers: getRagAuthHeaders(),
    //             body: JSON.stringify({ name: newDatasetName, tenant_id: getRagTenantId() }),
    //         });
    //         const data = await response.json();
    //         if (response.ok && data.code === 0) {
    //             setCreateDialogOpen(false);
    //             setNewDatasetName('');
    //             toast.dismiss(toastId);
    //             toast.success(`Dataset "${newDatasetName}" created successfully!`);
    //             setPagination((prev) => ({ ...prev, current: 1 }));
    //             setSearchQuery('');
    //             setAppliedSearchQuery('');
    //             setSearchTrigger((prev) => prev + 1);
    //         } else {
    //             toast.dismiss(toastId);
    //             toast.error(`${data.message || 'Failed to create dataset'}`);
    //         }
    //     } catch (err) {
    //         toast.error(`Failed to create dataset: ${err.message}`);
    //     }
    // }, [newDatasetName]);
    const createDatasetMutation = useMutationApi({
        service: 'dl', // or 'pl'
        endpoint: '/api/createdataset',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: createDatasetApi } = createDatasetMutation;
    const confirmCreateDataset = useCallback(async () => {
        if (!newDatasetName.trim()) {
            toast.warning('Please enter a dataset name');
            return;
        }

        try {
            const toastId = toast.loading('Creating dataset...');

            const data = await createDatasetApi({
                body: {
                    name: newDatasetName,
                    tenant_id: getRagTenantId(),
                },
            });

            console.log('Create dataset response:', data);

            if (data.code === 0) {
                setCreateDialogOpen(false);
                setNewDatasetName('');

                toast.dismiss(toastId);

                toast.success(`Dataset "${newDatasetName}" created successfully!`);

                setPagination((prev) => ({
                    ...prev,
                    current: 1,
                }));

                setSearchQuery('');
                setAppliedSearchQuery('');

                setSearchTrigger((prev) => prev + 1);
            } else {
                toast.dismiss(toastId);

                toast.error(data.message || 'Failed to create dataset');
            }
        } catch (err) {
            console.error('Create dataset failed:', err);

            toast.error(`Failed to create dataset: ${err.message}`);
        }
    }, [newDatasetName, createDatasetApi]);
    void user;
    void navigate;

    const activeTabButtonStyle = useMemo(
        () => ({
            background: 'var(--primary-color)',
            color: 'var(--surface-0)',
            borderRadius: '7px',
        }),
        [],
    );
    const inactiveTabButtonStyle = useMemo(
        () => ({ color: 'var(--primary-color)', borderRadius: '7px' }),
        [],
    );
    const primaryButtonStyle = useMemo(
        () => ({ backgroundColor: 'var(--primary-color)', border: 'none' }),
        [],
    );
    const successButtonStyle = useMemo(
        () => ({ backgroundColor: 'var(--green-600)', border: 'none' }),
        [],
    );
    const mutedPrimaryIconStyle = useMemo(
        () => ({ color: 'var(--primary-color)', opacity: 0.6, marginLeft: '0.5rem' }),
        [],
    );
    const headingPrimaryStyle = useMemo(() => ({ color: 'var(--primary-color)' }), []);
    const dialogWidth28Style = useMemo(() => ({ width: '28rem' }), []);
    const dialogWidth26Style = useMemo(() => ({ width: '26rem' }), []);

    const logoutFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseLogout} />
            <Button label="Yes, Logout" severity="danger" onClick={handleLogout} />
        </div>
    );

    const renameFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseRename} />
            <Button label="Rename" style={primaryButtonStyle} onClick={confirmRename} />
        </div>
    );

    const deleteFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseDelete} />
            <Button label="Yes, Delete" severity="danger" onClick={confirmDelete} />
        </div>
    );

    const createFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseCreate} />
            <Button label="Create" style={successButtonStyle} onClick={confirmCreateDataset} />
        </div>
    );

    return (
        <>
            <PageLayout className="w-full">
                <PageLayout.Header
                    title="Admin Repository"
                    subtitle="Manage datasets and users"
                    actions={
                        <div className="w-full flex justify-content-center items-center">
                            <div className="mx-auto flex bg-white shadow-md rounded-xl px-1 py-1 gap-3">
                                <button
                                    onClick={handleTabDatasets}
                                    className="w-10rem h-3rem rounded-full font-medium transition flex align-items-center justify-content-center gap-2"
                                    style={
                                        activeTab === 'datasets'
                                            ? activeTabButtonStyle
                                            : inactiveTabButtonStyle
                                    }
                                >
                                    <i className="pi pi-file" />
                                    Datasets
                                </button>
                                <button
                                    onClick={handleTabUsers}
                                    className="w-10rem h-3rem rounded-full font-medium transition flex align-items-center justify-content-center gap-2"
                                    style={
                                        activeTab === 'users'
                                            ? activeTabButtonStyle
                                            : inactiveTabButtonStyle
                                    }
                                >
                                    <i className="pi pi-users" />
                                    Users
                                </button>
                            </div>
                        </div>
                    }
                />
                <PageLayout.Content>
                    <Card>
                        {/* DATASETS TAB */}
                        {activeTab === 'datasets' && (
                            <div>
                                <div className="relative flex items-center justify-between mb-2">
                                    {/* Left Side */}
                                    <h2 className="text-3xl font-bold" style={headingPrimaryStyle}>
                                        Datasets
                                    </h2>

                                    {/* Center Tabs */}
                                    <div className="absolute left-1/2 transform -translate-x-1/2">
                                        <div className="flex align-items-center gap-2">
                                            {/* Your Tabs Here */}
                                        </div>
                                    </div>

                                    {/* Right Side */}
                                    <div className="flex align-items-center gap-2 ml-auto">
                                        <span className="p-input-icon-left p-input-icon-right">
                                            <i
                                                className="pi pi-search"
                                                style={mutedPrimaryIconStyle}
                                            />

                                            <InputText
                                                type="text"
                                                placeholder="Search datasets..."
                                                value={searchQuery}
                                                onChange={handleSearchChange}
                                                onKeyPress={handleKeyPress}
                                                className="h-3rem w-22rem pl-10 pr-3"
                                            />

                                            {searchQuery && (
                                                <button
                                                    onClick={handleClearSearch}
                                                    className="p-link"
                                                    style={mutedPrimaryIconStyle}
                                                    title="Clear search"
                                                >
                                                    <i className="pi pi-times text-sm" />
                                                </button>
                                            )}
                                        </span>

                                        <Button
                                            label={isSearching ? 'Searching...' : 'Search'}
                                            icon={
                                                isSearching
                                                    ? 'pi pi-spin pi-spinner'
                                                    : 'pi pi-search'
                                            }
                                            onClick={handleSearch}
                                            disabled={isSearching}
                                            style={primaryButtonStyle}
                                            className="h-3rem"
                                        />

                                        <Button
                                            label="Create Dataset"
                                            icon="pi pi-file"
                                            onClick={handleOpenCreate}
                                            style={successButtonStyle}
                                            className="h-3rem"
                                        />
                                    </div>
                                </div>

                                {error && (
                                    <div className="mb-4 p-4 bg-red-50 border-l-4 border-red-500 rounded text-red-700">
                                        {error}
                                    </div>
                                )}

                                <DatasetTable
                                    datasets={datasets}
                                    loading={loading}
                                    onRename={handleRename}
                                    onDelete={handleDelete}
                                    pagination={pagination}
                                    onPageChange={handlePageChange}
                                />
                            </div>
                        )}

                        {/* USERS TAB */}
                        {activeTab === 'users' && <TeamManagement />}
                    </Card>
                </PageLayout.Content>

                {/* LOGOUT DIALOG */}
                <Dialog
                    visible={logoutOpen}
                    onHide={handleCloseLogout}
                    header="Confirm Logout"
                    footer={logoutFooter}
                    style={dialogWidth28Style}
                >
                    <p className="text-gray-700">Are you sure you want to logout?</p>
                </Dialog>

                {/* RENAME DIALOG */}
                <Dialog
                    visible={renameDialogOpen}
                    onHide={handleCloseRename}
                    header="Rename Dataset"
                    footer={renameFooter}
                    style={dialogWidth26Style}
                >
                    <div className="space-y-3">
                        <label
                            htmlFor="rename-dataset-name"
                            className="text-sm font-semibold block"
                            style={headingPrimaryStyle}
                        >
                            New Name
                        </label>
                        <InputText
                            id="rename-dataset-name"
                            value={newName}
                            onChange={handleNewNameChange}
                            placeholder="Enter new dataset name"
                            className="w-full"
                        />
                    </div>
                </Dialog>

                {/* DELETE DIALOG */}
                <Dialog
                    visible={deleteDialogOpen}
                    onHide={handleCloseDelete}
                    header="Delete Dataset"
                    footer={deleteFooter}
                    style={dialogWidth28Style}
                >
                    <p className="text-gray-700">
                        Are you sure you want to delete{' '}
                        <span className="font-semibold">{selectedDataset?.name}</span>? This action
                        cannot be undone.
                    </p>
                </Dialog>

                {/* CREATE DATASET DIALOG */}
                <Dialog
                    visible={createDialogOpen}
                    onHide={handleCloseCreate}
                    header="Create New Dataset"
                    footer={createFooter}
                    style={dialogWidth26Style}
                >
                    <div className="space-y-3">
                        <label
                            htmlFor="create-dataset-name"
                            className="text-sm font-semibold block"
                            style={headingPrimaryStyle}
                        >
                            Dataset Name
                        </label>
                        <InputText
                            id="create-dataset-name"
                            value={newDatasetName}
                            onChange={handleNewDatasetNameChange}
                            placeholder="Enter dataset name"
                            className="w-full"
                        />
                    </div>
                </Dialog>
            </PageLayout>
        </>
    );
}
