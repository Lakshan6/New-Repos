import { useCallback, useEffect, useMemo, useState } from 'react';
import { toast } from '../utils/toast';
import { STORAGE_KEYS } from '@shared/utils';
// PrimeReact
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { Password } from 'primereact/password';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Paginator } from 'primereact/paginator';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Tag } from 'primereact/tag';
import { Card, PageLayout } from '@shared/components';
import { getRagAuthHeaders } from '../utils/ragAuth';
import { getRagTenantId } from '../utils/tenant';
// import API_CONFIG from '../utils/apiConfig';
import { useMutationApi } from '@shared/hooks';
// const TEAM_API = API_CONFIG.TEAM;
// const FETCHDATA_API = API_CONFIG.FETCHDATA;
// const REGISTER_API = API_CONFIG.REGISTER;
// const DELETE_USER_API = API_CONFIG.DELETE_USER;

const ADD_USER_BUTTON_STYLE = {
    background: 'linear-gradient(to right,#a855f7,#9333ea)',
    border: 'none',
};

const CREATE_USER_BUTTON_STYLE = {
    background: 'linear-gradient(to right,#a855f7,#9333ea)',
    border: 'none',
};
const headers = {
    Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN)}`,
};
const TABLE_STYLE = {
    minWidth: '50rem',
};

const TABLE_PT = {
    header: {
        className: 'bg-gradient-to-r from-blue-50 to-blue-100 border-b-2 border-blue-200',
    },
};

const PAGINATOR_PT = {
    root: { className: 'p-0 bg-transparent border-none' },
    prevPageButton: {
        className:
            'px-3 py-1 text-sm border border-blue-300 rounded-md hover:bg-blue-100 disabled:opacity-50 disabled:cursor-not-allowed transition',
    },
    nextPageButton: {
        className:
            'px-3 py-1 text-sm border border-blue-300 rounded-md hover:bg-blue-100 disabled:opacity-50 disabled:cursor-not-allowed transition',
    },
};

const ADD_USER_DIALOG_STYLE = {
    width: '32rem',
    maxHeight: '90vh',
};

const ADD_USER_DIALOG_CONTENT_STYLE = {
    overflowY: 'auto',
};

const DELETE_DIALOG_STYLE = {
    width: '28rem',
};

const LOADER_STYLE = {
    width: '48px',
    height: '48px',
};

const KB_LOADER_STYLE = {
    width: '32px',
    height: '32px',
};

const OWNER_TAG_STYLE = {
    background: 'linear-gradient(to right,#fef9c3,#fef3c7)',
    color: '#a16207',
    fontSize: '12px',
};

const NORMAL_TAG_STYLE = {
    background: 'linear-gradient(to right,#dcfce7,#d1fae5)',
    color: '#15803d',
    fontSize: '12px',
};

const TOOLTIP_OPTIONS = {
    position: 'top',
};

const EMPTY_ICON_STYLE = {
    fontSize: '2rem',
};

export default function TeamManagement() {
    const [users, setUsers] = useState([]);
    const [allUsers, setAllUsers] = useState([]);
    const [loading, setLoading] = useState(false);
    const [addUserDialogOpen, setAddUserDialogOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [selectedUser, setSelectedUser] = useState(null);
    const [deleting, setDeleting] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [knowledgeBases, setKnowledgeBases] = useState([]);
    const [loadingKBs, setLoadingKBs] = useState(false);
    const [selectedKBs, setSelectedKBs] = useState([]);

    const [pagination, setPagination] = useState({
        current: 1,
        pageSize: 10,
        total: 0,
    });

    const [sortConfig, setSortConfig] = useState({
        key: null,
        direction: null,
    });

    const [formData, setFormData] = useState({
        nickname: '',
        email: '',
        password: '',
    });

    const formatDate1 = useCallback((dateStr) => {
        if (!dateStr) {
            return '-';
        }

        const [datePart, timePart] = dateStr.split(/[T ]/);

        if (!datePart) {
            return '-';
        }

        const [yyyy, mm, dd] = datePart.split('-');

        return `${dd}-${mm}-${yyyy}${timePart ? ` ${timePart}` : ''}`.trim();
    }, []);

    const sortByLastLogin = useCallback((userList) => {
        return [...userList].sort((a, b) => {
            const timeA = a.update_date ? new Date(a.update_date) : new Date(0);
            const timeB = b.update_date ? new Date(b.update_date) : new Date(0);

            return timeB - timeA;
        });
    }, []);

    // const fetchTeamMembers = useCallback(
    //     async (tenantId) => {
    //         if (!TEAM_API) {
    //             toast.error('Team API URL is not configured');
    //             return;
    //         }

    //         setLoading(true);

    //         try {
    //             const response = await fetch(TEAM_API, {
    //                 method: 'POST',
    //                 headers: getRagAuthHeaders(),
    //                 body: JSON.stringify({
    //                     tenant_id: tenantId,
    //                 }),
    //             });

    //             const data = await response.json();

    //             if (data.code === 0 && data.data) {
    //                 const sorted = sortByLastLogin(data.data);

    //                 setAllUsers(sorted);
    //                 setUsers(sorted);

    //                 setPagination((prev) => ({
    //                     ...prev,
    //                     total: sorted.length,
    //                     current: 1,
    //                 }));
    //             } else {
    //                 toast.error(data.message || 'Failed to fetch team members');
    //             }
    //         } catch (err) {
    //             console.error('Error fetching team members:', err);
    //             toast.error('Failed to load team members');
    //         } finally {
    //             setLoading(false);
    //         }
    //     },
    //     [sortByLastLogin],
    // );

    // useEffect(() => {
    //     const tenantId = getRagTenantId();

    //     if (tenantId) {
    //         fetchTeamMembers(tenantId);
    //     }
    // }, [fetchTeamMembers]);
    const fetchTeamMembersMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/team',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: fetchTeamMembersApi } = fetchTeamMembersMutation;

    const fetchTeamMembers = useCallback(async () => {
        setLoading(true);

        try {
            const data = await fetchTeamMembersApi({
                body: {
                    tenant_id: getRagTenantId(),
                },
                headers: getRagAuthHeaders(),
            });

            if (data.code === 0 && data.data) {
                const sorted = sortByLastLogin(data.data);

                setAllUsers(sorted);
                setUsers(sorted);

                setPagination((prev) => ({
                    ...prev,
                    total: sorted.length,
                    current: 1,
                }));
            } else {
                toast.error(data.message || 'Failed to fetch team members');
            }
        } catch (err) {
            console.error('Error fetching team members:', err);

            toast.error(`Failed to load team members: ${err.message}`);
        } finally {
            setLoading(false);
        }
    }, [fetchTeamMembersApi, sortByLastLogin]);

    useEffect(() => {
        const tenantId = getRagTenantId();

        if (tenantId) {
            fetchTeamMembers(tenantId);
        }
    }, [fetchTeamMembers]);

    // const fetchKnowledgeBases = useCallback(async (tenantId) => {
    //     if (!FETCHDATA_API) {
    //         toast.error('Fetch data API URL is not configured');
    //         return;
    //     }

    //     setLoadingKBs(true);

    //     try {
    //         const response = await fetch(FETCHDATA_API, {
    //             method: 'POST',
    //             headers: getRagAuthHeaders(),
    //             body: JSON.stringify({
    //                 tenant_id: tenantId,
    //                 page: 1,
    //                 page_size: 50,
    //                 keywords: '',
    //             }),
    //         });

    //         const data = await response.json();

    //         if (data.code === 0 && data.data?.kbs) {
    //             setKnowledgeBases(data.data.kbs.filter((kb) => kb.name !== 'self-document'));
    //         } else {
    //             toast.error(data.message || 'Failed to fetch knowledge bases');
    //         }
    //     } catch (err) {
    //         console.error('Error fetching knowledge bases:', err);
    //         toast.error('Failed to load knowledge bases');
    //     } finally {
    //         setLoadingKBs(false);
    //     }
    // }, []);
    const fetchKnowledgeBasesMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/fetchdata',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: fetchKnowledgeBasesApi } = fetchKnowledgeBasesMutation;

    const fetchKnowledgeBases = useCallback(async () => {
        setLoadingKBs(true);

        try {
            const data = await fetchKnowledgeBasesApi({
                body: {
                    tenant_id: getRagTenantId(),
                    page: 1,
                    page_size: 50,
                    keywords: '',
                },
                headers: getRagAuthHeaders(),
            });

            if (data.code === 0 && data.data?.kbs) {
                setKnowledgeBases(data.data.kbs.filter((kb) => kb.name !== 'self-document'));
            } else {
                toast.error(data.message || 'Failed to fetch knowledge bases');
            }
        } catch (err) {
            console.error('Error fetching knowledge bases:', err);

            toast.error(`Failed to load knowledge bases: ${err.message}`);
        } finally {
            setLoadingKBs(false);
        }
    }, [fetchKnowledgeBasesApi]);

    const handleSort = useCallback((key) => {
        setSortConfig((prev) => {
            if (prev.key !== key) {
                return {
                    key,
                    direction: 'asc',
                };
            }

            if (prev.direction === 'asc') {
                return {
                    key,
                    direction: 'desc',
                };
            }

            if (prev.direction === 'desc') {
                return {
                    key: null,
                    direction: null,
                };
            }

            return {
                key,
                direction: 'asc',
            };
        });

        setPagination((prev) => ({
            ...prev,
            current: 1,
        }));
    }, []);

    const handleNicknameSort = useCallback(() => {
        handleSort('nickname');
    }, [handleSort]);

    const handleEmailSort = useCallback(() => {
        handleSort('email');
    }, [handleSort]);

    const handleCreateDateSort = useCallback(() => {
        handleSort('create_date');
    }, [handleSort]);

    const handleUpdateDateSort = useCallback(() => {
        handleSort('update_date');
    }, [handleSort]);

    const getSortedUsers = useCallback(
        (userList) => {
            if (!sortConfig.key || !sortConfig.direction) {
                return userList;
            }

            return [...userList].sort((a, b) => {
                let valA = a[sortConfig.key] ?? '';
                let valB = b[sortConfig.key] ?? '';

                if (sortConfig.key === 'create_date' || sortConfig.key === 'update_date') {
                    valA = valA ? new Date(valA) : new Date(0);
                    valB = valB ? new Date(valB) : new Date(0);

                    return sortConfig.direction === 'asc' ? valA - valB : valB - valA;
                }

                valA = valA.toString().toLowerCase();
                valB = valB.toString().toLowerCase();

                if (valA < valB) {
                    return sortConfig.direction === 'asc' ? -1 : 1;
                }

                if (valA > valB) {
                    return sortConfig.direction === 'asc' ? 1 : -1;
                }

                return 0;
            });
        },
        [sortConfig],
    );

    const handleAddUserDialogOpen = useCallback(() => {
        setAddUserDialogOpen(true);
        setSelectedKBs([]);

        const tenantId = getRagTenantId();

        if (tenantId) {
            fetchKnowledgeBases(tenantId);
        }
    }, [fetchKnowledgeBases]);

    const toggleKBSelection = useCallback((kb) => {
        setSelectedKBs((prev) =>
            prev.some((item) => item.id === kb.id)
                ? prev.filter((item) => item.id !== kb.id)
                : [...prev, kb],
        );
    }, []);

    const createKBSelectionHandler = useCallback(
        (kb) => {
            return () => {
                toggleKBSelection(kb);
            };
        },
        [toggleKBSelection],
    );

    const handleKBKeyDown = useCallback(
        (event, kb) => {
            if (event.key === 'Enter' || event.key === ' ') {
                event.preventDefault();
                toggleKBSelection(kb);
            }
        },
        [toggleKBSelection],
    );

    const createKBKeyDownHandler = useCallback(
        (kb) => {
            return (event) => {
                handleKBKeyDown(event, kb);
            };
        },
        [handleKBKeyDown],
    );

    const handleNicknameChange = useCallback((e) => {
        const { value } = e.target;

        setFormData((prev) => ({
            ...prev,
            nickname: value,
        }));
    }, []);

    const handleEmailChange = useCallback((e) => {
        const { value } = e.target;

        setFormData((prev) => ({
            ...prev,
            email: value,
        }));
    }, []);

    const handlePasswordChange = useCallback((e) => {
        const { value } = e.target;

        setFormData((prev) => ({
            ...prev,
            password: value,
        }));
    }, []);

    // const handleAddUser = useCallback(async () => {
    //     if (!formData.nickname.trim() || !formData.email.trim() || !formData.password.trim()) {
    //         toast.warning('Please fill in all fields');
    //         return;
    //     }

    //     if (formData.password.length < 4) {
    //         toast.warning('Password must be at least 4 characters');
    //         return;
    //     }

    //     if (!REGISTER_API) {
    //         toast.error('Register API URL is not configured');
    //         return;
    //     }

    //     setLoading(true);

    //     try {
    //         const toastId = toast.loading('Creating user...');

    //         const kbIds = selectedKBs.length > 0 ? selectedKBs.map((kb) => kb.id) : ['0'];

    //         const kbNames = selectedKBs.length > 0 ? selectedKBs.map((kb) => kb.name) : [''];

    //         const response = await fetch(`${REGISTER_API}/${getRagTenantId()}`, {
    //             method: 'POST',
    //             headers: getRagAuthHeaders(),
    //             body: JSON.stringify({
    //                 nickname: formData.nickname,
    //                 email: formData.email,
    //                 password: formData.password,
    //                 kb_ids: kbIds,
    //                 kb_names: kbNames,
    //             }),
    //         });

    //         const data = await response.json();

    //         toast.dismiss(toastId);

    //         if (data.code === 0) {
    //             toast.success(`User "${formData.nickname}" created successfully!`);

    //             setAddUserDialogOpen(false);

    //             setFormData({
    //                 nickname: '',
    //                 email: '',
    //                 password: '',
    //             });

    //             setSelectedKBs([]);

    //             fetchTeamMembers(getRagTenantId());
    //         } else {
    //             toast.error(data.error || data.message || 'Failed to create user');
    //         }
    //     } catch (err) {
    //         console.error('Error creating user:', err);
    //         toast.error('Failed to create user');
    //     } finally {
    //         setLoading(false);
    //     }
    // }, [formData, selectedKBs, fetchTeamMembers]);
    const registerUserMutation = useMutationApi({
        service: 'dl',
        endpoint: `/api/register/${getRagTenantId()}`,
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: registerUserApi } = registerUserMutation;

    const handleAddUser = useCallback(async () => {
        if (!formData.nickname.trim() || !formData.email.trim() || !formData.password.trim()) {
            toast.warning('Please fill in all fields');
            return;
        }

        if (formData.password.length < 4) {
            toast.warning('Password must be at least 4 characters');
            return;
        }

        setLoading(true);

        try {
            const toastId = toast.loading('Creating user...');

            const kbIds = selectedKBs.length > 0 ? selectedKBs.map((kb) => kb.id) : ['0'];

            const kbNames = selectedKBs.length > 0 ? selectedKBs.map((kb) => kb.name) : [''];

            const data = await registerUserApi({
                headers: getRagAuthHeaders(),
                body: {
                    nickname: formData.nickname,
                    email: formData.email,
                    password: formData.password,
                    kb_ids: kbIds,
                    kb_names: kbNames,
                },
            });

            toast.dismiss(toastId);

            if (data.code === 0) {
                toast.success(`User "${formData.nickname}" created successfully!`);

                setAddUserDialogOpen(false);

                setFormData({
                    nickname: '',
                    email: '',
                    password: '',
                });

                setSelectedKBs([]);

                fetchTeamMembers(getRagTenantId());
            } else {
                toast.error(data.error || data.message || 'Failed to create user');
            }
        } catch (err) {
            console.error('Error creating user:', err);

            toast.error(`Failed to create user: ${err.message}`);
        } finally {
            setLoading(false);
        }
    }, [formData, selectedKBs, fetchTeamMembers, registerUserApi]);

    const handleDeleteClick = useCallback((user) => {
        setSelectedUser(user);
        setDeleteDialogOpen(true);
    }, []);

    const createDeleteHandler = useCallback(
        (user) => {
            return () => {
                handleDeleteClick(user);
            };
        },
        [handleDeleteClick],
    );

    // const confirmDelete = useCallback(async () => {
    //     if (!DELETE_USER_API) {
    //         toast.error('Delete user API URL is not configured');
    //         return;
    //     }

    //     setDeleting(true);

    //     try {
    //         const toastId = toast.loading('Deleting user...');

    //         const response = await fetch(DELETE_USER_API, {
    //             method: 'POST',
    //             headers: {
    //                 ...getRagAuthHeaders(),
    //             },
    //             body: JSON.stringify({
    //                 email: selectedUser.email,
    //                 tenant_id: getRagTenantId(),
    //             }),
    //         });

    //         const data = await response.json();

    //         toast.dismiss(toastId);

    //         if (data.code === 0) {
    //             toast.success(`User "${selectedUser.nickname}" deleted successfully`);

    //             setDeleteDialogOpen(false);
    //             setSelectedUser(null);

    //             fetchTeamMembers(getRagTenantId());
    //         } else {
    //             toast.error(data.error || data.message || 'Failed to delete user');
    //         }
    //     } catch (err) {
    //         console.error('Error deleting user:', err);
    //         toast.error('Failed to delete user');
    //     } finally {
    //         setDeleting(false);
    //     }
    // }, [fetchTeamMembers, selectedUser]);
    const deleteUserMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/deleteUser',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: deleteUserApi } = deleteUserMutation;

    const confirmDelete = useCallback(async () => {
        setDeleting(true);

        try {
            const toastId = toast.loading('Deleting user...');

            const data = await deleteUserApi({
                headers: getRagAuthHeaders(),
                body: {
                    email: selectedUser.email,
                    tenant_id: getRagTenantId(),
                },
            });

            toast.dismiss(toastId);

            if (data.code === 0) {
                toast.success(`User "${selectedUser.nickname}" deleted successfully`);

                setDeleteDialogOpen(false);
                setSelectedUser(null);

                fetchTeamMembers(getRagTenantId());
            } else {
                toast.error(data.error || data.message || 'Failed to delete user');
            }
        } catch (err) {
            console.error('Error deleting user:', err);

            toast.error(`Failed to delete user: ${err.message}`);
        } finally {
            setDeleting(false);
        }
    }, [deleteUserApi, fetchTeamMembers, selectedUser]);

    const handleCloseAddUserDialog = useCallback(() => {
        setAddUserDialogOpen(false);

        setFormData({
            nickname: '',
            email: '',
            password: '',
        });

        setSelectedKBs([]);
    }, []);

    const handleCloseDeleteDialog = useCallback(() => {
        setDeleteDialogOpen(false);
    }, []);

    const handleSearch = useCallback(
        (query) => {
            setSearchQuery(query);

            const normalizedQuery = query.toLowerCase();

            const filteredUsers =
                query.trim() === ''
                    ? allUsers
                    : allUsers.filter((user) => {
                          const nickname = user.nickname?.toLowerCase() || '';
                          const email = user.email?.toLowerCase() || '';

                          return (
                              nickname.includes(normalizedQuery) || email.includes(normalizedQuery)
                          );
                      });

            setUsers(filteredUsers);

            setPagination((prev) => ({
                ...prev,
                current: 1,
                total: filteredUsers.length,
            }));
        },
        [allUsers],
    );

    const handleSearchChange = useCallback(
        (e) => {
            handleSearch(e.target.value);
        },
        [handleSearch],
    );

    const handlePageChange = useCallback((e) => {
        setPagination((prev) => ({
            ...prev,
            current: e.page + 1,
        }));
    }, []);

    const paginatedUsers = useMemo(() => {
        const sorted = getSortedUsers(users);

        const startIndex = (pagination.current - 1) * pagination.pageSize;

        return sorted.slice(startIndex, startIndex + pagination.pageSize);
    }, [getSortedUsers, pagination, users]);

    const totalPages = useMemo(() => {
        return Math.ceil(pagination.total / pagination.pageSize);
    }, [pagination]);

    const pageReport = useMemo(() => {
        const start = (pagination.current - 1) * pagination.pageSize + 1;

        const end = Math.min(pagination.current * pagination.pageSize, pagination.total);

        return {
            start,
            end,
        };
    }, [pagination]);

    const paginatorPt = useMemo(() => {
        return {
            ...PAGINATOR_PT,
            pageButton: ({ context }) => ({
                className: `px-3 py-1 text-sm border rounded-md transition ${
                    context.active
                        ? 'bg-blue-600 text-white border-blue-600'
                        : 'border-blue-300 hover:bg-blue-100'
                }`,
            }),
        };
    }, []);

    const nameBodyTemplate = useCallback((user) => {
        return (
            <div className="flex items-center gap-3">
                <div className="h-8 w-8 rounded-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center text-white font-semibold flex-shrink-0 text-sm">
                    {user.nickname ? user.nickname.charAt(0).toUpperCase() : 'U'}
                </div>

                <span
                    className="text-gray-900 font-medium text-sm overflow-hidden text-overflow-ellipsis white-space-nowrap"
                    style={{ maxWidth: '200px' }}
                    title={user.nickname}
                >
                    {user.nickname}
                </span>
            </div>
        );
    }, []);

    const roleBodyTemplate = useCallback((user) => {
        return (
            <Tag
                value={user.role || 'Normal'}
                style={user.role === 'owner' ? OWNER_TAG_STYLE : NORMAL_TAG_STYLE}
            />
        );
    }, []);

    const createDateBodyTemplate = useCallback(
        (user) => {
            return <span className="text-gray-600 text-sm">{formatDate1(user.create_date)}</span>;
        },
        [formatDate1],
    );

    const updateDateBodyTemplate = useCallback(
        (user) => {
            return <span className="text-gray-600 text-sm">{formatDate1(user.update_date)}</span>;
        },
        [formatDate1],
    );

    const actionsBodyTemplate = useCallback(
        (user) => {
            if (user.role === 'owner') {
                return <span className="text-gray-400 text-xs italic">Owner</span>;
            }

            return (
                <Button
                    icon="pi pi-trash"
                    rounded
                    text
                    severity="danger"
                    className="p-1.5"
                    onClick={createDeleteHandler(user)}
                    tooltip="Delete user"
                    tooltipOptions={TOOLTIP_OPTIONS}
                />
            );
        },
        [createDeleteHandler],
    );

    const addUserFooter = useMemo(() => {
        return (
            <div className="flex gap-2 justify-end">
                <Button label="Cancel" outlined onClick={handleCloseAddUserDialog} />

                <Button
                    label={loading ? 'Creating...' : 'Create User'}
                    icon={loading ? 'pi pi-spin pi-spinner' : undefined}
                    disabled={loading}
                    style={CREATE_USER_BUTTON_STYLE}
                    onClick={handleAddUser}
                />
            </div>
        );
    }, [handleAddUser, handleCloseAddUserDialog, loading]);

    const deleteFooter = useMemo(() => {
        return (
            <div className="flex gap-2 justify-end">
                <Button label="Cancel" outlined onClick={handleCloseDeleteDialog} />

                <Button
                    label={deleting ? 'Deleting...' : 'Yes, Delete'}
                    severity="danger"
                    disabled={deleting}
                    onClick={confirmDelete}
                />
            </div>
        );
    }, [confirmDelete, deleting, handleCloseDeleteDialog]);

    return (
        <PageLayout className="w-full">
            <PageLayout.Header
                title="Team Members"
                actions={
                    <div className="flex align-items-center gap-3">
                        <span className="p-input-icon-left relative">
                            <i className="pi pi-search absolute left-3 top-1/2 -translate-y-1/2 text-blue-400" />

                            <InputText
                                type="text"
                                placeholder="Search by name or email..."
                                value={searchQuery}
                                onChange={handleSearchChange}
                                className="pl-10 py-2 w-64 border-blue-300"
                            />
                        </span>

                        <Button
                            label="Add User"
                            icon="pi pi-plus"
                            style={ADD_USER_BUTTON_STYLE}
                            onClick={handleAddUserDialogOpen}
                        />
                    </div>
                }
            />

            <PageLayout.Content>
                <Card>
                    {loading ? (
                        <div className="flex items-center justify-center py-12">
                            <ProgressSpinner style={LOADER_STYLE} />
                        </div>
                    ) : users.length > 0 ? (
                        <div
                            className="bg-white rounded-lg shadow-md overflow-x-auto border border-blue-200 max-w-full"
                            style={{ minHeight: '300px' }}
                        >
                            <DataTable
                                value={paginatedUsers}
                                tableStyle={TABLE_STYLE}
                                pt={TABLE_PT}
                            >
                                <Column
                                    field="nickname"
                                    header="Name"
                                    sortable
                                    body={nameBodyTemplate}
                                    headerClassName="font-semibold text-blue-900 cursor-pointer"
                                    onHeaderClick={handleNicknameSort}
                                />

                                <Column
                                    field="email"
                                    header="Email"
                                    sortable
                                    headerClassName="font-semibold text-blue-900 cursor-pointer"
                                    bodyClassName="text-gray-700 text-sm"
                                    bodyStyle={{
                                        maxWidth: '250px',
                                        overflow: 'hidden',
                                        textOverflow: 'ellipsis',
                                        whiteSpace: 'nowrap',
                                    }}
                                    onHeaderClick={handleEmailSort}
                                />

                                <Column
                                    field="role"
                                    header="Role"
                                    body={roleBodyTemplate}
                                    headerClassName="font-semibold text-blue-900"
                                />

                                <Column
                                    field="create_date"
                                    header="Added On"
                                    sortable
                                    body={createDateBodyTemplate}
                                    headerClassName="font-semibold text-blue-900 cursor-pointer"
                                    onHeaderClick={handleCreateDateSort}
                                />

                                <Column
                                    field="update_date"
                                    header="Last Login Time"
                                    sortable
                                    body={updateDateBodyTemplate}
                                    headerClassName="font-semibold text-blue-900 cursor-pointer"
                                    onHeaderClick={handleUpdateDateSort}
                                />

                                <Column
                                    header="Actions"
                                    body={actionsBodyTemplate}
                                    headerClassName="font-semibold text-blue-900 text-center"
                                    bodyClassName="text-center"
                                />
                            </DataTable>

                            {totalPages > 1 && (
                                <div className="flex items-center justify-between px-6 py-4 border-t border-blue-200 bg-blue-50">
                                    <div className="text-sm text-gray-700">
                                        Showing {pageReport.start} to {pageReport.end} of{' '}
                                        {pagination.total} members
                                    </div>

                                    <Paginator
                                        first={(pagination.current - 1) * pagination.pageSize}
                                        rows={pagination.pageSize}
                                        totalRecords={pagination.total}
                                        onPageChange={handlePageChange}
                                        template="PrevPageLink PageLinks NextPageLink"
                                        pt={paginatorPt}
                                    />
                                </div>
                            )}
                        </div>
                    ) : (
                        <div className="flex flex-column align-items-center justify-content-center py-12 bg-blue-50 border-round-lg">
                            <div className="h-16 w-16 border-circle bg-blue-100 flex align-items-center justify-content-center mb-4">
                                <i className="pi pi-plus text-blue-400" style={EMPTY_ICON_STYLE} />
                            </div>

                            <p className="text-blue-900 text-lg font-semibold">
                                {searchQuery ? 'No team members found' : 'No team members yet'}
                            </p>

                            <p className="text-blue-600 text-sm mt-2">
                                {searchQuery
                                    ? 'Try a different search'
                                    : 'Click "Add User" to invite your first team member'}
                            </p>
                        </div>
                    )}
                </Card>
            </PageLayout.Content>

            <Dialog
                visible={addUserDialogOpen}
                onHide={handleCloseAddUserDialog}
                header="Add New Team Member"
                footer={addUserFooter}
                style={ADD_USER_DIALOG_STYLE}
                contentStyle={ADD_USER_DIALOG_CONTENT_STYLE}
            >
                <div className="space-y-5 py-4">
                    <div>
                        <label
                            htmlFor="team-member-nickname"
                            className="text-sm font-semibold text-blue-900 mb-2 block"
                        >
                            Nickname
                        </label>

                        <InputText
                            id="team-member-nickname"
                            placeholder="Enter member's nickname"
                            value={formData.nickname}
                            onChange={handleNicknameChange}
                            disabled={loading}
                            className="w-full border-blue-300"
                        />
                    </div>

                    <div>
                        <label
                            htmlFor="team-member-email"
                            className="text-sm font-semibold text-blue-900 mb-2 block"
                        >
                            Email
                        </label>

                        <InputText
                            id="team-member-email"
                            type="email"
                            placeholder="Enter member's email"
                            value={formData.email}
                            onChange={handleEmailChange}
                            disabled={loading}
                            className="w-full border-blue-300"
                        />
                    </div>

                    <div>
                        <label
                            htmlFor="team-member-password"
                            className="text-sm font-semibold text-blue-900 mb-2 block"
                        >
                            Password
                        </label>

                        <Password
                            inputId="team-member-password"
                            placeholder="Enter password (min 4 characters)"
                            value={formData.password}
                            onChange={handlePasswordChange}
                            disabled={loading}
                            className="w-full"
                            inputClassName="w-full border-blue-300"
                            feedback={false}
                            toggleMask
                        />
                    </div>

                    <div>
                        <label className="text-sm font-semibold text-blue-900 mb-3 block">
                            Select Knowledge Bases (Optional - {selectedKBs.length} selected)
                        </label>

                        {loadingKBs ? (
                            <div className="flex items-center justify-center py-8">
                                <ProgressSpinner style={KB_LOADER_STYLE} />
                            </div>
                        ) : knowledgeBases.length > 0 ? (
                            <div className="max-h-60 overflow-y-auto border border-blue-200 rounded-lg p-3 bg-blue-50">
                                <div className="space-y-2">
                                    {knowledgeBases.map((kb) => {
                                        const isSelected = selectedKBs.some(
                                            (item) => item.id === kb.id,
                                        );

                                        return (
                                            <div
                                                key={kb.id}
                                                role="button"
                                                tabIndex={0}
                                                onClick={createKBSelectionHandler(kb)}
                                                onKeyDown={createKBKeyDownHandler(kb)}
                                                className={`p-3 rounded-lg border-2 cursor-pointer transition-all ${
                                                    isSelected
                                                        ? 'border-blue-500 bg-blue-100'
                                                        : 'border-blue-200 bg-white hover:border-blue-300 hover:bg-blue-50'
                                                }`}
                                            >
                                                <div className="flex items-center justify-between">
                                                    <div className="flex-1">
                                                        <p className="font-medium text-blue-900">
                                                            {kb.name}
                                                        </p>

                                                        <p className="text-xs text-blue-600 mt-1">
                                                            {kb.doc_num} files • {kb.permission}
                                                        </p>
                                                    </div>

                                                    {isSelected && (
                                                        <i className="pi pi-check text-blue-600 flex-shrink-0 ml-2" />
                                                    )}
                                                </div>
                                            </div>
                                        );
                                    })}
                                </div>
                            </div>
                        ) : (
                            <p className="text-sm text-gray-500 italic p-4 bg-gray-50 rounded-lg">
                                No knowledge bases available
                            </p>
                        )}
                    </div>
                </div>
            </Dialog>

            <Dialog
                visible={deleteDialogOpen}
                onHide={handleCloseDeleteDialog}
                header="Delete Team Member"
                footer={deleteFooter}
                style={DELETE_DIALOG_STYLE}
            >
                <p className="text-gray-700">
                    Are you sure you want to remove{' '}
                    <span className="font-semibold">{selectedUser?.nickname}</span> (
                    {selectedUser?.email}) from the team? This action cannot be undone.
                </p>
            </Dialog>
        </PageLayout>
    );
}
