import { useState, useCallback } from 'react';
import { toast } from '../utils/toast';
import API_CONFIG from '../utils/apiConfig';
import { getRagAuthHeaders } from '../utils/ragAuth';

export const useFileUpload = (datasetId) => {
    const [uploading, setUploading] = useState(false);

    const uploadToDocumentService = useCallback(
        async (file) => {
            const formData = new FormData();
            formData.append('file', file);
            // No more kb_id in form data — it's in the URL path now

            const response = await fetch(`${API_CONFIG.DOCUMENT_UPLOAD}/${datasetId}/documents`, {
                method: 'POST',
                headers: {
                    Authorization: localStorage.getItem('ragAuthorization2') || '',
                },
                body: formData,
            });

            if (!response.ok) {
                const errorData = await response.json().catch(() => ({}));
                throw new Error(`Document upload failed: ${errorData.message || response.status}`);
            }

            return await response.json();
        },
        [datasetId],
    );

    const uploadFile = useCallback(
        async (file, datasetName, onComplete) => {
            if (!file) throw new Error('No file selected');
            if (!datasetName) throw new Error('Dataset name not loaded');

            setUploading(true);
            try {
                const toastId1 = toast.loading('Uploading to document service...');
                await uploadToDocumentService(file);
                toast.dismiss(toastId1);
                toast.success('Document uploaded successfully');

                if (onComplete) onComplete();
            } finally {
                setUploading(false);
            }
        },
        [uploadToDocumentService],
    );

    return { uploading, uploadFile };
};
