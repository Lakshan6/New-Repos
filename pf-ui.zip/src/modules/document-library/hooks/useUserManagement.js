import { useState, useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { toast } from '../utils/toast';
import { getRagTenantId } from '../utils/tenant';
import { STORAGE_KEYS } from '@shared/utils';
export const useUserManagement = (datasetId, tenantId) => {
    const [users, setUsers] = useState([]);
    const [allUsers, setAllUsers] = useState([]);
    const [userLoading, setUserLoading] = useState(false);
    const headers = {
        Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN)}`,
    };
    const getTenantId = useCallback(() => tenantId || getRagTenantId(), [tenantId]);

    // ====================== Mutations ======================

    const accessedUsersMutation = useMutationApi({
        service: 'dl', // or 'dl'
        endpoint: '/api/getAccessedUsers',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const teamUsersMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/team',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const addUserMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/addUsertoDataset',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const deleteUserMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/deleteUserFromDataset',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: fetchAccessedUsersApi } = accessedUsersMutation;
    const { mutateAsync: fetchTeamUsersApi } = teamUsersMutation;
    const { mutateAsync: addUserApi } = addUserMutation;
    const { mutateAsync: deleteUserApi } = deleteUserMutation;
    // ====================== Functions ======================
    const fetchAccessedUsers = useCallback(async () => {
        const resolvedTenantId = getTenantId();

        if (!datasetId || !resolvedTenantId) return;

        setUserLoading(true);

        try {
            const data = await fetchAccessedUsersApi({
                body: {
                    dataset_id: datasetId,
                    tenant_id: resolvedTenantId,
                },
            });

            setUsers(data || []);
        } catch (err) {
            console.error('Error fetching accessed users:', err);
            toast.error('Failed to load users');
        } finally {
            setUserLoading(false);
        }
    }, [datasetId, getTenantId, fetchAccessedUsersApi]);
    const fetchAllTeamUsers = useCallback(async () => {
        const resolvedTenantId = getTenantId();

        if (!datasetId || !resolvedTenantId) return;

        try {
            const data = await fetchTeamUsersApi({
                params: {
                    dataset_id: datasetId,
                    tenant_id: resolvedTenantId,
                },
            });

            const emails =
                Array.isArray(data) && data.every((item) => typeof item === 'string')
                    ? data
                    : data.map((user) => user.email).filter(Boolean);

            setAllUsers(emails || []);
        } catch (err) {
            console.error('Error fetching team users:', err);
            toast.error('Failed to load team users');
        }
    }, [datasetId, getTenantId, fetchTeamUsersApi]);
    const addUser = useCallback(
        async (email, datasetName) => {
            const resolvedTenantId = getTenantId();

            if (!email.trim()) {
                throw new Error('Invalid email');
            }

            if (!datasetName) {
                throw new Error('Dataset name not loaded');
            }

            const data = await addUserApi({
                body: {
                    email,
                    dataset_id: datasetId,
                    tenant_id: resolvedTenantId,
                    dataset_name: datasetName,
                },
            });

            toast.success(`User ${email} added successfully`);

            await fetchAccessedUsers();

            return data;
        },
        [datasetId, getTenantId, addUserApi, fetchAccessedUsers],
    );

    const deleteUser = useCallback(
        async (email) => {
            const data = await deleteUserApi({
                body: {
                    email,
                    dataset_id: datasetId,
                },
            });

            toast.success(`User ${email} removed successfully`);

            await fetchAccessedUsers();

            return data;
        },
        [datasetId, deleteUserApi, fetchAccessedUsers],
    );
    return {
        users,
        allUsers,
        userLoading,
        fetchAccessedUsers,
        fetchAllTeamUsers,
        addUser,
        deleteUser,
        // Optional: expose mutations if you need .isPending, .error, etc.
        mutations: {
            accessedUsers: accessedUsersMutation,
            teamUsers: teamUsersMutation,
            addUser: addUserMutation,
            deleteUser: deleteUserMutation,
        },
    };
};
