import { useQuery } from '@tanstack/react-query';
import { useSetAtom, useAtomValue } from 'jotai';
import { useEffect } from 'react';
import { ragAxios, RAG_APIS, EXCLUDED_DIALOG_NAMES } from '../utils/ragApi';
import { dialogListAtom, selectedDialogAtom } from '../store/atoms';

// const fetchDialogs = async () => {
//     const { data } = await ragAxios.get(RAG_APIS.DIALOG_LIST, {
//         params: {
//             page: 1,
//             page_size: 100,
//             orderby: 'update_time',
//             desc: true,
//         },
//     });
//     if (data.code !== 0) throw new Error(data.message ?? 'Failed to load dialogs');
//     // Response: { data: { chats: [], total } }
//     return data.data?.chats ?? [];
// };
const fetchDialogs = async () => {
    const { data } = await ragAxios.get(RAG_APIS.DIALOG_LIST, {
        params: {
            page: 1,
            page_size: 100,
            orderby: 'update_time',
            desc: true,
        },
    });
    if (data.code !== 0) throw new Error(data.message ?? 'Failed to load dialogs');

    // Normalize data (backend might return .chats or .dialogs)
    const dialogs = Array.isArray(data.data)
        ? data.data
        : data.data?.chats || data.data?.dialogs || [];

    return dialogs;
};

const useDialogs = () => {
    const setDialogList = useSetAtom(dialogListAtom);
    const setSelectedDialog = useSetAtom(selectedDialogAtom);
    const selectedDialog = useAtomValue(selectedDialogAtom);

    const query = useQuery({
        queryKey: ['rag', 'dialog-list'],
        queryFn: fetchDialogs,
        staleTime: 5 * 60 * 1000,
    });

    useEffect(() => {
        if (!query.data?.length) return;
        setDialogList(query.data);
        if (!selectedDialog) {
            // Auto-select first non-excluded dialog
            const preferred = query.data.find((d) => !EXCLUDED_DIALOG_NAMES.includes(d.name));
            setSelectedDialog(preferred ?? query.data[0]);
        }
    }, [query.data, selectedDialog, setDialogList, setSelectedDialog]);

    return query;
};

export default useDialogs;
