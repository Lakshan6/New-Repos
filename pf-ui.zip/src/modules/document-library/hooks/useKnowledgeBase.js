import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useSetAtom } from 'jotai';
import { ragAxios, RAG_APIS, getRagAuth, SELF_DOCUMENT_KB_NAME } from '../utils/ragApi';
import { selfDocKbAtom } from '../store/atoms';

// ── Self-doc KB ───────────────────────────────────────────────────────────────
const useSelfDocKb = () => {
    const setSelfDocKb = useSetAtom(selfDocKbAtom);

    return useQuery({
        queryKey: ['rag', 'self-doc-kb'],
        queryFn: async () => {
            const { authorization } = getRagAuth();
            const { data } = await ragAxios.get(RAG_APIS.KB_LIST, {
                headers: { Authorization: authorization },
            });
            if (data.code !== 0) throw new Error(data.message ?? 'Failed to load KBs');
            const kbList = Array.isArray(data.data) ? data.data : [];
            const kb = kbList.find((k) => k.name === SELF_DOCUMENT_KB_NAME) ?? null;
            setSelfDocKb(kb);
            return kb;
        },
        staleTime: 5 * 60 * 1000,
    });
};

// ── Document list with polling ────────────────────────────────────────────────
const useKbDocuments = (kbId) => {
    return useQuery({
        queryKey: ['rag', 'document-list', kbId],
        queryFn: async () => {
            const { authorization } = getRagAuth();
            const { data } = await ragAxios.get(
                `${RAG_APIS.DOCUMENT_LIST}/${kbId}/documents?keywords=&page=1&page_size=100`,
                { headers: { Authorization: authorization } },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Failed to load docs');
            return { docs: data.data?.docs ?? [], total: data.data?.total ?? 0 };
        },
        enabled: !!kbId,
        staleTime: 0,
        // Poll every 1.5s while any doc has run === "UNSTART" or "RUNNING" (parsing in progress)
        refetchInterval: (query) => {
            const docs = query?.state?.data?.docs ?? [];
            const anyRunning = docs.some(
                (d) => String(d.run) === 'UNSTART' || String(d.run) === 'RUNNING',
            );
            return anyRunning ? 1500 : false;
        },
    });
};

// ── Toggle status ─────────────────────────────────────────────────────────────
const useToggleDocStatus = (kbId) => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async ({ docId, docIds, status }) => {
            const ids = docIds || (Array.isArray(docId) ? docId : [docId]);
            const { authorization } = getRagAuth();
            const { data } = await ragAxios.post(
                `${RAG_APIS.DOCUMENT_LIST}/${kbId}/documents/batch-update-status`,
                { doc_ids: ids, status },
                { headers: { Authorization: authorization } },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Status change failed');
            return data.data;
        },
        onSuccess: () =>
            queryClient.invalidateQueries({ queryKey: ['rag', 'document-list', kbId] }),
    });
};

// ── Delete ────────────────────────────────────────────────────────────────────
const useDeleteDocument = (kbId) => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async (docId) => {
            const { authorization } = getRagAuth();
            const { data } = await ragAxios.post(
                RAG_APIS.DOCUMENT_REMOVE,
                { doc_id: docId },
                { headers: { Authorization: authorization } },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Delete failed');
            return data.data;
        },
        onSuccess: () =>
            queryClient.invalidateQueries({ queryKey: ['rag', 'document-list', kbId] }),
    });
};

// ── Rerun parsing ─────────────────────────────────────────────────────────────
const useRerunDocument = (kbId) => {
    const queryClient = useQueryClient();
    return useMutation({
        mutationFn: async (docId) => {
            const { authorization } = getRagAuth();
            const { data } = await ragAxios.post(
                RAG_APIS.DOCUMENT_RUN,
                { doc_ids: [docId], run: 1, delete: false },
                { headers: { Authorization: authorization } },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Rerun failed');
            return data.data;
        },
        // After rerun starts, begin polling
        onSuccess: () =>
            queryClient.invalidateQueries({ queryKey: ['rag', 'document-list', kbId] }),
    });
};

export { useSelfDocKb, useKbDocuments, useToggleDocStatus, useDeleteDocument, useRerunDocument };
