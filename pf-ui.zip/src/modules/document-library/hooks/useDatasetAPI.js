import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getRagAuth } from '../utils/ragApi';
import { STORAGE_KEYS } from '@shared/utils';

export const useDatasetAPI = () => {
    const getTenantId = useCallback(() => getRagAuth().tenantId, []);
    const getAuthHeader = useCallback(() => getRagAuth().authorization, []);

    const headers = {
        'Auth-Token': getRagAuth().authorization,
        Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN)}`,
    };
    // Fetch Dataset Details
    const fetchDatasetDetailsMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/kb_detail',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: fetchDatasetDetailsApi } = fetchDatasetDetailsMutation;

    const fetchDatasetDetails = useCallback(
        async (kbId) => {
            const tenantId = getTenantId();

            if (!kbId || !tenantId) {
                throw new Error('Missing KB ID or Tenant ID');
            }

            const data = await fetchDatasetDetailsApi({
                body: {
                    kb_id: kbId,
                    tenant_id: tenantId,
                },
            });

            if (data.code === 0 && data.data?.name) {
                return {
                    name: data.data.name,
                    id: kbId,
                };
            }

            throw new Error(data.message || 'Invalid KB response');
        },
        [getTenantId, fetchDatasetDetailsApi],
    );

    // Fetch Files
    const fetchFilesMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/filelist',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: fetchFilesApi } = fetchFilesMutation;

    const fetchFiles = useCallback(
        async (kbId) => {
            const tenantId = getTenantId();

            if (!kbId || !tenantId) {
                throw new Error('Missing KB ID or Tenant ID');
            }

            const data = await fetchFilesApi({
                body: {
                    kb_id: kbId,
                    tenant_id: tenantId,
                    page: 1,
                    page_size: 100,
                },
            });

            if (data.code === 0 && data.data?.docs) {
                return data.data.docs;
            }

            throw new Error(data.message || 'Failed to fetch files');
        },
        [getTenantId, fetchFilesApi],
    );

    return {
        fetchDatasetDetails,
        fetchFiles,
        getTenantId,
        getAuthHeader,
        // Optional: expose mutations if you need loading/error states
        mutations: {
            fetchDatasetDetails: fetchDatasetDetailsMutation,
            fetchFiles: fetchFilesMutation,
        },
    };
};
