import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAtomValue, useSetAtom, useAtom } from 'jotai';
import { useCallback } from 'react';
import { ragAxios, RAG_APIS } from '../utils/ragApi';
import {
    selectedDialogAtom,
    conversationListAtom,
    activeConversationAtom,
    messagesAtom,
} from '../store/atoms';
import { v4 as uuidv4 } from 'uuid';

const newId = uuidv4().replace(/-/g, ''); // 32-char hex string

// ── List ──────────────────────────────────────────────────────────────────────
const useConversations = () => {
    const selectedDialog = useAtomValue(selectedDialogAtom);
    const setConversationList = useSetAtom(conversationListAtom);

    return useQuery({
        queryKey: ['rag', 'conversations', selectedDialog?.id],
        queryFn: async () => {
            const { data } = await ragAxios.get(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Failed to load conversations');
            const list = data.data ?? [];
            setConversationList(list);
            return list;
        },
        enabled: !!selectedDialog?.id,
        staleTime: 30 * 1000,
    });
};

// ── Create ────────────────────────────────────────────────────────────────────
// const useCreateConversation = () => {
//     const queryClient = useQueryClient();
//     const selectedDialog = useAtomValue(selectedDialogAtom);
//     const setActiveConversation = useSetAtom(activeConversationAtom);
//     const setMessages = useSetAtom(messagesAtom);

//     return useMutation({
//         mutationFn: async () => {

//             const { data } = await ragAxios.post(`${RAG_APIS.SESSIONS_BASE}/set`, {
//                 conversation_id: newId,
//                 dialog_id: selectedDialog.id,
//                 name: 'New conversation',
//                 is_new: true,
//             });
//             if (data.code !== 0) throw new Error(data.message ?? 'Failed to create conversation');
//             return data.data;
//         },
//         onSuccess: (conv) => {
//             setActiveConversation(conv);
//             // "message" field (not "messages") — load ONLY this conversation's prologue
//             setMessages(conv.message ?? []);
//             queryClient.invalidateQueries({ queryKey: ['rag', 'conversations', selectedDialog?.id] });
//         },
//     });
// };
const useCreateConversation = () => {
    const queryClient = useQueryClient();
    const selectedDialog = useAtomValue(selectedDialogAtom);
    const setActiveConversation = useSetAtom(activeConversationAtom);
    const setMessages = useSetAtom(messagesAtom);

    return useMutation({
        mutationFn: async (name = 'New conversation') => {
            const { data } = await ragAxios.post(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                { name },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Failed to create conversation');
            return data.data; // Server returns the created session object
        },
        onSuccess: (conv) => {
            setActiveConversation(conv);
            setMessages(
                conv.messages?.length
                    ? conv.messages
                    : [
                          {
                              role: 'assistant',
                              content: "Hi! I'm your assistant, what can I do for you?",
                          },
                      ],
            );
            queryClient.invalidateQueries({
                queryKey: ['rag', 'conversations', selectedDialog?.id],
            });
        },
    });
};

// ── Rename ────────────────────────────────────────────────────────────────────
const useRenameConversation = () => {
    const queryClient = useQueryClient();
    const selectedDialog = useAtomValue(selectedDialogAtom);

    return useMutation({
        mutationFn: async ({ sessionId, name }) => {
            const { data } = await ragAxios.patch(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions/${sessionId}`,
                { name },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Rename failed');
            return data.data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: ['rag', 'conversations', selectedDialog?.id],
            });
        },
    });
};

// ── Delete ────────────────────────────────────────────────────────────────────
const useDeleteConversation = () => {
    const queryClient = useQueryClient();
    const selectedDialog = useAtomValue(selectedDialogAtom);
    const [activeConversation, setActiveConversation] = useAtom(activeConversationAtom);
    const setMessages = useSetAtom(messagesAtom);

    return useMutation({
        mutationFn: async (conversationId) => {
            const { data } = await ragAxios.delete(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                { data: { ids: [conversationId] } },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Delete failed');
            return conversationId;
        },
        onSuccess: (deletedId) => {
            if (activeConversation?.id === deletedId) {
                setActiveConversation(null);
                setMessages([]);
            }
            queryClient.invalidateQueries({
                queryKey: ['rag', 'conversations', selectedDialog?.id],
            });
        },
    });
};

// // ── Select existing conversation ──────────────────────────────────────────────
// const useSelectConversation = () => {
//     const setActiveConversation = useSetAtom(activeConversationAtom);
//     const setMessages = useSetAtom(messagesAtom);

//     return useCallback(
//         (conv) => {
//             setActiveConversation(conv);
//             // Full history already in conv.message[] from list API
//             // "message" field (NOT "messages")
//             setMessages(conv.message ?? []);
//         },
//         [setActiveConversation, setMessages],
//     );
// };
const useSelectConversation = () => {
    const setActiveConversation = useSetAtom(activeConversationAtom);
    const setMessages = useSetAtom(messagesAtom);

    return useCallback(
        (conv) => {
            setActiveConversation(conv);

            // Merge reference[] into assistant messages
            const rawMessages = conv.messages ?? [];
            const references = conv.reference ?? [];

            // reference[0] maps to the FIRST assistant response (not the greeting)
            // reference[1] maps to the SECOND assistant response, etc.
            let refIndex = 0;
            const mergedMessages = rawMessages.map((msg, idx) => {
                // Skip the initial greeting (first assistant message at index 0)
                if (msg.role === 'assistant' && idx > 0) {
                    const ref = references[refIndex] ?? { chunks: [], doc_aggs: [] };
                    refIndex++;
                    return { ...msg, reference: ref };
                }
                return msg;
            });

            setMessages(mergedMessages);
        },
        [setActiveConversation, setMessages],
    );
};

export {
    useConversations,
    useCreateConversation,
    useRenameConversation,
    useDeleteConversation,
    useSelectConversation,
};
