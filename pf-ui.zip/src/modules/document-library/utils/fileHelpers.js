export const formatFileDate = (timestamp) => {
    return new Date(timestamp).toLocaleString();
};

export const getFileStatusBadge = (status) => {
    return {
        className: status === '1' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700',
        label: status === '1' ? '✓ Enable' : 'Disable',
    };
};

export const filterFiles = (files, searchQuery) => {
    return files.filter((file) => file.name.toLowerCase().includes(searchQuery.toLowerCase()));
};

export const filterUsers = (users, searchQuery) => {
    return users.filter((email) => email.toLowerCase().includes(searchQuery.toLowerCase()));
};
