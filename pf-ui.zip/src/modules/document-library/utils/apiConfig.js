const API_CONFIG = {
    // Auth APIs
    //   LOGIN: import.meta.env.VITE_LOGIN_API,
    //   TENANT_INFO: import.meta.env.VITE_TENANT_INFO_API,
    //   // Dataset APIs
    //   FETCHDATA: import.meta.env.VITE_FETCHDATA_API,
    //   KB_DETAIL: import.meta.env.VITE_KB_DETAIL_API,
    //   FILELIST: import.meta.env.VITE_FILELIST_API,
    //   CREATEDATASET: import.meta.env.VITE_CREATEDATASET_API,
    //   RENAMEKB: import.meta.env.VITE_RENAMEKB_API,
    //   DELETEDATASET: import.meta.env.VITE_DELETEDATASET_API,
    //   // File APIs
    //   PARENTID: import.meta.env.VITE_PARENTID_API,
    //   DOCUMENT_LIST: import.meta.env.VITE_DOCUMENT_LIST,
    //   // User/Team APIs
    //   TEAM: import.meta.env.VITE_TEAM_API,
    //   REGISTER: import.meta.env.VITE_REGISTER_API,
    //   DELETE_USER: import.meta.env.VITE_DELETE_USER_API,
    //   GET_ACCESSED_USERS: import.meta.env.VITE_GET_ACCESSED_USERS_API,
    //   ADD_USER_TO_DATASET: import.meta.env.VITE_ADD_USER_TO_DATASET_API,
    // DELETE_USER_FROM_DATASET: import.meta.env.VITE_DELETE_USER_FROM_DATASET_API,

    DOCUMENT_UPLOAD: import.meta.env.VITE_DOCUMENT_UPLOAD_API,
    DOCUMENT_GET: import.meta.env.VITE_DOCUMENT_GET,
    FILE_UPLOAD: import.meta.env.VITE_FILE_UPLOAD_API,
    DOCUMENT_RUN: import.meta.env.VITE_DOCUMENT_RUN_API,
    DOCUMENT_DELETE: import.meta.env.VITE_DOCUMENT_DELETE,
    PUBLIC_KEY_PATH: import.meta.env.VITE_PUBLIC_KEY_PATH || '/public.pem',
};

// Validate that all required APIs are configured
const validateConfig = () => {
    const requiredKeys = [
        // 'LOGIN',
        // 'TENANT_INFO',
        // 'FETCHDATA',
        // 'KB_DETAIL',
        // 'FILELIST',
        // 'CREATEDATASET',
        // 'RENAMEKB',
        // 'DELETEDATASET',
        // 'PARENTID',
        // 'DOCUMENT_UPLOAD',
        // 'FILE_UPLOAD',
        // 'DOCUMENT_RUN',
        // 'DOCUMENT_DELETE',
        // 'DOCUMENT_GET',
        // 'DOCUMENT_LIST',
        // 'TEAM',
        // 'REGISTER',
        // 'DELETE_USER',
        // 'GET_ACCESSED_USERS',
        // 'ADD_USER_TO_DATASET',
        // 'DELETE_USER_FROM_DATASET',
        'DOCUMENT_UPLOAD',
        'DOCUMENT_GET',
        'FILE_UPLOAD',
        'DOCUMENT_RUN',
        'DOCUMENT_DELETE',
    ];

    const missingKeys = requiredKeys.filter((key) => !API_CONFIG[key]);

    if (missingKeys.length > 0) {
        console.warn('⚠️ Missing environment variables:', missingKeys);
    }
};

// Run validation in development
if (import.meta.env.DEV) {
    validateConfig();
}

export default API_CONFIG;
