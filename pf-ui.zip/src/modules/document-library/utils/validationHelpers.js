export const validateEmail = (email) => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

export const validateFileSize = (file, maxSizeMB = 100) => {
    return file.size <= maxSizeMB * 1024 * 1024;
};

export const validateFileType = (file, allowedTypes = []) => {
    if (allowedTypes.length === 0) return true;
    return allowedTypes.some((type) => file.type.includes(type));
};
