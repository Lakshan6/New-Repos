// authUtils.js
// Utility functions to manage authentication tokens

/**
 * Get authorization token from localStorage
 */
export const getauthorizationToken = () => {
    return localStorage.getItem('Authorization') || '';
};

/**
 * Get Token from localStorage
 */
export const getToken = () => {
    return localStorage.getItem('Token') || '';
};

/**
 * Get all auth tokens
 */
export const getAllTokens = () => {
    return {
        Authorization: localStorage.getItem('Authorization'),
        Token: localStorage.getItem('Token'),
        userInfo: JSON.parse(localStorage.getItem('userInfo') || '{}'),
    };
};

/**
 * Create headers with authorization
 */
export const createAuthHeaders = (includeContentType = true) => {
    const headers = {
        ...(includeContentType && { 'Content-Type': 'application/json' }),
    };

    const Authorization = getauthorizationToken();
    const Token = getToken();

    // Use authorization header if available, otherwise use Token
    if (Authorization) {
        headers['Authorization'] = Authorization;
    } else if (Token) {
        headers['Authorization'] = `Bearer ${Token}`;
    }

    return headers;
};

/**
 * Make authenticated API call
 */
export const authenticatedFetch = async (url, options = {}) => {
    const headers = {
        'Content-Type': 'application/json',
        ...createAuthHeaders(false),
        ...options.headers,
    };

    const response = await fetch(url, {
        ...options,
        headers,
    });

    return response;
};

/**
 * Check if user is authenticated
 */
export const isAuthenticated = () => {
    const Authorization = getauthorizationToken();
    const Token = getToken();
    return !!(Authorization || Token);
};

/**
 * Clear all auth tokens (logout)
 */
export const clearAuthTokens = () => {
    localStorage.removeItem('Authorization');
    localStorage.removeItem('Token');
    localStorage.removeItem('userInfo');
    localStorage.removeItem('tenantInfo');
    console.log('Auth tokens cleared from localStorage');
};

/**
 * Log current tokens (for debugging)
 */
export const logAuthTokens = () => {
    console.log('=== STORED AUTH TOKENS ===');
    console.log('Authorization:', getauthorizationToken().substring(0, 30) + '...');
    console.log('Token:', getToken().substring(0, 30) + '...');
    console.log('User Info:', JSON.parse(localStorage.getItem('userInfo') || '{}'));
};
