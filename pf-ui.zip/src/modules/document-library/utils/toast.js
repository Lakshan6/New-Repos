const notify = (level, message) => {
    const text = typeof message === 'string' ? message : String(message || '');
    if (!text) return;

    if (typeof window !== 'undefined' && typeof window.dispatchEvent === 'function') {
        window.dispatchEvent(
            new CustomEvent('document-library:toast', {
                detail: { level, message: text },
            }),
        );
    }

    const logger = level === 'error' ? console.error : console.log;
    logger(text);
};

export const toast = {
    success: (message) => notify('success', message),
    error: (message) => notify('error', message),
    info: (message) => notify('info', message),
    loading: (message) => {
        notify('info', message);
        return `loading-${Date.now()}`;
    },
    dismiss: () => {},
};
