// import { STORAGE_KEYS } from '@shared/utils';

// export const getRagToken = () => localStorage.getItem(STORAGE_KEYS.RAG_AUTHORIZATION) || '';

// export const getRagAuthHeaders = (includeContentType = true) => {
//     const ragToken = getRagToken();
//     return {
//         ...(includeContentType ? { 'Content-Type': 'application/json' } : {}),
//         ...(ragToken ? { Authorization: ragToken } : {}),
//     };
// };

// export const isRagAuthenticated = () => Boolean(getRagToken());
import { STORAGE_KEYS } from '@shared/utils';

export const getRagToken = () => {
    return localStorage.getItem(STORAGE_KEYS.RAG_AUTHORIZATION2) || '';
};

export const getRagTenantId = () => {
    return localStorage.getItem(STORAGE_KEYS.RAG_TENANT2) || '';
};

export const getRagAuthHeaders = (includeContentType = true) => {
    const ragToken = getRagToken();

    return {
        ...(includeContentType ? { 'Content-Type': 'application/json' } : {}),
        ...(ragToken ? { Authorization: ragToken } : {}),
    };
};

export const isRagAuthenticated = () => {
    return Boolean(getRagToken());
};
