export const createCoaFormDefinition = {
    submitLabel: 'Upload',
    fields: [
        {
            name: 'coaId',
            label: 'COA ID',
            type: 'text',
            required: true,
            placeholder: 'Enter COA ID',
        },
        {
            name: 'coaName',
            label: 'COA Name',
            type: 'text',
            required: true,
            placeholder: 'Enter COA Name',
        },
        {
            name: 'description',
            label: 'COA Description',
            type: 'text',
            required: true,
            placeholder: 'Enter COA Description',
        },
    ],
};
