export const createCompanyFormDefinition = {
    // title: 'Create Company',
    submitLabel: 'Create',
    fields: [
        {
            name: 'companyCode',
            label: 'Company Code',
            type: 'text',
            required: true,
            validations: [
                {
                    rule: 'pattern',
                    value: /^[A-Z0-9_]+$/,
                    message: 'Only uppercase letters and numbers allowed',
                },
            ],
        },
        {
            name: 'name',
            label: 'Company Name',
            type: 'text',
            required: true,
        },
        {
            name: 'country',
            label: 'Country',
            type: 'dropdown',
            required: true,
            options: [
                { label: 'India', value: 'IN' },
                { label: 'USA', value: 'US' },
            ],
        },
        {
            name: 'coaId',
            label: 'Chart of Accounts',
            type: 'dropdown',
            required: true,
            optionsKey: 'coaOptions',
            optionLabel: 'coaName',
            optionValue: 'coaId',
            placeholder: 'Select Chart of Accounts',
        },
        {
            name: 'currency',
            label: 'Currency',
            type: 'radio',
            required: true,
            options: [
                { label: 'INR', value: 'INR' },
                { label: 'USD', value: 'USD' },
            ],
        },
    ],
};
