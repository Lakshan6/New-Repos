// Chart Data
export const incomeExpenseData = {
    labels: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
    datasets: [
        {
            label: 'Revenue',
            data: [120, 140, 135, 160, 150, 155, 165, 170, 168, 180, 190, 200],
            borderColor: '#6366f1',
            backgroundColor: 'rgba(99,102,241,0.1)',
            fill: true,
            tension: 0.4,
        },
        {
            label: 'Operating Expenses',
            data: [90, 100, 98, 115, 110, 112, 120, 125, 123, 130, 135, 140],
            borderColor: '#94a3b8',
            borderDash: [5, 5],
            fill: false,
            tension: 0.4,
        },
    ],
};

// Chart Options
export const chartOptions = {
    maintainAspectRatio: false,
    plugins: {
        legend: {
            position: 'top',
            align: 'end',
            labels: { boxWidth: 8, usePointStyle: true },
        },
    },
    scales: {
        x: { grid: { display: false }, border: { display: false } },
        y: { grid: { color: '#f1f5f9' }, border: { display: false } },
    },
};

// Styles
export const iconBoxStyle = {
    width: '2.5rem',
    height: '2.5rem',
};

export const liquidityBarStyle = { height: '8px' };
export const liquidityFillStyle = { width: '65%' };
export const chartContainerStyle = { height: '350px' };
