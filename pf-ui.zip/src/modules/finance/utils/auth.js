export const getAuthToken = () => localStorage.getItem('authToken') ?? '';

export const getAuthHeaders = () => ({
    Authorization: `Bearer ${getAuthToken()}`,
});
