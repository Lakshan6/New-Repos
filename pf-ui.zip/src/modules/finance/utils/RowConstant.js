import useGetDoucs1 from '@modules/finance/hooks/GL/UseGetDoucs';
import { useMemo } from 'react';
import { getParsedLocalStorageItem } from '@shared/utils/common';
const userDetails = getParsedLocalStorageItem('userDetails', {});
const UUID = (userDetails.userInfo || userDetails)?.uuid || '';


const Rows = ({ companyCode, enabled = true }) => {
    const { doucs, loading, isError, error } = useGetDoucs1({
        enabled: enabled,
        uuid: UUID,
        companyCode,
    });

    const rows = useMemo(() => {
        if (!doucs) return [];

        if (Array.isArray(doucs)) {
            return doucs.map((item) => ({
                glId: item.glId,
                journalEntryNo: item.doucId,
                documentNo: item.doucstype,
                postingDate: item.postingDate,
                status: item.status,
                referenceNo: item.referenceDoc || "-",
                amountD: item.tdebit,
                amountC:item.tcredit
            }));
        }

        return [
            {
                glId: doucs.glId,
                journalEntryNo: doucs.doucId,
                documentNo: doucs.doucstype,
                postingDate: doucs.postingDate,
                status: doucs.status,
                referenceNo: doucs.referenceNo,
                debitA: doucs.amountD,
                creditA:doucs.amountC,
            },
        ];
    }, [doucs]);
 
    
    return {
        rows,
        loading,
        isError,
        error,
    };
};

export default Rows;
