export const showSuccess = (toastRef, message) => {
    toastRef.current?.show({
        severity: 'success',
        summary: 'Success',
        detail: message,
    });
};

export const showError = (toastRef, message) => {
    toastRef.current?.show({
        severity: 'error',
        summary: 'Error',
        detail: message,
    });
};

export const showWarn = (toastRef, message) => {
    toastRef.current?.show({
        severity: 'warn',
        summary: 'Warning',
        detail: message,
    });
};
