export const mapCOAResponseToTree = (coaList = []) => {
    const nodeMap = {};
    const roots = [];

    coaList.forEach((item) => {
        nodeMap[item.glId] = {
            key: item.glId,
            label: `${item.glId} - ${item.glName}`,
            code: item.glId,
            name: item.glName,
            isGroup: item.isGroup === 'Y',
            parentGlId: item.parentGlId,
            glType: item.glType,
            ledgerType: item.accountGroup,
            reportType: item.reportType,
            accountGroup: item.accountGroup,
            coaId: item.coaId,
            children: [],
        };
        // console.log('API item:', item);
    });

    coaList.forEach((item) => {
        if (item.parentGlId) {
            nodeMap[item.parentGlId]?.children.push(nodeMap[item.glId]);
        } else {
            roots.push(nodeMap[item.glId]);
        }
    });

    return roots;
};
