
export const JOURNAL_TYPES = [
    { label: 'Journal Entry', value: 'journal_entry' },
    { label: 'Inter Company Journal Entry', value: 'inter_company_journal_entry' },
    { label: 'Bank Entry', value: 'bank_entry' },
    { label: 'Cash Entry', value: 'cash_entry' },
    //   { label: "Credit Card Entry", value: "credit_card_entry" },
    { label: 'Debit Note', value: 'debit_note' },
    { label: 'Credit Note', value: 'credit_note' },
    //  { label: "Contra Entry", value: "contra_entry" },
    // { label: "Excise Entry", value: "excise_entry" },
    // { label: "Write Off Entry", value: "write_off_entry" },
    { label: 'Opening Entry', value: 'opening_entry' },
    // { label: "Depreciation Entry", value: "depreciation_entry" },
    // { label: "Exchange Rate Revaluation", value: "exchange_rate_revaluation" },
    // { label: "Exchange Gain Or Loss", value: "exchange_gain_or_loss" },
    // { label: "Deferred Revenue", value: "deferred_revenue" },
    // { label: "Deferred Expense", value: "deferred_expense" }
];
export const JOURNAL_SERIES = [
    { label: 'JV (Year-wise)', value: 'JV-.YYYY-.#####' },
    { label: 'Opening Entry', value: 'OPEN-JV-.YYYY-.###' },
];
export const COMPANIES = [
    {
        label: 'HAL',
        value: '1000',
    },
    {
        label: 'BDL',
        value: '1000',
    },
    {
        label: 'BPCL',
        value: '1000',
    },
];

export const ACCOUNT = [
    { label: '', values: '' },
    { label: '', values: '' },
];
