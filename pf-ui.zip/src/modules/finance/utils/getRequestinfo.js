export const getRequestInfo = () => {
    const authToken = localStorage.getItem('authToken');
    const userDetails = JSON.parse(localStorage.getItem('userDetails') || '{}');
    const tenant2roleMap = JSON.parse(localStorage.getItem('tenant2roleMap') || '{}');

    return {
        authToken,
        userInfo: {
            userDetails: userDetails.userInfo || userDetails,
            tenant2roleMap,
        },
    };
};
