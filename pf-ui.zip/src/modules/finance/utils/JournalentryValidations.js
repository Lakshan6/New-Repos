export const validateJournalEntry = ({ entryType, seriestype, companytype, date, totals }) => {
    const errors = {};

    if (!entryType) {
        errors.entryType = 'Entry Type is required';
    }

    if (!seriestype) {
        errors.seriestype = 'Series is required';
    }

    if (!companytype) {
        errors.companytype = 'Company is required';
    }

    if (!date) {
        errors.date = 'Posting Date is required';
    }
    if (totals.totalDebit == 0 && totals.totalCredit == 0) {
        errors.totals = 'Account feild is Manditory';
    }

    if (totals.totalDebit !== totals.totalCredit) {
        errors.balance = 'Debit and Credit must be equal';
    }

    return errors;
};
