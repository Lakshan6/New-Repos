export const BREADCRUMB_ROUTE_CONFIG = {
 
    accounts: { label: 'Account Detail', icon: '📄' },
    vouchers: { label: 'Vouchers', icon: '🧾' },
    preview: { label: 'Voucher Detail', icon: '🔍' }, // ← fallback only
    createJournal: { label: 'Create Journal', icon: '✏️' },
};
