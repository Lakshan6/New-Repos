import { useMemo } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import { BREADCRUMB_ROUTE_CONFIG } from '../utils/breadcrumbRoutes';

const HOME_CRUMB = {
    label: 'Home',
    icon: '🏠',
    path: '/web/landing/finance/general-ledger',
    state: null,
};

const useBreadcrumb = () => {
    const { pathname, state } = useLocation();
    const navigate = useNavigate();

    const breadcrumbs = useMemo(() => {
        const allSegments = pathname.split('/').filter(Boolean);
        const queryString = pathname.split('?')[1] || '';
        const crumbs = [];

        allSegments.forEach((seg, i) => {
            if (!BREADCRUMB_ROUTE_CONFIG[seg]) return;

            const path = '/' + allSegments.slice(0, i + 1).join('/');
            const config = BREADCRUMB_ROUTE_CONFIG[seg];

            // accounts segment
            if (seg === 'accounts') {
                crumbs.push({
                    label: state?.row?.name || 'Account Detail',
                    icon: config.icon,
                    path,
                    state: state || null,
                });
                return;
            }

            // preview segment
            if (seg === 'preview') {
                const params = new URLSearchParams(queryString);
                const docId = params.get('doucs') || '';
                const label = docId ? `Voucher: ${decodeURIComponent(docId)}` : 'Voucher Detail';

                crumbs.push({
                    label,
                    icon: config.icon,
                    path: path + (queryString ? `?${queryString}` : ''),
                    state: state || null,
                });
                return;
            }

            crumbs.push({
                label: config.label,
                icon: config.icon,
                path,
                state: null,
            });
        });

        return [HOME_CRUMB, ...crumbs];
    }, [pathname, state]);

    const popToIndex = (index) => {
        const crumb = breadcrumbs[index];
        navigate(crumb.path, { state: crumb.state });
    };

    return { breadcrumbs, popToIndex };
};

export default useBreadcrumb;
