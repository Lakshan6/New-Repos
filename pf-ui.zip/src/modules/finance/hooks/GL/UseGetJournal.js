import { useReadApi } from '@shared/hooks';
import { useMemo } from 'react';

export function useGetJournal({ documentId, enabled = true } = {}) {
    const authToken = localStorage.getItem('authToken') ?? '';

    const { data, isLoading, isError, error } = useReadApi({
        service: 'finance',
        endpoint: `/coa/document/${documentId}`,
        method: 'GET',
        headers: {
            Authorization: `Bearer ${authToken}`,
        },
        enabled: enabled && !!documentId,
    });

    const isSuccess = !isLoading && !isError && !!data;
    const header = useMemo(() => {
        if (!isSuccess) return null;

        const {
            docId,
            companyCode,
            fiscalYear,
            docType,
            postingDate,
            documentDate,
            postingPeriod,
            referenceDoc,
            headerText,
            reversedDocumentNo,
        } = data;

        return {
            docId,
            companyCode,
            fiscalYear,
            docType,
            postingDate,
            documentDate,
            postingPeriod,
            referenceDoc,
            headerText,
            reversedDocumentNo,
        };
    }, [data, isSuccess]);

    
    const Inlines = useMemo(() => {
        if (!isSuccess || !Array.isArray(data?.lineItems)) return [];

        return data.lineItems.map((item) => ({
            lineId: item.lineId,
            glId: item.glId,
            amount: item.amount,
            debitCredit: item.debitCredit,
            lineText: item.lineText,
        }));
    }, [data, isSuccess]);

    return {
        header,
        Inlines,
        loading: isLoading,
        isLoading,
        isError,
        error,
        isSuccess,
    };
}

export default useGetJournal;
