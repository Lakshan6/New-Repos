import { useMutationApi } from '@shared/hooks/useMutationApi';

const useSubmitJournal = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const mutation = useMutationApi({
        service: 'finance',
        endpoint: '/coa/transaction/_post',
        method: 'POST',
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    return mutation;
};

export default useSubmitJournal;
