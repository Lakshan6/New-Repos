import { useMutationApi } from '@shared/hooks/useMutationApi';

const usePostReversal = () => {
    const authToken = localStorage.getItem('authToken') ?? '';

    const mutation = useMutationApi({
        service: 'finance',
        endpoint: '/coa/transcation/_reservalPost',
        method: 'POST',
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
    });

    return mutation;
};

export default usePostReversal;
