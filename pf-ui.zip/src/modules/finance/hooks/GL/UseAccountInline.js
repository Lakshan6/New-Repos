import { useCallback, useMemo, useEffect } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getParsedLocalStorageItem } from '@shared/utils/common';

export function useGetGlLineItems({ enabled = true, glId, companyCode } = {}) {
    const { data, mutate, isPending, isError, error, reset } = useMutationApi({
        service: 'finance',
        endpoint: '/coa/account/line-items',
        method: 'POST',
        useGateway: true,
    });

    const fetchLineItems = useCallback(() => {
        const userDetails = getParsedLocalStorageItem('userDetails', {});
        const uuid = (userDetails.userInfo || userDetails)?.uuid || '';

        const requestBody = {
            glId,
            companyCode,
            requestInfo: {
                userInfo: {
                    userDetails: { uuid },
                },
            },
        };

        mutate(requestBody);
    }, [mutate, companyCode, glId]);

    /* ---------- API CALL ---------- */
    useEffect(() => {
        if (!enabled || !glId) return;

        reset();
        fetchLineItems();
    }, [enabled, glId, companyCode, fetchLineItems, reset]);

    /* ---------- RAW DATA ---------- */
    const rawLineItems = useMemo(() => {
        if (!data) return [];
        if (Array.isArray(data)) return data;
        return [];
    }, [data]);

    /* ---------- RUNNING BALANCE ---------- */
    const lineItems = useMemo(() => {
        let running = 0;

        return rawLineItems.map((item) => {
            const amount = Number(item.amount || 0);
            const isDebit = item.debitCredit?.toUpperCase() === 'D';

            running = isDebit ? running + amount : running - amount;

            return {
                ...item,
                debit: isDebit ? amount : null,
                credit: !isDebit ? amount : null,
                runningBalance: running,
            };
        });
    }, [rawLineItems]);

    /* ---------- TOTALS ---------- */
    const totalDebit = useMemo(
        () => lineItems.reduce((sum, item) => sum + (item.debit ?? 0), 0),
        [lineItems],
    );

    const totalCredit = useMemo(
        () => lineItems.reduce((sum, item) => sum + (item.credit ?? 0), 0),
        [lineItems],
    );

    const closingBalance = totalDebit - totalCredit;

    /* ---------- DROPDOWN OPTIONS ---------- */
    const costCenterOptions = useMemo(
        () => [...new Set(lineItems.map((i) => i.costCenter).filter(Boolean))],
        [lineItems],
    );

    const docTypeOptions = useMemo(
        () => [...new Set(lineItems.map((i) => i.docType).filter(Boolean))],
        [lineItems],
    );

    return {
        lineItems,
        totalDebit,
        totalCredit,
        closingBalance,
        docTypeOptions,
        costCenterOptions,
        loading: isPending,
        error,
        isError,
    };
}

export default useGetGlLineItems;
