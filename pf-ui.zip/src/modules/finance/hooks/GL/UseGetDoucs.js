import { useMutationApi } from '@shared/hooks';
import { useState, useEffect } from 'react';

export function useGetDoucs({ enabled = true, uuid, companyCode } = {}) {
    const authToken = localStorage.getItem('authToken') ?? '';

    const [doucs, setDoucs] = useState([]);

    const { mutate, isPending, isError, error } = useMutationApi({
        service: 'finance',
        endpoint: '/coa/documents/_search',
        method: 'POST',
        headers: {
            Authorization: `Bearer ${authToken}`,
            'Content-Type': 'application/json',
        },
        options: {
            onSuccess: (data) => {
                if (!data) return setDoucs([]);
                if (Array.isArray(data)) return setDoucs(data);
                setDoucs([data]);
            },
            onError: () => {
                setDoucs([]);
            },
        },
    });

    // ✅ Fires fresh API call every time companyCode or uuid changes
    useEffect(() => {
        if (!enabled || !uuid || !companyCode) return;

        mutate({
            requestInfo: {
                userInfo: {
                    userDetails: { uuid },
                },
            },
            company: {
                companyCode,
            },
        });
    }, [uuid, companyCode, enabled,mutate]); // ✅ refire on every company change

    return {
        doucs,
        loading: isPending,
        error,
        isError,
    };
}

export default useGetDoucs;
