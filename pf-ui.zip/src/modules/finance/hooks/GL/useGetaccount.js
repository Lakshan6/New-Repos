import { useReadApi } from '@shared/hooks';
import { useMemo } from 'react';
import { getReqInfoObj } from '@shared/utils/common';

export function useGetaccounts({ enabled = true, uuid, coaId } = {}) {
    const authToken = localStorage.getItem('authToken') ?? '';

    const requestBody = {
        requestInfo: {
            ...getReqInfoObj,
        },
        coaId,
    };

    const { data, isLoading, isError, error } = useReadApi({
        service: 'finance',
        endpoint: '/coa/_search',
        method: 'POST',
        // headers: {
        //     Authorization: `Bearer ${authToken}`,
        //     'Content-Type': 'application/json',
        // },
        body: requestBody,
        enabled: enabled && !!uuid && !!coaId,
    });

    // 1️⃣ Normalize accounts FIRST
    const accounts = useMemo(() => {
        if (!Array.isArray(data)) return [];

        return data
            .filter((item) => item.isGroup === 'N')
            .map(({ glId, glName }) => ({
                glId,
                glName,
            }));
    }, [data]);
    //   console.log(accounts);

    const glNameToIdMap = useMemo(() => {
        return accounts.reduce((map, acc) => {
            map[acc.glName] = acc.glId;
            return map;
        }, {});
    }, [accounts]);

    return {
        accounts,
        glNameToIdMap, // ✅ correct map
        loading: isLoading,
        error,
        isError,
    };
}

export default useGetaccounts;
