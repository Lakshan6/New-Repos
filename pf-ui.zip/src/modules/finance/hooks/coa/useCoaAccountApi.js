import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getParsedLocalStorageItem } from '@shared/utils/common';
import { getAuthHeaders } from '../../utils/auth';
import { useQueryClient } from '@tanstack/react-query';

// ✅ same pattern as useListCOA and useSearchCOA which are confirmed working
const buildRequestInfo = () => {
    return {
        authToken: localStorage.getItem('authToken') ?? '',
    };
};

export const useCoaAccountApi = () => {
    const queryClient = useQueryClient();

    const invalidate = useCallback(() => {
        queryClient.invalidateQueries({ queryKey: ['finance', '/coa/account/_search'] });
        queryClient.invalidateQueries({ queryKey: ['finance', '/coa/_search'] });
    }, [queryClient]);

    const createMutation = useMutationApi({
        service: 'finance',
        endpoint: '/coa/account/_create',
        method: 'POST',
        useGateway: true,
        options: { onSuccess: invalidate },
    });

    const updateMutation = useMutationApi({
        service: 'finance',
        endpoint: '/coa/account/_update',
        method: 'POST',
        useGateway: true,
        options: { onSuccess: invalidate },
    });

    const deleteMutation = useMutationApi({
        service: 'finance',
        endpoint: '/coa/account/_delete',
        method: 'POST',
        useGateway: true,
        options: { onSuccess: invalidate },
    });

    const fetchMutation = useMutationApi({
        service: 'finance',
        endpoint: '/coa/company/_accounts',
        method: 'POST',
        useGateway: true,
    });

    const createAccount = useCallback(
        (payload, options) =>
            createMutation.mutate({ requestInfo: buildRequestInfo(), ...payload }, options),
        [createMutation],
    );

    const updateAccount = useCallback(
        (payload, options) =>
            updateMutation.mutate({ requestInfo: buildRequestInfo(), ...payload }, options),
        [updateMutation],
    );

    const deleteAccount = useCallback(
        (payload, options) =>
            deleteMutation.mutate({ requestInfo: buildRequestInfo(), ...payload }, options),
        [deleteMutation],
    );

    const fetchAccounts = useCallback(
        async ({ companyCode } = {}) =>
            await fetchMutation.mutateAsync({
                requestInfo: buildRequestInfo(),
                companyCode,
            }),
        [fetchMutation],
    );

    return {
        createAccount,
        updateAccount,
        deleteAccount,
        fetchAccounts,
        isCreating: createMutation.isPending,
        isUpdating: updateMutation.isPending,
        isDeleting: deleteMutation.isPending,
        isFetching: fetchMutation.isPending,
    };
};
