import { useCallback, useEffect, useRef } from 'react';
import { useAtom } from 'jotai';
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj, getParsedLocalStorageItem } from '@shared/utils/common';
import { getAuthHeaders } from '../../utils/auth';
import { coaTreeAtom, selectedCompanyAtom } from '../../store/atoms';
import { mapCOAResponseToTree } from '../../utils/coaTreeMapper';

export const useListCOA = () => {
    const requestInfo = getReqInfoObj();
    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'finance',
        endpoint: '/coa/_list',
        method: 'POST',
        useGateway: true,
        headers: getAuthHeaders(),
    });

    const fetchAllCoa = useCallback(async () => {
        return mutateAsync({
            requestInfo: {
                authToken: localStorage.getItem('authToken') ?? '',
            },
        });
    }, [mutateAsync]);

    return { fetchAllCoa, isPending, isError, error, data };
};

export const useSearchCOA = () => {
    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'finance',
        endpoint: '/coa/_search',
        method: 'POST',
        useGateway: true,
        // headers: getAuthHeaders(),
    });
    const fetchCOAById = useCallback(
        (coaId) =>
            mutateAsync({
                requestInfo: {
                    authToken: localStorage.getItem('authToken') ?? '',
                },
                coaId,
            }),
        [mutateAsync],
    );

    return { fetchCOAById, isPending, isError, error, data };
};

export const useDeleteCOA = () => {
    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'finance',
        endpoint: '/coa/_delete',
        method: 'POST',
        useGateway: true,
    });

    const deleteCOA = async (coaId) => {
        return await mutateAsync({ ...getReqInfoObj(), coaId });
    };

    return { deleteCOA, isPending, isError, error, data };
};

export const useCreateCOA = () => {
    const { mutateAsync, isPending, isError, error } = useMutationApi({
        service: 'finance',
        endpoint: '/coa/_import',
        method: 'POST',
        useGateway: true,
    });

    const createCOA = useCallback(
        async (formData) => {
            const requestInfo = getReqInfoObj();

            if (formData instanceof FormData) {
                formData.append('requestInfo', JSON.stringify(requestInfo));

                return mutateAsync(formData, {
                    headers: {
                        Authorization: `Bearer ${requestInfo.authToken}`,
                    },
                });
            }

            return mutateAsync({
                requestInfo,
                ...formData,
            });
        },
        [mutateAsync],
    );

    return { createCOA, isPending, isError, error };
};

export const useExportCOA = (coaId) => {
    const { mutateAsync, isPending, isError, error } = useMutationApi({
        service: 'finance',
        endpoint: `/coa/_export?coaId=${coaId}`,
        method: 'GET',
        useGateway: true,
        responseType: 'blob',
        headers: getAuthHeaders(),
    });

    const exportCOA = useCallback(async () => {
        const response = await mutateAsync();
        const blob = new Blob([response], {
            type: 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
        });
        const url = URL.createObjectURL(blob);
        const link = document.createElement('a');
        link.href = url;
        link.download = `COA_${coaId ?? 'UNKNOWN'}.xlsx`;
        link.click();
        URL.revokeObjectURL(url);
    }, [mutateAsync, coaId]);

    return { exportCOA, isPending, isError, error };
};

export const useCOAData = () => {
    const [selectedCompany, setSelectedCompany] = useAtom(selectedCompanyAtom);
    const [, setCoaTree] = useAtom(coaTreeAtom);
    const { fetchCOAById } = useSearchCOA();

    const lastLoadedCoaIdRef = useRef(null);
    const isLoadingRef = useRef(false);

    const loadCOA = useCallback(
        async (company) => {
            const coaId = company?.coaId;
            if (!coaId) return;
            if (isLoadingRef.current) return;

            try {
                isLoadingRef.current = true;
                const response = await fetchCOAById(coaId);
                const coaList =
                    response?.chartOfAccounts ?? response?.coa ?? response?.data ?? response;
                setCoaTree(mapCOAResponseToTree(coaList));
                lastLoadedCoaIdRef.current = coaId;
            } finally {
                isLoadingRef.current = false;
            }
        },
        [fetchCOAById, setCoaTree],
    );

    useEffect(() => {
        if (selectedCompany) loadCOA(selectedCompany);
    }, [selectedCompany, loadCOA]);

    const changeCompany = useCallback(
        (company) => setSelectedCompany(company),
        [setSelectedCompany],
    );

    // ✅ resets the ref so loadCOA bypasses the "already loaded" guard and refetches
    const refreshCOA = useCallback(() => {
        lastLoadedCoaIdRef.current = null;
        loadCOA(selectedCompany);
    }, [selectedCompany, loadCOA]);

    return { changeCompany, refreshCOA };
};
