import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';

export const useCreateCompany = () => {
    //const authToken = localStorage.getItem('authToken') ?? '';
    const { mutateAsync, isPending, isError, error } = useMutationApi({
        service: 'finance',
        endpoint: '/masterdata/company/_create',
        method: 'POST',
        useGateway: true,
    });
    const createCompany = async (company) => {
        const requestInfo = getReqInfoObj();

        const requestBody = {
            ...requestInfo,
            company,
        };
        return await mutateAsync(requestBody);
    };

    return {
        createCompany,
        isPending,
        isError,
        error,
    };
};
