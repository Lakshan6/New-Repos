import { useCallback } from 'react';
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils/common';
import { getAuthHeaders } from '../../utils/auth';

export const useSearchCompany = () => {
    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'finance',
        endpoint: '/masterdata/company/_all',
        method: 'GET',
        useGateway: true,
        headers: getAuthHeaders(),
    });

    const fetchAllCompanies = useCallback(async () => {
        return await mutateAsync();
    }, [mutateAsync]);

    return { fetchAllCompanies, isPending, isError, error, data };
};

export const useUpdateCompany = () => {
    const { mutateAsync, isPending, isError, error } = useMutationApi({
        service: 'finance',
        endpoint: '/masterdata/company/_update',
        method: 'POST',
        useGateway: true,
    });

    const updateCompany = async (company) => {
        return await mutateAsync({ ...getReqInfoObj(), company });
    };

    return { updateCompany, isPending, isError, error };
};

export const useDeleteCompany = () => {
    const { mutateAsync, isPending, isError, error, data } = useMutationApi({
        service: 'finance',
        endpoint: '/masterdata/company/_delete',
        method: 'POST',
        useGateway: true,
    });

    const deleteCompany = async (companyCode) => {
        return await mutateAsync({ ...getReqInfoObj(), companyCode });
    };

    return { deleteCompany, isPending, isError, error, data };
};
