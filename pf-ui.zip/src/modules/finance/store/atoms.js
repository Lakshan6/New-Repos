import { atom } from 'jotai';

export const coaResponseAtom = atom(null);
export const coaTreeAtom = atom([]);
export const selectedCompanyAtom = atom(null);
export const translationsAtom = atom({});
export const coaExpandedKeysAtom = atom({});
export const addAccountContextAtom = atom(null);
export const selectedCoaAtom = atom(null);
