import { useState, useCallback, useRef, useMemo } from 'react';
import { useAtom, useAtomValue } from 'jotai';

import { useExportCOA, useCreateCOA, useCOAData, useDeleteCOA } from '../../hooks/coa/useCOAApi';
import { useCreateCompany } from '../../hooks/company/useCreateCompany';
import { useUpdateCompany, useDeleteCompany } from '../../hooks/company/useCompanyApi';

import { selectedCompanyAtom, selectedCoaAtom } from '../../store/atoms';

import CompanySelector from '../../components/CompanySelector';
import CoaList from '../../components/CoaList';
import CoaActions from '../../components/CoaActions';
import FieldWrapper from '../../components/FieldWrapper';
import ToggleView from '../../components/ToggleView';
import TreeView from '../../components/TreeView';
import TableView from '../../components/TableView';
import AddAccountDialog from '../../components/AddAccountDialog';
import CreateCoaDialog from '../../components/CreateCoaDialog';
import CustomDialog from '../../components/customComponents/CustomDialog';
import CustomSnackbar from '../../components/customComponents/CustomSnackbar';
import CompanyFormDialog from '../../components/CompanyFormDialog';

import { showSuccess, showError } from '../../utils/snackbarUtils';
import { createCompanyFormDefinition } from '../../utils/createCompanyForm';
import { Button } from 'primereact/button';

const ChartOfAccounts = () => {
    const [selectedCompany] = useAtom(selectedCompanyAtom);
    const selectedCoaId = useAtomValue(selectedCoaAtom);
    const [selectedCoa] = useAtom(selectedCoaAtom);

    const { changeCompany, changeCoa } = useCOAData();

    const effectiveCoaId = selectedCompany?.coaId || selectedCoaId;

    const { exportCOA } = useExportCOA(effectiveCoaId);
    const { createCOA, isPending: isCreating } = useCreateCOA();
    const { createCompany, isPending: isCompanyCreating } = useCreateCompany();
    const { updateCompany, isPending: isCompanyUpdating } = useUpdateCompany();
    const { deleteCompany, isPending: isDeleting } = useDeleteCompany();
    const { deleteCOA: deleteCoa, isPending: isCoaDeleting } = useDeleteCOA();

    const [view, setView] = useState('TREE');
    const [showCompanyForm, setShowCompanyForm] = useState(false);
    const [formMode, setFormMode] = useState('CREATE');
    const [showCreateDialog, setShowCreateDialog] = useState(false);
    const [showDeleteDialog, setShowDeleteDialog] = useState(false);
    const [showDeleteCoaDialog, setShowDeleteCoaDialog] = useState(false);
    const [companyReloadKey, setCompanyReloadKey] = useState(0);
    const [coaReloadKey, setCoaReloadKey] = useState(0);
    const toastRef = useRef(null);
    const [coaOptions, setCoaOptions] = useState([]);

    const openDeleteDialog = useCallback(() => {
        setShowDeleteDialog(true);
    }, []);

    const closeDeleteDialog = useCallback(() => {
        setShowDeleteDialog(false);
    }, []);
    const openDeleteCoaDialog = useCallback(() => {
        setShowDeleteCoaDialog(true);
    }, []);

    const closeDeleteCoaDialog = useCallback(() => {
        setShowDeleteCoaDialog(false);
    }, []);

    const handleDelete = useCallback(async () => {
        try {
            await deleteCompany(selectedCompany.companyCode);
            setCompanyReloadKey((prev) => prev + 1);
            showSuccess(toastRef, 'Company deleted successfully');
        } catch (err) {
            showError(toastRef, `Failed to delete company: ${err.message}`);
        }
        setShowDeleteDialog(false);
    }, [deleteCompany, selectedCompany]);

    const handleDeleteCoa = useCallback(async () => {
        try {
            const coaIdToDelete = selectedCoa?.coaId || selectedCoa?.id || effectiveCoaId;
            if (!coaIdToDelete) {
                showError(toastRef, 'No CoA selected to delete');
                setShowDeleteCoaDialog(false);
                return;
            }
            console.debug('Calling deleteCoa with id:', coaIdToDelete);
            await deleteCoa(coaIdToDelete);
            setCoaReloadKey((prev) => prev + 1);
            showSuccess(toastRef, 'CoA deleted successfully');
        } catch (err) {
            showError(toastRef, `Failed to delete CoA: ${err?.message || 'Unknown error'}`);
        } finally {
            setShowDeleteCoaDialog(false);
        }
    }, [deleteCoa, selectedCoa, effectiveCoaId]);

    const handleCreateUpload = useCallback(
        async ({ file, coaId, coaName, description }) => {
            const formData = new FormData();
            formData.append('file', file);
            formData.append('coaId', coaId);
            formData.append('coaName', coaName);
            formData.append('description', description);

            await createCOA(formData);
            setShowCreateDialog(false);
            setCoaReloadKey((prev) => prev + 1);
            showSuccess(toastRef, 'Chart of Accounts created successfully');
        },
        [createCOA],
    );

    const openCreateDialog = useCallback(() => {
        setShowCreateDialog(true);
    }, []);

    const closeCreateDialog = useCallback(() => {
        setShowCreateDialog(false);
    }, []);

    const openCreateCompanyDialog = useCallback(() => {
        setFormMode('CREATE');
        setShowCompanyForm(true);
    }, []);

    const openUpdateCompany = useCallback(() => {
        if (!selectedCompany) return;
        setFormMode('UPDATE');
        setShowCompanyForm(true);
    }, [selectedCompany]);

    const handleCompanySubmit = useCallback(
        async (formData) => {
            try {
                if (formMode === 'CREATE') {
                    await createCompany(formData);
                    showSuccess(toastRef, 'Company created successfully');
                } else {
                    await updateCompany({
                        ...formData,
                        companyCode: selectedCompany.companyCode,
                    });
                    showSuccess(toastRef, 'Company updated successfully');
                }
                setCompanyReloadKey((prev) => prev + 1);
            } catch (err) {
                showError(
                    toastRef,
                    `Failed to ${formMode === 'CREATE' ? 'create' : 'update'} company: ${
                        err?.message || 'Unknown error'
                    }`,
                );
            } finally {
                setShowCompanyForm(false);
            }
        },
        [formMode, createCompany, updateCompany, selectedCompany],
    );

    const handleCloseCompanyForm = useCallback(() => {
        setShowCompanyForm(false);
    }, []);

    const formOptions = useMemo(
        () => ({
            coaOptions,
        }),
        [coaOptions],
    );

    return (
        <div>
            <h2>Chart of Accounts</h2>
            <CustomSnackbar ref={toastRef} />

            {/* CoA selection + actions */}
            <div className="flex gap-3 align-items-end mb-3">
                <FieldWrapper label="Select Chart of Accounts">
                    <CoaList
                        onChange={changeCoa}
                        reloadKey={coaReloadKey}
                        onOptionsLoaded={setCoaOptions}
                    />
                </FieldWrapper>

                <FieldWrapper>
                    <CoaActions
                        onExport={exportCOA}
                        onCreate={openCreateDialog}
                        onDelete={openDeleteCoaDialog}
                        exportDisabled={!effectiveCoaId}
                    />
                    <CustomDialog
                        visible={showDeleteCoaDialog}
                        header="Delete CoA"
                        message={
                            <>
                                Are you sure you want to delete CoA
                                <strong> {selectedCoa?.name}</strong>?
                                <br />
                                This action cannot be undone.
                            </>
                        }
                        onHide={closeDeleteCoaDialog}
                        onAction={handleDeleteCoa}
                        actionLabel="Delete"
                        actionSeverity="danger"
                        loading={isCoaDeleting}
                    />

                    <CreateCoaDialog
                        visible={showCreateDialog}
                        onHide={closeCreateDialog}
                        onUpload={handleCreateUpload}
                        loading={isCreating}
                    />
                </FieldWrapper>
            </div>

            <div className="flex gap-3 align-items-end mb-3">
                <FieldWrapper label="Select Company">
                    <CompanySelector onChange={changeCompany} reloadKey={companyReloadKey} />
                </FieldWrapper>
                <FieldWrapper>
                    <ToggleView value={view} onChange={setView} />
                </FieldWrapper>
                <FieldWrapper>
                    <Button
                        label="Create"
                        severity="primary"
                        raised
                        className="p-button-sm"
                        onClick={openCreateCompanyDialog}
                    />
                    <CompanyFormDialog
                        visible={showCompanyForm}
                        onHide={handleCloseCompanyForm}
                        onSubmit={handleCompanySubmit}
                        loading={isCompanyCreating || isCompanyUpdating}
                        mode={formMode}
                        formDefinition={createCompanyFormDefinition}
                        initialValues={formMode === 'UPDATE' ? selectedCompany : null}
                        formOptions={formOptions}
                    />
                </FieldWrapper>
                <FieldWrapper>
                    <Button
                        label="Update"
                        className="p-button-sm"
                        severity="primary"
                        raised
                        onClick={openUpdateCompany}
                    />
                </FieldWrapper>
                <FieldWrapper>
                    <Button
                        label="Delete"
                        className="p-button-sm"
                        severity="danger"
                        onClick={openDeleteDialog}
                    />
                    <CustomDialog
                        visible={showDeleteDialog}
                        header="Delete Company"
                        message={
                            <>
                                Are you sure you want to delete Company
                                <strong> {selectedCompany?.name}</strong>?
                                <br />
                                This action cannot be undone.
                            </>
                        }
                        onHide={closeDeleteDialog}
                        onAction={handleDelete}
                        actionLabel="Delete"
                        actionSeverity="danger"
                        loading={isDeleting}
                    />
                </FieldWrapper>
            </div>

            {/* Tree / Table */}
            {view === 'TREE' ? <TreeView /> : <TableView />}
            <AddAccountDialog />
        </div>
    );
};

export default ChartOfAccounts;
