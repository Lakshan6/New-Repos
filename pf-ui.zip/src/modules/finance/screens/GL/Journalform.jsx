import { Card } from 'primereact/card';
import { InputText } from 'primereact/inputtext';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { Toast } from 'primereact/toast';

import { JOURNAL_SERIES, JOURNAL_TYPES } from '../../utils/JournalTypes';
import '../../styles/Jscreen.scss';
import JournalTable from '../../components/generalLedger/JournalTable';
import { validateJournalEntry } from '../../utils/JournalentryValidations';
import useGetaccount from '../../hooks/GL//useGetaccount';
import useSubmitJournal from '../../hooks/GL/useSubmitJournal';

import { useRef, useState, useCallback, useMemo, useEffect } from 'react';

import { useSearchCompany } from '../../hooks/company/useCompanyApi';
import { getParsedLocalStorageItem } from '@shared/utils/common';
const userDetails = getParsedLocalStorageItem('userDetails', {});
const UUID = (userDetails.userInfo || userDetails)?.uuid || '';

const JournalEntry = () => {
    const toast = useRef(null);

    /* -------------------- FORM STATE -------------------- */
    const [date, setDate] = useState(null);
    const [entryType, setEntryType] = useState(null);
    const [seriestype, setSeriesType] = useState(null);
    const [companytype, setCompany] = useState(null);
    const [refDate, setRefDate] = useState(null);
    const [refNumber, setRefNumber] = useState('');
    const [userremark, setRemark] = useState('');

    const [totals, setTotals] = useState({ totalDebit: 0, totalCredit: 0 });
    const [rows, setRows] = useState([]);

    const [showValidationDialog, setShowValidationDialog] = useState(false);
    const [validationMessages, setValidationMessages] = useState([]);
    const [resetTableKey, setResetTableKey] = useState(0);

    /* -------------------- DATA HOOKS -------------------- */

    const { fetchAllCompanies } = useSearchCompany();

    const [companies, setCompanies] = useState([]);
    const [companyCoaMap, setCompanyCoaMap] = useState({});

    useEffect(() => {
        const loadCompanies = async () => {
            try {
                const response = await fetchAllCompanies();

                // Dropdown mapping
                const mapped = (response || []).map((company) => ({
                    label: company.name,
                    value: company.companyCode,
                }));

                // companyCode → coaId map
                const coaMap = (response || []).reduce((acc, company) => {
                    acc[company.companyCode] = company.coaId;
                    return acc;
                }, {});

                setCompanies(mapped);
                setCompanyCoaMap(coaMap);
            } catch (err) {
                console.error(err);
            }
        };

        loadCompanies();
    }, [fetchAllCompanies]);
    const { glNameToIdMap } = useGetaccount({
        uuid: { UUID },
        coaId: companyCoaMap[companytype],
        enabled: true,
    });

    const { mutateAsync: submitJournal, isLoading } = useSubmitJournal();
    const isBalanced = totals.totalDebit === totals.totalCredit && totals.totalDebit > 0;
    const difference = totals.totalDebit - totals.totalCredit;
    /* -------------------- HELPERS -------------------- */
    const buildLineItems = useCallback(() => {
        return rows.map((row) => {
            const glId = glNameToIdMap[row.accountName];

            if (!glId) {
                throw new Error(`GL ID not found for ${row.accountName}`);
            }

            return {
                glId,
                amount: row.debit || row.credit,
                debitCredit: row.debit ? 'D' : 'C',
                lineText: row.accountName,
            };
        });
    }, [rows, glNameToIdMap]);

    const resetForm = useCallback(() => {
        setDate(null);
        setEntryType(null);
        setSeriesType(null);
        setCompany(null);
        setRefDate(null);
        setRefNumber('');
        setRemark('');
        setTotals({ totalDebit: 0, totalCredit: 0 });
    }, []);

    /* -------------------- SUBMIT -------------------- */
    const handleSubmit = useCallback(
        async (e) => {
            e.preventDefault();

            /* 1️⃣ UI validation */
            const validationErrors = validateJournalEntry({
                entryType,
                seriestype,
                companytype,
                date,
                totals,
            });

            if (Object.keys(validationErrors).length > 0) {
                setValidationMessages(Object.values(validationErrors));
                setShowValidationDialog(true);
                return;
            }

            /* 2️⃣ Build line items */
            let lineItems;
            try {
                lineItems = buildLineItems();
            } catch (err) {
                toast.current.show({
                    severity: 'error',
                    summary: 'Account Error',
                    detail: err.message,
                });
                return;
            }

            if (!lineItems.length) {
                toast.current.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'At least one debit and credit entry is required',
                });
                return;
            }

            /* 3️⃣ Build API payload */
            const apiPayload = {
                requestInfo: {
                    userInfo: {
                        userDetails: { uuid: UUID },
                    },
                },
                documentHeader: {
                    companyCode: companytype,
                    fiscalYear: date.getFullYear(),
                    docType: entryType,
                    postingDate: date.toISOString().split('T')[0],
                    documentDate: date.toISOString().split('T')[0],
                    postingPeriod: date.getMonth() + 1,
                    referenceDoc: refNumber,
                    headerText: userremark,
                },
                lineItems,
            };

            /* 4️⃣ Submit */
            try {
                await submitJournal(apiPayload);

                toast.current.show({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Journal Entry posted successfully',
                    life: 3000,
                });

                resetForm();
                setResetTableKey((prev) => prev + 1);
            } catch {
                toast.current.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Failed to post journal entry',
                });
            }
        },
        [
            entryType,
            seriestype,
            companytype,
            date,
            totals,
            refNumber,
            userremark,
            submitJournal,
            resetForm,
            buildLineItems,
        ],
    );
    const handleEntryTypeChange = useCallback((e) => {
        setEntryType(e.value);
    }, []);

    const handleSeriesTypeChange = useCallback((e) => {
        setSeriesType(e.value);
    }, []);

    const handleRefNumberChange = useCallback((e) => {
        setRefNumber(e.target.value);
    }, []);

    const handleCompanyChange = useCallback((e) => {
        setCompany(e.value);
    }, []);

    const handleDateChange = useCallback((e) => {
        setDate(e.value);
    }, []);

    const handleRefDateChange = useCallback((e) => {
        setRefDate(e.value);
    }, []);

    const validationDialogStyle = useMemo(
        () => ({
            width: '30vw',
        }),
        [],
    );

    const handleValidationDialogHide = useCallback(() => {
        setShowValidationDialog(false);
    }, []);

    /* -------------------- RENDER -------------------- */
    return (
        <div className="erp-page-container">
            <form onSubmit={handleSubmit}>
                <Toast ref={toast} />

                {/* 1. DOCUMENT HEADER STRIP */}
                <div className="erp-header-strip flex justify-content-between align-items-center mb-4">
                    <div>
                        <h2 className="m-0 text-900">Journal Entry</h2>
                        <small className="text-800">New Transaction</small>
                    </div>
                    <div className="flex align-items-center gap-3">
                        <div className={`balance-tag ${isBalanced ? 'balanced' : 'unbalanced'}`}>
                            <i
                                className={`pi ${isBalanced ? 'pi-check-circle' : 'pi-exclamation-triangle'} mr-2`}
                            ></i>
                            {isBalanced ? 'Balanced' : 'Out of Balance'}
                        </div>
                        <Button
                            label="Post Entry"
                            icon="pi pi-cloud-upload"
                            type="submit"
                            className="p-button-primary shadow-2"
                            loading={isLoading}
                        />
                    </div>
                </div>

                <div className="grid">
                    {/* 2. PRIMARY DETAILS CARD */}
                    <div className="col-12 lg:col-8">
                        <Card className="erp-section-card h-full">
                            <h5 className="section-title">
                                <i className="pi pi-info-circle mr-2"></i>General Information
                            </h5>
                            <div className="p-fluid grid">
                                <div className="field col-12 md:col-6">
                                    <label className="erp-label-sm" htmlFor="entryType">
                                        Entry Type *
                                    </label>
                                    <Dropdown
                                        value={entryType}
                                        options={JOURNAL_TYPES}
                                        onChange={handleEntryTypeChange}
                                        placeholder="Select Type"
                                    />
                                </div>
                                <div className="field col-12 md:col-6">
                                    <label className="erp-label-sm" htmlFor="date">
                                        Posting Date *
                                    </label>
                                    <Calendar value={date} onChange={handleDateChange} showIcon />
                                </div>
                                <div className="field col-12 md:col-6">
                                    <label className="erp-label-sm" htmlFor="seriestype">
                                        Series *
                                    </label>
                                    <Dropdown
                                        value={seriestype}
                                        options={JOURNAL_SERIES}
                                        onChange={handleSeriesTypeChange}
                                    />
                                </div>
                                <div className="field col-12 md:col-6">
                                    <label className="erp-label-sm" htmlFor="compantype">
                                        Company *
                                    </label>
                                    <Dropdown
                                        value={companytype}
                                        options={companies}
                                        onChange={handleCompanyChange}
                                    />
                                </div>
                            </div>
                        </Card>
                    </div>
                    {/* 3. SIDEBAR / REFERENCE CARD */}
                    <div className="col-12 lg:col-4">
                        <Card className="erp-section-card h-full">
                            <h5 className="section-title">
                                <i className="pi pi-paperclip mr-2"></i>References
                            </h5>
                            <div className="p-fluid">
                                <div className="field">
                                    <label className="erp-label-sm" htmlFor="refNumber">
                                        Reference Number
                                    </label>
                                    <InputText value={refNumber} onChange={handleRefNumberChange} />
                                </div>
                                <div className="field">
                                    <label className="erp-label-sm" htmlFor="refDate">
                                        Reference Date
                                    </label>
                                    <Calendar
                                        value={refDate}
                                        onChange={handleRefDateChange}
                                        showIcon
                                    />
                                </div>
                            </div>
                        </Card>
                    </div>

                    <div className="col-12 mt-3">
                        <Card className="erp-table-card">
                            <div className="flex justify-content-between align-items-center mb-3">
                                <h5 className="section-title m-0">Accounting Lines</h5>
                            </div>
                            <JournalTable
                                onTotalsChange={setTotals}
                                onRowsChange={setRows}
                                resetKey={resetTableKey}
                                coaId={companyCoaMap[companytype]}
                            />

                            {/* 5. MODERN TOTALS BAR */}
                            <div className="erp-footer-totals mt-4">
                                <div className="grid grid-nogutter">
                                    <div className="col-12 md:col-4 total-box">
                                        <span className="label">TOTAL DEBIT</span>
                                        <span className="value text-green-600">
                                            {totals.totalDebit.toLocaleString('en-US', {
                                                minimumFractionDigits: 2,
                                            })}
                                        </span>
                                    </div>
                                    <div className="col-12 md:col-4 total-box">
                                        <span className="label">TOTAL CREDIT</span>
                                        <span className="value text-red-600">
                                            {totals.totalCredit.toLocaleString('en-US', {
                                                minimumFractionDigits: 2,
                                            })}
                                        </span>
                                    </div>
                                    <div
                                        className={`col-12 md:col-4 total-box highlight ${difference === 0 ? 'bg-green-50' : 'bg-red-50'}`}
                                    >
                                        <span className="label">DIFFERENCE</span>
                                        <span
                                            className={`value ${difference === 0 ? 'text-green-700' : 'text-red-700'}`}
                                        >
                                            {difference.toLocaleString('en-US', {
                                                minimumFractionDigits: 2,
                                            })}
                                        </span>
                                    </div>
                                </div>
                            </div>
                        </Card>
                    </div>
                </div>
            </form>

            <Dialog
                header="Missing fields"
                visible={showValidationDialog}
                style={validationDialogStyle}
                onHide={handleValidationDialogHide}
            >
                <ul>
                    {validationMessages.map((msg, i) => (
                        <li key={i} className="p-error">
                            {msg}
                        </li>
                    ))}
                </ul>
            </Dialog>
        </div>
    );
};

export default JournalEntry;
