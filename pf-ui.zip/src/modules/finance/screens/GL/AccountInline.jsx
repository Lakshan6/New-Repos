import React, { useMemo, useState, useCallback } from 'react';
import { Card } from 'primereact/card';
import { Divider } from 'primereact/divider';
import { Calendar } from 'primereact/calendar';
import { Dropdown } from 'primereact/dropdown';
import { InputText } from 'primereact/inputtext';
import { Button } from 'primereact/button';
import { ProgressSpinner } from 'primereact/progressspinner';
import { parsePostingDate } from '../../utils/ParseingDate';
import '../../styles/AccountInline.scss';
import { JOURNAL_TYPES } from '../../utils/JournalTypes';
import { CustomTable } from '@modules/finance/components';
import { useGetGlLineItems } from '../../hooks/GL/UseAccountInline';
import { useNavigate, useLocation } from 'react-router-dom';

const AccountInline = () => {
    const { state } = useLocation();
    const glId = state?.glId ?? '';
    const companyCode = state?.companyCode ?? '';
    const selectedRow = state?.row ?? '';
  
    const {
        lineItems,
        totalDebit,
        totalCredit,
        closingBalance,
        costCenterOptions,
        loading,
        isError,
        error,
    } = useGetGlLineItems({ glId, companyCode, enabled: !!glId });

    /* FILTER STATES */
    const [dateFrom, setDateFrom] = useState(null);
    const [dateTo, setDateTo] = useState(null);
    const [voucherType, setVoucherType] = useState(null);
    const [party, setParty] = useState('');
    const [costCenter, setCostCenter] = useState(null);
    const [search, setSearch] = useState('');
    const [filteredData, setFilteredData] = useState(null);

    /* ---------- Currency formatter ---------- */
    const currencyFormatter = useMemo(
        () =>
            new Intl.NumberFormat('en-IN', {
                style: 'currency',
                currency: 'INR',
                minimumFractionDigits: 2,
            }),
        [],
    );

    const fmt = useCallback(
        (val) => currencyFormatter.format(Math.abs(val || 0)),
        [currencyFormatter],
    );
const navigate = useNavigate();
    /* ---------- Navigation ---------- */


const handleDocClick = useCallback(
    (docId) => {
        navigate(
            `/web/landing/finance/general-ledger/coa/accounts/preview?doucs=${encodeURIComponent(docId)}`,
            {
                state: {
                    fromRoute: 'accounts',
                    glId,
                    companyCode,
                    row: selectedRow,
                },
            },
        );
    },
    [navigate, glId, companyCode, selectedRow],
);
    const handleDocClickEvent = useCallback(
        (e) => {
            const docId = e.currentTarget.dataset.docid;
            handleDocClick(docId);
        },
        [handleDocClick],
    );

    const renderDocId = useCallback(
        (row) => (
            <button
                type="button"
                className="gl-doc-link"
                data-docid={row.docId}
                onClick={handleDocClickEvent}
            >
                {row.docId}
            </button>
        ),
        [handleDocClickEvent],
    );

    /* ---------- Apply filter ---------- */
 const applyFilter = useCallback(() => {
     const from = dateFrom ? new Date(new Date(dateFrom).setHours(0, 0, 0, 0)) : null;
     const to = dateTo ? new Date(new Date(dateTo).setHours(0, 0, 0, 0)) : null;

     const filtered = lineItems.filter((item) => {
         const postingDate = parsePostingDate(item.postingDate);

         if (from && postingDate < from) return false;
         if (to && postingDate > to) return false;

         if (voucherType && item.docType?.toLowerCase().trim() !== voucherType.toLowerCase().trim())
             return false;

         if (party && !item.party?.toLowerCase().includes(party.toLowerCase())) return false;

         if (costCenter && item.costCenter !== costCenter) return false;

         if (search && !Object.values(item).join(' ').toLowerCase().includes(search.toLowerCase()))
             return false;

         return true;
     });

     setFilteredData(filtered);
 }, [lineItems, dateFrom, dateTo, voucherType, party, costCenter, search]);
    /* ---------- Reset filters ---------- */
    const resetFilters = useCallback(() => {
        setDateFrom(null);
        setDateTo(null);
        setVoucherType(null);
        setParty('');
        setCostCenter(null);
        setSearch('');
        setFilteredData(null);
    }, []);

    const tableData = filteredData === null ? lineItems : filteredData;

    /* ---------- Column renderers ---------- */
    const renderDebit = useCallback((r) => (r.debit ? fmt(r.debit) : '—'), [fmt]);

    const renderCredit = useCallback((r) => (r.credit ? fmt(r.credit) : '—'), [fmt]);

    const renderRunningBalance = useCallback((r) => fmt(r.runningBalance), [fmt]);

    const columns = useMemo(
        () => [
            { field: 'postingDate', header: 'Posting Date' },
            { field: 'documentDate', header: 'Document Date' },
            { field: 'docType', header: 'Voucher Type' },
            { field: 'docId', header: 'Voucher No', body: renderDocId },
            { field: 'party', header: 'Party' },
            { field: 'debit', header: 'Debit (₹)', body: renderDebit },
            { field: 'credit', header: 'Credit (₹)', body: renderCredit },
            {
                field: 'runningBalance',
                header: 'Running Balance (₹)',
                body: renderRunningBalance,
            },
            { field: 'reference', header: 'Reference' },
            { field: 'narration', header: 'Narration' },
            { field: 'costCenter', header: 'Cost Center' },
        ],
        [renderDocId, renderDebit, renderCredit, renderRunningBalance],
    );

    /* ---------- Change handlers ---------- */
    const handleDateFromChange = useCallback((e) => setDateFrom(e.value), []);
    const handleDateToChange = useCallback((e) => setDateTo(e.value), []);
    const handleVoucherChange = useCallback((e) => setVoucherType(e.value), []);
    const handlePartyChange = useCallback((e) => setParty(e.target.value), []);
    const handleCostCenterChange = useCallback((e) => setCostCenter(e.value), []);
    const handleSearchChange = useCallback((e) => setSearch(e.target.value), []);

    if (loading)
        return (
            <div className="loader-center">
                <ProgressSpinner />
            </div>
        );

if (isError) {
    return (
        <div className="error-container">
            <div className="error-box">
                <i className="pi pi-exclamation-triangle error-icon" />
                <h2>Not Found</h2>
                <p>{error?.message || 'Failed to load data'}</p>
            </div>
        </div>
    );
}

    return (
        <Card>
            <div className="gl-header">
                <h2 className="gl-title">
                    Account : <span className="gl-id">{selectedRow?.glId}</span>
                    <span className="gl-name">{selectedRow?.name }</span>
                </h2>

                <div className="gl-meta">
                    <span>Type: {selectedRow?.glType}</span>
                    <span>Currency: {selectedRow?.currency || 'INR'}</span>
                    <span>Status: {selectedRow?.status || 'Active'}</span>
                </div>
            </div>

            <div className="ledger-summary">
                <div className="debit">Total Debit :{fmt(totalDebit)}</div>

                <div className="credit">Total Credit : {fmt(totalCredit)}</div>

                <div className="balance">Closing Balance: {fmt(closingBalance)}</div>
            </div>

            <Divider />

            <div className="ledger-filter-container">
                <div className="ledger-filter-bar">
                    <Calendar
                        placeholder="From Date"
                        value={dateFrom}
                        onChange={handleDateFromChange}
                        showIcon
                    />
                    <Calendar
                        placeholder="To Date"
                        value={dateTo}
                        onChange={handleDateToChange}
                        showIcon
                    />

                    <Dropdown
                        value={voucherType}
                        options={JOURNAL_TYPES}
                        optionLabel="label"
                        optionValue="value"
                        onChange={handleVoucherChange}
                        placeholder="Voucher Type"
                    />

                    <InputText value={party} onChange={handlePartyChange} placeholder="Party" />

                    <Dropdown
                        value={costCenter}
                        options={costCenterOptions}
                        onChange={handleCostCenterChange}
                        placeholder="Cost Center"
                    />

                    <InputText value={search} onChange={handleSearchChange} placeholder="Search" />

                    <div className="filter-actions">
                        <Button label="Filter" icon="pi pi-filter" onClick={applyFilter} />
                        <Button
                            label="Reset"
                            severity="secondary"
                            outlined
                            onClick={resetFilters}
                        />
                    </div>
                </div>
            </div>

            <Divider />

            <CustomTable data={tableData} columns={columns} paginator rows={10} dataKey="lineId" />
        </Card>
    );
};

export default AccountInline;
