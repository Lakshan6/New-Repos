import '../../styles/Jscreen.scss';
import JournalPreviewTable from '../../components/generalLedger/ViewTable';
import useGetJournal1 from '../../hooks/GL/UseGetJournal';
import { useMemo, useState, useRef, useCallback, useEffect } from 'react';
import { useSearchCompany } from '../../hooks/company/useCompanyApi';
import ReversalDialog from '../../components/generalLedger/ReversalDialog';
import usePostReversal from '../../hooks/GL/UsePostReversal';
import { Button } from 'primereact/button';
import { Toast } from 'primereact/toast';
import { getParsedLocalStorageItem } from '@shared/utils/common';
const userDetails = getParsedLocalStorageItem('userDetails', {});
const UUID = (userDetails.userInfo || userDetails)?.uuid || '';

const JournalPreview = () => {
    const [showReversal, setShowReversal] = useState(false);
    const [dialogKey] = useState(0);

    const postReversalMutation = usePostReversal();
    const toast = useRef(null);

    /* -------- COMPANY MAP -------- */
    const { fetchAllCompanies } = useSearchCompany();
    const [companyMap, setCompanyMap] = useState({});

    const loadCompanies = useCallback(async () => {
        const response = await fetchAllCompanies();

        const map = (response || []).reduce((acc, company) => {
            acc[company.companyCode] = company.name;
            return acc;
        }, {});

        setCompanyMap(map);
    }, [fetchAllCompanies]);

    useEffect(() => {
        loadCompanies();
    }, [loadCompanies]);

    /* -------- URL PARAM -------- */
    const doucs = useMemo(() => {
        const params = new URLSearchParams(window.location.search);
        return params.get('doucs');
    }, []);

    /* -------- REVERSAL HANDLERS -------- */
    const openReversalDialog = useCallback(() => {
        setShowReversal(true);
    }, []);

    const hideReversalDialog = useCallback(() => {
        setShowReversal(false);
    }, []);

    const handleReversalPost = useCallback(() => {
        const apiPayload = {
            requestInfo: {
                userInfo: {
                    userDetails: { uuid: UUID },
                },
            },
            JournalId: doucs,
        };

        postReversalMutation.mutate(apiPayload, {
            onSuccess: () => {
                toast.current?.show({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Document reversed successfully',
                    life: 4000,
                });

                setTimeout(() => {
                    window.location.reload();
                }, 1000);
            },

            onError: () => {
                toast.current?.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: 'Reversal failed',
                    life: 3000,
                });
            },
        });
    }, [postReversalMutation, doucs]);

    /* -------- DATA FETCH -------- */
    const { header, Inlines, isLoading, isError, isSuccess } = useGetJournal1({
        enabled: !!doucs,
        documentId: doucs,
    });

    /* -------- ROWS -------- */
    const rows = useMemo(() => {
        if (!isSuccess) return [];

        return Inlines.map((inline) => ({
            account: inline.lineText,
            amount: inline.amount,
            type: inline.debitCredit,
            glId: inline.glId,
        }));
    }, [Inlines, isSuccess]);

    /* -------- TOTALS -------- */
    const { totalDebit, totalCredit } = useMemo(() => {
        return rows.reduce(
            (totals, row) => {
                if (row.type === 'D') totals.totalDebit += row.amount;
                if (row.type === 'C') totals.totalCredit += row.amount;
                return totals;
            },
            { totalDebit: 0, totalCredit: 0 },
        );
    }, [rows]);

    if (!doucs || isLoading) return null;
    if (isError) return <p>Error: GL Document not found with ID {doucs}</p>;

    return (
        <div className="erp-preview">
            <Toast ref={toast} />

            <div className="erp-header">Journal Entry : {header?.docId}</div>
            <div className="erp-preview-header">Details</div>

            <div className="erp-preview-body erp-flex-two-col">
                <div className="erp-col">
                    <div className="erp-preview-row">
                        <span className="erp-label">Company Name :</span>
                        <span className="erp-value">{companyMap[header?.companyCode]}</span>
                    </div>

                    <div className="erp-preview-row">
                        <span className="erp-label">Posting Date :</span>
                        <span className="erp-value">{header?.postingDate}</span>
                    </div>

                    <div className="erp-preview-row">
                        <span className="erp-label">Journal Type :</span>
                        <span className="erp-value">{header?.docType}</span>
                    </div>
                </div>

                <div className="erp-col">
                    <div className="erp-preview-row">
                        <span className="erp-label">Reference Docs :</span>
                        <span className="erp-value">{header?.referenceDoc}</span>
                    </div>

                    <div className="erp-preview-row">
                        <span className="erp-label">Fiscal Year :</span>
                        <span className="erp-value">{header?.fiscalYear}</span>
                    </div>

                    <div className="erp-preview-row">
                        <span className="erp-label">Reversal Doc No :</span>
                        <span className="erp-value">{header?.reversedDocumentNo}</span>
                    </div>
                </div>
            </div>

            <h5 className="erp-preview-header">Accounting</h5>
            <JournalPreviewTable rows={rows} />

            <div className="erp-totals-row">
                <div className="erp-total-item">
                    <span className="label">Total Debit :</span>
                    <span className="value debit">{totalDebit}</span>
                </div>

                <div className="erp-total-item">
                    <span className="label">Total Credit :</span>
                    <span className="value credit">{totalCredit}</span>
                </div>

                <div className="erp-total-item">
                    <span className="label">Difference :</span>
                    <span className="value diff">{(totalDebit - totalCredit).toFixed(2)}</span>
                </div>
            </div>

            <div>
                <Button
                    label="Reversal"
                    icon="pi pi-refresh"
                    severity="warning"
                    onClick={openReversalDialog}
                    disabled={!!header?.reversedDocumentNo}
                />

                <ReversalDialog
                    key={dialogKey}
                    visible={showReversal}
                    onHide={hideReversalDialog}
                    onPost={handleReversalPost}
                />
            </div>
        </div>
    );
};

export default JournalPreview;
