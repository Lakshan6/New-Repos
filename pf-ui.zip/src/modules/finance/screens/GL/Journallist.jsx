import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { useNavigate } from 'react-router';
import '../../styles/Jscreen.scss';
import { Divider } from 'primereact/divider';
import JournalFilters from '../../components/generalLedger/filterRowJournal';
import { useMemo, useState, useCallback, useEffect } from 'react';
import Rows from '../../utils/RowConstant';
import ViewJournalTable from '@modules/finance/components/generalLedger/ViewTableJournal';
import { useSearchCompany } from '../../hooks/company/useCompanyApi';
import { parseDDMMYYYY, normalizeDate } from '../../utils/ParseingDate';
const Journallist = () => {
    const navigate = useNavigate();
    const { fetchAllCompanies } = useSearchCompany();

    const [companies, setCompanies] = useState([]);
    const [setCompanyCoaMap] = useState({});

    /* ---------- Restore selected company ---------- */
    const [selectedCompany, setSelectedCompany] = useState(() => {
        const stored = sessionStorage.getItem('journalSelectedCompany');
        const timestamp = sessionStorage.getItem('journalSelectedCompanyTime');

        if (!stored || !timestamp) return null;

        const TEN_MINUTES = 1 * 60 * 1000;
        const isExpired = Date.now() - Number(timestamp) > TEN_MINUTES;

        if (isExpired) {
            sessionStorage.removeItem('journalSelectedCompany');
            sessionStorage.removeItem('journalSelectedCompanyTime');
            return null;
        }

        return stored;
    });

    const [filters, setFilters] = useState({
        status: 'ALL',
        fromDate: null,
        toDate: null,
    });

    /* ---------- Load companies ---------- */
    useEffect(() => {
        const loadCompanies = async () => {
            try {
                const response = await fetchAllCompanies();

                const mapped = (response || []).map((company) => ({
                    label: company.name,
                    value: company.companyCode,
                }));

                const coaMap = (response || []).reduce((acc, company) => {
                    acc[company.companyCode] = company.coaId;
                    return acc;
                }, {});

                setCompanies(mapped);
                setCompanyCoaMap(coaMap);
            } catch (err) {
                console.error(err);
            }
        };

        loadCompanies();
    }, [fetchAllCompanies, setCompanyCoaMap]);

    const { rows, loading } = Rows({
        companyCode: selectedCompany,
        enabled: !!selectedCompany,
    });
    const displayRows = useMemo(() => {
        return selectedCompany ? rows : [];
    }, [selectedCompany, rows]);

    /* ---------- Persist company ---------- */
    const handleCompanyChange = useCallback((e) => {
        const value = e.value ?? null;
        setSelectedCompany(value);

        if (value) {
            sessionStorage.setItem('journalSelectedCompany', value);
            sessionStorage.setItem('journalSelectedCompanyTime', Date.now());
        } else {
            sessionStorage.removeItem('journalSelectedCompany');
            sessionStorage.removeItem('journalSelectedCompanyTime');
        }
    }, []);
const handleActionClick = useCallback(
    (row) => {
        const doucsId = row.journalEntryNo;
        navigate(
            `/web/landing/finance/general-ledger/vouchers/preview?doucs=${encodeURIComponent(doucsId)}`,
            {
                state: {
                    fromRoute: 'vouchers', // ← ADD this line
                },
            },
        );
    },
    [navigate],
);
    const handleBackClick = useCallback(() => {
        navigate(-1);
    }, [navigate]);

    const handleNewEntryClick = useCallback(() => {
        navigate('/web/landing/finance/general-ledger/vouchers/createJournal');
    }, [navigate]);

    /* ---------- Date helpers ---------- */

    /* ---------- Filter rows ---------- */
    const filteredRows = useMemo(() => {
        return displayRows.filter((row) => {
            if (filters.status !== 'ALL' && row.status !== filters.status) return false;

            const postingDate = normalizeDate(parseDDMMYYYY(row.postingDate));
            const fromDate = normalizeDate(filters.fromDate);
            const toDate = normalizeDate(filters.toDate, true);

            if (fromDate && postingDate < fromDate) return false;
            if (toDate && postingDate > toDate) return false;

            return true;
        });
    }, [displayRows, filters]);

    return (
        <div className="journal-header">
            <div className="journal-header-top">
                <h2 className="journal-title">Journal Entries</h2>

                <Button
                    label="Back"
                    icon="pi pi-arrow-left"
                    className="p-button-text"
                    onClick={handleBackClick}
                />
            </div>
            <div className="journal-header-actions">
                <span className="filter-label">Company</span>

                <Dropdown
                    value={selectedCompany}
                    options={companies}
                    onChange={handleCompanyChange}
                    placeholder="Select a Company"
                    showClear
                />

                <Button
                    label="New Journal Entry"
                    className="p-button-primary"
                    onClick={handleNewEntryClick}
                />
            </div>
            <Divider />
            <JournalFilters onChange={setFilters} />
            <Divider />

            <div className="journal-table-wrapper">
                {!selectedCompany ? (
                    <p className="journal-muted-text">
                        Please select a company to view journal entries.
                    </p>
                ) : loading ? (
                    <p className="journal-center-text">Loading...</p>
                ) : (
                    <ViewJournalTable rows={filteredRows} onActionClick={handleActionClick} />
                )}
            </div>
        </div>
    );
};

export default Journallist;
