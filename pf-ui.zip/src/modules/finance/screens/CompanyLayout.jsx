import { Outlet } from 'react-router';
import Breadcrumb from '../components/Breadcrumb';
import useBreadcrumb from '../hooks/useBreadcrumb';
const CompanyLayout = () => {

    const { breadcrumbs,  popToIndex } = useBreadcrumb();
    return (
        <div>
            <Breadcrumb breadcrumbs={breadcrumbs} onNavigate={popToIndex} />
            <Outlet/>
        </div>
    );
};

export default CompanyLayout;
