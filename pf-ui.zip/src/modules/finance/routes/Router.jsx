import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';

import CompanyLayout from '../screens/CompanyLayout.jsx';
import ChartOfAccounts from '../screens/coa/ChartOfAccounts';
import JournalPreviw from '../screens/GL/JournalPreview';
import JournalEntry from '../screens/GL/Journalform';
import Journallist from '../screens/GL/Journallist';
import AccountInline from '../screens/GL/AccountInline';
const Router = () => {
    return (
        <TranslationProvider
            module={LOCALISATION_MODULES.FINANCE}
            translationsAtom={translationsAtom}
        >
            <Routes>
                <Route index element={<>Accounting Home Screen</>} />
                <Route path="general-ledger" element={<CompanyLayout />}>
                    <Route index element={<ChartOfAccounts />} />
                    <Route path="coa" element={<ChartOfAccounts />} />
                    <Route path="coa/accounts" element={<AccountInline />} />
                    <Route path="vouchers" element={<Journallist />} />
                    <Route path="coa/accounts/preview" element={<JournalPreviw />} />
                    <Route path="vouchers/createJournal" element={<JournalEntry />} />
                    <Route path="vouchers/preview" element={<JournalPreviw />} />
                </Route>

                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
