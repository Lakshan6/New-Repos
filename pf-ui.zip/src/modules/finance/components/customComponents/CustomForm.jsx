import PropTypes from 'prop-types';
import { useState, useMemo, useCallback, useEffect } from 'react';

import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { RadioButton } from 'primereact/radiobutton';
import { Checkbox } from 'primereact/checkbox';
import { Button } from 'primereact/button';

import FieldWrapper from '../FieldWrapper';

/* ---------------- validation engine ---------------- */

const runValidations = (value, formData, validations = []) => {
    for (const rule of validations) {
        if (rule.rule === 'required' && !value) {
            return rule.message;
        }

        if (rule.rule === 'minLength' && value?.length < rule.value) {
            return rule.message;
        }

        if (rule.rule === 'pattern' && !rule.value.test(value)) {
            return rule.message;
        }

        if (rule.rule === 'custom' && rule.validator) {
            const error = rule.validator(value, formData);
            if (error) return error;
        }
    }
    return null;
};

/* ---------------- component ---------------- */

const CustomForm = ({ definition, onSubmit, loading, initialValues, formOptions = {} }) => {
    const defaultValues = useMemo(() => {
        return definition.fields.reduce((acc, field) => {
            acc[field.name] = initialValues?.[field.name] ?? field.defaultValue ?? '';
            return acc;
        }, {});
    }, [definition.fields, initialValues]);

    const [formData, setFormData] = useState(defaultValues);
    const [errors, setErrors] = useState({});

    /* ---------------- handlers ---------------- */

    const updateField = useCallback((name, value) => {
        setFormData((prev) => ({ ...prev, [name]: value }));
    }, []);
    useEffect(() => {
        setFormData(defaultValues);
    }, [defaultValues]);
    const validateForm = useCallback(() => {
        const newErrors = {};

        definition.fields.forEach((field) => {
            const value = formData[field.name];

            if (field.required && !value) {
                newErrors[field.name] = `${field.label} is required`;
                return;
            }

            const error = runValidations(value, formData, field.validations);

            if (error) newErrors[field.name] = error;
        });

        setErrors(newErrors);
        return Object.keys(newErrors).length === 0;
    }, [definition.fields, formData]);

    const handleSubmit = useCallback(() => {
        if (!validateForm()) return;
        onSubmit(formData);
    }, [validateForm, onSubmit, formData]);

    /* ---------------- field change handler (memoized) ---------------- */

    const fieldChangeHandlers = useMemo(() => {
        const handlers = {};

        definition.fields.forEach((field) => {
            handlers[field.name] = {
                text: (e) => updateField(field.name, e.target.value),
                dropdown: (e) => updateField(field.name, e.value),
                checkbox: (e) => updateField(field.name, e.checked),
            };
        });

        return handlers;
    }, [definition.fields, updateField]);
    /* ---------------- renderer ---------------- */

    const renderField = (field) => {
        const value = formData[field.name];

        switch (field.type) {
            case 'text':
                return (
                    <InputText
                        value={value}
                        onChange={fieldChangeHandlers[field.name].text}
                        placeholder={field.placeholder}
                        className="w-full"
                    />
                );

            case 'dropdown': {
                const dropdownOptions =
                    field.options ||
                    (field.optionsKey ? formOptions[field.optionsKey] : undefined) ||
                    [];
                return (
                    <Dropdown
                        value={value}
                        options={dropdownOptions}
                        optionLabel={field.optionLabel}
                        optionValue={field.optionValue}
                        onChange={fieldChangeHandlers[field.name].dropdown}
                        placeholder={field.placeholder || `Select ${field.label}`}
                        className="w-full"
                        filter
                        showClear
                    />
                );
            }

            case 'radio':
                return (
                    <div className="flex gap-3">
                        {field.options.map((opt) => (
                            <div key={opt.value} className="flex align-items-center">
                                <RadioButton
                                    value={opt.value}
                                    checked={value === opt.value}
                                    onChange={fieldChangeHandlers[field.name].dropdown}
                                />
                                <label htmlFor={`${field.name}-${opt.value}`} className="ml-2">
                                    {opt.label}
                                </label>
                            </div>
                        ))}
                    </div>
                );

            case 'checkbox':
                return (
                    <Checkbox
                        checked={!!value}
                        onChange={fieldChangeHandlers[field.name].checkbox}
                    />
                );

            default:
                return null;
        }
    };

    /* ---------------- UI ---------------- */

    return (
        <div className="flex flex-column gap-3">
            {definition.title && <h3>{definition.title}</h3>}

            {definition.fields.map((field) => (
                <FieldWrapper
                    key={field.name}
                    label={field.label}
                    required={field.required}
                    error={errors[field.name]}
                >
                    {renderField(field)}
                </FieldWrapper>
            ))}

            <div className="flex justify-content-end">
                <Button
                    label={definition.submitLabel || 'Submit'}
                    onClick={handleSubmit}
                    loading={loading}
                />
            </div>
        </div>
    );
};

CustomForm.propTypes = {
    definition: PropTypes.object.isRequired,
    onSubmit: PropTypes.func.isRequired,
    loading: PropTypes.bool,
    initialValues: PropTypes.object,
    formOptions: PropTypes.object,
};

CustomForm.defaultProps = {
    loading: false,
    formOptions: {},
};

export default CustomForm;
