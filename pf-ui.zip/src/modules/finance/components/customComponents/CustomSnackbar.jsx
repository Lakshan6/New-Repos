import { Toast } from 'primereact/toast';
import { forwardRef } from 'react';

const CustomSnackbar = forwardRef((props, ref) => {
    return <Toast ref={ref} position="top-right" life={3000} />;
});

CustomSnackbar.displayName = 'CustomSnackbar';

export default CustomSnackbar;
