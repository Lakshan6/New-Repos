import PropTypes from 'prop-types';
import { useCallback } from 'react';
import '../../styles/CustomBreadcrumb.scss';

const CustomBreadcrumb = ({ items, onNavigate }) => {
    const handleClick = useCallback(
        (item) => {
            if (item.path && onNavigate) {
                onNavigate(item.path);
            }
        },
        [onNavigate],
    );
    const handleItemClick = useCallback(
        (e) => {
            const itemId = e.currentTarget.getAttribute('data-id');
            const selectedItem = items.find((i) => String(i.id) === itemId);
            if (!selectedItem) return;

            handleClick(selectedItem);
        },
        [items, handleClick],
    );

    return (
        <nav aria-label="Breadcrumb" className="custom-breadcrumb">
            <ol className="breadcrumb-list">
                {items.map((item, index) => {
                    const isLast = index === items.length - 1;

                    return (
                        <li key={index} className="breadcrumb-item">
                            {!isLast && item.path ? (
                                <button
                                    type="button"
                                    className="breadcrumb-button"
                                    onClick={handleItemClick}
                                >
                                    {item.icon && <i className={`${item.icon} mr-2`} />}
                                    {item.label}
                                </button>
                            ) : (
                                <span className="breadcrumb-active">
                                    {item.icon && <i className={`${item.icon} mr-2`} />}
                                    {item.label}
                                </span>
                            )}

                            {!isLast && <i className="pi pi-chevron-right breadcrumb-separator" />}
                        </li>
                    );
                })}
            </ol>
        </nav>
    );
};

CustomBreadcrumb.propTypes = {
    items: PropTypes.array.isRequired,
    onNavigate: PropTypes.func,
};

CustomBreadcrumb.defaultProps = {
    onNavigate: null,
};

export default CustomBreadcrumb;
