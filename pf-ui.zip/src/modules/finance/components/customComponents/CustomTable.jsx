import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { MultiSelect } from 'primereact/multiselect';
import { Tooltip } from 'primereact/tooltip';
import { FilterMatchMode } from 'primereact/api';
import { Tag } from 'primereact/tag';
import { OverlayPanel } from 'primereact/overlaypanel';
import { useState, useCallback, useMemo, useRef } from 'react';
import '../../styles/CustomTable.scss';

const TOOLTIP_OPTIONS_TOP = { position: 'top' };
const COLUMN_HEADER_STYLE_SM = { width: '3rem' };

/* ------------------------------------------------------------------ */
/*  Action Buttons                                                      */
/* ------------------------------------------------------------------ */
const ActionButtons = ({ rowData, actions, onEdit, onDelete, onCustomAction }) => (
    <div className="flex gap-1 action-icons">
        {actions?.edit && (
            <Button
                icon="pi pi-pencil"
                className="p-button-sm action-btn action-btn--edit"
                text
                rounded
                tooltip="Edit"
                tooltipOptions={TOOLTIP_OPTIONS_TOP}
                onClick={onEdit}
                data-row-id={rowData.id}
            />
        )}
        {actions?.delete && (
            <Button
                icon="pi pi-trash"
                className="p-button-sm action-btn action-btn--delete"
                text
                rounded
                tooltip="Delete"
                tooltipOptions={TOOLTIP_OPTIONS_TOP}
                onClick={onDelete}
                data-row-id={rowData.id}
            />
        )}
        {actions?.custom?.map((action, idx) => (
            <Button
                key={idx}
                icon={action.icon}
                className="p-button-sm action-btn"
                text
                rounded
                severity={action.severity || 'info'}
                tooltip={action.label || 'Action'}
                tooltipOptions={TOOLTIP_OPTIONS_TOP}
                onClick={onCustomAction}
                data-action-id={idx}
                data-row-id={rowData.id}
            />
        ))}
    </div>
);

ActionButtons.propTypes = {
    rowData: PropTypes.object.isRequired,
    actions: PropTypes.object,
    onEdit: PropTypes.func,
    onDelete: PropTypes.func,
    onCustomAction: PropTypes.func,
};

/* ------------------------------------------------------------------ */
/*  Empty State                                                         */
/* ------------------------------------------------------------------ */
const EmptyState = ({ message, icon }) => (
    <div className="custom-table-empty">
        <i className={`${icon} custom-table-empty__icon`} />
        <p className="custom-table-empty__text">{message}</p>
    </div>
);

EmptyState.propTypes = {
    message: PropTypes.string,
    icon: PropTypes.string,
};

EmptyState.defaultProps = {
    message: 'No records found',
    icon: 'pi pi-inbox',
};

/* ------------------------------------------------------------------ */
/*  Column Filter Header (memoized for react-perf)                      */
/* ------------------------------------------------------------------ */
const ColumnFilterHeader = ({
    field,
    header,
    filterValue,
    filterPlaceholder,
    isFilterActive,
    onFilterChange,
    onCloseFilter,
    onOpenFilter,
}) => {
    const handleFilterChange = useCallback(
        (e) => onFilterChange(field, e.target.value),
        [field, onFilterChange],
    );
    const handleStopPropagation = useCallback((e) => e.stopPropagation(), []);
    const handleClose = useCallback(
        (e) => {
            e.stopPropagation();
            onCloseFilter();
        },
        [onCloseFilter],
    );
    const handleOpen = useCallback(
        (e) => {
            e.stopPropagation();
            onOpenFilter(field);
        },
        [field, onOpenFilter],
    );

    if (isFilterActive) {
        return (
            <div className="column-header-with-search" data-field={field}>
                <div className="column-filter-wrapper column-filter-wrapper--inline">
                    <i className="pi pi-search column-filter-icon" />
                    <InputText
                        value={filterValue}
                        onChange={handleFilterChange}
                        onMouseDown={handleStopPropagation}
                        onClick={handleStopPropagation}
                        placeholder={filterPlaceholder || header}
                        className="column-filter-input"
                    />
                    <Button
                        icon="pi pi-times"
                        className="p-button-text p-button-sm column-filter-close"
                        onClick={handleClose}
                        aria-label="Close filter"
                    />
                </div>
            </div>
        );
    }
    return (
        <div className="column-header-with-icon">
            <span>{header}</span>
            <button
                type="button"
                className="column-header-search-btn"
                onClick={handleOpen}
                title="Click to search"
                aria-label={`Search ${header}`}
            >
                <i className="pi pi-search column-header-search-icon" />
            </button>
        </div>
    );
};

ColumnFilterHeader.propTypes = {
    field: PropTypes.string.isRequired,
    header: PropTypes.string.isRequired,
    filterValue: PropTypes.string.isRequired,
    filterPlaceholder: PropTypes.string,
    isFilterActive: PropTypes.bool.isRequired,
    onFilterChange: PropTypes.func.isRequired,
    onCloseFilter: PropTypes.func.isRequired,
    onOpenFilter: PropTypes.func.isRequired,
};

/* ------------------------------------------------------------------ */
/*  CustomTable                                                         */
/* ------------------------------------------------------------------ */
const CustomTable = ({
    data,
    columns,
    loading,
    paginator,
    rows,
    actions,
    dataKey,
    globalFilterFields,
    paginatorConfig,
    title,
    headerActions,
    selectable,
    onSelectionChange,
    emptyMessage,
    emptyIcon,
    exportable,
    columnToggle,
    resizableColumns,
    reorderableColumns,
    rowExpansion,
    stickyHeader,
    columnSearch,
    showColumnBorders,
}) => {
    /* ---------------- state ---------------- */
    const [globalFilterValue, setGlobalFilterValue] = useState('');
    const [filters, setFilters] = useState(() => {
        const base = {
            global: { value: null, matchMode: FilterMatchMode.CONTAINS },
        };
        if (columnSearch) {
            columns.forEach((col) => {
                if (col.filterable !== false) {
                    base[col.field] = { value: null, matchMode: FilterMatchMode.CONTAINS };
                }
            });
        }
        return base;
    });

    const [selectedRows, setSelectedRows] = useState(null);
    const [visibleColumns, setVisibleColumns] = useState(columns);
    const [expandedRows, setExpandedRows] = useState(null);
    const [activeFilterColumn, setActiveFilterColumn] = useState(null);

    const dt = useRef(null);
    const columnToggleRef = useRef(null);

    /* ---------------- global filter ---------------- */
    const onGlobalFilterChange = useCallback((e) => {
        const value = e.target.value;
        setGlobalFilterValue(value);
        setFilters((prev) => ({
            ...prev,
            global: { value, matchMode: FilterMatchMode.CONTAINS },
        }));
    }, []);

    /* ---------------- per-column filter ---------------- */
    const onColumnFilterChange = useCallback((field, value) => {
        setFilters((prev) => ({
            ...prev,
            [field]: { value: value || null, matchMode: FilterMatchMode.CONTAINS },
        }));
    }, []);

    const handleCloseFilter = useCallback(() => setActiveFilterColumn(null), []);
    const handleOpenFilter = useCallback((field) => setActiveFilterColumn(field), []);

    /* ---------------- selection ---------------- */
    const handleSelectionChange = useCallback(
        (e) => {
            setSelectedRows(e.value);
            onSelectionChange?.(e.value);
        },
        [onSelectionChange],
    );

    /* ---------------- actions ---------------- */
    const hasActions = useMemo(
        () => !!(actions?.edit || actions?.delete || actions?.custom?.length > 0),
        [actions],
    );

    const handleEditClick = useCallback(
        (e) => {
            const rowId = e.currentTarget.getAttribute('data-row-id');
            const rowData = data.find((item) => String(item[dataKey]) === rowId);
            if (rowData) actions?.edit?.(rowData);
        },
        [actions, data, dataKey],
    );

    const handleDeleteClick = useCallback(
        (e) => {
            const rowId = e.currentTarget.getAttribute('data-row-id');
            const rowData = data.find((item) => String(item[dataKey]) === rowId);
            if (rowData) actions?.delete?.(rowData);
        },
        [actions, data, dataKey],
    );

    const handleCustomActionClick = useCallback(
        (e) => {
            const actionId = parseInt(e.currentTarget.getAttribute('data-action-id'), 10);
            const rowId = e.currentTarget.getAttribute('data-row-id');
            const rowData = data.find((item) => String(item[dataKey]) === rowId);
            if (rowData && actions?.custom?.[actionId]) {
                actions.custom[actionId].callback(rowData);
            }
        },
        [actions, data, dataKey],
    );

    const actionTemplate = useCallback(
        (rowData) => (
            <ActionButtons
                rowData={rowData}
                actions={actions}
                onEdit={handleEditClick}
                onDelete={handleDeleteClick}
                onCustomAction={handleCustomActionClick}
            />
        ),
        [actions, handleEditClick, handleDeleteClick, handleCustomActionClick],
    );

    /* ---------------- export ---------------- */
    const handleExportCSV = useCallback(() => dt.current?.exportCSV(), []);

    const handleColumnToggleClick = useCallback((e) => {
        columnToggleRef.current?.toggle(e);
    }, []);

    /* ---------------- column toggle ---------------- */
    const onColumnToggle = useCallback(
        (e) => {
            const ordered = columns.filter((col) => e.value.some((s) => s.field === col.field));
            setVisibleColumns(ordered);
        },
        [columns],
    );

    /* ---------------- link click ---------------- */
    const handleLinkClick = useCallback(
        (e) => {
            const rowId = e.currentTarget.getAttribute('data-row-id');
            const field = e.currentTarget.getAttribute('data-field');
            const rowData = data.find((item) => String(item[dataKey]) === rowId);
            if (!rowData) return;
            columns.find((col) => col.field === field)?.onClick?.(rowData);
        },
        [data, dataKey, columns],
    );

    /* ---------------- resolved columns ---------------- */
    const resolvedColumns = useMemo(() => {
        return visibleColumns.map((col) => {
            let body = col.body;

            if (col.isLink) {
                body = (rowData) => (
                    <button
                        type="button"
                        className="table-link-button"
                        onClick={handleLinkClick}
                        data-row-id={rowData[dataKey]}
                        data-field={col.field}
                    >
                        {rowData[col.field]}
                    </button>
                );
            } else if (col.isTag) {
                body = (rowData) => (
                    <Tag
                        value={rowData[col.field]}
                        severity={col.tagSeverity?.(rowData) || 'info'}
                        className="custom-tag"
                    />
                );
            }

            const isFilterable = columnSearch && col.filterable !== false;
            const isFilterActive = activeFilterColumn === col.field;
            const filterValue = filters[col.field]?.value || '';

            const headerTemplate = isFilterable
                ? () => (
                      <ColumnFilterHeader
                          field={col.field}
                          header={col.header}
                          filterValue={filterValue}
                          filterPlaceholder={col.filterPlaceholder}
                          isFilterActive={isFilterActive}
                          onFilterChange={onColumnFilterChange}
                          onCloseFilter={handleCloseFilter}
                          onOpenFilter={handleOpenFilter}
                      />
                  )
                : null;

            // No-op filterElement so PrimeReact ColumnFilter doesn't call filterApplyCallback
            // during render (we control filter UI and state via the custom header).
            const filterElement = isFilterable ? () => null : undefined;

            return {
                ...col,
                body,
                header: headerTemplate || col.header,
                filterElement,
            };
        });
    }, [
        visibleColumns,
        handleLinkClick,
        dataKey,
        columnSearch,
        onColumnFilterChange,
        handleCloseFilter,
        handleOpenFilter,
        activeFilterColumn,
        filters,
    ]);

    /* ---------------- header toolbar ---------------- */
    const tableHeader = (
        <div className="custom-table-header">
            <div className="custom-table-header__left">
                {title && <span className="custom-table-header__title">{title}</span>}
                {data?.length > 0 && (
                    <span className="custom-table-header__count">{data.length} records</span>
                )}
            </div>

            <div className="custom-table-header__right">
                {/* Global search — hidden when columnSearch is active */}
                {!columnSearch && globalFilterFields?.length > 0 && (
                    <div className="custom-search">
                        <i className="pi pi-search custom-search__icon" />
                        <InputText
                            value={globalFilterValue}
                            onChange={onGlobalFilterChange}
                            placeholder="Search..."
                            className="p-inputtext-sm"
                        />
                    </div>
                )}

                {selectable && selectedRows?.length > 0 && (
                    <span className="custom-table-header__selected">
                        {selectedRows.length} selected
                    </span>
                )}

                {columnToggle && (
                    <>
                        <Button
                            icon="pi pi-table"
                            className="p-button-sm toolbar-btn"
                            text
                            rounded
                            tooltip="Toggle columns"
                            tooltipOptions={TOOLTIP_OPTIONS_TOP}
                            onClick={handleColumnToggleClick}
                        />
                        <OverlayPanel ref={columnToggleRef} className="column-toggle-panel">
                            <p className="column-toggle-panel__label">Visible Columns</p>
                            <MultiSelect
                                value={visibleColumns}
                                options={columns}
                                optionLabel="header"
                                onChange={onColumnToggle}
                                className="w-full"
                                display="chip"
                            />
                        </OverlayPanel>
                    </>
                )}

                {exportable && (
                    <Button
                        icon="pi pi-download"
                        className="p-button-sm toolbar-btn"
                        text
                        rounded
                        tooltip="Export CSV"
                        tooltipOptions={TOOLTIP_OPTIONS_TOP}
                        onClick={handleExportCSV}
                    />
                )}

                {headerActions}
            </div>
        </div>
    );

    const actionColumnStyle = useMemo(() => ({ width: '7rem' }), []);

    const handleRowToggle = useCallback((e) => setExpandedRows(e.data), []);

    const emptyMessageContent = useMemo(
        () => <EmptyState message={emptyMessage} icon={emptyIcon} />,
        [emptyMessage, emptyIcon],
    );

    const rowsPerPageOptions = useMemo(
        () => paginatorConfig?.rowsPerPageOptions || [5, 10, 25, 50],
        [paginatorConfig?.rowsPerPageOptions],
    );

    return (
        <div
            className={`custom-table-wrapper ${stickyHeader ? 'sticky-header' : ''} ${showColumnBorders ? '' : 'no-column-borders'}`}
        >
            <Tooltip target=".action-btn" />
            <DataTable
                ref={dt}
                value={data}
                loading={loading}
                paginator={paginator}
                rows={rows}
                dataKey={dataKey}
                size="small"
                scrollable
                scrollHeight={stickyHeader ? '600px' : undefined}
                filters={filters}
                filterDisplay={undefined}
                globalFilterFields={!columnSearch ? globalFilterFields : undefined}
                header={tableHeader}
                rowsPerPageOptions={rowsPerPageOptions}
                paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown CurrentPageReport"
                currentPageReportTemplate="Showing {first}–{last} of {totalRecords}"
                emptyMessage={emptyMessageContent}
                selection={selectable ? selectedRows : undefined}
                onSelectionChange={selectable ? handleSelectionChange : undefined}
                selectionMode={selectable ? 'multiple' : undefined}
                expandedRows={rowExpansion ? expandedRows : undefined}
                onRowToggle={rowExpansion ? handleRowToggle : undefined}
                rowExpansionTemplate={rowExpansion}
                resizableColumns={resizableColumns}
                reorderableColumns={reorderableColumns}
                className="custom-datatable"
            >
                {selectable && (
                    <Column
                        selectionMode="multiple"
                        headerStyle={COLUMN_HEADER_STYLE_SM}
                        className="selection-col"
                    />
                )}

                {rowExpansion && (
                    <Column
                        expander
                        headerStyle={COLUMN_HEADER_STYLE_SM}
                        className="expander-col"
                    />
                )}

                {resolvedColumns.map((col) => (
                    <Column
                        key={col.field}
                        field={col.field}
                        header={col.header}
                        sortable={col.sortable !== false}
                        body={col.body}
                        filter={columnSearch && col.filterable !== false}
                        filterElement={col.filterElement}
                        filterMatchMode={FilterMatchMode.CONTAINS}
                        showFilterMenu={false}
                        filterPlaceholder={col.filterPlaceholder}
                        style={col.style}
                        frozen={col.frozen}
                    />
                ))}

                {hasActions && (
                    <Column
                        header="Actions"
                        body={actionTemplate}
                        style={actionColumnStyle}
                        frozen
                        alignFrozen="right"
                    />
                )}
            </DataTable>
        </div>
    );
};

CustomTable.propTypes = {
    data: PropTypes.array.isRequired,
    columns: PropTypes.array.isRequired,
    loading: PropTypes.bool,
    paginator: PropTypes.bool,
    rows: PropTypes.number,
    actions: PropTypes.shape({
        edit: PropTypes.func,
        delete: PropTypes.func,
        custom: PropTypes.arrayOf(
            PropTypes.shape({
                label: PropTypes.string,
                icon: PropTypes.string.isRequired,
                callback: PropTypes.func.isRequired,
                severity: PropTypes.string,
            }),
        ),
    }),
    dataKey: PropTypes.string,
    globalFilterFields: PropTypes.array,
    paginatorConfig: PropTypes.object,
    title: PropTypes.string,
    headerActions: PropTypes.node,
    selectable: PropTypes.bool,
    onSelectionChange: PropTypes.func,
    emptyMessage: PropTypes.string,
    emptyIcon: PropTypes.string,
    exportable: PropTypes.bool,
    columnToggle: PropTypes.bool,
    resizableColumns: PropTypes.bool,
    reorderableColumns: PropTypes.bool,
    rowExpansion: PropTypes.func,
    stickyHeader: PropTypes.bool,
    columnSearch: PropTypes.bool,
    showColumnBorders: PropTypes.bool,
};

CustomTable.defaultProps = {
    loading: false,
    paginator: true,
    rows: 10,
    actions: undefined,
    dataKey: 'id',
    globalFilterFields: [],
    paginatorConfig: {},
    title: '',
    headerActions: null,
    selectable: false,
    onSelectionChange: undefined,
    emptyMessage: 'No records found',
    emptyIcon: 'pi pi-inbox',
    exportable: false,
    columnToggle: false,
    resizableColumns: false,
    reorderableColumns: false,
    rowExpansion: null,
    stickyHeader: false,
    columnSearch: false,
    showColumnBorders: true,
};

export default CustomTable;
