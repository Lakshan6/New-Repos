import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { useCallback, useMemo } from 'react';

const CustomDialog = ({
    visible,
    header,
    message,
    onHide,
    onAction,
    actionLabel,
    actionSeverity,
    showCancel,
    cancelLabel,
    loading,
}) => {
    const handleAction = useCallback(() => {
        onAction();
    }, [onAction]);

    const handleCancel = useCallback(() => {
        onHide();
    }, [onHide]);
    const dialogStyle = useMemo(() => ({ width: '30rem' }), []);

    return (
        <Dialog header={header} visible={visible} modal style={dialogStyle} onHide={handleCancel}>
            <div className="flex flex-column gap-4">
                <div>{message}</div>

                <div className="flex justify-content-end gap-2">
                    {showCancel && (
                        <Button label={cancelLabel} severity="secondary" onClick={handleCancel} />
                    )}

                    <Button
                        label={actionLabel}
                        severity={actionSeverity}
                        onClick={handleAction}
                        loading={loading}
                    />
                </div>
            </div>
        </Dialog>
    );
};

CustomDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    header: PropTypes.string.isRequired,
    message: PropTypes.node.isRequired, // string OR JSX
    onHide: PropTypes.func.isRequired,
    onAction: PropTypes.func.isRequired,
    actionLabel: PropTypes.string.isRequired,
    actionSeverity: PropTypes.oneOf(['success', 'danger', 'warning', 'info', 'secondary']),
    showCancel: PropTypes.bool,
    cancelLabel: PropTypes.string,
    loading: PropTypes.bool,
};

CustomDialog.defaultProps = {
    actionSeverity: 'success',
    showCancel: true,
    cancelLabel: 'Cancel',
    loading: false,
};

export default CustomDialog;
