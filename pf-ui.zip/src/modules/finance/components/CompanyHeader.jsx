import { useState, useCallback, useMemo } from 'react';
import { Button } from 'primereact/button';
import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';

import FieldWrapper from './FieldWrapper';
import CompanySelector from './CompanySelector';
import ToggleView from './ToggleView';
import coaList from '../utils/coaList.json';
import PropTypes from 'prop-types';
import countryList from '../utils/countryList.json';

const CompanyHeader = ({ changeCompany, view, setView, createCompany, fetchCompanies }) => {
    const [showCreateDialog, setShowCreateDialog] = useState(false);

    const [companyForm, setCompanyForm] = useState({
        companyCode: '',
        name: '',
        currency: '',
        country: '',
        coaId: null,
    });

    const dialogStyle = useMemo(
        () => ({
            width: '450px',
        }),
        [],
    );

    /* ---------------- handlers ---------------- */

    const handleCreateCompany = useCallback(() => {
        setCompanyForm({
            companyCode: '',
            name: '',
            currency: '',
            country: '',
            coaId: null,
        });
        setShowCreateDialog(true);
    }, []);

    const updateField = useCallback((key, value) => {
        setCompanyForm((prev) => ({
            ...prev,
            [key]: value,
        }));
    }, []);

    const handleSubmitCompany = useCallback(async () => {
        const requestBody = { ...companyForm };

        try {
            await createCompany(requestBody);
            setShowCreateDialog(false);
            fetchCompanies();
        } catch (err) {
            console.error('Create company failed', err);
        }
    }, [companyForm, createCompany, fetchCompanies]);

    const handleHideCreateDialog = useCallback(() => {
        setShowCreateDialog(false);
    }, []);

    const handleCompanyCodeChange = useCallback(
        (e) => {
            updateField('companyCode', e.target.value);
        },
        [updateField],
    );
    const handleCompanyNameChange = useCallback(
        (e) => {
            updateField('name', e.target.value);
        },
        [updateField],
    );
    const handleCompanyCurrencyChange = useCallback(
        (e) => {
            updateField('currency', e.target.value);
        },
        [updateField],
    );
    const handleCompanyCountryChange = useCallback(
        (e) => {
            updateField('country', e.target.value);
        },
        [updateField],
    );
    const handleCompanyCoaIdChange = useCallback(
        (e) => {
            updateField('coaId', e.target.value);
        },
        [updateField],
    );

    const handleCloseCreateDialog = useCallback(() => {
        setShowCreateDialog(false);
    }, []);

    const isSubmitDisabled =
        !companyForm.companyCode ||
        !companyForm.name ||
        !companyForm.currency ||
        !companyForm.country ||
        !companyForm.coaId;

    /* ---------------- UI ---------------- */

    return (
        <>
            <div className="flex gap-3 align-items-end mb-3 justify-content-between">
                <div className="flex gap-3 align-items-end">
                    <FieldWrapper label="Select Company">
                        <CompanySelector onChange={changeCompany} />
                    </FieldWrapper>

                    <FieldWrapper>
                        <ToggleView value={view} onChange={setView} />
                    </FieldWrapper>
                </div>

                <Button
                    label="Create Company"
                    icon="pi pi-plus"
                    severity="success"
                    onClick={handleCreateCompany}
                />
            </div>

            <Dialog
                header="Create Company"
                visible={showCreateDialog}
                modal
                style={dialogStyle}
                onHide={handleHideCreateDialog}
            >
                <div className="flex flex-column gap-3">
                    <FieldWrapper label="Company Code">
                        <InputText
                            value={companyForm.companyCode}
                            onChange={handleCompanyCodeChange}
                        />
                    </FieldWrapper>

                    <FieldWrapper label="Company Name">
                        <InputText value={companyForm.name} onChange={handleCompanyNameChange} />
                    </FieldWrapper>

                    <FieldWrapper label="Currency">
                        <InputText
                            placeholder="INR / USD"
                            value={companyForm.currency}
                            onChange={handleCompanyCurrencyChange}
                        />
                    </FieldWrapper>

                    <FieldWrapper label="Country">
                        <Dropdown
                            options={countryList}
                            value={companyForm.country}
                            onChange={handleCompanyCountryChange}
                            placeholder="Select Country"
                            showClear
                            filter
                            className="w-full"
                        />
                    </FieldWrapper>

                    <FieldWrapper label="Select COA">
                        <Dropdown
                            optionLabel="coaName"
                            optionValue="coaId"
                            options={coaList}
                            value={companyForm.coaId}
                            onChange={handleCompanyCoaIdChange}
                            placeholder="Select Chart of Accounts"
                            showClear
                            filter
                            className="w-full"
                        />
                    </FieldWrapper>

                    <div className="flex justify-content-end gap-2 mt-3">
                        <Button
                            label="Cancel"
                            severity="secondary"
                            onClick={handleCloseCreateDialog}
                        />
                        <Button
                            label="Submit"
                            icon="pi pi-check"
                            disabled={isSubmitDisabled}
                            onClick={handleSubmitCompany}
                        />
                    </div>
                </div>
            </Dialog>
        </>
    );
};

CompanyHeader.propTypes = {
    changeCompany: PropTypes.func.isRequired,
    view: PropTypes.string.isRequired,
    setView: PropTypes.func.isRequired,
    createCompany: PropTypes.func.isRequired,
    fetchCompanies: PropTypes.func.isRequired,
};

export default CompanyHeader;
