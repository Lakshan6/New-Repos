import PropTypes from 'prop-types';
import { useState, useCallback } from 'react';
import { Dialog } from 'primereact/dialog';
import { FileUpload } from 'primereact/fileupload';
import { Message } from 'primereact/message';
import CustomForm from './customComponents/CustomForm';
import { createCoaFormDefinition } from '../utils/createCoaForm';

const dialogStyle = { width: '450px' };

const CreateCoaDialog = ({ visible, onHide, onUpload, loading }) => {
    const [selectedFile, setSelectedFile] = useState(null);
    const [fileError, setFileError] = useState(null);

    const onFileSelect = useCallback((e) => {
        setSelectedFile(e.files[0]);
        setFileError(null);
    }, []);

    const handleSubmit = useCallback(
        (formData) => {
            if (!selectedFile) {
                setFileError('Please select an Excel file');
                return;
            }
            setFileError(null);
            onUpload({
                file: selectedFile,
                ...formData,
            });
        },
        [onUpload, selectedFile],
    );

    return (
        <Dialog
            header="Create Chart of Accounts"
            visible={visible}
            style={dialogStyle}
            onHide={onHide}
            modal
        >
            <div className="flex flex-column gap-3">
                <FileUpload
                    mode="basic"
                    name="coaExcel"
                    accept=".xlsx,.xls"
                    chooseLabel="Choose Excel"
                    customUpload
                    auto={false}
                    onSelect={onFileSelect}
                />
                {fileError && <Message severity="error" text={fileError} className="w-full" />}

                <CustomForm
                    definition={createCoaFormDefinition}
                    onSubmit={handleSubmit}
                    loading={loading}
                />
            </div>
        </Dialog>
    );
};

/* ---------------- prop types ---------------- */

CreateCoaDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
    onUpload: PropTypes.func.isRequired,
    loading: PropTypes.bool,
};

CreateCoaDialog.defaultProps = {
    loading: false,
};

export default CreateCoaDialog;
