import { useAtom } from 'jotai';
import { useMemo, useCallback, useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';

import { selectedCompanyAtom, selectedCoaAtom } from '../store/atoms';
import CustomTable from './customComponents/CustomTable';
import { useCoaAccountApi } from '../hooks/coa/useCoaAccountApi';

const PAGINATOR_CONFIG = { rowsPerPageOptions: [25, 50, 100] };

const TableView = () => {
    const [selectedCompany] = useAtom(selectedCompanyAtom);
    const [selectedCoaId] = useAtom(selectedCoaAtom);

    const { fetchAccounts, isFetching } = useCoaAccountApi();
    const navigate = useNavigate();

    const [accounts, setAccounts] = useState([]);

    const effectiveCoaId = selectedCompany?.coaId || selectedCoaId;
    const companyCode = selectedCompany?.companyCode || null;

    useEffect(() => {
        if (!effectiveCoaId) return;

        const load = async () => {
            try {
                const res = await fetchAccounts({ coaId: effectiveCoaId, companyCode });
                const list = res?.accounts ?? res?.data?.accounts ?? res?.data ?? [];
                setAccounts(list);
            } catch (err) {
                console.error('Failed to fetch accounts:', err);
                setAccounts([]);
            }
        };

        load();
    }, [effectiveCoaId, companyCode]); // eslint-disable-line react-hooks/exhaustive-deps

    const ledgers = useMemo(() => {
        return accounts
            .filter((acc) => acc.isGroup === 'N')
            .map((acc) => ({
                id: acc.glId,
                code: acc.glId,
                name: acc.glName,
                glType: acc.glType,
                parentGlId: acc.parentGlId,
                accountGroup: acc.accountGroup,
                reportType: acc.reportType,
                levelNo: acc.levelNo,
            }));
    }, [accounts]);

    const handleLedgerClick = useCallback(
        (row) => {
            navigate('../general-ledger/coa/accounts', {
                state: {
                    glId: row.code,
                    companyCode,
                    row,
                },
            });
        },
        [navigate, companyCode],
    );

    const columns = useMemo(
        () => [
            { field: 'code', header: 'GL Code', sortable: true, filterable: true },
            {
                field: 'name',
                header: 'Ledger Name',
                sortable: true,
                filterable: true,
                isLink: true,
                onClick: handleLedgerClick,
            },
            { field: 'parentGlId', header: 'Parent Code', sortable: true, filterable: true },
            { field: 'glType', header: 'Type', sortable: true, filterable: true },
            { field: 'accountGroup', header: 'Account Group', sortable: true, filterable: true },
            { field: 'reportType', header: 'Report Type', sortable: true, filterable: true },
        ],
        [handleLedgerClick],
    );

    if (!effectiveCoaId) {
        return (
            <div className="flex align-items-center justify-content-center p-4">
                <span className="text-color-secondary">
                    Please select a Chart of Accounts to view ledgers.
                </span>
            </div>
        );
    }

    return (
        <CustomTable
            data={ledgers}
            columns={columns}
            loading={isFetching}
            paginator
            rows={25}
            dataKey="code"
            paginatorConfig={PAGINATOR_CONFIG}
            columnSearch
            columnToggle
            exportable
            showColumnBorders
        />
    );
};

export default TableView;
