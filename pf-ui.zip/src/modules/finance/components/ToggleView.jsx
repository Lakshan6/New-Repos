import PropTypes from 'prop-types';
import { ToggleButton } from 'primereact/togglebutton';
import { useCallback } from 'react';

const ToggleView = ({ value, onChange }) => {
    const handleChange = useCallback(
        (e) => {
            onChange(e.value ? 'TABLE' : 'TREE');
        },
        [onChange],
    );

    return (
        <ToggleButton
            checked={value === 'TABLE'}
            onChange={handleChange}
            className="p-button-sm"
            onLabel="Table"
            offLabel="Tree"
        />
    );
};

ToggleView.propTypes = {
    value: PropTypes.oneOf(['TABLE', 'TREE']).isRequired,
    onChange: PropTypes.func.isRequired,
};

export default ToggleView;
