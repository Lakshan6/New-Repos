import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { BreadCrumb } from 'primereact/breadcrumb';
import '../styles/CustomBreadcrumb.scss';

const Breadcrumb = ({ breadcrumbs, onNavigate }) => {
    const model = useMemo(
        () =>
            breadcrumbs.map((crumb, i) => ({
                label: crumb.label,
                icon: crumb.icon,
                command: () => onNavigate(i),
            })),
        [breadcrumbs, onNavigate],
    );

  return (
    <div className="app-breadcrumb">
      <BreadCrumb model={model} />
    </div>
  );
};

Breadcrumb.propTypes = {
    breadcrumbs: PropTypes.arrayOf(
        PropTypes.shape({
            label: PropTypes.string.isRequired,
            icon: PropTypes.string,
        }),
    ).isRequired,
    onNavigate: PropTypes.func.isRequired,
};

export default Breadcrumb;
