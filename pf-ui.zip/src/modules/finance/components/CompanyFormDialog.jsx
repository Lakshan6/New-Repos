import { Dialog } from 'primereact/dialog';
import DynamicForm from './customComponents/CustomForm';
import PropTypes from 'prop-types';
import { useMemo } from 'react';

const DIALOG_STYLE = { width: '450px' };
const CompanyFormDialog = ({
    visible,
    onHide,
    onSubmit,
    loading,
    initialValues,
    mode, // 'CREATE' | 'UPDATE'
    formDefinition,
    formOptions,
}) => {
    const resolvedDefinition = useMemo(
        () => ({
            ...formDefinition,
            submitLabel: mode === 'CREATE' ? 'Create' : 'Update',
        }),
        [formDefinition, mode],
    );
    return (
        <Dialog
            header={mode === 'CREATE' ? 'Create Company' : 'Update Company'}
            visible={visible}
            onHide={onHide}
            modal
            style={DIALOG_STYLE}
        >
            <DynamicForm
                definition={resolvedDefinition}
                initialValues={initialValues}
                loading={loading}
                onSubmit={onSubmit}
                formOptions={formOptions}
            />
        </Dialog>
    );
};

CompanyFormDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
    onSubmit: PropTypes.func.isRequired,
    loading: PropTypes.bool,
    initialValues: PropTypes.object,
    mode: PropTypes.oneOf(['CREATE', 'UPDATE']).isRequired,
    formDefinition: PropTypes.object.isRequired,
    formOptions: PropTypes.object,
};

export default CompanyFormDialog;
