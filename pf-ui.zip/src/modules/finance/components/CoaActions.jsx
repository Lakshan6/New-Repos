import PropTypes from 'prop-types';
import { Button } from 'primereact/button';

const CoaActions = ({ onExport, onCreate, onDelete, exportDisabled }) => {
    return (
        <div className="flex gap-2">
            <Button
                label="Export"
                icon="pi pi-download"
                className="p-button-sm"
                severity="secondary"
                raised
                onClick={onExport}
                disabled={exportDisabled}
            />

            <Button
                label="Create"
                className="p-button-sm"
                icon="pi pi-plus"
                raised
                onClick={onCreate}
            />
            <Button
                label="Delete"
                className="p-button-sm"
                icon="pi pi-trash"
                severity="danger"
                raised
                onClick={onDelete}
            />
        </div>
    );
};

CoaActions.propTypes = {
    onExport: PropTypes.func.isRequired,
    onCreate: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    exportDisabled: PropTypes.bool,
};

CoaActions.defaultProps = {
    exportDisabled: false,
};

export default CoaActions;
