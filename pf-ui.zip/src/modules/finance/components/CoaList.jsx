import PropTypes from 'prop-types';
import { Dropdown } from 'primereact/dropdown';
import { useAtom } from 'jotai';
import { useCallback, useEffect, useState, useRef } from 'react';
import { selectedCoaAtom } from '../store/atoms';
import { useListCOA } from '../hooks/coa/useCOAApi';

const CoaList = ({ onChange, reloadKey, onOptionsLoaded }) => {
    const [selectedCoaId, setSelectedCoaId] = useAtom(selectedCoaAtom);
    const [coaOptions, setCoaOptions] = useState([]);
    const [isLoading, setIsLoading] = useState(false);
    const { fetchAllCoa } = useListCOA();
    const prevReloadKeyRef = useRef(-1);

    const loadCoaList = useCallback(async () => {
        setIsLoading(true);
        try {
            const data = await fetchAllCoa();
            if (data) {
                let items = [];
                if (Array.isArray(data)) items = data;
                else if (Array.isArray(data.coas)) items = data.coas;
                setCoaOptions(items);
                onOptionsLoaded?.(items); // 👈 pass items up to parent
            }
        } catch (error) {
            console.error('Failed to fetch COA list:', error);
        } finally {
            setIsLoading(false);
        }
    }, [fetchAllCoa, onOptionsLoaded]);

    useEffect(() => {
        if (reloadKey !== prevReloadKeyRef.current) {
            prevReloadKeyRef.current = reloadKey;
            loadCoaList();
        }
    }, [reloadKey, loadCoaList]);

    const handleChange = useCallback(
        (e) => {
            setSelectedCoaId(e.value);
            onChange?.(e.value); // ✅ safe optional call
        },
        [onChange, setSelectedCoaId],
    );

    return (
        <Dropdown
            id="coaDropdown"
            value={selectedCoaId}
            options={coaOptions}
            optionLabel="coaName"
            optionValue="coaId"
            placeholder="Select Chart of Accounts"
            className="w-30rem"
            onChange={handleChange}
            loading={isLoading}
        />
    );
};

CoaList.propTypes = {
    onChange: PropTypes.func,
    reloadKey: PropTypes.number,
    onOptionsLoaded: PropTypes.func,
};

CoaList.defaultProps = {
    onChange: () => {},
    reloadKey: 0,
    onOptionsLoaded: undefined,
};

export default CoaList;
