import { Dialog } from 'primereact/dialog';
import { InputText } from 'primereact/inputtext';
import { Dropdown } from 'primereact/dropdown';
import { Button } from 'primereact/button';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { useAtom } from 'jotai';
import { addAccountContextAtom } from '../store/atoms';
import { useEffect, useState, useCallback, useMemo, useRef } from 'react';
import { useCoaAccountApi } from '../hooks/coa/useCoaAccountApi';
import { useCOAData } from '../hooks/coa/useCOAApi';
import { getRequestInfo } from '../utils/getRequestinfo';
import { showSuccess, showError } from '../utils/snackbarUtils';
import CustomSnackbar from './customComponents/CustomSnackbar';

const ACCOUNT_TYPE_OPTIONS = [
    { label: 'Group', value: 'GROUP' },
    { label: 'Ledger', value: 'LEDGER' },
];

const REPORT_TYPE_OPTIONS = [
    { label: 'Balance Sheet', value: 'BALANCE_SHEET' },
    { label: 'Income Statement', value: 'INCOME_STATEMENT' },
];

const ACCOUNT_GROUP_OPTIONS = [
    { label: 'Assets', value: 'ASSETS' },
    { label: 'Liability', value: 'LIABILITY' },
    { label: 'Equity', value: 'EQUITY' },
    { label: 'Income', value: 'INCOME' },
    { label: 'Expense', value: 'EXPENSE' },
];

const EMPTY_FORM = {
    code: '',
    name: '',
    type: 'GROUP',
    ledgerType: '',
    coaId: '',
    reportType: '',
    accountGroup: '',
};

const AddAccountDialog = () => {
    const [context, setContext] = useAtom(addAccountContextAtom);
    const { createAccount, updateAccount, deleteAccount, isCreating, isUpdating, isDeleting } =
        useCoaAccountApi();
    const { refreshCOA } = useCOAData();

    const isAdd = context?.mode === 'ADD';
    const isEdit = context?.mode === 'EDIT' && !!context?.account;
    const isDelete = context?.mode === 'DELETE';

    const [form, setForm] = useState(EMPTY_FORM);
    const toastRef = useRef(null);
    const dialogStyle = useMemo(() => ({ width: '32rem' }), []);

    const closeContext = useCallback(() => setContext(null), [setContext]);

    const handleChange = useCallback(
        (field) => (e) => {
            const value = e.target !== undefined ? e.target.value : e.value;
            setForm((prev) => ({ ...prev, [field]: value }));
        },
        [],
    );

    /* ---------------- initialize form ---------------- */
    useEffect(() => {
        if (!context || isDelete) return;

        if (isEdit && context.account) {
            setForm({
                code: context.account.code,
                name: context.account.name,
                type: context.account.isGroup ? 'GROUP' : 'LEDGER',
                ledgerType: context.account.ledgerType || '',
                coaId: context.coaId || '',
                reportType: context.account.reportType || '',
                accountGroup: context.account.accountGroup || '',
            });
        } else {
            setForm(EMPTY_FORM);
        }
    }, [context, isEdit, isDelete]);

    /* ---------------- delete handler ---------------- */
    const handleDeleteAccept = useCallback(() => {
        deleteAccount(
            {
                coaId: context?.coaId,
                glId: context.code,
                requestInfo: getRequestInfo(),
            },
            {
                onSuccess: () => {
                    showSuccess(toastRef, 'Account deleted successfully');
                    closeContext();
                    refreshCOA();
                },
                onError: (err) => {
                    showError(
                        toastRef,
                        `Failed to delete account: ${err?.message || 'Unknown error'}`,
                    );
                },
            },
        );
    }, [context, deleteAccount, closeContext, refreshCOA]);

    /* ---------------- save handler ---------------- */
    const onSave = useCallback(() => {
        if (isAdd && !form.code.trim()) return;

        const payload = {
            coaId: context?.coaId || 'DEFAULT_COA',
            account: {
                glId: form.code,
                glName: form.name,
                glType: form.type,
                parentGlId: context?.parentCode || null,
                levelNo: context?.levelNo ? context.levelNo + 1 : 1,
                isGroup: form.type === 'GROUP' ? 'Y' : 'N',
                reportType: form.reportType || null,
                accountGroup: form.accountGroup || null,
            },
            requestInfo: getRequestInfo(),
        };

        if (isEdit) {
            updateAccount(payload, {
                onSuccess: () => {
                    showSuccess(toastRef, 'Account updated successfully');
                    closeContext();
                    refreshCOA();
                },
                onError: (err) => {
                    showError(
                        toastRef,
                        `Failed to update account: ${err?.message || 'Unknown error'}`,
                    );
                },
            });
        } else {
            createAccount(payload, {
                onSuccess: () => {
                    showSuccess(toastRef, 'Account created successfully');
                    closeContext();
                    refreshCOA();
                },
                onError: (err) => {
                    showError(
                        toastRef,
                        `Failed to create account: ${err?.message || 'Unknown error'}`,
                    );
                },
            });
        }
    }, [form, isAdd, isEdit, context, createAccount, updateAccount, closeContext, refreshCOA]);

    const isCodeInvalid = isAdd && !form.code.trim();

    return (
        <>
            <CustomSnackbar ref={toastRef} />

            <ConfirmDialog
                visible={isDelete}
                header="Confirm Delete"
                message={
                    <div className="flex align-items-start gap-3">
                        <i className="pi pi-exclamation-triangle text-red-600" />
                        <span>
                            Are you sure you want to delete <b>{context?.account?.label}</b>?<br />
                            <small className="text-color-secondary">
                                This action cannot be undone.
                            </small>
                        </span>
                    </div>
                }
                acceptLabel="Delete"
                rejectLabel="Cancel"
                rejectClassName="p-button-text p-button-md"
                acceptClassName="p-button-danger p-button-md"
                defaultFocus="reject"
                onHide={closeContext}
                accept={handleDeleteAccept}
                reject={closeContext}
            />

            <Dialog
                header={isEdit ? 'Edit Account' : 'Add Account'}
                visible={!!(isAdd || isEdit)}
                onHide={closeContext}
                style={dialogStyle}
                modal
            >
                <div className="mb-3">
                    <label htmlFor="account-code">
                        Code <span className="text-red-500">*</span>
                    </label>
                    <InputText
                        id="account-code"
                        value={form.code}
                        disabled={isEdit}
                        onChange={handleChange('code')}
                        className={`w-full ${isCodeInvalid ? 'p-invalid' : ''}`}
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="account-name">Name</label>
                    <InputText
                        id="account-name"
                        value={form.name}
                        onChange={handleChange('name')}
                        className="w-full"
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="account-type">Account Type</label>
                    <Dropdown
                        inputId="account-type"
                        value={form.type}
                        disabled={isEdit}
                        options={ACCOUNT_TYPE_OPTIONS}
                        onChange={handleChange('type')}
                        className="w-full"
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="report-type">Report Type</label>
                    <Dropdown
                        inputId="report-type"
                        value={form.reportType}
                        disabled={isEdit}
                        options={REPORT_TYPE_OPTIONS}
                        onChange={handleChange('reportType')}
                        className="w-full"
                    />
                </div>

                <div className="mb-3">
                    <label htmlFor="account-group">Account Group</label>
                    <Dropdown
                        inputId="account-group"
                        value={form.accountGroup}
                        disabled={isEdit}
                        options={ACCOUNT_GROUP_OPTIONS}
                        onChange={handleChange('accountGroup')}
                        className="w-full"
                    />
                </div>

                <div className="flex justify-content-end gap-2">
                    <Button label="Cancel" className="p-button-text" onClick={closeContext} />
                    <Button
                        label={isEdit ? 'Update' : 'Save'}
                        onClick={onSave}
                        loading={isCreating || isUpdating || isDeleting}
                        disabled={isCodeInvalid}
                    />
                </div>
            </Dialog>
        </>
    );
};

export default AddAccountDialog;
