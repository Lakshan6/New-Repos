import PropTypes from 'prop-types';
import { SplitButton } from 'primereact/splitbutton';
import { useExportCOA } from '../hooks/coa/useCOAApi';

const CoaExport = ({ onImport }) => {
    const { exportCOA, isPending } = useExportCOA();
    const menuItems = [
        {
            label: 'Import from Excel',
            icon: 'pi pi-upload',
            command: onImport,
        },
    ];

    return (
        <SplitButton
            label="Export to Excel"
            icon="pi pi-file-excel"
            model={menuItems}
            className="p-button-sm"
            onClick={exportCOA}
            disabled={isPending}
        />
    );
};

CoaExport.propTypes = {
    onImport: PropTypes.func.isRequired,
};

export default CoaExport;
