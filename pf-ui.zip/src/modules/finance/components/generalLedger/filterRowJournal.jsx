import { Dropdown } from 'primereact/dropdown';
import { Calendar } from 'primereact/calendar';
import { Button } from 'primereact/button';
import { useCallback, useState } from 'react';
import PropTypes from 'prop-types';

const statusOptions = [
    { label: 'All', value: 'ALL' },
    { label: 'Draft', value: 'Draft' },
    { label: 'Posted', value: 'Posted' },
    { label: 'Cancelled', value: 'Cancelled' },
];

const JournalFilters = ({ onChange }) => {
    const [status, setStatus] = useState('ALL');
    const [fromDate, setFromDate] = useState(null);
    const [toDate, setToDate] = useState(null);

    const handleSubmit = useCallback(() => {
        onChange?.({
            status,
            fromDate,
            toDate,
        });
    }, [onChange, status, fromDate, toDate]);

    const handleClear = useCallback(() => {
        setStatus('ALL');
        setFromDate(null);
        setToDate(null);

        onChange?.({
            status: 'ALL',
            fromDate: null,
            toDate: null,
        });
    }, [onChange]);

    const handleStatusChange = useCallback((e) => {
        setStatus(e.value);
    }, []);
    const handleFromDateChange = useCallback((e) => {
        setFromDate(e.value);
    }, []);
    const handleToDateChange = useCallback((e) => {
        setToDate(e.value);
    }, []);



    return (
        <div className="journal-filter-row">
            <div className="filter-item">
                <label htmlFor="status">Status:</label>
                <Dropdown value={status} options={statusOptions} onChange={handleStatusChange} />
            </div>

            <div className="filter-item">
                <label htmlFor="fromDate">From Date:</label>
                <Calendar
                    value={fromDate}
                    onChange={handleFromDateChange}
                    showIcon
                    dateFormat="dd/mm/yy"
                />
            </div>

            <div className="filter-item">
                <label htmlFor="toDate">To Date:</label>
                <Calendar
                    value={toDate}
                    onChange={handleToDateChange}
                    showIcon
                    dateFormat="dd/mm/yy"
                />
            </div>
            <div className="filter-item">
                <Button className="button-row" onClick={handleSubmit}>
                    Submit
                </Button>
            </div>
            <div className="filter-item">
                <Button className="button-row" onClick={handleClear}>
                    Clear
                </Button>
            </div>
        </div>
    );
};
JournalFilters.propTypes = {
    onChange: PropTypes.func,
};

export default JournalFilters;
