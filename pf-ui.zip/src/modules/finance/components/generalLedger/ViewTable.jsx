import PropTypes from 'prop-types';
import CustomTable from '../../components/customComponents/CustomTable';
import '../../styles/Jscreen.scss';
import { useMemo } from 'react';

const JournalPreviewTable = ({ rows = [] }) => {
    const columns = useMemo(
        () => [
            {
                field: 'glId',
                header: 'GL ID',
                sortable: true,
            },
            {
                field: 'account',
                header: 'Account',
                sortable: true,
            },
            {
                field: 'debit',
                header: 'Debit',
                body: (row) => (row.type === 'D' ? row.amount : '-'),
            },
            {
                field: 'credit',
                header: 'Credit',
                body: (row) => (row.type === 'C' ? row.amount : '-'),
            },
        ],
        [],
    );

    return (
        <CustomTable
            data={rows}
            columns={columns}
            paginator={false}
            loading={false}
            dataKey="glId"
            globalFilterFields={[]}
        />
    );
};

JournalPreviewTable.propTypes = {
    rows: PropTypes.arrayOf(
        PropTypes.shape({
            glId: PropTypes.string,
            account: PropTypes.string,
            amount: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
            type: PropTypes.string,
        }),
    ),
};

export default JournalPreviewTable;
