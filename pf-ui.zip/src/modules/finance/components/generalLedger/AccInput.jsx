import React, { useState, useCallback } from 'react';
import { AutoComplete } from 'primereact/autocomplete';
import useGetaccount from '../../hooks/GL/useGetaccount';
import PropTypes from 'prop-types';
import blockEnter from './BlockEnter';
const AccInput = ({ value, onSelect, onChangeText, uuid, coaId }) => {
    const { accounts } = useGetaccount({
        uuid,
        coaId,
        enabled: true,
    });

    const [filteredAccounts, setFilteredAccounts] = useState([]);

    const searchAccounts = useCallback(
        (event) => {
            const query = event.query?.toLowerCase() || '';

            const filtered = accounts.filter((acc) => acc.glName.toLowerCase().includes(query));
            setFilteredAccounts(filtered);
        },
        [accounts],
    );

    const handleChange = useCallback(
        (e) => {
            const text = e.value ?? '';

            onChangeText(text);
            searchAccounts({ query: text });
        },
        [onChangeText, searchAccounts],
    );

    const handleSelect = useCallback(
        (e) => {
            const account = e.value;

            onSelect(account);
            onChangeText(account.glName);
        },
        [onSelect, onChangeText],
    );

    return (
        <AutoComplete
            value={value || ''}
            suggestions={filteredAccounts}
            completeMethod={searchAccounts}
            field="glName"
            placeholder="Select Account"
            className="w-full"
            onChange={handleChange}
            onSelect={handleSelect}
            onKeyDown={blockEnter}
        />
    );
};

AccInput.propTypes = {
    value: PropTypes.string,
    onSelect: PropTypes.func.isRequired,
    onChangeText: PropTypes.func.isRequired,
    uuid: PropTypes.string.isRequired,
    coaId: PropTypes.string.isRequired,
    placeholder: PropTypes.string,
};

export default AccInput;
