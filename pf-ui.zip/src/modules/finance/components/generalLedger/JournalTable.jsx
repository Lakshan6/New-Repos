import React, { useState, useEffect, useCallback } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import CellEditor from './Editors';
import PropTypes from 'prop-types';
import AccInput from './AccInput';
import { getParsedLocalStorageItem } from '@shared/utils/common';
const userDetails = getParsedLocalStorageItem('userDetails', {});
const UUID = (userDetails.userInfo || userDetails)?.uuid || '';



const numberColumnStyle = {
    width: '60px',
    textAlign: 'center',
};

const accountColumnStyle = {
    width: '20%',
};

const actionsColumnStyle = {
    width: '120px',
    textAlign: 'center',
};

const JournalTable = ({ onTotalsChange, onRowsChange, resetKey, coaId }) => {
    const [rows, setRows] = useState([
        {
            id: 1,
            account: '',
            debit: null,
            credit: null,
        },
    ]);
    console.log(coaId + "i am");

    const addRow = useCallback(() => {
        setRows((prev) => [
            ...prev,
            {
                id: Date.now(),
                account: '',
                debit: null,
                credit: null,
            },
        ]);
    }, []);

    const totalDebit = rows.reduce((sum, row) => sum + (Number(row.debit) || 0), 0);

    const totalCredit = rows.reduce((sum, row) => sum + (Number(row.credit) || 0), 0);

    useEffect(() => {
        if (onRowsChange) {
            onRowsChange(rows);
        }
    }, [rows, onRowsChange]);

    useEffect(() => {
        onTotalsChange({
            totalDebit,
            totalCredit,
        });
    }, [totalDebit, totalCredit, onTotalsChange]);

    // ✅ reset table ONLY when parent submits
    useEffect(() => {
        setRows([{ id: Date.now(), account: '', debit: null, credit: null }]);

        onTotalsChange({
            totalDebit: 0,
            totalCredit: 0,
        });
    }, [resetKey, onTotalsChange]);

    const rowNumberTemplate = useCallback((_, options) => options.rowIndex + 1, []);

    const deleteRow = useCallback(
        (rowIndex) => {
            setRows((prev) => prev.filter((_, i) => i !== rowIndex));
        },
        [setRows],
    );

    const handleDeleteClick = useCallback(
        (e) => {
            e.preventDefault();
            e.stopPropagation();

            const rowIndex = Number(e.currentTarget.dataset.rowIndex);
            deleteRow(rowIndex);
        },
        [deleteRow],
    );

    const actionsBodyTemplate = useCallback(
        (rowData, options) => (
            <div className="flex gap-2 justify-center">
                <Button
                    icon="pi pi-trash"
                    rounded
                    text
                    severity="danger"
                    tabIndex={-1}
                    data-row-index={options.rowIndex}
                    onClick={handleDeleteClick}
                />
            </div>
        ),
        [handleDeleteClick],
    );

    const accountEditor = useCallback(
        (options) => (
            <CellEditor
                rowIndex={options.rowIndex}
                field={options.field}
                rows={rows}
                setRows={setRows}
            />
        ),
        [rows, setRows],
    );

    const handleAccountChangeText = useCallback(
        (options, rowIndex) => (text) => {
            const safeText = typeof text === 'string' ? text : (text?.glName ?? '');

            options.editorCallback(safeText);

            setRows((prev) => {
                const updated = [...prev];
                updated[rowIndex] = {
                    ...updated[rowIndex],
                    accountName: safeText,
                    accountId: null,
                };
                return updated;
            });
        },
        [setRows],
    );

    const handleAccountSelect = useCallback(
        (options, rowIndex) => (account) => {
            options.editorCallback(account.glName);

            setRows((prev) => {
                const updated = [...prev];
                updated[rowIndex] = {
                    ...updated[rowIndex],
                    accountId: account.glId,
                    accountName: account.glName,
                };
                return updated;
            });
        },
        [setRows],
    );

    const accountEditor1 = useCallback(
        (options) => {
            const rowIndex = options.rowIndex;

            return (
                <AccInput
                    uuid={UUID}
                    coaId={coaId}
                    value={options.value ?? ''}
                    onChangeText={handleAccountChangeText(options, rowIndex)}
                    onSelect={handleAccountSelect(options, rowIndex)}
                />
            );
        },
        [handleAccountChangeText, handleAccountSelect,coaId],
    );

    return (
        <div>
            <DataTable
                value={rows}
                dataKey="id"
                editMode="cell"
                showGridlines
                size="small"
                scrollable
                className="journal-table"
            >
                <Column header="No" body={rowNumberTemplate} style={numberColumnStyle} />
                <Column
                    field="accountName"
                    header="Account"
                    style={accountColumnStyle}
                    editor={accountEditor1}
                />

                <Column
                    field="debit"
                    header="Debit"
                    style={accountColumnStyle}
                    editor={accountEditor}
                />

                <Column
                    field="credit"
                    header="Credit"
                    style={accountColumnStyle}
                    editor={accountEditor}
                />

                <Column header="Actions" style={actionsColumnStyle} body={actionsBodyTemplate} />
            </DataTable>
            <div className="grid">
                <div className="col-12 md:col-1">
                    <Button
                        label="Add Row"
                        className="button_addrow  mt-2 "
                        type="button"
                        onClick={addRow}
                    />
                </div>
            </div>
        </div>
    );
};

JournalTable.propTypes = {
    onTotalsChange: PropTypes.func.isRequired,
    resetKey: PropTypes.number,
    onRowsChange: PropTypes.func.isRequired,
    coaId: PropTypes.string.isRequired,
};

export default JournalTable;
