import { useState, useCallback, useMemo } from 'react';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { Calendar } from 'primereact/calendar';
import { InputText } from 'primereact/inputtext';
import PropTypes from 'prop-types';

const initialState = {
    postingDate: new Date(),
    reversalDate: null,
    reason: '',
};

const ReversalDialog = ({ visible, onHide, onPost }) => {
    const [form, setForm] = useState(initialState);

    const dialogStyle = useMemo(() => ({ width: '30rem' }), []);

    // Format date yyyy-MM-dd
    const formatDate = useCallback((date) => {
        if (!date) return null;
        return date.toISOString().split('T')[0];
    }, []);

    const handlePostingDateChange = useCallback((e) => {
        setForm((prev) => ({ ...prev, postingDate: e.value }));
    }, []);

    const handleReversalDateChange = useCallback((e) => {
        setForm((prev) => ({ ...prev, reversalDate: e.value }));
    }, []);

    const handleReasonChange = useCallback((e) => {
        setForm((prev) => ({ ...prev, reason: e.target.value }));
    }, []);

    const handlePost = useCallback(() => {
        const payload = {
            postingDate: formatDate(form.postingDate),
            reversalDate: formatDate(form.reversalDate),
            reason: form.reason.trim(),
        };

        onPost(payload);
        setForm(initialState);
        onHide();
    }, [form, formatDate, onPost, onHide]);

    const handleHide = useCallback(() => {
        setForm(initialState);
        onHide();
    }, [onHide]);

    return (
        <Dialog header="Reversal" visible={visible} style={dialogStyle} modal onHide={handleHide}>
            <div className="p-fluid">
                <div className="field">
                    <label htmlFor="postingDate">Posting Date</label>
                    <Calendar
                        value={form.postingDate}
                        onChange={handlePostingDateChange}
                        dateFormat="yy-mm-dd"
                    />
                </div>

                <div className="field">
                    <label htmlFor="reversalDate">Reversal Date</label>
                    <Calendar
                        value={form.reversalDate}
                        onChange={handleReversalDateChange}
                        dateFormat="yy-mm-dd"
                    />
                </div>

                <div className="field">
                    <label htmlFor="reason">Reversal Reason</label>
                    <InputText value={form.reason} onChange={handleReasonChange} />
                </div>

                <div className="flex justify-content-end mt-4 gap-2">
                    <Button label="Cancel" text onClick={handleHide} />
                    <Button
                        label="Post"
                        icon="pi pi-check"
                        onClick={handlePost}
                        disabled={!form.reversalDate}
                    />
                </div>
            </div>
        </Dialog>
    );
};

ReversalDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
    onPost: PropTypes.func.isRequired,
};

export default ReversalDialog;
