const blockEnter = (e) => {
    if (e.key === 'Enter') {
        e.preventDefault();
        return false;
    }
};
export default blockEnter;
