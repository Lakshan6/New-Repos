import PropTypes from 'prop-types';
import { useMemo } from 'react';
import CustomTable from '../../components/customComponents/CustomTable';

const ViewJournalTable = ({ rows = [], onActionClick }) => {
    /* 
       🔥 CRITICAL FIX
       PrimeReact DataTable + scrollable requires
       stable & unique dataKey.
    */
    const tableData = useMemo(() => {
        return rows.map((row, index) => ({
            ...row,
            id: `${row.glId}-${row.journalEntryNo}-${index}`, // guaranteed unique
        }));
    }, [rows]);

    const columns = useMemo(
        () => [
            {
                field: 'glId',
                header: 'GL ID',
                sortable: true,
            },
            {
                field: 'journalEntryNo',
                header: 'Journal Entry No.',
                sortable: true,
                isLink: true,
                onClick: (row) => onActionClick?.(row),
            },
            {
                field: 'documentNo',
                header: 'Document No.',
                sortable: true,
            },
            {
                field: 'postingDate',
                header: 'Posting Date',
                sortable: true,
            },
            {
                field: 'status',
                header: 'Status',
                sortable: true,
            },
            {
                field: 'referenceNo',
                header: 'Reference No.',
                sortable: true,
            },
            {
                field: 'amountD',
                header: 'Debit',
                sortable: true,
               // body: (row) => (row.debitCredit === 'Debit' ? (row.amount ?? '-') : '-'),
            },
            {
                field: 'amountC',
                header: 'Credit',
                sortable: true,
              //  body: (row) => (row.debitCredit === 'Credit' ? (row.amount ?? '-') : '-'),
            },
        ],
        [onActionClick],
    );

    const actions = useMemo(
        () => ({
            custom: [
                {
                    label: 'View',
                    icon: 'pi pi-eye',
                    severity: 'primary',
                    callback: (row) => onActionClick?.(row),
                },
            ],
        }),
        [onActionClick],
    );

    return (
        <CustomTable
            data={tableData}
            columns={columns}
            paginator
            rows={10}
            dataKey="id" // 👈 MUST match mapped id
            globalFilterFields={[
                'glId',
                'journalEntryNo',
                'documentNo',
                'postingDate',
                'status',
                'referenceNo',
            ]}
            actions={actions}
        />
    );
};

ViewJournalTable.propTypes = {
    rows: PropTypes.array,
    onActionClick: PropTypes.func,
};

export default ViewJournalTable;
