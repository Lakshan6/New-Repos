import { useCallback } from 'react';
import { InputText } from 'primereact/inputtext';
import { InputNumber } from 'primereact/inputnumber';
import '../../styles/Jscreen.scss';
import PropTypes from 'prop-types';
import blockEnter from './BlockEnter';

const CellEditor = ({ rowIndex, field, rows, setRows }) => {
    const row = rows[rowIndex];
    const value = row[field];
    const handleKeyDown = (e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            e.stopPropagation();
            return false;
        }
    };
    const isDebit = field === 'debit';
    const isCredit = field === 'credit';

    const disabled = (isDebit && row.credit > 0) || (isCredit && row.debit > 0);

    const updateRow = useCallback(
        (newValue) => {
            setRows((prev) => {
                const updated = [...prev];

                updated[rowIndex] = {
                    ...updated[rowIndex],
                    [field]: newValue,
                    ...(isDebit && newValue ? { credit: null } : {}),
                    ...(isCredit && newValue ? { debit: null } : {}),
                };

                return updated;
            });
        },
        [rowIndex, field, isDebit, isCredit, setRows],
    );

    const handleNumberChange = useCallback((e) => updateRow(e.value), [updateRow]);

    const handleTextChange = useCallback((e) => updateRow(e.target.value), [updateRow]);

    if (isDebit || isCredit) {
        return (
            <InputNumber
                value={value}
                onValueChange={handleNumberChange}
                disabled={disabled}
                min={0}
                mode="decimal"
                onKeyDownCapture={handleKeyDown}
                useGrouping={false}
                className={`w-full ${disabled ? 'cell-disabled' : ''}`}
            />
        );
    }

    return <InputText value={value || ''} onChange={handleTextChange} onKeyDown={blockEnter} />;
};

CellEditor.propTypes = {
    rowIndex: PropTypes.number.isRequired,
    field: PropTypes.oneOf(['account', 'debit', 'credit']).isRequired,
    rows: PropTypes.arrayOf(
        PropTypes.shape({
            id: PropTypes.oneOfType([PropTypes.number, PropTypes.string]),
            account: PropTypes.string,
            debit: PropTypes.oneOfType([PropTypes.number, PropTypes.null]),
            credit: PropTypes.oneOfType([PropTypes.number, PropTypes.null]),
        }),
    ).isRequired,
    setRows: PropTypes.func.isRequired,
};

export default CellEditor;
