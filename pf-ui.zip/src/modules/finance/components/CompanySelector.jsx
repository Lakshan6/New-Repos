import PropTypes from 'prop-types';
import { Dropdown } from 'primereact/dropdown';
import { useAtom } from 'jotai';
import { useEffect, useState, useCallback } from 'react';
import { selectedCompanyAtom } from '../store/atoms';
import { useSearchCompany } from '../hooks/company/useCompanyApi';

const CompanySelector = ({ onChange, reloadKey }) => {
    const [selectedCompany, setSelectedCompany] = useAtom(selectedCompanyAtom);
    const [companies, setCompanies] = useState([]);
    const [loading, setLoading] = useState(false);

    const { fetchAllCompanies } = useSearchCompany();

    const loadCompanies = useCallback(async () => {
        try {
            setLoading(true);
            const response = await fetchAllCompanies();
            setCompanies(Array.isArray(response) ? response : []);
        } catch (err) {
            console.error('Failed to load companies', err);
        } finally {
            setLoading(false);
        }
    }, [fetchAllCompanies]);

    useEffect(() => {
        loadCompanies();
    }, [reloadKey, loadCompanies]);

    const handleChange = useCallback(
        (e) => {
            setSelectedCompany(e.value);
            onChange(e.value);
        },
        [onChange, setSelectedCompany],
    );

    return (
        <div>
            <Dropdown
                id="companyDropdown"
                value={selectedCompany}
                options={companies}
                optionLabel="name"
                placeholder="Select Company"
                className="w-30rem"
                onChange={handleChange}
                loading={loading}
                filter
                showClear
            />
            {/* <CustomTable data={companies} columns={companyColumns} />
            <CustomTable
                data={companies}
                columns={companyColumns}
                actions={{
                    edit: openEditCompany,
                    delete: openDeleteCompany,
                }}
            /> */}
        </div>
    );
};

CompanySelector.propTypes = {
    onChange: PropTypes.func,
    reloadKey: PropTypes.number,
};

CompanySelector.defaultProps = {
    onChange: () => {},
    reloadKey: 0,
};

export default CompanySelector;
