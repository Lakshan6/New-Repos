import { Tree } from 'primereact/tree';
import { Button } from 'primereact/button';
import { ConfirmDialog } from 'primereact/confirmdialog';
import { useAtom } from 'jotai';
import { coaTreeAtom, coaExpandedKeysAtom, addAccountContextAtom } from '../store/atoms';
import '../styles/TreeView.scss';
import { useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';

const mapToTreeNodes = (nodes = [], level = 0, parent = null) =>
    nodes.map((node) => ({
        key: node.code,
        code: node.code,
        name: node.name,
        label: `${node.code} - ${node.name}`,
        isGroup: node.isGroup,
        level,
        isAccountType: level === 0,
        parentCode: parent?.code || null,
        parentLabel: parent ? `${parent.code} - ${parent.name}` : '—',
        reportType: node.reportType || null,
        accountGroup: node.accountGroup || null,
        coaId: node.coaId || null,
        children: mapToTreeNodes(node.children || [], level + 1, node),
    }));

const collectExpandedKeys = (nodes = [], expanded = {}) => {
    nodes.forEach((node) => {
        expanded[node.key] = true;
        if (node.children?.length) {
            collectExpandedKeys(node.children, expanded);
        }
    });
    return expanded;
};

const nodePropType = PropTypes.shape({
    key: PropTypes.string,
    code: PropTypes.string,
    name: PropTypes.string,
    label: PropTypes.string,
    isGroup: PropTypes.bool,
    isAccountType: PropTypes.bool,
    level: PropTypes.number,
    coaId: PropTypes.string,
    reportType: PropTypes.string,
    accountGroup: PropTypes.string,
    ledgerType: PropTypes.string,
    parentCode: PropTypes.string,
    parentLabel: PropTypes.string,
});

const TreeNodeTemplate = ({ node, expandedKeys, onAdd, onEdit, onDelete }) => {
    const iconClass = node.isGroup
        ? expandedKeys[node.key]
            ? 'pi pi-folder-open'
            : 'pi pi-folder'
        : 'pi pi-book';

    const handleAdd = useCallback((e) => onAdd(node, e), [node, onAdd]);
    const handleEdit = useCallback((e) => onEdit(node, e), [node, onEdit]);
    const handleDelete = useCallback((e) => onDelete(node, e), [node, onDelete]);

    return (
        <div className="flex align-items-center justify-content-between w-full">
            <div className="flex align-items-center gap-2">
                <i className={iconClass} />
                <span>{node.label}</span>

                <div className="flex align-items-center gap-2 coa-actions">
                    {node.isGroup && (
                        <Button label="Add" link className="p-0 coa-add" onClick={handleAdd} />
                    )}
                    {!node.isAccountType && (
                        <Button label="Edit" link className="p-0 coa-edit" onClick={handleEdit} />
                    )}
                    {!node.isAccountType && (
                        <Button
                            label="Delete"
                            link
                            className="p-0 coa-delete"
                            onClick={handleDelete}
                        />
                    )}
                </div>
            </div>
        </div>
    );
};

TreeNodeTemplate.propTypes = {
    node: nodePropType.isRequired,
    expandedKeys: PropTypes.objectOf(PropTypes.bool).isRequired,
    onAdd: PropTypes.func.isRequired,
    onEdit: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
};

const TreeView = () => {
    const [coaTree] = useAtom(coaTreeAtom);
    const [expandedKeys, setExpandedKeys] = useAtom(coaExpandedKeysAtom);
    const [, setContext] = useAtom(addAccountContextAtom);

    const onAdd = useCallback(
        (node, e) => {
            e.stopPropagation();
            setContext({
                mode: 'ADD',
                parentCode: node.code,
                parentLabel: node.label,
                reportType: node.reportType,
                coaId: node.coaId,
                levelNo: node.level,
                account: null,
            });
        },
        [setContext],
    );

    const onEdit = useCallback(
        (node, e) => {
            e.stopPropagation();
            if (node.isAccountType) return;
            setContext({
                mode: 'EDIT',
                parentCode: node.parentCode,
                parentLabel: node.parentLabel,
                reportType: node.reportType,
                coaId: node.coaId,
                levelNo: node.level,
                account: {
                    code: node.code,
                    name: node.name,
                    isGroup: node.isGroup,
                    ledgerType: node.ledgerType,
                    reportType: node.reportType || '',
                    accountGroup: node.accountGroup || '',
                },
            });
        },
        [setContext],
    );

    const onDelete = useCallback(
        (node, e) => {
            e.stopPropagation();
            if (node.isAccountType) return;
            setContext({
                mode: 'DELETE',
                coaId: node.coaId,
                code: node.code,
                // account: {
                //     code: node.code,
                //     name: node.name,
                //     label: node.label,
                // },
            });
        },
        [setContext],
    );

    const handleToggle = useCallback((e) => setExpandedKeys(e.value), [setExpandedKeys]);

    const treeNodes = useMemo(() => mapToTreeNodes(coaTree), [coaTree]);

    const nodeTemplate = useCallback(
        (node) => (
            <TreeNodeTemplate
                node={node}
                expandedKeys={expandedKeys}
                onAdd={onAdd}
                onEdit={onEdit}
                onDelete={onDelete}
            />
        ),
        [expandedKeys, onAdd, onEdit, onDelete],
    );

    const expandAll = useCallback(
        () => setExpandedKeys(collectExpandedKeys(treeNodes)),
        [treeNodes, setExpandedKeys],
    );
    const collapseAll = useCallback(() => setExpandedKeys({}), [setExpandedKeys]);

    return (
        <div className="coa-tree">
            <ConfirmDialog />

            <div className="flex gap-2 mb-2">
                <Button label="Expand All" size="small" severity="primary" onClick={expandAll} />
                <Button
                    label="Collapse All"
                    size="small"
                    severity="secondary"
                    onClick={collapseAll}
                />
            </div>

            <Tree
                value={treeNodes}
                expandedKeys={expandedKeys}
                onToggle={handleToggle}
                nodeTemplate={nodeTemplate}
            />
        </div>
    );
};

export default TreeView;
