import PropTypes from 'prop-types';
import '../styles/FieldWrapper.scss';

const FieldWrapper = ({ label, required, children }) => {
    return (
        <div className="flex flex-column gap-1">
            <label className={`field-label ${label ? '' : 'hidden'}`}>
                {label || 'placeholder'}
                {required && <span className="field-label__required">*</span>}
            </label>
            {children}
        </div>
    );
};

FieldWrapper.propTypes = {
    label: PropTypes.string,
    required: PropTypes.bool,
    children: PropTypes.node.isRequired,
};

FieldWrapper.defaultProps = {
    label: '',
    required: false,
};

export default FieldWrapper;
