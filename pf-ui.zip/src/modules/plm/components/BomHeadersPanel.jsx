import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';

import { Dialog } from 'primereact/dialog';

import { InputTextarea } from 'primereact/inputtextarea';
import { Menu } from 'primereact/menu';
import { useReadApi, useMutationApi } from '@shared/hooks';
import BomLayout from './BOMLayout'; // ← replaces BomVisualization
import MaterialDetailsDialog from './MaterialDetailsDialog';
import { useNavigate } from 'react-router';
// ── Style constants ───────────────────────────────────────────────────────────
// Wider dialog to accommodate tree table + viz side-by-side
const DIALOG_STYLE = { width: '70vw', maxWidth: '900px', height: '75vh' };
const TOOLTIP_LEFT = { position: 'right' };
const SKELETON_ROWS = Array.from({ length: 4 });
const COL_STYLE_BOMID = { minWidth: 100 };
const COL_STYLE_MATERIAL = { minWidth: 160 };
const COL_STYLE_SMALL = { minWidth: 90 };
const COL_STYLE_ACTION = { minWidth: 160 };
const TOOLTIP_OPTIONS = { position: 'top' };
const CONTENT_STYLE = {
    height: 'calc(80vh - 80px)',
    padding: 0,
};
// ── Legend colours ────────────────────────────────────────────────────────────
// ── Legend colours (Using PrimeReact Theme Variables) ──────────────────────────
const LEGEND_COLOURS = {
    finished: 'var(--green-600)',
    assembly: 'var(--blue-600)',
    part: 'var(--orange-600)',
    raw: 'var(--surface-500)',
};
const BOM_STATE_ACTIONS = {
    CREATED: [
        { action: 'CREATE', label: 'Submit for Review', icon: 'pi pi-send', severity: 'info' },
    ],
    IN_REVIEW: [
        {
            action: 'SENDFORAPPROVAL',
            label: 'Send for Approval',
            icon: 'pi pi-arrow-up-right',
            severity: 'success',
        },
        {
            action: 'REJECT',
            label: 'Reject',
            icon: 'pi pi-ban',
            severity: 'danger',
            outlined: true,
        },
    ],
    PENDING_FOR_APPROVAL: [
        {
            action: 'APPROVE',
            label: 'Approve',
            icon: 'pi pi-check-circle',
            severity: 'success',
        },
        {
            action: 'SENDBACK',
            label: 'Send Back for Review',
            icon: 'pi pi-replay',
            severity: 'warning',
            outlined: true,
        },
        {
            action: 'REJECT',
            label: 'Reject',
            icon: 'pi pi-ban',
            severity: 'danger',
            outlined: true,
        },
    ],
};
// ── Skeleton styles ───────────────────────────────────────────────────────────
const SKELETON_BASE = {
    height: 16,
    background:
        'linear-gradient(90deg, var(--surface-border) 25%, var(--surface-section) 50%, var(--surface-border) 75%)',
    backgroundSize: '200% 100%',
    animation: 'shimmer 1.4s infinite',
};
const SKELETON_FLEX_1 = { ...SKELETON_BASE, flex: 1 };
const SKELETON_FLEX_2 = { ...SKELETON_BASE, flex: 2 };
const STATUS_SEVERITY = {
    IN_REVIEW: 'info', // blue
    PENDING_FOR_APPROVAL: 'warning', // orange
    APPROVED: 'success', // green
};

const STATUS_LABEL = {
    IN_REVIEW: 'In Review',
    PENDING_FOR_APPROVAL: 'Pending for Approval',
    APPROVED: 'Approved',
};

// ── No-op handlers for read-only context menu on BomVisualization ─────────────
const NOOP = () => {};

// ════════════════════════════════════════════════════════════════════════════
//  Skeleton row
// ════════════════════════════════════════════════════════════════════════════
const SkeletonRow = () => (
    <div className="flex gap-3 align-items-center p-2">
        {SKELETON_ROWS.map((_, i) => (
            <div
                key={i}
                className="border-round"
                style={i === 1 ? SKELETON_FLEX_2 : SKELETON_FLEX_1}
            />
        ))}
    </div>
);

// ════════════════════════════════════════════════════════════════════════════
//  LEVEL_LABELS
// ════════════════════════════════════════════════════════════════════════════
const LEVEL_LABELS = ['Level 0', 'Level 1', 'Level 2', 'Level 3'];

// ════════════════════════════════════════════════════════════════════════════
//  transformTreeNode
// ════════════════════════════════════════════════════════════════════════════
const transformTreeNode = (apiNode, depth = 0, counter = { n: 0 }) => {
    if (!apiNode?.data) return null;
    counter.n += 1;

    const partNo = apiNode.data.partNo;

    return {
        key: `bom-view-${partNo}-${counter.n}`,
        label: apiNode.data.materialName || apiNode.data.description || partNo,
        data: {
            partNo,
            materialName: apiNode.data.materialName || '',
            description: apiNode.data.description || '—',
            qty: apiNode.data.qty,
            uom: apiNode.data.uom,
            type: apiNode.data.type || '—',
            typeCode: apiNode.data.typeCode ?? null,
            alternativeMaterial: apiNode.data.alternativeMaterial ?? '-',
            level: LEVEL_LABELS[depth] ?? `Level ${depth}`,
        },
        children: Array.isArray(apiNode.children)
            ? apiNode.children.map((c) => transformTreeNode(c, depth + 1, counter)).filter(Boolean)
            : [],
    };
};

// ════════════════════════════════════════════════════════════════════════════
//  resolveRootApiNode
// ════════════════════════════════════════════════════════════════════════════
const resolveRootApiNode = (resp) => {
    if (!resp) return null;
    if (resp?.data?.partNo) return { data: resp.data, children: resp.children ?? [] };
    if (resp?.data?.data?.partNo) return resp.data;
    if (resp?.partNo) return resp;
    return null;
};

// ════════════════════════════════════════════════════════════════════════════
//  collectPartNos
// ════════════════════════════════════════════════════════════════════════════
const collectPartNos = (apiNode, out = []) => {
    if (!apiNode?.data?.partNo) return out;
    out.push(apiNode.data.partNo);
    (apiNode.children ?? []).forEach((c) => collectPartNos(c, out));
    return out;
};

// ════════════════════════════════════════════════════════════════════════════
//  NodeEnricher
// ════════════════════════════════════════════════════════════════════════════
const NodeEnricher = ({ partNos, authHeaders, authToken, onMaterialLoaded, onDone }) => {
    const [index, setIndex] = useState(0);

    const { mutate } = useMutationApi({
        service: 'material',
        endpoint: '/material/_searchOne',
        method: 'POST',
        headers: authHeaders,
        options: {
            onSuccess: (resp) => {
                const record = resp?.data ?? resp ?? {};
                onMaterialLoaded(partNos[index], record);
                const next = index + 1;
                if (next >= partNos.length) onDone();
                else setIndex(next);
            },
            onError: () => {
                const next = index + 1;
                if (next >= partNos.length) onDone();
                else setIndex(next);
            },
        },
    });

    useEffect(() => {
        if (index < partNos.length) {
            mutate({ requestInfo: { authToken }, materialCode: partNos[index] });
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [index]);

    return null;
};

NodeEnricher.propTypes = {
    partNos: PropTypes.arrayOf(PropTypes.string).isRequired,
    authHeaders: PropTypes.object.isRequired,
    authToken: PropTypes.string.isRequired,
    onMaterialLoaded: PropTypes.func.isRequired,
    onDone: PropTypes.func.isRequired,
};

// ════════════════════════════════════════════════════════════════════════════
//  BomHeadersPanel
// ════════════════════════════════════════════════════════════════════════════
const BomHeadersPanel = ({ headers, loading, authToken, t, refetch }) => {
    // ✅ FIX 2 — useNavigate called at the top of the component with all other hooks
    const navigate = useNavigate();

    const [selectedBomId, setSelectedBomId] = useState(null);
    const [selectedRow, setSelectedRow] = useState(null);
    const [showTreeDialog, setShowTreeDialog] = useState(false);
    const [treeNodes, setTreeNodes] = useState([]);
    const [enrichQueue, setEnrichQueue] = useState([]);
    const [enriching, setEnriching] = useState(false);
    const [showNodeDetails, setShowNodeDetails] = useState(false);
    const [selectedNodeDetails, setSelectedNodeDetails] = useState(null);
    const [remarks, setRemarks] = useState('');
    const actionsMenuRef = useRef(null);
    const toast = useRef(null);

    // ── BOM-by-ID search bar state ────────────────────────────────────────
    // bomIdInput  : controlled text field value
    // bomIdSearchKey : committed value that actually triggers useReadApi
    // const [bomIdInput, setBomIdInput] = useState('');
    const [bomIdSearchKey] = useState(null);

    // ── TreeTable controlled state ────────────────────────────────────────
    // Passed straight through to BomLayout → BomTreeTable
    const [expandedKeys, setExpandedKeys] = useState({});
    const [selectedKeys, setSelectedKeys] = useState({});

    // ── Auth headers ──────────────────────────────────────────────────────
    const authHeaders = useMemo(() => ({ Authorization: `Bearer ${authToken}` }), [authToken]);

    // ── BOM-by-ID fetch ───────────────────────────────────────────────────
    const bomByIdEndpoint = bomIdSearchKey ? `/bom/_getbombyId?bomId=${bomIdSearchKey}` : null;

    const { data: bomByIdResp, isLoading: loadingBomById } = useReadApi({
        service: 'material',
        endpoint: bomByIdEndpoint,
        headers: authHeaders,
        enabled: !!bomIdSearchKey,
    });

    // Normalise API response → always an array for the DataTable
    const bomByIdResults = useMemo(() => {
        if (!bomByIdResp) return null; // null = no search done yet
        const raw = bomByIdResp?.data ?? bomByIdResp;
        if (Array.isArray(raw)) return raw;
        if (raw && typeof raw === 'object' && raw.bomId !== undefined) return [raw];
        return [];
    }, [bomByIdResp]);

    // When a search is active show its result, otherwise show the full headers prop
    const displayHeaders = bomIdSearchKey ? (bomByIdResults ?? []) : headers;

    // ── BOM-by-ID search handlers ─────────────────────────────────────────
    // const handleBomIdInputChange = useCallback((e) => setBomIdInput(e.target.value), []);

    // const handleBomIdSearch = useCallback(() => {
    //     const trimmed = bomIdInput.trim();
    //     if (!trimmed) return;
    //     setBomIdSearchKey(trimmed);
    // }, [bomIdInput]);

    // const handleBomIdClear = useCallback(() => {
    //     setBomIdInput('');
    //     setBomIdSearchKey(null);
    // }, []);

    // const handleBomIdKeyDown = useCallback(
    //     (e) => {
    //         if (e.key === 'Enter') handleBomIdSearch();
    //     },
    //     [handleBomIdSearch],
    // );

    // ── BOM tree fetch ────────────────────────────────────────────────────
    const endpoint = selectedBomId ? `/bom/_getbomtree?bomId=${selectedBomId}` : null;

    const { data: bomTreeResp, isLoading: loadingTree } = useReadApi({
        service: 'material',
        endpoint,
        headers: authHeaders,
        enabled: !!selectedBomId,
    });

    const bomAction = useMutationApi({
        service: 'material',
        endpoint: '/bom/_action',
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            Authorization: `Bearer ${authToken}`,
        },
        options: {
            onSuccess: () => {
                // 1️⃣ Close dialog
                closeTreeDialog();

                // 2️⃣ Redirect to Search page
                navigate('/web/landing/plm/bom/search-bom');

                // 3️⃣ Optional: show toast (if you have one)
                toast.current?.show({
                    severity: 'success',
                    summary: 'Success',
                    detail: 'Workflow updated successfully',
                    life: 3000,
                });
                refetch();
            },
            onError: (error) => {
                toast.current?.show({
                    severity: 'error',
                    summary: 'Error',
                    detail: error?.message || 'BOM action failed',
                    life: 3000,
                });
            },
        },
    });
    const handleBomWorkflowAction = useCallback(
        (actionType) => {
            if (!selectedRow) return;

            bomAction.mutate({
                requestInfo: {
                    authToken,
                },
                bomId: selectedRow.bomId,
                action: actionType,
                remarks: remarks || `${actionType} via UI`,
            });
        },
        [selectedRow, authToken, remarks, bomAction],
    );
    const bomMenuItems = useMemo(() => {
        if (!selectedRow?.status) return [];

        const actions = BOM_STATE_ACTIONS[selectedRow.status] ?? [];

        return actions.map(({ action, label, icon, severity, outlined }) => ({
            label: t(label),
            icon,
            className: `wfh-menu-item--${severity}${outlined ? ' wfh-menu-item--outlined' : ''}`,
            command: () => handleBomWorkflowAction(action),
        }));
    }, [selectedRow, handleBomWorkflowAction, t]);
    // Build initial nodes + enrich queue when tree data arrives
    useEffect(() => {
        const root = resolveRootApiNode(bomTreeResp);
        if (!root) {
            setTreeNodes([]);
            setEnrichQueue([]);
            setExpandedKeys({});
            setSelectedKeys({});
            return;
        }
        const nodes = transformTreeNode(root);
        setTreeNodes(nodes ? [nodes] : []);
        setExpandedKeys({});
        setSelectedKeys({});

        const partNos = collectPartNos(root);
        if (partNos.length) {
            setEnrichQueue(partNos);
            setEnriching(true);
        }
    }, [bomTreeResp]);

    // ── Patch node after each _searchOne response ─────────────────────────
    const patchNode = useCallback(
        (nodes, partNo, record) =>
            nodes.map((node) => {
                if (node.data.partNo === partNo) {
                    const materialName = record.materialName || record.name || node.data.partNo;
                    const rawCode = record.materialType ?? record.typeCode ?? node.data.typeCode;
                    const typeCode = rawCode != null ? String(rawCode) : node.data.typeCode;
                    const type = record.categoryName || record.materialTypeName || node.data.type;
                    return {
                        ...node,
                        label: materialName,
                        data: {
                            ...node.data,
                            materialName,
                            typeCode,
                            type,
                            description: record.description || node.data.description,
                        },
                    };
                }
                if (node.children?.length) {
                    return { ...node, children: patchNode(node.children, partNo, record) };
                }
                return node;
            }),
        [],
    );

    const handleMaterialLoaded = useCallback(
        (partNo, record) => setTreeNodes((prev) => patchNode(prev, partNo, record)),
        [patchNode],
    );

    const handleEnrichDone = useCallback(() => {
        setEnriching(false);
        setEnrichQueue([]);
    }, []);

    // ── Legend items ──────────────────────────────────────────────────────
    const legendItems = useMemo(
        () => [
            {
                icon: 'pi pi-check-square',
                color: LEGEND_COLOURS.finished,
                label: t('Finished Product'),
            },
            { icon: 'pi pi-box', color: LEGEND_COLOURS.assembly, label: t('Assembly') },
            { icon: 'pi pi-cog', color: LEGEND_COLOURS.part, label: t('Part') },
            { icon: 'pi pi-inbox', color: LEGEND_COLOURS.raw, label: t('Raw Material') },
        ],
        [t],
    );

    // ── Dialog open / close ───────────────────────────────────────────────
    const handleViewBom = useCallback((rowData) => {
        setTreeNodes([]);
        setEnrichQueue([]);
        setEnriching(false);
        setExpandedKeys({});
        setSelectedKeys({});
        setSelectedRow(rowData);
        setSelectedBomId(rowData.bomId);
        setShowTreeDialog(true);
    }, []);

    const closeTreeDialog = useCallback(() => {
        setShowTreeDialog(false);
        setSelectedBomId(null);
        setSelectedRow(null);
        setTreeNodes([]);
        setEnrichQueue([]);
        setEnriching(false);
        setExpandedKeys({});
        setSelectedKeys({});
    }, []);

    // ── TreeTable handlers (passed through BomLayout → BomTreeTable) ──────
    const handleToggle = useCallback((e) => setExpandedKeys(e.value), []);

    const handleSelectionChange = useCallback((e) => setSelectedKeys(e.value), []);

    const handleContextMenuSelectionChange = useCallback(
        (e) => setSelectedKeys({ [e.value.key]: true }),
        [],
    );

    // Edit click — opens MaterialDetailsDialog (reuse existing detail view)
    const handleEditClick = useCallback((node) => {
        setSelectedNodeDetails(node.data);
        setShowNodeDetails(true);
    }, []);

    // Context menu — read-only view, no actions needed
    const handleContextMenu = useCallback(NOOP, []);

    // ── Viz node-click → MaterialDetailsDialog ────────────────────────────
    const handleNodeClick = useCallback((node) => {
        setSelectedNodeDetails(node.data);
        setShowNodeDetails(true);
    }, []);

    const handleNodeKeyDown = useCallback((node, e) => {
        if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            setSelectedNodeDetails(node.data);
            setShowNodeDetails(true);
        }
    }, []);

    const hideNodeDetails = useCallback(() => {
        setShowNodeDetails(false);
        setSelectedNodeDetails(null);
    }, []);

    // ── DataTable cell renderers ──────────────────────────────────────────
    const qtyBody = useCallback(
        (row) => <span className="font-medium">{Number(row.qty).toFixed(2)}</span>,
        [],
    );

    const uomBody = useCallback((row) => <span className="font-medium">{row.uom}</span>, []);

    const statusBody = useCallback((row) => {
        const severity = STATUS_SEVERITY[row.status] ?? 'secondary';
        const label = STATUS_LABEL[row.status] ?? row.status;

        return <span className={`p-tag p-tag-${severity}`}>{label}</span>;
    }, []);

    const createWorkflowHistoryHandler = useCallback(
        (wfInstanceId) => {
            if (!wfInstanceId) return undefined;

            return () => {
                navigate(`/web/landing/plm/workflow-history/${wfInstanceId}`);
            };
        },
        [navigate],
    );
    // ✅ FIX 3 — workflowHistoryBody wrapped in useCallback with button label
    const workflowHistoryBody = useCallback(
        (row) => (
            <Button
                icon="pi pi-sitemap"
                label={t('View Workflow')}
                className="p-button-sm p-button-outlined p-button-secondary"
                tooltip={t('View Workflow History')}
                tooltipOptions={TOOLTIP_OPTIONS}
                onClick={createWorkflowHistoryHandler(row.wfInstanceId)}
                disabled={!row.wfInstanceId}
            />
        ),
        [createWorkflowHistoryHandler, t],
    );

    const handleActionClick = useCallback(
        (rowData) => () => handleViewBom(rowData),
        [handleViewBom],
    );

    const actionBody = useCallback(
        (rowData) => (
            <Button
                icon="pi pi-sitemap"
                label={t('View BOM Tree')}
                className="p-button-sm p-button-outlined p-button-info"
                onClick={handleActionClick(rowData)}
                tooltip={t('View BOM Tree Visualization')}
                tooltipOptions={TOOLTIP_LEFT}
            />
        ),
        [handleActionClick, t],
    );
    const handleWorkflowHistoryClick = useCallback(() => {
        if (!selectedRow?.wfInstanceId) return;

        navigate(`/web/landing/plm/workflow-history/${selectedRow.wfInstanceId}`);
    }, [navigate, selectedRow?.wfInstanceId]);

    const handleActionsToggle = useCallback((event) => {
        actionsMenuRef.current?.toggle(event);
    }, []);
    // ── Dialog header ─────────────────────────────────────────────────────
    const dialogHeader = useMemo(() => {
        if (!selectedRow) return null;

        return (
            <div className="flex justify-content-between align-items-center w-full">
                <div className="flex align-items-center gap-3">
                    <i className="pi pi-sitemap text-blue-500 text-xl" />
                    <div>
                        <div className="font-bold text-lg text-900">
                            {t('BOM Tree')} — {selectedRow.materialId}
                        </div>
                        <div className="text-sm text-500 mt-1">
                            {t('BOM ID')}: {selectedRow.bomId}
                        </div>
                    </div>
                </div>

                <div className="flex gap-2 align-items-center">
                    {/* Workflow History */}
                    {selectedRow.wfInstanceId && (
                        <Button
                            label={t('Workflow History')}
                            icon="pi pi-list"
                            outlined
                            severity="secondary"
                            className="p-button-sm"
                            onClick={handleWorkflowHistoryClick}
                        />
                    )}

                    {/* Actions Dropdown */}
                    {bomMenuItems.length > 0 && (
                        <Button
                            label={t('Actions')}
                            icon="pi pi-chevron-down"
                            iconPos="right"
                            severity="primary"
                            className="p-button-sm"
                            onClick={handleActionsToggle}
                        />
                    )}
                </div>
            </div>
        );
    }, [
        selectedRow,
        bomMenuItems,
        handleWorkflowHistoryClick, // ✅ added
        handleActionsToggle, // ✅ also include this
        t,
    ]);
    const handleRemarksChange = useCallback((event) => {
        setRemarks(event.target.value);
    }, []);
    // ── Table header ──────────────────────────────────────────────────────
    const tableHeader = useMemo(
        () => (
            <div className="flex justify-content-between align-items-center">
                <span className="text-900 font-bold text-lg">
                    <i className="pi pi-list mr-2 text-primary" />
                    {t('BOM Headers')}
                    {!loading && !loadingBomById && (
                        <span className="ml-2 text-sm font-normal text-500">
                            ({displayHeaders.length} {t('records')}
                            {bomIdSearchKey && (
                                <span className="ml-1 text-primary font-medium">
                                    — BOM ID: {bomIdSearchKey}
                                </span>
                            )}
                            )
                        </span>
                    )}
                </span>
            </div>
        ),
        [displayHeaders.length, loading, loadingBomById, bomIdSearchKey, t],
    );

    // ════════════════════════════════════════════════════════════════════
    //  RENDER
    // ════════════════════════════════════════════════════════════════════
    return (
        <>
            <style>{`@keyframes shimmer{0%{background-position:200% 0}to{background-position:-200% 0}}`}</style>

            {/* ── BOM Headers DataTable ── */}
            <div className="border-1 surface-border border-round surface-card mt-3 p-3">
                {/* ── No-result hint when search returned empty ── */}
                {bomIdSearchKey && !loadingBomById && bomByIdResults?.length === 0 && (
                    <div className="flex align-items-center gap-2 mb-3 px-2 py-2 border-round surface-section text-sm text-orange-700 border-1 border-orange-200">
                        <i className="pi pi-info-circle" />
                        {t('No BOM found for ID')}: <strong>{bomIdSearchKey}</strong>
                    </div>
                )}

                {loading ? (
                    <div className="px-2 py-3">
                        <div className="text-sm text-500 mb-3 font-medium">
                            <i className="pi pi-spin pi-spinner mr-2" />
                            {t('Loading BOM Headers…')}
                        </div>
                        {[0, 1, 2, 3].map((i) => (
                            <SkeletonRow key={i} />
                        ))}
                    </div>
                ) : (
                    <DataTable
                        value={displayHeaders}
                        // loading={loadingBomById}
                        header={tableHeader}
                        paginator
                        rows={5}
                        rowHover
                        showGridlines
                        stripedRows
                        size="small"
                        emptyMessage={
                            <div className="text-center py-5 text-500">
                                <i className="pi pi-inbox text-4xl opacity-40 block mb-2" />
                                {t('No BOM headers found.')}
                            </div>
                        }
                        paginatorTemplate="FirstPageLink PrevPageLink PageLinks NextPageLink LastPageLink RowsPerPageDropdown"
                        className="p-datatable-sm"
                    >
                        <Column
                            field="bomId"
                            header={t('BOM ID')}
                            style={COL_STYLE_BOMID}
                            headerClassName="font-semibold"
                        />
                        <Column
                            field="materialId"
                            header={t('Material ID')}
                            style={COL_STYLE_MATERIAL}
                            headerClassName="font-semibold"
                        />
                        <Column
                            field="qty"
                            header={t('Qty')}
                            style={COL_STYLE_SMALL}
                            headerClassName="font-semibold"
                            body={qtyBody}
                        />
                        <Column
                            field="uom"
                            header={t('UOM')}
                            style={COL_STYLE_SMALL}
                            headerClassName="font-semibold"
                            body={uomBody}
                        />
                        <Column
                            field="status"
                            header={t('Status')}
                            style={COL_STYLE_ACTION}
                            headerClassName="font-semibold"
                            body={statusBody}
                        />
                        <Column
                            header={t('Actions')}
                            style={COL_STYLE_ACTION}
                            headerClassName="font-semibold"
                            body={actionBody}
                            exportable={false}
                        />

                        <Column
                            header={t('Workflow')}
                            style={COL_STYLE_ACTION}
                            headerClassName="font-semibold"
                            body={workflowHistoryBody}
                            exportable={false}
                        />
                    </DataTable>
                )}
            </div>

            {/* ── BOM Tree Dialog: Table (left) + Visualization (right) ── */}
            <Dialog
                visible={showTreeDialog}
                onHide={closeTreeDialog}
                header={dialogHeader}
                style={DIALOG_STYLE}
                modal
                draggable={false}
                resizable={false}
                maximizable
                position="center"
                contentClassName="p-0" // let BomLayout control its own padding
                contentStyle={CONTENT_STYLE}
            >
                <Menu ref={actionsMenuRef} model={bomMenuItems} popup />
                {bomMenuItems.length > 0 && (
                    <div className="px-3 pt-2">
                        <label className="font-bold block mb-2">{t('Remarks')}</label>
                        <InputTextarea
                            rows={2}
                            value={remarks}
                            onChange={handleRemarksChange}
                            placeholder={t('Add remarks for this action...')}
                            className="w-full"
                        />
                    </div>
                )}
                {loadingTree ? (
                    <div className="flex flex-column align-items-center justify-content-center h-full gap-3">
                        <i className="pi pi-spin pi-spinner text-4xl text-primary" />
                        <span className="text-600">{t('Loading BOM Tree…')}</span>
                    </div>
                ) : treeNodes.length === 0 ? (
                    <div className="flex flex-column align-items-center justify-content-center h-full gap-2 text-500">
                        <i className="pi pi-sitemap text-5xl opacity-30" />
                        <span className="font-medium">
                            {t('No tree data available for this BOM.')}
                        </span>
                    </div>
                ) : (
                    <div className="flex flex-column h-full p-3 gap-2">
                        {/* Enricher: fires _searchOne per node while queue has items */}
                        {enriching && enrichQueue.length > 0 && (
                            <NodeEnricher
                                partNos={enrichQueue}
                                authHeaders={authHeaders}
                                authToken={authToken}
                                onMaterialLoaded={handleMaterialLoaded}
                                onDone={handleEnrichDone}
                            />
                        )}

                        {/* Loading banner — tree is already visible while enriching */}
                        {enriching && (
                            <div className="flex align-items-center gap-2 px-3 py-2 border-1 surface-border border-round surface-section text-sm text-600">
                                <i className="pi pi-spin pi-spinner text-primary" />
                                {t('Loading material names and icons…')}
                            </div>
                        )}

                        {/*
                         * BomLayout renders:
                         *   LEFT  (45 %) — BomTreeTable  (your existing component, untouched)
                         *   RIGHT (55 %) — BomVisualization
                         *
                         * Zoom state is owned internally by BomLayout.
                         * All BomTreeTable props are forwarded verbatim.
                         */}
                        <BomLayout
                            // ── BomTreeTable props ──
                            bomNodes={treeNodes}
                            selectedKeys={selectedKeys}
                            expandedKeys={expandedKeys}
                            onSelectionChange={handleSelectionChange}
                            onToggle={handleToggle}
                            onContextMenu={handleContextMenu}
                            onContextMenuSelectionChange={handleContextMenuSelectionChange}
                            onEditClick={handleEditClick}
                            // ── BomVisualization props ──
                            vizNodes={treeNodes}
                            legendItems={legendItems}
                            highlightedNodeKey={null}
                            onMouseEnter={NOOP}
                            onMouseLeave={NOOP}
                            onNodeClick={handleNodeClick}
                            onNodeKeyDown={handleNodeKeyDown}
                            // ── Shared ──
                            t={t}
                        />
                    </div>
                )}
            </Dialog>

            {/* ── Node-click / edit-click → Material Details dialog ── */}
            {showNodeDetails && selectedNodeDetails && (
                <MaterialDetailsDialog
                    visible
                    details={selectedNodeDetails}
                    onHide={hideNodeDetails}
                    t={t}
                />
            )}
        </>
    );
};

BomHeadersPanel.propTypes = {
    headers: PropTypes.arrayOf(
        PropTypes.shape({
            bomId: PropTypes.oneOfType([PropTypes.number, PropTypes.string]).isRequired,
            materialId: PropTypes.string.isRequired,
            qty: PropTypes.number,
            uom: PropTypes.string,
        }),
    ).isRequired,
    loading: PropTypes.bool,
    authToken: PropTypes.string.isRequired,
    t: PropTypes.func.isRequired,
    refetch: PropTypes.func,
};

BomHeadersPanel.defaultProps = { loading: false };

export default BomHeadersPanel;
