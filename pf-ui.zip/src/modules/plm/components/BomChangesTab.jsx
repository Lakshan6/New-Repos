import { useMemo, useCallback } from 'react';
import { Dropdown } from 'primereact/dropdown';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Tag } from 'primereact/tag';
import PropTypes from 'prop-types';

import { useReadApi, useT } from '@shared/hooks';

const CHANGE_TYPE_SEVERITY = {
    CHILD_ADDED: 'success',
    CHILD_DELETED: 'danger',
    CHILD_UPDATED: 'warn',
};

const CHANGE_TYPE_LABEL = {
    CHILD_ADDED: 'Child Added',
    CHILD_DELETED: 'Child Deleted',
    CHILD_UPDATED: 'Child Updated',
};

const changeTypeTemplate = (row) => (
    <Tag
        value={CHANGE_TYPE_LABEL[row.changeType] || row.changeType}
        severity={CHANGE_TYPE_SEVERITY[row.changeType] || 'info'}
    />
);

const BomChangesTab = ({
    bomId,
    currentVersion,
    headers,
    selectedFromVersion,
    onFromVersionChange,
}) => {
    const { t } = useT();

    // 1. Generate options list for comparison dropdown
    const versionOptions = useMemo(() => {
        const current = parseFloat(currentVersion);
        if (isNaN(current) || current <= 1) return [];
        const options = [];
        for (let v = 1; v < current; v++) {
            const label = `${v}.0`;
            options.push({ label, value: label });
        }
        return options;
    }, [currentVersion]);

    // 2. Build the dynamic endpoint URL string based on user selection
    const changesUrl = useMemo(() => {
        if (!bomId || !selectedFromVersion) return null;
        return `/bom/_changes?bomId=${bomId}&fromVersion=${selectedFromVersion}&toVersion=${currentVersion}`;
    }, [bomId, selectedFromVersion, currentVersion]);

    // 3. Call the hook using your clean, direct GET syntax style
    const { data: changesResp, isFetching: isLoading } = useReadApi({
        service: 'material',
        endpoint: changesUrl,
        method: 'GET',
        headers,
        enabled: !!changesUrl, // Only triggers when a version is picked
    });

    const changesData = useMemo(() => {
        const raw = changesResp?.changes ?? changesResp?.data ?? changesResp;
        return Array.isArray(raw) ? raw : [];
    }, [changesResp]);
    const handleVersionChange = useCallback(
        (e) => {
            onFromVersionChange(e.value);
        },
        [onFromVersionChange],
    );
    return (
        <div className="flex flex-column gap-3 p-3">
            <div className="flex align-items-center gap-2">
                <label className="font-medium text-700 text-sm">{t('Compare with version')}:</label>
                <Dropdown
                    value={selectedFromVersion}
                    options={versionOptions}
                    onChange={handleVersionChange}
                    placeholder={t('SELECT_VERSION') || 'Select version'}
                    className="w-12rem"
                    showClear
                />
                <span className="text-sm text-color-secondary">
                    {t('to')} v{currentVersion}
                </span>
            </div>

            {!selectedFromVersion && (
                <div className="text-center text-color-secondary py-5">
                    {t('SELECT_VERSION_TO_VIEW_CHANGES') || 'Select a version to view BOM changes'}
                </div>
            )}

            {selectedFromVersion && isLoading && (
                <div className="flex align-items-center justify-content-center py-5">
                    <i className="pi pi-spin pi-spinner text-2xl text-primary mr-2" />
                    <span>{t('LOADING') || 'Loading...'}</span>
                </div>
            )}

            {selectedFromVersion && !isLoading && changesData.length === 0 && (
                <div className="text-center text-color-secondary py-5">
                    {t('NO_CHANGES_FOUND') || 'No changes found'}
                </div>
            )}

            {selectedFromVersion && !isLoading && changesData.length > 0 && (
                <DataTable
                    value={changesData}
                    size="small"
                    paginator
                    rows={10}
                    className="p-datatable-sm"
                    emptyMessage={t('NO_DATA') || 'No data'}
                >
                    <Column
                        field="changeType"
                        header={t('Change Type')}
                        body={changeTypeTemplate}
                    />
                    <Column field="materialCode" header={t('Material Code')} />
                    <Column field="oldQty" header={t('Old Qty')} />
                    <Column field="newQty" header={t('New Qty')} />
                    <Column field="oldUom" header={t('Old UOM')} />
                    <Column field="newUom" header={t('New UOM')} />
                    <Column field="remarks" header={t('Remarks')} />
                </DataTable>
            )}
        </div>
    );
};

BomChangesTab.propTypes = {
    bomId: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    currentVersion: PropTypes.string.isRequired,
    headers: PropTypes.object.isRequired,
    authToken: PropTypes.string,
    selectedFromVersion: PropTypes.string,
    onFromVersionChange: PropTypes.func.isRequired,
};

export default BomChangesTab;
