import React, { useCallback, useMemo, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import {
    FormGroup,
    ControlledInputText,
    ControlledDropdown,
    ControlledInputNumber,
} from '@shared/components/FormComponents';
import useMaterialDropdown from './UseMaterialDropdown';
import MaterialDocumentAttachmentField from './MaterialDocumentAttachment';
import useBomDocumentAttachment from './useBomDocumentAttachment';
import '../styles/bom.scss';

// ─────────────────────────────────────────────────────────────────────────────
//  PURE HELPERS
// ─────────────────────────────────────────────────────────────────────────────

const getTypeLabel = (dialogType, t) => {
    if (dialogType === 'assembly') return t('Assembly');
    if (dialogType === 'part') return t('Part');
    return t('Raw Material');
};

const extractCostPerUnit = (selectedItem) => {
    if (!selectedItem) return null;
    if (selectedItem.costPerUnit != null) return Number(selectedItem.costPerUnit);
    if (Array.isArray(selectedItem.plantDataList) && selectedItem.plantDataList.length > 0) {
        const firstPlant = selectedItem.plantDataList[0];
        if (firstPlant?.costPerUnit != null) {
            return Number(firstPlant.costPerUnit);
        }
    }
    return null;
};

const itemTemplate = (option) => {
    if (option?.__isSeparator) {
        return <hr className="m-2 border-none border-top-1 surface-border" aria-hidden="true" />;
    }
    return <span>{option?.materialName}</span>;
};

const DIALOG_BREAKPOINTS = { '960px': '95vw' };

// ─────────────────────────────────────────────────────────────────────────────
//  COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
const AddChildDialog = ({
    visible,
    isEditMode,
    addDialogType,
    form,
    setForm,
    contractMaterials,
    otherMaterials,
    isContractMode,
    loadingMaterials,
    uomOptions,
    loadingUoms,
    waitingForMaterials,
    onSubmit,
    onHide,
    t,
}) => {
    const typeLabel = getTypeLabel(addDialogType, t);

    const { options, hasMore, handleShowMore, handleReset } = useMaterialDropdown({
        isContractMode,
        contractMaterials,
        otherMaterials,
    });

    const { control, handleSubmit, watch, setValue, reset, getValues } = useForm({
        defaultValues: form,
    });

    useEffect(() => {
        if (visible && !waitingForMaterials) {
            reset(form);
            handleReset();
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [visible, waitingForMaterials]);

    // Relentlessly sync RHF state to the parent's `form` state so onSubmit has the right data.
    useEffect(() => {
        const subscription = watch(() => {
            const currentFormValues = getValues();
            setForm((prev) => ({ ...prev, ...currentFormValues }));
        });
        return () => subscription.unsubscribe();
    }, [watch, setForm, getValues]);

    const handleViewMoreClick = useCallback(
        (e) => {
            e.stopPropagation();
            handleShowMore();
        },
        [handleShowMore],
    );

    const panelFooterTemplate = useCallback(() => {
        if (!hasMore) return null;

        return (
            <div className="py-2 px-3 border-top-1 surface-border">
                <Button
                    label={t('View More')}
                    icon="pi pi-chevron-down"
                    iconPos="right"
                    className="p-button-text p-button-plain text-sm py-1 px-2 text-blue-600"
                    onClick={handleViewMoreClick}
                />
            </div>
        );
    }, [hasMore, handleViewMoreClick, t]);

    // Auto-populate related fields when the primary item changes
    const selectedItem = watch('item');
    const {
        attachmentFieldRef,
        currentView,
        isAttachmentView,
        selectedMaterialCode,
        handleOpenAttachmentView,
        handleCloseAttachmentView,
        handleTargetMaterialChange,
        handleAttachmentsChange,
        submitAttachmentsForTarget,
    } = useBomDocumentAttachment({
        visible,
        selectedMaterial: selectedItem,
        setValue,
        materialFieldName: 'item',
    });

    useEffect(() => {
        if (selectedItem && selectedItem.materialCode) {
            setValue('description', selectedItem.description || '', { shouldValidate: true });
            setValue('uom', selectedItem.baseUom || '', { shouldValidate: true });
            setValue('type', selectedItem.materialType || '', { shouldValidate: true });
            setValue('costPerUnit', extractCostPerUnit(selectedItem), { shouldValidate: true });
        }
    }, [selectedItem, setValue]);

    const handleDialogSubmit = useMemo(
        () =>
            handleSubmit(async (values) => {
                const resolvedMaterialCode = values.item?.materialCode;
                const uploadResult = await submitAttachmentsForTarget({
                    materialCode: resolvedMaterialCode,
                    materialId: resolvedMaterialCode,
                });

                if (uploadResult && !uploadResult.success) {
                    return;
                }

                const resolvedForm = {
                    ...values,
                    attachments: uploadResult?.attachments || [],
                };

                setForm((prev) => ({ ...prev, ...resolvedForm }));
                onSubmit(resolvedForm);
            }),
        [handleSubmit, onSubmit, setForm, submitAttachmentsForTarget],
    );

    const footer = useMemo(() => <div className="flex justify-content-end gap-2" />, []);
    const mainViewStyle = useMemo(
        () => ({ display: currentView === 'main' ? 'block' : 'none' }),
        [currentView],
    );

    const itemPlaceholder = `${t('Select')} ${typeLabel}`;
    const isOptionDisabled = useCallback((opt) => opt?.__isSeparator, []);

    const itemRules = useMemo(
        () => ({
            validate: (val) => (val && val.materialCode ? true : `${typeLabel} is required`),
        }),
        [typeLabel],
    );

    const qtyRules = useMemo(() => ({ required: t('Quantity is required') }), [t]);
    const uomRules = useMemo(() => ({ required: t('UOM is required') }), [t]);
    const header = useMemo(
        () => {
            if (isAttachmentView) {
                return (
                    <div className="flex align-items-center gap-3 w-full pr-3">
                        <Button
                            icon="pi pi-arrow-left"
                            className="p-button-rounded p-button-text p-button-plain text-800"
                            onClick={handleCloseAttachmentView}
                            aria-label={t('Back')}
                        />
                        <span className="text-xl font-semibold">
                            {t('Attach Document') || 'Attach Document'}
                        </span>
                    </div>
                );
            }

            return (
                <div className="flex align-items-center justify-content-between w-full pr-3">
                    <span className="text-xl font-semibold">
                        {isEditMode ? `${t('Edit')} ${typeLabel}` : `${t('Add')} ${typeLabel}`}
                    </span>

                    <Button
                        label={isEditMode ? t('Update') : `${t('Add')} ${typeLabel}`}
                        icon={isEditMode ? 'pi pi-check' : 'pi pi-plus'}
                        className="p-button-sm"
                        onClick={handleDialogSubmit}
                        disabled={waitingForMaterials}
                    />
                </div>
            );
        },
        [
            handleCloseAttachmentView,
            handleDialogSubmit,
            isAttachmentView,
            isEditMode,
            t,
            typeLabel,
            waitingForMaterials,
        ],
    );

    return (
        <Dialog
            header={header}
            visible={visible}
            className="w-full md:w-30rem"
            breakpoints={DIALOG_BREAKPOINTS}
            contentClassName="py-3 px-4"
            onHide={onHide}
            footer={footer}
        >
            {waitingForMaterials ? (
                <div className="flex align-items-center justify-content-center gap-2 p-5 text-sm">
                    <i className="pi pi-spin pi-spinner" aria-hidden="true" />
                    <span className="text-color-secondary">{t('Loading material data...')}</span>
                </div>
            ) : (
                <div className="flex flex-column gap-3 bom-dialog-form">
                    <div style={mainViewStyle}>
                        <FormGroup htmlFor="item" label={typeLabel} required className="mb-3">
                            <ControlledDropdown
                                inputId="item"
                                name="item"
                                control={control}
                                options={options}
                                loading={loadingMaterials}
                                optionLabel="materialName"
                                dataKey="materialCode"
                                optionDisabled={isOptionDisabled}
                                itemTemplate={itemTemplate}
                                panelFooterTemplate={panelFooterTemplate}
                                placeholder={itemPlaceholder}
                                filter
                                className="w-full"
                                optionValue={null}
                                rules={itemRules}
                                onChange={handleTargetMaterialChange}
                            />
                        </FormGroup>

                        <FormGroup htmlFor="description" label={t('Description')} className="mb-3">
                            <ControlledInputText
                                inputId="description"
                                name="description"
                                control={control}
                                className="w-full"
                            />
                        </FormGroup>

                        <div className="formgrid grid mb-3">
                            <div className="field col">
                                <FormGroup htmlFor="qty" label={t('Qty')} required>
                                    <ControlledInputNumber
                                        inputId="qty"
                                        name="qty"
                                        control={control}
                                        min={1}
                                        className="w-full"
                                        rules={qtyRules}
                                    />
                                </FormGroup>
                            </div>

                            <div className="field col">
                                <FormGroup htmlFor="costPerUnit" label={t('Cost Per Unit')}>
                                    <ControlledInputNumber
                                        inputId="costPerUnit"
                                        name="costPerUnit"
                                        control={control}
                                        min={0}
                                        minFractionDigits={2}
                                        maxFractionDigits={4}
                                        className="w-full"
                                    />
                                </FormGroup>
                            </div>
                        </div>

                        <div className="formgrid grid mb-3">
                            <div className="field col">
                                <FormGroup htmlFor="uom" label={t('UOM')} required>
                                    <ControlledDropdown
                                        inputId="uom"
                                        name="uom"
                                        control={control}
                                        options={uomOptions}
                                        loading={loadingUoms}
                                        optionLabel="label"
                                        optionValue="value"
                                        placeholder={t('Select UOM')}
                                        className="w-full"
                                        rules={uomRules}
                                    />
                                </FormGroup>
                            </div>

                            <div className="field col">
                                <FormGroup htmlFor="type" label={t('Type')}>
                                    <ControlledInputText
                                        inputId="type"
                                        name="type"
                                        control={control}
                                        disabled
                                        className="w-full"
                                    />
                                </FormGroup>
                            </div>
                        </div>

                        <FormGroup
                            htmlFor="alternativeMaterial"
                            label={t('Alt. Material')}
                            className="mb-3"
                        >
                            <ControlledDropdown
                                inputId="alternativeMaterial"
                                name="alternativeMaterial"
                                control={control}
                                options={options}
                                loading={loadingMaterials}
                                optionLabel="materialName"
                                dataKey="materialCode"
                                optionDisabled={isOptionDisabled}
                                itemTemplate={itemTemplate}
                                panelFooterTemplate={panelFooterTemplate}
                                placeholder={t('Select Alt. Material')}
                                filter
                                showClear
                                className="w-full"
                            />
                        </FormGroup>
                    </div>

                    <FormGroup label={t('Attachment')} className={isAttachmentView ? '' : 'mb-0'}>
                        <MaterialDocumentAttachmentField
                            ref={attachmentFieldRef}
                            value={watch('attachments') || []}
                            onChange={handleAttachmentsChange}
                            visible={visible}
                            buttonLabel={t('Attachment') || 'Attachment'}
                            submitLabel={t('Submit') || 'Submit'}
                            materialCode={selectedMaterialCode}
                            disabled={!selectedMaterialCode}
                            isViewActive={isAttachmentView}
                            onOpenView={handleOpenAttachmentView}
                            onCloseView={handleCloseAttachmentView}
                        />
                    </FormGroup>
                </div>
            )}
        </Dialog>
    );
};

// ─────────────────────────────────────────────────────────────────────────────
//  PROP TYPES
// ─────────────────────────────────────────────────────────────────────────────
const materialShape = PropTypes.shape({
    materialName: PropTypes.string,
    materialCode: PropTypes.string,
    description: PropTypes.string,
    baseUom: PropTypes.string,
    materialType: PropTypes.string,
    costPerUnit: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    plantDataList: PropTypes.array,
});

const uomOptionShape = PropTypes.shape({
    label: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,
});

const formShape = PropTypes.shape({
    item: materialShape,
    description: PropTypes.string,
    qty: PropTypes.number,
    uom: PropTypes.string,
    type: PropTypes.string,
    alternativeMaterial: materialShape,
    costPerUnit: PropTypes.number,
    attachments: PropTypes.arrayOf(PropTypes.object),
    validFrom: PropTypes.instanceOf(Date),
});

AddChildDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    isEditMode: PropTypes.bool.isRequired,
    addDialogType: PropTypes.string.isRequired,
    form: formShape.isRequired,
    setForm: PropTypes.func.isRequired,
    contractMaterials: PropTypes.arrayOf(materialShape),
    otherMaterials: PropTypes.arrayOf(materialShape),
    isContractMode: PropTypes.bool,
    loadingMaterials: PropTypes.bool,
    uomOptions: PropTypes.arrayOf(uomOptionShape).isRequired,
    loadingUoms: PropTypes.bool,
    waitingForMaterials: PropTypes.bool,
    onSubmit: PropTypes.func.isRequired,
    onHide: PropTypes.func.isRequired,
    t: PropTypes.func.isRequired,
};

AddChildDialog.defaultProps = {
    contractMaterials: [],
    otherMaterials: [],
    isContractMode: false,
    loadingMaterials: false,
    loadingUoms: false,
    waitingForMaterials: false,
};

export default AddChildDialog;
