import React, { useCallback, useMemo, useEffect } from 'react';
import PropTypes from 'prop-types';
import { useForm } from 'react-hook-form';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import {
    FormGroup,
    ControlledInputText,
    ControlledDropdown,
    ControlledInputNumber,
    ControlledCalendar,
} from '@shared/components/FormComponents';
import useMaterialDropdown from './UseMaterialDropdown';
import MaterialDocumentAttachmentField from './MaterialDocumentAttachment';
import useBomDocumentAttachment from './useBomDocumentAttachment';
import '../styles/bom.scss';

// ─────────────────────────────────────────────────────────────────────────────
//  PURE HELPERS
// ─────────────────────────────────────────────────────────────────────────────

const extractCostPerUnit = (selectedItem) => {
    if (!selectedItem) return null;
    if (selectedItem.costPerUnit != null) return Number(selectedItem.costPerUnit);
    if (Array.isArray(selectedItem.plantDataList) && selectedItem.plantDataList.length > 0) {
        const firstPlant = selectedItem.plantDataList[0];
        if (firstPlant?.costPerUnit != null) {
            return Number(firstPlant.costPerUnit);
        }
    }
    return null;
};

const itemTemplate = (option) => {
    if (option?.__isSeparator) {
        return <hr className="m-2 border-none border-top-1 surface-border" aria-hidden="true" />;
    }
    return <span>{option?.materialName}</span>;
};

const DIALOG_BREAKPOINTS = { '960px': '95vw' };

// ─────────────────────────────────────────────────────────────────────────────
//  COMPONENT
// ─────────────────────────────────────────────────────────────────────────────
const AddProductDialog = ({
    visible,
    isEditMode,
    waitingForProductMaterials,
    form,
    setForm,
    contractMaterials,
    otherMaterials,
    isContractMode,
    loadingMaterials,
    uomOptions,
    loadingUoms,
    onSubmit,
    onHide,
    t,
}) => {
    const { options, hasMore, handleShowMore, handleReset } = useMaterialDropdown({
        isContractMode,
        contractMaterials,
        otherMaterials,
    });

    const { control, handleSubmit, watch, setValue, reset } = useForm({
        defaultValues: form,
    });

    useEffect(() => {
        if (visible) {
            if (!waitingForProductMaterials) {
                reset(form);
                handleReset();
            }
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [visible, waitingForProductMaterials]);

    // Relentlessly sync RHF state to the parent's `form` state so onSubmit has the right data
    const currentFormValues = watch();
    useEffect(() => {
        setForm((prev) => {
            if (JSON.stringify(prev) !== JSON.stringify(currentFormValues)) {
                return { ...prev, ...currentFormValues };
            }
            return prev;
        });
    }, [currentFormValues, setForm]);

    const handleViewMoreClick = useCallback(
        (e) => {
            e.stopPropagation();
            handleShowMore();
        },
        [handleShowMore],
    );

    const panelFooterTemplate = useCallback(() => {
        if (!hasMore) return null;
        return (
            <div className="py-2 px-3 border-top-1 surface-border">
                <Button
                    label={t('View More')}
                    icon="pi pi-chevron-down"
                    iconPos="right"
                    className="p-button-text p-button-plain text-sm py-1 px-2 text-blue-600"
                    onClick={handleViewMoreClick}
                />
            </div>
        );
    }, [hasMore, handleViewMoreClick, t]);

    // Auto-populate related fields when the primary material changes
    const selectedMaterial = watch('material');
    const {
        attachmentFieldRef,
        currentView,
        isAttachmentView,
        selectedMaterialCode,
        handleOpenAttachmentView,
        handleCloseAttachmentView,
        handleTargetMaterialChange,
        handleAttachmentsChange,
        submitAttachmentsForTarget,
    } = useBomDocumentAttachment({
        visible,
        selectedMaterial,
        setValue,
        materialFieldName: 'material',
    });

    useEffect(() => {
        if (selectedMaterial && selectedMaterial.materialCode) {
            setValue('description', selectedMaterial.description || '', { shouldValidate: true });
            setValue('uom', selectedMaterial.baseUom || '', { shouldValidate: true });
            setValue('type', selectedMaterial.materialType || '', { shouldValidate: true });
            setValue('costPerUnit', extractCostPerUnit(selectedMaterial), { shouldValidate: true });
        }
    }, [selectedMaterial, setValue]);

    const handleDialogSubmit = useMemo(
        () =>
            handleSubmit(async (values) => {
                const uploadResult = await submitAttachmentsForTarget({
                    materialCode: values.material?.materialCode,
                    materialId: values.material?.materialCode,
                });

                if (uploadResult && !uploadResult.success) {
                    return;
                }

                const resolvedForm = {
                    ...values,
                    attachments: uploadResult?.attachments || [],
                };

                setForm((prev) => ({ ...prev, ...resolvedForm }));
                onSubmit(resolvedForm);
            }),
        [handleSubmit, onSubmit, setForm, submitAttachmentsForTarget],
    );

    const footer = useMemo(() => <div className="flex justify-content-end gap-2" />, []);

    const mainViewStyle = useMemo(() => ({ display: currentView === 'main' ? 'block' : 'none' }), [currentView]);

    const header = useMemo(() => {
        if (isAttachmentView) {
            return (
                <div className="flex align-items-center gap-3 w-full pr-3">
                    <Button
                        icon="pi pi-arrow-left"
                        className="p-button-rounded p-button-text p-button-plain text-800"
                        onClick={handleCloseAttachmentView}
                        aria-label={t('Back')}
                    />
                    <span className="text-xl font-semibold">
                        {t('Attach Document') || 'Attach Document'}
                    </span>
                </div>
            );
        }

        return (
            <div className="flex align-items-center justify-content-between w-full pr-3">
                <span className="text-xl font-semibold">
                    {isEditMode ? t('Edit Product') : t('Add Product to BOM')}
                </span>
                <Button
                    label={isEditMode ? t('Update') : t('Add Product')}
                    icon={isEditMode ? 'pi pi-check' : 'pi pi-plus'}
                    className="p-button-sm"
                    onClick={handleDialogSubmit}
                    disabled={waitingForProductMaterials}
                />
            </div>
        );
    }, [handleCloseAttachmentView, handleDialogSubmit, isAttachmentView, isEditMode, waitingForProductMaterials, t]);

    const isOptionDisabled = useCallback((opt) => opt?.__isSeparator, []);

    const materialRules = useMemo(
        () => ({
            validate: (val) => (val && val.materialCode ? true : t('Product is required')),
        }),
        [t],
    );
    const qtyRules = useMemo(() => ({ required: t('Quantity is required') }), [t]);
    const uomRules = useMemo(() => ({ required: t('UOM is required') }), [t]);
    const validFromRules = useMemo(() => ({ required: t('Valid From is required') }), [t]);

    return (
        <Dialog
            header={header}
            visible={visible}
            className="w-full md:w-30rem"
            breakpoints={DIALOG_BREAKPOINTS}
            contentClassName="py-3 px-4 transition-all transition-duration-200"
            onHide={onHide}
            footer={footer}
        >
            {waitingForProductMaterials ? (
                <div className="flex align-items-center justify-content-center gap-2 p-5 text-sm">
                    <i className="pi pi-spin pi-spinner" aria-hidden="true" />
                    <span className="text-color-secondary">{t('Loading material data...')}</span>
                </div>
            ) : (
                <div className="flex flex-column gap-3">
                    {/* --- MAIN FORM CONTENT (Hidden when navigating to attachment view) --- */}
                    <div style={mainViewStyle}>
                        <FormGroup
                            htmlFor="material"
                            label={t('Product')}
                            required
                            className="mb-3"
                        >
                            <ControlledDropdown
                                inputId="material"
                                name="material"
                                control={control}
                                options={options}
                                loading={loadingMaterials}
                                optionLabel="materialName"
                                optionValue={null}
                                dataKey="materialCode"
                                optionDisabled={isOptionDisabled}
                                itemTemplate={itemTemplate}
                                panelFooterTemplate={panelFooterTemplate}
                                placeholder={t('Select Product')}
                                filter
                                className="w-full"
                                rules={materialRules}
                                onChange={handleTargetMaterialChange}
                            />
                        </FormGroup>
                        <FormGroup htmlFor="description" label={t('Description')} className="mb-3">
                            <ControlledInputText
                                inputId="description"
                                name="description"
                                control={control}
                                className="w-full"
                            />
                        </FormGroup>
                        <div className="formgrid grid mb-3">
                            <div className="field col">
                                <FormGroup htmlFor="qty" label={t('Qty')} required>
                                    <ControlledInputNumber
                                        inputId="qty"
                                        name="qty"
                                        control={control}
                                        min={1}
                                        className="w-full"
                                        rules={qtyRules}
                                    />
                                </FormGroup>
                            </div>

                            <div className="field col">
                                <FormGroup htmlFor="costPerUnit" label={t('Cost Per Unit')}>
                                    <ControlledInputNumber
                                        inputId="costPerUnit"
                                        name="costPerUnit"
                                        control={control}
                                        min={0}
                                        minFractionDigits={2}
                                        maxFractionDigits={4}
                                        className="w-full"
                                    />
                                </FormGroup>
                            </div>
                        </div>
                        <div className="formgrid grid mb-3">
                            <div className="field col">
                                <FormGroup htmlFor="uom" label={t('UOM')} required>
                                    <ControlledDropdown
                                        inputId="uom"
                                        name="uom"
                                        control={control}
                                        options={uomOptions}
                                        loading={loadingUoms}
                                        optionLabel="label"
                                        optionValue="value"
                                        placeholder={t('Select UOM')}
                                        rules={uomRules}
                                    />
                                </FormGroup>
                            </div>
                            <div className="field col">
                                <FormGroup htmlFor="type" label={t('Type')}>
                                    <ControlledInputText
                                        inputId="type"
                                        name="type"
                                        control={control}
                                        disabled
                                    />
                                </FormGroup>
                            </div>
                        </div>
                        <FormGroup
                            htmlFor="alternativeMaterial"
                            label={t('Alt. Product')}
                            className="mb-3"
                        >
                            <ControlledDropdown
                                inputId="alternativeMaterial"
                                name="alternativeMaterial"
                                control={control}
                                options={options}
                                loading={loadingMaterials}
                                optionLabel="materialName"
                                optionValue={null}
                                dataKey="materialCode"
                                optionDisabled={isOptionDisabled}
                                itemTemplate={itemTemplate}
                                panelFooterTemplate={panelFooterTemplate}
                                placeholder={t('Select Alt. Product')}
                                filter
                                showClear
                                className="w-full"
                            />
                        </FormGroup>
                    </div>

                    {/* --- ATTACHMENTS & VALID FROM ROW --- */}
                    {/* In main view, this renders as a 50/50 split row. In attachment view, it becomes 100% width. */}
                    <div className={currentView === 'main' ? 'formgrid grid' : 'block w-full'}>
                        <div
                            className="field col"
                            style={mainViewStyle}
                        >
                            <FormGroup htmlFor="validFrom" label={t('Valid From')} required>
                                <ControlledCalendar
                                    inputId="validFrom"
                                    name="validFrom"
                                    control={control}
                                    dateFormat="dd/mm/yy"
                                    placeholder="dd/mm/yyyy"
                                    className="w-full"
                                    showIcon
                                    rules={validFromRules}
                                />
                            </FormGroup>
                        </div>

                        <div className={currentView === 'main' ? 'field col' : 'w-full'}>
                            {currentView === 'main' && (
                                <label className="block text-sm font-semibold text-900 mb-2">
                                    {t('Attach Documents')}
                                </label>
                            )}
                            <MaterialDocumentAttachmentField
                                ref={attachmentFieldRef}
                                value={watch('attachments') || []}
                                onChange={handleAttachmentsChange}
                                visible={visible}
                                buttonLabel={t('Attachment') || 'Attachment'}
                                submitLabel={t('Save Attachment') || 'Save Attachment'}
                                materialCode={selectedMaterialCode}
                                disabled={!selectedMaterialCode}
                                isViewActive={isAttachmentView}
                                onOpenView={handleOpenAttachmentView}
                                onCloseView={handleCloseAttachmentView}
                            />
                        </div>
                    </div>
                </div>
            )}
        </Dialog>
    );
};

const materialShape = PropTypes.shape({
    materialName: PropTypes.string,
    materialCode: PropTypes.string,
    description: PropTypes.string,
    baseUom: PropTypes.string,
    materialType: PropTypes.string,
    costPerUnit: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
    plantDataList: PropTypes.array,
});

const uomOptionShape = PropTypes.shape({
    label: PropTypes.string.isRequired,
    value: PropTypes.string.isRequired,
});

const formShape = PropTypes.shape({
    material: materialShape,
    description: PropTypes.string,
    qty: PropTypes.number,
    uom: PropTypes.string,
    type: PropTypes.string,
    alternativeMaterial: materialShape,
    costPerUnit: PropTypes.number,
    attachments: PropTypes.arrayOf(PropTypes.object),
    validFrom: PropTypes.instanceOf(Date),
});

AddProductDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    isEditMode: PropTypes.bool,
    waitingForProductMaterials: PropTypes.bool,
    form: formShape.isRequired,
    setForm: PropTypes.func.isRequired,
    contractMaterials: PropTypes.arrayOf(materialShape),
    otherMaterials: PropTypes.arrayOf(materialShape),
    isContractMode: PropTypes.bool,
    loadingMaterials: PropTypes.bool,
    uomOptions: PropTypes.arrayOf(uomOptionShape).isRequired,
    loadingUoms: PropTypes.bool,
    onSubmit: PropTypes.func.isRequired,
    onHide: PropTypes.func.isRequired,
    t: PropTypes.func.isRequired,
};

AddProductDialog.defaultProps = {
    isEditMode: false,
    waitingForProductMaterials: false,
    contractMaterials: [],
    otherMaterials: [],
    isContractMode: false,
    loadingMaterials: false,
    loadingUoms: false,
};

export default AddProductDialog;
