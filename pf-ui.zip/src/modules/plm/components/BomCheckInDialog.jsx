import React, { forwardRef } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import { FileUpload } from 'primereact/fileupload';
import { InputTextarea } from 'primereact/inputtextarea';

const CHECK_IN_DIALOG_BREAKPOINTS = { '960px': '75vw', '641px': '100vw' };

const AUTOMATION_STEPS = [
    'Parse FreeCAD',
    'Generate BOM',
    'Convert to GLB',
    'Generate BOM Diff',
    'Create New Revision',
];

const BomCheckInDialog = forwardRef(
    (
        {
            visible,
            onHide,
            selectedBomDocumentId,
            fileKey,
            onFileSelect,
            onFileClear,
            comment,
            onCommentChange,
            onSubmit,
            loading,
            hasFile,
        },
        ref,
    ) => {
        const handleChooseFile = (e) => {
            e?.preventDefault();
            e?.stopPropagation();
            if (ref && 'current' in ref && ref.current) {
                if (typeof ref.current.getInput === 'function') {
                    const input = ref.current.getInput();
                    if (input) {
                        input.click();
                        return;
                    }
                }
                if (typeof ref.current.choose === 'function') {
                    ref.current.choose();
                    return;
                }
            }
            const container = document.getElementById('bom-check-in-file');
            const fileInput = container?.querySelector('input[type="file"]');
            if (fileInput) {
                fileInput.click();
            }
        };

        const header = (
            <div className="flex flex-column gap-1">
                <div className="flex align-items-center gap-2 text-xl font-semibold text-900">
                    <i className="pi pi-sign-in text-primary" />
                    <span>Check In</span>
                </div>
                <span className="text-sm font-normal text-600 mt-1">
                    Upload the updated model and run automation.
                </span>
            </div>
        );

        return (
            <Dialog
                header={header}
                visible={visible}
                onHide={onHide}
                breakpoints={CHECK_IN_DIALOG_BREAKPOINTS}
                className="w-30rem"
                blockScroll
                footer={
                    <div className="flex justify-content-end gap-2 pt-3">
                        <Button
                            type="button"
                            label="Cancel"
                            className="p-button-text p-button-secondary font-semibold"
                            onClick={onHide}
                            disabled={loading}
                        />
                        <Button
                            type="button"
                            label="Check In"
                            className="font-semibold"
                            onClick={onSubmit}
                            loading={loading}
                            disabled={!hasFile}
                        />
                    </div>
                }
            >
                <div className="flex flex-column gap-4 pt-3">
                    <div className="flex flex-column gap-2">
                        <span className="text-xs font-semibold text-500 uppercase tracking-wide">
                            UPLOAD UPDATED .FCSTD
                        </span>
                        <FileUpload
                            key={fileKey}
                            ref={ref}
                            id="bom-check-in-file"
                            name="file"
                            customUpload
                            auto={false}
                            accept=".fcstd,.FCStd"
                            onSelect={onFileSelect}
                            onClear={onFileClear}
                            onRemove={onFileClear}
                            disabled={loading}
                            chooseOptions={{ className: 'hidden' }}
                            cancelOptions={{ className: 'hidden' }}
                            uploadOptions={{ className: 'hidden' }}
                            emptyTemplate={() => (
                                <div
                                    className="flex align-items-center justify-content-center flex-column py-5 surface-ground border-round border-dashed border-2 surface-border cursor-pointer hover:surface-hover transition-colors"
                                    onClick={handleChooseFile}
                                    role="button"
                                    tabIndex={0}
                                    onKeyDown={(e) => {
                                        if (e.key === 'Enter' || e.key === ' ') handleChooseFile(e);
                                    }}
                                >
                                    <i className="pi pi-cloud-upload text-3xl text-500 mb-2" />
                                    <span className="text-700 font-medium text-sm">
                                        Click to browse or drop a .FCStd file
                                    </span>
                                    <span className="text-xs text-500 mt-1">
                                        FreeCAD document - max 250 MB
                                    </span>
                                </div>
                            )}
                            contentClassName="p-0 border-none"
                            headerClassName="hidden"
                        />
                    </div>

                    <div className="flex flex-column gap-2">
                        <span className="text-xs font-semibold text-500 uppercase tracking-wide">
                            VERSION COMMENT
                        </span>
                        <InputTextarea
                            inputId="bom-check-in-revision-comment"
                            value={comment}
                            onChange={(e) => onCommentChange(e.target.value)}
                            rows={3}
                            autoResize
                            placeholder="Describe the changes in this revision..."
                            className="w-full"
                            disabled={loading}
                        />
                    </div>

                    <div className="flex flex-column gap-2">
                        <span className="text-xs font-semibold text-500 uppercase tracking-wide">
                            AUTOMATION PIPELINE
                        </span>
                        <div className="flex flex-column border-round border-1 surface-border bg-white overflow-hidden">
                            {AUTOMATION_STEPS.map((step, idx) => (
                                <div
                                    key={idx}
                                    className={`flex align-items-center gap-3 px-3 py-2 ${idx !== AUTOMATION_STEPS.length - 1 ? 'border-bottom-1 surface-border' : ''}`}
                                >
                                    <div
                                        className="flex align-items-center justify-content-center bg-green-100 text-green-500 border-circle"
                                        style={{ width: '20px', height: '20px' }}
                                    >
                                        <i
                                            className="pi pi-check"
                                            style={{ fontSize: '12px', fontWeight: 'bold' }}
                                        />
                                    </div>
                                    <span className="text-700 text-sm">{step}</span>
                                </div>
                            ))}
                        </div>
                    </div>
                </div>
            </Dialog>
        );
    },
);

BomCheckInDialog.displayName = 'BomCheckInDialog';
BomCheckInDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    onHide: PropTypes.func.isRequired,
    selectedBomDocumentId: PropTypes.string,
    fileKey: PropTypes.number.isRequired,
    onFileSelect: PropTypes.func.isRequired,
    onFileClear: PropTypes.func.isRequired,
    comment: PropTypes.string.isRequired,
    onCommentChange: PropTypes.func.isRequired,
    onSubmit: PropTypes.func.isRequired,
    loading: PropTypes.bool.isRequired,
    hasFile: PropTypes.bool.isRequired,
};

export default BomCheckInDialog;
