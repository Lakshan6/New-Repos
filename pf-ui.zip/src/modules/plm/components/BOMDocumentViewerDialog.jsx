import React, { useState, useEffect, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';

/* ─────────────────────────────────────────────────────────────
   STYLE CONSTANTS (NO INLINE OBJECTS IN JSX)
───────────────────────────────────────────────────────────── */

const DIALOG_STYLE = { width: '85vw', maxWidth: '1100px', height: '80vh' };
const CONTENT_STYLE = { padding: 0 };

const BODY_STYLE = {
    display: 'flex',
    height: 'calc(80vh - 120px)',
    overflow: 'hidden',
};

const SIDEBAR_STYLE = {
    width: '240px',
    minWidth: '200px',
    borderRight: '1px solid var(--surface-border)',
    overflowY: 'auto',
    padding: '12px 8px',
    background: 'var(--surface-ground)',
    display: 'flex',
    flexDirection: 'column',
    gap: '6px',
};

const PREVIEW_STYLE = {
    flex: 1,
    display: 'flex',
    flexDirection: 'column',
    background: 'var(--surface-card)',
    overflow: 'hidden',
};

const PREVIEW_HEADER_STYLE = {
    padding: '10px 16px',
    borderBottom: '1px solid var(--surface-border)',
    fontSize: '0.85rem',
    fontWeight: 600,
    display: 'flex',
    alignItems: 'center',
    gap: '8px',
    background: 'var(--surface-section)',
};

const PREVIEW_CONTENT_STYLE = {
    flex: 1,
    display: 'flex',
    alignItems: 'center',
    justifyContent: 'center',
    padding: '16px',
    overflow: 'hidden',
};

const EMPTY_STYLE = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '12px',
    color: 'var(--text-color-secondary)',
};

const EMPTY_PADDED_STYLE = {
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    gap: '12px',
    color: 'var(--text-color-secondary)',
    padding: '48px',
};

const IMAGE_STYLE = {
    maxWidth: '100%',
    maxHeight: '100%',
    objectFit: 'contain',
};

const PDF_OBJECT_STYLE = {
    width: '100%',
    height: '100%',
    border: 'none',
};

const FILE_NAME_STYLE = {
    flex: 1,
    overflow: 'hidden',
    textOverflow: 'ellipsis',
    whiteSpace: 'nowrap',
};

const ICON_LARGE = { fontSize: '3rem' };
const ICON_PDF = { fontSize: '3rem', color: 'var(--red-500)' };
const LINK_STYLE = { color: 'var(--primary-color)' };

/* ─────────────────────────────────────────────────────────────
   HELPERS
───────────────────────────────────────────────────────────── */

const guessType = (name = '') => {
    const ext = name.split('.').pop()?.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'webp', 'svg'].includes(ext))
        return `image/${ext === 'jpg' ? 'jpeg' : ext}`;
    if (ext === 'pdf') return 'application/pdf';
    return '';
};

const normaliseAttachment = (att) => {
    if (!att) return null;

    if (att instanceof File) {
        return {
            name: att.name,
            type: att.type || guessType(att.name),
            isFile: true,
            raw: att,
            url: null,
            size: att.size,
        };
    }

    if (typeof att === 'string') {
        const name = att.split('/').pop();
        return {
            name,
            type: guessType(name),
            isFile: false,
            raw: att,
            url: att,
            size: null,
        };
    }

    if (typeof att === 'object') {
        if (att.file instanceof File) {
            return {
                name: att.documentName || att.fileName || att.file.name || 'document',
                type: att.file.type || guessType(att.file.name),
                isFile: true,
                raw: att.file,
                url: null,
                size: att.file.size ?? att.size ?? null,
            };
        }

        return {
            name: att.documentName || att.fileName || att.name || 'document',
            type: att.type || guessType(att.fileName || att.name),
            isFile: false,
            raw: att,
            url: att.url || null,
            size: att.size ?? null,
        };
    }

    return null;
};

const isImage = (type) => type?.startsWith('image/');
const isPdf = (type) => type === 'application/pdf';

/* ─────────────────────────────────────────────────────────────
   FILE ITEM
───────────────────────────────────────────────────────────── */

const FileItem = React.memo(function FileItem({ norm, selected, onSelect }) {
    const handleClick = useCallback(() => {
        onSelect(norm.index);
    }, [onSelect, norm.index]);

    return (
        <button
            type="button"
            onClick={handleClick}
            className={`flex align-items-center gap-2 px-2 py-2 w-full text-left cursor-pointer
        ${selected ? 'bg-blue-50 border-1 border-blue-200' : 'border-1 border-transparent'}
    `}
        >
            <span style={FILE_NAME_STYLE}>{norm.name}</span>
        </button>
    );
});

FileItem.displayName = 'FileItem';

FileItem.propTypes = {
    norm: PropTypes.object.isRequired,
    selected: PropTypes.bool.isRequired,
    onSelect: PropTypes.func.isRequired,
};

/* ─────────────────────────────────────────────────────────────
   PREVIEW
───────────────────────────────────────────────────────────── */

const FilePreview = ({ norm }) => {
    const [blobUrl, setBlobUrl] = useState(null);

    useEffect(() => {
        if (!norm?.isFile) return;
        const url = URL.createObjectURL(norm.raw);
        setBlobUrl(url);
        return () => URL.revokeObjectURL(url);
    }, [norm]);

    if (!norm) {
        return (
            <div style={EMPTY_STYLE}>
                <i className="pi pi-file" style={ICON_LARGE} />
                <span>Select a document to preview</span>
            </div>
        );
    }

    const url = norm.isFile ? blobUrl : norm.url;
    if (!url) return null;

    if (isPdf(norm.type)) {
        return (
            <object
                data={url}
                type="application/pdf"
                style={PDF_OBJECT_STYLE}
                aria-label={norm.name}
            >
                <div style={EMPTY_STYLE}>
                    <i className="pi pi-file-pdf" style={ICON_PDF} />
                    <a href={url} target="_blank" rel="noreferrer" style={LINK_STYLE}>
                        Open PDF
                    </a>
                </div>
            </object>
        );
    }

    if (isImage(norm.type)) {
        return <img src={url} alt={norm.name} style={IMAGE_STYLE} />;
    }

    return (
        <div style={EMPTY_STYLE}>
            <i className="pi pi-file" style={ICON_LARGE} />
            <a href={url} target="_blank" rel="noreferrer" style={LINK_STYLE}>
                Open File
            </a>
        </div>
    );
};

FilePreview.propTypes = {
    norm: PropTypes.object,
};

/* ─────────────────────────────────────────────────────────────
   MAIN DIALOG
───────────────────────────────────────────────────────────── */

const DocumentViewerDialog = ({ visible, attachments, onHide, t }) => {
    const [selectedIndex, setSelectedIndex] = useState(0);

    const normalised = useMemo(() => {
        return (attachments || [])
            .map(normaliseAttachment)
            .filter(Boolean)
            .map((item, index) => ({ ...item, index }));
    }, [attachments]);

    useEffect(() => {
        if (visible) setSelectedIndex(0);
    }, [visible]);

    const selected = normalised[selectedIndex] ?? null;

    const handleSelect = useCallback((idx) => {
        setSelectedIndex(idx);
    }, []);

    const footer = useMemo(() => {
        return (
            <Button
                label={t('Close')}
                icon="pi pi-times"
                onClick={onHide}
                className="p-button-text"
            />
        );
    }, [t, onHide]);

    return (
        <Dialog
            header={t('Documents')}
            visible={visible}
            style={DIALOG_STYLE}
            contentStyle={CONTENT_STYLE}
            onHide={onHide}
            footer={footer}
            maximizable
        >
            {normalised.length === 0 ? (
                <div style={EMPTY_PADDED_STYLE}>
                    <i className="pi pi-inbox" style={ICON_LARGE} />
                    <span>{t('No documents attached')}</span>
                </div>
            ) : (
                <div style={BODY_STYLE}>
                    <div style={SIDEBAR_STYLE}>
                        {normalised.map((norm, idx) => (
                            <FileItem
                                key={`${norm.name}-${idx}`}
                                norm={norm}
                                selected={idx === selectedIndex}
                                onSelect={handleSelect}
                            />
                        ))}
                    </div>

                    <div style={PREVIEW_STYLE}>
                        {selected && <div style={PREVIEW_HEADER_STYLE}>{selected.name}</div>}
                        <div style={PREVIEW_CONTENT_STYLE}>
                            <FilePreview norm={selected} />
                        </div>
                    </div>
                </div>
            )}
        </Dialog>
    );
};

DocumentViewerDialog.propTypes = {
    visible: PropTypes.bool.isRequired,
    attachments: PropTypes.array,
    onHide: PropTypes.func.isRequired,
    t: PropTypes.func.isRequired,
};

DocumentViewerDialog.defaultProps = {
    attachments: [],
};

export default DocumentViewerDialog;
