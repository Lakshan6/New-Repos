import React from 'react';
import PropTypes from 'prop-types';
import '../styles/bom.scss';

/**
 * BomFormRow
 * A single label : input row used across all BOM dialogs.
 * Layout is handled by flex utility via SCSS class .bom-form-row.
 */
const BomFormRow = ({ label, children }) => (
    <div className="flex align-items-center gap-2 min-h-3rem">
        <div className="bom-form-label">{label}</div>
        <span className="bom-form-colon">:</span>
        <div className="bom-form-field flex-1">{children}</div>
    </div>
);

BomFormRow.propTypes = {
    label: PropTypes.node.isRequired,
    children: PropTypes.node,
};

export default BomFormRow;
