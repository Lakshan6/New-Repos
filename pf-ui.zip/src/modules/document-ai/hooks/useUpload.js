import { useState, useCallback } from 'react';
import { useQueryClient } from '@tanstack/react-query';
import { ragAxios, RAG_APIS, getRagAuth } from './ragApi';

// ── Chat upload ───────────────────────────────────────────────────────────────
const useChatUpload = () => {
    const [isUploading, setIsUploading] = useState(false);
    const [uploadError, setUploadError] = useState(null);

    const uploadForChat = useCallback(async (file, conversationId) => {
        setIsUploading(true);
        setUploadError(null);
        try {
            const { authorization } = getRagAuth();
            const form = new FormData();
            form.append('file', file);
            form.append('conversation_id', conversationId);
            const { data } = await ragAxios.post('/api/v1/documents/upload', form, {
                headers: { 'Content-Type': 'multipart/form-data', Authorization: authorization },
            });
            if (data.code !== 0) throw new Error(data.message ?? 'Upload failed');
            // upload_info returns a single object, not an array
            return data.data ? [data.data] : [];
        } catch (err) {
            setUploadError(err.message);
            return [];
        } finally {
            setIsUploading(false);
        }
    }, []);

    return { uploadForChat, isUploading, uploadError };
};

// ── Self-doc upload → upload + run → then refresh document list ───────────────
const useSelfDocUpload = (kbId) => {
    const [isUploading, setIsUploading] = useState(false);
    const [uploadError, setUploadError] = useState(null);
    const queryClient = useQueryClient();

    const uploadAndRun = useCallback(
        async (file) => {
            setIsUploading(true);
            setUploadError(null);
            try {
                const { authorization } = getRagAuth();

                // Step 1: Upload
                const form = new FormData();
                form.append('file', file);
                const uploadRes = await ragAxios.post(
                    `${RAG_APIS.DOCUMENT_UPLOAD}/${kbId}/documents`,
                    form,
                    {
                        headers: {
                            'Content-Type': 'multipart/form-data',
                            Authorization: authorization,
                        },
                    },
                );
                if (uploadRes.data.code !== 0)
                    throw new Error(uploadRes.data.message ?? 'Upload failed');

                const docs = uploadRes.data.data ?? [];
                const docIds = docs.map((d) => d.id);

                // Step 2: Run (trigger parsing)
                if (docIds.length) {
                    await ragAxios.post(
                        RAG_APIS.DOCUMENT_RUN,
                        { doc_ids: docIds, run: 1, delete: false },
                        { headers: { Authorization: authorization } },
                    );
                }

                // Step 3: Refresh document list immediately after upload + run
                await queryClient.invalidateQueries({ queryKey: ['rag', 'document-list', kbId] });

                return docs;
            } catch (err) {
                setUploadError(err.message);
                return [];
            } finally {
                setIsUploading(false);
            }
        },
        [kbId, queryClient],
    );

    return { uploadAndRun, isUploading, uploadError };
};

export { useChatUpload, useSelfDocUpload };
