import { useQuery } from '@tanstack/react-query';
import { useSetAtom, useAtomValue } from 'jotai';
import { useEffect } from 'react';
import { ragAxios, RAG_APIS, EXCLUDED_DIALOG_NAMES, getRagAuth } from './ragApi';
import { daiDialogListAtom, daiSelectedDialogAtom } from '../store/atoms';

const fetchDialogs = async () => {
    const { data } = await ragAxios.get(RAG_APIS.DIALOG_LIST, {
        params: {
            page: 1,
            page_size: 100,
            orderby: 'update_time',
            desc: true,
        },
    });
    if (data.code !== 0) throw new Error(data.message ?? 'Failed to load dialogs');
    const dialogs = Array.isArray(data.data)
        ? data.data
        : data.data?.chats || data.data?.dialogs || [];
    const excluded = EXCLUDED_DIALOG_NAMES.map((n) => n.toLowerCase());
    return dialogs.filter((d) => !excluded.includes(d.name?.toLowerCase()));
};

const useWidgetDialogs = () => {
    const setDialogList = useSetAtom(daiDialogListAtom);
    const setSelectedDialog = useSetAtom(daiSelectedDialogAtom);
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);

    const { tenantId } = getRagAuth();

    const query = useQuery({
        queryKey: ['dai', 'dialog-list', tenantId],
        queryFn: fetchDialogs,
        staleTime: 5 * 60 * 1000,
    });

    useEffect(() => {
        if (!query.data?.length) return;
        setDialogList(query.data);
        const isValid = selectedDialog && query.data.some((d) => d.id === selectedDialog.id);
        if (!isValid) {
            setSelectedDialog(query.data[0]);
        }
    }, [query.data, selectedDialog, setDialogList, setSelectedDialog]);

    return query;
};

export default useWidgetDialogs;
