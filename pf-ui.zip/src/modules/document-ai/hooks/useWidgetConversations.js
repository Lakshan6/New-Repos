import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { useAtomValue, useSetAtom, useAtom } from 'jotai';
import { useCallback } from 'react';
import { ragAxios, RAG_APIS } from './ragApi';
import {
    daiSelectedDialogAtom,
    daiConversationListAtom,
    daiActiveConversationAtom,
    daiMessagesAtom,
    INITIAL_DAI_MESSAGE,
} from '../store/atoms';

// ── List ──────────────────────────────────────────────────────────────────────
const useWidgetConversations = () => {
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);
    const setConversationList = useSetAtom(daiConversationListAtom);

    return useQuery({
        queryKey: ['dai', 'conversations', selectedDialog?.id],
        queryFn: async () => {
            const { data } = await ragAxios.get(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Failed to load conversations');
            const list = data.data ?? [];
            setConversationList(list);
            return list;
        },
        enabled: !!selectedDialog?.id,
        staleTime: 30 * 1000,
    });
};

// ── Create ────────────────────────────────────────────────────────────────────
const useWidgetCreateConversation = () => {
    const queryClient = useQueryClient();
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);
    const setActiveConversation = useSetAtom(daiActiveConversationAtom);
    const setMessages = useSetAtom(daiMessagesAtom);

    return useMutation({
        mutationFn: async (name = 'New conversation') => {
            const { data } = await ragAxios.post(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                { name },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Failed to create conversation');
            return data.data;
        },
        onSuccess: (conv) => {
            setActiveConversation(conv);
            setMessages(conv.messages?.length ? conv.messages : [INITIAL_DAI_MESSAGE]);
            queryClient.invalidateQueries({
                queryKey: ['dai', 'conversations', selectedDialog?.id],
            });
        },
    });
};

// ── Rename ────────────────────────────────────────────────────────────────────
const useWidgetRenameConversation = () => {
    const queryClient = useQueryClient();
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);

    return useMutation({
        mutationFn: async ({ sessionId, name }) => {
            const { data } = await ragAxios.patch(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions/${sessionId}`,
                { name },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Rename failed');
            return data.data;
        },
        onSuccess: () => {
            queryClient.invalidateQueries({
                queryKey: ['dai', 'conversations', selectedDialog?.id],
            });
        },
    });
};

// ── Delete ────────────────────────────────────────────────────────────────────
const useWidgetDeleteConversation = () => {
    const queryClient = useQueryClient();
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);
    const [activeConversation, setActiveConversation] = useAtom(daiActiveConversationAtom);
    const setMessages = useSetAtom(daiMessagesAtom);

    return useMutation({
        mutationFn: async (conversationId) => {
            const { data } = await ragAxios.delete(
                `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                { data: { ids: [conversationId] } },
            );
            if (data.code !== 0) throw new Error(data.message ?? 'Delete failed');
            return conversationId;
        },
        onSuccess: (deletedId) => {
            if (activeConversation?.id === deletedId) {
                setActiveConversation(null);
                setMessages([INITIAL_DAI_MESSAGE]);
            }
            queryClient.invalidateQueries({
                queryKey: ['dai', 'conversations', selectedDialog?.id],
            });
        },
    });
};

// ── Select existing conversation ──────────────────────────────────────────────
const useWidgetSelectConversation = () => {
    const setActiveConversation = useSetAtom(daiActiveConversationAtom);
    const setMessages = useSetAtom(daiMessagesAtom);

    return useCallback(
        (conv) => {
            setActiveConversation(conv);
            const rawMessages = conv.messages ?? [];
            const references = conv.reference ?? [];

            let refIndex = 0;
            const mergedMessages = rawMessages.map((msg, idx) => {
                if (msg.role === 'assistant' && idx > 0) {
                    const ref = references[refIndex] ?? { chunks: [], doc_aggs: [] };
                    refIndex++;
                    return { ...msg, reference: ref };
                }
                return msg;
            });

            setMessages(mergedMessages?.length ? mergedMessages : [INITIAL_DAI_MESSAGE]);
        },
        [setActiveConversation, setMessages],
    );
};

export {
    useWidgetConversations,
    useWidgetCreateConversation,
    useWidgetRenameConversation,
    useWidgetDeleteConversation,
    useWidgetSelectConversation,
};
