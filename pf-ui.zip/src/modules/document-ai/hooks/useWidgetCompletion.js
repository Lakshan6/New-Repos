import { useAtomValue, useSetAtom } from 'jotai';
import { useCallback } from 'react';
import { RAG_APIS, getRagAuth } from './ragApi';
import {
    daiMessagesAtom,
    daiIsStreamingAtom,
    daiActiveConversationAtom,
    daiSelectedDialogAtom,
} from '../store/atoms';

// Basically identical to useCompletion.js but wired to dai* atoms
const useWidgetCompletion = () => {
    const setMessages = useSetAtom(daiMessagesAtom);
    const setIsStreaming = useSetAtom(daiIsStreamingAtom);
    const isStreaming = useAtomValue(daiIsStreamingAtom);
    const activeConversation = useAtomValue(daiActiveConversationAtom);
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);

    const sendMessage = useCallback(
        async ({ userText, files, currentMessages, conversationId }) => {
            const targetConvId = conversationId || activeConversation?.id;

            if (!targetConvId || !selectedDialog?.id || isStreaming || !userText.trim()) {
                return null;
            }

            const { authorization } = getRagAuth();

            const userMsg = {
                role: 'user',
                content: userText.trim(),
                id: crypto.randomUUID(),
                conversationId: targetConvId,
                ...(files?.length ? { files } : {}), // attach full file objects
            };

            const fullMessages = [...currentMessages, userMsg];

            // Optimistically show user message
            setMessages(fullMessages);
            setIsStreaming(true);

            // Insert placeholder
            const placeholderId = crypto.randomUUID();
            setMessages([
                ...fullMessages,
                {
                    role: 'assistant',
                    content: '',
                    id: placeholderId,
                    reference: { chunks: [], doc_aggs: [] },
                    _streaming: true,
                    _thinking: true,
                },
            ]);

            let finalAnswer = '';
            let finalReference = { chunks: [], doc_aggs: [] };

            try {
                // Same payload as useCompletion
                const payload = {
                    chat_id: selectedDialog.id,
                    session_id: targetConvId,
                    stream: true,
                    pass_all_history_messages: true,
                    messages: fullMessages
                        .filter((m) => m.id !== 'prologue')
                        .map((m) => {
                            const msg = {
                                role: m.role,
                                content: m.content,
                                id: m.id,
                                conversationId: targetConvId,
                            };
                            // Include files if present
                            if (m.files?.length) {
                                msg.files = m.files;
                            }
                            return msg;
                        }),
                };

                const response = await fetch(
                    `${import.meta.env.VITE_RAG_BASE_URL}${RAG_APIS.CONVERSATION_COMPLETION}`,
                    {
                        method: 'POST',
                        headers: {
                            'Content-Type': 'application/json',
                            Accept: 'text/event-stream',
                            Authorization: authorization, // using the original RAG token from LS
                        },
                        body: JSON.stringify(payload),
                    },
                );

                if (!response.ok) throw new Error(`HTTP ${response.status}`);

                const reader = response.body.getReader();
                const decoder = new TextDecoder();
                let buffer = '';
                let done = false;

                while (!done) {
                    const { value, done: readerDone } = await reader.read();

                    if (readerDone) {
                        if (buffer.trim()) {
                            const remaining = buffer.trim();
                            if (remaining.startsWith('data:')) {
                                const raw = remaining.slice(5).trim();
                                try {
                                    const frame = JSON.parse(raw);
                                    if (frame.data === true) {
                                        // end
                                    } else if (
                                        frame.code === 0 &&
                                        typeof frame.data?.answer === 'string'
                                    ) {
                                        if (frame.data?.final === true) {
                                            finalAnswer = frame.data.answer;
                                        } else {
                                            finalAnswer += frame.data.answer;
                                        }
                                        if (frame.data.reference?.chunks?.length) {
                                            finalReference = frame.data.reference;
                                        }
                                    }
                                } catch {
                                    // ignore
                                }
                            }
                        }
                        break;
                    }

                    buffer += decoder.decode(value, { stream: true });
                    const lines = buffer.split('\n');
                    buffer = lines.pop() ?? '';

                    for (const line of lines) {
                        const trimmed = line.trim();
                        if (!trimmed.startsWith('data:')) continue;
                        const raw = trimmed.slice(5).trim();
                        if (!raw) continue;

                        let frame;
                        try {
                            frame = JSON.parse(raw);
                        } catch {
                            continue;
                        }

                        if (frame.code !== 0) continue;
                        if (frame.data === true) {
                            done = true;
                            break;
                        }

                        const answer = frame.data?.answer;
                        const reference = frame.data?.reference;

                        if (typeof answer === 'string') {
                            if (frame.data?.final === true) {
                                finalAnswer = answer;
                            } else {
                                finalAnswer += answer;
                            }
                            if (reference?.chunks?.length) finalReference = reference;

                            setMessages((prev) =>
                                prev.map((m) =>
                                    m.id === placeholderId
                                        ? {
                                              ...m,
                                              content: finalAnswer,
                                              reference: finalReference || m.reference,
                                              _streaming: true,
                                              _thinking: false,
                                          }
                                        : m,
                                ),
                            );
                        }
                    }
                }

                setMessages((prev) =>
                    prev.map((m) =>
                        m.id === placeholderId
                            ? {
                                  ...m,
                                  content: finalAnswer || '(No response)',
                                  reference: finalReference,
                                  _streaming: false,
                                  _thinking: false,
                              }
                            : m,
                    ),
                );

                return { userMsg, finalAnswer, finalReference };
            } catch (err) {
                setMessages((prev) =>
                    prev.map((m) =>
                        m.id === placeholderId
                            ? {
                                  ...m,
                                  content: `⚠️ Error: ${err.message}`,
                                  _streaming: false,
                                  _thinking: false,
                                  _error: true,
                              }
                            : m,
                    ),
                );
                return null;
            } finally {
                setIsStreaming(false);
            }
        },
        [activeConversation, selectedDialog, isStreaming, setIsStreaming, setMessages],
    );

    return { sendMessage, isStreaming };
};

export default useWidgetCompletion;
