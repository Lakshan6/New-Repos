import axios from 'axios';
export const LS_KEYS = {
    AUTHORIZATION: 'ragAuthorization1',
    TENANT_ID: 'ragtenant1',
    COOKIE: 'ragCookie1',
};
export const getRagAuth = () => ({
    authorization: localStorage.getItem(LS_KEYS.AUTHORIZATION) ?? '',
    tenantId: localStorage.getItem(LS_KEYS.TENANT_ID) ?? '',
    cookie: (localStorage.getItem(LS_KEYS.COOKIE) ?? '').split(';')[0].trim(),
});
export const ragAxios = axios.create({
    baseURL: import.meta.env.VITE_RAG_BASE_URL,
    headers: { 'Content-Type': 'application/json' },
    withCredentials: true,
});
ragAxios.interceptors.request.use((config) => {
    const { authorization } = getRagAuth();
    if (authorization) config.headers.Authorization = authorization;
    return config;
});
export const RAG_APIS = {
    DIALOG_LIST: import.meta.env.VITE_DIALOG_LIST_API,
    SESSIONS_BASE: import.meta.env.VITE_SESSIONS_BASE_API,
    CONVERSATION_COMPLETION: import.meta.env.VITE_CONVERSATION_COMPLETION_API,
    KB_LIST: import.meta.env.VITE_KB_LIST_API,
    DOCUMENT_LIST: import.meta.env.VITE_DOCUMENT_LIST_API,
    DOCUMENT_UPLOAD: import.meta.env.VITE_DOCUMENT_UPLOAD_API,
    DOCUMENT_UPLOAD_AND_PARSE: import.meta.env.VITE_DOCUMENT_UPLOAD_AND_PARSE_API,
    DOCUMENT_RUN: import.meta.env.VITE_DOCUMENT_RUN_API,
    DOCUMENT_IMAGE_BASE_URL: import.meta.env.VITE_DOCUMENT_IMAGE_BASE_URL,
};

export const EXCLUDED_DIALOG_NAMES = ['self-document'];
export const SELF_DOCUMENT_KB_NAME = 'self-document';
