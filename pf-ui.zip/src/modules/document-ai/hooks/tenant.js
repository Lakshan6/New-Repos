import { STORAGE_KEYS } from '@shared/utils';

export const getRagTenantId = () => localStorage.getItem(STORAGE_KEYS.RAG_TENANT1) || '';
