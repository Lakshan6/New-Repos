import { useState, useCallback, useEffect, useRef } from 'react';
import { toast } from '../utils/toast';
import { RAG_APIS, getRagAuth } from './ragApi';
import { getRagTenantId } from './tenant';
import { useMutationApi } from '@shared/hooks';
import { STORAGE_KEYS } from '@shared/utils';

const getRagAuthHeaders = () => {
    const auth = getRagAuth();
    return {
        'Content-Type': 'application/json',
        ...(auth.authorization ? { Authorization: auth.authorization } : {}),
    };
};

export const RunningStatus = {
    UNSTART: '0', // Need to run - show play button
    RUNNING: '1', // Currently parsing - show spinner
    CANCEL: '2', // Cancelled - show refresh button (green)
    DONE: '3', // Completed successfully - show refresh button (gray)
    FAIL: '4', // Failed - show refresh button (red)
};

export const RunningStatusLabels = {
    0: 'Pending',
    1: 'Running',
    2: 'Cancelled',
    3: 'Done Successfully',
    4: 'Failed',
};

export const RunningStatusColors = {
    0: '#9CA3AF', // gray
    1: '#3B82F6', // blue
    2: '#F59E0B', // amber
    3: '#10B981', // green
    4: '#EF4444', // red
};
const headers = {
    Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN)}`,
};
// export const useParsingWithPolling = (kbId, tenantId, fetchFilesAPI) => {
//     // Track polling intervals per document
//     const pollingIntervalsRef = useRef(new Map());

//     // Track parsing states
//     const [parsingStates, setParsingStates] = useState(new Map());

//     const getAuthHeader = useCallback(() => getRagAuthHeaders(), []);

//     // Poll file progress every 1s
//     const pollFileProgress = useCallback(
//         async (documentId) => {
//             try {
//                 const normalizedDocumentId = String(documentId);
//                 const resolvedTenantId = tenantId || getRagTenantId();
//                 const response = await fetch(API_CONFIG.FILELIST, {
//                     method: 'POST',
//                     headers: getAuthHeader(),
//                     body: JSON.stringify({
//                         kb_id: kbId,
//                         tenant_id: resolvedTenantId,
//                         page: 1,
//                         page_size: 100,
//                     }),
//                 });

//                 if (!response.ok) throw new Error('Failed to fetch file list');

//                 const data = await response.json();
//                 if (data.code === 0 && data.data?.docs) {
//                     const file = data.data.docs.find(
//                         (f) => String(f.id) === normalizedDocumentId,
//                     );

//                     if (file) {
//                         // Update parsing state
//                         setParsingStates((prev) => {
//                             const newMap = new Map(prev);
//                             newMap.set(normalizedDocumentId, {
//                                 progress: file.progress || 0,
//                                 run: file.run,
//                                 progress_msg: file.progress_msg || '',
//                                 process_begin_at: file.process_begin_at,
//                                 process_duration: file.process_duration || 0,
//                                 chunk_num: file.chunk_num || 0,
//                             });
//                             return newMap;
//                         });

//                         // Stop polling if parsing is complete (run = 3) or failed (run = 4)
//                         if (file.run === '3' || file.run === '4') {
//                             const interval = pollingIntervalsRef.current.get(normalizedDocumentId);
//                             if (interval) {
//                                 clearInterval(interval);
//                                 pollingIntervalsRef.current.delete(normalizedDocumentId);
//                             }

//                             // Refresh files list
//                             if (fetchFilesAPI) {
//                                 try {
//                                     await fetchFilesAPI(kbId);
//                                 } catch (err) {
//                                     console.error('Error refreshing files:', err);
//                                 }
//                             }

//                             if (file.run === '3') {
//                                 toast.success(
//                                     `${file.name || 'File'} parsing completed successfully!`,
//                                 );
//                             } else if (file.run === '4') {
//                                 toast.error(`${file.name || 'File'} parsing failed`);
//                             }
//                         }
//                     }
//                 }
//             } catch (err) {
//                 console.error('Error polling file progress:', err);
//             }
//         },
//         [kbId, tenantId, getAuthHeader, fetchFilesAPI],
//     );

export const useParsingWithPolling = (kbId, tenantId, fetchFilesAPI) => {
    const pollingIntervalsRef = useRef(new Map());
    const [parsingStates, setParsingStates] = useState(new Map());

    const getAuthHeader = useCallback(() => getRagAuthHeaders(), []);

    const fileListMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/filelist',
        method: 'POST',
        useGateway: true,
        headers,
    });

    const { mutateAsync: fileListApi } = fileListMutation;

    // Poll file progress using the mutation
    const pollFileProgress = useCallback(
        async (documentId) => {
            try {
                if (!kbId || !documentId) return;

                const normalizedDocumentId = String(documentId);
                const resolvedTenantId = tenantId || getRagTenantId();

                const data = await fileListApi({
                    body: {
                        kb_id: kbId,
                        tenant_id: resolvedTenantId,
                        page: 1,
                        page_size: 100,
                    },
                });

                if (data?.code !== 0 || !data?.data?.docs) return;

                const file = data.data.docs.find((f) => String(f.id) === normalizedDocumentId);

                if (!file) return;

                setParsingStates((prev) => {
                    const next = new Map(prev);
                    // next.set(normalizedDocumentId, {
                    //     progress: file.progress || 0,
                    next.set(normalizedDocumentId, {
                        progress: file.progress || 0,
                        run: file.run,
                        progress_msg: file.progress_msg || '',
                        process_begin_at: file.process_begin_at,
                        process_duration: file.process_duration || 0,
                        chunk_num: file.chunk_num || 0,
                    });
                    return next;
                });

                // Stop polling if done or failed
                if (file.run === '3' || file.run === '4') {
                    const interval = pollingIntervalsRef.current.get(normalizedDocumentId);

                    if (interval) {
                        clearInterval(interval);
                        pollingIntervalsRef.current.delete(normalizedDocumentId);
                    }

                    // refresh file list (optional)
                    if (fetchFilesAPI && kbId) {
                        try {
                            await fetchFilesAPI(kbId);
                        } catch (err) {
                            console.error('Error refreshing files:', err);
                        }
                    }

                    if (file.run === '3') {
                        toast.success(`${file.name || 'File'} parsing completed successfully!`);
                    }

                    if (file.run === '4') {
                        toast.error(`${file.name || 'File'} parsing failed`);
                    }
                }
            } catch (err) {
                console.error('Error polling file progress:', err);
            }
        },
        [kbId, tenantId, fileListApi, fetchFilesAPI],
    );
    // Start parsing - triggers API call and polling for single or multiple files
    // Sends: { doc_ids: ["id1", "id2", ...], run: 1, delete: false }
    const startParsing = useCallback(
        async (documentIds, fileNames) => {
            // Handle both single and multiple files
            const docIdsArray = (Array.isArray(documentIds) ? documentIds : [documentIds]).map(
                (id) => String(id),
            );
            const namesArray = Array.isArray(fileNames) ? fileNames : [fileNames];

            // Check if any file is already parsing
            const alreadyParsing = docIdsArray.filter((id) => parsingStates.get(id)?.run === '1');
            if (alreadyParsing.length > 0) {
                toast.info(`${alreadyParsing.length} file(s) already parsing...`);
                return;
            }

            try {
                // Call run API with doc_ids array, run: 1, delete: false
                const response = await fetch(RAG_APIS.DOCUMENT_RUN, {
                    method: 'POST',
                    headers: getAuthHeader(),
                    body: JSON.stringify({
                        delete: false,
                        doc_ids: docIdsArray,
                        run: 1,
                    }),
                });

                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(errorData.message || `Server error: ${response.status}`);
                }

                const fileCount = docIdsArray.length;
                const fileMessage = fileCount === 1 ? `"${namesArray[0]}"` : `${fileCount} file(s)`;
                toast.success(`${fileMessage} parsing started!`);

                // Set initial state as running for all selected files
                setParsingStates((prev) => {
                    const newMap = new Map(prev);
                    docIdsArray.forEach((docId) => {
                        newMap.set(docId, {
                            progress: 0,
                            run: '1',
                            progress_msg: 'Starting parsing...',
                            process_begin_at: new Date().toLocaleString(),
                            process_duration: 0,
                            chunk_num: 0,
                        });
                    });
                    return newMap;
                });

                // Start polling for each file if not already polling
                docIdsArray.forEach((docId) => {
                    if (!pollingIntervalsRef.current.has(docId)) {
                        const interval = setInterval(() => {
                            pollFileProgress(docId);
                        }, 1000); // Poll every 1s

                        pollingIntervalsRef.current.set(docId, interval);
                    }
                    // Initial poll
                    pollFileProgress(docId);
                });
            } catch (err) {
                console.error('Error starting parsing:', err);
                toast.error(err.message || `Failed to start parsing`);
            }
        },
        [parsingStates, getAuthHeader, pollFileProgress],
    );

    // Refresh/Retry parsing (for DONE, CANCEL, FAIL buttons)
    // Sends: { doc_ids: ["id1", "id2",...], run: 1, delete: true }
    const refreshParsing = useCallback(
        async (documentIds, fileNames) => {
            const docIdsArray = (Array.isArray(documentIds) ? documentIds : [documentIds]).map(
                (id) => String(id),
            );
            const namesArray = Array.isArray(fileNames) ? fileNames : [fileNames];

            try {
                const response = await fetch(RAG_APIS.DOCUMENT_RUN, {
                    method: 'POST',
                    headers: getAuthHeader(),
                    body: JSON.stringify({
                        delete: true,
                        doc_ids: docIdsArray,
                        run: 1,
                    }),
                });

                if (!response.ok) {
                    const errorData = await response.json().catch(() => ({}));
                    throw new Error(errorData.message || `Server error: ${response.status}`);
                }

                const fileCount = docIdsArray.length;
                const fileMessage = fileCount === 1 ? `"${namesArray[0]}"` : `${fileCount} file(s)`;
                toast.success(`${fileMessage} parsing restarted!`);

                // Set initial state as running
                setParsingStates((prev) => {
                    const newMap = new Map(prev);
                    docIdsArray.forEach((docId) => {
                        newMap.set(docId, {
                            progress: 0,
                            run: '1',
                            progress_msg: 'Restarting parsing...',
                            process_begin_at: new Date().toLocaleString(),
                            process_duration: 0,
                            chunk_num: 0,
                        });
                    });
                    return newMap;
                });

                // Start polling for each file if not already polling
                docIdsArray.forEach((docId) => {
                    if (!pollingIntervalsRef.current.has(docId)) {
                        const interval = setInterval(() => {
                            pollFileProgress(docId);
                        }, 1000);

                        pollingIntervalsRef.current.set(docId, interval);
                    }
                    // Initial poll
                    pollFileProgress(docId);
                });
            } catch (err) {
                console.error('Error refreshing parsing:', err);
                toast.error(err.message || `Failed to refresh parsing`);
            }
        },
        [getAuthHeader, pollFileProgress],
    );

    // Cancel parsing - for single or multiple files
    // Sends: { doc_ids: ["id1", "id2",...], run: 2, delete: false }
    const cancelParsing = useCallback(
        async (documentIds, fileNames) => {
            const docIdsArray = (Array.isArray(documentIds) ? documentIds : [documentIds]).map(
                (id) => String(id),
            );
            const namesArray = Array.isArray(fileNames) ? fileNames : [fileNames];

            try {
                const response = await fetch(RAG_APIS.DOCUMENT_RUN, {
                    method: 'POST',
                    headers: getAuthHeader(),
                    body: JSON.stringify({
                        doc_ids: docIdsArray,
                        run: 2,
                        delete: false,
                    }),
                });

                if (!response.ok) {
                    throw new Error('Failed to cancel parsing');
                }

                const fileCount = docIdsArray.length;
                const fileMessage = fileCount === 1 ? `"${namesArray[0]}"` : `${fileCount} file(s)`;
                toast.success(`${fileMessage} parsing cancelled!`);

                // Stop polling for each file
                docIdsArray.forEach((docId) => {
                    const interval = pollingIntervalsRef.current.get(docId);
                    if (interval) {
                        clearInterval(interval);
                        pollingIntervalsRef.current.delete(docId);
                    }
                });

                // Update state to cancelled
                setParsingStates((prev) => {
                    const newMap = new Map(prev);
                    docIdsArray.forEach((docId) => {
                        const current = newMap.get(docId);
                        if (current) {
                            newMap.set(docId, { ...current, run: '2' });
                        }
                    });
                    return newMap;
                });

                if (fetchFilesAPI && kbId) {
                    try {
                        await fetchFilesAPI(kbId);
                    } catch (err) {
                        console.error('Error refreshing files after cancel:', err);
                    }
                }
            } catch (err) {
                console.error('Error cancelling parsing:', err);
                toast.error(err.message || 'Failed to cancel parsing');
            }
        },
        [getAuthHeader],
    );

    // Get parsing state for a document
    const getParsingState = useCallback(
        (documentId) => {
            return parsingStates.get(String(documentId));
        },
        [parsingStates],
    );

    // Cleanup intervals on unmount
    useEffect(() => {
        const pollingIntervals = pollingIntervalsRef.current;
        return () => {
            pollingIntervals.forEach((interval) => clearInterval(interval));
            pollingIntervals.clear();
        };
    }, []);

    return {
        parsingStates,
        startParsing,
        refreshParsing,
        cancelParsing,
        getParsingState,
    };
};
