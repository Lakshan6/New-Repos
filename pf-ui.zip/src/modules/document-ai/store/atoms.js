import { atom } from 'jotai';

// Document AI Widget Global State
export const daiWidgetOpenAtom = atom(false);

export const daiSelectedDialogAtom = atom(null);

export const daiDialogListAtom = atom([]);

export const daiConversationListAtom = atom([]);

export const daiActiveConversationAtom = atom(null);

export const daiIsStreamingAtom = atom(false);

export const INITIAL_DAI_MESSAGE = {
    id: 'init-msg',
    role: 'assistant',
    content: 'Hello! How can I help you today?',
};

export const daiMessagesAtom = atom([INITIAL_DAI_MESSAGE]);
