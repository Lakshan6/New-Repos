import { useEffect } from 'react';
import { Routes, Route, Navigate, useNavigate, useParams } from 'react-router-dom';
import { useSetAtom } from 'jotai';
import KnowledgeBaseDashboard from '../screens/KnowledgeBaseDashboard';
import DatasetFilesPage from '../screens/DatasetFilesPage';
import { NotFoundPage } from '@shared/screens';
import { daiWidgetOpenAtom } from '../store/atoms';

// Component to trigger AI Assistant widget and return to doc-repo
const AiWidgetTrigger = () => {
    const setWidgetOpen = useSetAtom(daiWidgetOpenAtom);
    const navigate = useNavigate();

    useEffect(() => {
        setWidgetOpen(true);
        // Replace current URL with doc-repo so layout remains stable
        navigate('../doc-repo', { replace: true });
    }, [setWidgetOpen, navigate]);

    return null;
};

const DashboardWrapper = () => {
    const navigate = useNavigate();
    return <KnowledgeBaseDashboard onSelectDataset={(id) => navigate(`dataset/${id}`)} />;
};

const DatasetFilesWrapper = () => {
    const { id } = useParams();
    const navigate = useNavigate();
    return <DatasetFilesPage datasetId={id} onBack={() => navigate(-1)} />;
};

const Router = () => {
    return (
        <Routes>
            {/* Default to doc-repo if they land here */}
            <Route index element={<Navigate to="doc-repo" replace />} />

            {/* Doc Repo Pages */}
            <Route path="doc-repo" element={<DashboardWrapper />} />
            <Route path="doc-repo/dataset/:id" element={<DatasetFilesWrapper />} />

            {/* AI Assistant (Widget Trigger) */}
            <Route path="ai" element={<AiWidgetTrigger />} />

            <Route path="*" element={<NotFoundPage />} />
        </Routes>
    );
};

export default Router;
