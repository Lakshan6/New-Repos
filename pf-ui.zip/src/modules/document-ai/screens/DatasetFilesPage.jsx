import { useEffect, useState, useMemo, useCallback } from 'react';
import PropTypes from 'prop-types';
import { toast } from '../utils/toast';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Checkbox } from 'primereact/checkbox';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Card, PageLayout } from '@shared/components';

import { useDatasetAPI } from '../hooks/useDatasetAPI';
import { useFileUpload } from '../hooks/useFileUpload';
import { useParsingWithPolling } from '../hooks/useParsingWithPolling';
import { ParsingStatusCell } from '../../document-library/components/ParsingStatusCell';
import { getFileStatusBadge, filterFiles } from '../../document-library/utils/fileHelpers';
import FilePreviewDialog from '../../document-library/components/FilePreviewDialog';
import { getRagTenantId } from '../hooks/tenant';

const PRIMARY = 'var(--primary-color)';
const PRIMARY_BG = 'var(--surface-hover)';

function cycleSort(prev, key) {
    if (prev.key !== key) return { key, direction: 'asc' };
    if (prev.direction === 'asc') return { key, direction: 'desc' };
    if (prev.direction === 'desc') return { key: null, direction: null };
    return { key, direction: 'asc' };
}

function sortList(list, sortConfig, dateKeys = []) {
    if (!sortConfig.key || !sortConfig.direction) return list;
    return [...list].sort((a, b) => {
        let valA = a[sortConfig.key] ?? '';
        let valB = b[sortConfig.key] ?? '';
        if (dateKeys.includes(sortConfig.key)) {
            valA = valA ? new Date(valA) : new Date(0);
            valB = valB ? new Date(valB) : new Date(0);
            return sortConfig.direction === 'asc' ? valA - valB : valB - valA;
        }
        if (typeof valA === 'number' && typeof valB === 'number') {
            return sortConfig.direction === 'asc' ? valA - valB : valB - valA;
        }
        valA = valA.toString().toLowerCase();
        valB = valB.toString().toLowerCase();
        if (valA < valB) return sortConfig.direction === 'asc' ? -1 : 1;
        if (valA > valB) return sortConfig.direction === 'asc' ? 1 : -1;
        return 0;
    });
}

export default function DatasetFilesPage({ datasetId, onBack }) {
    const id = datasetId;

    const [files, setFiles] = useState([]);
    const [loading, setLoading] = useState(false);
    const [detailsLoading, setDetailsLoading] = useState(true);
    const [searchQuery, setSearchQuery] = useState('');
    const [selectedFiles, setSelectedFiles] = useState(new Set());
    const [showUploadDialog, setShowUploadDialog] = useState(false);
    const [selectedFile, setSelectedFile] = useState(null);
    const [datasetInfo, setDatasetInfo] = useState(null);
    const [hoverFileId, setHoverFileId] = useState(null);
    const [previewFile, setPreviewFile] = useState(null);
    const [fileSortConfig, setFileSortConfig] = useState({ key: null, direction: null });

    const handleFileSort = useCallback(
        (key) => setFileSortConfig((prev) => cycleSort(prev, key)),
        [],
    );

    const { fetchDatasetDetails, fetchFiles: fetchFilesAPI } = useDatasetAPI();
    const tenantId = getRagTenantId();
    const { uploading, uploadFile } = useFileUpload(id, tenantId);
    const { startParsing, cancelParsing, getParsingState, parsingStates } = useParsingWithPolling(
        id,
        tenantId,
        fetchFilesAPI,
    );

    const formatUploadDate = (dateStr) => {
        if (!dateStr) return '-';
        const [datePart, timePart] = dateStr.split('T');
        if (!datePart) return '-';
        const [yyyy, mm, dd] = datePart.split('-');
        return `${dd}-${mm}-${yyyy} ${timePart || ''}`.trim();
    };

    useEffect(() => {
        const loadDatasetDetails = async () => {
            if (!id) return;
            setDetailsLoading(true);
            try {
                const details = await fetchDatasetDetails(id);
                setDatasetInfo(details);
            } catch {
                toast.error('❌ Failed to load dataset details');
            } finally {
                setDetailsLoading(false);
            }
        };
        loadDatasetDetails();
    }, [id, fetchDatasetDetails]);

    useEffect(() => {
        const loadData = async () => {
            if (!datasetInfo || !tenantId) return;
            try {
                const filesData = await fetchFilesAPI(datasetInfo.id);
                setFiles(filesData);
            } catch {
                toast.error('❌ Failed to load files');
            } finally {
                setLoading(false);
            }
        };
        loadData();
    }, [datasetInfo, tenantId, fetchFilesAPI]);

    const filteredFiles = useMemo(() => filterFiles(files, searchQuery), [files, searchQuery]);

    const sortedFiles = useMemo(() => {
        const base = fileSortConfig.key
            ? sortList(filteredFiles, fileSortConfig, ['create_time'])
            : [...filteredFiles].sort((a, b) => new Date(b.create_time) - new Date(a.create_time));
        return base.map((file) => ({
            ...file,
            _parsingUpdate: parsingStates.get(String(file.id))?.progress || 0,
            _selected: selectedFiles.has(file.id),
        }));
    }, [filteredFiles, fileSortConfig, parsingStates, selectedFiles]);

    const handleFileSelect = useCallback((e) => {
        const file = e.target.files?.[0];
        if (file) {
            setSelectedFile(file);
            toast.success(`📁 File selected: ${file.name}`);
        }
    }, []);

    const handleFileUpload = useCallback(async () => {
        if (!selectedFile) {
            toast.warning('Please select a file to upload');
            return;
        }
        if (!datasetInfo?.name) {
            toast.error('Dataset name not loaded');
            return;
        }
        const fileName = selectedFile.name;
        const toastId = toast.loading(`Uploading "${fileName}"...`);
        try {
            await uploadFile(selectedFile, datasetInfo.name, async () => {
                setShowUploadDialog(false);
                setSelectedFile(null);
                const filesData = await fetchFilesAPI(id);
                setFiles(filesData);
                toast.dismiss(toastId);
            });
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Failed to upload "${fileName}": ${err.message}`);
        }
    }, [selectedFile, datasetInfo, uploadFile, fetchFilesAPI, id]);

    const handleParseFile = useCallback(
        async (documentId, fileName) => {
            toast.loading(`⏳ Starting to parse "${fileName}"...`);
            await startParsing(documentId, fileName);
        },
        [startParsing],
    );

    const handleCancelParsing = useCallback(
        async (documentId, fileName) => {
            toast.loading(`⛔ Cancelling parsing for "${fileName}"...`);
            await cancelParsing(documentId, fileName);
        },
        [cancelParsing],
    );

    const handleBulkParseFiles = useCallback(async () => {
        if (selectedFiles.size === 0) return;
        const docIds = Array.from(selectedFiles);
        const fileNames = docIds
            .map((fid) => filteredFiles.find((f) => f.id === fid)?.name)
            .filter(Boolean);
        const toastId = toast.loading(`Parsing ${docIds.length} file(s)...`);
        try {
            await startParsing(docIds, fileNames);
            toast.dismiss(toastId);
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Failed to parse files: ${err.message}`);
        }
    }, [selectedFiles, filteredFiles, startParsing]);

    const handleBulkCancelParsing = useCallback(async () => {
        if (selectedFiles.size === 0) return;
        const docIds = Array.from(selectedFiles);
        const fileNames = docIds
            .map((fid) => filteredFiles.find((f) => f.id === fid)?.name)
            .filter(Boolean);
        const toastId = toast.loading(`Cancelling parsing for ${docIds.length} file(s)...`);
        try {
            await cancelParsing(docIds, fileNames);
            toast.dismiss(toastId);
            toast.success(`✅ Parsing cancelled for ${docIds.length} file(s)`);
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Failed to cancel parsing: ${err.message}`);
        }
    }, [selectedFiles, filteredFiles, cancelParsing]);

    const handleDeleteSingleFile = useCallback(
        async (fileId, fileName) => {
            if (
                !window.confirm(
                    `Are you sure you want to delete "${fileName}"? This action cannot be undone.`,
                )
            ) {
                toast.info('Delete operation cancelled');
                return;
            }
            const toastId = toast.loading(`Deleting "${fileName}"...`);
            try {
                const DATASET_API = import.meta.env.VITE_DATASET_API;
                const url = `${DATASET_API}/${id}/documents`;
                const response = await fetch(url, {
                    method: 'DELETE',
                    credentials: 'include',
                    headers: {
                        'Content-Type': 'application/json',
                        ...(localStorage.getItem('ragAuthorization1')
                            ? { Authorization: localStorage.getItem('ragAuthorization1') }
                            : {}),
                    },
                    body: JSON.stringify({ ids: [fileId] }),
                });
                const data = await response.json();
                if (response.ok && data.code === 0) {
                    toast.dismiss(toastId);
                    const updatedFiles = await fetchFilesAPI(id);
                    setFiles(updatedFiles);
                    setSelectedFiles((prev) => {
                        const s = new Set(prev);
                        s.delete(fileId);
                        return s;
                    });
                    toast.success(`✅ File "${fileName}" deleted successfully!`);
                } else {
                    toast.dismiss(toastId);
                    toast.error(
                        `❌ Failed to delete "${fileName}": ${data.message || 'Unknown error'}`,
                    );
                }
            } catch (err) {
                toast.dismiss(toastId);
                toast.error(`❌ Error deleting "${fileName}": ${err.message}`);
            }
        },
        [fetchFilesAPI, id],
    );

    const handleBulkDeleteFiles = useCallback(async () => {
        if (selectedFiles.size === 0) return;
        if (
            !window.confirm(
                `Are you sure you want to delete ${selectedFiles.size} file(s)? This action cannot be undone.`,
            )
        ) {
            toast.info('Delete operation cancelled');
            return;
        }
        const docIds = Array.from(selectedFiles);
        const toastId = toast.loading(`Deleting ${docIds.length} file(s)...`);
        try {
            const DATASET_API = import.meta.env.VITE_DATASET_API;
            const url = `${DATASET_API}/${id}/documents`;
            const response = await fetch(url, {
                method: 'DELETE',
                credentials: 'include',
                headers: {
                    'Content-Type': 'application/json',
                    ...(localStorage.getItem('ragAuthorization1')
                        ? { Authorization: localStorage.getItem('ragAuthorization1') }
                        : {}),
                },
                body: JSON.stringify({ ids: docIds }),
            });
            const data = await response.json();
            if (response.ok && data.code === 0) {
                toast.dismiss(toastId);
                const updatedFiles = await fetchFilesAPI(id);
                setFiles(updatedFiles);
                setSelectedFiles(new Set());
                toast.success(`✅ ${docIds.length} file(s) deleted successfully!`);
            } else {
                toast.dismiss(toastId);
                toast.error(`❌ Failed to delete files: ${data.message || 'Unknown error'}`);
            }
        } catch (err) {
            toast.dismiss(toastId);
            toast.error(`❌ Error deleting files: ${err.message}`);
        }
    }, [selectedFiles, fetchFilesAPI, id]);

    const toggleFileSelection = useCallback((fileId) => {
        setSelectedFiles((prev) => {
            const s = new Set(prev);
            s.has(fileId) ? s.delete(fileId) : s.add(fileId);
            return s;
        });
    }, []);

    const toggleAllFiles = useCallback(() => {
        setSelectedFiles((prev) =>
            prev.size === filteredFiles.length
                ? new Set()
                : new Set(filteredFiles.map((f) => f.id)),
        );
    }, [filteredFiles]);

    const handleBack = useCallback(() => {
        if (onBack) onBack();
    }, [onBack]);

    const handleOpenUpload = useCallback(() => setShowUploadDialog(true), []);
    const handleCloseUpload = useCallback(() => {
        setShowUploadDialog(false);
        setSelectedFile(null);
    }, []);
    const handleClosePreview = useCallback(() => setPreviewFile(null), []);
    const handleFileSearchChange = useCallback((e) => setSearchQuery(e.target.value), []);

    if (detailsLoading) {
        return (
            <div className="w-full min-h-screen flex items-center justify-center">
                <div className="text-center">
                    <ProgressSpinner
                        style={{ width: '48px', height: '48px' }}
                        className="mx-auto mb-4"
                    />
                    <p className="text-color-secondary">Loading dataset details...</p>
                </div>
            </div>
        );
    }

    if (!datasetInfo) {
        return (
            <div className="w-full min-h-screen flex flex-col items-center justify-center">
                <p className="text-red-600 text-lg font-semibold mb-4">Failed to load dataset</p>
                <Button label="Back to Dashboard" onClick={handleBack} />
            </div>
        );
    }

    // ── Column body templates ─────────────────────────────────────────────────
    const fileCheckboxTemplate = (file) => (
        <Checkbox
            checked={selectedFiles.has(file.id)}
            onChange={() => toggleFileSelection(file.id)}
        />
    );

    const fileNameTemplate = (file) => (
        <button
            onClick={() => setPreviewFile(file)}
            className="flex items-center gap-2 group text-left transition-colors"
            title={`Preview ${file.name}`}
            style={{ color: 'inherit' }}
        >
            <i className="pi pi-file flex-shrink-0" style={{ color: '#ef4444' }} />
            <span className="group-hover:underline underline-offset-2" style={{ color: PRIMARY }}>
                {file.name}
            </span>
            <i
                className="pi pi-eye flex-shrink-0 text-xs opacity-0 group-hover:opacity-100 transition-opacity"
                style={{ color: PRIMARY }}
            />
        </button>
    );

    const fileDateTemplate = (file) => (
        <span className="text-color-secondary text-sm">{formatUploadDate(file.create_date)}</span>
    );

    const fileStatusTemplate = (file) => {
        const statusBadge = getFileStatusBadge(file.status);
        return (
            <span
                className={`inline-flex items-center px-2 py-1 rounded text-xs font-semibold ${statusBadge.className}`}
            >
                {statusBadge.label}
            </span>
        );
    };

    const fileParseTemplate = (file) => {
        const parsingState = getParsingState(file.id);
        return (
            <ParsingStatusCell
                file={file}
                parsingState={parsingState}
                onStartParsing={handleParseFile}
                onCancelParsing={handleCancelParsing}
            />
        );
    };

    const fileActionTemplate = (file) => (
        <button
            onClick={() => handleDeleteSingleFile(file.id, file.name)}
            onMouseEnter={() => setHoverFileId(file.id)}
            onMouseLeave={() => setHoverFileId(null)}
            className={`p-2 rounded-lg transition-all duration-200 ${hoverFileId === file.id ? 'bg-red-50 text-red-600 shadow-md scale-110' : 'text-color-secondary'}`}
            title="Delete file"
        >
            <i className="pi pi-trash" style={{ fontSize: '1.1rem' }} />
        </button>
    );

    const uploadFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined disabled={uploading} onClick={handleCloseUpload} />
            <Button
                label={uploading ? 'Uploading...' : 'Upload'}
                icon={uploading ? 'pi pi-spin pi-spinner' : undefined}
                disabled={!selectedFile || uploading}
                style={{ backgroundColor: PRIMARY, border: 'none' }}
                onClick={handleFileUpload}
            />
        </div>
    );

    return (
        <PageLayout className="w-full">
            <PageLayout.Header
                title={datasetInfo?.name || 'Dataset Details'}
                backButton
                onBack={handleBack}
            />

            <PageLayout.Content>
                <div className="flex flex-column h-full">
                    {/* Toolbar */}
                    <div
                        className="bg-white rounded-lg shadow-md p-3 border-l-4 mb-3"
                        style={{ borderLeftColor: PRIMARY }}
                    >
                        <div className="flex items-center justify-between gap-3 mb-3">
                            <span className="text-xs font-semibold text-color-secondary">
                                Selected: {selectedFiles.size} Files
                            </span>
                            {selectedFiles.size > 0 && (
                                <div className="flex items-center gap-2">
                                    <Button
                                        label={`Parse All (${selectedFiles.size})`}
                                        style={{
                                            backgroundColor: '#22c55e',
                                            border: 'none',
                                            height: '2rem',
                                            fontSize: '0.75rem',
                                            padding: '0 0.75rem',
                                        }}
                                        onClick={handleBulkParseFiles}
                                    />
                                    <Button
                                        label={`Cancel Parse (${selectedFiles.size})`}
                                        style={{
                                            backgroundColor: '#f97316',
                                            border: 'none',
                                            height: '2rem',
                                            fontSize: '0.75rem',
                                            padding: '0 0.75rem',
                                        }}
                                        onClick={handleBulkCancelParsing}
                                    />
                                    <Button
                                        label={`Delete (${selectedFiles.size})`}
                                        severity="danger"
                                        style={{
                                            height: '2rem',
                                            fontSize: '0.75rem',
                                            padding: '0 0.75rem',
                                        }}
                                        onClick={handleBulkDeleteFiles}
                                    />
                                </div>
                            )}
                        </div>
                        <div className="flex items-center gap-2">
                            <span className="p-input-icon-left relative flex-1">
                                <i className="pi pi-search absolute left-3 top-1/2 -translate-y-1/2 text-color-secondary" />
                                <InputText
                                    placeholder="Search files..."
                                    value={searchQuery}
                                    onChange={handleFileSearchChange}
                                    className="pl-10 py-1 text-sm w-full border-200"
                                />
                            </span>
                            <Button
                                label="Add File"
                                icon="pi pi-upload"
                                style={{
                                    backgroundColor: PRIMARY,
                                    border: 'none',
                                    height: '2rem',
                                    fontSize: '0.75rem',
                                    padding: '0 0.75rem',
                                }}
                                onClick={handleOpenUpload}
                            />
                        </div>
                    </div>

                    {/* Files Table */}
                    <div className="bg-white rounded-lg shadow-md overflow-hidden border-1 border-200 flex-1">
                        {loading ? (
                            <div className="flex justify-content-center align-items-center py-12">
                                <ProgressSpinner style={{ width: '48px', height: '48px' }} />
                            </div>
                        ) : sortedFiles.length === 0 ? (
                            <div className="flex flex-column items-center justify-content-center py-12">
                                <i
                                    className="pi pi-file text-300 mb-4"
                                    style={{ fontSize: '4rem' }}
                                />
                                <p className="text-500 text-lg font-semibold">No files found</p>
                            </div>
                        ) : (
                            <DataTable
                                value={sortedFiles}
                                tableStyle={{ minWidth: '40rem' }}
                                pt={{ headerRow: { style: { background: PRIMARY_BG } } }}
                                scrollable
                                scrollHeight="flex"
                            >
                                <Column
                                    header={
                                        <Checkbox
                                            checked={
                                                selectedFiles.size === filteredFiles.length &&
                                                filteredFiles.length > 0
                                            }
                                            onChange={toggleAllFiles}
                                        />
                                    }
                                    body={fileCheckboxTemplate}
                                    style={{ width: '3rem' }}
                                    headerClassName="py-4"
                                />
                                <Column
                                    field="name"
                                    header="Name"
                                    sortable
                                    body={fileNameTemplate}
                                    headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                    onHeaderClick={() => handleFileSort('name')}
                                    bodyClassName="py-3"
                                />
                                <Column
                                    field="create_date"
                                    header="Upload Date"
                                    sortable
                                    body={fileDateTemplate}
                                    headerStyle={{ color: PRIMARY, fontWeight: 700 }}
                                    onHeaderClick={() => handleFileSort('create_time')}
                                    bodyClassName="py-3"
                                />
                                <Column
                                    field="status"
                                    header="Enabled"
                                    body={fileStatusTemplate}
                                    headerStyle={{
                                        color: PRIMARY,
                                        fontWeight: 700,
                                        textAlign: 'center',
                                    }}
                                    bodyClassName="text-center py-3"
                                />
                                <Column
                                    header="Parse"
                                    body={fileParseTemplate}
                                    headerStyle={{
                                        color: PRIMARY,
                                        fontWeight: 700,
                                        textAlign: 'center',
                                    }}
                                    bodyClassName="text-center py-3"
                                />
                                <Column
                                    header="Action"
                                    body={fileActionTemplate}
                                    headerStyle={{
                                        color: PRIMARY,
                                        fontWeight: 700,
                                        textAlign: 'center',
                                    }}
                                    bodyClassName="text-center py-3"
                                />
                            </DataTable>
                        )}
                    </div>
                </div>
            </PageLayout.Content>

            {/* FILE PREVIEW DIALOG */}
            {previewFile && <FilePreviewDialog file={previewFile} onClose={handleClosePreview} />}

            {/* UPLOAD DIALOG */}
            <Dialog
                visible={showUploadDialog}
                onHide={handleCloseUpload}
                header="Upload File to Dataset"
                footer={uploadFooter}
                style={{ width: '28rem' }}
            >
                <div className="space-y-4">
                    <button
                        type="button"
                        className="border-2 border-dashed rounded-lg p-6 text-center cursor-pointer transition w-full"
                        style={{ borderColor: PRIMARY }}
                        onClick={() => document.getElementById('dai-fileInput')?.click()}
                    >
                        <i
                            className="pi pi-upload mb-2"
                            style={{ fontSize: '2rem', color: PRIMARY }}
                        />
                        <p className="text-sm font-medium mt-2">
                            {selectedFile ? selectedFile.name : 'Click to select a file'}
                        </p>
                        <p className="text-xs text-color-secondary mt-1">
                            {selectedFile
                                ? `Size: ${(selectedFile.size / 1024 / 1024).toFixed(2)} MB`
                                : 'PDF, DOC, DOCX, TXT, Images, etc.'}
                        </p>
                        <input
                            id="dai-fileInput"
                            type="file"
                            onChange={handleFileSelect}
                            className="hidden"
                            accept=".pdf,.doc,.docx,.txt,.jpg,.jpeg,.png,.pptx,.ppt,.xlsx,.xls"
                        />
                    </button>
                </div>
            </Dialog>
        </PageLayout>
    );
}

DatasetFilesPage.propTypes = {
    datasetId: PropTypes.string.isRequired,
    onBack: PropTypes.func,
};
