import { useEffect, useMemo, useState, useRef, useCallback } from 'react';
import PropTypes from 'prop-types';
import { toast } from '../utils/toast';
import { Button } from 'primereact/button';
import { InputText } from 'primereact/inputtext';
import { Dialog } from 'primereact/dialog';
import { Card, PageLayout } from '@shared/components';
import WidgetDatasetTable from '../components/WidgetDatasetTable';
import { STORAGE_KEYS } from '@shared/utils';
import { getRagTenantId } from '../hooks/tenant';
import { getRagAuth } from '../hooks/ragApi';
import { useMutationApi } from '@shared/hooks';

export default function KnowledgeBaseDashboard({ onSelectDataset }) {
    const [datasets, setDatasets] = useState([]);
    const [loading, setLoading] = useState(false);
    const [searchQuery, setSearchQuery] = useState('');
    const [appliedSearchQuery, setAppliedSearchQuery] = useState('');
    const [searchTrigger, setSearchTrigger] = useState(0);
    const [isSearching, setIsSearching] = useState(false);
    const [error, setError] = useState('');
    const [renameDialogOpen, setRenameDialogOpen] = useState(false);
    const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
    const [selectedDataset, setSelectedDataset] = useState(null);
    const [newName, setNewName] = useState('');
    const [createDialogOpen, setCreateDialogOpen] = useState(false);
    const [newDatasetName, setNewDatasetName] = useState('');
    const [pagination, setPagination] = useState({ current: 1, pageSize: 10, total: 0 });

    const searchTimeoutRef = useRef(null);
    const currentPage = pagination.current;
    const pageSize = pagination.pageSize;

    const ragAuth = getRagAuth();
    const headers = {
        Authorization: `Bearer ${localStorage.getItem(STORAGE_KEYS.AUTH_TOKEN) || localStorage.getItem('Token') || localStorage.getItem('Authorization') || ''}`,
        'X-Tenant-Id': getRagTenantId(),
    };

    useEffect(() => {
        if (getRagTenantId()) {
            setSearchTrigger((prev) => prev + 1);
        }
    }, []);

    useEffect(() => {
        return () => {
            if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        };
    }, []);

    const fetchDatasetsMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/fetchdata',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: fetchDatasetsApi } = fetchDatasetsMutation;

    const fetchDatasets = useCallback(
        async (searchTerm = '') => {
            setLoading(true);
            setError('');
            try {
                const tenantId = getRagTenantId();
                const data = await fetchDatasetsApi({
                    body: {
                        tenant_id: tenantId,
                        page: currentPage,
                        page_size: pageSize,
                        keywords: searchTerm,
                    },
                });
                if (data.code === 0 && data.data?.kbs) {
                    setDatasets(data.data.kbs);
                    setPagination((prev) => ({ ...prev, total: data.data.total || 0 }));
                } else {
                    setError(data.message || 'Failed to fetch datasets');
                    toast.error(data.message || 'Failed to fetch datasets');
                }
            } catch (err) {
                console.error(err);
                setError('Error fetching datasets');
                toast.error('Failed to load datasets');
            } finally {
                setLoading(false);
                setIsSearching(false);
            }
        },
        [currentPage, pageSize, fetchDatasetsApi],
    );

    useEffect(() => {
        if (getRagTenantId()) {
            fetchDatasets(appliedSearchQuery);
        }
    }, [appliedSearchQuery, fetchDatasets, searchTrigger]);

    const debouncedSearch = useCallback((query) => {
        setSearchQuery(query);
        if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        setIsSearching(true);
        searchTimeoutRef.current = setTimeout(() => {
            setPagination((prev) => ({ ...prev, current: 1 }));
            setAppliedSearchQuery(query);
            setSearchTrigger((prev) => prev + 1);
        }, 300);
    }, []);

    const handleSearch = useCallback(() => {
        if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        setIsSearching(true);
        setPagination((prev) => ({ ...prev, current: 1 }));
        setAppliedSearchQuery(searchQuery);
        setSearchTrigger((prev) => prev + 1);
    }, [searchQuery]);

    const handleKeyPress = useCallback((e) => {
        if (e.key === 'Enter') {
            e.preventDefault();
            if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
            setPagination((prev) => ({ ...prev, current: 1 }));
        }
    }, []);

    const handleClearSearch = useCallback(() => {
        setSearchQuery('');
        if (searchTimeoutRef.current) clearTimeout(searchTimeoutRef.current);
        setPagination((prev) => ({ ...prev, current: 1 }));
        setAppliedSearchQuery('');
        setSearchTrigger((prev) => prev + 1);
    }, []);

    const handlePageChange = useCallback((page) => {
        setPagination((prev) => ({ ...prev, current: page }));
    }, []);

    const handleRename = useCallback((dataset) => {
        setSelectedDataset(dataset);
        setNewName(dataset.name);
        setRenameDialogOpen(true);
    }, []);

    const handleDelete = useCallback((dataset) => {
        setSelectedDataset(dataset);
        setDeleteDialogOpen(true);
    }, []);

    const handleCloseRename = useCallback(() => setRenameDialogOpen(false), []);
    const handleCloseDelete = useCallback(() => setDeleteDialogOpen(false), []);
    const handleOpenCreate = useCallback(() => setCreateDialogOpen(true), []);
    const handleCloseCreate = useCallback(() => setCreateDialogOpen(false), []);
    const handleSearchChange = useCallback(
        (e) => debouncedSearch(e.target.value),
        [debouncedSearch],
    );
    const handleNewNameChange = useCallback((e) => setNewName(e.target.value), []);
    const handleNewDatasetNameChange = useCallback((e) => setNewDatasetName(e.target.value), []);

    const renameDatasetMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/renamekb',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: renameDatasetApi } = renameDatasetMutation;

    const confirmRename = useCallback(async () => {
        if (!newName.trim()) {
            toast.warning('Please enter a dataset name');
            return;
        }
        if (newName === selectedDataset?.name) {
            toast.info('Name is the same as current');
            return;
        }
        try {
            const toastId = toast.loading('Renaming dataset...');
            const data = await renameDatasetApi({
                body: { kb_id: selectedDataset.id, tenant_id: getRagTenantId(), new_name: newName },
            });
            if (data.code === 0) {
                setRenameDialogOpen(false);
                setNewName('');
                setSelectedDataset(null);
                toast.dismiss(toastId);
                toast.success(`Dataset renamed to "${newName}"`);
                setSearchTrigger((prev) => prev + 1);
            } else {
                toast.dismiss(toastId);
                toast.error(data.message || 'Only owner can rename');
            }
        } catch (err) {
            toast.error(`Failed to rename: ${err.message}`);
        }
    }, [newName, selectedDataset, renameDatasetApi]);

    const deleteDatasetMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/deletedataset',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: deleteDatasetApi } = deleteDatasetMutation;

    const confirmDelete = useCallback(async () => {
        if (!selectedDataset?.id) {
            toast.error('No dataset selected');
            return;
        }
        try {
            const toastId = toast.loading('Deleting dataset...');
            const data = await deleteDatasetApi({
                body: { kb_id: selectedDataset.id, tenant_id: getRagTenantId() },
            });
            if (data.code === 1) {
                toast.dismiss(toastId);
                toast.error(data.message || 'Failed to delete dataset');
                return;
            }
            if (data.code === 0) {
                setDeleteDialogOpen(false);
                setSelectedDataset(null);
                toast.dismiss(toastId);
                toast.success('Dataset deleted successfully');
                setPagination((prev) => ({ ...prev, current: 1 }));
                setSearchTrigger((prev) => prev + 1);
            } else {
                toast.dismiss(toastId);
                toast.error(data.message || 'Failed to delete dataset');
            }
        } catch (err) {
            toast.error(`Failed to delete: ${err.message}`);
        }
    }, [selectedDataset, deleteDatasetApi]);

    const createDatasetMutation = useMutationApi({
        service: 'dl',
        endpoint: '/api/createdataset',
        method: 'POST',
        useGateway: true,
        headers,
    });
    const { mutateAsync: createDatasetApi } = createDatasetMutation;

    const confirmCreateDataset = useCallback(async () => {
        if (!newDatasetName.trim()) {
            toast.warning('Please enter a dataset name');
            return;
        }
        try {
            const toastId = toast.loading('Creating dataset...');
            const data = await createDatasetApi({
                body: { name: newDatasetName, tenant_id: getRagTenantId() },
            });
            if (data.code === 0) {
                setCreateDialogOpen(false);
                setNewDatasetName('');
                toast.dismiss(toastId);
                toast.success(`Dataset "${newDatasetName}" created successfully!`);
                setPagination((prev) => ({ ...prev, current: 1 }));
                setSearchQuery('');
                setAppliedSearchQuery('');
                setSearchTrigger((prev) => prev + 1);
            } else {
                toast.dismiss(toastId);
                toast.error(data.message || 'Failed to create dataset');
            }
        } catch (err) {
            toast.error(`Failed to create dataset: ${err.message}`);
        }
    }, [newDatasetName, createDatasetApi]);

    const primaryButtonStyle = useMemo(
        () => ({ backgroundColor: 'var(--primary-color)', border: 'none' }),
        [],
    );
    const successButtonStyle = useMemo(
        () => ({ backgroundColor: 'var(--green-600)', border: 'none' }),
        [],
    );
    const mutedPrimaryIconStyle = useMemo(
        () => ({ color: 'var(--primary-color)', opacity: 0.6, marginLeft: '0.5rem' }),
        [],
    );
    const headingPrimaryStyle = useMemo(() => ({ color: 'var(--primary-color)' }), []);
    const dialogWidth26Style = useMemo(() => ({ width: '26rem' }), []);
    const dialogWidth28Style = useMemo(() => ({ width: '28rem' }), []);

    const renameFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseRename} />
            <Button label="Rename" style={primaryButtonStyle} onClick={confirmRename} />
        </div>
    );
    const deleteFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseDelete} />
            <Button label="Yes, Delete" severity="danger" onClick={confirmDelete} />
        </div>
    );
    const createFooter = (
        <div className="flex gap-2 justify-end">
            <Button label="Cancel" outlined onClick={handleCloseCreate} />
            <Button label="Create" style={successButtonStyle} onClick={confirmCreateDataset} />
        </div>
    );

    return (
        <>
            <PageLayout className="w-full">
                <PageLayout.Header
                    title="Admin Repository"
                    subtitle="Manage knowledge base datasets"
                />
                <PageLayout.Content>
                    <Card>
                        <div>
                            <div className="relative flex items-center justify-between mb-2">
                                <h2 className="text-3xl font-bold" style={headingPrimaryStyle}>
                                    Datasets
                                </h2>
                                <div className="flex align-items-center gap-2 ml-auto">
                                    <span className="p-input-icon-left p-input-icon-right">
                                        <i className="pi pi-search" style={mutedPrimaryIconStyle} />
                                        <InputText
                                            type="text"
                                            placeholder="Search datasets..."
                                            value={searchQuery}
                                            onChange={handleSearchChange}
                                            onKeyPress={handleKeyPress}
                                            className="h-3rem w-22rem pl-10 pr-3"
                                        />
                                        {searchQuery && (
                                            <button
                                                onClick={handleClearSearch}
                                                className="p-link"
                                                style={mutedPrimaryIconStyle}
                                                title="Clear search"
                                            >
                                                <i className="pi pi-times text-sm" />
                                            </button>
                                        )}
                                    </span>
                                    <Button
                                        label={isSearching ? 'Searching...' : 'Search'}
                                        icon={
                                            isSearching ? 'pi pi-spin pi-spinner' : 'pi pi-search'
                                        }
                                        onClick={handleSearch}
                                        disabled={isSearching}
                                        style={primaryButtonStyle}
                                        className="h-3rem"
                                    />
                                    <Button
                                        label="Create Dataset"
                                        icon="pi pi-file"
                                        onClick={handleOpenCreate}
                                        style={successButtonStyle}
                                        className="h-3rem"
                                    />
                                </div>
                            </div>

                            {error && (
                                <div className="mb-4 p-4 bg-red-50 border-l-4 border-red-500 rounded text-red-700">
                                    {error}
                                </div>
                            )}

                            <WidgetDatasetTable
                                datasets={datasets}
                                loading={loading}
                                onRename={handleRename}
                                onDelete={handleDelete}
                                pagination={pagination}
                                onPageChange={handlePageChange}
                                onRowClick={onSelectDataset}
                            />
                        </div>
                    </Card>
                </PageLayout.Content>

                {/* RENAME DIALOG */}
                <Dialog
                    visible={renameDialogOpen}
                    onHide={handleCloseRename}
                    header="Rename Dataset"
                    footer={renameFooter}
                    style={dialogWidth26Style}
                >
                    <div className="space-y-3">
                        <label
                            htmlFor="dai-rename-dataset-name"
                            className="text-sm font-semibold block"
                            style={headingPrimaryStyle}
                        >
                            New Name
                        </label>
                        <InputText
                            id="dai-rename-dataset-name"
                            value={newName}
                            onChange={handleNewNameChange}
                            placeholder="Enter new dataset name"
                            className="w-full"
                        />
                    </div>
                </Dialog>

                {/* DELETE DIALOG */}
                <Dialog
                    visible={deleteDialogOpen}
                    onHide={handleCloseDelete}
                    header="Delete Dataset"
                    footer={deleteFooter}
                    style={dialogWidth28Style}
                >
                    <p>
                        Are you sure you want to delete{' '}
                        <span className="font-semibold">{selectedDataset?.name}</span>? This action
                        cannot be undone.
                    </p>
                </Dialog>

                {/* CREATE DATASET DIALOG */}
                <Dialog
                    visible={createDialogOpen}
                    onHide={handleCloseCreate}
                    header="Create New Dataset"
                    footer={createFooter}
                    style={dialogWidth26Style}
                >
                    <div className="space-y-3">
                        <label
                            htmlFor="dai-create-dataset-name"
                            className="text-sm font-semibold block"
                            style={headingPrimaryStyle}
                        >
                            Dataset Name
                        </label>
                        <InputText
                            id="dai-create-dataset-name"
                            value={newDatasetName}
                            onChange={handleNewDatasetNameChange}
                            placeholder="Enter dataset name"
                            className="w-full"
                        />
                    </div>
                </Dialog>
            </PageLayout>
        </>
    );
}

KnowledgeBaseDashboard.propTypes = {
    onSelectDataset: PropTypes.func,
};
