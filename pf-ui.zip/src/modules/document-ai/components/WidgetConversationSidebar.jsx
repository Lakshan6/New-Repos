import PropTypes from 'prop-types';
import { useAtomValue, useSetAtom, useAtom } from 'jotai';
import { useCallback, useMemo } from 'react';
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Tag } from 'primereact/tag';
import {
    daiDialogListAtom,
    daiSelectedDialogAtom,
    daiConversationListAtom,
    daiActiveConversationAtom,
    daiMessagesAtom,
    INITIAL_DAI_MESSAGE,
} from '../store/atoms';
import {
    useWidgetConversations,
    useWidgetCreateConversation,
    useWidgetSelectConversation,
    useWidgetDeleteConversation,
} from '../hooks/useWidgetConversations';
import useWidgetDialogs from '../hooks/useWidgetDialogs';

const assistantLabelStyle = {
    letterSpacing: '0.06em',
};

const tagStyle = {
    fontSize: '10px',
    padding: '1px 5px',
};

const spinnerStyle = {
    width: '32px',
    height: '32px',
};

const emptyStateIconStyle = {
    fontSize: '2rem',
    color: 'var(--text-color-secondary)',
};

const scrollContainerStyle = {
    minHeight: 0,
};

const formatDate = (ts) => {
    if (!ts) return '';
    return new Date(ts).toLocaleDateString('en-IN', {
        day: 'numeric',
        month: 'short',
    });
};

// ── ConversationItem ──────────────────────────────────────────────────────────
const ConversationItem = ({ conv, isActive, onSelect, onDelete }) => {
    const userMsgs = useMemo(
        () => (conv.messages ?? []).filter((m) => m.role === 'user').length,
        [conv.messages],
    );

    const handleClick = useCallback(() => onSelect(conv), [conv, onSelect]);
    const handleKeyDown = useCallback(
        (e) => {
            if (e.key === 'Enter' || e.key === ' ') onSelect(conv);
        },
        [conv, onSelect],
    );
    const handleDelete = useCallback(
        (e) => {
            e.stopPropagation();
            onDelete(conv.id);
        },
        [conv.id, onDelete],
    );

    return (
        <div
            role="button"
            tabIndex={0}
            className={`ai-conv-item p-2 mb-1 flex align-items-start gap-1${isActive ? ' ai-conv-item--active' : ''}`}
            onClick={handleClick}
            onKeyDown={handleKeyDown}
            aria-current={isActive ? 'true' : undefined}
            aria-label={`Open conversation: ${conv.name}`}
        >
            <div className="flex flex-column flex-1 min-w-0">
                <span
                    className="text-sm font-medium text-900 white-space-nowrap overflow-hidden text-overflow-ellipsis"
                    title={conv.name}
                >
                    {conv.name || 'Untitled'}
                </span>
                <div className="flex align-items-center justify-content-between mt-1">
                    <span className="text-xs text-color-secondary">
                        {formatDate(conv.update_time)}
                    </span>
                    {userMsgs > 0 && (
                        <Tag value={`${userMsgs} msg`} severity="secondary" style={tagStyle} />
                    )}
                </div>
            </div>
            <Button
                icon="pi pi-trash"
                text
                severity="danger"
                size="small"
                tabIndex={-1}
                onClick={handleDelete}
                aria-label={`Delete conversation ${conv.name}`}
            />
        </div>
    );
};

ConversationItem.propTypes = {
    conv: PropTypes.shape({
        id: PropTypes.string.isRequired,
        name: PropTypes.string,
        update_time: PropTypes.number,
        messages: PropTypes.array,
    }).isRequired,
    isActive: PropTypes.bool.isRequired,
    onSelect: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
};

// ── WidgetConversationSidebar ─────────────────────────────────────────────────
const WidgetConversationSidebar = ({ onNewChat }) => {
    // Load dialogs on mount
    useWidgetDialogs();

    const dialogList = useAtomValue(daiDialogListAtom);
    const [selectedDialog, setSelectedDialog] = useAtom(daiSelectedDialogAtom);
    const conversationList = useAtomValue(daiConversationListAtom);
    const activeConversation = useAtomValue(daiActiveConversationAtom);
    const setActiveConversation = useSetAtom(daiActiveConversationAtom);
    const setMessages = useSetAtom(daiMessagesAtom);

    const { isLoading: convLoading } = useWidgetConversations();
    const { mutate: deleteConversation } = useWidgetDeleteConversation();
    const selectConversation = useWidgetSelectConversation();

    const dialogOptions = useMemo(
        () => dialogList.map((d) => ({ label: d.name, value: d.id })),
        [dialogList],
    );

    const handleDialogChange = useCallback(
        (e) => {
            const found = dialogList.find((d) => d.id === e.value);
            if (found) {
                setSelectedDialog(found);
                setMessages([INITIAL_DAI_MESSAGE]);
                setActiveConversation(null);
            }
        },
        [dialogList, setSelectedDialog, setMessages, setActiveConversation],
    );

    const handleNewChat = useCallback(() => {
        setActiveConversation(null);
        setMessages([INITIAL_DAI_MESSAGE]);
        if (onNewChat) {
            onNewChat();
        }
    }, [setActiveConversation, setMessages, onNewChat]);

    const handleDelete = useCallback((convId) => deleteConversation(convId), [deleteConversation]);

    return (
        <div className="dai-assistant-sidebar flex flex-column">
            {/* Assistant / dialog selector */}
            <div className="p-3 border-bottom-1 surface-border flex-shrink-0">
                <p
                    className="text-xs font-semibold text-color-secondary mb-2 uppercase"
                    style={assistantLabelStyle}
                >
                    Assistant
                </p>
                <Dropdown
                    value={selectedDialog?.id}
                    options={dialogOptions}
                    onChange={handleDialogChange}
                    placeholder="Select assistant"
                    className="w-full"
                    aria-label="Select assistant dialog"
                />
            </div>

            {/* New Chat */}
            <div className="p-3 border-bottom-1 surface-border flex-shrink-0">
                <Button
                    label="New Chat"
                    icon="pi pi-plus"
                    className="w-full"
                    disabled={!selectedDialog}
                    onClick={handleNewChat}
                    aria-label="Start a new chat conversation"
                />
            </div>

            {/* Conversation list */}
            <div
                className="flex-1 overflow-y-auto p-2"
                style={scrollContainerStyle}
                aria-label="Conversation list"
            >
                {convLoading ? (
                    <div className="flex justify-content-center mt-4">
                        <ProgressSpinner
                            style={spinnerStyle}
                            strokeWidth="4"
                            aria-label="Loading conversations"
                        />
                    </div>
                ) : conversationList.length === 0 ? (
                    <div className="flex flex-column align-items-center mt-4 gap-2">
                        <i
                            className="pi pi-comments"
                            style={emptyStateIconStyle}
                            aria-hidden="true"
                        />
                        <p className="text-sm text-color-secondary text-center">
                            No conversations yet.
                        </p>
                    </div>
                ) : (
                    conversationList.map((conv) => (
                        <ConversationItem
                            key={conv.id}
                            conv={conv}
                            isActive={activeConversation?.id === conv.id}
                            onSelect={selectConversation}
                            onDelete={handleDelete}
                        />
                    ))
                )}
            </div>
        </div>
    );
};

WidgetConversationSidebar.propTypes = {
    onNewChat: PropTypes.func,
};

WidgetConversationSidebar.defaultProps = {
    onNewChat: undefined,
};

export default WidgetConversationSidebar;
