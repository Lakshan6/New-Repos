import { lazy, Suspense, useCallback, useMemo, useEffect, useRef } from 'react';
import { useLocation } from 'react-router';
import { useAtom, useAtomValue, useSetAtom } from 'jotai';
import { Button } from 'primereact/button';
import { Sidebar } from 'primereact/sidebar';
import {
    daiWidgetOpenAtom,
    daiSelectedDialogAtom,
    daiActiveConversationAtom,
    daiMessagesAtom,
    daiIsStreamingAtom,
    INITIAL_DAI_MESSAGE,
} from '../store/atoms';
import { useWidgetDeleteConversation } from '../hooks/useWidgetConversations';
import { isAuthenticated } from '../utils/roleCheck';
import useWidgetDialogs from '../hooks/useWidgetDialogs';
import { ragAxios, RAG_APIS, getRagAuth } from '../hooks/ragApi';
import '../styles/document-ai-widget.scss';

const AiChatPanel = lazy(() => import('./AiChatPanel'));

// ── AiAssistantPanel ─────────────────────────────────────────────────────────
const AiAssistantPanel = () => {
    // Initialize dialogs so we get the default single dialog
    useWidgetDialogs();
    return (
        <div className="dai-assistant-root h-full flex flex-column">
            <Suspense fallback={null}>
                <AiChatPanel />
            </Suspense>
        </div>
    );
};

// ── DocumentAiWidget ──────────────────────────────────────────────────────────
const DocumentAiWidget = () => {
    const [widgetOpen, setWidgetOpen] = useAtom(daiWidgetOpenAtom);
    const selectedDialog = useAtomValue(daiSelectedDialogAtom);
    const activeConversation = useAtomValue(daiActiveConversationAtom);
    const isStreaming = useAtomValue(daiIsStreamingAtom);
    const setActiveConversation = useSetAtom(daiActiveConversationAtom);
    const setMessages = useSetAtom(daiMessagesAtom);

    const { mutateAsync: deleteConversation, isPending: deleting } = useWidgetDeleteConversation();

    const loggedIn = useMemo(() => isAuthenticated(), []);

    const handleOpen = useCallback(() => setWidgetOpen(true), [setWidgetOpen]);
    const handleHide = useCallback(() => setWidgetOpen(false), [setWidgetOpen]);

    const location = useLocation();

    const isChatbotRoute = location.pathname.includes('/document-library/ai-assistant');
    const initRef = useRef(false);
    const cleanupActiveIdRef = useRef(null);

    const handleClearChat = useCallback(async () => {
        const activeId = activeConversation?.id || cleanupActiveIdRef.current;
        if (activeId) {
            try {
                await deleteConversation(activeId);
            } catch (error) {
                console.error('Failed to clear chat:', error);
            }
        } else {
            setMessages([INITIAL_DAI_MESSAGE]);
        }
    }, [activeConversation, deleteConversation, setMessages]);

    // Lifecycle: Create a single conversation per session for the selected dialog
    useEffect(() => {
        if (!loggedIn || !selectedDialog?.id || initRef.current) return;
        initRef.current = true;

        const initSessionConversation = async () => {
            try {
                // 1. Fetch existing conversations
                const { data: fetchRes } = await ragAxios.get(
                    `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                );
                const existing = fetchRes?.data ?? [];

                // 2. Check if a conversation already exists
                if (existing.length > 0) {
                    const conv = existing[0];
                    setActiveConversation(conv);
                    cleanupActiveIdRef.current = conv.id;

                    const rawMessages = conv.messages ?? [];
                    const references = conv.reference ?? [];

                    let refIndex = 0;
                    const mergedMessages = rawMessages.map((msg, idx) => {
                        if (msg.role === 'assistant' && idx > 0) {
                            const ref = references[refIndex] ?? { chunks: [], doc_aggs: [] };
                            refIndex++;
                            return { ...msg, reference: ref };
                        }
                        return msg;
                    });

                    setMessages(mergedMessages.length ? mergedMessages : [INITIAL_DAI_MESSAGE]);
                } else {
                    // 3. Create one new conversation
                    const { data: createRes } = await ragAxios.post(
                        `${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                        { name: 'Session Chat' },
                    );

                    if (createRes?.code === 0 && createRes.data) {
                        setActiveConversation(createRes.data);
                        cleanupActiveIdRef.current = createRes.data.id;
                        setMessages([INITIAL_DAI_MESSAGE]);
                    }
                }
            } catch (error) {
                console.error('Failed to initialize session conversation:', error);
            }
        };

        initSessionConversation();
    }, [loggedIn, selectedDialog, setActiveConversation, setMessages]);

    // Handle logout deletion via global event
    useEffect(() => {
        const handleLogout = () => {
            const activeId = cleanupActiveIdRef.current;
            if (activeId && selectedDialog?.id) {
                const { authorization } = getRagAuth();
                fetch(
                    `${import.meta.env.VITE_RAG_BASE_URL}${RAG_APIS.SESSIONS_BASE}/${selectedDialog.id}/sessions`,
                    {
                        method: 'DELETE',
                        keepalive: true,
                        headers: {
                            'Content-Type': 'application/json',
                            Authorization: authorization || '',
                        },
                        body: JSON.stringify({ ids: [activeId] }),
                    },
                ).catch(() => {});
            }
        };

        window.addEventListener('erp-logout', handleLogout);
        return () => window.removeEventListener('erp-logout', handleLogout);
    }, [selectedDialog]);

    if (!loggedIn || isChatbotRoute) return null;

    const sidebarHeader = selectedDialog?.name ? `${selectedDialog.name} Chatbot` : 'Chatbot';

    return (
        <>
            {/* Floating Action Button — visible only when widget is closed */}
            {!widgetOpen && (
                <div className="dai-fab">
                    <Button
                        icon="pi pi-sparkles"
                        rounded
                        onClick={handleOpen}
                        aria-label="Open Document AI"
                        title="Document AI"
                    />
                </div>
            )}

            <Sidebar
                visible={widgetOpen}
                position="right"
                onHide={handleHide}
                className="dai-sidebar p-0"
                modal={false}
                style={{
                    width: '550px',
                    height: 'calc(100vh - 180px)',
                    top: '100px',
                    bottom: '80px',
                    right: '20px',
                    borderRadius: '16px',
                }}
                baseZIndex={9000}
                header={
                    <div className="flex align-items-center w-full">
                        <span className="font-bold text-xl flex-1">{sidebarHeader}</span>
                        <Button
                            label="Clear Chat"
                            icon="pi pi-trash"
                            text
                            severity="danger"
                            size="small"
                            className="mr-3 p-1"
                            onClick={handleClearChat}
                            disabled={isStreaming || deleting}
                            title="Clear current chat session"
                        />
                    </div>
                }
                pt={{
                    content: {
                        className: 'p-0 flex flex-column h-full overflow-hidden',
                        style: { borderBottomLeftRadius: '16px', borderBottomRightRadius: '16px' },
                    },
                    header: {
                        className: 'border-bottom-1 surface-border py-3 px-4',
                        style: { borderTopLeftRadius: '16px', borderTopRightRadius: '16px' },
                    },
                }}
            >
                <AiAssistantPanel />
            </Sidebar>
        </>
    );
};

export default DocumentAiWidget;
