import { useRef, useState, useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Button } from 'primereact/button';
import { Menu } from 'primereact/menu';
import { ProgressSpinner } from 'primereact/progressspinner';
import { Paginator } from 'primereact/paginator';
import { Tag } from 'primereact/tag';

const PRIMARY = 'var(--primary-color)';
const PRIMARY_BG_LIGHT = 'var(--surface-hover)';

const datasetNameStyle = { color: 'var(--text-color)' };
const createdByStyle = { color: 'var(--text-color-secondary)' };
const docNumStyle = { color: PRIMARY };
const dateStyle = { color: 'var(--text-color-secondary)' };
const loadingSpinnerStyle = { width: '48px', height: '48px' };
const emptyContainerStyle = { background: PRIMARY_BG_LIGHT, borderColor: PRIMARY };
const emptyPrimaryTextStyle = { color: PRIMARY };
const emptySecondaryTextStyle = { color: PRIMARY, opacity: 0.7 };
const tableContainerStyle = { borderColor: 'var(--surface-border)' };
const tableStyle = { minWidth: '50rem' };
const tableHeaderRowStyle = { style: { background: PRIMARY_BG_LIGHT } };
const headerStyleLeft = { color: PRIMARY, fontWeight: 700, textAlign: 'left' };
const headerStyleCenter = { color: PRIMARY, fontWeight: 700, textAlign: 'center' };
const paginationContainerStyle = { borderColor: 'var(--surface-border)' };
const pageSummaryStyle = { color: '#6b7280' };
const pageSummaryAccentStyle = { color: PRIMARY };
const pageSummaryDotStyle = { color: PRIMARY };
const paginatorRootPt = { className: 'p-0 bg-transparent border-none' };
const paginatorPageButtonBaseClass = 'h-8 px-2 text-sm font-medium border rounded-md transition';
const paginatorPrevNextBaseClass = 'h-8 px-2 border rounded-md disabled:opacity-50';
const paginatorActiveButtonStyle = {
    backgroundColor: PRIMARY,
    color: '#fff',
    borderColor: PRIMARY,
};
const paginatorInactiveButtonStyle = { borderColor: '#d1d5db', color: PRIMARY };
const paginatorPrevNextStyle = { borderColor: '#d1d5db', color: PRIMARY };
const deleteMenuItemStyle = { color: '#ef4444' };

const rowClassName = () => 'cursor-pointer transition border-b';
const pageButtonPt = ({ context }) => ({
    className: paginatorPageButtonBaseClass,
    style: context.active ? paginatorActiveButtonStyle : paginatorInactiveButtonStyle,
});
const leftHeader = (label) => <span className="block text-left w-full">{label}</span>;
const centeredHeader = (label) => <span className="block text-center w-full">{label}</span>;

const formatDate = (dateStr) => {
    if (!dateStr) return '-';
    const [datePart, timePart] = dateStr.split('T');
    const [yyyy, mm, dd] = datePart.split('-');
    return `${dd}-${mm}-${yyyy} ${timePart}`;
};

const nameBodyTemplate = (dataset) => (
    <div className="flex align-items-center">
        <span className="font-medium" style={datasetNameStyle}>
            {dataset.name}
        </span>
    </div>
);

const createdByBodyTemplate = (dataset) => (
    <span className="text-left block" style={createdByStyle}>
        {dataset.nickname}
    </span>
);

const docNumBodyTemplate = (dataset) => (
    <span className="font-semibold text-center block" style={docNumStyle}>
        {dataset.doc_num}
    </span>
);

const createDateBodyTemplate = (dataset) => (
    <span className="text-center block" style={dateStyle}>
        {formatDate(dataset.create_date)}
    </span>
);

const permissionBodyTemplate = (dataset) => (
    <div className="flex justify-content-center">
        <Tag value={dataset.permission} />
    </div>
);

function ActionsCell({ dataset, menuRef, onRename, onDelete }) {
    const menuId = dataset.id;

    const handleRename = useCallback(
        (e) => {
            e.originalEvent.stopPropagation();
            onRename(dataset);
        },
        [dataset, onRename],
    );

    const handleDelete = useCallback(
        (e) => {
            e.originalEvent.stopPropagation();
            onDelete(dataset);
        },
        [dataset, onDelete],
    );

    const menuItems = useMemo(
        () => [
            { label: 'Rename', icon: 'pi pi-pencil', command: handleRename },
            {
                label: 'Delete',
                icon: 'pi pi-trash',
                style: deleteMenuItemStyle,
                command: handleDelete,
            },
        ],
        [handleDelete, handleRename],
    );

    const setMenuRef = useCallback(
        (el) => {
            menuRef.current[menuId] = el;
        },
        [menuId, menuRef],
    );

    const handleMenuToggle = useCallback(
        (e) => {
            e.stopPropagation();
            menuRef.current[menuId]?.toggle(e);
        },
        [menuId, menuRef],
    );

    return (
        <div className="flex justify-content-center">
            <Menu model={menuItems} popup ref={setMenuRef} id={`menu_${menuId}`} />
            <Button
                icon="pi pi-ellipsis-v"
                rounded
                text
                severity="secondary"
                onClick={handleMenuToggle}
                aria-controls={`menu_${menuId}`}
                aria-haspopup
            />
        </div>
    );
}

ActionsCell.propTypes = {
    dataset: PropTypes.object.isRequired,
    menuRef: PropTypes.shape({ current: PropTypes.object }).isRequired,
    onRename: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
};

export default function WidgetDatasetTable({
    datasets,
    loading,
    onRename,
    onDelete,
    pagination,
    onPageChange,
    onRowClick,
}) {
    const [sortField, setSortField] = useState('create_date');
    const [sortOrder, setSortOrder] = useState(-1);
    const menuRefs = useRef({});

    const handleSort = useCallback((e) => {
        setSortField(e.sortField);
        setSortOrder(e.sortOrder);
    }, []);

    const sortedDatasets = useMemo(() => {
        return [...(datasets || [])].sort((a, b) => {
            if (!sortField) return new Date(b.create_date) - new Date(a.create_date);
            let valA = a[sortField] ?? '';
            let valB = b[sortField] ?? '';
            if (sortField === 'create_date') {
                valA = valA ? new Date(valA) : new Date(0);
                valB = valB ? new Date(valB) : new Date(0);
                return sortOrder === 1 ? valA - valB : valB - valA;
            }
            if (sortField === 'doc_num') return sortOrder === 1 ? valA - valB : valB - valA;
            valA = valA.toString().toLowerCase();
            valB = valB.toString().toLowerCase();
            if (valA < valB) return sortOrder === 1 ? -1 : 1;
            if (valA > valB) return sortOrder === 1 ? 1 : -1;
            return 0;
        });
    }, [datasets, sortField, sortOrder]);

    const totalPages = Math.ceil(pagination.total / pagination.pageSize);
    const startIndex = (pagination.current - 1) * pagination.pageSize + 1;
    const endIndex = Math.min(pagination.current * pagination.pageSize, pagination.total);

    const handleRowClickInternal = useCallback(
        (e) => {
            if (onRowClick) onRowClick(e.data.id);
        },
        [onRowClick],
    );

    const handlePageChangeWrapper = useCallback((e) => onPageChange(e.page + 1), [onPageChange]);

    const actionsBodyTemplate = useCallback(
        (dataset) => (
            <ActionsCell
                dataset={dataset}
                menuRef={menuRefs}
                onRename={onRename}
                onDelete={onDelete}
            />
        ),
        [onDelete, onRename],
    );

    const dataTablePt = useMemo(() => ({ headerRow: tableHeaderRowStyle }), []);
    const paginatorPt = useMemo(
        () => ({
            root: paginatorRootPt,
            pageButton: pageButtonPt,
            prevPageButton: {
                className: paginatorPrevNextBaseClass,
                style: paginatorPrevNextStyle,
            },
            nextPageButton: {
                className: paginatorPrevNextBaseClass,
                style: paginatorPrevNextStyle,
            },
        }),
        [],
    );

    if (loading) {
        return (
            <div className="flex items-center justify-center py-12">
                <ProgressSpinner style={loadingSpinnerStyle} />
            </div>
        );
    }

    if (!datasets || datasets.length === 0) {
        return (
            <div
                className="flex items-center justify-center gap-3 py-12 rounded-lg border"
                style={emptyContainerStyle}
            >
                <p className="text-lg font-semibold" style={emptyPrimaryTextStyle}>
                    No datasets found
                </p>

                <p className="text-sm" style={emptySecondaryTextStyle}>
                    Create your first dataset to get started
                </p>
            </div>
        );
    }

    return (
        <div className="space-y-4">
            <div
                className="bg-white rounded-lg shadow-md overflow-hidden border"
                style={tableContainerStyle}
            >
                <DataTable
                    value={sortedDatasets}
                    sortField={sortField}
                    sortOrder={sortOrder}
                    onSort={handleSort}
                    removableSort
                    onRowClick={handleRowClickInternal}
                    rowClassName={rowClassName}
                    tableStyle={tableStyle}
                    pt={dataTablePt}
                >
                    <Column
                        field="name"
                        header={leftHeader('Name')}
                        sortable
                        body={nameBodyTemplate}
                        headerStyle={headerStyleLeft}
                        bodyClassName="text-left py-3"
                    />
                    <Column
                        field="nickname"
                        header={leftHeader('Created by')}
                        body={createdByBodyTemplate}
                        headerStyle={headerStyleLeft}
                        bodyClassName="text-left py-3"
                    />
                    <Column
                        field="doc_num"
                        header={centeredHeader('Files')}
                        sortable
                        body={docNumBodyTemplate}
                        headerStyle={headerStyleCenter}
                        bodyClassName="text-center py-3"
                    />
                    <Column
                        field="create_date"
                        header={centeredHeader('Created on')}
                        sortable
                        body={createDateBodyTemplate}
                        headerStyle={headerStyleCenter}
                        bodyClassName="text-center py-3"
                    />
                    <Column
                        field="permission"
                        header={centeredHeader('Permission')}
                        body={permissionBodyTemplate}
                        headerStyle={headerStyleCenter}
                        bodyClassName="text-center py-3"
                    />
                    <Column
                        header={centeredHeader('Actions')}
                        body={actionsBodyTemplate}
                        headerStyle={headerStyleCenter}
                        bodyClassName="text-center py-3"
                    />
                </DataTable>
            </div>

            {totalPages > 1 && (
                <div
                    className="flex items-center justify-between px-4 py-3 bg-white rounded-lg border"
                    style={paginationContainerStyle}
                >
                    <div className="text-xs font-medium" style={pageSummaryStyle}>
                        Showing{' '}
                        <span className="font-semibold text-sm" style={pageSummaryAccentStyle}>
                            {startIndex}
                        </span>
                        -
                        <span className="font-semibold text-sm" style={pageSummaryAccentStyle}>
                            {endIndex}
                        </span>
                        {' of '}
                        <span className="font-semibold text-sm" style={pageSummaryAccentStyle}>
                            {pagination.total}
                        </span>
                        {' datasets'}
                        <span className="ml-2" style={pageSummaryDotStyle}>
                            • Page {pagination.current}/{totalPages}
                        </span>
                    </div>
                    <Paginator
                        first={(pagination.current - 1) * pagination.pageSize}
                        rows={pagination.pageSize}
                        totalRecords={pagination.total}
                        onPageChange={handlePageChangeWrapper}
                        template="PrevPageLink PageLinks NextPageLink"
                        pt={paginatorPt}
                    />
                </div>
            )}
        </div>
    );
}

WidgetDatasetTable.propTypes = {
    datasets: PropTypes.arrayOf(PropTypes.object).isRequired,
    loading: PropTypes.bool.isRequired,
    onRename: PropTypes.func.isRequired,
    onDelete: PropTypes.func.isRequired,
    pagination: PropTypes.shape({
        current: PropTypes.number.isRequired,
        pageSize: PropTypes.number.isRequired,
        total: PropTypes.number.isRequired,
    }).isRequired,
    onPageChange: PropTypes.func.isRequired,
    onRowClick: PropTypes.func,
};
