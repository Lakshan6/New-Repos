import { useState, lazy, Suspense } from 'react';

const KnowledgeBaseDashboard = lazy(() => import('../screens/KnowledgeBaseDashboard'));
const DatasetFilesPage = lazy(() => import('../screens/DatasetFilesPage'));

export default function DocRepoTab() {
    const [selectedDatasetId, setSelectedDatasetId] = useState(null);

    return (
        <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
            <Suspense fallback={null}>
                {selectedDatasetId ? (
                    <DatasetFilesPage
                        datasetId={selectedDatasetId}
                        onBack={() => setSelectedDatasetId(null)}
                    />
                ) : (
                    <KnowledgeBaseDashboard onSelectDataset={(id) => setSelectedDatasetId(id)} />
                )}
            </Suspense>
        </div>
    );
}
