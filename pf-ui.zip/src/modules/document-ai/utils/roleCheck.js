export const isAuthenticated = () => {
    return !!(
        localStorage.getItem('authToken') ||
        localStorage.getItem('Authorization') ||
        localStorage.getItem('Token')
    );
};
