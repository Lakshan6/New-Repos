import { Routes, Route } from 'react-router-dom';
import MaterialScreen from '../screens/MaterialScreen.jsx';
import MaintPlanCategory from '../screens/MaintPlanCategory.jsx';
import MaintStrategy from '../screens/MaintStrategy.jsx';
import TechObjAuth from '../screens/TechObjAuth.jsx';
import EquipmentScreen from '../screens/EquipmentScreen.jsx';
import EquipInitialScreen from '../screens/EquipInitialScreen.jsx';

const MiRoutes = () => {
  return (
    <Routes>
      {/* This will resolve to /web/landing/qm/material */}
      <Route path="maint-plan-category" element={<MaintPlanCategory />} />
      <Route path="maint-strategy" element={<MaintStrategy />} />
      <Route path="tech-obj-auth" element={<TechObjAuth />} />
      <Route path="create-equip" element={<EquipmentScreen />} />
       <Route path="create-equip-initial" element={<EquipInitialScreen />} />
      {/* Optional: Default index for the module */}
      <Route index element={<div>MI Home</div>} />
    </Routes>
    
  );
};

export default MiRoutes;