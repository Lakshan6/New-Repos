import { Route, Routes } from 'react-router';
import { TranslationProvider } from '@shared/components';
import { translationsAtom } from '../store/atoms';
import { NotFoundPage } from '@shared/screens';
import { LOCALISATION_MODULES } from '@shared/utils';
import ChatbotScreen from '../screens/ChatbotScreen';

const Router = () => {
    return (
        <TranslationProvider module={LOCALISATION_MODULES.AI} translationsAtom={translationsAtom}>
            <Routes>
                <Route index element={<ChatbotScreen />} />
                <Route path="/chatbot" element={<ChatbotScreen />} />
                <Route path="*" element={<NotFoundPage />} />
            </Routes>
        </TranslationProvider>
    );
};

export default Router;
