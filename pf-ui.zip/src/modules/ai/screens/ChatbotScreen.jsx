import React, { useState, useRef, useEffect, useCallback } from 'react';
import { useAtom } from 'jotai';
import { Button } from 'primereact/button';
import { useMutationApi } from '@shared/hooks';
import { getReqInfoObj } from '@shared/utils';
import ChatMessageList from '../components/ChatMessageList';
import ChatInputArea from '../components/ChatInputArea';
import ChatEmptyState from '../components/ChatEmptyState';
import { messagesAtom } from '../store/atoms';
import '../styles/ChatbotScreen.scss';

const ChatbotScreen = () => {
    const [inputValue, setInputValue] = useState('');
    const [messages, setMessages] = useAtom(messagesAtom);

    const messagesEndRef = useRef(null);

    const scrollToBottom = useCallback(() => {
        messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }, []);

    useEffect(() => {
        scrollToBottom();
    }, [messages, scrollToBottom]);

    const handleSetInputValue = useCallback((value) => {
        setInputValue(value);
    }, []);

    const handleCopyMessage = useCallback((content) => {
        navigator.clipboard.writeText(content);
    }, []);

    const handleClear = useCallback(() => {
        setMessages([]);
    }, [setMessages]);

    const llmMutation = useMutationApi({
        service: 'llm',
        endpoint: '/psllm/generateLlmResponse',
    });

    // Fix: added setMessages to dep array
    const handleSendMessage = useCallback(() => {
        if (!inputValue.trim() || llmMutation.isPending) return;

        const requestInfo = getReqInfoObj();

        const userMessage = {
            id: Date.now(),
            type: 'user',
            content: inputValue,
            timestamp: new Date().toISOString(),
        };

        const aiId = Date.now() + 1;

        setMessages((prev) => [
            ...prev,
            userMessage,
            {
                id: aiId,
                type: 'ai',
                content: '',
                rawResponse: null,
                timestamp: new Date().toISOString(),
            },
        ]);

        setInputValue('');

        llmMutation.mutate(
            { ...requestInfo, llmRequestStr: userMessage.content },
            {
                onSuccess: (data) => {
                    setMessages((prev) =>
                        prev.map((msg) => (msg.id === aiId ? { ...msg, rawResponse: data } : msg)),
                    );
                },
                onError: (error) => {
                    setMessages((prev) =>
                        prev.map((msg) =>
                            msg.id === aiId ? { ...msg, content: `Error: ${error.message}` } : msg,
                        ),
                    );
                },
            },
        );
    }, [inputValue, llmMutation, setMessages]);

    return (
        <div className="chatbot-wrapper">
            {messages.length > 0 && (
                <div className="chatbot-toolbar">
                    <Button
                        icon="pi pi-refresh"
                        label="New Chat"
                        text
                        size="small"
                        onClick={handleClear}
                    />
                </div>
            )}
            {messages.length === 0 ? (
                <ChatEmptyState onSuggestionClick={handleSetInputValue} />
            ) : (
                <ChatMessageList
                    messages={messages}
                    messagesEndRef={messagesEndRef}
                    onCopyMessage={handleCopyMessage}
                    loading={llmMutation.isPending}
                />
            )}
            <ChatInputArea
                inputValue={inputValue}
                setInputValue={handleSetInputValue}
                onSendMessage={handleSendMessage}
                loading={llmMutation.isPending}
            />
        </div>
    );
};

export default ChatbotScreen;
