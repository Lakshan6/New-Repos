import React, { useCallback, useMemo } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Card } from 'primereact/card';
import '../styles/ChatEmptyState.scss';

const SUGGESTIONS = [
    {
        text: 'Top 10 Airforce projects with open defect counts',
        icon: 'pi pi-globe',
    },
    {
        text: 'List top 10 projects with highest defects complaint-wise & status-wise',
        icon: 'pi pi-chart-bar',
    },
    {
        text: 'Provide defect status breakdown with counts',
        icon: 'pi pi-info-circle',
    },
];

const ChatEmptyState = ({ onSuggestionClick }) => {
    const handleSuggestionClick = useCallback(
        (text) => {
            onSuggestionClick(text);
        },
        [onSuggestionClick],
    );

    const suggestionHandlers = useMemo(() => {
        const handlers = {};
        SUGGESTIONS.forEach((item) => {
            handlers[item.text] = () => handleSuggestionClick(item.text);
        });
        return handlers;
    }, [handleSuggestionClick]);

    return (
        <div className="chat-empty-state">
            <h2 className="empty-title">What can I help with?</h2>

            <div className="empty-suggestions">
                {SUGGESTIONS.map((item) => (
                    <Card key={item.text} className="suggestion-card">
                        <Button
                            label={item.text}
                            icon={item.icon}
                            iconPos="left"
                            className="suggestion-btn p-button-text p-button-plain"
                            onClick={suggestionHandlers[item.text]}
                        />
                    </Card>
                ))}
            </div>
        </div>
    );
};

ChatEmptyState.propTypes = {
    onSuggestionClick: PropTypes.func.isRequired,
};

export default ChatEmptyState;
