import React, { useMemo } from 'react';
import PropTypes from 'prop-types';
import { Chart } from 'primereact/chart';
import {
    Chart as ChartJS,
    LinearScale,
    CategoryScale,
    PointElement,
    LineElement,
    BarElement,
    BubbleController,
    TimeScale,
    Tooltip,
    Legend,
} from 'chart.js';
import 'chartjs-adapter-date-fns';
import { prepareChartData } from '../utils/chartDataUtils';

ChartJS.register(
    LinearScale,
    CategoryScale,
    PointElement,
    LineElement,
    BarElement,
    BubbleController,
    TimeScale,
    Tooltip,
    Legend,
);

// Fix: module-level style const
const chartStyle = { height: '100%', width: '100%' };

export default function PrimeChart({ type, data = [], chartResolverOutput = {}, columnMeta = {} }) {
    const chartConfig = useMemo(() => {
        if (!type || !chartResolverOutput?.applicable) {
            return { data: { labels: [], datasets: [] }, options: {} };
        }

        let chartType = type;
        const prepared = prepareChartData(type, data, chartResolverOutput, columnMeta);

        if (type === 'histogram') chartType = 'bar';

        const options = {
            responsive: true,
            maintainAspectRatio: false,
            plugins: { legend: { display: true }, tooltip: { enabled: true } },
            scales: {},
        };

        if (chartType === 'line') {
            if (chartResolverOutput.axisMode === 'time') {
                options.scales = {
                    x: {
                        type: 'time',
                        time: { tooltipFormat: 'Pp' },
                        title: { display: true, text: chartResolverOutput?.roles?.x || '' },
                    },
                    y: { title: { display: true, text: chartResolverOutput?.roles?.y || '' } },
                };
            } else {
                options.scales = {
                    x: {
                        type: 'category',
                        title: {
                            display: true,
                            text:
                                chartResolverOutput?.roles?.x === '__index__'
                                    ? 'Index'
                                    : chartResolverOutput?.roles?.x || '',
                        },
                    },
                    y: { title: { display: true, text: chartResolverOutput?.roles?.y || '' } },
                };
            }
        }

        if (chartType === 'bar') {
            const isTime = chartResolverOutput.axisMode === 'time';
            options.scales = {
                x: {
                    type: isTime ? 'time' : 'category',
                    time: isTime ? { tooltipFormat: 'Pp' } : undefined,
                    title: { display: true, text: chartResolverOutput?.roles?.x || '' },
                    ticks: {
                        autoSkip: false,
                        maxRotation: 45,
                        minRotation: 30,
                        callback: function (value, index) {
                            const label = this.getLabelForValue(index);
                            return label?.length > 14 ? label.slice(0, 14) + '…' : label;
                        },
                    },
                },
                y: {
                    beginAtZero: true,
                    title: { display: true, text: chartResolverOutput?.roles?.y || 'Count' },
                },
            };
        }

        if (chartType === 'scatter') {
            const xMeta = columnMeta?.[chartResolverOutput?.roles?.x];
            const yMeta = columnMeta?.[chartResolverOutput?.roles?.y];
            const xIsTime =
                chartResolverOutput?.conversions?.[chartResolverOutput?.roles?.x] === 'datetime' ||
                xMeta?.type === 'datetime';
            const yIsTime =
                chartResolverOutput?.conversions?.[chartResolverOutput?.roles?.y] === 'datetime' ||
                yMeta?.type === 'datetime';

            options.scales = {
                x: {
                    type: xIsTime ? 'time' : 'linear',
                    time: xIsTime ? { tooltipFormat: 'Pp' } : undefined,
                    title: { display: true, text: chartResolverOutput?.roles?.x || '' },
                },
                y: {
                    type: yIsTime ? 'time' : 'linear',
                    time: yIsTime ? { tooltipFormat: 'Pp' } : undefined,
                    title: { display: true, text: chartResolverOutput?.roles?.y || '' },
                },
            };
        }

        return { data: prepared, options, type: chartType };
    }, [type, data, chartResolverOutput, columnMeta]);

    return <Chart {...chartConfig} style={chartStyle} />;
}

PrimeChart.propTypes = {
    type: PropTypes.string,
    data: PropTypes.arrayOf(PropTypes.object),
    chartResolverOutput: PropTypes.object,
    columnMeta: PropTypes.object,
};
