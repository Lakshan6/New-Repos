import React, { useState, useMemo, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { profileData } from '../utils/dataProfiler';
import { resolveChart } from '../utils/chartEngine';
import PrimeChart from './PrimeChart';

const CHART_ICONS = {
    bar: 'pi pi-chart-bar',
    line: 'pi pi-chart-line',
    doughnut: 'pi pi-chart-pie',
    scatter: 'pi pi-circle',
    histogram: 'pi pi-chart-bar',
};

const MAX_COLUMNS = 2;
const ALL_CHARTS = ['bar', 'line', 'doughnut', 'scatter', 'histogram'];

// Styles
const containerStyle = { display: 'flex', height: '100%', minHeight: 540, gap: 0 };

const leftPanelStyle = {
    width: 180,
    flexShrink: 0,
    borderRight: '1px solid #daeaf8',
    padding: '16px 12px',
    background: '#f8fbff',
    borderRadius: '12px 0 0 12px',
};

const columnHeadingStyle = {
    margin: '0 0 10px',
    fontWeight: 600,
    fontSize: 13,
    color: '#0F3E66',
    textTransform: 'uppercase',
    letterSpacing: '0.5px',
};

const columnItemStyle = { marginBottom: 8 };
const checkboxStyle = { accentColor: '#2186DE', width: 14, height: 14 };

const mainAreaStyle = {
    flex: 1,
    padding: '16px 20px',
    display: 'flex',
    flexDirection: 'column',
};

const chartSelectorStyle = { marginBottom: 14, display: 'flex', gap: 6, flexWrap: 'wrap' };
const chartOutputStyle = { flex: 1, height: 460, minHeight: 460 };

const warningBoxStyle = {
    padding: 16,
    background: '#fff3cd',
    border: '1px solid #ffeeba',
    borderRadius: 6,
    color: '#856404',
};

const makeLabelStyle = (isSelected, isDisabled) => ({
    display: 'flex',
    alignItems: 'center',
    gap: 8,
    cursor: isDisabled ? 'not-allowed' : 'pointer',
    opacity: isDisabled ? 0.4 : 1,
    fontSize: 13,
    color: isSelected ? '#1B6EB6' : '#0F3E66',
    fontWeight: isSelected ? 600 : 400,
});

export default function DataFrameCharts({ data = [] }) {
    const [selectedColumns, setSelectedColumns] = useState([]);
    const [activeChart, setActiveChart] = useState(null);
    const [activeChartData, setActiveChartData] = useState(null);

    const columnMeta = useMemo(() => profileData(data), [data]);
    const allColumns = useMemo(() => Object.keys(columnMeta), [columnMeta]);

    useEffect(() => {
        if (
            selectedColumns.length === 0 &&
            allColumns.length > 0 &&
            allColumns.length <= MAX_COLUMNS
        ) {
            setSelectedColumns(allColumns.slice(0, MAX_COLUMNS));
        }
    }, [allColumns, selectedColumns.length]);

    const toggleColumn = useCallback((col) => {
        setSelectedColumns((prev) => {
            if (prev.includes(col)) return prev.filter((c) => c !== col);
            if (prev.length < MAX_COLUMNS) return [...prev, col];
            return prev;
        });
    }, []);

    const handleChartClick = useCallback(
        (chart) => {
            if (!selectedColumns.length) return;
            const result = resolveChart(chart, selectedColumns, columnMeta);
            setActiveChart(chart);
            setActiveChartData(result);
        },
        [selectedColumns, columnMeta],
    );

    // ✅ Pre-create column handlers
    const columnHandlers = useMemo(() => {
        const map = {};
        allColumns.forEach((col) => {
            map[col] = () => toggleColumn(col);
        });
        return map;
    }, [allColumns, toggleColumn]);

    // ✅ Pre-create chart handlers
    const chartHandlers = useMemo(() => {
        const map = {};
        ALL_CHARTS.forEach((chart) => {
            map[chart] = () => handleChartClick(chart);
        });
        return map;
    }, [handleChartClick]);

    useEffect(() => {
        if (!selectedColumns.length) {
            setActiveChart(null);
            setActiveChartData(null);
            return;
        }
        for (const chart of ALL_CHARTS) {
            const result = resolveChart(chart, selectedColumns, columnMeta);
            if (result?.applicable) {
                setActiveChart(chart);
                setActiveChartData(result);
                return;
            }
        }
        const lastResult = resolveChart(
            ALL_CHARTS[ALL_CHARTS.length - 1],
            selectedColumns,
            columnMeta,
        );
        setActiveChart(null);
        setActiveChartData(lastResult);
    }, [selectedColumns, columnMeta]);

    const showColumnWarning = selectedColumns.length === 0 && allColumns.length > MAX_COLUMNS;

    return (
        <div style={containerStyle}>
            {/* LEFT PANEL */}
            <div style={leftPanelStyle}>
                <p style={columnHeadingStyle}>Columns</p>
                {allColumns.map((col) => {
                    const isSelected = selectedColumns.includes(col);
                    const isDisabled = !isSelected && selectedColumns.length >= MAX_COLUMNS;
                    const labelStyle = makeLabelStyle(isSelected, isDisabled);

                    return (
                        <div key={col} style={columnItemStyle}>
                            <label style={labelStyle}>
                                <input
                                    type="checkbox"
                                    checked={isSelected}
                                    onChange={columnHandlers[col]}
                                    disabled={isDisabled}
                                    style={checkboxStyle}
                                />
                                {col}
                            </label>
                        </div>
                    );
                })}
            </div>

            {/* MAIN AREA */}
            <div style={mainAreaStyle}>
                <div style={chartSelectorStyle}>
                    {ALL_CHARTS.map((chart) => {
                        const isActive = chart === activeChart;
                        const result = resolveChart(chart, selectedColumns, columnMeta);
                        const title = result?.applicable
                            ? ''
                            : result?.reason || 'Chart not applicable';

                        return (
                            <Button
                                key={chart}
                                label={chart.charAt(0).toUpperCase() + chart.slice(1)}
                                icon={CHART_ICONS[chart]}
                                size="small"
                                severity={isActive ? 'info' : 'secondary'}
                                outlined={!isActive}
                                onClick={chartHandlers[chart]}
                                title={title}
                            />
                        );
                    })}
                </div>

                {showColumnWarning ? (
                    <WarningBox message={`Select up to ${MAX_COLUMNS} columns to view a chart.`} />
                ) : selectedColumns.length === 0 ? (
                    <WarningBox message="Please select columns." />
                ) : activeChartData?.applicable ? (
                    <div style={chartOutputStyle}>
                        <PrimeChart
                            type={activeChart}
                            data={data}
                            selectedColumns={selectedColumns}
                            columnMeta={columnMeta}
                            chartResolverOutput={activeChartData}
                        />
                    </div>
                ) : (
                    <WarningBox message={activeChartData?.reason || 'No chart can be rendered.'} />
                )}
            </div>
        </div>
    );
}

DataFrameCharts.propTypes = {
    data: PropTypes.arrayOf(PropTypes.object),
};

function WarningBox({ message }) {
    return <div style={warningBoxStyle}>{message}</div>;
}

WarningBox.propTypes = {
    message: PropTypes.string.isRequired,
};
