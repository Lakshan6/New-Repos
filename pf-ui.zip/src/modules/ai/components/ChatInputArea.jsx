import React, { useRef, useEffect, useCallback } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import '../styles/ChatInputArea.scss';

function ChatInputArea({ inputValue, setInputValue, onSendMessage, loading, isInDialog = false }) {
    const textareaRef = useRef(null);

    // Auto-resize textarea
    useEffect(() => {
        const textarea = textareaRef.current;
        if (!textarea) return;
        textarea.style.height = 'auto';
        const scrollHeight = textarea.scrollHeight;
        // const newHeight = Math.min(Math.max(scrollHeight, 52), 180);
        const newHeight = Math.min(Math.max(scrollHeight, 18), 120);
        textarea.style.height = newHeight + 'px';
    }, [inputValue]);

    // Enter key sends message
    const handleKeyDown = useCallback(
        (e) => {
            if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                onSendMessage();
            }
        },
        [onSendMessage],
    );

    // Update input value
    const handleInputChange = useCallback(
        (e) => {
            setInputValue(e.target.value);
        },
        [setInputValue],
    );

    return (
        <div className={`chat-input-area ${isInDialog ? 'chat-input-dialog' : ''}`}>
            <div className="input-wrapper">
                <div className="input-container">
                    <textarea
                        ref={textareaRef}
                        value={inputValue}
                        onChange={handleInputChange}
                        onKeyDown={handleKeyDown}
                        placeholder="Ask anything..."
                        disabled={loading}
                        className="input-textarea"
                        rows={1}
                    />

                    <Button
                        icon="pi pi-arrow-up"
                        onClick={onSendMessage}
                        disabled={!inputValue.trim() || loading}
                        className="send-btn"
                        rounded
                    />
                </div>
            </div>
        </div>
    );
}

ChatInputArea.propTypes = {
    inputValue: PropTypes.string.isRequired,
    setInputValue: PropTypes.func.isRequired,
    onSendMessage: PropTypes.func.isRequired,
    loading: PropTypes.bool.isRequired,
    isInDialog: PropTypes.bool,
};

export default ChatInputArea;
