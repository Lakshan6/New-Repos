import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { Button } from 'primereact/button';
import { Avatar } from 'primereact/avatar';

import DataframeChart from './DataframeChart';
import DataframeViewer from './DataframeViewer';

import '../styles/ChatMessageList.scss';

const EMPTY_SCHEMA = {};

const ChatMessageList = ({ messages, messagesEndRef, onCopyMessage, loading }) => {
    return (
        <div className="chat-messages-container">
            <div className="messages-list">
                {messages.map((msg) => (
                    <MessageItem
                        key={msg.id}
                        msg={msg}
                        onCopyMessage={onCopyMessage}
                        loading={loading}
                    />
                ))}
                <div ref={messagesEndRef} />
            </div>
        </div>
    );
};

const MessageItem = ({ msg, onCopyMessage, loading }) => {
    const [copied, setCopied] = useState(false);
    const [isVisualizing, setIsVisualizing] = useState(false);

    const handleCopy = useCallback(async () => {
        if (msg.type !== 'user') return;

        try {
            await navigator.clipboard.writeText(msg.content || '');
            setCopied(true);
            setTimeout(() => setCopied(false), 1500);
            onCopyMessage(msg.content || '');
        } catch (err) {
            console.error('Copy failed:', err);
        }
    }, [msg, onCopyMessage]);

    const handleVisualize = useCallback(() => {
        setIsVisualizing((prev) => !prev);
    }, []);

    const renderAIContent = () => {
        if (!msg.rawResponse) {
            if (loading) {
                return (
                    <div className="message-streaming">
                        <i className="pi pi-spin pi-spinner" />
                        <span>Generating response...</span>
                    </div>
                );
            }

            return <div className="no-data">No data available</div>;
        }
        let jsonResponse;

        try {
            jsonResponse = msg.rawResponse.jsonResponse
                ? JSON.parse(msg.rawResponse.jsonResponse)
                : null;
        } catch (err) {
            console.error('Parsing failed:', err);
            return <div className="no-data">Invalid response format</div>;
        }

        const rows = jsonResponse?.rows || [];

        if (!Array.isArray(rows) || rows.length === 0) {
            return <div className="no-data">No rows returned</div>;
        }

        return (
            <>
                <div className="ai-message-toolbar margin-1rem">
                    <Button
                        icon={isVisualizing ? 'pi pi-table' : 'pi pi-chart-bar'}
                        label={isVisualizing ? 'Table' : 'Visualize'}
                        severity="info"
                        size="small"
                        onClick={handleVisualize}
                    />
                </div>

                <div className="dataframe-visual-wrapper">
                    {isVisualizing ? (
                        <DataframeChart data={rows} />
                    ) : (
                        <DataframeViewer data={rows} schema={EMPTY_SCHEMA} filePath="result" />
                    )}
                </div>
            </>
        );
    };

    const renderContent = () => {
        if (msg.isStreaming) {
            return (
                <div className="message-streaming">
                    <i className="pi pi-spin pi-spinner" />
                    <span>Processing...</span>
                </div>
            );
        }

        if (msg.type === 'ai') {
            return <div className="ai-message-bubble">{renderAIContent()}</div>;
        }

        return (
            <div className="message-bubble message-bubble-user">
                <p>{msg.content}</p>
            </div>
        );
    };

    return (
        <div className={`message-wrapper message-${msg.type}`}>
            <div className="message-avatar">
                {msg.type === 'user' ? (
                    <Avatar icon="pi pi-user" size="large" shape="circle" />
                ) : (
                    <i className="pi pi-sparkles ai-icon" />
                )}
            </div>

            <div className="message-content-section">
                {renderContent()}

                {msg.type === 'user' && !msg.isStreaming && (
                    <div className="message-actions">
                        <Button
                            icon="pi pi-copy"
                            text
                            rounded
                            onClick={handleCopy}
                            className={copied ? 'copy-btn copied' : 'copy-btn'}
                        />
                        {copied && <span className="copy-feedback">Copied</span>}
                    </div>
                )}
            </div>
        </div>
    );
};

ChatMessageList.propTypes = {
    messages: PropTypes.array.isRequired,
    messagesEndRef: PropTypes.any,
    onCopyMessage: PropTypes.func.isRequired,
    loading: PropTypes.bool.isRequired,
};

MessageItem.propTypes = {
    msg: PropTypes.shape({
        id: PropTypes.oneOfType([PropTypes.string, PropTypes.number]),
        type: PropTypes.string,
        content: PropTypes.string,
        isStreaming: PropTypes.bool,
        rawResponse: PropTypes.shape({
            jsonResponse: PropTypes.string,
        }),
    }).isRequired,
    onCopyMessage: PropTypes.func.isRequired,
    loading: PropTypes.bool.isRequired,
};

export default ChatMessageList;
