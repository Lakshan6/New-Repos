import React, { useState, useCallback } from 'react';
import PropTypes from 'prop-types';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import '../styles/DataframeViewer.scss';

const DataframeViewer = ({ data = [] }) => {
    const [rowsPerPage] = useState(100);

    const renderCell = useCallback(
        (col) => (rowData) => (rowData[col] !== null ? String(rowData[col]) : 'null'),
        [],
    );

    if (!data || data.length === 0) {
        return <div className="dataframe-empty">📊 No data to display</div>;
    }

    const columns = Object.keys(data[0]);

    return (
        <div className="dataframe-viewer">
            <div className="dataframe-header">
                Rows: {data.length} | Columns: {columns.length}
            </div>
            <DataTable
                value={data}
                paginator
                rows={rowsPerPage}
                scrollable
                scrollHeight="400px"
                stripedRows
                className="p-datatable-sm small-paginator"
            >
                {columns.map((col) => (
                    <Column key={col} field={col} header={col} body={renderCell(col)} />
                ))}
            </DataTable>
        </div>
    );
};

DataframeViewer.propTypes = {
    data: PropTypes.arrayOf(PropTypes.object),
};

export default DataframeViewer;
