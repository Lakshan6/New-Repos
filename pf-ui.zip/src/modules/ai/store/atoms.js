import { atom } from 'jotai';

const translationsAtom = atom({});
const messagesAtom = atom([]);

export { translationsAtom, messagesAtom };
