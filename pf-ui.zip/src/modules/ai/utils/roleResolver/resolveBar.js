export function resolveBar(selectedColumns = [], columnMeta = {}) {
    const MAX_PRIMARY_CATEGORY = 100;

    const baseResult = {
        applicable: false,
        reason: null,
        roles: {},
        aggregation: { required: false },
        conversions: {},
        axisMode: 'aggregated',
        metadata: {
            detectedPattern: null,
            usedConvertible: false,
            usedAggregation: false,
            smallDatasetDirect: false,
        },
    };

    const reject = (reason) => ({ ...baseResult, reason });

    if (!Array.isArray(selectedColumns) || selectedColumns.length === 0)
        return reject('No columns selected.');

    // ✅ STRICT 2 COLUMN LIMIT
    if (selectedColumns.length > 2) return reject('Bar chart supports maximum 2 columns.');

    const resolved = selectedColumns.map((name) => {
        const meta = columnMeta[name];
        if (!meta) return null;

        return {
            name,
            originalType: meta.type,
            convertibleTo: meta.convertibleTo,
            uniqueCount: meta.uniqueCount,
            nullCount: meta.nullCount,
        };
    });

    if (resolved.includes(null)) return reject('Column metadata missing.');

    const conversions = {};
    let usedConvertible = false;

    // -------------------------------------------------
    // Capability checks
    // -------------------------------------------------

    const canBeCategorical = (col) =>
        col.originalType === 'string' || col.originalType === 'boolean';

    const canBeNumeric = (col) =>
        col.originalType === 'numeric' ||
        (col.originalType === 'string' && col.convertibleTo === 'numeric');

    const canBeDatetime = (col) =>
        col.originalType === 'datetime' ||
        (col.originalType === 'string' && col.convertibleTo === 'datetime');

    const guardCategory = (col, label) => {
        if (col.uniqueCount <= 1) return `${label} must contain multiple values.`;

        if (col.uniqueCount > MAX_PRIMARY_CATEGORY)
            return `${label} has too many categories for bar chart.`;

        return null;
    };

    const guardNumeric = (col) => {
        if (col.uniqueCount <= 1) return 'Numeric column must contain multiple valid values.';
        return null;
    };

    const applyNumericConversion = (col) => {
        if (col.originalType === 'string' && col.convertibleTo === 'numeric') {
            conversions[col.name] = 'numeric';
            usedConvertible = true;
        }
    };

    const applyDatetimeConversion = (col) => {
        if (col.originalType === 'string' && col.convertibleTo === 'datetime') {
            conversions[col.name] = 'datetime';
            usedConvertible = true;
        }
    };

    // =====================================================
    // 1 COLUMN → categorical count
    // =====================================================

    if (resolved.length === 1) {
        const col = resolved[0];

        if (!canBeCategorical(col)) return reject('Single column bar requires categorical data.');

        const guard = guardCategory(col, 'Category');
        if (guard) return reject(guard);

        return {
            ...baseResult,
            applicable: true,
            roles: { x: col.name, y: '__count__' },
            aggregation: {
                required: true,
                method: 'count',
                groupBy: [col.name],
            },
            metadata: {
                detectedPattern: 'categorical_count',
                usedConvertible,
                usedAggregation: true,
                smallDatasetDirect: false,
            },
        };
    }

    // =====================================================
    // 2 COLUMNS
    // =====================================================

    const [colA, colB] = resolved;

    // ❌ numeric + numeric → reject
    if (canBeNumeric(colA) && canBeNumeric(colB))
        return reject('Bar chart requires one categorical or datetime axis.');

    // -------------------------------------------------
    // categorical + numeric
    // -------------------------------------------------

    if (
        (canBeCategorical(colA) && canBeNumeric(colB)) ||
        (canBeCategorical(colB) && canBeNumeric(colA))
    ) {
        const x = canBeCategorical(colA) ? colA : colB;
        const y = x === colA ? colB : colA;

        const guard = guardCategory(x, 'Category');
        if (guard) return reject(guard);

        const numericGuard = guardNumeric(y);
        if (numericGuard) return reject(numericGuard);

        applyNumericConversion(y);

        return {
            ...baseResult,
            applicable: true,
            roles: { x: x.name, y: y.name },
            aggregation: {
                required: true,
                method: 'sum',
                groupBy: [x.name],
                field: y.name,
            },
            conversions,
            metadata: {
                detectedPattern: 'categorical_numeric_sum',
                usedConvertible,
                usedAggregation: true,
                smallDatasetDirect: false,
            },
        };
    }

    // -------------------------------------------------
    // datetime + numeric
    // -------------------------------------------------

    if (
        (canBeDatetime(colA) && canBeNumeric(colB)) ||
        (canBeDatetime(colB) && canBeNumeric(colA))
    ) {
        const x = canBeDatetime(colA) ? colA : colB;
        const y = x === colA ? colB : colA;

        const guard = guardCategory(x, 'Time');
        if (guard) return reject(guard);

        const numericGuard = guardNumeric(y);
        if (numericGuard) return reject(numericGuard);

        applyDatetimeConversion(x);
        applyNumericConversion(y);

        return {
            ...baseResult,
            applicable: true,
            axisMode: 'time', // ✅ future-proof if using time scale
            roles: { x: x.name, y: y.name },
            aggregation: {
                required: true,
                method: 'sum',
                groupBy: [x.name],
                field: y.name,
            },
            conversions,
            metadata: {
                detectedPattern: 'datetime_numeric_sum',
                usedConvertible,
                usedAggregation: true,
                smallDatasetDirect: false,
            },
        };
    }

    return reject('Unsupported configuration for bar chart.');
}
