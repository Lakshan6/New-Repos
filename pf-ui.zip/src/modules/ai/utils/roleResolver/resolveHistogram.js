// utils/chartResolvers/resolveHistogram.js

export function resolveHistogram(selectedColumns = [], columnMeta = {}) {
    const MAX_GROUP_CATEGORIES = 50;
    const MAX_HISTOGRAM_BINS = 30;
    const MIN_HISTOGRAM_BINS = 5;

    const baseResult = {
        applicable: false,
        reason: null,
        roles: {},
        conversions: {},
        aggregation: { required: false },
        metadata: {
            detectedPattern: null,
            binCount: null,
        },
    };

    const reject = (reason) => ({ ...baseResult, reason });

    // ===========================
    // Selection Validation
    // ===========================
    if (!Array.isArray(selectedColumns)) return reject('Invalid column selection.');
    if (selectedColumns.length < 1 || selectedColumns.length > 2)
        return reject('Histogram requires 1 or 2 columns.');

    // ===========================
    // Determine main and group columns based on suitability
    // ===========================
    let mainName = null;
    let groupName = null;

    // Pick main column as numeric or convertible
    for (const col of selectedColumns) {
        const meta = columnMeta[col];
        if (!meta) continue;
        let type = meta.type;
        if (type === 'string' && meta.convertibleTo) type = meta.convertibleTo;
        if (type === 'numeric' || type === 'datetime') {
            mainName = col;
            break;
        }
    }

    if (!mainName) return reject('Histogram requires at least one numeric or datetime column.');

    // Pick group column if the other column exists and is categorical/boolean
    groupName =
        selectedColumns.find(
            (col) => col !== mainName && ['string', 'boolean'].includes(columnMeta[col]?.type),
        ) || null;

    const mainCol = columnMeta[mainName];
    const groupCol = groupName ? columnMeta[groupName] : null;

    // ===========================
    // Resolve Primary Column Type
    // ===========================
    let primaryType = mainCol.type;
    const conversions = {};

    if (primaryType === 'string' && mainCol.convertibleTo) {
        primaryType = mainCol.convertibleTo;
        conversions[mainName] = mainCol.convertibleTo;
    }

    if (primaryType !== 'numeric' && primaryType !== 'datetime')
        return reject('Histogram requires numeric or datetime column.');

    if (mainCol.uniqueCount <= 1)
        return reject('Primary column must contain multiple unique values.');

    // ===========================
    // Compute Bin Count (heuristic using uniqueCount)
    // ===========================
    const binCount = Math.min(
        MAX_HISTOGRAM_BINS,
        Math.max(MIN_HISTOGRAM_BINS, Math.ceil(Math.sqrt(mainCol.uniqueCount))),
    );

    // ===========================
    // Single Column Histogram
    // ===========================
    if (!groupName) {
        return {
            applicable: true,
            reason: null,
            roles: { x: mainName, y: '__count__' },
            conversions,
            aggregation: {
                required: true,
                method: 'histogram_bin_count',
                field: mainName,
                binCount,
            },
            metadata: {
                detectedPattern:
                    primaryType === 'datetime' ? 'datetime_histogram' : 'numeric_histogram',
                binCount,
            },
        };
    }

    // ===========================
    // Grouped Histogram
    // ===========================
    if (!groupCol) return reject('Grouping column metadata missing.');

    if (groupCol.type !== 'string' && groupCol.type !== 'boolean')
        return reject('Grouping column must be categorical or boolean.');

    if (groupCol.uniqueCount > MAX_GROUP_CATEGORIES) return reject('Too many grouping categories.');

    return {
        applicable: true,
        reason: null,
        roles: { x: mainName, y: '__count__', group: groupName },
        conversions,
        aggregation: {
            required: true,
            method: 'histogram_bin_count',
            field: mainName,
            groupBy: groupName,
            binCount,
        },
        metadata: {
            detectedPattern:
                primaryType === 'datetime'
                    ? 'datetime_histogram_grouped'
                    : 'numeric_histogram_grouped',
            binCount,
        },
    };
}
