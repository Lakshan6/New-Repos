export function resolveLine(selectedColumns = [], columnMeta = {}) {
    const reject = (reason, pattern = 'invalid_line_configuration') => ({
        applicable: false,
        reason,
        roles: {},
        aggregation: { required: false },
        conversions: {},
        axisMode: 'ordered',
        metadata: {
            detectedPattern: pattern,
            usedConvertible: false,
            usedAggregation: false,
        },
    });

    if (!Array.isArray(selectedColumns) || selectedColumns.length === 0) {
        return reject('No columns selected.');
    }

    if (selectedColumns.length > 2) {
        return reject('Line chart supports maximum 2 columns.');
    }

    const conversions = {};
    let usedConvertible = false;
    const resolved = [];

    // Resolve types
    for (const colName of selectedColumns) {
        const meta = columnMeta[colName];
        if (!meta) return reject(`Missing metadata for column: ${colName}`);

        let finalType = meta.type;

        if (meta.type === 'string' && meta.convertibleTo) {
            finalType = meta.convertibleTo;
            conversions[colName] = meta.convertibleTo;
            usedConvertible = true;
        }

        resolved.push({
            name: colName,
            type: finalType,
            uniqueCount: meta.uniqueCount || 0,
        });
    }

    let x = null;
    let y = null;
    let detectedPattern = null;

    // =============================
    // SINGLE COLUMN
    // =============================
    if (resolved.length === 1) {
        const col = resolved[0];

        if (col.type !== 'numeric' && col.type !== 'datetime') {
            return reject('Single column line requires numeric or datetime.');
        }

        if (col.uniqueCount <= 1) {
            return reject('Column must contain multiple values.');
        }

        if (col.type === 'datetime') {
            x = col;
            y = { name: '__index__', type: 'index' };
        } else {
            x = { name: '__index__', type: 'index' };
            y = col;
        }

        detectedPattern =
            col.type === 'datetime' ? 'single_datetime_index_line' : 'single_numeric_index_line';
    }

    // =============================
    // TWO COLUMNS
    // =============================
    if (resolved.length === 2) {
        const colA = resolved[0];
        const colB = resolved[1];

        const isNumericA = colA.type === 'numeric';
        const isNumericB = colB.type === 'numeric';
        const isDatetimeA = colA.type === 'datetime';
        const isDatetimeB = colB.type === 'datetime';

        // datetime + numeric
        if ((isDatetimeA && isNumericB) || (isDatetimeB && isNumericA)) {
            x = isDatetimeA ? colA : colB;
            y = isNumericA ? colA : colB;
            detectedPattern = 'time_series_line';
        }

        // numeric + numeric
        else if (isNumericA && isNumericB) {
            x = colA;
            y = colB;
            detectedPattern = 'numeric_numeric_line';
        } else {
            return reject('Line chart requires numeric/datetime X and numeric Y.');
        }

        if (x.uniqueCount <= 1) return reject('X axis must contain multiple values.');

        if (y.uniqueCount <= 1) return reject('Y axis must contain multiple values.');
    }

    if (!x || !y) {
        return reject('Unable to determine X and Y roles.');
    }

    return {
        applicable: true,
        reason: null,
        roles: { x: x.name, y: y.name },
        aggregation: { required: false }, // 🔥 Always false
        conversions,
        axisMode: x.type === 'datetime' ? 'time' : 'ordered',
        metadata: {
            detectedPattern,
            usedConvertible,
            usedAggregation: false,
        },
    };
}
