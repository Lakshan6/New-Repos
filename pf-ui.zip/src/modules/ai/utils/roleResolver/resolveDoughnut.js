export function resolveDoughnut(selectedColumns = [], columnMeta = {}) {
    const MAX_CATEGORIES = 50;

    const baseResult = {
        applicable: false,
        reason: null,
        roles: {},
        aggregation: { required: false },
        conversions: {},
        metadata: {
            detectedPattern: null,
            usedConvertible: false,
            usedAggregation: false,
            smallDatasetDirect: false,
            singleCategory: false,
        },
    };

    const reject = (reason) => ({ ...baseResult, reason });

    if (
        !Array.isArray(selectedColumns) ||
        selectedColumns.length < 1 ||
        selectedColumns.length > 2
    ) {
        return reject('Doughnut supports 1 or 2 columns.');
    }

    const conversions = {};
    let usedConvertible = false;

    const resolved = selectedColumns.map((name) => {
        const meta = columnMeta[name];
        if (!meta) return null;

        return {
            name,
            originalType: meta.type, // aligned with profiler
            convertibleTo: meta.convertibleTo,
            uniqueCount: meta.uniqueCount,
            nullCount: meta.nullCount,
        };
    });

    if (resolved.includes(null)) return reject('Column metadata missing.');

    // ✅ Updated to support datetime (aligned with profiler)
    const canBeCategorical = (col) =>
        col.originalType === 'string' ||
        col.originalType === 'boolean' ||
        col.originalType === 'datetime' ||
        (col.originalType === 'string' && col.convertibleTo === 'datetime');

    const canBeNumeric = (col) =>
        col.originalType === 'numeric' ||
        (col.originalType === 'string' && col.convertibleTo === 'numeric');

    // =====================================================
    // ✅ Single column case (categorical count)
    // =====================================================
    if (resolved.length === 1) {
        const col = resolved[0];

        if (!canBeCategorical(col))
            return reject('Single column doughnut requires categorical data.');

        if (col.uniqueCount <= 1) return reject('Column must contain multiple categories.');

        if (col.uniqueCount > MAX_CATEGORIES)
            return reject('Too many categories for doughnut chart.');

        // Handle string → datetime conversion
        if (col.originalType === 'string' && col.convertibleTo === 'datetime') {
            conversions[col.name] = 'datetime';
            usedConvertible = true;
        }

        return {
            applicable: true,
            reason: null,
            roles: { category: col.name, value: '__count__' },
            aggregation: {
                required: true,
                method: 'count',
                groupBy: [col.name],
            },
            conversions,
            metadata: {
                detectedPattern: 'categorical_count',
                usedConvertible,
                usedAggregation: true,
                smallDatasetDirect: false,
                singleCategory: false,
            },
        };
    }

    // =====================================================
    // ✅ Two column case (categorical + numeric sum)
    // =====================================================
    const [colA, colB] = resolved;
    let category = null;
    let numeric = null;

    if (canBeCategorical(colA) && canBeNumeric(colB)) {
        category = colA;
        numeric = colB;
    } else if (canBeCategorical(colB) && canBeNumeric(colA)) {
        category = colB;
        numeric = colA;
    } else {
        return reject('Doughnut requires one categorical and one numeric column.');
    }

    // Handle numeric conversion
    if (numeric.originalType === 'string' && numeric.convertibleTo === 'numeric') {
        conversions[numeric.name] = 'numeric';
        usedConvertible = true;
    }

    // Handle string → datetime conversion for category
    if (category.originalType === 'string' && category.convertibleTo === 'datetime') {
        conversions[category.name] = 'datetime';
        usedConvertible = true;
    }

    if (category.uniqueCount <= 1) return reject('Category column must contain multiple values.');

    if (category.uniqueCount > MAX_CATEGORIES)
        return reject('Too many categories for doughnut chart.');

    return {
        applicable: true,
        reason: null,
        roles: { category: category.name, value: numeric.name },
        aggregation: {
            required: true,
            method: 'sum',
            groupBy: [category.name],
            field: numeric.name,
        },
        conversions,
        metadata: {
            detectedPattern: 'categorical_numeric_sum',
            usedConvertible,
            usedAggregation: true,
            smallDatasetDirect: false,
            singleCategory: false,
        },
    };
}
