export function resolveScatter(selectedColumns = [], columnMeta = {}) {
    const baseResult = {
        applicable: false,
        reason: null,
        roles: {},
        aggregation: { required: false },
        conversions: {},
        axisMode: 'direct',
        metadata: {
            detectedPattern: null,
            usedConvertible: false,
        },
    };

    const reject = (reason) => ({ ...baseResult, reason });

    // -------------------------------------------------
    // 1. Strict column count
    // -------------------------------------------------

    if (!Array.isArray(selectedColumns) || selectedColumns.length !== 2)
        return reject('Scatter requires exactly 2 columns.');

    // -------------------------------------------------
    // 2. Resolve metadata
    // -------------------------------------------------

    const resolved = selectedColumns.map((name) => {
        const meta = columnMeta[name];
        if (!meta) return null;

        return {
            name,
            originalType: meta.type,
            convertibleTo: meta.convertibleTo,
            uniqueCount: meta.uniqueCount ?? 0,
            nullCount: meta.nullCount ?? 0,
        };
    });

    if (resolved.includes(null)) return reject('Column metadata missing.');

    const [colX, colY] = resolved;

    // -------------------------------------------------
    // 3. Capability checks
    // -------------------------------------------------

    const isNumeric = (col) => col.originalType === 'numeric';
    const isDatetime = (col) => col.originalType === 'datetime';

    const canConvertToNumeric = (col) =>
        col.originalType === 'string' && col.convertibleTo === 'numeric';

    const canConvertToDatetime = (col) =>
        col.originalType === 'string' && col.convertibleTo === 'datetime';

    const isQuantitative = (col) =>
        isNumeric(col) || isDatetime(col) || canConvertToNumeric(col) || canConvertToDatetime(col);

    if (!isQuantitative(colX) || !isQuantitative(colY))
        return reject('Scatter requires numeric or datetime columns.');

    // -------------------------------------------------
    // 4. Ensure at least one valid value exists
    // -------------------------------------------------

    if (colX.uniqueCount === 0 || colY.uniqueCount === 0)
        return reject('One of the axes has no valid values.');

    // -------------------------------------------------
    // 5. Track conversion intent (non-mutating)
    // -------------------------------------------------

    const conversions = {};
    let usedConvertible = false;

    const applyConversion = (col) => {
        if (canConvertToNumeric(col)) {
            conversions[col.name] = 'numeric';
            usedConvertible = true;
        } else if (canConvertToDatetime(col)) {
            conversions[col.name] = 'datetime';
            usedConvertible = true;
        }
    };

    applyConversion(colX);
    applyConversion(colY);

    // -------------------------------------------------
    // 6. Return clean direct scatter
    // -------------------------------------------------

    return {
        ...baseResult,
        applicable: true,
        roles: {
            x: colX.name,
            y: colY.name,
        },
        conversions,
        metadata: {
            detectedPattern: 'quantitative_quantitative_direct',
            usedConvertible,
        },
    };
}
