// chartEngine.js

import { resolveLine } from './roleResolver/resolveLine';
import { resolveBar } from './roleResolver/resolveBar';
import { resolveDoughnut } from './roleResolver/resolveDoughnut';
import { resolveScatter } from './roleResolver/resolveScatter';
import { resolveHistogram } from './roleResolver/resolveHistogram';

/**
 * Lazy resolve a single chart on-demand
 * Returns { possible, data, reason }
 */
export function resolveChart(chartType, selectedColumns = [], profilerOutput = {}) {
    switch (chartType) {
        case 'line':
            return resolveLine(selectedColumns, profilerOutput);
        case 'bar':
            return resolveBar(selectedColumns, profilerOutput);
        case 'doughnut':
            return resolveDoughnut(selectedColumns, profilerOutput);
        case 'scatter':
            return resolveScatter(selectedColumns, profilerOutput);
        case 'histogram':
            return resolveHistogram(selectedColumns, profilerOutput);
        default:
            return { possible: false, reason: 'Unknown chart type' };
    }
}
