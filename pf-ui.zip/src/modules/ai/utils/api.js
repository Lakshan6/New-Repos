import { dummyAnalyzeResponses } from './dummyAnalyzeResponses';
import { useMutation } from '@tanstack/react-query';

const sleep = (ms) => new Promise((resolve) => setTimeout(resolve, ms));

const mockAnalyzeMutation = async (body) => {
    console.log('Mock analyze called with:', body);

    // simulate latency
    const latency = 400 + Math.random() * 1100;
    await sleep(latency);

    // simulate error like real fetch
    if (Math.random() < 0.1) {
        const error = new Error('Mock network error');
        error.status = 500;
        throw error;
    }

    const randomIndex = Math.floor(Math.random() * dummyAnalyzeResponses.length);

    // 🚨 RETURN EXACT SAME SHAPE AS REAL API
    return dummyAnalyzeResponses[randomIndex];
};

export function useMockMutationApi(options) {
    return useMutation({
        mutationFn: (variables) => mockAnalyzeMutation(variables),
        ...options,
    });
}
