export function applyAggregation(data = [], resolverOutput = {}) {
    if (!Array.isArray(data) || data.length === 0) return data;

    const aggregation = resolverOutput?.aggregation;
    if (!aggregation?.required || !aggregation.method) return data;

    const { method, groupBy = [], field, binCount = 10 } = aggregation;

    const groupColumns = Array.isArray(groupBy) ? groupBy : groupBy ? [groupBy] : [];

    // ---------------------------------------------
    // Helpers
    // ---------------------------------------------

    const normalize = (val) => (val instanceof Date ? val.getTime() : val);

    const buildKey = (row) =>
        groupColumns.length
            ? groupColumns.map((col) => normalize(row[col])).join('__|__')
            : '__all__';

    const assignGroupFields = (base, row) => {
        groupColumns.forEach((col) => {
            base[col] = row[col];
        });
    };

    // ====================================================
    // COUNT
    // ====================================================
    if (method === 'count') {
        const map = new Map();

        for (const row of data) {
            const key = buildKey(row);

            if (!map.has(key)) {
                const base = { __count__: 0 };
                assignGroupFields(base, row);
                map.set(key, base);
            }

            map.get(key).__count__ += 1;
        }

        return Array.from(map.values());
    }

    // ====================================================
    // SUM (numeric only)
    // ====================================================
    if (method === 'sum') {
        if (!field) return data;

        const map = new Map();

        for (const row of data) {
            const key = buildKey(row);
            let value = row[field];

            if (value == null) continue;

            if (typeof value !== 'number') {
                value = Number(value);
            }

            if (isNaN(value)) continue;

            if (!map.has(key)) {
                const base = { [field]: 0 };
                assignGroupFields(base, row);
                map.set(key, base);
            }

            map.get(key)[field] += value;
        }

        return Array.from(map.values());
    }

    // ====================================================
    // HISTOGRAM (numeric or datetime)
    // ====================================================
    if (method === 'histogram_bin_count') {
        if (!field) return [];

        let min = Infinity;
        let max = -Infinity;

        // 1️⃣ Find min/max
        for (const row of data) {
            let val = row[field];
            if (val instanceof Date) {
                val = val.getTime();
            } else if (typeof val !== 'number') {
                val = Number(val);
            }

            if (isNaN(val)) continue;
            if (val < min) min = val;
            if (val > max) max = val;
        }

        if (min === Infinity || max === -Infinity || min === max) return [];

        const binSize = (max - min) / binCount;
        const binMap = new Map();

        for (const row of data) {
            let value = row[field];
            if (value instanceof Date) {
                value = value.getTime();
            } else if (typeof value !== 'number') {
                value = Number(value);
            }

            if (isNaN(value)) continue;

            // 2️⃣ Compute bin index safely
            let index = Math.floor((value - min) / binSize);
            if (index < 0) index = 0;
            if (index >= binCount) index = binCount - 1;

            // 3️⃣ Key includes group columns if any
            const key = `${index}__${buildKey(row)}`;

            if (!binMap.has(key)) {
                const base = {
                    binIndex: index,
                    binStart: min + index * binSize,
                    binEnd: index === binCount - 1 ? max : min + (index + 1) * binSize,
                    __count__: 0,
                };
                assignGroupFields(base, row);
                binMap.set(key, base);
            }

            // 4️⃣ Increment count
            binMap.get(key).__count__ += 1;
        }

        return Array.from(binMap.values());
    }

    return data;
}
