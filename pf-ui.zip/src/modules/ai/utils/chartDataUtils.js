// import { applyConversions } from "./conversionEngine";
// import { applyAggregation } from "./aggregationEngine";

// /**
//  * Main entry: prepares chart data for PrimeChart.
//  * Handles each chart type explicitly.
//  */
// export function prepareChartData(type, data = [], resolverOutput = {}, columnMeta = {}) {
//   if (!Array.isArray(data) || data.length === 0) return { labels: [], datasets: [] };
//   if (!resolverOutput?.applicable) return { labels: [], datasets: [] };

//   // Step 1: Apply conversions
//   let processedData = applyConversions(data, resolverOutput, columnMeta);

//   // Step 2: Apply aggregation if needed
//   if (resolverOutput.aggregation?.required) {
//     processedData = applyAggregation(processedData, resolverOutput);
//   }

//   if (!processedData.length) return { labels: [], datasets: [] };

//   switch (type) {
//     case "histogram":
//       return prepareHistogramData(processedData, resolverOutput, columnMeta);

//     case "scatter":
//       return prepareScatterData(processedData, resolverOutput, columnMeta);

//     case "line":
//       return prepareLineData(processedData, resolverOutput, columnMeta);

//     case "bar":
//       return prepareBarData(processedData, resolverOutput, columnMeta);

//     case "pie":
//     case "doughnut":
//       return preparePieData(processedData, resolverOutput, columnMeta);

//     default:
//       return { labels: [], datasets: [] };
//   }
// }

// // ---------------------------
// // Histogram Handler
// // ---------------------------
// function prepareHistogramData(data, resolverOutput, columnMeta) {
//   const { roles = {}, aggregation = {}, conversions = {} } = resolverOutput;
//   if (!aggregation || aggregation.method !== "histogram_bin_count") return { labels: [], datasets: [] };

//   const isGrouped = !!roles.group;
//   const groupKey = roles.group;
//   const countKey = "__count__";

//   // Determine histogram field
//   const histField = roles.x || roles.y || Object.keys(roles)[0];

//   // Check if resolver says this field was converted to datetime
//   const meta = columnMeta?.[histField] || {};

//   const isDatetime =
//     conversions[histField] === "datetime" ||
//     meta.type === "datetime";

//   // 1️⃣ Sort bins by binIndex
//   const bins = [...data].sort((a, b) => a.binIndex - b.binIndex);

//   // 2️⃣ Unique bin indices
//   const binIndices = [...new Set(bins.map((r) => r.binIndex))].sort((a, b) => a - b);

//   // 3️⃣ Prepare labels
//   const labels = binIndices.map((i) => {
//     const bin = bins.find((b) => b.binIndex === i);
//     if (!bin) return `${i}`;

//     let { binStart: start, binEnd: end } = bin;

//     if (isDatetime) {
//       // Convert numbers or strings to Date
//       if (!(start instanceof Date)) start = new Date(start);
//       if (!(end instanceof Date)) end = new Date(end);

//       // Fallback in case of invalid dates
//       start = isNaN(start.getTime()) ? start : start.toLocaleString();
//       end = isNaN(end.getTime()) ? end : end.toLocaleString();
//     }

//     return start === end ? `${start}` : `${start} - ${end}`;
//   });

//   // 4️⃣ Prepare datasets
//   const datasets = [];

//   if (isGrouped) {
//     const groups = [...new Set(data.map((r) => r[groupKey]))];
//     groups.forEach((grp) => {
//       const counts = binIndices.map((i) => {
//         const row = data.find((r) => r.binIndex === i && r[groupKey] === grp);
//         return row ? Number(row[countKey] || 0) : 0;
//       });
//       datasets.push({ label: grp, data: counts });
//     });
//   } else {
//     const counts = binIndices.map((i) => {
//       const row = data.find((r) => r.binIndex === i);
//       return row ? Number(row[countKey] || 0) : 0;
//     });
//     datasets.push({ label: roles.y || countKey, data: counts });
//   }

//   return { labels, datasets };
// }

// // ---------------------------
// // Scatter Handler
// // ---------------------------
// function prepareScatterData(data, resolverOutput, columnMeta) {
//   const { roles = {} } = resolverOutput;
//   if (!roles.x || !roles.y)
//     return { datasets: [] };

//   const points = data
//     .filter(
//       (r) =>
//         r[roles.x] != null &&
//         r[roles.y] != null
//     )
//     .map((r) => ({
//       x: r[roles.x],
//       y: r[roles.y],
//     }));

//   return {
//     datasets: [
//       {
//         label: `${roles.y} vs ${roles.x}`,
//         data: points,
//       },
//     ],
//   };
// }

// // ---------------------------
// // Line Handler
// // ---------------------------
// function prepareLineData(data, resolverOutput, columnMeta) {
//   const { roles = {}, axisMode } = resolverOutput;

//   if (!roles.x || !roles.y)
//     return { labels: [], datasets: [] };

//   // ----------------------------------
//   // 🔹 SINGLE COLUMN (index synthetic)
//   // ----------------------------------
//   if (roles.y === "__index__") {
//     const sorted =
//       axisMode === "time"
//         ? [...data].sort(
//           (a, b) => new Date(a[roles.x]) - new Date(b[roles.x])
//         )
//         : data;

//     return {
//       labels: sorted.map((r) => r[roles.x]),
//       datasets: [
//         {
//           label: "Index",
//           data: sorted.map((_, idx) => idx + 1),
//         },
//       ],
//     };
//   }

//   if (roles.x === "__index__") {
//     return {
//       labels: data.map((_, idx) => idx + 1),
//       datasets: [
//         {
//           label: roles.y,
//           data: data.map((r) => r[roles.y]),
//         },
//       ],
//     };
//   }

//   // ----------------------------------
//   // 🔹 DATETIME X-AXIS
//   // ----------------------------------
//   if (axisMode === "time") {
//     const sorted = [...data].sort(
//       (a, b) => new Date(a[roles.x]) - new Date(b[roles.x])
//     );

//     return {
//       labels: sorted.map((r) => r[roles.x]),
//       datasets: [
//         {
//           label: roles.y,
//           data: sorted.map((r) => r[roles.y]),
//         },
//       ],
//     };
//   }

//   // ----------------------------------
//   // 🔹 NORMAL CASE
//   // ----------------------------------
//   return {
//     labels: data.map((r) => r[roles.x]),
//     datasets: [
//       {
//         label: roles.y,
//         data: data.map((r) => r[roles.y]),
//       },
//     ],
//   };
// }

// // ---------------------------
// // Bar Handler
// // ---------------------------
// function prepareBarData(data, resolverOutput, columnMeta) {
//   const { roles = {}, aggregation = {} } = resolverOutput;

//   return {
//     labels: data.map((r) => r[roles.x]),
//     datasets: [
//       {
//         label: roles.y,
//         data: data.map((r) =>
//           aggregation?.required
//             ? r.__count__ || r[aggregation.field] || 0
//             : r[roles.y]
//         ),
//       },
//     ],
//   };
// }

// // ---------------------------
// // Doughnut Handler
// // ---------------------------
// function preparePieData(data, resolverOutput, columnMeta) {
//   const { roles = {}, aggregation = {} } = resolverOutput;

//   const labels = data.map((r) => {
//     const value = r[roles.category];

//     if (value instanceof Date) {
//       return value.toLocaleString();
//     }

//     return value != null ? String(value) : "Null";
//   });

//   const datasets = [
//     {
//       label: roles.value,
//       data: data.map((r) =>
//         aggregation?.required
//           ? r.__count__ ?? r[aggregation.field] ?? 0
//           : r[roles.value]
//       ),
//     },
//   ];

//   return { labels, datasets };
// }
import { applyConversions } from './conversionEngine';
import { applyAggregation } from './aggregationEngine';

export function prepareChartData(type, data = [], resolverOutput = {}, columnMeta = {}) {
    if (!Array.isArray(data) || data.length === 0) return { labels: [], datasets: [] };
    if (!resolverOutput?.applicable) return { labels: [], datasets: [] };

    let processedData = applyConversions(data, resolverOutput, columnMeta);

    if (resolverOutput.aggregation?.required) {
        processedData = applyAggregation(processedData, resolverOutput);
    }

    if (!processedData.length) return { labels: [], datasets: [] };

    switch (type) {
        case 'histogram':
            return prepareHistogramData(processedData, resolverOutput, columnMeta);
        case 'scatter':
            return prepareScatterData(processedData, resolverOutput);
        case 'line':
            return prepareLineData(processedData, resolverOutput);
        case 'bar':
            return prepareBarData(processedData, resolverOutput);
        case 'pie':
        case 'doughnut':
            return preparePieData(processedData, resolverOutput);
        default:
            return { labels: [], datasets: [] };
    }
}

function prepareHistogramData(data, resolverOutput, columnMeta) {
    const { roles = {}, aggregation = {}, conversions = {} } = resolverOutput;
    if (!aggregation || aggregation.method !== 'histogram_bin_count')
        return { labels: [], datasets: [] };

    const isGrouped = !!roles.group;
    const groupKey = roles.group;
    const countKey = '__count__';
    const histField = roles.x || roles.y || Object.keys(roles)[0];
    const meta = columnMeta?.[histField] || {};
    const isDatetime = conversions[histField] === 'datetime' || meta.type === 'datetime';

    const bins = [...data].sort((a, b) => a.binIndex - b.binIndex);
    const binIndices = [...new Set(bins.map((r) => r.binIndex))].sort((a, b) => a - b);

    const labels = binIndices.map((i) => {
        const bin = bins.find((b) => b.binIndex === i);
        if (!bin) return `${i}`;
        let { binStart: start, binEnd: end } = bin;
        if (isDatetime) {
            if (!(start instanceof Date)) start = new Date(start);
            if (!(end instanceof Date)) end = new Date(end);
            start = isNaN(start.getTime()) ? start : start.toLocaleString();
            end = isNaN(end.getTime()) ? end : end.toLocaleString();
        }
        return start === end ? `${start}` : `${start} - ${end}`;
    });

    const datasets = [];
    if (isGrouped) {
        const groups = [...new Set(data.map((r) => r[groupKey]))];
        groups.forEach((grp) => {
            const counts = binIndices.map((i) => {
                const row = data.find((r) => r.binIndex === i && r[groupKey] === grp);
                return row ? Number(row[countKey] || 0) : 0;
            });
            datasets.push({ label: grp, data: counts });
        });
    } else {
        const counts = binIndices.map((i) => {
            const row = data.find((r) => r.binIndex === i);
            return row ? Number(row[countKey] || 0) : 0;
        });
        datasets.push({ label: roles.y || countKey, data: counts });
    }

    return { labels, datasets };
}

function prepareScatterData(data, resolverOutput) {
    const { roles = {} } = resolverOutput;
    if (!roles.x || !roles.y) return { datasets: [] };
    const points = data
        .filter((r) => r[roles.x] != null && r[roles.y] != null)
        .map((r) => ({ x: r[roles.x], y: r[roles.y] }));
    return { datasets: [{ label: `${roles.y} vs ${roles.x}`, data: points }] };
}

function prepareLineData(data, resolverOutput) {
    const { roles = {}, axisMode } = resolverOutput;
    if (!roles.x || !roles.y) return { labels: [], datasets: [] };

    if (roles.y === '__index__') {
        const sorted =
            axisMode === 'time'
                ? [...data].sort((a, b) => new Date(a[roles.x]) - new Date(b[roles.x]))
                : data;
        return {
            labels: sorted.map((r) => r[roles.x]),
            datasets: [{ label: 'Index', data: sorted.map((_, idx) => idx + 1) }],
        };
    }

    if (roles.x === '__index__') {
        return {
            labels: data.map((_, idx) => idx + 1),
            datasets: [{ label: roles.y, data: data.map((r) => r[roles.y]) }],
        };
    }

    if (axisMode === 'time') {
        const sorted = [...data].sort((a, b) => new Date(a[roles.x]) - new Date(b[roles.x]));
        return {
            labels: sorted.map((r) => r[roles.x]),
            datasets: [{ label: roles.y, data: sorted.map((r) => r[roles.y]) }],
        };
    }

    return {
        labels: data.map((r) => r[roles.x]),
        datasets: [{ label: roles.y, data: data.map((r) => r[roles.y]) }],
    };
}

function prepareBarData(data, resolverOutput) {
    const { roles = {}, aggregation = {} } = resolverOutput;
    return {
        labels: data.map((r) => r[roles.x]),
        datasets: [
            {
                label: roles.y,
                data: data.map((r) =>
                    aggregation?.required ? r.__count__ || r[aggregation.field] || 0 : r[roles.y],
                ),
            },
        ],
    };
}

function preparePieData(data, resolverOutput) {
    const { roles = {}, aggregation = {} } = resolverOutput;
    const labels = data.map((r) => {
        const value = r[roles.category];
        if (value instanceof Date) return value.toLocaleString();
        return value != null ? String(value) : 'Null';
    });
    const datasets = [
        {
            label: roles.value,
            data: data.map((r) =>
                aggregation?.required ? (r.__count__ ?? r[aggregation.field] ?? 0) : r[roles.value],
            ),
        },
    ];
    return { labels, datasets };
}
