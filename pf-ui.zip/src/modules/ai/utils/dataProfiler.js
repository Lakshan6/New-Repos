// utils/dataProfiler.js

const MAX_SAMPLE_SIZE = 50;

// ================= NULL CHECK =================

const isNullish = (value) =>
    value === null || value === undefined || value === '' || value === 'null' || value === 'NaN';

// ================= HELPERS =================

const normalize = (v) => String(v).trim().toLowerCase();

const getSampleValues = (data, column) => {
    const clean = data.map((row) => row[column]).filter((v) => !isNullish(v));

    return clean.slice(0, Math.min(MAX_SAMPLE_SIZE, clean.length));
};

// ================= BOOLEAN =================

const isBooleanColumn = (values) => {
    if (!values.length) return false;

    return values.every((v) => ['true', 'false', '0', '1'].includes(normalize(v)));
};

// ================= NUMERIC =================

const isNumericColumn = (values) => {
    if (!values.length) return false;

    return values.every((v) => {
        if (typeof v === 'number') return !isNaN(v);

        if (typeof v === 'string' && v.trim() !== '') {
            return !isNaN(Number(v));
        }

        return false;
    });
};

// ================= DATETIME =================

const DATE_PATTERNS = [/^\d{4}-\d{2}-\d{2}/, /^\d{2}\/\d{2}\/\d{4}/, /^\d{4}\/\d{2}\/\d{2}/];

const looksLikeTimestampNumber = (value) => {
    if (typeof value !== 'number' && isNaN(Number(value))) return false;

    const num = Number(value);
    return num > 1000000000;
};

const looksLikeDate = (value) => {
    if (DATE_PATTERNS.some((pattern) => pattern.test(String(value)))) {
        return !isNaN(new Date(value).getTime());
    }

    if (looksLikeTimestampNumber(value)) {
        const ts = String(value).length === 10 ? Number(value) * 1000 : Number(value);

        return !isNaN(new Date(ts).getTime());
    }

    return false;
};

const isDateColumn = (values) => {
    if (!values.length) return false;
    return values.every((v) => looksLikeDate(v));
};

// ================= MAIN =================

export function profileData(data = []) {
    if (!Array.isArray(data) || !data.length) return {};

    const columns = Object.keys(data[0]);
    const result = {};

    columns.forEach((column) => {
        const values = data.map((row) => row[column]);
        const nonNullValues = values.filter((v) => !isNullish(v));

        const nullCount = values.length - nonNullValues.length;
        const uniqueCount = new Set(nonNullValues).size;

        const sampleValues = getSampleValues(data, column);

        // ================= TYPE DETECTION =================
        let type = 'string';

        const booleanMatch = isBooleanColumn(sampleValues);
        const numericMatch = isNumericColumn(sampleValues);
        const dateMatch = isDateColumn(sampleValues);

        if (booleanMatch) {
            type = 'boolean';
        } else if (numericMatch) {
            type = 'numeric';
        } else if (dateMatch) {
            type = 'datetime';
        }

        // ================= CONVERTIBILITY =================
        let convertibleTo = null;

        if (type === 'string') {
            // priority: numeric first
            if (numericMatch) {
                convertibleTo = 'numeric';
            } else if (dateMatch) {
                convertibleTo = 'datetime';
            }
        }

        result[column] = {
            type,
            convertibleTo,
            uniqueCount,
            nullCount,
        };
    });

    return result;
}
