export function applyConversions(data = [], resolverOutput = {}, columnMeta = {}) {
    if (!Array.isArray(data) || data.length === 0) return data;

    const roles = resolverOutput?.roles || {};
    const explicitConversions = resolverOutput?.conversions || {};

    const columnsToConvert = { ...explicitConversions };

    // -------------------------------------------------
    // 1️⃣ Auto-normalize datetime axes
    // -------------------------------------------------

    const axisColumns = Object.values(roles).filter(
        (col) => col && col !== '__count__' && col !== '__index__',
    );

    axisColumns.forEach((colName) => {
        const meta = columnMeta[colName];
        if (!meta) return;

        if (meta.type === 'datetime') {
            columnsToConvert[colName] = 'datetime';
        }
    });

    if (Object.keys(columnsToConvert).length === 0) return data;

    // -------------------------------------------------
    // Parsers
    // -------------------------------------------------

    const parseDatetime = (value) => {
        if (value instanceof Date) return value;
        if (value === null || value === undefined) return null;

        // Handle numeric timestamp
        if (typeof value === 'number') {
            let timestamp = value;

            // If likely microseconds → convert to milliseconds
            if (timestamp > 1e12) {
                timestamp = Math.floor(timestamp / 1000);
            }

            const d = new Date(timestamp);
            return isNaN(d.getTime()) ? null : d;
        }

        // Handle string
        if (typeof value === 'string') {
            const trimmed = value.trim();
            if (trimmed === '') return null;

            // Numeric string timestamp
            const numeric = Number(trimmed);
            if (!isNaN(numeric)) {
                let timestamp = numeric;

                if (timestamp > 1e12) {
                    timestamp = Math.floor(timestamp / 1000);
                }

                const d = new Date(timestamp);
                return isNaN(d.getTime()) ? null : d;
            }

            const parsed = new Date(trimmed);
            return isNaN(parsed.getTime()) ? null : parsed;
        }

        return null;
    };

    const parseNumeric = (value) => {
        if (typeof value === 'number') return value;
        if (typeof value === 'boolean') return value ? 1 : 0;
        if (value === null || value === undefined) return null;

        const trimmed = String(value).trim();
        if (trimmed === '') return null;

        const num = Number(trimmed);
        return isNaN(num) ? null : num;
    };

    const toCategorical = (value) => {
        if (value === null || value === undefined) return null;
        return String(value);
    };

    // -------------------------------------------------
    // 2️⃣ Apply conversions
    // -------------------------------------------------

    return data.map((row) => {
        const newRow = { ...row };

        Object.entries(columnsToConvert).forEach(([column, type]) => {
            if (!(column in newRow)) return;

            switch (type) {
                case 'numeric':
                    newRow[column] = parseNumeric(newRow[column]);
                    break;

                case 'datetime':
                    newRow[column] = parseDatetime(newRow[column]);
                    break;

                case 'categorical':
                    newRow[column] = toCategorical(newRow[column]);
                    break;
            }
        });

        return newRow;
    });
}
