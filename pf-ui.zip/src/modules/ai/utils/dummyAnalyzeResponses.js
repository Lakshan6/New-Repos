// dummyAnalyzeResponses.js

// IMPORTANT:
// jsonResponse and chartResponse MUST be STRINGIFIED
// because your frontend expects stringified JSON.

export const dummyAnalyzeResponses = [
    // -----------------------------
    // 1️⃣ Project Count Example
    // -----------------------------
    {
        chartPossible: true,
        chartResponse: JSON.stringify({
            data: [
                { group: 'Alpha', value: 12 },
                { group: 'Beta', value: 8 },
                { group: 'Gamma', value: 15 },
            ],
        }),
        jsonResponse: JSON.stringify({
            headers: [
                { key: 'id', header: 'ID' },
                { key: 'project', header: 'Project' },
                { key: 'count', header: 'Count' },
            ],
            rows: [
                { id: '1', project: 'Alpha', count: 12 },
                { id: '2', project: 'Beta', count: 8 },
                { id: '3', project: 'Gamma', count: 15 },
            ],
        }),
    },

    // -----------------------------
    // 2️⃣ Monthly Sales Example
    // -----------------------------
    {
        chartPossible: true,
        chartResponse: JSON.stringify({
            data: [
                { group: 'Jan', value: 1200 },
                { group: 'Feb', value: 900 },
                { group: 'Mar', value: 1500 },
            ],
        }),
        jsonResponse: JSON.stringify({
            headers: [
                { key: 'month', header: 'Month' },
                { key: 'sales', header: 'Sales' },
            ],
            rows: [
                { month: 'Jan', sales: 1200 },
                { month: 'Feb', sales: 900 },
                { month: 'Mar', sales: 1500 },
            ],
        }),
    },

    // -----------------------------
    // 3️⃣ No Chart Example
    // -----------------------------
    {
        chartPossible: false,
        chartResponse: null,
        jsonResponse: JSON.stringify({
            headers: [
                { key: 'employee', header: 'Employee' },
                { key: 'department', header: 'Department' },
            ],
            rows: [
                { employee: 'John', department: 'HR' },
                { employee: 'Sara', department: 'Finance' },
                { employee: 'Mike', department: 'Engineering' },
            ],
        }),
    },
];
