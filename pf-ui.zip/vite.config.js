import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';
import { visualizer } from 'rollup-plugin-visualizer';
import path from 'path';

export default defineConfig(({ mode }) => {

    const env = loadEnv(mode, process.cwd(), '');
    
    return {
        base: '/web/', // 👈 Added this line — sets the context path
        plugins: [react(), visualizer()],
        resolve: {
            alias: {
                '@modules': path.resolve(__dirname, 'src/modules'),
                '@shared': path.resolve(__dirname, 'src/shared'),
                '@snd': path.resolve(__dirname, 'src/modules/sales-and-distribution'),
            },
        },
        server: {
            port: env.VITE_APP_PORT ? Number(env.VITE_APP_PORT) : 3000,
            strictPort: true,
            open: '/web/login',
            proxy: {
                '/api': {
                    //target: 'http://localhost:80',
                    target: 'http://172.16.2.5:80',
                    changeOrigin: true,
                },
                '/v1': {
                  //  target: 'http://localhost:80',
                    target: 'http://172.16.2.5:80',
                    changeOrigin: true,
                }
            }
        },
    };
});