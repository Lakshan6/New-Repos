# 🧩 PF UI

## 🚀 About

A lightweight React UI shell used by the Census frontend (pf-ui).

This repository contains a Vite + React application built with PrimeReact components, Jotai for state, TanStack Query for data fetching, and a small set of utilities and shared components used across modules.

## 💻 Technology Stack

- Framework: **React (v19)**
- Bundler: **Vite**
- UI kit: **PrimeReact + PrimeFlex + PrimeIcons**
- Styling: **Sass + PrimeFlex utility classes**
- State Management: **Jotai**
- Data fetching: **@tanstack/react-query**
- Navigation: **React Router**

## 📥 Installation

#### ✅ Prerequisites

- Node.js 22.x (as declared in package.json engines)
- npm 10.x (recommended)
- A modern OS (Windows/macOS/Linux)

## ▶️ Running Application

1. Clone the repository and install dependencies:

```powershell
git clone <repo-url> pf-ui
cd pf-ui
npm install
```

2. Start the dev server:

```powershell
npm run dev
```

By default the Vite dev server will open to `/web/login`. The server port can be controlled via the `VITE_APP_PORT` environment variable.

## Scripts

- `npm run dev` - Start the Vite development server
- `npm run build` - Create a production build (Vite)
- `npm run preview` - Preview the production build locally
- `npm run lint` - Run ESLint
- `npm run lint:fix` - Run ESLint and attempt to fix issues
- `npm run format` - Run Prettier (formatting)
- `npm run format:fix` - Run Prettier and write fixes

These scripts are defined in `package.json`.

## Environment variables

- `VITE_APP_PORT` - port the dev server listens on (defaults to 5173 if not set)

Any other environment-specific configuration (API backends, feature flags) should follow the Vite convention and be prefixed with `VITE_` if you need them available in client code.

## 🌳 Project Structure

- `src/` - application source
    - `modules/` - feature modules (admin, dashboard, reports, irs, boilerplate)
        - each module can have its own `routes/`, `components/`, `screens/` and `utils/`
    - `shared/` - shared components, hooks, utils, styles and store
        - `components/` - layout components (topbar, sidebar, footer, menu, providers)
        - `hooks/` - custom React hooks (api helpers, i18n helpers, safe context, etc.)
        - `routes/` - top-level router wiring
        - `screens/` - common screens (Login, ErrorPage, Landing, NotFound)
        - `store/` - global atoms/state
        - `styles/` - SCSS partials and main styles
        - `utils/` - apiRequest, constants, queryClient, loaders

- `vite.config.js` - Vite configuration. Notable bits:
    - aliases: `@modules` -> `src/modules`, `@shared` -> `src/shared`
    - `@vitejs/plugin-react` and `rollup-plugin-visualizer` are configured
    - `server.open` defaults to `/web/login`

## ➕ Adding a new module

1. Adding a new module in the project requires you to simply copy the **boilerplate** folder and rename it the required module name. For ex: **pf-remote-irs**

2. Add an entry to the module in [shared/utils/constants.js](./src/shared/utils/constants.js) at `AVAILABLE_MODULES` and `MODULES`.

3. Change the module name to the respective module to load the translations in this line of `routes/Router.jsx`

    ```js
    <TranslationProvider module={'<module_name_here_in_caps>'} translationsAtom={translationsAtom}>
    ```

4. Set the service and context url for the same module in the [.env.local](.env.local) and [.env.production](.env.production) .

5. Restart the frontend server.

## ➕Adding new screens

Create a new screen in the `screens/` folder.

**Example** : Suppose you have created and exported a screen named `Sample.jsx`, specify the url path to access it like this in your `routes/Router.jsx`:

```js
<Routes>
    <Route index element={<>IRS Home Page</>} />
    <Route path="/sample" element={<Sample />} /> // this will resolve to http://localhost:port/web/landing/your_module/sample
    <Route path="*" element={<>Not Found</>} />
</Routes>
```

All the components required for the screen can be placed inthe `components/` folder.

## 🧭 Navigation
React Router’s useNavigate hook lets you change routes programmatically inside your components.

- **Absolute Navigation**

    Absolute paths always start with `/`, they resolve from the root of your app, no matter where the component is rendered.

    **Example** :

    ```js
    import { useNavigate } from 'react-router';

    export const Dashboard = () => {
      const navigate = useNavigate();

      const goToLogin = () => {
        navigate('/web/login');
      };

      return <button onClick={goToLogin}>Logout</button>;
    };

    ```

    ✅ Use absolute navigation when you want to jump to a specific route regardless of the current location.

- **Relative Navigation**

    Relative paths **do not** start with `/`, they resolve relative to the current route.

    **Example** :

    ```js
    import { useNavigate } from 'react-router';

    export const Users = () => {
      const navigate = useNavigate();

      const goToProfile = () => {
        // If current URL = /web/users
        // This navigates to /web/users/profile
        navigate('profile');
      };

      const goBack = () => {
        // Navigate 1 step back in history
        navigate(-1);
      };

      const goForward = () => {
        // Navigate 1 step forward in history
        navigate(1);
      };

      return (
        <>
          <button onClick={goToProfile}>Go to Profile</button>
          <button onClick={goBack}>Go Back</button>
          <button onClick={goForward}>Go Forward</button>
        </>
      );
    };
    ```

- **Relative with segments**

    navigate('../settings') → Goes up one level and then to settings

    **Example**:

    ```
    If current path = /web/users/123,

    navigate('../settings') → /web/users/settings
    ```

## 📡 Data Fetching

This project uses a hybrid data-fetching architecture that combines the strengths of **React Router Data APIs** and **TanStack React Query**.

To simplify and standardize API requests across the project, we expose two wrapper hooks:

**Use useReadApi (query) for data you want fetched automatically on component mount, and useMutationApi (mutation) for actions you only want to run on demand.**

- **useReadApi** → **READ ONLY** (GET / POST on component mount + refetch on demand).

    This hook is used for read operations. It wraps useQuery from TanStack Query.

    Suitable only for idempotent APIs (fixed endpoint -> fixed response).

    **Signature**

    ```js
    useReadApi({
        service, // Target service (user, mdms, workflow, etc.)
        endpoint, // API endpoint (string, e.g. "/users/1")
        method, // HTTP method (default = 'GET')
        body, // body for the request
        useGateway, // Whether to route via Gateway (default = true)
        options, // React Query options (enabled, refetchInterval, etc.)
    });
    ```

    **Example 1**: This useReadApi fetches the data required on component mount.

    ```js
    import { useReadApi } from "@shared/hooks";

    export function UserProfile(userId) {
      const { data, isLoading, error } = useReadApi({
        service: "user",
        endpoint: `/profile/${userId}`,
      });

      if (isLoading) return <p>Loading...</p>;
      if (error) return <p>Failed to load profile</p>;

      return <h2>Welcome, {data?.name}</h2>;
    }
    ```

    **Example 2**: This useReadApi fetches the data required on demand.

    ```js
    import { useReadApi } from "@shared/hooks";

    export function UserProfile() {
      const { data, isFetching, error, refetch } = useReadApi({
        service: "user",
        endpoint: `/profile/${userId}`,
        options: { enabled: false }, // don't fetch automatically
      });

      if (error) return <p>Failed to load profile</p>;

      return (
        <div>
          <button onClick={() => refetch()} disabled={isFetching}>
            {isFetching ? "Loading..." : "Load Profile"}
          </button>

          {data && <h2>Welcome, {data.name}</h2>}
        </div>
      );
    }
    ```

- **useMutationApi** → (POST, PUT, PATCH, DELETE) on demand only.

    This hook is used for write operations. It wraps useMutation from TanStack Query.

    **Signature**

    ```js
    useMutationApi({
        service, // Target service (user, workflow, etc.)
        endpoint, // API endpoint (e.g. "/users")
        method, // HTTP method (default = 'POST')
        useGateway, // Whether to route via Gateway (default = true)
        options, // React Query mutation options (onSuccess, onError, etc.)
    });
    ```

    **Example**

    ```js
    import { useMutationApi } from "@shared/hooks";

    export function CreateUserForm() {
      const createUser = useMutationApi({
        service: "user",
        endpoint: "/create",
        method: "POST",
        options: {
          onSuccess: () => {
            alert("User created successfully!");
          },
          onError: (err) => {
            console.error("Failed to create user", err);
          },
        },
      });

      const handleSubmit = () => {
        createUser.mutate({ name: "Alice" });
      };

      return <button onClick={handleSubmit}>Create User</button>;
    }
    ```

Both hooks internally rely on a shared utility `apiRequest` that builds service URLs and handles HTTP requests consistently.